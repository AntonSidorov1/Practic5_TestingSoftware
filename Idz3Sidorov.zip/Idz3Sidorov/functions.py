"""Функции для ИДЗ1. сидоров антон дмитриевич, Группа 3586"""

import random
import datetime

def create_students()->dict:
    """Создание списка студентов"""
    students:dict = {} # students:dict = dict()
    students["сидоров антон дмитриевич"] = []
    students["Тамлвыа Лвимоалм Имаум"]=[]
    students["Учяялиоотавл Лиишми Выришфа"]=[]
    students["Фашмрравш Шшрагри Шгармшг"]=[]
    students["Хшармимшравы Арммшгшва Ырггвааива"]=[]
    return students

def create_grades(min_grades: int, max_grades:int, count:int) -> list:
    """Метод генерации оценок"""
    return [random.randint(min_grades, max_grades) for _ in range(count)]

def print_students(students: dict):
    """Вывод оценок"""
    max_len:int = len(max(students, key=len))
    for student, grades in students.items():
        grades_row:str = str(grades)
        grades_row = grades_row.replace("[", "")
        grades_row = grades_row.replace("]", "")
        grades_row = grades_row.replace(";", "")
        grades_row = grades_row.replace(",", "")
        print(f"| {(str(student)):<{max_len}} | {grades_row} |")


def input_int(message: str) -> int:
    """Ввод целого числа с проверкой"""
    res:int = 0
    while True:
        try:
            print(f"Введите целое число ({message})")
            res = int(input())
            break
        except Exception:
            print("Ошибка!!! Error 400 Bad Request")
            print("Значение должно быть целым положительным числом")
    return res

def get_now_date() -> str :
    "Получить текущие дату и время"
    date:datetime = datetime.datetime.now()
    return date.strftime(date.strftime("%d-%m-%Y %H:%M:%S"))
