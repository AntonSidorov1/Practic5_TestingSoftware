"""Индивидуальное домашнее задание 3. Циклы, словари. сидоров антон дмитриевич, Группа 3586"""
from functions import *
print("ИДЗ1. Словари, циклы ")
print("Автор программы – студент Группы 3586, Сидоров Антон Дмитриевич")
print()
print("Время запуска программы - "+get_now_date())
print()
columsCount: int = input_int("Количество оценок")

students: dict = create_students()
for student, grades in students.items():
    MIN_GRADE, MAX_GRADE = 1, 5
    if student == "сидоров антон дмитриевич":
        MIN_GRADE = 4
    grades += create_grades(MIN_GRADE, MAX_GRADE, columsCount)

print_students(students)
