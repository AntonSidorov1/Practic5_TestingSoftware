﻿namespace TableAIS
{
    public static class Buffer
    {
        static string text;

        public static string Text
        {
            get => text;
            set => text = value;
        }
        public static CalculatePositionCopy CalculatetionCopy { get => calculatetionCopy; set => calculatetionCopy = value; }

        public static CalculatePositionCopy GetCalculatetionCopy() => calculatetionCopy.GetThis();

        static CalculatePositionCopy calculatetionCopy;
    } 
}
