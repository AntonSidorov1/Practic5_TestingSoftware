﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class AbstractBigConverter : ConverterList
    {
        public AbstractBigConverter() : base()
        {
            MetrsConvert convert = Add("");
            convert.ConvertFrom = (value) => value;
            convert.ConvertTo = (value) => value;

            convert = Add("Выбранный вариант");
            convert.ConvertFrom = (value) => VariantFrom(value);
            convert.ConvertTo = (value) => VariantTo(value);
        }

        public MetrsConvert FirstOperation => Get(0);

        public string NameFirst
        {
            get => FirstOperation.Name;
            set => FirstOperation.Name = value;
        }

        public MetrsConvert VariantOperation => Get(1);

        public string NameVariant
        {
            get => VariantOperation.Name;
            set => VariantOperation.Name = value;
        }

        public abstract double VariantFrom(double value);
        public abstract double VariantTo(double value);

    }
}
