﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class AbstractConverter
    {
        public AbstractConverter()
        {
        }

        public abstract string NameConvert{get;}

        public override string ToString()
        {
            return NameConvert;
        }
    }
}
