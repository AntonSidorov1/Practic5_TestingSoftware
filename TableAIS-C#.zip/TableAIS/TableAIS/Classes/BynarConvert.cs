﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TableAIS
{

    internal class BynarConvert : NameConverter
    {
        public BynarConvert() : base()
        {
        }

        public BynarConvert(string name) : base(name)
        {
        }

        Func<double, double, double> calculate;
        public Func<double, double, double> Calculate;

        public double RunCalculate(double x, double y)
        {
            return Calculate?.Invoke(x, y)??0;
        }
    }
}
