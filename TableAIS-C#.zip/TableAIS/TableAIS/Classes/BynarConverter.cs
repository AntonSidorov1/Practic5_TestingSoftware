﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace TableAIS
{
    internal class BynarConverter : ConverterList
    {
        public BynarConverter() : base()
        {
            BynarIndex = -1;
            IndexOperand1 = -1;
            IndexOperand2 = -1;
            IndexConvertResult = -1;
            bynarIndexesResult = new List<IndexesConvert>();
            bynarIndexesOperand1 = new List<IndexesConvert>();
            bynarIndexesOperand2 = new List<IndexesConvert>();
            BynarConverts = new List<BynarConvert>();
            AddOperand1();
            AddOperand2();
            AddResult();
            Create();
        }

        List<BynarConvert> bynarConverts;

        public List<BynarConvert> BynarConverts
        {
            get => bynarConverts;
            set => bynarConverts = value;
        }

        public BynarConvert AddBynar(string name)
        {
            BynarConvert result = new BynarConvert(name);
            BynarConverts.Add(result);
            return result;
        }

        int bynarIndex;

        public int BynarIndex
        {
            get => bynarIndex;
            set => bynarIndex = value;
        }

        public override int ToIndex { get => GetResult().ToIndex; set => GetResult().ToIndex = value; }
        public override int FromIndex { get => GetResult().FromIndex; set => GetResult().FromIndex = value; }

        public int ToIndex1 { get => GetOperand1().ToIndex; set => GetOperand1().ToIndex = value; }
        public int FromIndex1 { get => GetOperand1().FromIndex; set => GetOperand1().FromIndex = value; }

        public int ToIndex2 { get => GetOperand2().ToIndex; set => GetOperand2().ToIndex = value; }
        public int FromIndex2 { get => GetOperand2().FromIndex; set => GetOperand2().FromIndex = value; }

        public string IndexesText => $"{IndexOperand1}:{IndexOperand2}:{IndexResult}";

        List<IndexesConvert> bynarIndexesResult, bynarIndexesOperand1, bynarIndexesOperand2;

        public List<IndexesConvert> BynarIndexesResult => bynarIndexesResult;
        public List<IndexesConvert> BynarIndexesOperand1 => bynarIndexesOperand1;
        public List<IndexesConvert> BynarIndexesOperand2 => bynarIndexesOperand2;

        public void AddResult()
        {
            BynarIndexesResult.Add(new IndexesConvert(0, 0));
            IndexConvertResult = BynarIndexesResult.Count - 1;
        }

        public IndexesConvert GetResult(int index) => BynarIndexesResult[index];
        public IndexesConvert GetOperand1(int index) => BynarIndexesOperand1[index];
        public IndexesConvert GetOperand2(int index) => BynarIndexesOperand2[index];

        public IndexesConvert GetOperand1() => GetOperand1(IndexOperand1);
        public IndexesConvert GetOperand2() => GetOperand2(IndexOperand2);
        public IndexesConvert GetResult() => GetResult(IndexConvertResult);

        int indexOperand1, indexOperand2, indexConvertResult;

        public int IndexConvertResult
        {
            get => indexConvertResult;
            set => indexConvertResult = value;
        }

        public int IndexOperand1
        {
            get => indexOperand1;
            set => indexOperand1 = value;
        }

        public int IndexOperand2
        {
            get => indexOperand2;
            set => indexOperand2 = value;
        }

        public int CountIndexesOperand1 => BynarIndexesOperand1.Count;
        public int LastIndexesOperand1 => CountIndexesOperand1 - 1;
        public int CountIndexesOperand2 => BynarIndexesOperand2.Count;
        public int LastIndexesOperand2 => CountIndexesOperand2 - 1;

        public int CountIndexesResult => BynarIndexesResult.Count;
        public int LastIndexesResult => CountIndexesResult - 1;

        public void IndexOperand1Plus()
        {
            int index = IndexOperand1;
            if (index < LastIndexesOperand1)
                IndexOperand1 = index + 1;
        }

        public int IndexResult
        {
            get => IndexConvertResult;
            set => IndexConvertResult = value;
        }

        public void IndexOperand2Plus()
        {
            int index = IndexOperand2;
            if (index < LastIndexesOperand2)
                IndexOperand2 = index + 1;
        }

        public void IndexResultPlus()
        {
            int index = IndexResult;
            if (index < LastIndexesResult)
                IndexResult = index + 1;
        }

        public void IndexOperand1Mines()
        {
            int index = IndexOperand1;
            if (index > 0)
                IndexOperand1 = index - 1;
        }

        public void IndexOperand2Mines()
        {
            int index = IndexOperand2;
            if (index > 0)
                IndexOperand2 = index - 1;
        }

        public void IndexResultMines()
        {
            int index = IndexResult;
            if (index > 0)
                IndexResult = index - 1;
        }

        public void AddOperand1()
        {
            BynarIndexesOperand1.Add(new IndexesConvert(0, 0));
            IndexOperand1 = BynarIndexesOperand1.Count - 1;
        }

        public void AddOperand2()
        {
            BynarIndexesOperand2.Add(new IndexesConvert(0, 0));
            IndexOperand2 = BynarIndexesOperand2.Count - 1;
        }

        public void DeleteResult(int index)
        {
           BynarIndexesResult.RemoveAt(index);
        }

        public void DeleteResult()
        {
            DeleteResult(IndexResult);
            IndexResultMines();
        }

        public void DeleteOperand1(int index)
        {
            BynarIndexesOperand1.RemoveAt(index);
        }

        public void DeleteOperand1()
        {
            DeleteOperand1(IndexOperand1);
            IndexOperand1Mines();
        }

        public void DeleteOperand2(int index)
        {
            BynarIndexesOperand2.RemoveAt(index);
        }

        public void DeleteOperand2()
        {
            DeleteOperand2(IndexOperand2);
            IndexOperand2Mines();
        }

        public BynarConvert GetBynarConvert(int index)
        {
            return BynarConverts[index];
        }

        public BynarConvert GetBynarConvert()
        {
            return BynarConverts[BynarIndex];
        }

        public BynarConvert GetBynarConvert(string name)
        {
            return BynarConverts.Find(x => x.Name == name);
        }

        public double RunCalculate(int index, double x, double y)
        {
            return GetBynarConvert(index).RunCalculate(x, y);
        }

        public double RunCalculate(double x, double y)
        {
            return GetBynarConvert().RunCalculate(x, y);
        }

        public double RunCalculate(string name, double x, double y)
        {
            string index = name;
            return GetBynarConvert(index).RunCalculate(x, y);
        }

        public double CalculateResult(double x, double y)
        {
            return RunConvertResultAll(RunCalculate(RunConvertOperand1All(x), RunConvertOperand2All(y)));
        }

        public double RunConvertResultAll(double z)
        {
            int count = BynarIndexesResult.Count;
            for(int i = 0; i < count; i++)
            {
                z = Convert(BynarIndexesResult[i], z);
            }
            return z;
        }

        public double RunConvertOperand1All(double x)
        {
            int count = BynarIndexesOperand1.Count;
            for (int i = 0; i < count; i++)
            {
                x = Convert(BynarIndexesOperand1[i], x);
            }
            return x;
        }

        public double RunConvertOperand2All(double y)
        {
            double x = y;
            int count = BynarIndexesOperand2.Count;
            for (int i = 0; i < count; i++)
            {
                x = Convert(BynarIndexesOperand2[i], x);
            }
            return x;
        }

    }
}
