﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Двоичный код
    /// </summary>
    public class BynaryCode
    {
        /// <summary>
        /// Тип двоичного представления
        /// </summary>
        public enum CodeTupe
        {
            None,
            Direct,
            Ret,
            Dope
        }

        public static int IntByNoneCode(string bynary)
        {
            char first = bynary[0];
            bool negative = false;
            if (first == '-')
            {
                negative = true;
                bynary = bynary.Remove(0, 1);
            }
            int number = BynaryCode.BynaryInt(bynary);
            if (negative)
                number *= -1;
            return number;
        }

        public static int IntByDirectCode(string bynary)
        {
            char first = bynary[0];
            bool negative = false;
            if (first == '-')
            {
                negative = true;
                bynary = bynary.Remove(0, 1);
            }
            bool negative1 = false;
            if (bynary[0] == '1' && bynary.Length > 31)
            {
                negative1 = true;
            }
            if (bynary.Length > 31)
                bynary = bynary.Remove(0, 1);
            int number = BynaryCode.BynaryInt(bynary);
            if (negative)
                number *= -1;
            if(negative1)
                number *= -1;
            return number;
        }


        public static int IntByDopeCode(string bynaryCode)
        {
            uint number = 0;

            int length = bynaryCode.Length;
            for (int i = 0; i < length; i++)
            {
                char c = bynaryCode[i];
                int digit = int.Parse(c.ToString());
                if (digit != 0 && digit != 1)
                    throw new Exception();
                int j = length - i - 1;
                number += (uint)(digit * Power(2, j));
            }

            return (int)number;
        }


        public static int IntByRetCode(string bynary)
        {
            char first = bynary[0];
            bool negative = false;
            if (first == '-')
            {
                negative = true;
                bynary = bynary.Remove(0, 1);
            }
            bool negative1 = false;
            if (bynary[0] == '1' && bynary.Length > 31)
            {
                negative1 = true;
            }
            if (bynary.Length > 31)
                bynary = bynary.Substring(1);
            if (negative1)
                bynary = Invert(bynary);
            int number = BynaryCode.BynaryInt(bynary);
            if (negative)
                number *= -1;
            if (negative1)
                number *= -1;
            return number;
        }



        public static string BynaryInt(int number, CodeTupe type, bool run = false)
        {
            if(type == CodeTupe.Dope)
            {
                return DopeCode(number);
            }
            if(type == CodeTupe.Ret)
            {
                return RetCode(number);
            }
            if(type == CodeTupe.Direct)
            {
                return DirectCode(number);
            }
            return BynaryWithSign(number, run);
        }

        public static string Invert(string code)
        {
            string result = "";
            for(int i = 0; i< code.Length; i++)
            {
                char sign = code[i];
                if(sign == '-')
                {
                    result += "-";
                }
                else 
                //if (sign != '0' && sign != '1')
                 //   throw new Exception();
                //result += sign == '1' ? "0" : "1";
                result += Invert(sign);
            }
            return result;
        }

        public static char Invert(char sign)
        {
            if (sign != '0' && sign != '1')
                throw new Exception();

            int num = int.Parse(sign + "");

            return InvertChar(num).ToString()[0];
        }

        public static int InvertChar(int sign)
        {
            if (sign != 0 && sign != 1)
                throw new Exception();
            return 1 - sign;
        }

        public static string DopeCode(int number)
        {
            /*
            if (number >= 0)
                return BynaryInt(number);
            else
            */
            {
                uint num1 = (uint)number;
                //num1++;
                string bynary = "";

                while (num1 > 0)
                {
                    bynary = (num1 % 2) + bynary;
                    num1 /= 2;
                }

                return bynary;
            }
        }

        public static int CharToInt(char sign)
        {
            return sign;
        }

        public static string BynaryInt(int number)
        {
            string bynary = "";

            while (number > 0)
            {
                bynary = (number % 2)+bynary;
                number /= 2;
            }
            if (bynary.Length < 1)
                bynary = "0";
            return bynary;
        }

        public static string DirectCode(int number)
        {
            string bynary = RunBynaryInt(number);
            if(number < 0)
            {
                bynary = "1" + bynary.Remove(0, 1);
            }
            return bynary;
        }

        public static string RetCode(int number)
        {
            return RetCode(DirectCode(number));
        }

        public static string RetCode(string bynary)
        {
            bynary = RunBynary(bynary);
            char sign = bynary[0];
            if (sign == '0')
                return bynary;
            else
            {
                string newBynary = "1";

                for(int i = 1; i<bynary.Length; i++)
                {
                    newBynary += Invert(bynary[i]);
                }

                return newBynary;
            }
        }


        public static string BynaryWithSign(int number, bool run)
        {
            return run? RunBynaryWithSign(number):BynaryWithSign(number);
        }


        public static string BynaryWithSign(int number)
        {
            string bynary = BynaryInt(Math.Abs(number));
            int sign = HyperbolicFunctions.Sgn(number);

            if(sign == -1)
            {
                bynary = "-" + bynary;
            }

            return bynary;
        }

        public static string RunBynaryWithSign(int number)
        {
            string bynary = RunBynaryInt(Math.Abs(number));
            int sign = HyperbolicFunctions.Sgn(number);

            if (sign == -1)
            {
                bynary = "-" + bynary;
            }

            return bynary;
        }


        public static string RunBynaryInt(int number)
        {
            return RunBynary(BynaryInt(number));
        }

        public static string RunBynary(string oldBynary)
        {
            string newBynary = oldBynary;

            while (newBynary.Length < 32)
            {
                newBynary = "0" + newBynary;
            }

            return newBynary;
        }

        public static string RunBynary(string oldBynary, int length)
        {
            string newBynary = oldBynary;

            while (newBynary.Length < length)
            {
                newBynary = "0" + newBynary;
            }

            return newBynary;
        }

        public static string BynaryInt(uint number)
        {
            string bynary = "";

            while (number > 0)
            {
                bynary = (number % 2) + bynary;
                number /= 2;
            }

            return bynary;
        }

        public static string BynaryChar(char sign)
        {
            return BynaryInt(CharToInt(sign));
        }

        /// <summary>
        /// Преобразует текст в двоичный код
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string BynaryText(string text)
        {
            List<string> list = new List<string>();

            int length = text.Length;
            for(int i = 0; i < length; i++)
            {
                list.Add(BynaryChar(text[i]));
            }

            return string.Join(" ", list);
        }


        public static string BynaryText(string text, Encoding encoding)
        {
            string bynaryCode = "";

            List<string> list = new List<string>();

            byte[] bytes = encoding.GetBytes(text);

            for(int i = 0; i < text.Length; i++)
            {
                char symwol = text[i];
                string test = symwol + "";
                byte[] bytesTest = encoding.GetBytes(test);


                string part = "";
                int code = 0;

                try
                {
                    code = BitConverter.ToInt32(bytesTest, 0);
                }
                catch
                {
                    try
                    {
                        code = BitConverter.ToChar(bytesTest, 0);
                    }
                    catch
                    {
                        code = bytesTest[0];
                    }
                }
                
                list.Add(BynaryInt(code));

            }
            bynaryCode = String.Join(" ", list);

            return bynaryCode;
        }


        public static char IntToChar(int number)
        {
            return (char)number;
        }

        public static int Power(int number, int stepen)
        {
            int result = 1;
            for(int i = 0; i < stepen; i++)
            {
                result *= number;
            }
            return result;
        }

        public static char BynaryChar(string bynaryCode)
        {
            return IntToChar(BynaryInt(bynaryCode));
        }

            public static int BynaryInt(string bynaryCode)
        {
            int number = 0;

            int length = bynaryCode.Length;
            for(int i = 0; i < length; i++)
            {
                char c = bynaryCode[i];
                int digit = int.Parse(c.ToString());
                if (digit != 0 && digit != 1)
                    throw new Exception();
                int j = length - i - 1;
                number += digit * Power(2, j);
            }
            
            return number;
        }

        /// <summary>
        /// Преобразует двоичный код в текст
        /// </summary>
        /// <param name="bynaryCode"></param>
        /// <returns></returns>
        public static string TextByBynaryCode(string bynaryCode)
        {
            string result = "";
            string[] parts = bynaryCode.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int length = parts.Length;
            for(int i = 0; i < length;i++)
            {
                
                result += BynaryChar(parts[i]);
            }
            return result;
        }

        /// <summary>
        /// Преобразует двоичный код в текст
        /// </summary>
        /// <param name="bynaryCode"></param>
        /// <returns></returns>
        public static string TextByBynaryCode(string bynaryCode, Encoding encoding)
        {
            string text = "";

            List<byte> bytes = new List<byte>();
            string[] parts = bynaryCode.Split(' ');

            for (int i = 0; i < parts.Length; i++)
            {
                byte[] code = BitConverter.GetBytes((char)BynaryInt(parts[i]));

                string symwol = encoding.GetString(code).Trim('\0');
                text += symwol;
            }

            return text;
        }


        public static bool IsBynaryCode(string code)
        {
            char sign = code[0];
            if (sign != '-' && sign!= '0' && sign != '1')
                return false;
            for(int i = 1; i<code.Length;i++)
            {
                sign = code[i];
                if (sign != '0' && sign != '1')
                    return false;
            }

            return true;
        }

        public static string AsBynaryCode(string code)
        {
            if (code.Length < 1)
                return code;
            if(IsBynaryCode(code))
                return code;
            throw new FormatException();
        }


        public static char Konunkt(char a, char b)
        {
            if (a != '0' && a != '1')
                throw new Exception();
            if (b != '0' && b != '1')
                throw new Exception();
            int na = int.Parse(a + "");
            int nb = int.Parse(b + "");

            return KonunktChar(na, nb).ToString()[0];

        }

        public static int KonunktChar(int a, int b)
        {
            if (a != 0 && a != 1)
                throw new Exception();
            if (b != 0 && b != 1)
                throw new Exception();

            return (a * b);

        }

        public static string LogicalShiftRight(string code, int number)
        {
            string res = code;
            if(number < 0)
            {
                return LogicalShiftLeft(code, -number);
            }
            for(int i = 0; i<number; i++)
            {
                res = LogicalShiftRight(res);
            }
            return res;
        }

        public static string LogicalShiftLeft(string code, int number)
        {
            string res = code;
            if (number < 0)
            {
                return LogicalShiftRight(code, -number);
            }
            for (int i = 0; i < number; i++)
            {
                res = LogicalShiftLeft(res);
            }
            return res;
        }

        public static string ArithmeticShiftRight(string code, int number)
        {
            string res = code;
            if (number < 0)
            {
                return ArithmeticShiftLeft(code, -number);
            }
            for (int i = 0; i < number; i++)
            {
                res = ArithmeticShiftRight(res);
            }
            return res;
        }

        public static string ArithmeticShiftLeft(string code, int number)
        {
            string res = code;
            if (number < 0)
            {
                return ArithmeticShiftRight(code, -number);
            }
            for (int i = 0; i < number; i++)
            {
                res = ArithmeticShiftLeft(res);
            }
            return res;
        }

        public static string LogicalShiftRight(string code)
        {
            code = RunBynary(code);
            code = "0" + code;
            return code.Remove(32);
        }

        public static string ArithmeticShiftRight(string code)
        {
            code = RunBynary(code);
            code = code[0] + code;
            return code.Remove(32);
        }

        public static string LogicalShiftLeft(string code)
        {
            code = RunBynary(code);
            code = code+"0";
            return code.Substring(1);
        }

        public static string ArithmeticShiftLeft(string code)
        {
           return LogicalShiftLeft(code);
        }

        public static string CycleShiftRight(string code)
        {
            code = RunBynary(code);
            code = code[31] + code;
            return code.Remove(32);
        }



        public static string CycleShiftLeft(string code)
        {
            code = RunBynary(code);
            code = code+ code[0];
            return code.Substring(1);
        }


        public static string CycleShiftRight(string code, int number)
        {
            string res = code;
            if (number < 0)
            {
                return CycleShiftLeft(code, -number);
            }
            for (int i = 0; i < number; i++)
            {
                res = CycleShiftRight(res);
            }
            return res;
        }

        public static string CycleShiftLeft(string code, int number)
        {
            string res = code;
            if (number < 0)
            {
                return CycleShiftRight(code, -number);
            }
            for (int i = 0; i < number; i++)
            {
                res = CycleShiftLeft(res);
            }
            return res;
        }


        public static char Sheffer(char a, char b)
        {
            return Invert(Konunkt(a, b));
        }

        public static int ShefferChar(int a, int b)
        {
            return InvertChar(KonunktChar(a, b));
        }

        public static char Pirs(char a, char b)
        {
            return Invert(Dizunkt(a, b));
        }

        public static int PirsChar(int a, int b)
        {
            return InvertChar(DizunktChar(a, b));
        }

        public static char Dizunkt(char a, char b)
        {
            return (Sheffer(Invert(a), Invert(b)));
        }

        public static int DizunktChar(int a, int b)
        {
            return (ShefferChar(InvertChar(a), InvertChar(b)));
        }



        public static char Implicate(char a, char b)
        {
            return Dizunkt(Invert(a), b);
        }

        public static char Equivalention(char a, char b)
        {
            return Konunkt(Dizunkt(Invert(a), Invert(b)), Dizunkt(a, b));
        }

        public static char Zhegalkin(char a, char b)
        {
            return Invert(Equivalention(a, b));
        }

        public string Dizunkt(string a, string b)
        {
            a = RunBynary(a);
            b = RunBynary(b);
            string result = "";
            for (int i = 0; i < 32; i++)
            {
                result += Dizunkt(a[i], b[i]);
            }
            return result;
        }

        public string Konunkt(string a, string b)
        {

            a = RunBynary(a);
            b = RunBynary(b);
            string result = "";
            for (int i = 0; i < 32; i++)
            {
                result += Konunkt(a[i], b[i]);
            }
            return result;
        }

        public string Implicate(string a, string b)
        {

            a = RunBynary(a);
            b = RunBynary(b);
            string result = "";
            for (int i = 0; i < 32; i++)
            {
                result += Implicate(a[i], b[i]);
            }
            return result;
        }

        public string Equivalention(string a, string b)
        {

            a = RunBynary(a);
            b = RunBynary(b);
            string result = "";
            for (int i = 0; i < 32; i++)
            {
                result += Equivalention(a[i], b[i]);
            }
            return result;
        }

        public string Zhegalkin(string a, string b)
        {

            a = RunBynary(a);
            b = RunBynary(b);
            string result = "";
            for (int i = 0; i < 32; i++)
            {
                result += Zhegalkin(a, b);
            }
            return result;
        }





    }
}
