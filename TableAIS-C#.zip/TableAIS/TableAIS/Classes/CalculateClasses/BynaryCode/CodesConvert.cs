﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public static class CodesConvert
    {
        public static char[] SymwolCodes =
        {
            '0','1','2','3','4','5','6','7',
            '8','9','A','B','C','D','E','F',
            'G','H','I','J','K','L','M','N',
            'O','P','Q','R','S','T','U','V',
            'W', 'X','Y','Z'
        };

        public static char NumberToCode(int code)
        {
            return SymwolCodes[code];
        }

        public static string SymwolToCode(int symwol, int ss)
        {
            string code = "";

            while(symwol>0)
            {
                code = NumberToCode(symwol % ss) + code;
                symwol /= ss;
            }

            return code;
        }

        public static string TextToCode(string text, int ss)
        {
            List<string> code = new List<string>();
            int length = text.Length;

            for(int i = 0; i< length;i++)
            {
                code.Add(SymwolToCode(text[i], ss));
            }

            return string.Join(" ", code);
        }

        public static string TextToQuaternaryCode(string text)
        {
            return TextToCode(text, 4);
        }

        public static string TextToOctalCode(string text)
        {
            return TextToCode(text, 8);
        }

        public static string TextToHexadecimalCode(string text)
        {
            return TextToCode(text, 16);
        }



        public static int CodeToInt(string code, int ss)
        {
            code = code.ToUpper();
            int symwol = 0;
            List<char> chars = new List<char>(SymwolCodes);

            int length = code.Length;
            int last = length - 1;
            for (int i = 0; i < length; i++)
            {
                int pos = last - i;
                char c = code[i];
                int number = chars.IndexOf(c);
                if (number < 0 || number >= ss)
                    throw new Exception();
                symwol += number * BynaryCode.Power(ss, pos);
            }

            return symwol;
        }

        public static char CodeToSymwol(string code, int ss)
        {
            return (char)CodeToInt(code, ss);
        }

        public static string CodeToText(string code, int ss)
        {
            string[] parts = code.Split(' ');
            string text = "";
            int length = parts.Length;

            for(int i = 0; i < length; i++)
            {
                text += CodeToSymwol(parts[i], ss).ToString();
            }

            return text;
        }

        public static string QuaternaryCodeToText(string text)
        {
            return CodeToText(text, 4);
        }

        public static string OctalCodeToText(string text)
        {
            return CodeToText(text, 8);
        }

        public static string HexadecimalCodeToText(string text)
        {
            return CodeToText(text, 16);
        }

    }
}
