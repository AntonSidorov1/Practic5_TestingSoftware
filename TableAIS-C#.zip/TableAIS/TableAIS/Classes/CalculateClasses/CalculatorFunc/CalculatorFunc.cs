﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class CalculatorFunc
    {
        public static void Change(ref double a, ref double b)
        {
            double c = a;
            a = b;
            b = c;
        }

        public static void FromMinToMax(ref double a, ref double b)
        {
            if(b > a)
            {
                Change(ref a, ref b);
            }
        }

        public static int CellStepen(ref double number, ref double osnovanie, int tochnost)
        {
            int stepen = 0;
            double b = number;
            double a = osnovanie;
            int f = 0;
            while(b >= a && stepen < tochnost)
            {
                b /= a;
                stepen++;
            }
            number = b;
            osnovanie = a;
            return stepen;
        }

        public static double Stepen(double number, double osnovanie,int tochnost)
        {
            return Stepen(number, osnovanie, tochnost, tochnost);
        }

        public static double Stepen(double number, double osnovanie)
        {
            return Stepen(number, osnovanie, 100000, int.MaxValue - 2);
        }
            

        public static double Stepen(double number, double osnovanie, int length, int tochnost)
        {
            double d = 1.0000001;
            double d1 = 1.000000000001;

            double[] positions = new double[length];
            int stepen = 0;
            int pos = 1;
            double n = 0;
            double b = number;
            double a = osnovanie;
            if (a <= 0 || b <= 0 || a == 1)
                return double.NaN;
            if (b == 1)
                return 0;
            if (a == b)
                return 1;
            bool fromOne = b > 1;
            if (!fromOne)
                b = 1 / b;
            bool fromOne1 = a > 1;
            if(!fromOne1)
            {
                fromOne = !fromOne;
                a = 1 / a;
            }

            if((a>d1 && a < d) || (b>d1 && b < d))
            {
                return Math.Log(b, a);
            }

            if (b < d)
            {
                return 0;
            }
            if (a < d)
            {
                return double.NaN;
            }

            bool few =b > a;
            
                FromMinToMax(ref b, ref a);

            stepen = CellStepen(ref b, ref a, tochnost); 
            positions[0] = stepen;

            if (b > 1 && stepen < tochnost)
            {
                for (int i = 1; i < length; i++)
                {
                    if ((a > d1 && a < d) || (b > d1 && b < d))
                    {
                        positions[i] = Math.Log(a, b);
                        break;
                    }

                    pos = i;
                    if (b < d)
                    {
                        break;
                    }
                    FromMinToMax(ref b, ref a);
                    stepen = CellStepen(ref b, ref a, tochnost);
                    positions[i] = stepen;
                    if (b <= 1 || stepen >= tochnost)
                    {
                        break;
                    }
                }
                for (int i = pos; i > 0; i--)
                {
                    double position = positions[i];
                    if (position != 0)
                        positions[i - 1] += 1 / position;
                }
            }
            n = positions[0];
            n = few ? n : 1 / n;
            n = fromOne ? n : -n;
            return n;
        }
    }
}
