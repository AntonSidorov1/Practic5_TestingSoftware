﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Точкак с запятой (разделитель частей массива в формуле)
    /// </summary>
    public class FormuleArraySplit : FormuleSpecSymwol
    {
        /// <inheritdoc/>
        public FormuleArraySplit() : base()
        {
        }
/// <inheritdoc/>

        public override FormulePart Copy()
        {
            return new FormuleArraySplit();
        }

        /// <inheritdoc/>

        public override string GetText()
        {
            return ";";
        }

        /// <inheritdoc/>

        public override FormulePartType Type()
        {
            return FormulePartType.ArraySplit;
        }
    }
}
