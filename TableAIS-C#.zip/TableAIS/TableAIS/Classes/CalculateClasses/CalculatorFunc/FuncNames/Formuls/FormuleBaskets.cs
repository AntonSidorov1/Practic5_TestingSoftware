﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Скобка в формуле
    /// </summary>
    public abstract class FormuleBaskets : FormuleSpecSymwol
    {
        /// <summary>
        /// Создаёт объект класса
        /// </summary>
        protected FormuleBaskets(bool abs) : base()
        {
            SetAbs(abs);
        }

        bool abs;

        /// <summary>
        /// Является ли скобка модульной
        /// </summary>
        public bool GetAbs()
        {
            return abs;
        }

        /// <summary>
        /// Является ли скобка модульной
        /// </summary>
        public void SetAbs(bool value)
        {
            abs = value;
        }

        /// <summary>
        /// Является ли скобка модульной
        /// </summary>
        public bool Abs
        {
            get => GetAbs();
            set => SetAbs(value);
        }

        /// <summary>
        /// Создаёт открывающую скобку
        /// </summary>
        /// <param name="abs">Модуль</param>
        /// <returns></returns>
        public static FormuleOpenBasket CreateOpen(bool abs)
        {
            return new FormuleOpenBasket(abs);
        }

        /// <summary>
        /// Создаёт закрывающую скобку
        /// </summary>
        /// <param name="abs">Модуль</param>
        /// <returns></returns>
        public static FormuleCloseBasket CreateClose(bool abs)
        {
            return new FormuleCloseBasket(abs);
        }

        /// <inheritdoc/>

        public override FormulePartType Type()
        {
            return FormulePartType.Basket;
        }
    }
}
