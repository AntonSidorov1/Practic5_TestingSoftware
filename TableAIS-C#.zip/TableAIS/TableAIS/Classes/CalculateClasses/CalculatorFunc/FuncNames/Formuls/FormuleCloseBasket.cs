﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Закрывающая скобка в формуле
    /// </summary>
    public class  FormuleCloseBasket : FormuleBaskets
    {
        /// <inheritdoc/>
        public FormuleCloseBasket(bool abs) : base(abs)
        {
        }
/// <inheritdoc/>

        public override FormulePart Copy()
        {
            return new FormuleCloseBasket(Abs);
        }

        /// <inheritdoc/>
        public override string GetText()
        {
            return Abs ? ")|" : ")";
        }
    }
}
