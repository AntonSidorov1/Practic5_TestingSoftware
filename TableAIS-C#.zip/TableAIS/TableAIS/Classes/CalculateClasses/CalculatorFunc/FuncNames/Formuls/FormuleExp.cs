﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Экспонента в формуле
    /// </summary>
    public class FormuleExp : FormuleOperation
    {
        /// <inheritdoc/>
        public FormuleExp() : base()
        {
        }

        public override int BinarnPriority => 0;

        public override int BinarnFewPriority =>6;

        public override int UnarnPriority => BinarnPriority;

        public override int UnarnFewPriority => BinarnFewPriority;

        public override int FuncBinarnPriority => BinarnPriority;

        public override int FuncBinarnFewPriority => BinarnFewPriority;

        public override int FuncUnarnPriority => UnarnPriority;

        public override int FuncUnarnFewPriority => UnarnFewPriority;

        public override bool AllowWithOperator => true;

        public override bool IsOperator => true;

        public override bool AllowReal => true;

        /// <inheritdoc/>

        public override FormulePart Copy()
        {
            FormuleExp exp = new FormuleExp();
            exp.SetByFew(this);
            return exp;
        }

        /// <inheritdoc/>
        public override string GetText()
        {
            return "e";
        }
/// <inheritdoc/>

        public override double RunCalc(double[] values)
        {
            return MyCalculate.GetFuncs().Exp.FuncDoingInvoke(values);
        }
    }
}
