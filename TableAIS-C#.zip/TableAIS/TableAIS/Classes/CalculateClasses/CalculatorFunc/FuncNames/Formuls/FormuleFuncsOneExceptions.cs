﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class FormuleFuncsOneExceptions : FormuleOperand
    {
        public FormuleFuncsOneExceptions(FuncsOneArgumentExceptions exception) : base()
        {
            this.exception = exception;
        }

        FuncsOneArgumentExceptions exception;

        public override bool AllowChange => false;

        public FuncsOneArgumentExceptions Exception { get => exception; set => exception = value; }

        public FuncNames Function => Exception.Featcher;
        public double Argument => Exception.Argument;



        public override FormulePart Copy()
        {
            return new FormuleFuncsOneExceptions(Exception);
        }

        public override string GetText()
        {
            return Function.GetName() + "(" + Argument + ")";
        }
    }
}
