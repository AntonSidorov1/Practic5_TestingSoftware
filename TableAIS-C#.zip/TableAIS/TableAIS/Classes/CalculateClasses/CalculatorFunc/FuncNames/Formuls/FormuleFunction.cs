﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Функция в формуле
    /// </summary>

    public class FormuleFunction : FormuleOperation
    {
        /// <summary>
        /// Создаёт объект класса
        /// </summary>
        /// <param name="psevdoCode"></param>
        /// <param name="nameID"></param>
        public FormuleFunction(int psevdoCode, int nameID) : base()
        {
            this.PsevdoCode = psevdoCode;
            this.NameID = nameID;
        }

        /// <summary>
        /// Создаёт объект класса
        /// </summary>
        /// <param name="psevdoCode"></param>
        public FormuleFunction(int psevdoCode):this(psevdoCode, 0)
        {

        }

        /// <summary>
        /// Создаёт объект класса
        /// </summary>
        public FormuleFunction(FuncNames func):this(func.GetPsevdoName())
        {

        }

        /// <summary>
        /// Создаёт объект класса
        /// </summary>
        public FormuleFunction(FuncNames func, int nameID) : this(func.GetPsevdoName(), nameID)
        {

        }

        int psevdoCode, nameID;
/// <inheritdoc/>


        /// <summary>
        /// Псевдокод функции
        /// </summary>
        public int PsevdoCode { get => psevdoCode; set => psevdoCode = value; }

        /// <summary>
        /// Идентификатор названия функции
        /// </summary>
        public int NameID { get => nameID; set => nameID = value; }

        /// <summary>
        /// Функция
        /// </summary>
        public FuncNames Function => MyCalculate.GetFuncs().Get(PsevdoCode);
/// <inheritdoc/>

        public override int BinarnPriority => Function.GetBynarnPriority();
/// <inheritdoc/>

        public override int BinarnFewPriority => Function.GetBynarnFewPriority();
/// <inheritdoc/>

        public override int UnarnPriority => Function.GetUnarnPriority();
/// <inheritdoc/>

        public override int UnarnFewPriority => Function.GetUnarnFewPriority();

        public bool FuncBeforePower() =>false;

        public override int FuncBinarnPriority => FuncBeforePower()?2:0;

        public override int FuncBinarnFewPriority => 3;

        public override int FuncUnarnPriority => FuncBeforePower() ? 2 : 0;

        public override int FuncUnarnFewPriority => 3;

        public override bool AllowWithOperator => false;

        public override bool IsOperator
        {
            get
            {
                return Function.IsWorkOperator();
            }
        }

        public override bool AllowReal => Function.AllowReal;

        /// <summary>
        /// Отображаемое название функции
        /// </summary>
        /// <returns></returns>
        public string FuncName()
        {
            return Function.GetNameByCode(NameID);
        }


/// <inheritdoc/>



        public override string GetText()
        {
            return FuncName();
        }
/// <inheritdoc/>

        public override FormulePart Copy()
        {
            FormuleFunction function = new FormuleFunction(PsevdoCode, NameID);
            function.SetByFew(this);
            return function;
        }

        public FormuleFunction CopyByPersent()
        {
            return new FormuleFunction(Function.PersentFunction);
        }

/// <inheritdoc/>

        public override double RunCalc(double[] values)
        {
           return Function.FuncDoingInvoke(values);
        }
/// <inheritdoc/>

        public override bool CanHaveBeforeArgument => Function.CanHaveBeforeArgument;
    }
}
