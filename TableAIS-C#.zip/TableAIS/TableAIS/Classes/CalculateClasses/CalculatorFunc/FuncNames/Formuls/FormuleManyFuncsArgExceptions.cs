﻿namespace TableAIS
{
    public class FormuleManyFuncsArgExceptions : FormuleOperand
    {
        public FormuleManyFuncsArgExceptions(ManyFuncsOneExceptions exception) : base()
        {
            this.exception = exception;
        }

        ManyFuncsOneExceptions exception;

        public override bool AllowChange => false;

        public ManyFuncsOneExceptions Exception { get => exception; set => exception = value; }
        public FormulePartList Postfics() => Exception.Postfics();


        public override FormulePart Copy()
        {
            return new FormuleManyFuncsArgExceptions(Exception);
        }

        public override string GetText()
        {
            return Postfics().GetFormuleArr();
        }
    }
}
