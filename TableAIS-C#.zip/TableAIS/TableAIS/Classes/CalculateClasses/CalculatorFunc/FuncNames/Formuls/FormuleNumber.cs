﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Число в формуле
    /// </summary>
    public class FormuleNumber : FormuleOperand
    {
        /// <inheritdoc/>
        public FormuleNumber() : this(0)
        {

        }

        double number;

        /// <summary>
        /// Создаёт объект класса
        /// </summary>
        /// <param name="number"></param>
        public FormuleNumber(double number) : base()
        {
            this.number = number;
        }

        /// <summary>
        /// Число
        /// </summary>
        public double Number
        {
            get => number;
            set => number = value;
        }

        /// <inheritdoc/>
        public override bool AllowChange => true;
/// <inheritdoc/>

        public override string GetText()
        {
            return Number.ToString();
        }
/// <inheritdoc/>

        public override FormulePart Copy()
        {
            return new FormuleNumber(Number);
        }

        public double ToDouble() => Number;
/// <inheritdoc/>

        public override FormulePartType Type()
        {
            return FormulePartType.Number;
        }
    }
}
