﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Открывающая скобка в фомуле
    /// </summary>
    public class FormuleOpenBasket : FormuleBaskets
    {
        /// <inheritdoc/>
        public FormuleOpenBasket(bool abs) : base(abs)
        {
        }
/// <inheritdoc/>

        public override FormulePart Copy()
        {
            return new FormuleOpenBasket(Abs);
        }

        /// <inheritdoc/>

        public override string GetText()
        {
            return Abs ? "|(" : "(";
        }
    }
}
