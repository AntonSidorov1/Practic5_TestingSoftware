﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Операция в формуле
    /// </summary>
    public abstract class FormuleOperation : FormuleSpecSymwol
    {
        /// <inheritdoc/>
        protected FormuleOperation() : base()
        {
            Operate = false;
            //Binarn = true;
            OperandsCount = 2;
            FirstOperate = true;
            LastOperate = false;
            Operate = true;
        }

        public FormuleOperation SetByFew(FormuleOperation op)
        {
            Operate = op.Operate;
            //Binarn = true;
            OperandsCount = op.OperandsCount;
            FirstOperate = op.FirstOperate;
            LastOperate = op.LastOperate;
            Operate = op.Operate;
            return this;
        }

        /// <summary>
        /// Собственный приоритет бинарной операции
        /// </summary>
        public abstract int BinarnPriority { get; }

        /// <summary>
        /// Внешний приоритет бинарной операции
        /// </summary>
        public abstract int BinarnFewPriority { get; }

        /// <summary>
        /// Собственный приоритет унарной операции
        /// </summary>
        public abstract int UnarnPriority { get; }

        /// <summary>
        /// Внешний приоритет унарной операции
        /// </summary>
        public abstract int UnarnFewPriority { get; }



        /// <summary>
        /// Собственный приоритет бинарной операции
        /// </summary>
        public abstract int FuncBinarnPriority { get; }

        /// <summary>
        /// Внешний приоритет бинарной операции
        /// </summary>
        public abstract int FuncBinarnFewPriority { get; }

        /// <summary>
        /// Собственный приоритет унарной операции
        /// </summary>
        public abstract int FuncUnarnPriority { get; }

        /// <summary>
        /// Внешний приоритет унарной операции
        /// </summary>
        public abstract int FuncUnarnFewPriority { get; }

        /// <summary>
        /// Функция - оператор?
        /// </summary>
        public bool Operate { get => operate; set => operate = value; }

        bool operate;

        public int RealBinarnFewPriority => IsDoingByOperator ? BinarnFewPriority : FuncBinarnFewPriority;

        public int RealUnarnFewPriority => IsDoingByOperator ? UnarnFewPriority : FuncUnarnFewPriority;

        public int RealBinarnPriority => IsDoingByOperator ? BinarnPriority : FuncBinarnPriority;

        public int RealUnarnPriority => IsDoingByOperator ? UnarnPriority : FuncUnarnPriority;

        /// <summary>
        /// True - бинарная операция, False - унарная, или многооперандовая операция
        /// </summary>
        public bool Binarn { get => OperandsCount == 2; }

        /// <summary>
        /// True - унарная операция, False - бинарная, или многооперандовая операция
        /// </summary>
        public bool Unarn { get => OperandsCount == 1; }

        public int RealFewPriority => Binarn ? RealBinarnFewPriority : RealUnarnFewPriority;
        public int RealPriority => Binarn ? RealBinarnPriority : RealUnarnPriority;

        public abstract bool AllowWithOperator { get; }
        public abstract bool IsOperator { get; }

        /// <summary>
        /// Количество передаваемых операндов
        /// </summary>
        public int OperandsCount { get => operandsCount; set => operandsCount = value; }

        int operandsCount;

        public abstract bool AllowReal { get; }

        /// <summary>
        /// ВЫполнение операции
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        public abstract double RunCalc(double[] values);

        public bool CanOperator => Binarn || Unarn;

        public bool IsDoingByOperator => CanOperator && Operate && IsOperator;

        public bool FirstOperate { get => firstOperate; set => firstOperate = value; }
        public bool LastOperate { get => lastOperate; set => lastOperate = value; }

        bool firstOperate;

        bool lastOperate;

        public bool IsMoreFewPriority(FormuleOperation op)
        {

            return RealFewPriority < op.RealFewPriority;
        }

        public bool IndexFunc
        {
            get
            {
                if (!IsFunction)
                {
                    return false;
                }
                return AsFunction.Function.IndexFunc;
            }
        }


        /// <inheritdoc/>

        public override FormulePartType Type()
        {
            return IsConst() ? FormulePartType.Const : FormulePartType.Operation;
        }

        /// <summary>
        /// Может ли быть аргумент перед функцией?
        /// </summary>
        public virtual bool CanHaveBeforeArgument
        {
            get => true;
        }


    }
}
