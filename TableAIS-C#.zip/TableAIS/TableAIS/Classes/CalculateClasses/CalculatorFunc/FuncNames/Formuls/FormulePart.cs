﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Часть формулы
    /// </summary>
    public abstract class FormulePart
    {
        /// <summary>
        /// Создаёт объект класса
        /// </summary>
        public FormulePart()
        {
            Create();
        }

        protected virtual void Create()
        {

        }


        /// <summary>
        /// Отображаемый текст
        /// </summary>
        /// <returns></returns>
        public abstract string GetText();


        /// <summary>
        /// Отображаемый текст
        /// </summary>
        /// <returns></returns>
        public sealed override string ToString()
        {
            return GetText();
        }

        /// <summary>
        /// Можно ли менять текст
        /// </summary>
        public abstract bool AllowChange { get; }

        /// <summary>
        /// Преобразует объект в отображаемый текст
        /// </summary>
        /// <param name="part"></param>
        public static implicit operator string(FormulePart part)
        {
            return part.ToString();
        }

        public bool IsNumber => this is FormuleNumber;
        public FormuleNumber AsNumber => this as FormuleNumber;

        public bool IsFunction => this is FormuleFunction;
        public FormuleFunction AsFunction => this as FormuleFunction;

        public bool IsSpecSymwol => this is FormuleSpecSymwol;
        public FormuleSpecSymwol AsSpecSymwol => this as FormuleSpecSymwol;

        public bool IsArraySplit => this is FormuleArraySplit;
        public FormuleArraySplit AsArraySplit => this as FormuleArraySplit;

        public bool IsBaskets => this is FormuleBaskets;
        public FormuleBaskets AsBaskets => this as FormuleBaskets;

        public bool IsOpenBasket => this is FormuleOpenBasket;
        public FormuleOpenBasket AsOpenBasket => this as FormuleOpenBasket;

        public bool IsCloseBasket => this is FormuleCloseBasket;
        public FormuleCloseBasket AsCloseBasket => this as FormuleCloseBasket;

        public bool IsExp => this is FormuleExp;
        public FormuleExp AsExp => this as FormuleExp;

        public bool IsStaticVariable => this is FormuleStaticVariables;
        public FormuleStaticVariables AsStaticVariable => this as FormuleStaticVariables;

        public bool IsMemoryVariable => this is FormuleVariableMemory;
        public FormuleVariableMemory AsMemoryVariable => this as FormuleVariableMemory;

        public bool IsStaticVariableThis() => IsStaticVariable && !IsMemoryVariable;


        public bool IsOperation => this is FormuleOperation;
        public FormuleOperation AsOperation => this as FormuleOperation;

        public bool IsFuncOneException => this is FormuleFuncsOneExceptions;
        public FormuleFuncsOneExceptions AsFuncOneException => this as FormuleFuncsOneExceptions;

        public bool IsOperand => this is FormuleOperand;
        public FormuleOperand AsOperand => this as FormuleOperand;

        public bool IsManyFuncsArgExceptions => this is FormuleManyFuncsArgExceptions;
        public FormuleManyFuncsArgExceptions AsManyFuncsArgExceptions => this as FormuleManyFuncsArgExceptions;

        public bool IsNoCanHaveBeforeArgument()
        {
            if(!IsOperation)
                return false;
            if (IsConst())
                return true;
            else
                return !AsOperation.CanHaveBeforeArgument;
        }


        /// <summary>
        /// Создаёт копию объекта
        /// </summary>
        /// <returns></returns>
        public abstract FormulePart Copy();

        public bool IsCloseOperator => IsArraySplit || IsCloseBasket;

        public bool IsConst()
        {
            if (!IsFunction)
                return IsNumber || IsStaticVariable;
            else
                return AsFunction.Function.IsConst();
        }

        public bool IsConstOrExp()
        {
            return IsConst() || IsExp;
        }

        public bool IsConstExpOpen()
        {
            return IsConstOrExp() || IsOpenBasket || !AllowReal();
        }

        public bool IsConstExpClose()
        {
            return IsConstOrExp() || IsCloseBasket;
        }

        public bool IsConstExpBasket()
        {
            return IsConstOrExp() || IsBaskets;
        }

        public bool EqualsText(String text)
        {
            return GetText() == (text);
        }

        public bool AllowReal()
        {
            if (!IsFunction)
            {
                return true;
            }
            else
            {
                FuncNames func = AsFunction.Function;
                return !func.IsConst() && func.AllowReal;
            }
        }

        public bool IsNoOpen()
        {
            FormulePart partLast = this;
            return (!partLast.IsOpenBasket && !partLast.AllowReal()) || partLast.IsConst();
        }

        public bool IsNoOpenOrExp()
        {
            return IsNoOpen() || IsExp;
        }

        public bool IsClosePart()
        {
            FormulePart partLast = this;
            return partLast.IsConst() || partLast.IsCloseBasket || !partLast.AllowReal();
        }

        /// <summary>
        /// Тип части формулы
        /// </summary>
        /// <returns></returns>
        public virtual FormulePartType Type()
        {
            return FormulePartType.None;
        }

        public FormulePart GetThis()
        {
            return this;
        }


        public virtual bool IsAdditionFunction()
        {
            return false;
        }

        public bool IsPlusFunction()
        {
            if (!IsFunction)
                return false;
            else
                return AsFunction.Function.GetPsevdoName() == FuncList.Get().Plus().GetPsevdoName();
        }

        public bool IsUgleOperator()
        {
            return this is FormuleUgleOperator;
        }
    }
}
