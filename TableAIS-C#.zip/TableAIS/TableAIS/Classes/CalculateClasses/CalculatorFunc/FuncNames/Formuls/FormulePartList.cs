﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Список частей в формуле (логика интерактивного калькулятора)
    /// </summary>
    public sealed class FormulePartList : ListObjects<FormulePart>
    {


        /// <inheritdoc/>
        public FormulePartList() : base()
        {
        }

        /// <inheritdoc/>
        public FormulePartList(int capacity) : base(capacity)
        {
        }

        /// <inheritdoc/>
        public FormulePartList(IEnumerable<FormulePart> collection) : base(collection)
        {
        }

        public FormulePartList(FormulePart part):this()
        {
            Add(part);
        }

        public FormulePartList(double number) : this(new FormuleNumber(number))
        {
        }

        /// <summary>
        /// Преобразует объект в формулу
        /// </summary>
        /// <returns></returns>
        public string GetFormule()
        {
            return String.Join<FormulePart>(" ", ToArray());
        }

        /// <summary>
        /// Преобразует объект в формулу
        /// </summary>
        /// <returns></returns>
        public string GetFormuleArr()
        {
            return String.Join<FormulePart>(";", ToArray());
        }

        /// <summary>
        /// Преобразует объект в формулу
        /// </summary>
        /// <returns></returns>
        public sealed override string ToString()
        {
            return GetFormule();
        }

        /// <summary>
        /// Преобразует объект в формулу
        /// </summary>
        /// <param name="parts"></param>
        public static implicit operator string(FormulePartList parts)
        {
            return parts.ToString();
        }

        /// <summary>
        /// Добавляет открывающую скобку и возвращает её индекс
        /// </summary>
        /// <param name="abs"></param>
        /// <returns></returns>
        public int AddOpenBasket(bool abs)
        {
            return Add(FormuleBaskets.CreateOpen(abs));
        }

        /// <summary>
        /// Добавляет закрывающую скобку и возвращает её индекс
        /// </summary>
        /// <param name="abs"></param>
        /// <returns></returns>
        public int AddCloseBasket(bool abs)
        {
            return Add(FormuleBaskets.CreateClose(abs));
        }

        /// <summary>
        /// Добавляет точку с запятой и возвращает её индекс
        /// </summary>
        /// <returns></returns>
        public int AddArraySplit()
        {
            return Add(new FormuleArraySplit());
        }

        /// <summary>
        /// Добавляет E и возвращает её индекс
        /// </summary>
        /// <returns></returns>
        public int AddExp()
        {
            return Add(new FormuleExp());
        }

        /// <summary>
        /// Добавляет число и возвращает его индекс
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public int AddNumber(double number)
        {
            return Add(new FormuleNumber(number));
        }

        /// <summary>
        /// Добавляет функцию и возвращает её индекс
        /// </summary>
        /// <returns></returns>
        public int AddFunction(int psevdoCode)
        {
            return Add(new FormuleFunction(psevdoCode));
        }
        /// <summary>
        /// Добавляет функцию и возвращает её индекс
        /// </summary>
        /// <returns></returns>
        public int AddFunction(FuncNames func)
        {
            return Add(new FormuleFunction(func));
        }


        /// <summary>
        /// Добавляет статическую переменную и возвращает её индекс
        /// </summary>
        /// <returns></returns>
        public int AddStaticVariable(string name)
        {
            return Add(new FormuleStaticVariables(name));
        }

        /// <summary>
        /// Добавляет статическую переменную и возвращает её индекс
        /// </summary>
        /// <returns></returns>
        public int AddMemoryVariable(string name)
        {
            return Add(new FormuleVariableMemory(name));
        }

        /// <summary>
        /// Добавляет функцию и возвращает её индекс
        /// </summary>
        /// <returns></returns>
        public int AddFunction(int psevdoCode, int nameID)
        {
            return Add(new FormuleFunction(psevdoCode, nameID));
        }


        /// <summary>
        /// Добавляет число и возвращает ссылку на добавленный объект
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public FormuleNumber AddNumberWithReturn(double number)
        {
            return AddWithReturn(new FormuleNumber(number)).AsNumber;
        }


        /// <summary>
        /// Добавляет статическую переменную и возвращает ссылку на добавленный объект
        /// </summary>
        /// <returns></returns>
        public FormuleStaticVariables AddStaticVariablesWithReturn(string name)
        {
            return AddWithReturn(new FormuleStaticVariables(name)).AsStaticVariable;
        }


        /// <summary>
        /// Добавляет статическую переменную и возвращает ссылку на добавленный объект
        /// </summary>
        /// <returns></returns>
        public FormuleVariableMemory AddMemoryVariablesWithReturn(string name)
        {
            return AddWithReturn(new FormuleVariableMemory(name)).AsMemoryVariable;
        }

        /// <summary>
        /// Добавляет функцию и возвращает ссылку на добавленный объект
        /// </summary>
        /// <returns></returns>
        public FormuleFunction AddFunctionWithReturn(int psevdoCode)
        {
            return AddWithReturn(new FormuleFunction(psevdoCode)).AsFunction;
        }
        /// <returns></returns>
        public FormuleFunction AddFunctionWithReturn(FuncNames psevdoCode)
        {
            return AddWithReturn(new FormuleFunction(psevdoCode)).AsFunction;
        }

        /// <summary>
        /// Добавляет функцию и возвращает ссылку на добавленный объект
        /// </summary>
        /// <returns></returns>
        public FormuleFunction AddFunctionWithReturn(int psevdoCode, int nameID)
        {
            return AddWithReturn(new FormuleFunction(psevdoCode, nameID)).AsFunction;
        }

        /// <summary>
        /// Добавляет точку и возвращает ссылку на добавленный объект
        /// </summary>
        /// <returns></returns>
        public FormuleArraySplit AddArraySplitWithReturn()
        {
            return AddWithReturn(new FormuleArraySplit()).AsArraySplit;
        }

        /// <summary>
        /// Добавляет точку и возвращает ссылку на добавленный объект
        /// </summary>
        /// <returns></returns>
        public FormuleExp AddExpWithReturn()
        {
            return AddWithReturn(new FormuleExp()).AsExp;
        }

        /// <summary>
        /// Добавляет открывающую скобку и возвращает ссылку на добавленный объект
        /// </summary>
        /// <param name="abs"></param>
        /// <returns></returns>
        public FormuleOpenBasket AddOpenBasketWithReturn(bool abs)
        {
            return AddWithReturn(FormuleBaskets.CreateOpen(abs)).AsOpenBasket;
        }

        /// <summary>
        /// Добавляет закрывающую скобку и возвращает ссылку на добавленный объект
        /// </summary>
        /// <param name="abs"></param>
        /// <returns></returns>
        public FormuleCloseBasket AddCloseBasketWithReturn(bool abs)
        {
            return AddWithReturn(FormuleBaskets.CreateClose(abs)).AsCloseBasket;
        }


        /// <summary>
        /// Задаёт объект по его индексу и возвращает ссылку на текущий объект
        /// </summary>
        /// <param name="index"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public new FormulePartList Set(int index, FormulePart value)
        {
            this[index] = value;
            return this;
        }

        /// <summary>
        /// Возвращает ссылку на текущий объект
        /// </summary>
        /// <returns></returns>
        public FormulePartList GetThis()
        {
            return this;
        }

        /// <summary>
        /// Добавляет число и возвращает ссылку на текущий объект
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public FormulePartList AddNumberWithThis(double number)
        {
            FormulePartList parts = GetThis();
            parts.AddNumber(number);
            return parts;
        }

        /// <summary>
        /// Добавляет функцию и возвращает ссылку на текущий объект
        /// </summary>
        /// <returns></returns>
        public FormulePartList AddFunctionWithThis(int psevdoCode)
        {
            FormulePartList parts = GetThis();
            parts.AddFunction(psevdoCode);
            return parts;
        }

        /// <summary>
        /// Добавляет функцию и возвращает ссылку на текущий объект
        /// </summary>
        /// <returns></returns>
        public FormulePartList AddFunctionWithThis(int psevdoCode, int nameID)
        {
            FormulePartList parts = GetThis();
            parts.AddFunction(psevdoCode, nameID);
            return parts;
        }


        /// <summary>
        /// Добавляет E и возвращает ссылку на текущий объект
        /// </summary>
        /// <returns></returns>
        public FormulePartList AddExpWithThis()
        {
            FormulePartList parts = GetThis();
            parts.AddExp();
            return parts;
        }

        /// <summary>
        /// Добавляет точку с запятой и возвращает ссылку на текущий объект
        /// </summary>
        /// <returns></returns>
        public FormulePartList AddArraySplitWithThis()
        {
            FormulePartList parts = GetThis();
            parts.AddArraySplit();
            return parts;
        }

        /// <summary>
        /// Добавляет статическую переменную и возвращает ссылку на текущий объект
        /// </summary>
        /// <returns></returns>
        public FormulePartList AddStaticVariableWithThis(string name)
        {
            FormulePartList parts = GetThis();
            parts.AddStaticVariable(name);
            return parts;
        }

        public int AddUgleOperator(int dole)
        {
            return Add(new FormuleUgleOperator(dole));
        }

        public FormuleUgleOperator AddUgleOperatorWithResult(int dole)
        {
            return Get(AddUgleOperator(dole)) as FormuleUgleOperator;
        }

        public FormulePartList AddUgleOperatorWithThis(int dole)
        {
            FormulePartList parts = GetThis();
            parts.AddUgleOperator(dole);
            return parts;
        }


        /// <summary>
        /// Добавляет статическую переменную и возвращает ссылку на текущий объект
        /// </summary>
        /// <returns></returns>
        public FormulePartList AddMemoryVariableWithThis(string name)
        {
            FormulePartList parts = GetThis();
            parts.AddMemoryVariable(name);
            return parts;
        }

        /// <summary>
        /// Добавляет открывающую скобку и возвращает ссылку на текущий объект
        /// </summary>
        /// <returns></returns>
        public FormulePartList AddOpenBasketWithThis(bool abs)
        {
            FormulePartList parts = GetThis();
            parts.AddOpenBasket(abs);
            return parts;
        }

        /// <summary>
        /// Добавляет закрывающую скобку и возвращает ссылку на текущий объект
        /// </summary>
        /// <returns></returns>
        public FormulePartList AddCloseBasketWithThis(bool abs)
        {
            FormulePartList parts = GetThis();
            parts.AddCloseBasket(abs);
            return parts;
        }

        /// <summary>
        /// Добавляет новый объект в список и возвращает ссылку на текущий объект
        /// </summary>
        /// <returns></returns>
        public FormulePartList AddWithThis(FormulePart part)
        {
            FormulePartList formuleParts = GetThis();
            formuleParts.Add(part);
            return formuleParts;
        }

        /// <summary>
        /// Добавляет заданный массив объектов в список и возвращает ссылку на текущий объект
        /// </summary>
        /// <param name="parts"></param>
        /// <returns></returns>
        public new FormulePartList AddRange(IEnumerable<FormulePart> parts)
        {
            FormulePartList partParts = GetThis();

            foreach (FormulePart part in parts)
            {
                partParts = partParts.AddWithThis(part);
            }

            return partParts;
        }

        /// <summary>
        /// Добавляет формулу
        /// </summary>
        /// <param name="formule"></param>
        /// <param name="variable"></param>
        /// <returns></returns>
        public FormulePartList AddFormule(string formule, char variable = '\0')
        {
            // formule = MyCalculate.AddBaskets(formule);
            AddRange(MyCalculate.ReplaceToFullFuncsCodeInteractive(formule, variable));
            return this;
        }

        /// <summary>
        /// Пролучить копию объекта по его индексу
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public FormulePart GetCopy(int index)
        {
            return Get(index).Copy();
        }

        public FormulePartList Copy()
        {
            FormulePartList parts = new FormulePartList();

            foreach (FormulePart part in this)
            {
                parts.Add(part);
            }

            return parts;
        }


        public FormulePartList InsertText(int index, string formule)
        {
            FormulePartList list = MyCalculate.ReplaceToFullFuncsCodeInteractive(formule);
            if (index >= Count)
                AddRange(list);
            else
                InsertRange(index, list);
            return this;
        }

        public FormulePartList SetFormule(int index, string formule)
        {
            try
            {
                RemoveAt(index);
            }
            catch { }
            return InsertText(index, formule);
        }

        public FormulePartList SetPart(int index, FormulePart part)
        {
            try
            {
                RemoveAt(index);
            }
            catch { }
            return InsertPart(index, part);
        }

        public FormulePartList InsertPart(int index, FormulePart part)
        {
            if (index >= Count)
                Add(part);
            else
                Insert(index, part);
            return this;
        }

        public bool ExpIsConst(int index)
        {
            bool result = false;
            if (index == 0 || index == LastIndex)
            {

                result = true;
            }
            else
            {
                FormulePart lastPart = Get(index - 1);
                FormulePart nextPart = Get(index + 1);
                if (nextPart.IsCloseBasket || lastPart.IsOpenBasket)
                {
                    return true;
                }
                if ((lastPart.IsConstExpOpen()) && nextPart.IsConstExpClose())
                {
                    return false;
                }
                if (lastPart.IsConstExpOpen())
                {
                    return true;
                }
                if (nextPart.IsConstExpClose())
                {
                    return true;
                }

            }


            return result;
        }

    }
}
