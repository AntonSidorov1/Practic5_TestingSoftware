﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Спец-символы в формуле
    /// </summary>
    public abstract class FormuleSpecSymwol : FormulePart
    {
        /// <inheritdoc/>
        public FormuleSpecSymwol() : base()
        {
        }
/// <inheritdoc/>

        public override bool AllowChange => false;
    }
}
