﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class FormuleStack : ListStack<FormuleOperation>
    {
        public FormuleStack()
        {
            FirstOperate = true;
            LastOperate = false;
            LastFunction = false;
            OperandsCount = 1;
            ReservOperandsCount = 0;
        }

        public FormuleStack(int capacity) : base(capacity)
        {
            FirstOperate = true;
            LastOperate = false;
            LastFunction = false;
            OperandsCount = 1;
            ReservOperandsCount = 0;
        }

        public FormuleStack(IEnumerable<FormuleOperation> collection) : base(collection)
        {
            FirstOperate = true;
            LastOperate = false;
            LastFunction = false;
            OperandsCount = 1;
            ReservOperandsCount = 0;
        }


        public bool FirstOperate { get => firstOperate; set => firstOperate = value; }
        public bool LastOperate { get => lastOperate; set => lastOperate = value; }


        bool firstOperate;

        bool lastOperate;

        bool lastFunction;


        /// <summary>
        /// Количество передаваемых операндов
        /// </summary>
        public int OperandsCount { get => operandsCount; set => operandsCount = value; }

        int operandsCount;

        /// <summary>
        /// Количество передаваемых операндов
        /// </summary>
        public int ReservOperandsCount { get => reservOperandsCount; set => reservOperandsCount = value; }
        public bool LastFunction { get => lastFunction; set => lastFunction = value; }

        int reservOperandsCount;

        public int GetAndClearReservOperandsCount()
        {
            int count = ReservOperandsCount;
            ReservOperandsCount = 0;
            return count;
        }

        public void ReservOpen()
        {
            int count = GetAndClearReservOperandsCount();
            if (count > 0)
                OperandsCount += count;
        }

    }
}
