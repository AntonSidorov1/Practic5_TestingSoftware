﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class FormuleStackList : ListStack<FormuleStack>
    {
        public FormuleStackList()
        {
        }

        public FormuleStackList(int capacity) : base(capacity)
        {
        }

        public FormuleStackList(IEnumerable<FormuleStack> collection) : base(collection)
        {
        }

        public FormuleStack Push()
        {
            Push(new FormuleStack());
            return GetLast();
        }

        public int Put()
        {
            return Put(new FormuleStack());
        }
    }
}
