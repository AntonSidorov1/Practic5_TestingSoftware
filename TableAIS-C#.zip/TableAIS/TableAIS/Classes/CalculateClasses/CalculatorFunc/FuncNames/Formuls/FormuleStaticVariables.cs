﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Статические переменные в формуле
    /// </summary>
    public class FormuleStaticVariables : FormuleSpecSymwol
    {
        /// <summary>
        /// Создаёт объект класса
        /// </summary>
        /// <param name="name"></param>
        public FormuleStaticVariables(string name) : base()
        {
            this.name = name;
        }

        string name;

        /// <summary>
        /// Имя переменной
        /// </summary>
        public string GetName()
        {
            return name;
        }

        /// <summary>
        /// Имя переменной
        /// </summary>
        public void SetName(string value)
        {
            name = value;
        }

        /// <summary>
        /// Имя переменной
        /// </summary>
        public string Name
        {
            get => name;
            set => name = value;
        }


        /// <inheritdoc/>

        public override string GetText()
        {
            return Name;
        }
/// <inheritdoc/>

        public override FormulePart Copy()
        {
           return new FormuleStaticVariables(Name);
        }

        /// <inheritdoc/>

        public override FormulePartType Type()
        {
            return FormulePartType.StaticVariable;
        }
    }
}
