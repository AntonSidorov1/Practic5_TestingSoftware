﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class FormuleUgleOperator : FormuleOperation
    {
        int dole = 0;

        public int Dole
        {
            get => dole;
            set => dole = value;
        }
        public FormuleUgleOperator(int dole = 0) : base()
        {
            Dole = dole;
        }

        public override int BinarnPriority => 0;

        public override int BinarnFewPriority => 6;

        public override int UnarnPriority => BinarnPriority;

        public override int UnarnFewPriority => BinarnFewPriority;

        public override int FuncBinarnPriority => BinarnPriority;

        public override int FuncBinarnFewPriority => BinarnFewPriority;

        public override int FuncUnarnPriority => UnarnPriority;

        public override int FuncUnarnFewPriority => UnarnFewPriority;

        public override bool AllowWithOperator => true;

        public override bool IsOperator => true;

        public override bool AllowReal => false;



        public override FormulePart Copy()
        {
            FormuleUgleOperator result = new FormuleUgleOperator(Dole);
            result.SetByFew(this);
            return result;
        }

        public override string GetText()
        {
            if (Dole <= 0)
                return "°";
            else if(Dole == 1)
            {
                return "'";
            }
            else if(Dole == 2)
            {
                return "''";
            }

            return "";
        }

        public override double RunCalc(double[] values)
        {
            List<double> numbers = new List<double>(values);
            double number = values[0] * 2 * Math.PI / 360;
            int dole = Dole;
            while(dole > 0)
            {
               numbers.Insert(0, 0);
                dole--;
            }
            number = FuncList.Get().DegToRad.FuncDoingInvoke(numbers.ToArray());

            return number;
        }

        public override bool IsAdditionFunction()
        {
            return true;
        }
    }
}
