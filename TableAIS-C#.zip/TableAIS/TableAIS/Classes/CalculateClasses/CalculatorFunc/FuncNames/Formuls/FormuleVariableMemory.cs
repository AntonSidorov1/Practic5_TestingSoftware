﻿namespace TableAIS
{
    /// <summary>
    /// Переменная, ссылающаяся на память
    /// </summary>
    public class FormuleVariableMemory : FormuleStaticVariables
    {

        /// <inheritdoc/>
        public FormuleVariableMemory(string name) : base(name)
        {
        }

        public CalculatorMemoryItem MemoryItem()
        {
            return CalculatorString.History.FindByNumber(Name);
        }

        public string GetValue()
        {
            return MemoryItem().Formule;
        }

        public override FormulePart Copy()
        {
            return new FormuleVariableMemory(Name);
        }
    }
}
