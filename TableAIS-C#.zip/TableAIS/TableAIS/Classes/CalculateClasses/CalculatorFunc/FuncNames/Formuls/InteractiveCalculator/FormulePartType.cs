﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Тип части в формуле
    /// </summary>
    public enum FormulePartType
    {
        None,
        Number,
        StaticVariable,
        Const,
        Operation,
        ArraySplit,
        FuncOneException,
        FuncManyArgsException,
        Basket
    }
}
