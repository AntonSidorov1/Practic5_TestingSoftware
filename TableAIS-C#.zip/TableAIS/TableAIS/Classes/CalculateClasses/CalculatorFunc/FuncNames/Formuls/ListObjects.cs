﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Список объектов
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ListObjects<T> : List<T>
    {
        /// <inheritdoc/>
        public ListObjects() : base()
        {
        }

        /// <inheritdoc/>
        public ListObjects(int capacity) : base(capacity)
        {
        }

        /// <inheritdoc/>
        public ListObjects(IEnumerable<T> collection) : base(collection)
        {
        }


        /// <summary>
        /// Возвращает объект по его индексу
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public T Get(int index)
        {
            return this[index];
        }

        public T GetByLast(int index)
        {
            return Get(LastIndex - index);
        }

        public void RemoveByLast(int count)
        {
            for (int i = 0; i < count; i++)
            {
                RemoveLast();
            }
        }

        public void InsertLast(T obj)
        {
            Insert(LastIndex, obj);
        }

        /// <summary>
        /// Задаёт объект по его индексу и возвращает ссылку на текущий объект
        /// </summary>
        /// <param name="index"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public List<T> Set(int index, T value)
        {
            this[index] = value;
            return this;
        }


        /// <summary>
        /// Индекс последнего элемента в списке
        /// </summary>
        public int LastIndex => Count - 1;

        /// <summary>
        /// Последний объект в списке
        /// </summary>
        /// <returns></returns>
        public T GetLast() => Get(LastIndex);


        /// <summary>
        /// Добавляет объект в список и возвращает его индекс
        /// </summary>
        /// <param name="part"></param>
        /// <returns></returns>
        public new int Add(T part)
        {
            base.Add(part);
            return LastIndex;
        }


        /// <summary>
        /// Добавляет объект в список и возвращает ссылку на него
        /// </summary>
        /// <param name="part"></param>
        /// <returns></returns>
        public T AddWithReturn(T part)
        {
            return Get(Add(part));
        }

        /// <summary>
        /// Удаляет последний объект из списка
        /// </summary>
        public void RemoveLast()
        {
            RemoveAt(LastIndex);
        }

        /// <summary>
        /// Возвращает последний элемент в списке и удаляет его
        /// </summary>
        /// <returns></returns>
        public T GetLastAndRemove()
        {
            T item = GetLast();
            RemoveLast();
            return item;
        }

        public bool IsEmpty()
        {
            return Count == 0;
        }

        public bool IsNoEmpty()
        {
            return !IsEmpty();
        }


        public void Move(int oldIndex, int newIndex)
        {
            T oldObj = Get(oldIndex);
            T newObj = Get(newIndex);
            Set(newIndex, oldObj);
            Set(oldIndex, newObj);
        }

        public void MoveUp(int oldIndex)
        {
            Move(oldIndex, oldIndex - 1);
        }

        public void MoveDown(int oldIndex)
        {
            Move(oldIndex, oldIndex + 1);
        }


    }
}
