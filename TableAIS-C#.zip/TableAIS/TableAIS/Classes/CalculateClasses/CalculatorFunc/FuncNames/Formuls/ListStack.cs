﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class ListStack<T> : ListObjects<T>
    {
        public ListStack()
        {
        }

        public ListStack(int capacity) : base(capacity)
        {
        }

        public ListStack(IEnumerable<T> collection) : base(collection)
        {
        }


        public int Put(T t)
        {
            return Add(t);
        }

        public int Push(T t)
        {
            return Add(t);
        }



        public T Peek()
        {
            return GetLast();
        }

        public T Pop()
        {
            return GetLastAndRemove();
        }
    }
}
