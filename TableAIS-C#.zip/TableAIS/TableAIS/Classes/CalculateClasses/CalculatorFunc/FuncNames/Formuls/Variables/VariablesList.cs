﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Список переменных
    /// </summary>
    public class VariablesList : ListObjects<string>
    {
        public VariablesList()
        {
            DogCount = 2;
        }

        public VariablesList(int capacity) : base(capacity)
        {
            DogCount = 2;
        }

        public VariablesList(IEnumerable<string> collection) : base(collection)
        {
            DogCount = 2;
        }

        int dogCount;

        public int DogCount { get => dogCount; set => dogCount = value; }

        public string GetCode(string name)
        {
            string dogs = "";
            int count = Math.Max(DogCount, 2);
            for (int i = 0; i < count; i++)
                dogs += '@';
            return "{~" + dogs + FindIndex(n => n.ToLower().Trim() == name.ToLower().Trim()) + "}";
        }

        public string ReplaceToCode(string formule)
        {
            for(int i = 0; i< Count; i++)
            {
                string name = Get(i).ToLower().Trim();
                formule = formule.ToLower().Trim().Replace(name, GetCode(name));
            }

            return formule;
        }

        public string ReplaceByCode(string formule)
        {
            for (int i = 0; i < Count; i++)
            {
                string name = Get(i);
                formule = formule.Replace(GetCode(name), name);
            }

            return formule;
        }
    }
}
