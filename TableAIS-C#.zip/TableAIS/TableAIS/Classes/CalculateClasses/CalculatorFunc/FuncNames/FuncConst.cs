﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Функция-константа - функция, возвращающая число
    /// </summary>
    public class FuncConst : FuncNames
    {
        double number;

        /// <summary>
        /// Возвращаемое число
        /// </summary>
        public double Number
        {
            get => number; set => number = value;
        }

        public FuncConst() : base()
        {
            Number = 0;
        }

        public override void Create()
        {
            base.Create();
            FuncDoing = (value) => Number;
        }

        public override string GetFuncType()
        {
            return "Функция-константа";
        }
/// <inheritdoc/>


        public override string GetSpecification()
        {
            string text = "";
            text += "Функция: " + GetName() + "\n";
            text += "Другие её обозначения: " + string.Join(", ", GetAllNames()) + "\n";
            text += "Код (псевдокод): " + GetPsevdoName() + "\n";
            text += "Исполняемый псевдокод (Псевдоним): " + GetPsevdoNameText() + "\n";
            text += "Тип: " + GetFuncType() + "\n\n";
            text += "================================= \n\n";
            text += "Число, равное " + Number + "\n";

            if (Notes != null && Notes != "" && !Notes.Equals(""))
            {
                text += "================================= \n\n";
                text += "Примечания: \n" + Notes + "\n\n";

            }

            text += "================================= \n\n";
            text += "Назначение: \n";
            text += Appointment + "\n \n";
            text += "================================= \n\n";
            text += "Описание: \n";
            text += Description + "\n \n";
            text += "================================= \n\n";

            return text;
        }

    }
}
