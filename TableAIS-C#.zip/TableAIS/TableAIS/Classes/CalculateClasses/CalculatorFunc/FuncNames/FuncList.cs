﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Activation;

namespace TableAIS
{
    public class FuncList : FuncNamesList
    {


        public FuncList() : base()
        {
            if (Abs == null)
                Abs = "";
        }

        public string listToText(List<FuncNames> list)
        {
            List<String> names = new List<String>();
            foreach (FuncNames name in list)
            {
                names.Add(name.GetName());
            }
            return String.Join(", ", names);
        }

        List<FuncNames> funcs;
        /// <inheritdoc/>
        /// 
        public override void Create()
        {
            funcs = new List<FuncNames>();

            base.Create();

            List<string> list = new List<string>();

            FuncNames rFromUI = Add();
            rFromUI.SetName("RFromUI");
            rFromUI.Appointment = "Вольт-амперная характеристика резистора (Закон Ома): Нахождение сопротивление";
            rFromUI.Description = "Нахождение сопротивление резистора через напряжение и сылу тока (R=U/I)";
            rFromUI.FuncDoing = (value) =>
            {
                return value[0] / value[1];
            };
            

            FuncNames uFromIR = Add();
            uFromIR.SetName("UFromIR");
            uFromIR.Appointment = "Вольт-амперная характеристика резистора (Закон Ома): Нахождение напряжения";
            uFromIR.Description = "Нахождение силы тока резистора через напряжение и сопротивление (U=I*R)";
            uFromIR.FuncDoing = (value) =>
            {
                return value[0] * value[1];
            };

            FuncNames iFromUR = Add();
            iFromUR.SetName("IFromUR");
            iFromUR.Appointment = "Вольт-амперная характеристика резистора (Закон Ома): Нахождение силы тока";
            iFromUR.Description = "Нахождение силы тока резистора через напряжение и сопротивление (I=U/R)";
            iFromUR.FuncDoing = (value) =>
            {
                return value[0] / value[1];
            };

            FuncNames isMoreOrZero = Add("IsMoreOrZero");
            isMoreOrZero.AddFewName("IsMoreOrEqualsZero");
            isMoreOrZero.AddFewName("IsMoreEqualsZero");
            isMoreOrZero.FuncDoing = (value) =>
            {
                try
                {
                    if (value.Length < 1)
                    {
                        throw new ManyFuncsOneExceptions(isMoreOrZero, value);
                    }
                    return value[0] >= 0 ? 1 : 0;
                }
                catch (ManyFuncsOneExceptions e)
                {
                    throw e;
                }
                catch
                {
                    return 0;
                }

            };

            FuncNames isLessOrZero = Add("IsLessOrZero");
            isLessOrZero.AddFewName("IsLessOrEqualsZero");
            isLessOrZero.AddFewName("IsLessEqualsZero");
            isLessOrZero.FuncDoing = (value) =>
            {
                try
                {
                    if (value.Length < 1)
                    {
                        throw new ManyFuncsOneExceptions(isLessOrZero, value);
                    }
                    return value[0] <= 0 ? 1 : 0;
                }
                catch (ManyFuncsOneExceptions e)
                {
                    throw e;
                }
                catch
                {
                    return 0;
                }

            };

            FuncNames isMoreZero = Add("IsMoreZero");
            isMoreZero.FuncDoing = (value) =>
            {
                try
                {
                    if (value.Length < 1)
                    {
                        throw new ManyFuncsOneExceptions(isMoreZero, value);
                    }
                    return value[0] > 0 ? 1 : 0;
                }
                catch (ManyFuncsOneExceptions e)
                {
                    throw e;
                }
                catch
                {
                    return 0;
                }

            };

            FuncNames isLessZero = Add("IsLessZero");
            isLessZero.FuncDoing = (value) =>
            {
                try
                {
                    if (value.Length < 1)
                    {
                        throw new ManyFuncsOneExceptions(isLessZero, value);
                    }
                    return value[0] < 0 ? 1 : 0;
                }
                catch (ManyFuncsOneExceptions e)
                {
                    throw e;
                }
                catch
                {
                    return 0;
                }

            };

            FuncNames isNoZero = Add("IsNoZero");
            isNoZero.FuncDoing = (value) =>
            {
                try
                {
                    if (value.Length < 1)
                    {
                        throw new ManyFuncsOneExceptions(isNoZero, value);
                    }
                    return value[0] != 0 ? 1 : 0;
                }
                catch (ManyFuncsOneExceptions e)
                {
                    throw e;
                }
                catch
                {
                    return 0;
                }

            };

            FuncNames isZero = Add("IsZero");
            isZero.FuncDoing = (value) =>
            {
                try
                {
                    if (value.Length < 1)
                    {
                        throw new ManyFuncsOneExceptions(isZero, value);
                    }
                    return value[0] == 0 ? 1 : 0;
                }
                catch (ManyFuncsOneExceptions e)
                {
                    throw e;
                }
                catch
                {
                    return 0;
                }

            };

            FuncNames isInt = Add("IsInteger");
            isInt.AddFewName("IsInt");
            isInt.FuncDoing = (value) =>
            {
                try
                {
                    if (value.Length < 1)
                    {
                        throw new ManyFuncsOneExceptions(isInt, value);
                    }
                    int.Parse(value[0].ToString());
                    return 1;
                }
                catch (ManyFuncsOneExceptions e)
                {
                    throw e;
                }
                catch
                {
                    return 0;
                }

            };

            FuncNames countBetween = Add();
            FuncNames sumBetween = Add();
            FuncNames mullBetween = Add();


            FuncNames between = Add("Between");
            between.AddFewName("Beetwen");
            between.AddFewName("Beetween");
            between.AddFewName("Betwen");
            between.FuncDoing = (value) =>
            {
                if (value.Length < 3)
                {
                    throw new ManyFuncsOneExceptions(between, value);
                }
                double n = value[0];
                double start = value[1];
                double end = value[2];
                double start1 = Math.Min(end, start);
                double end1 = Math.Max(start, end);
                return n >= start1 && n <= end1 ? 1 : 0;
            };

            mullBetween.SetSpecification("Произведение чисел в диапазоне",
                "Перемножает числа, которые соответстуют условию " + between.GetName() + " с 1-ыми 2-мя числами, начиная с третьего, ");
            mullBetween.FuncDoing = (value) =>
            {
                double first = value[0];
                double second = value[1];
                double res = 1;
                for (int i = 2; i < value.Length; i++)
                {
                    double num = value[i];
                    if (between.FuncDoingInvoke(num, first, second) == 1)
                        res *= num;
                }
                return res;
            };

            sumBetween.SetSpecification("Сумма чисел в диапазоне",
                "Складывает числа, которые соответстуют условию " + between.GetName() + " с 1-ыми 2-мя числами, начиная с третьего, ");
            sumBetween.FuncDoing = (value) =>
            {
                double first = value[0];
                double second = value[1];
                double res = 0;
                for (int i = 2; i < value.Length; i++)
                {
                    double num = value[i];
                    if (between.FuncDoingInvoke(num, first, second) == 1)
                        res += num;
                }
                return res;
            };

            countBetween.SetSpecification("Счёт чисел в диапазоне",
                "Считаает числа, которые соответстуют условию "+between.GetName()+" с 1-ыми 2-мя числами, начиная с третьего, ");
            countBetween.FuncDoing = (value) =>
            {
                double first = value[0];
                double second = value[1];
                double res = 0;
                for(int i= 2; i<value.Length; i++)
                {
                    double num = value[i];
                    if (between.FuncDoingInvoke(num, first, second) == 1)
                        res++;
                }
                return res;
            };

            FuncNames secondArgErr = Add("SecondArgErr");
            secondArgErr.Appointment = "Второй аргумент в случае ошибочного первого";
            secondArgErr.Description = "Возвращает 2-ой аргумент, если 1-ый аргумент ошибочный, или 1-ый аргумент в противном случае\n" +
                "Применимо для обработки ошибок, выдаваемых функциями";
            secondArgErr.FuncDoing = (value) =>
            {
                if (value.Length < 1)
                    return 0;
                double retZ = 0;
                if (value.Length > 1)
                    retZ = value[1];
                double num = value[0];
                return double.IsNaN(num) ? retZ : num;
            };


            FuncNames zeroErr = Add("ZeroErr");
            zeroErr.Appointment = "Ноль в случае ошибочного первого";
            zeroErr.Description = "Возвращает ноль, если 1-ый аргумент ошибочный, или 1-ый аргумент в противном случае\n" +
                "Применимо для обработки ошибок, выдаваемых функциями";
            zeroErr.FuncDoing = (value) =>
            {
                if (value.Length < 1)
                    return 0;
                double num = value[0];
                return double.IsNaN(num) ? 0 : num;
            };

            FuncNames zero = Add("Zero");
            zero.Appointment = "Ноль";
            zero.Description = "Возвращает ноль, вне зависимости от передаваемых аругментов";
            zero.FuncDoing = (value) => 0;

            FuncOperator addMullNext = AddOperator();
            addMullNext.SetName("Addition");
            list = addMullNext.GetFewNames();
            list.Add("Add");
            list.Add("Adition");
            list.Add("Slozhenie"); ;
            list.Add("Slozh"); ;
            list.Add("Sloz"); ;
            list.Add("Slog");
            list.Add("Plus");
            list.Add("Suma");
            list.Add("Summa");
            list.Add("Summ");
            list.Add("Sum");
            addMullNext.ReplaceWithAddSymwolLast("MullNext");
            addMullNext.WorkOperator = false;
            addMullNext.BinarnFewPriority = 1;
            addMullNext.BinarnPriority = 0;
            addMullNext.UnarnFewPriority = 7;
            addMullNext.UnarnPriority = 0;
            addMullNext.ProcentInput = true;
            addMullNext.Appointment = "Прибавление произведения аргументов к первому аргументу";
            addMullNext.Description = "Прибавляет к 1-ому аргументу произведение этого аргумента на 2-ой аргумент";
            addMullNext.Doing = (value) =>
            {
                return value[0] + value[0] * value[1];
            };


            FuncOperator subMullNext = AddOperator();
            subMullNext.SetName("Substraction");
            list = subMullNext.GetFewNames();
            list.Add("Deduction");
            list.Add("Vichitaie");
            list.Add("Vichetaie");
            list.Add("Vichit");
            list.Add("Vichet");
            list.Add("Sub");
            list.Add("Mines");
            subMullNext.ReplaceWithAddSymwolLast("MullNext");
            subMullNext.WorkOperator = false;
            subMullNext.WorkOperator = false;
            subMullNext.BinarnFewPriority = 1;
            subMullNext.BinarnPriority = 0;
            subMullNext.UnarnFewPriority = 7;
            subMullNext.UnarnPriority = 0;
            subMullNext.ProcentInput = true;
            subMullNext.Appointment = "Вычитание произведения аргументов из первого аргумента";
            subMullNext.Description = "Вычитает из 1-ого аргумента произведение этого аргумета на 2-ой аргумент";
            subMullNext.Doing = (value) =>
            {
                return value[0] - value[0] * value[1];
            };


            FuncNames intToLong = Add("IntToUnsigned");
            intToLong.Appointment = "Перевод числа в беззнаковое представление";
            intToLong.Description = "Переводит число из представления в виде числа со знаком в беззнаковое представление, сохраняя двоичное представление";
            intToLong.FuncDoing = (value) =>
            {
                long res = (uint)((int)value[0]);
                return res;
            };

            FuncNames LongToInt = Add("UnsignedToLong");
            LongToInt.Appointment = "Перевод числа из беззнакового представления";
            LongToInt.Description = "Переводит число из беззнакового представления в представление в виде числа со знаком, сохраняя двоичное представление";
            LongToInt.FuncDoing = (value) =>
            {
                return (int)((uint)((long)value[0]));
            };

            FuncNames divRet = AddOperator();
            divRet.SetName("DivisionRet");
            list = divRet.GetFewNames();
            list.Add("DivisionRet");
            list.Add("DegreeRet");
            list.Add("SegmentationRet");
            list.Add("SegmentRet");
            list.Add("DivRet");
            list.Add("DelenieRet");
            list.Add("DelenRet");
            list.Add("RetDivision");
            list.Add("RetDegree");
            list.Add("RetSegmentation");
            list.Add("RetSegment");
            list.Add("RetDiv");
            list.Add("RetDelenie");
            list.Add("RetDelen");
            divRet.Appointment = "Число обратное частному (частное обратных чисел)";
            divRet.Description = "Деление обратного числа 1-ому аргументу на произведение обратных чисел всем последующим аргументам \n" +
                "Если аргумент 1, то он число, обратное этому аргументу\n" +
                "(1/a1)/(1/a2)/(1/a3)/.../(1/an) \n" +
                "1/a = a^(-1) \n" +
                "(1/a)/(1/b) = 1/(a/b) = b/a; \n " +
                "(1/a)/(1/b)/(1/c) = (1/(a/b))/(1/c) = 1/(a/b/c) = (1/a)/(1/(b*c)) = (b/a)/(1/c) = (b*c)/a; \n" +
                "(1/a1)/(1/a2)/.../(1/an) = 1/(a1/a2/.../an)";
            divRet.FuncDoing = (value) =>
            {
                int length = value.Length;
                double number = value[0];
                double sum = number;
                for (int i = 1; i < length; i++)
                {
                    double b = value[i];
                    if (b == 0)
                    {
                        return double.NaN; ;
                    }
                    sum /= b;
                }
                number = sum;
                if (number == 0)
                    return double.NaN;

                return 1 / number;
            };

            FuncNames subRet = Add();
            subRet.SetName("SubstractionRet");
            list = subRet.GetFewNames();
            list.Add("DeductionRet");
            list.Add("VichitaieRet");
            list.Add("VichetaieRet");
            list.Add("VichitRet");
            list.Add("VichetRet");
            list.Add("SubRet");
            list.Add("MinesRet");
            subRet.Appointment = "Разность обратных чисел";
            subRet.Description = "Если аргумент 1, то возвращает обратное число этого аргумента, умноженное на -1 \n" +
                "В противном случае вычитает из обратного числа 1-ого аргумента сумму обратных чисел всех последующих аргументов \n" +
                "(1/a1)-(1/a2)-(1/a3)-...-(1/an) \n" +
                "1/a = a^(-1) \n" +
                "(1/a)-(1/b) = (b-a)/(a*b); (1/a)-(1/b)-(1/c) = ((b*c)-(a*c)-(a*b))/(a*b*c)";
            subRet.FuncDoing = (value) =>
            {
                int length = value.Length;
                double number = value[0];
                if (number == 0)
                    return double.NaN;
                double sum = 1 / number;
                if (length < 2)
                    return -sum;
                for (int i = 1; i < length; i++)
                {
                    number = value[i];
                    if (number == 0)
                        return double.NaN;
                    sum -= 1 / number;
                }
                return sum;
            };

            FuncNames retsub = Add();
            retsub.SetName("RetSubstraction");
            list = retsub.GetFewNames();
            list.Add("RetDeduction");
            list.Add("RetVichitaie");
            list.Add("RetVichetaie");
            list.Add("RetVichit");
            list.Add("RetVichet");
            list.Add("RetSub");
            list.Add("RetMines");
            retsub.Appointment = "Обратное число разности ";
            retsub.Description = "Если аргумент 1, то возвращает обратное число этого аргумента, умноженное на -1\n" +
                "В противном случае вычитает из 1-ого аргумента сумму всех последующих аргументов и число, обратное результату \n" +
                "1/(a1+a2+a3+...+an) \n" +
                "1/a = a^(-1) \n";
            retsub.FuncDoing = (value) =>
            {
                int length = value.Length;
                if (length < 2)
                {
                    double number = value[0];
                    if (number == 0)
                        return double.NaN;
                    else
                        return 1 / number;
                }

                double sum = value[0];
                for (int i = 1; i < length; i++)
                {
                    sum -= value[i];
                }
                if (sum == 0)
                    return double.NaN;
                return 1 / sum;
            };


            FuncNames mullRet = Add();
            mullRet.SetName("RetMullation");
            list = mullRet.GetFewNames();
            list.Add("RetMullation");
            list.Add("RetMull");
            list.Add("RetMulation");
            list.Add("RetMul");
            list.Add("RetUmnozhenie");
            list.Add("RetUmnozh");
            list.Add("RetUmn");
            list.Add("MullationRet");
            list.Add("MullRet");
            list.Add("MulationRet");
            list.Add("MulRet");
            list.Add("UmnozhenieRet");
            list.Add("UmnozhRet");
            list.Add("UmnRet");
            mullRet.Appointment = "Произведение обратных чисел (Обратное произведению чисел)";
            mullRet.Description = "Произведение обратных чисел всех указанных аргументов \n" +
                "(1/a1)*(1/a2)*(1/a3)+...+(1/an) \n" +
                "1/a = a^(-1) \n" +
                "(1/a)*(1/b) = 1/(a*b) = 1/(b*a) = (1/b)*(1/b); \n " +
                "(1/a)*(1/b)*(1/c) = (1/(a*b))*(1/c) = 1/(a*b*c) = (1/a)*(1/(b*c)) = (1/b)*(1/a)*(1/c) = (1/b)*(1/c)*(1/a) = (1/c)*(1/b)*(1/a); \n" +
                "(1/a1)*(1/a2)*...*(1/an) = 1/(a1*a2*...*an)";
            mullRet.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = 1;
                for (int i = 0; i < length; i++)
                {
                    sum *= value[i];
                }
                if (sum == 0)
                    return double.NaN;
                return 1 / sum;
            };


            FuncNames addRet = Add();
            addRet.SetName("additionRet");
            list = addRet.GetFewNames();
            list.Add("addRet");
            list.Add("aditionRet");
            list.Add("slozhenieRet"); ;
            list.Add("slozhRet"); ;
            list.Add("slozRet"); ;
            list.Add("slogRet");
            list.Add("plusRet");
            list.Add("sumaRet");
            list.Add("summaRet");
            list.Add("summRet");
            list.Add("sumRet");
            addRet.Appointment = "Сумма обратных чисел";
            addRet.Description = "Складывает числа, обратные заданным \n" +
                "(1/a1)+(1/a2)+...+(1/an) \n" +
                "1/a = a^(-1) \n" +
                "(1/a)+(1/b) = (a+b)/(a*b) = (a+b)/(b*a) = (b+a)/(a*b) = (b+a)/(b*a) = (1/b)+(1/a);\n" +
                " (1/a)+(1/b)+(1/c) = ((b*c)+(a*c)+(a*b))/(a*b*c) = ((1/a)+(1/b))+(1/c) = ((a+b)/(a*b))+(1/c) = (1/a)+((b+c)/(b*c)) = (1/a)+((b+c)/(b*c))";
            addRet.Doing = (value) =>
            {
                int length = value.Length;
                double sum = 0;
                for (int i = 0; i < length; i++)
                {
                    double number = value[i];
                    if (number == 0)
                        return double.NaN;
                    sum += 1 / number;
                }
                return sum;
            };

            FuncNames retAdd = Add();
            retAdd.SetName("RetAddition");
            list = retAdd.GetFewNames();
            list.Add("RetAdd");
            list.Add("RetAdition");
            list.Add("RetSlozhenie"); ;
            list.Add("RetSlozh"); ;
            list.Add("RetSloz"); ;
            list.Add("RetSlog");
            list.Add("RetPlus");
            list.Add("RetSuma");
            list.Add("RetSumma");
            list.Add("RetSumm");
            list.Add("RetSum");
            retAdd.Appointment = "Обратное число суммы чисел";
            retAdd.Description = "Складывает все аргументы и возвращает число, обратное результату \n" +
                "1/(a1+a2+a3+...+an) \n" +
                "1/a = a^(-1) \n";
            retAdd.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = 0;
                for (int i = 0; i < length; i++)
                {
                    sum += (value[i]);
                }
                if (sum == 0)
                    return double.NaN;
                return 1 / sum;
            };



            FuncNames degNorm = Add("GradusNorm");
            degNorm.GetFewNames().Add("DegNorm");
            degNorm.Appointment = "Преобразование последовательности чисел в градусы";
            degNorm.Description = "Преобразует угол в градусную меру из последовательности чисел, которыми, начиная с первого являются: \n" +
                "градусы, минуты, секунды, милисекунды и т.д.";
            degNorm.FuncDoing = (value) =>
            {
                double gradus = 0;

                for (int i = 0; i < Math.Min(3, value.Length); i++)
                {
                    gradus += value[i] / Math.Pow(60, i);
                }
                for (int i = 3; i < value.Length; i++)
                {
                    gradus += value[i] / (3600 * Math.Pow(1000, i - 2));
                }
                return gradus;
            };

            FuncNames minuteNorm = Add("MinuteNorm");
            minuteNorm.Appointment = "Преобразование последовательности чисел в минуты";
            minuteNorm.Description = "Преобразует угол в секундную меру из последовательности чисел, которыми, начиная с первого являются: \n" +
                "минуты, секунды, милисекунды, микросекунды и т.д.";
            minuteNorm.FuncDoing = (value) =>
            {
                double minute = 0;

                for (int i = 0; i < Math.Min(2, value.Length); i++)
                {
                    minute += value[i] / Math.Pow(60, i);
                }
                for (int i = 2; i < value.Length; i++)
                {
                    minute += value[i] / (60 * Math.Pow(1000, i - 1));
                }
                return minute;
            };

            FuncNames secondNorm = Add("SecondNorm");
            secondNorm.Appointment = "Преобразование последовательности чисел в секунды";
            secondNorm.Description = "Преобразует угол в секундную меру из последовательности чисел, которыми, начиная с первого являются: \n" +
                "секунды, милисекунды, микросекунды и т.д.";
            secondNorm.FuncDoing = (value) =>
            {
                double second = 0;
                for (int i = 0; i < value.Length; i++)
                {
                    second += value[i] / Math.Pow(1000, i);
                }
                return second;
            };

            FuncNames degToRad = Add("GradusToRadian");
            list = degToRad.GetFewNames();
            list.Add("DegToRad");
            list.Add("GradusToRadian");
            degToRad.Appointment = "Перевод из градусов в радианы";
            degToRad.Description = "Переводит преобразованный функцией " + degNorm.GetName() + " заданный угол из градусной меры в радианную \n"
                                   + degToRad.GetName() + "(a) = 2*a*PI/360";
            degToRad.FuncDoing = (value) =>
            {
                return degNorm.FuncDoing(value) * 2 * Math.PI / 360;
            };

            FuncNames degToGrad = Add("GradusToGradian");
            list = degToGrad.GetFewNames();
            list.Add("DegToGrad");
            list.Add("GradusToGrad");
            degToGrad.Appointment = "Перевод из градусов в грады (градианы)";
            degToGrad.Description = "Переводит преобразованный функцией " + degNorm.GetName() + " заданный угол из градусной меры в градианную \n" +
                degToGrad.GetName() + "(a) = a*400/360";
            degToGrad.FuncDoing = (value) =>
            {
                return degNorm.FuncDoing(value) * 400 / 360;
            };

            FuncNames degToOborot = Add("GradusToOborot");
            list = degToOborot.GetFewNames();
            list.Add("DegToOborot");
            degToOborot.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            degToOborot.Appointment = "Перевод из градусов в обороты (окружности)";
            degToOborot.Description = "Переводит преобразованный функцией " + degNorm.GetName() + " заданный угол из градусной меры в количество оборотов (окружностей) \n" +
                degToOborot.GetName() + "(a) = a/360";
            degToOborot.FuncDoing = (value) =>
            {
                return degNorm.FuncDoing(value) / 360;
            };

            FuncNames degToPI = Add("GradusToPI");
            list = degToPI.GetFewNames();
            list.Add("DegToPI");
            degToPI.Appointment = "Перевод из градусов в PI";
            degToPI.Description = "Переводит преобразованный функцией " + degNorm.GetName() + " заданный угол из градусной меры в количество чисел PI \n" +
                degToPI.GetName() + "(a) = a/180";
            degToPI.FuncDoing = (value) =>
            {
                return degNorm.FuncDoing(value) / 180;
            };


            FuncNames degToMinute = Add("GradusToMinute");
            list = degToMinute.GetFewNames();
            list.Add("DegToMinute");
            degToMinute.Appointment = "Перевод из градусов в минуты";
            degToMinute.Description = "Переводит преобразованный функцией " + degNorm.GetName() + " заданный угол из градусной меры в минутную \n" +
                degToMinute.GetName() + "(a) = a*60";
            degToMinute.FuncDoing = (value) =>
            {
                return degNorm.FuncDoing(value) * 60;
            };

            FuncNames degToSecond = Add("GradusToSecond");
            list = degToSecond.GetFewNames();
            list.Add("DegToSecond");
            degToSecond.Appointment = "Перевод из градусов в секунды";
            degToSecond.Description = "Переводит преобразованный функцией " + degNorm.GetName() + " заданный угол из градусной меры в секундную \n" +
                degToSecond.GetName() + "(a) = a*3600";
            degToSecond.FuncDoing = (value) =>
            {
                return degNorm.FuncDoing(value) * 3600;
            };

            FuncNames degToRumb = Add("GradusToRumb");
            list = degToRumb.GetFewNames();
            list.Add("DegToRumb");
            degToRumb.Appointment = "Перевод из градусов в румбы";
            degToRumb.Description = "Переводит преобразованный функцией " + degNorm.GetName() + " заданный угол из градусной меры в румбическую \n" +
                degToSecond.GetName() + "(a) = a/11.25";
            degToRumb.FuncDoing = (value) =>
            {
                return degNorm.FuncDoing(value) / 11.25;
            };

            FuncNames radToDeg = Add("RadianToGradus");
            list = radToDeg.GetFewNames();
            list.Add("RadToDeg");
            list.Add("RadianToGradus");
            radToDeg.Appointment = "Перевод из радиан в градусы";
            radToDeg.Description = "Переводит заданный угол из радианной меры в градусную \n" +
                radToDeg.GetName() + "(a) = a*360/(2*PI)";
            radToDeg.FuncDoing = (value) =>
            {
                return value[0] * 360 / (2 * Math.PI);
            };

            FuncNames radToGrad = Add("RadianToGradian");
            list = radToGrad.GetFewNames();
            list.Add("RadToGrad");
            list.Add("RadianToGrad");
            radToGrad.Appointment = "Перевод из радиан в грады (градианы)";
            radToGrad.Description = "Переводит заданный угол из радианной меры в градианную \n" +
                radToGrad.GetName() + "(a) = a*200/PI";
            radToGrad.FuncDoing = (value) =>
            {
                return radToDeg.FuncDoing(value[0]) * 400 / 360;
            };

            FuncNames radToOborot = Add("RadianToOborot");
            list = radToOborot.GetFewNames();
            list.Add("RadToOborot");
            radToOborot.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            radToOborot.Appointment = "Перевод из радиан в обороты (окружности)";
            radToOborot.Description = "Переводит заданный угол из радианной меры в количество оборотов (окружностей) \n" +
                radToOborot.GetName() + "(a) = a/(2*PI)";
            radToOborot.FuncDoing = (value) =>
            {
                return radToDeg.FuncDoing(value[0]) / 360;
            };

            FuncNames radToPI = Add("RadianToPI");
            list = radToPI.GetFewNames();
            list.Add("RadToPI");
            radToPI.Appointment = "Перевод из радианов в PI";
            radToPI.Description = "Переводит заданный угол из радианной меры в количество чисел PI \n" +
                radToPI.GetName() + "(a) = a/PI";
            radToPI.FuncDoing = (value) =>
            {
                return radToDeg.FuncDoing(value[0]) / 180;
            };


            FuncNames radToMinute = Add("RadianToMinute");
            list = radToMinute.GetFewNames();
            list.Add("RadToMinute");
            radToMinute.Appointment = "Перевод из радианов в минуты";
            radToMinute.Description = "Переводит заданный угол из радианной меры в минутную \n" +
                radToMinute.GetName() + "(a) = a*21600/(2*PI)";
            radToMinute.FuncDoing = (value) =>
            {
                return radToDeg.FuncDoing(value[0]) * 60;
            };

            FuncNames radToSecond = Add("RadianToSecond");
            list = radToSecond.GetFewNames();
            list.Add("RadToSecond");
            radToSecond.Appointment = "Перевод из радианов в секунды";
            radToSecond.Description = "Переводит заданный угол из радианной меры в секундную \n" +
                radToSecond.GetName() + "(a) = a*1296000/(2*PI)";
            radToSecond.FuncDoing = (value) =>
            {
                return radToDeg.FuncDoing(value[0]) * 3600;
            };

            FuncNames radToRumb = Add("RadianToRumb");
            list = radToRumb.GetFewNames();
            list.Add("RadToRumb");
            radToRumb.Appointment = "Перевод из радианов в румбы";
            radToRumb.Description = "Переводит заданный угол из радианной меры в румбическую \n" +
                radToRumb.GetName() + "(a) =  a*360/(22.5*PI)";
            radToRumb.FuncDoing = (value) =>
            {
                return radToDeg.FuncDoing(value[0]) / 11.25;
            };

            FuncNames gradToDeg = Add("GradianToGradus");
            list = gradToDeg.GetFewNames();
            list.Add("GradToDeg");
            list.Add("GradianToGradus");
            gradToDeg.Appointment = "Перевод из градов (градианов) в градусы";
            gradToDeg.Description = "Переводит заданный угол из градианной меры в градусную \n" +
                gradToDeg.GetName() + "(a) = a*360/400";
            gradToDeg.FuncDoing = (value) =>
            {
                return value[0] * 360 / 400;
            };

            FuncNames gradToRad = Add("GradianToRadian");
            list = gradToRad.GetFewNames();
            list.Add("GradToRadian");
            list.Add("GradToRad");
            gradToRad.Appointment = "Перевод из градов (градианов) в радианную";
            gradToRad.Description = "Переводит заданный угол из градианной меры в радианную \n" +
                gradToRad.GetName() + "(a) = a*PI/200";
            gradToRad.FuncDoing = (value) =>
            {
                return gradToDeg.FuncDoing(value) * 2 * Math.PI / 360;
            };

            FuncNames gradToOborot = Add("GradianToOborot");
            list = gradToOborot.GetFewNames();
            list.Add("GradToOborot");
            gradToOborot.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            radToOborot.Appointment = "Перевод из градов (градианов) в обороты (окружности)";
            radToOborot.Description = "Переводит заданный угол из градианной меры в количество оборотов (окружностей) \n" +
                gradToOborot.GetName() + "(a) = a/400";
            radToOborot.FuncDoing = (value) =>
            {
                return gradToDeg.FuncDoing(value[0]) / 360;
            };

            FuncNames gradToPI = Add("GradianToPI");
            list = gradToPI.GetFewNames();
            list.Add("GradToPI");
            gradToPI.Appointment = "Перевод из градов (градианов) в PI";
            gradToPI.Description = "Переводит заданный угол из градианной меры в количество чисел PI \n" +
                gradToPI.GetName() + "(a) = a/200";
            gradToPI.FuncDoing = (value) =>
            {
                return gradToDeg.FuncDoing(value[0]) / 180;
            };


            FuncNames gradToMinute = Add("GradianToMinute");
            list = gradToMinute.GetFewNames();
            list.Add("GradToMinute");
            gradToMinute.Appointment = "Перевод из градов (градианов) в минуты";
            gradToMinute.Description = "Переводит заданный угол из градианной меры в минутную \n" +
                gradToMinute.GetName() + "(a) = a*21600/400";
            gradToMinute.FuncDoing = (value) =>
            {
                return gradToDeg.FuncDoing(value[0]) * 60;
            };

            FuncNames gradToSecond = Add("GradianToSecond");
            list = gradToSecond.GetFewNames();
            list.Add("GradToSecond");
            gradToSecond.Appointment = "Перевод из градов (градианов) в секунды";
            gradToSecond.Description = "Переводит заданный угол из градианной меры в секундную \n" +
                gradToSecond.GetName() + "(a) = a*1296000/400";
            gradToSecond.FuncDoing = (value) =>
            {
                return gradToDeg.FuncDoing(value[0]) * 3600;
            };

            FuncNames gradToRumb = Add("GradianToRumb");
            list = gradToRumb.GetFewNames();
            list.Add("GradToRumb");
            gradToRumb.Appointment = "Перевод из градов (градианов) в румбы";
            gradToRumb.Description = "Переводит заданный угол из градианной меры в румбическую \n" +
                gradToRumb.GetName() + "(a) =  a*360/(11.25*400)";
            gradToRumb.FuncDoing = (value) =>
            {
                return gradToDeg.FuncDoing(value[0]) / 11.25;
            };

            ReplaceItemToEnd(radToDeg);
            ReplaceItemToEnd(radToGrad);
            ReplaceItemToEnd(radToOborot);
            ReplaceItemToEnd(radToPI);
            ReplaceItemToEnd(radToMinute);
            ReplaceItemToEnd(radToSecond);
            ReplaceItemToEnd(radToRumb);


            FuncNames oborotToDeg = Add("OborotToGradus");
            list = oborotToDeg.GetFewNames();
            list.Add("OborotToDeg");
            oborotToDeg.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            oborotToDeg.Appointment = "Перевод из оборотов (окружностей) в градусы";
            oborotToDeg.Description = $"Переводит заданный угол из количества оборотов (окружностей) из градусной меры в градусную меру\n" +
                oborotToDeg.GetName() + "(a) = a*360";
            oborotToDeg.FuncDoing = (value) =>
            {
                return value[0] * 360;
            };

            FuncNames oborotToRad = Add("OborotToRadian");
            list = oborotToRad.GetFewNames();
            list.Add("OborotToRad");
            oborotToRad.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            oborotToRad.Appointment = "Перевод из радиан в радианы";
            oborotToRad.Description = "Переводит заданный угол из радианной меры в радианную меру \n" +
                oborotToRad.GetName() + "(a) = a*2*PI";
            oborotToRad.FuncDoing = (value) =>
            {
                return oborotToDeg.FuncDoing(value) * (2 * Math.PI) / 360;
            };

            FuncNames oborotToGrad = Add("OborotToGradian");
            list = oborotToGrad.GetFewNames();
            list.Add("OborotToGrad");
            oborotToGrad.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            oborotToGrad.Appointment = "Перевод из оборотов (окружностей) в грады (градианы)";
            oborotToGrad.Description = "Переводит заданный угол из количества оборотов (окружностей) в градианную меру\n" +
                oborotToGrad.GetName() + "(a) = a*400";
            oborotToGrad.FuncDoing = (value) =>
            {
                return oborotToDeg.FuncDoing(value[0]) * 400 / 360;
            };

            FuncNames oborotToPI = Add("OborotToPI");
            oborotToPI.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            oborotToPI.Appointment = "Перевод из оборотов (окружностей) в PI";
            oborotToPI.Description = "Переводит заданный угол из количества оборотов (окружностей) в количество чисел PI \n" +
                oborotToPI.GetName() + "(a) = a*2";
            oborotToPI.FuncDoing = (value) =>
            {
                return oborotToDeg.FuncDoing(value[0]) / 180;
            };


            FuncNames oborotToMinute = Add("OborotToMinute");
            oborotToMinute.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            oborotToMinute.Appointment = "Перевод из оборотов (окружностей) в минуты";
            oborotToMinute.Description = "Переводит заданный угол из количества оборотов (окружностей) в минутную меру\n" +
               oborotToMinute.GetName() + "(a) = a*21600/400";
            oborotToMinute.FuncDoing = (value) =>
            {
                return oborotToDeg.FuncDoing(value[0]) * 60;
            };

            FuncNames oborotToSecond = Add("OborotToSecond");
            oborotToSecond.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            oborotToSecond.Appointment = "Перевод из оборотов (окружностей) в секунды";
            oborotToSecond.Description = "Переводит заданный угол из градианной меры в секундную меру\n" +
                oborotToSecond.GetName() + "(a) = a*1296000/400";
            oborotToSecond.FuncDoing = (value) =>
            {
                return oborotToDeg.FuncDoing(value[0]) * 3600;
            };

            FuncNames oborotToRumb = Add("OborotToRumb");
            oborotToRumb.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            oborotToRumb.Appointment = "Перевод из gradToRumb в румбы";
            oborotToRumb.Description = "Переводит заданный угол из градианной меры в румбическую меру\n" +
                oborotToRumb.GetName() + "(a) =  a*360/(11.25*400)";
            oborotToRumb.FuncDoing = (value) =>
            {
                return oborotToDeg.FuncDoing(value[0]) / 11.25;
            };

            FuncNames piToDeg = Add("PiToGradus");
            list = piToDeg.GetFewNames();
            list.Add("PiToDeg");
            piToDeg.Appointment = "Перевод из чисел PI в градусы";
            piToDeg.Description = "Переводит заданный угол из количества чисел PI в градусную меру \n" +
                piToDeg.GetName() + "(a) = a*180";
            piToDeg.FuncDoing = (value) =>
            {
                return value[0] * 180;
            };

            FuncNames piToRad = Add("PiToRadian");
            list = piToRad.GetFewNames();
            list.Add("PiToRad");
            piToRad.Appointment = "Перевод из градов (градианов) в радианы";
            piToRad.Description = "Переводит заданный угол из градианной меры в радианную меру \n" +
               piToRad.GetName() + "(a) = a*PI";
            piToRad.FuncDoing = (value) =>
            {
                return piToDeg.FuncDoing(value) * 2 * Math.PI / 360;
            };

            FuncNames piToGrad = Add("PiToGradian");
            list = piToGrad.GetFewNames();
            list.Add("PiToGrad");
            piToGrad.Appointment = "Перевод из количества чисел PI в грады (градианы)";
            piToGrad.Description = "Переводит заданный угол из количества чисел PI в градианную меру \n" +
                piToGrad.GetName() + "(a) = a*200";
            radToGrad.FuncDoing = (value) =>
            {
                return piToDeg.FuncDoing(value[0]) * 400 / 360;
            };

            FuncNames piToOborot = Add("PiToOborot");
            list = piToOborot.GetFewNames();
            piToOborot.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            piToOborot.Appointment = "Перевод из чисел PI в обороты (окружности)";
            piToOborot.Description = "Переводит заданный угол из количества чисел PI в количество оборотов (окружностей) \n" +
                piToOborot.GetName() + "(a) = a/2";
            piToOborot.FuncDoing = (value) =>
            {
                return piToDeg.FuncDoing(value[0]) / 360;
            };

            FuncNames piToMinute = Add("PiToMinute");
            piToMinute.Appointment = "Перевод из чисел PI в минуты";
            piToMinute.Description = "Переводит заданный угол из количества чисел PI в минутную меру\n" +
                piToMinute.GetName() + "(a) = a*7200";
            piToMinute.FuncDoing = (value) =>
            {
                return piToDeg.FuncDoing(value[0]) * 60;
            };

            FuncNames piToSecond = Add("PiToSecond");
            piToSecond.Appointment = "Перевод из чисел PI в секунды";
            piToSecond.Description = "Переводит заданный угол из количества чисел PI в секундную меру\n" +
                piToSecond.GetName() + "(a) = a*432000";
            piToSecond.FuncDoing = (value) =>
            {
                return piToDeg.FuncDoing(value[0]) * 3600;
            };

            FuncNames piToRumb = Add("PiToRumb");
            piToRumb.Appointment = "Перевод из чисел PI в румбы";
            piToRumb.Description = "Переводит заданный угол из количества чисел PI в румбическую \n" +
                piToRumb.GetName() + "(a) =  a*180/11.25";
            piToRumb.FuncDoing = (value) =>
            {
                return piToDeg.FuncDoing(value[0]) / 11.25;
            };

            FuncNames minuteToDeg = Add("MinuteToGradus");
            list = minuteToDeg.GetFewNames();
            list.Add("MinuteToDeg");
            minuteToDeg.Appointment = "Перевод из минут в градусы";
            minuteToDeg.Description = "Переводит заданный угол из минутной меры в градусную меру \n" +
                minuteToDeg.GetName() + "(a) = a/60";
            minuteToDeg.FuncDoing = (value) =>
            {
                return value[0] / 60;
            };

            FuncNames minuteToRad = Add("MinuteToRadian");
            list = minuteToRad.GetFewNames();
            list.Add("MinuteToRad");
            minuteToRad.Appointment = "Перевод из минут в радианы";
            minuteToRad.Description = "Переводит заданный угол из минутной меры в радианную меру \n" +
                minuteToRad.GetName() + "(a) = a*2*PI/21600";
            minuteToRad.FuncDoing = (value) =>
            {
                return minuteToDeg.FuncDoing(value) * 2 * Math.PI / 360;
            };

            FuncNames minuteToGrad = Add("MinuteToGradian");
            list = minuteToGrad.GetFewNames();
            list.Add("MinuteToGrad");
            minuteToGrad.Appointment = "Перевод из минут в грады (градианы)";
            minuteToGrad.Description = "Переводит заданный угол из минутной меры в градианную меру \n" +
                minuteToGrad.GetName() + "(a) = a*400/21600";
            minuteToGrad.FuncDoing = (value) =>
            {
                return minuteToDeg.FuncDoing(value[0]) * 400 / 360;
            };

            FuncNames minuteToOborot = Add("MinuteToOborot");
            minuteToOborot.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            minuteToOborot.Appointment = "Перевод из минут в обороты (окружности)";
            minuteToOborot.Description = "Переводит заданный угол из минутной меры в количество оборотов (окружностей) \n" +
                minuteToOborot.GetName() + "(a) = a/21600";
            minuteToOborot.FuncDoing = (value) =>
            {
                return minuteToDeg.FuncDoing(value[0]) / 360;
            };

            FuncNames minuteToPI = Add("MinuteToPI");
            minuteToPI.Appointment = "Перевод из минут в PI";
            minuteToPI.Description = "Переводит заданный угол из минутной меры в количество чисел PI \n" +
                minuteToPI.GetName() + "(a) = a/10800";
            minuteToPI.FuncDoing = (value) =>
            {
                return minuteToDeg.FuncDoing(value[0]) / 180;
            };

            FuncNames minuteToSecond = Add("MinuteToSecond");
            minuteToSecond.Appointment = "Перевод из минут в секунды";
            minuteToSecond.Description = "Переводит заданный угол из минутной меры в секундную меру\n" +
                minuteToSecond.GetName() + "(a) = a*60";
            minuteToSecond.FuncDoing = (value) =>
            {
                return minuteToDeg.FuncDoing(value[0]) * 3600;
            };

            FuncNames minuteToRumb = Add("MinuteToRumb");
            minuteToRumb.Appointment = "Перевод из минут в румбы";
            minuteToRumb.Description = "Переводит заданный угол из минутной меры в румбическую \n" +
                minuteToRumb.GetName() + "(a) =  a*/(11.25*60)";
            minuteToRumb.FuncDoing = (value) =>
            {
                return minuteToDeg.FuncDoing(value[0]) / 11.25;
            };

            FuncNames secondToDeg = Add("SecondToGradus");
            list = secondToDeg.GetFewNames();
            list.Add("SecondToDeg");
            secondToDeg.Appointment = "Перевод из секунд в градусы";
            secondToDeg.Description = $"Переводит преобразованный функцией " + secondNorm.GetName() + " заданный угол из секундной меры в градусную меру \n" +
                secondToDeg.GetName() + "(a) = a/3600";
            secondToDeg.FuncDoing = (value) =>
            {
                return secondNorm.FuncDoing(value) / 3600;
            };

            FuncNames secondToRad = Add("SecondToRadian");
            list = secondToRad.GetFewNames();
            list.Add("SecondToRad");
            secondToRad.Appointment = "Перевод из секунд в радианы";
            secondToRad.Description = $"Переводит преобразованный функцией " + secondNorm.GetName() + " заданный угол из секундной меры в радианную меру \n" +
                secondToRad.GetName() + "(a) = a*2*PI/1296000";
            secondToRad.FuncDoing = (value) =>
            {
                return secondToDeg.FuncDoing(value) * 2 * Math.PI / 360;
            };

            FuncNames secondToGrad = Add("SecondToGradian");
            list = secondToGrad.GetFewNames();
            list.Add("SecondToGrad");
            secondToGrad.Appointment = "Перевод из секунд в грады (градианы)";
            secondToGrad.Description = $"Переводит преобразованный функцией " + secondNorm.GetName() + " заданный угол из секундной меры в градианную меру \n" +
                secondToGrad.GetName() + "(a) = a*400/1296000";
            secondToGrad.FuncDoing = (value) =>
            {
                return secondToDeg.FuncDoing(value) * 400 / 360;
            };

            FuncNames secondToOborot = Add("SecondToOborot");
            secondToOborot.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            secondToOborot.Appointment = "Перевод из секунд в обороты (окружности)";
            secondToOborot.Description = $"Переводит преобразованный функцией " + secondNorm.GetName() + " заданный угол из секундной меры в количество оборотов (окружностей) \n" +
                secondToOborot.GetName() + "(a) = a/1296000";
            secondToOborot.FuncDoing = (value) =>
            {
                return secondToDeg.FuncDoing(value) / 360;
            };

            FuncNames secondToPI = Add("SecondToPI");
            secondToPI.Appointment = "Перевод из секунд в PI";
            secondToPI.Description = $"Переводит преобразованный функцией " + secondNorm.GetName() + " заданный угол из секундной меры в количество чисел PI \n" +
                secondToPI.GetName() + "(a) = a/648000";
            secondToPI.FuncDoing = (value) =>
            {
                return secondToDeg.FuncDoing(value) / 180;
            };

            FuncNames secondToMinute = Add("SecondToMinute");
            secondToMinute.Appointment = "Перевод из секунд в минуты";
            secondToMinute.Description = $"Переводит преобразованный функцией " + secondNorm.GetName() + " заданный угол из секундной меры в минутную меру\n" +
                secondToMinute.GetName() + "(a) = a/60";
            secondToMinute.FuncDoing = (value) =>
            {
                return secondToDeg.FuncDoing(value) * 60;
            };

            FuncNames secondToRumb = Add("SecondToRumb");
            secondToRumb.Appointment = "Перевод из секунд в румбы";
            secondToRumb.Description = $"Переводит преобразованный функцией " + secondNorm.GetName() + " заданный угол из секундной меры в румбическую \n" +
                secondToRumb.GetName() + "(a) =  a*/(11.25*60)";
            secondToRumb.FuncDoing = (value) =>
            {
                return secondToDeg.FuncDoing(value) / 11.25;
            };

            FuncNames rumbToDeg = Add("RumbToGradus");
            list = rumbToDeg.GetFewNames();
            list.Add("RumbToDeg");
            rumbToDeg.Appointment = "Перевод из румбов в градусы";
            rumbToDeg.Description = "Переводит заданный угол из румбической меры в градусную меру \n" +
               rumbToDeg.GetName() + "(a) = a*11.25";
            rumbToDeg.FuncDoing = (value) =>
            {
                return value[0] / 11.25;
            };

            FuncNames rumbToRad = Add("RumbToRadian");
            list = rumbToRad.GetFewNames();
            list.Add("RumbToRad");
            rumbToRad.Appointment = "Перевод из румбов в радианы";
            rumbToRad.Description = "Переводит заданный угол из румбической меры в радианную меру \n" +
                rumbToRad.GetName() + "(a) = a*22.5*PI/360";
            rumbToRad.FuncDoing = (value) =>
            {
                return rumbToDeg.FuncDoing(value) * 2 * Math.PI / 360;
            };

            FuncNames rumbToGrad = Add("RumbToGradian");
            list = rumbToGrad.GetFewNames();
            list.Add("RumbToGrad");
            rumbToGrad.Appointment = "Перевод из румбов в грады (градианы)";
            rumbToGrad.Description = "Переводит заданный угол из румбической меры в градианную меру \n" +
               rumbToGrad.GetName() + "(a) = a*4500/360";
            rumbToGrad.FuncDoing = (value) =>
            {
                return rumbToDeg.FuncDoing(value[0]) * 400 / 360;
            };

            FuncNames rumbToOborot = Add("RumbToOborot");
            rumbToOborot.AddNamesByReplace("Oborot", "Curcle").
                AddNamesByReplace("Curcle", "Circle").
                AddNamesByReplace("Curcle", "Surcle").
                AddNamesByReplace("Circle", "Sircle");
            rumbToOborot.Appointment = "Перевод из румбов в обороты (окружности)";
            rumbToOborot.Description = "Переводит заданный угол из румбической меры в количество оборотов (окружностей) \n" +
                rumbToOborot.GetName() + "(a) = a*11.25/360";
            rumbToOborot.FuncDoing = (value) =>
            {
                return rumbToDeg.FuncDoing(value[0]) / 360;
            };

            FuncNames rumbToPI = Add("RumbToPI");
            rumbToPI.Appointment = "Перевод из румбов в PI";
            rumbToPI.Description = "Переводит заданный угол из румбической меры в количество чисел PI \n" +
                rumbToPI.GetName() + "(a) = a*11.25/180";
            rumbToPI.FuncDoing = (value) =>
            {
                return rumbToDeg.FuncDoing(value[0]) / 180;
            };

            FuncNames rumbToMinute = Add("RumbToMinute");
            rumbToMinute.Appointment = "Перевод из румбов в минуты";
            rumbToMinute.Description = "Переводит заданный угол из румбической меры в минутную меру\n" +
                rumbToMinute.GetName() + "(a) = a*60*11.25";
            rumbToMinute.FuncDoing = (value) =>
            {
                return rumbToDeg.FuncDoing(value[0]) * 60;
            };

            FuncNames rumbToSecond = Add("RumbToSecond");
            rumbToSecond.Appointment = "Перевод из румбов в секунды";
            rumbToSecond.Description = "Переводит заданный угол из румбической меры в секундную меру\n" +
                rumbToSecond.GetName() + "(a) = a*3600*11.25";
            rumbToSecond.FuncDoing = (value) =>
            {
                return rumbToDeg.FuncDoing(value[0]) * 3600;
            };



            FuncOperator stepen = AddOperator("Stepen");
            list = stepen.GetFewNames();
            list.Add("LogExpend");
            list.Add("LogExp");
            list.Add("\\");
            list.Add("-/-");
            stepen.WorkOperator = true;
            stepen.BinarnFewPriority = 3;
            stepen.BinarnPriority = 1;
            stepen.Appointment = "Логарифм по алгоритму автора данной программы";
            stepen.Description = "Вычисляет логарифм по алгоритму автора данной программы: a-/-b = log(b;a) = (b)log(a)";
            stepen.FuncDoing = (value) =>
                {
                    return CalculatorFunc.Stepen(value[0], value[1]);
                };


            FuncNames rightTriangle = Add("RightTriangle");
            list = rightTriangle.GetFewNames();
            list.Add("RightTriangle");
            list.Add("RightTriangl");
            list.Add("RightTriang");
            list.Add("◺");
            list.Add("◣");
            rightTriangle.Appointment = "Работа с прямоугольным треугльником";
            rightTriangle.Description = "Набор функций для работы с прямоугольным треугльником. Определяется функция 1-ым аргументом: \n" +
                "0 - Является ли треугльник с введёнными сторонами прямоугольным; \n" +
                "1 - Гипотенуза по 2-м катетам; \n" +
                "2 - Катет по гипотенузе и другому катету; \n" +
                "3 - Синус угла по гипотенузе и протеволежащему катету (Косинус угла по гипотенузе и прилежащему тангенсу, или тангенс угла по двум катетам); \n" +
                "4 - Угол в градусах по гипотенузе и протеволежащему катету; \n" +
                "5 - Угол в градусах по гипотенузе и прилежащему катету; \n" +
                "6 - Угол в градусах по протеволежащему катету и прилежащему катету; \n" +
                "7 - Угол в градусах по прилежащему катету и протеволежащему катету; \n" +
                "8 - Противоположный острый угол; \n" +
                "9 - Гипотенуза по катету и синусу протиполежащего угла (косинусу прилежащего угла); \n" +
                "10 - Гипотенуза по катету и прилежащему углу (в градусах); \n" +
                "11 - Гипотенуза по катету и противолежащему углу (в градусах); \n" +
                "12 - Катет по гипотенузе и синусу протиполежащего угла (косинусу прилежащего угла); \n" +
                "13 - Катет по гипотенузе и противолежащему углу (в градусах); \n" +
                "14 - Катет по гипотенузе и прилежащему углу (в градусах); \n" +
                "15 - Катет по другому катету и противолежащему углу (в градусах); \n" +
                "16 - Катет по другому катету и прилежащему углу (в градусах); \n" +
                "17 - Радиус описанной окружности по гипотенузе; \n" +
                "18 - Радиус описанной окружности по двум катетам; \n" +
                "19 - Гипотенуза по радиусу описанной окружности; \n" +
                "20 - Катет по радиусу описанной окружности и другому катету; \n";
            rightTriangle.FuncDoing = (value) =>
            {
                try
                {
                    int n = HyperbolicFunctions.ToInt(value[0]);
                    switch (n)
                    {
                        case 0:
                            {
                                double a = value[1];
                                double b = value[2];
                                double c = value[3];
                                double d = Math.Pow(a, 2) + Math.Pow(b, 2) - Math.Pow(c, 2);
                                if (Math.Round(d, 14) == 0)
                                {
                                    return 1;
                                }
                                d = Math.Pow(a, 2) + Math.Pow(c, 2) - Math.Pow(b, 2);
                                if (Math.Round(d, 14) == 0)
                                {
                                    return 1;
                                }
                                d = Math.Pow(b, 2) + Math.Pow(c, 2) - Math.Pow(a, 2);
                                if (Math.Round(d, 14) == 0)
                                {
                                    return 1;
                                }
                                return 0;
                            }
                        case 1:
                            {
                                double a = value[1];
                                double b = value[2];
                                return HyperbolicFunctions.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2));
                            }
                        case 2:
                            {
                                double a = value[1];
                                double b = value[2];
                                return HyperbolicFunctions.Sqrt(Math.Pow(a, 2) - Math.Pow(b, 2));
                            }
                        case 3:
                            {
                                double a = value[1];
                                double b = value[2];
                                return a / b;
                            }
                        case 4:
                            {
                                double a = value[1];
                                double b = value[2];
                                return UgolsConverter.Arcsin(a / b);
                            }
                        case 5:
                            {
                                double a = value[1];
                                double b = value[2];
                                return UgolsConverter.Arccos(a / b);
                            }
                        case 6:
                            {
                                double a = value[1];
                                double b = value[2];
                                return UgolsConverter.Arctg(a / b);
                            }
                        case 7:
                            {
                                double a = value[1];
                                double b = value[2];
                                return UgolsConverter.Arcctg(a / b);
                            }
                        case 8:
                            {
                                return 90 - value[1];
                            }
                        case 9:
                            {
                                return value[1] / value[2];
                            }
                        case 10:
                            {
                                return value[1] / UgolsConverter.Cos(value[2]);
                            }
                        case 11:
                            {
                                return value[1] / UgolsConverter.Sin(value[2]);
                            }
                        case 12:
                            {
                                return value[1] * value[2];
                            }
                        case 13:
                            {
                                return value[1] * UgolsConverter.Cos(value[2]);
                            }
                        case 14:
                            {
                                return value[1] * UgolsConverter.Sin(value[2]);
                            }
                        case 15:
                            {
                                return value[1] * UgolsConverter.Tg(value[2]);
                            }
                        case 16:
                            {
                                return value[1] * UgolsConverter.Ctg(value[2]);
                            }
                        case 17:
                            {
                                return value[1] / 2;
                            }
                        case 18:
                            {
                                double a = value[1];
                                double b = value[2];
                                return HyperbolicFunctions.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2)) / 2;
                            }
                        case 19:
                            {
                                return value[1] * 2;
                            }
                        case 20:
                            {
                                double a = value[1];
                                double b = value[2];
                                return HyperbolicFunctions.Sqrt(Math.Pow(a * 2, 2) - Math.Pow(b, 2));
                            }
                    }
                    return 0;
                }
                catch (Exception ex)
                {
                    return double.NaN;
                }
            };

            FuncNames NoEqualTriangle = Add("NoEqualsTriangle");
            FuncNames net = NoEqualTriangle;
            list = net.GetFewNames();
            list.Add("NoEqualsTriangle");
            list.Add("NoEqualTriangle");
            list.Add("NoEqualsTriangl");
            list.Add("NoEqualTriangl");
            net.Appointment = "Проверка неравенства треугольника";
            net.Description = "Проверяет, неравенство треугольника для трёх указанных чисел";
            net.FuncDoing = (value) =>
            {
                double a = Math.Abs(value[0]);
                double b = Math.Abs(value[1]);
                double c = Math.Abs(value[2]);
                if (a > b + c)
                    return 0;
                if (b > a + c)
                    return 0;
                if (c > a + b)
                    return 0;
                return 1;
            };

            FuncNames PosibleTriangle = Add("PosibleTriangle");
            FuncNames pt = PosibleTriangle;
            list = pt.GetFewNames();
            list.Add("PosibleTriangle");
            list.Add("PosibleTriangl");
            list.Add("PosibleTriang");
            list.Add("PosTriangle");
            list.Add("PosTriangl");
            list.Add("PosTriang");
            list.Add("AvailableTriangle");
            list.Add("AvailabelTriangle");
            list.Add("AvailableTriangl");
            list.Add("AvailabelTriangl");
            list.Add("AvailableTriang");
            list.Add("AvailabelTriang");
            list.Add("AvailTriangle");
            list.Add("AvailTriangl");
            list.Add("AvailTriang");
            list.Add("△");
            list.Add("▲");
            pt.Appointment = "Проверка возможности создания треугольника";
            pt.Description = "Проверяет, можно ли создать треугольник с тремя указанными сторонами";
            pt.FuncDoing = (value) =>
            {
                double a = Math.Abs(value[0]);
                double b = Math.Abs(value[1]);
                double c = Math.Abs(value[2]);
                if (a >= b + c)
                    return 0;
                if (b >= a + c)
                    return 0;
                if (c >= a + b)
                    return 0;
                return 1;
            };

            FuncNames lenVector = Add("LenVector");
            lenVector.GetFewNames().Add("LengthVector");
            lenVector.Appointment = "Длина вектора";
            lenVector.Description = "Длина вектора в произвольном линейном пространстве (Координата вектора - аргумент функции) \n" +
                "Квадратный корень из суммы квадратов координат";
            lenVector.Doing = (value) =>
            {
                int length = value.Length;
                double sum = 0;
                for (int i = 0; i < length; i++)
                {
                    sum += Math.Pow(value[i], 2);
                }
                return HyperbolicFunctions.Sqrt(sum);
            };


            FuncNames divsqrt = AddOperator();
            divsqrt.SetName("DivisionSqrt");
            list = divsqrt.GetFewNames();
            list.Add("DivisionSqrt");
            list.Add("DegreeSqrt");
            list.Add("SegmentationSqrt");
            list.Add("SegmentSqrt");
            list.Add("DivSqrt");
            list.Add("DelenieSqrt");
            list.Add("DelenSqrt");
            list.Add("SqrtDivision");
            list.Add("SqrtDegree");
            list.Add("SqrtSegmentation");
            list.Add("SqrtSegment");
            list.Add("SqrtDiv");
            list.Add("SqrtDelenie");
            list.Add("SqrtDelen");
            divsqrt.Appointment = "Квадратный корень частного";
            divsqrt.Description = "Деление квадратного корня 1-ого аргумента на произведение квадратных корней всех последующих аргументов \n" +
                "Если аргумент 1, то он  возвращается его квадратный корень\n" +
                "(√a)/(√b) = √(a/b); \n " +
                "(√a)/(√b^2)/(√c^2) = (√(a/b))/(√c) = √(a/b/c) = (√a)/(√(b*c)); \n" +
                "(√a1)/(√a2)/.../(√an) = √(a1/a2/.../an)";
            divsqrt.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = value[0];
                for (int i = 1; i < length; i++)
                {
                    double b = value[i];
                    if (b == 0)
                    {
                        return double.NaN; ;
                    }
                    sum /= b;
                }
                return HyperbolicFunctions.Sqrt(sum);
            };

            FuncNames divsqr = AddOperator();
            divsqr.SetName("DivisionSqr");
            list = divsqr.GetFewNames();
            list.Add("DivisionSqr");
            list.Add("DegreeSqr");
            list.Add("SegmentationSqr");
            list.Add("SegmentSqr");
            list.Add("DivSqr");
            list.Add("DelenieSqr");
            list.Add("DelenSqr");
            list.Add("SqrDivision");
            list.Add("SqrDegree");
            list.Add("SqrSegmentation");
            list.Add("SqrSegment");
            list.Add("SqrDiv");
            list.Add("SqrDelenie");
            list.Add("SqrDelen");
            divsqr.Appointment = "Квадрат частного";
            divsqr.Description = "Деление квадраты 1-ого аргумента на произведение квадратов всех последующих аргументов \n" +
                "Если аргумент 1, то он  возвращается его квадрат\n" +
                "(a^2)/(b^2) = (a/b)^2; \n " +
                "(a^2)/(b^2)/(c^2) = ((a/b)^2)/(c^2) = (a/b/c)^2 = (a^2)/((b*c)^2); \n" +
                "(a1^2)/(a2^2)/.../(an^2) = (a1/a2/.../an)^2";
            divsqr.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = value[0];
                for (int i = 1; i < length; i++)
                {
                    double b = value[i];
                    if (b == 0)
                    {
                        return double.NaN; ;
                    }
                    sum /= b;
                }
                return Math.Pow(sum, 2);
            };


            FuncNames subsqrt = Add();
            subsqrt.SetName("SubstractionSqrt");
            list = subsqrt.GetFewNames();
            list.Add("DeductionSqrt");
            list.Add("VichitaieSqrtt");
            list.Add("VichetaieSqrt");
            list.Add("VichitSqrt");
            list.Add("VichetSqrt");
            list.Add("SubSqrt");
            list.Add("MinesSqrt");
            subsqrt.Appointment = "Разность квадратных корней";
            subsqrt.Description = "Если аргумент 1, то возвращает квадратный корень этого аргумента, умноженный на -1 \n" +
                "В противном случае вычитает из квадратного корня 1-ого аргумента сумму квадратных корней всех последующих аргументов";
            subsqrt.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = HyperbolicFunctions.Sqrt(value[0]);
                if (length < 2)
                    return -sum;
                for (int i = 1; i < length; i++)
                {
                    sum -= HyperbolicFunctions.Sqrt(value[i]);
                }
                return sum;
            };

            FuncNames subsqr = Add();
            subsqr.SetName("SubstractionSqr");
            list = subsqr.GetFewNames();
            list.Add("DeductionSqr");
            list.Add("VichitaieSqr");
            list.Add("VichetaieSqr");
            list.Add("VichitSqr");
            list.Add("VichetSqr");
            list.Add("SubSqr");
            list.Add("MinesSqr");
            subsqr.Appointment = "Разность квадрат";
            subsqr.Description = "Если аргумент 1, то возвращает квадрат этого аргумента, умноженный на -1 \n" +
                "В противном случае вычитает из квадрата 1-ого аргумента сумму квадратов всех последующих аргументов";
            subsqr.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = Math.Pow(value[0], 2);
                if (length < 2)
                    return -sum;
                for (int i = 1; i < length; i++)
                {
                    sum -= Math.Pow(value[i], 2);
                }
                return sum;
            };

            FuncNames sqrtsub = Add();
            sqrtsub.SetName("SqrtSubstraction");
            list = sqrtsub.GetFewNames();
            list.Add("SqrtDeduction");
            list.Add("SqrtVichitaie");
            list.Add("SqrtVichetaie");
            list.Add("SqrtVichit");
            list.Add("SqrtVichet");
            list.Add("SqrtSub");
            list.Add("SqrtMines");
            sqrtsub.Appointment = "Квадратный корень разности ";
            sqrtsub.Description = "Если аргумент 1, то возвращает квадратный корень этого аргумента, умноженный на -1\n" +
                "В противном случае вычитает из 1-ого аргумента сумму всех последующих аргументов и из результата извлекает";
            sqrtsub.FuncDoing = (value) =>
            {
                int length = value.Length;
                if (length < 2)
                    return -HyperbolicFunctions.Sqrt(value[0]);
                double sum = value[0];
                for (int i = 1; i < length; i++)
                {
                    sum -= value[i];
                }
                return HyperbolicFunctions.Sqrt(sum);
            };

            FuncNames sqrsub = Add();
            sqrsub.SetName("SqrSubstraction");
            list = sqrsub.GetFewNames();
            list.Add("SqrDeduction");
            list.Add("SqrVichitaie");
            list.Add("SqrVichetaie");
            list.Add("SqrVichit");
            list.Add("SqrVichet");
            list.Add("SqrSub");
            list.Add("SqrMines");
            sqrsub.Appointment = "Квадрат разности ";
            sqrsub.Description = "Если аргумент 1, то возвращает этот аргумент в квадрате \n" +
                "В противном случае вычитает из 1-ого аргумента сумму всех последующих аргументов и результат возводит в квадрат";
            sqrsub.FuncDoing = (value) =>
            {
                int length = value.Length;
                if (length < 2)
                    return Math.Pow(value[0], 2);
                double sum = value[0];
                for (int i = 1; i < length; i++)
                {
                    sum -= value[i];
                }
                return Math.Pow(sum, 2);
            };


            FuncNames mullsqrt = Add();
            mullsqrt.SetName("SqrtMullation");
            list = mullsqrt.GetFewNames();
            list.Add("SqrtMullation");
            list.Add("SqrtMull");
            list.Add("SqrtMulation");
            list.Add("SqrtMul");
            list.Add("SqrtUmnozhenie");
            list.Add("SqrtUmnozh");
            list.Add("SqrtUmn");
            list.Add("MullationSqrt");
            list.Add("MullSqrt");
            list.Add("MulationSqrt");
            list.Add("MulSqrt");
            list.Add("UmnozhenieSqrt");
            list.Add("UmnozhSqrt");
            list.Add("UmnSqrt");
            mullsqrt.Appointment = "Квадратный корень произведения";
            mullsqrt.Description = "Произведение квадратный корней всех указанных аргументов \n" +
                "(√a)*(√b) = √(a*b) = √(b*a) = (√b)*(√a); \n " +
                "(√a)*(√b^2)*(√c^2) = (√(a*b))*(√c) = √(a*b*c) = (√a)*(√(b*c)) = (√b)*(√a)*(√c) = (√b)*(√c)*(√a) = (√c)*(√b)*(√a); \n" +
                "(√a1)*(√a2)*...*(√an) = √(a1*a2*...*an)";
            mullsqrt.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = 1;
                for (int i = 0; i < length; i++)
                {
                    sum *= value[i];
                }
                return HyperbolicFunctions.Sqrt(sum);
            };

            FuncNames mullsqr = Add();
            mullsqr.SetName("SqrMullation");
            list = mullsqr.GetFewNames();
            list.Add("SqrMullation");
            list.Add("SqrMull");
            list.Add("SqrMulation");
            list.Add("SqrMul");
            list.Add("SqrUmnozhenie");
            list.Add("SqrUmnozh");
            list.Add("SqrUmn");
            list.Add("MullationSqr");
            list.Add("MullSqr");
            list.Add("MulationSqr");
            list.Add("MulSqr");
            list.Add("UmnozhenieSqr");
            list.Add("UmnozhSqr");
            list.Add("UmnSqr");
            mullsqr.Appointment = "Квадрат произведения";
            mullsqr.Description = "Произведение квадратов всех указанных аргументов \n" +
                "(a^2)*(b^2) = (a*b)^2 = (b*a)^2 = (b^2)*(a^2); \n " +
                "(a^2)*(b^2)*(c^2) = ((a*b)^2)*(c^2) = (a*b*c)^2 = (a^2)*((b*c)^2) = (b^2)*(a^2)*(c^2) = (b^2)*(c^2)*(a^2) = (c^2)*(b^2)*(a^2); \n" +
                "(a1^2)*(a2^2)*...*(an^2) = (a1*a2*...*an)^2";
            mullsqr.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = 1;
                for (int i = 0; i < length; i++)
                {
                    sum *= value[i];
                }
                return Math.Pow(sum, 2);
            };

            FuncNames addSqrt = Add();
            addSqrt.SetName("additionSqrt");
            list = addSqrt.GetFewNames();
            list.Add("addSqrt");
            list.Add("aditionSqrt");
            list.Add("slozhenieSqrt"); ;
            list.Add("slozhSqrt"); ;
            list.Add("slozSqrt"); ;
            list.Add("slogSqrt");
            list.Add("plusSqrt");
            list.Add("sumaSqrt");
            list.Add("summaSqrt");
            list.Add("summSqrt");
            list.Add("sumSqrt");
            addSqrt.Appointment = "Сумма квадратных корней";
            addSqrt.Description = "Из каждого аргумента извлекает квадратный корень и результаты складывает";
            addSqrt.Doing = (value) =>
            {
                int length = value.Length;
                double sum = 0;
                for (int i = 0; i < length; i++)
                {
                    sum += HyperbolicFunctions.Sqrt(value[i]);
                }
                return sum;
            };

            FuncNames addSqr = Add();
            addSqr.SetName("additionSqr");
            list = addSqr.GetFewNames();
            list.Add("addSqr");
            list.Add("aditionSqr");
            list.Add("slozhenieSqr"); ;
            list.Add("slozhSqr"); ;
            list.Add("slozSqr"); ;
            list.Add("slogSqr");
            list.Add("plusSqr");
            list.Add("sumaSqr");
            list.Add("summaSqr");
            list.Add("summSqr");
            list.Add("sumSqr");
            addSqr.Appointment = "Сумма квадратов";
            addSqr.Description = "Возводит каждый аргумент в квадрат и результаты складывает";
            addSqr.Doing = (value) =>
            {
                int length = value.Length;
                double sum = 0;
                for (int i = 0; i < length; i++)
                {
                    sum += Math.Pow(value[i], 2);
                }
                return sum;
            };

            FuncNames sqrtAdd = Add();
            sqrtAdd.SetName("SqrtAddition");
            list = sqrtAdd.GetFewNames();
            list.Add("SqrtAdd");
            list.Add("SqrtAdition");
            list.Add("SqrtSlozhenie"); ;
            list.Add("SqrtSlozh"); ;
            list.Add("SqrtSloz"); ;
            list.Add("SqrtSlog");
            list.Add("SqrtPlus");
            list.Add("SqrtSuma");
            list.Add("SqrtSumma");
            list.Add("SqrtSumm");
            list.Add("SqrtSum");
            sqrtAdd.Appointment = "Квадратный корень суммы";
            sqrtAdd.Description = "Складывает все аргументы и из результата извлекает квадратный корень";
            sqrtAdd.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = 0;
                for (int i = 0; i < length; i++)
                {
                    sum += (value[i]);
                }
                return HyperbolicFunctions.Sqrt(sum);
            };

            FuncNames sqrAdd = Add();
            sqrAdd.SetName("SqrAddition");
            list = sqrAdd.GetFewNames();
            list.Add("SqrAdd");
            list.Add("SqrAdition");
            list.Add("SqrSlozhenie"); ;
            list.Add("SqrSlozh"); ;
            list.Add("SqrSloz"); ;
            list.Add("SqrSlog");
            list.Add("SqrPlus");
            list.Add("SqrSuma");
            list.Add("SqrSumma");
            list.Add("SqrSumm");
            list.Add("SqrSum");
            sqrAdd.Appointment = "Квадрат суммы";
            sqrAdd.Description = "Складывает все аргументы и результат возводит в квадрат";
            sqrAdd.Doing = (value) =>
            {
                int length = value.Length;
                double sum = 0;
                for (int i = 0; i < length; i++)
                {
                    sum += (value[i]);
                }
                return Math.Pow(sum, 2);
            };


            FuncOperator rightShiftl = AddOperator("LogicalShiftRight");
            rightShiftl.AddFewName(">>>");
            rightShiftl.BinarnFewPriority = 1;
            rightShiftl.BinarnPriority = 1;
            rightShiftl.PriorityToBinarn();
            rightShiftl.WorkOperator = true;
            rightShiftl.Appointment = "Логический сдвиг в право";
            rightShiftl.Description = "Сдвигает биты 1-ого аргумента в право на количество разрядов, указанных вторым аргументом \n" +
                "a>>>b \n" +
                "!!! a>>>(-b) = a<<<b";
            rightShiftl.FuncDoing = (value) =>
            {
                double result = value[0];
                for (int i = 1; i < value.Length; i++)
                {
                    result = HyperbolicFunctions.LogicalShiftRight(result, value[i]);
                }
                return result;
            };


            FuncOperator leftShiftl = AddOperator("LogicalShiftLeft");
            leftShiftl.AddFewName("<<<");
            leftShiftl.BinarnFewPriority = 1;
            leftShiftl.BinarnPriority = 1;
            leftShiftl.PriorityToBinarn();
            leftShiftl.WorkOperator = true;
            leftShiftl.Appointment = "Логический сдвиг в лево";
            leftShiftl.Description = "Сдвигает биты 1-ого аргумента в лево на количество разрядов, указанных вторым аргументом \n" +
                "a<<<b \n" +
                "!!! a<<<(-b) = a>>>b";
            leftShiftl.FuncDoing = (value) =>
            {
                double result = value[0];
                for (int i = 1; i < value.Length; i++)
                {
                    result = HyperbolicFunctions.LogicalShiftLeft(result, value[i]);
                }
                return result;
            };


            FuncOperator rightShift = AddOperator("ArithmeticShiftRight");
            rightShift.AddFewName(">>");
            rightShift.BinarnFewPriority = 1;
            rightShift.BinarnPriority = 1;
            rightShift.PriorityToBinarn();
            rightShift.WorkOperator = true;
            rightShift.Appointment = "Арифметрический сдвиг в право";
            rightShift.Description = "Сдвигает биты 1-ого аргумента в право на количество разрядов, указанных вторым аргументом \n" +
                "a>>b \n" +
                "!!! a>>(-b) = a<<b";
            rightShift.FuncDoing = (value) =>
            {
                double result = value[0];
                for (int i = 1; i < value.Length; i++)
                {
                    result = HyperbolicFunctions.ArithmeticShiftRight(result, value[i]);
                }
                return result;
            };

            FuncOperator leftShift = AddOperator("ArithmeticShiftLeft");
            leftShift.AddFewName("<<");
            leftShift.BinarnFewPriority = 1;
            leftShift.BinarnPriority = 1;
            leftShift.PriorityToBinarn();
            leftShift.WorkOperator = true;
            leftShift.Appointment = "Арифметрический сдвиг в лево";
            leftShift.Description = "Сдвигает биты 1-ого аргумента в лево на количество разрядов, указанных вторым аргументом \n" +
                "a<<b \n" +
                "!!! a<<(-b) = a>>b";
            leftShift.FuncDoing = (value) =>
            {
                double result = value[0];
                for (int i = 1; i < value.Length; i++)
                {
                    result = HyperbolicFunctions.ArithmeticShiftLeft(result, value[i]);
                }
                return result;
                //return HyperbolicFunctions.ArithmeticShiftLeft(value[0], value[1]);
            };


            FuncOperator cmp = AddOperator("Cmp");
            cmp.GetFewNames().Add("<=>");
            cmp.BinarnFewPriority = 1;
            cmp.BinarnPriority = 2;
            cmp.PriorityToBinarn();
            cmp.WorkOperator = true;
            cmp.Appointment = "Трёхстороннее сравнение";
            cmp.Description = "Возвращает 0, если входных числа равны; возвращает 1, если 1-ое число больше 1-ого; Возвращает -1, если 1-ое число меньше 2-ого";
            cmp.Doing = (value) =>
            {
                double result = value[0] - value[1];


                return HyperbolicFunctions.Sgn(result);
            };


            FuncOperator invertAnd = AddOperator("And");
            invertAnd.GetFewNames().Add("&&");
            invertAnd.GetFewNames().Add("∧");
            invertAnd.ReplaceWithAddSymwolFirst("Invert", "Invers", "`¬");
            invertAnd.AddFewName("`↑");
            invertAnd.BinarnPriority = 11;
            invertAnd.BinarnFewPriority = 1;

            invertAnd.UnarnPriority = 1;
            invertAnd.PriorityToBinarn();
            invertAnd.WorkOperator = true;
            invertAnd.Appointment = "Поразрядный оператор \"И-Не\" (Штрих Шеффера - \"Отрицание конъюнкции\" или \"Инверсия конъюнкции\")";
            invertAnd.Description = "Применяет операцию ↑ к каждому двоичному разряду \n" +
                "a↑b = ¬(a∧b) = ((¬a)∨(¬b)) \n" +
                "0∧0=0; 0∧1=0; 1∧0=0; 1∧1=1   =>\n" +
                "0↑0=1; 0↑1=1; 1↑0=1; 1↑1=0 \n" +
                "a↑b = b↑a";
            invertAnd.FuncDoing = (value) =>
            {
                int res = (int)value[0];
                for (int i = 1; i < value.Length; i++)
                {
                    res = ~(res & HyperbolicFunctions.ToInt(value[i]));
                }
                return res;
            };

            FuncOperator invertAndB = AddOperator("And");
            invertAndB.GetFewNames().Add("&&");
            invertAndB.GetFewNames().Add("∧");
            invertAndB.ReplaceWithAddSymwolFirst("No", "¬");
            invertAndB.AddFewName("↑");

            invertAndB.BinarnPriority = 11;
            invertAndB.BinarnFewPriority = 1;

            invertAndB.UnarnPriority = 1;
            invertAndB.PriorityToBinarn();
            invertAndB.WorkOperator = true;
            invertAndB.Appointment = "Логический оператор \"И-Не\" (Штрих Шеффера - \"Отрицание конъюнкции\" или \"Инверсия конъюнкции\")";
            invertAndB.Description = "" +
                "a↑b = ¬(a∧b) = ((¬a)∨(¬b)) \n" +
                "0∧0=0; 0∧1=0; 1∧0=0; 1∧1=1   =>\n" +
                "0↑0=1; 0↑1=1; 1↑0=1; 1↑1=0 \n" +
                "a↑b = b↑a";
            invertAndB.FuncDoing = (value) =>
            {
                //int res = 0;
                int res = (int)value[0];
                if (res != 0 && res != 1)
                    return double.NaN;
                for (int i = 1; i < value.Length; i++)
                {
                    int num = (int)value[i];
                    if (num != 0 && num != 1)
                        return double.NaN;

                    res = BynaryCode.ShefferChar(res, num);
                }
                return res;
            };



            FuncOperator invertOr = AddOperator("Or");
            invertOr.GetFewNames().Add("||");
            invertOr.GetFewNames().Add("∨");
            invertOr.ReplaceWithAddSymwolFirst("Invert", "Invers", "`¬");
            invertOr.AddFewName("`↓");

            invertOr.BinarnPriority = 11;
            invertOr.BinarnFewPriority = 1;
            invertOr.PriorityToBinarn();
            invertOr.WorkOperator = true;
            invertOr.Appointment = "Поразрядный оператор \"Или-Не\" (Стрелка Пирса - \"Отрицание дизъюнкции\" или \"Инверсия дизъюнкции\")";
            invertOr.Description = "Применяет операцию ↓ к каждому двоичному разряду \n" +
                "a↓b = ¬(a∨b) = ((¬a)∧(¬b)) \n" +
                "0∨0=0; 0∨1=1; 1∨0=1; 1∨1=1   =>\n" +
                "0↓0=1; 0↓1=0; 1↓0=0; 1↓1=0 \n" +
                "a↓b = b↓a";
            invertOr.Doing = (value) =>
            {
                int res = (int)value[0];
                for (int i = 1; i < value.Length; i++)
                {
                    res = ~(res | HyperbolicFunctions.ToInt(value[i]));
                }
                return res;
            };


            FuncOperator invertOrB = AddOperator("Or");
            invertOrB.GetFewNames().Add("||");
            invertOrB.GetFewNames().Add("∨");
            invertOrB.ReplaceWithAddSymwolFirst("No", "¬");
            invertOrB.AddFewName("↓");

            invertOrB.BinarnPriority = 11;
            invertOrB.BinarnFewPriority = 1;
            invertOrB.PriorityToBinarn();
            invertOrB.WorkOperator = true;
            invertOrB.Appointment = "Логический оператор \"Или-Не\" (Стрелка Пирса - \"Отрицание дизъюнкции\" или \"Инверсия дизъюнкции\")";
            invertOrB.Description = "" +
                "a↓b = ¬(a∨b) = ((¬a)∧(¬b)) \n" +
                "0∨0=0; 0∨1=1; 1∨0=1; 1∨1=1   =>\n" +
                "0↓0=1; 0↓1=0; 1↓0=0; 1↓1=0 \n" +
                "a↓b = b↓a";
            invertOrB.Doing = (value) =>
            {
                //int res = 0;
                int res = (int)value[0];
                if (res != 0 && res != 1)
                    return double.NaN;
                for (int i = 1; i < value.Length; i++)
                {
                    int num = (int)value[i];
                    if (num != 0 && num != 1)
                        return double.NaN;

                    res = BynaryCode.PirsChar(res, num);
                }
                return res;
            };



            FuncNames invert = Add("Invert");
            //invert.SetPsevdoName(82);
            invert.GetFewNames().Add("Inversia");
            invert.GetFewNames().Add("Invers");
            invert.GetFewNames().Add("`¬");
            //invert.GetFewNames().Add("~");
            invert.Appointment = "Поразрядная инверсия (Поразрядное \"Не\")";
            invert.Description = "Инвертирует все двоичные разряды заданного числа \n" +
                "Изменение двоичных разрядов (Операция No к каждому разряду):  No(1)=0; No(0)=1";
            invert.Doing = (value) =>
            {
                int num = HyperbolicFunctions.ToInt(value[0]);
                return ~num;
            };

            FuncOperator and = AddOperator("And");
            and.GetFewNames().Add("&&");
            and.GetFewNames().Add("∧");
            and.BinarnPriority = 6;
            and.BinarnFewPriority = 1;

            and.UnarnPriority = 1;
            and.PriorityToBinarn();
            and.WorkOperator = true;
            and.Appointment = "Оператор \"И\" (Конъюнкция)";
            and.Description = "Если логическая: 0∧0=0; 0∧1=0; 1∧0=0; 1∧1=1 \n" +
                "Если поразрядная, то And применяется к каждому двоичному разряду";
            and.Doing = (value) =>
            {
                int res = -1;
                for (int i = 0; i < value.Length; i++)
                {
                    res = res & HyperbolicFunctions.ToInt(value[i]);
                }
                return res;
            };

            FuncOperator equivalention2 = AddOperator("EquivalentEqual");
            equivalention2.GetFewNames().Add("EquivalentionMath");
            equivalention2.GetFewNames().Add("EquivalentiaMath");
            equivalention2.GetFewNames().Add("EquivalentMath");
            equivalention2.GetFewNames().Add("≡");
            equivalention2.GetFewNames().Add("===");
            equivalention2.WorkOperator = true;
            equivalention2.BinarnFewPriority = 1;
            equivalention2.BinarnPriority = 9;
            equivalention2.PriorityToBinarn();
            equivalention2.Appointment = "Арифметическая эквиваленция";
            equivalention2.Description = "Сравнение: a===b = a==b \n" +
                "0↔0 = 1; 0↔1 = 1; 1↔0 = 0; 1↔1 = 1";
            equivalention2.FuncDoing = (value) =>
            {
                if (value.Length < 2)
                {
                    throw new FuncsOneArgumentExceptions(value[0], equivalention2);
                }
                return value[0] == value[1] ? 1 : 0;
            };

            FuncOperator equivalention1 = AddOperator("EquivalentionLog");
            equivalention1.GetFewNames().Add("EquivalentiaLog");
            equivalention1.GetFewNames().Add("EquivalentLog");
            equivalention1.GetFewNames().Add("↔");
            equivalention1.GetFewNames().Add("<->");
            equivalention1.ReplaceWithAddSymwolFirst("`");
            equivalention1.WorkOperator = true;
            equivalention1.BinarnFewPriority = 1;
            equivalention1.BinarnPriority = 10;
            equivalention1.PriorityToBinarn();
            equivalention1.Appointment = "Логическая эквиваленция (тогда и только тогда, когда)";
            equivalention1.Description = "Равносилие: a↔b = Or(And(No(a);No(b));And(a;b)) \n" +
                "0↔0 = 1; 0↔1 = 1; 1↔0 = 0; 1↔1 = 1";
            equivalention1.FuncDoing = (value) =>
            {
                int res = HyperbolicFunctions.ToInt(value[0]);
                for (int i = 1; i < value.Length; i++)
                {
                    res = HyperbolicFunctions.EquivalentionLog(res, HyperbolicFunctions.ToInt(value[i]));
                }

                return res;
            };

            equivalention1 = AddOperator("EquivalentionLog");
            equivalention1.GetFewNames().Add("EquivalentiaLog");
            equivalention1.GetFewNames().Add("EquivalentLog");
            equivalention1.GetFewNames().Add("↔");
            equivalention1.GetFewNames().Add("<->");
            equivalention1.WorkOperator = true;
            equivalention1.BinarnFewPriority = 1;
            equivalention1.BinarnPriority = 9;
            equivalention1.PriorityToBinarn();
            equivalention1.Appointment = "Логическая эквиваленция (тогда и только тогда, когда)";
            equivalention1.Description = "Равносилие: a↔b = Or(And(No(a);No(b));And(a;b)) \n" +
                "0↔0 = 1; 0↔1 = 1; 1↔0 = 0; 1↔1 = 1";
            equivalention1.FuncDoing = (value) =>
            {
                int res = HyperbolicFunctions.ToInt(value[0]);
                for (int i = 1; i < value.Length; i++)
                {
                    res = HyperbolicFunctions.EquivalentionLog(res, HyperbolicFunctions.ToInt(value[i]));
                }

                return res;
            };


            FuncOperator equivalention = AddOperator("Equivalention");
            equivalention.GetFewNames().Add("Equivalentia");
            equivalention.GetFewNames().Add("Equivalent");
            equivalention.GetFewNames().Add("⇔");
            equivalention.GetFewNames().Add("<==>");
            equivalention.ReplaceWithAddSymwolFirst("`");
            equivalention.WorkOperator = true;
            equivalention.BinarnFewPriority = 1;
            equivalention.BinarnPriority = 10;
            equivalention.PriorityToBinarn();
            equivalention.Appointment = "Поразрядная эквиваленция (тогда и только тогда, когда)";
            equivalention.Description = "Равносилие: a=>b = Or(And(Invers(a);Invers(b));And(a;b)) \n" +
                "Изменение двоичных разрядов (Операция ↔ к каждому разряду): 0↔0 = 1; 0↔1 = 1; 1↔0 = 0; 1↔1 = 1";
            equivalention.FuncDoing = (value) =>
            {
                int res = HyperbolicFunctions.ToInt(value[0]);
                for (int i = 1; i < value.Length; i++)
                {
                    res = HyperbolicFunctions.Equivalention(res, HyperbolicFunctions.ToInt(value[i]));
                }
                return res;
            };

            equivalention = AddOperator("Equivalention");
            equivalention.GetFewNames().Add("Equivalentia");
            equivalention.GetFewNames().Add("Equivalent");
            equivalention.GetFewNames().Add("⇔");
            equivalention.GetFewNames().Add("<==>");
            equivalention.WorkOperator = true;
            equivalention.BinarnFewPriority = 1;
            equivalention.BinarnPriority = 9;
            equivalention.PriorityToBinarn();
            equivalention.Appointment = "Поразрядная эквиваленция (тогда и только тогда, когда)";
            equivalention.Description = "Равносилие: a=>b = Or(And(Invers(a);Invers(b));And(a;b)) \n" +
                "Изменение двоичных разрядов (Операция ↔ к каждому разряду): 0↔0 = 1; 0↔1 = 1; 1↔0 = 0; 1↔1 = 1";
            equivalention.FuncDoing = (value) =>
            {
                int res = HyperbolicFunctions.ToInt(value[0]);
                for (int i = 1; i < value.Length; i++)
                {
                    res = HyperbolicFunctions.Equivalention(res, HyperbolicFunctions.ToInt(value[i]));
                }
                return res;
            };


            FuncOperator implication1 = AddOperator("ImplicationLog");
            implication1.GetFewNames().Add("ImplicateLog");
            implication1.GetFewNames().Add("ImplicatLog");
            implication1.GetFewNames().Add("→");
            implication1.GetFewNames().Add("==>");
            implication1.GetFewNames().Add("->");
            implication1.ReplaceWithAddSymwolFirst("`");
            implication1.WorkOperator = true;
            implication1.BinarnFewPriority = 1;
            implication1.BinarnPriority = 9;
            implication1.PriorityToBinarn();
            implication1.Appointment = "Логическая импликация (Если-то)";
            implication1.Description = "Следствие: a→b = Or(No(a);b) \n" +
                "0→0 = 1; 0→1 = 1; 1→0 = 0; 1→1 = 1";
            implication1.Doing = (value) =>
            {
                int res = HyperbolicFunctions.ToInt(value[0]);
                for (int i = 1; i < value.Length; i++)
                {
                    res = HyperbolicFunctions.ImplicationLog(res, HyperbolicFunctions.ToInt(value[i]));
                }
                return res;
            };

            implication1 = AddOperator("ImplicationLog");
            implication1.GetFewNames().Add("ImplicateLog");
            implication1.GetFewNames().Add("ImplicatLog");
            implication1.GetFewNames().Add("→");
            implication1.GetFewNames().Add("==>");
            implication1.GetFewNames().Add("->");
            implication1.WorkOperator = true;
            implication1.BinarnFewPriority = 1;
            implication1.BinarnPriority = 10;
            implication1.PriorityToBinarn();
            implication1.Appointment = "Логическая импликация (Если-то)";
            implication1.Description = "Следствие: a→b = Or(No(a);b) \n" +
                "0→0 = 1; 0→1 = 1; 1→0 = 0; 1→1 = 1";
            implication1.Doing = (value) =>
            {
                int res = HyperbolicFunctions.ToInt(value[0]);
                for (int i = 1; i < value.Length; i++)
                {
                    res = HyperbolicFunctions.ImplicationLog(res, HyperbolicFunctions.ToInt(value[i]));
                }
                return res;
            };

            FuncOperator implication = AddOperator("Implication");
            implication.GetFewNames().Add("Implicate");
            implication.GetFewNames().Add("Implicat");
            implication.GetFewNames().Add("=>");
            implication.ReplaceWithAddSymwolFirst("`");
            implication.WorkOperator = true;
            implication.BinarnFewPriority = 1;
            implication.BinarnPriority = 9;
            implication.PriorityToBinarn();
            implication.Appointment = "Поразрядная импликация (Если-то)";
            implication.Description = "Следствие: a=>b = Or(Invers(a);b) \n" +
                "Изменение двоичных разрядов (Операция → к каждому разряду): 0→0 = 1; 0→1 = 1; 1→0 = 0; 1→1 = 1";
            implication.Doing = (value) =>
            {
                int res = HyperbolicFunctions.ToInt(value[0]);
                for (int i = 1; i < value.Length; i++)
                {
                    res = HyperbolicFunctions.Implication(res, HyperbolicFunctions.ToInt(value[i]));
                }
                return res;
            };

            implication = AddOperator("Implication");
            implication.GetFewNames().Add("Implicate");
            implication.GetFewNames().Add("Implicat");
            implication.GetFewNames().Add("=>");
            implication.WorkOperator = true;
            implication.BinarnFewPriority = 1;
            implication.BinarnPriority = 10;
            implication.PriorityToBinarn();
            implication.Appointment = "Поразрядная импликация (Если-то)";
            implication.Description = "Следствие: a=>b = Or(Invers(a);b) \n" +
                "Изменение двоичных разрядов (Операция → к каждому разряду): 0→0 = 1; 0→1 = 1; 1→0 = 0; 1→1 = 1";
            implication.Doing = (value) =>
            {
                int res = HyperbolicFunctions.ToInt(value[0]);
                for (int i = 1; i < value.Length; i++)
                {
                    res = HyperbolicFunctions.Implication(res, HyperbolicFunctions.ToInt(value[i]));
                }
                return res;
            };

            FuncOperator xor2 = AddOperator("SumZhegalcin");
            xor2.GetFewNames().Add("SumZhegalcin");
            xor2.GetFewNames().Add("Zhegalcin");
            xor2.GetFewNames().Add("SumZhegalkin");
            xor2.GetFewNames().Add("Zhegalkin");
            xor2.GetFewNames().Add("!∨");
            xor2.GetFewNames().Add("!Or");
            xor2.GetFewNames().Add("`Xor");
            xor2.ReplaceWithAddSymwolFirst("`");
            xor2.AddFewName("SumModTwo");
            xor2.BinarnPriority = 5;
            xor2.BinarnFewPriority = 1;
            xor2.UnarnPriority = 3;
            xor2.PriorityToBinarn();
            xor2.WorkOperator = true;
            xor2.Appointment = "Сумма жегалкина; Исключающее \"Или\"; Сложение по модулю 2; Строгая дизъюнкция; Поразрядное дополнение; " +
                "Инвертирование по маске; Жегалкинское сложение; Логическое вычитание; Логическая неравнозна́чность";
            xor2.Description = "Если логическая операция: Xor(a;b) = No(a<->b) (Xor(a;a) = 0; Xor(a;No(a) = 1: Xor(0;0) = 0; Xor(0;1) = 1; Xor(1;0) = 1; Xor(1;1) = 0) \n" +
                "Если поразрядная, то Xor применяется к каждому двоичному разряду: Xor(a;b) = Invert(a<=>b)";
            xor2.Doing = (value) =>
            {
                int res = 0;
                for (int i = 0; i < value.Length; i++)
                {
                    res = res ^ HyperbolicFunctions.ToInt(value[i]);
                }
                return res;
            };

            FuncOperator xor1 = AddOperator("SumZhegalcin");
            xor1.GetFewNames().Add("SumZhegalcin");
            xor1.GetFewNames().Add("Zhegalcin");
            xor1.GetFewNames().Add("SumZhegalkin");
            xor1.GetFewNames().Add("Zhegalkin");
            xor1.GetFewNames().Add("!∨");
            xor1.GetFewNames().Add("!Or");
            xor1.GetFewNames().Add("`Xor");
            xor1.BinarnPriority = 7;
            xor1.BinarnFewPriority = 1;
            xor1.UnarnPriority = 3;
            xor1.PriorityToBinarn();
            xor1.WorkOperator = true;
            xor1.Appointment = "Сумма жегалкина; Исключающее \"Или\"; Сложение по модулю 2; Строгая дизъюнкция; Поразрядное дополнение; " +
                "Инвертирование по маске; Жегалкинское сложение; Логическое вычитание; Логическая неравнозна́чность";
            xor1.Description = "Если логическая операция: Xor(a;b) = No(a<->b) (Xor(a;a) = 0; Xor(a;No(a) = 1: Xor(0;0) = 0; Xor(0;1) = 1; Xor(1;0) = 1; Xor(1;1) = 0) \n" +
                "Если поразрядная, то Xor применяется к каждому двоичному разряду: Xor(a;b) = Invert(a<=>b)";
            xor1.Doing = (value) =>
            {
                int res = 0;
                for (int i = 0; i < value.Length; i++)
                {
                    res = res ^ HyperbolicFunctions.ToInt(value[i]);
                }
                return res;
            };

            FuncOperator xor = AddOperator("Xor");
            xor.GetFewNames().Add("⊕");
            xor.GetFewNames().Add("⊻");
            xor.BinarnPriority = 11;
            xor.BinarnFewPriority = 1;
            xor.UnarnPriority = 3;
            xor.PriorityToBinarn();
            xor.WorkOperator = true;
            xor.ImportSpecification(xor1);
            xor.Doing = (value) =>
            {
                int res = 0;
                for (int i = 0; i < value.Length; i++)
                {
                    res = res ^ HyperbolicFunctions.ToInt(value[i]);
                }
                return res;
            };

            FuncOperator or = AddOperator("Or");
            or.GetFewNames().Add("||");
            or.GetFewNames().Add("∨");
            or.BinarnPriority = 8;
            or.BinarnFewPriority = 1;
            or.PriorityToBinarn();
            or.WorkOperator = true;
            or.Appointment = "Оператор \"Или\" (Дизъюнкция)";
            or.Description = "Если логическая: 0∨0=0; 0∨1=0; 1∨0=0; 1∨1=1 \n" +
                "Если поразрядная, то Or применяется к каждому двоичному разряду";
            or.Doing = (value) =>
            {
                int res = 0;
                for (int i = 0; i < value.Length; i++)
                {
                    res = res | HyperbolicFunctions.ToInt(value[i]);
                }
                return res;
            };


            FuncNames ln = Add();
            ln.SetName("Ln");
            ln.Appointment = "Натуральный логарифм";
            ln.Description = "Логарифм по основанию E";
            ln.FuncDoing = (value) =>
            {
                double number = value[0];
                if (number <= 0)
                    return double.NaN;
                return Math.Log(number);
            };

            FuncNames lg = Add();
            lg.SetName("Lg");
            lg.Appointment = "Десятичный логарифм";
            lg.Description = "Логарифм по основанию 10";
            lg.FuncDoing = (value) =>
            {
                double number = value[0];
                if (number <= 0)
                    return double.NaN;
                return Math.Log10(number);
            };

            FuncNames log = Add();
            log.SetName("Log");
            log.Appointment = "Логарифм Log(a;b)=(a)Log(b)=(a;b)Log";
            log.Description = "Логарифм из числа b по основанию a";
            log.FuncDoing = (value) =>
            {
                double a = value[0];
                double b = value[1];
                if (a <= 0 || a == 1)
                    return double.NaN;
                else if (b <= 0)
                    return double.NaN;
                return Math.Log(b, a);
            };

            FuncOperator inc = AddWorkOperator("Increment");
            inc.AddFewName("Incriment");
            inc.AddFewName("Inc");
            inc.Appointment = "Инкримент";
            inc.Description = "Увеличение числа на единицу";
            inc.AddNamesByReplace("c", "k");
            inc.AddFewName("++");

            inc.FuncDoing = (value) => value[0] + 1;

            FuncOperator dec = AddWorkOperator("Decrement");
            dec.AddFewName("Decriment");
            dec.AddFewName("Dec");
            dec.AddNamesByReplace("c", "k");
            dec.AddFewName("--");
            dec.Appointment = "Декримент";
            dec.Description = "Уменьшение числа на единицу";
            dec.FuncDoing = (value) => value[0] - 1;

            FuncNames grad = Add();
            grad.SetName("Gradus");
            grad.GetFewNames().Add("Grad");
            grad.Appointment = "Градус";
            grad.Description = "Перевод изменения угла из радианной меры в градусную";
            grad.FuncDoing = (value) => value[0] * 360 / (2 * Math.PI);

            FuncNames rad = Add();
            rad.SetName("Radian");
            rad.GetFewNames().Add("Rad");
            rad.Appointment = "Радиан (вызов функции"+degToRad.GetName()+")";
            rad.Description = "Перевод изменения угла из градусной меры в радианную \n"+
                "Вызывает функцию "+degToRad.GetName()+", а именно "+degToRad.Description;
            //rad.FuncDoing = (value) => value[0] * 2 * Math.PI / 360;
            rad.FuncDoing = (value) => degToRad.FuncDoingInvoke(value);

            FuncNames sqrtE = Add();
            sqrtE.SetName("sqrtExpend");
            sqrtE.SetPsevdoName(74);
            sqrtE.GetFewNames().Add("SqrtE");
            sqrtE.GetFewNames().Add("√");
            sqrtE.GetFewNames().Add("✓");
            sqrtE.Appointment = "Квадратный корень или корень в степени";
            sqrtE.Description = "Если 1 аргумент, то вычисляет квадратный корень из этого аргумента \n" +
                "В противном случае, вычисляет из последнего аргумента корень в степени, равной произведению всех предшедствующих аргументов";
            sqrtE.Doing = (value) =>
            {
                int length = value.Length;
                double number = value[length - 1];
                double stepenN = 1;
                if (length < 2)
                    stepenN = 2;
                else
                {
                    for (int i = 0; i < length - 1; i++)
                    {
                        stepenN *= value[i];
                    }
                }

                return HyperbolicFunctions.Sqrt(number, stepenN);
            };


            FuncNames sqrtPI = Add();
            sqrtPI.SetName("sqrt");
            sqrtPI.SetPsevdoName(8);
            sqrtPI.Appointment = "Квадратный корень или корень в степени из числа, умноженного на PI";
            sqrtPI.Description = "Если 1 аргумент, то вычисляет квадратный корень из этого аргумента, умноженного на число-PI \n" +
                "В противном случае, вычисляет из первого аргумента, умноженного на число-PI, корень в степени, равной произведению всех последующих аргументов";

            FuncNames sqrt = Add();
            sqrt.SetName("sqrt");
            sqrt.SetPsevdoName(8);
            sqrt.Appointment = "Квадратный корень или корень в степени";
            sqrt.Description = "Если 1 аргумент, то вычисляет квадратный корень из этого аргумента \n" +
                "В противном случае, вычисляет из первого аргумента корень в степени, равной произведению всех последующих аргументов";
            sqrt.Doing = (value) =>
            {
                int length = value.Length;
                double number = value[0];
                double stepenN = 1;
                if (length < 2)
                    stepenN = 2;
                else
                {
                    for (int i = 1; i < length; i++)
                    {
                        stepenN *= value[i];
                    }
                }

                return HyperbolicFunctions.Sqrt(number, stepenN);
            };

            sqrtPI.FuncDoing = (value) =>
            {
                List<double> numbers = new List<double>(value);
                numbers[0] = numbers[0] * Math.PI;
                return sqrt.FuncDoingInvoke(numbers.ToArray());
            };

            FuncNames sqr = Add();
            sqr.SetName("sqr");
            sqr.SetPsevdoName(9);
            sqr.Doing = (value) => HyperbolicFunctions.Sqr(value[0]);

            FuncNames cbrt = Add();
            cbrt.SetName("Cbrt");
            cbrt.SetPsevdoName(73);
            cbrt.Doing = (value) =>
            {
                double num = value[0];

                return Math.Pow(num, 1 / 3.0);
            };

            FuncNames kub = Add();
            kub.SetName("kube");
            kub.SetPsevdoName(59);
            List<string> listKube = kub.GetFewNames();
            listKube.AddRange(new string[] { "Kube", "Kub", "Cube", "Cub", "Cbr" });
            kub.Doing = (value) => HyperbolicFunctions.Kub(value[0]);




            FuncOperator noequals = AddOperator("NoEquuls");
            noequals.SetPsevdoName(77);
            list = noequals.GetFewNames();
            list.Add("NoEquals");
            list.Add("<>");
            list.Add("!=");
            list.Add("≠");
            noequals.BinarnFewPriority = 1;
            noequals.BinarnPriority = 4;
            noequals.PriorityToBinarn();
            noequals.WorkOperator = true;
            noequals.Doing = (value) =>
            {
                if (value.Length < 2)
                {
                    throw new FuncsOneArgumentExceptions(value[0], noequals);
                }
                return value[0] != value[1] ? 1 : 0;
            };


            FuncNames factorial = Add();
            factorial.SetName("Factorial");
            factorial.SetPsevdoName(61);
            List<string> listFactorial = factorial.GetFewNames();
            listFactorial.AddRange(new string[] { "Fact", "Faktorial", "Fakt", "!" });
            factorial.Doing = (value) =>
            {
                int length = value.Length;
                double number = value[0];
                if (length < 2)
                    return HyperbolicFunctions.Factorial(number);
                else
                    return HyperbolicFunctions.Factorial(number, value[1]);

            };


            FuncNames promileRet = Add("promileRet");
            list = promileRet.GetFewNames();
            list.Add("promileRet");
            promileRet.SetPsevdoName(67);
            promileRet.Description = "Процентное соотношение между первым и вторым числом *второе число по умолчанию - 1)";
            promileRet.Doing = (value) =>
            {
                //double result = 1;
                int length = value.Length;
                double number1 = value[0];
                double number2 = length > 1 ? value[1] : 1;
                if (number2 == 0)
                    throw new ArithmeticException();

                return (number1 / number2) * 1000;
            };

            FuncNames promile = Add("promile");
            list = promile.GetFewNames();
            list.Add("promile");
            promile.SetPsevdoName(68);
            promile.Description = "Промиль - одна тысячная часть произведения всех чисел";
            promile.Doing = (value) =>
            {
                double result = 1;
                int length = value.Length;
                for (int i = 0; i < length; i++)
                {
                    result *= value[i];
                }
                return result / 1000;
            };

            FuncOperator promile1 = AddOperator("%%");
            list = promile1.GetFewNames();
            //list.Add("promile");
            list.Add("‰");
            list.Add("‰");
            promile1.SetPsevdoName(69);
            promile1.UnarnFewPriority = 4;
            //promile1.BinarnFewPriority = 4;
            promile1.BinarnFewPriority = 2;
            promile1.UnarnFewPriority = 4;
            promile1.UnarnPriority = 0;
            promile1.BinarnPriority = 0;
            promile1.WorkOperator = true;
            promile1.Description = "Промиль - одна тысячная часть произведения всех чисел";
            promile1.AllowReal = false;
            promile1.Doing = (value) =>
            {

                throw new NumCalcException(value[0] / 1000);
            };

            FuncNames persentRet = Add("PersentRet");
            list = persentRet.GetFewNames();
            list.Add("persentRet");
            list.Add("procentRet");
            list.Add("procRet");
            persentRet.SetPsevdoName(66);
            persentRet.Description = "Процентное соотношение между первым и вторым числом *второе число по умолчанию - 1)";
            persentRet.Doing = (value) =>
            {
                //double result = 1;
                int length = value.Length;
                double number1 = value[0];
                double number2 = length > 1 ? value[1] : 1;
                if (number2 == 0)
                    throw new ArithmeticException();

                return (number1 / number2) * 100;
            };

            FuncNames persent = Add("Persent");
            list = persent.GetFewNames();
            list.Add("persent");
            list.Add("procent");
            list.Add("proc");
            persent.SetPsevdoName(65);
            persent.Description = "Процент - одна сотая часть произведения всех чисел";
            persent.Doing = (value) =>
            {
                double result = 1;
                int length = value.Length;
                for (int i = 0; i < length; i++)
                {
                    result *= value[i];
                }
                return result / 100;
            };


            FuncNames ret = Add("Reverse");
            List<string> retList = ret.GetFewNames();
            retList.Add("revers");
            retList.Add("reverze");
            retList.Add("reverz");
            retList.Add("return");
            retList.Add("ret");
            ret.SetPsevdoName(60);
            ret.Doing = (value) =>
            {
                int length = value.Length;
                double result = 1.0;

                for (int i = 0; i < length; i++)
                {
                    double b = value[i];
                    if (b == 0)
                        throw new Exception();
                    result /= b;
                }

                return result;
            };

            FuncNames abs = Add();
            abs.SetName("abs");
            Abs = abs.GetMName();
            abs.Appointment = "Модуль";
            abs.Description = "Модуль из среднего арифметического всех аргументов";
            //abs.Doing = (value) => HyperbolicFunctions.Abs(value[0]);
            abs.FuncDoing = (value) =>
                {
                    int length = value.Length;
                    double sum = 0;
                    for (int i = 0; i < length; i++)
                    {
                        sum += value[i];
                    }
                    return Math.Abs(sum / length);
                };
            absFunc = abs;

            // Случайное вещественное число
            FuncNames rand1 = Add();
            rand1.SetName("RandowDouble");
            rand1.GetFewNames().Add("RandomDouble");
            rand1.GetFewNames().Add("RandDouble");
            rand1.GetFewNames().Add("RandowReal");
            rand1.GetFewNames().Add("RandomReal");
            rand1.GetFewNames().Add("RandReal");
            rand1.SetPsevdoName(31);
            rand1.Doing = (value) =>
                {
                    try
                    {
                        return HyperbolicFunctions.Random(value[0], value[1]);
                    }
                    catch
                    {
                        return HyperbolicFunctions.Random(0, value[0]);
                    }
                };


            // Случайное вещественное число
            FuncNames rand2 = Add();
            rand2.SetName("RandowMass");
            rand2.GetFewNames().Add("RandomMass");
            rand2.GetFewNames().Add("RandowMass");
            rand2.GetFewNames().Add("RandMass");
            rand2.GetFewNames().Add("RandowArray");
            rand2.GetFewNames().Add("RandomArray");
            rand2.GetFewNames().Add("RandArray");
            rand2.GetFewNames().Add("RandowAray");
            rand2.GetFewNames().Add("RandomAray");
            rand2.GetFewNames().Add("RandAray");
            rand2.GetFewNames().Add("RandowArr");
            rand2.GetFewNames().Add("RandomArr");
            rand2.GetFewNames().Add("RandArr");
            rand2.SetPsevdoName(45);
            rand2.Doing = (value) =>
            {
                int last = value.Length - 1;
                int id = (int)HyperbolicFunctions.Random(0, last);

                return value[id];
            };

            // Случайное целое число
            FuncNames rand = Add();
            rand.SetName("RandowInt");
            rand.GetFewNames().Add("RandomInt");
            rand.GetFewNames().Add("RandInt");
            rand.GetFewNames().Add("Randow");
            rand.GetFewNames().Add("Random");
            rand.GetFewNames().Add("Rand");
            rand.SetPsevdoName(32);
            rand.Doing = (value) =>
                {
                    try
                    {
                        return HyperbolicFunctions.RandomInt(value[0], value[1]);
                    }
                    catch
                    {
                        return HyperbolicFunctions.RandomInt(0, value[0]);
                    }
                };


            FuncNames sgn = Add();
            sgn.SetName("sgn");
            sgn.SetPsevdoName(10);
            sgn.Doing = (value) => HyperbolicFunctions.Sgn(value[0]);


            FuncNames arccosech = Add();
            arccosech.SetName("arccosech");
            arccosech.GetFewNames().Add("arcsch");
            arccosech.GetFewNames().Add("acosech");
            arccosech.SetPsevdoName(50);
            arccosech.Doing = (value) => HyperbolicFunctions.ArcCsch(value[0]);

            FuncNames arcsech = Add();
            arcsech.SetName("arcsech");
            arcsech.GetFewNames().Add("arsch");
            arcsech.GetFewNames().Add("asech");
            arcsech.SetPsevdoName(51);
            arcsech.Doing = (value) => HyperbolicFunctions.ArSch(value[0]);

            FuncNames arccosh = Add();
            arccosh.SetName("arccosinh");
            arccosh.GetFewNames().Add("arch");
            arccosh.GetFewNames().Add("arccosh");
            arccosh.GetFewNames().Add("acosinh");
            arccosh.GetFewNames().Add("acosh");
            arccosh.SetPsevdoName(52);
            arccosh.Doing = (value) => HyperbolicFunctions.ArCh(value[0]);

            FuncNames arcsinh = Add();
            arcsinh.SetName("arcsinh");
            arcsinh.GetFewNames().Add("arsh");
            arcsinh.GetFewNames().Add("asinh");
            arcsinh.SetPsevdoName(53);
            arcsinh.Doing = (value) => HyperbolicFunctions.ArSh(value[0]);

            FuncNames arcctgh = Add();
            arcctgh.SetName("arcctgh");
            arcctgh.GetFewNames().Add("arcth");
            arcctgh.GetFewNames().Add("arcctanh");
            arcctgh.GetFewNames().Add("arccotanh");
            arcctgh.GetFewNames().Add("arccotgh");
            arcctgh.GetFewNames().Add("arccoth");
            arcctgh.GetFewNames().Add("actgh");
            arcctgh.GetFewNames().Add("actanh");
            arcctgh.GetFewNames().Add("acotanh");
            arcctgh.GetFewNames().Add("acotgh");
            arcctgh.GetFewNames().Add("acoth");
            arcctgh.SetPsevdoName(54);
            arcctgh.Doing = (value) => HyperbolicFunctions.ArCth(value[0]);

            FuncNames arctgh = Add();
            arctgh.SetName("arctgh");
            arctgh.GetFewNames().Add("arth");
            arctgh.GetFewNames().Add("arctanh");
            arctgh.GetFewNames().Add("atgh");
            arctgh.GetFewNames().Add("atanh");
            arctgh.SetPsevdoName(55);
            arctgh.Doing = (value) => HyperbolicFunctions.ArTh(value[0]);

            FuncNames cosech = Add();
            cosech.SetName("cosech");
            cosech.GetFewNames().Add("csch");
            cosech.SetPsevdoName(48);
            cosech.Doing = (value) => HyperbolicFunctions.Sch(value[0]);

            FuncNames sech = Add();
            sech.SetName("sech");
            sech.GetFewNames().Add("sch");
            sech.SetPsevdoName(49);
            sech.Doing = (value) => HyperbolicFunctions.Csch(value[0]);


            FuncNames ch = Add();
            ch.SetName("ch");
            ch.GetFewNames().Add("cosh");
            ch.GetFewNames().Add("cosinh");
            ch.SetPsevdoName(16);
            ch.Doing = (value) => HyperbolicFunctions.Ch(value[0]);

            FuncNames sh = Add();
            sh.SetName("sh");
            sh.GetFewNames().Add("sinh");
            sh.SetPsevdoName(17);
            sh.Doing = (value) => HyperbolicFunctions.Sh(value[0]);

            FuncNames cth = Add();
            cth.SetName("cotanh");
            cth.GetFewNames().Add("cotanh");
            cth.GetFewNames().Add("ctanh");
            cth.GetFewNames().Add("ctgh");
            cth.GetFewNames().Add("cotgh");
            cth.GetFewNames().Add("cth");
            cth.GetFewNames().Add("coth");
            cth.SetPsevdoName(18);
            cth.Doing = (value) => HyperbolicFunctions.Cth(value[0]);

            FuncNames th = Add();
            th.SetName("th");
            th.GetFewNames().Add("tgh");
            th.GetFewNames().Add("tanh");
            th.SetPsevdoName(19);
            th.Doing = (value) => HyperbolicFunctions.Th(value[0]);

            FuncNames arccosec = Add();
            arccosec.SetName("arccosec");
            arccosec.GetFewNames().Add("arccosec");
            arccosec.GetFewNames().Add("acosec");
            arccosec.SetPsevdoName(33);
            arccosec.Doing = (value) => UgolsConverter.ArccosecRad(value[0]);

            FuncNames cosec = Add();
            cosec.SetName("cosec");
            cosec.GetFewNames().Add("cosec");
            cosec.SetPsevdoName(28);
            cosec.Doing = (value) => UgolsConverter.CosecRad(value[0]);

            FuncNames arcsec = Add();
            arcsec.SetName("arcsec");
            arcsec.GetFewNames().Add("arcsec");
            arcsec.GetFewNames().Add("asec");
            arcsec.SetPsevdoName(34);
            arcsec.Doing = (value) => UgolsConverter.ArcsecRad(value[0]);

            FuncNames sec = Add();
            sec.SetName("sec");
            sec.GetFewNames().Add("sec");
            sec.SetPsevdoName(29);
            sec.Doing = (value) => UgolsConverter.SecRad(value[0]);

            // Возведение в степень
            FuncOperator pow = AddOperator();
            pow.SetName("Power");
            pow.GetFewNames().Add("Pow");
            pow.GetFewNames().Add("Pover");
            pow.GetFewNames().Add("Pov");
            pow.GetFewNames().Add("^");
            pow.WorkOperator = true;
            pow.BinarnFewPriority = 3;
            pow.BinarnPriority = -1;
            pow.PriorityToBinarn();
            pow.Appointment = "Возведение в степень";
            pow.Description = "Возводит 1-ый аргумент в степень, равную произведению всех последующих чисел. \n" +
                "Если аргумент всего один, то он возводится в квадрат";
            pow.Doing = (value) =>
            {
                int length = value.Length;
                double number = value[0];
                double stepenN = 1;
                if (length < 2)
                    stepenN = 2;
                else
                {
                    for (int i = 1; i < length; i++)
                    {
                        stepenN *= value[i];
                    }
                }
                return HyperbolicFunctions.Pow(number, stepenN);
                //return HyperbolicFunctions.Pow(value[0], value[1]);
            };
            pow.SetHaveInt().FuncDoingInt = (value) =>
            {
                int length = value.Length;
                int number = value[0];
                int stepenN = 1;
                if (length < 2)
                    stepenN = 2;
                else
                {
                    for (int i = 1; i < length; i++)
                    {
                        stepenN *= value[i];
                    }
                }
                return HyperbolicFunctions.PowInt(number, stepenN);
            };
            inc.SetPriorityByFewOperator(pow);
            dec.SetPriorityByFewOperator(pow);



            FuncNames arccos = Add();
            arccos.SetName("arccosin");
            arccos.GetFewNames().Add("arccosin");
            arccos.GetFewNames().Add("arccos");
            arccos.GetFewNames().Add("acosin");
            arccos.GetFewNames().Add("acos");
            arccos.SetPsevdoName(35);
            arccos.Doing = (value) => UgolsConverter.ArccosRad(value[0]);

            FuncNames cos = Add();
            cos.SetName("cosin");
            cos.GetFewNames().Add("cos");
            cos.SetPsevdoName(12);
            cos.Doing = (value) => UgolsConverter.CosRad(value[0]);

            FuncNames arcsin = Add();
            arcsin.SetName("arcsin");
            arcsin.GetFewNames().Add("arcsin");
            arcsin.GetFewNames().Add("asin");
            arcsin.SetPsevdoName(36);
            arcsin.Doing = (value) => UgolsConverter.ArcsinRad(value[0]);

            FuncNames sin = Add();
            sin.SetName("sin");
            sin.SetPsevdoName(13);
            sin.Doing = (value) => UgolsConverter.SinRad(value[0]);

            FuncNames arcctg = Add();
            arcctg.SetName("arcctg");
            arcctg.GetFewNames().Add("arcctg");
            arcctg.GetFewNames().Add("arcctan");
            arcctg.GetFewNames().Add("arccotan");
            arcctg.GetFewNames().Add("arccotg");
            arcctg.GetFewNames().Add("arccot");
            arcctg.GetFewNames().Add("actg");
            arcctg.GetFewNames().Add("actan");
            arcctg.GetFewNames().Add("acotan");
            arcctg.GetFewNames().Add("acotg");
            arcctg.GetFewNames().Add("acot");
            arcctg.SetPsevdoName(37);
            arcctg.Doing = (value) => UgolsConverter.ArcctgRad(value[0]);

            FuncNames arctg = Add();
            arctg.SetName("arctg");
            arctg.GetFewNames().Add("arctg");
            arctg.GetFewNames().Add("arctan");
            arctg.GetFewNames().Add("atg");
            arctg.GetFewNames().Add("atan");
            arctg.SetPsevdoName(38);
            arctg.Doing = (value) => UgolsConverter.ArctgRad(value[0]);


            FuncNames ctg = Add();
            ctg.SetName("ctg");
            ctg.GetFewNames().Add("ctan");
            ctg.GetFewNames().Add("cotan");
            ctg.GetFewNames().Add("cotg");
            ctg.GetFewNames().Add("cot");
            ctg.SetPsevdoName(14);
            ctg.Doing = (value) => UgolsConverter.CtgRad(value[0]);

            FuncNames tg = Add();
            tg.SetName("tg");
            tg.GetFewNames().Add("tan");
            tg.SetPsevdoName(15);
            tg.Doing = (value) => UgolsConverter.TgRad(value[0]);

            FuncNames ceil = Add();
            ceil.SetName("Ceiling");
            ceil.GetFewNames().Add("Ceil");
            ceil.Appointment = "Округление до наименьшего целого в большую сторону";
            ceil.Description = "Возвращает наименьшее целое число, которое больше или равно указанному числу.";
            ceil.FuncDoing = (value) =>
            {
                double num = value[0];

                return Math.Ceiling(num);
            };

            FuncNames floor = Add();
            floor.SetName("Floor");
            floor.Appointment = "Округление до наибольшего целого в меньшую сторону";
            floor.Description = "Возвращает наибольшее целое число, которое меньше или равно заданному числу.";
            floor.FuncDoing = (value) =>
            {
                double num = value[0];

                return Math.Floor(num);
            };


            FuncNames roundExp = Add();
            roundExp.SetName("AroundExp");
            list = roundExp.GetFewNames();
            list.Add("RoundExp");
            roundExp.Appointment = "Округление в экспоненциальной форме";
            roundExp.Description = "Округляет 1-ое число до количества знаков в экспоненциальной форме, указанного вторым числом (по-умолчанию 0)";
            roundExp.FuncDoing = (value) =>
            {
                double num = value[0];

                try
                {
                    return HyperbolicFunctions.RoundExp(num, (int)value[1]);
                }
                catch
                {
                    return HyperbolicFunctions.RoundExp(num);
                }
            };


            FuncNames exp = Add();
            exp.SetName("Exp");
            exp.SetPsevdoName(20);
            exp.Appointment = "Экспонетнта числа или экспоненциальная форма записи числа";
            exp.Description = "Если нет аргуметов, то число E; \n" +
                "Если аргумент 1, то експонента этого числа (возведение числа e в степень, равную этому аргументу: exp(n) = e^n);" +
                "В остальных случаях экспоненциальная запись числа: (a)E(b), где a - 1-ый аргумент, а b - сумма остальных аргументов";
            exp.FuncDoing = (value) =>
            {
                if (value.Length == 0)
                {
                    return Math.E;
                }
                if (value.Length == 1)
                    return Math.Pow(Math.E, (value[0]));
                else
                {
                    double num = value[0];
                    double sum = 0;
                    for (int i = 1; i < value.Length; i++)
                    {
                        sum += value[i];
                    }
                    return num * Math.Pow(10, sum);
                }
            };
            this.exp = exp;


            FuncOperator divInt = AddWorkOperator();
            divInt.SetName("divisionInt");
            list = divInt.GetFewNames();
            list.Add("degreeInt");
            list.Add("segmentationInt");
            list.Add("segmentInt");
            list.Add("divInt");
            list.Add("delenieInt");
            list.Add("delenInt");
            divInt.SetPsevdoName(63);
            divInt.BinarnFewPriority = 2;
            divInt.BinarnPriority = 0;
            divInt.PriorityToBinarn();
            divInt.Appointment = "Целочисленное деление";
            divInt.Description = "Делит целочисленно 1-ый аргумент на 2-ой";
            divInt.FuncDoing = (value) =>
            {
                int number2 = HyperbolicFunctions.ToInt(value[1]);
                if (number2 == 0)
                {
                    return double.NaN; ;
                }
                int result = HyperbolicFunctions.ToInt(value[0]) / number2;
                return result;

            };

            FuncOperator mod = AddOperator();
            mod.SetName("Modulo");
            list = mod.GetFewNames();
            list.Add("Mod");
            list.Add("%");
            mod.SetPsevdoName(64);
            mod.BinarnFewPriority = 2;
            mod.UnarnFewPriority = 4;
            mod.UnarnPriority = 0;
            mod.BinarnPriority = 0;
            mod.WorkOperator = true;
            mod.AllowReal = false;
            mod.Appointment = "Остаток от целочисленного деления, или процент";
            mod.Description = "Если 2 аргумента, то останок от целочисленного деления 1-ого на 2-ой;\n" +
                "Если 1 аргумент, то процент (деление на 100), но с нюансом:" +
                "Пусть a и b - произвольные числа, тогда a+b% = a+(a*b/100), a-b% = a-(a*b/100), a+(b%) = a+b/100, a-(b%) = a-b/100";
            mod.Doing = (value) =>
            {
                if (value.Length < 2)
                {
                    throw new NumCalcException(value[0] / 100);
                }
                int number2 = HyperbolicFunctions.ToInt(value[1]);
                if (number2 == 0)
                {
                    return double.NaN;
                }
                int result = HyperbolicFunctions.ToInt(value[0]) % number2;
                return result;

            };


            FuncNames trancate = Add();
            trancate.SetName("Trancate");
            list = trancate.GetFewNames();
            list.Add("Tran");
            list.Add("Integer");
            list.Add("Int");
            trancate.Appointment = "Возврат целой части числа";
            trancate.Description = "Возвращает целую часть указанного числа";
            trancate.Doing = (value) =>
                {
                    string number = value[0].ToString();
                    try
                    {
                        return double.Parse(number.Split(new char[] { '.', ',' })[0]);
                    }
                    catch
                    {
                        return 0;
                    }
                };

            FuncNames drob = Add();
            drob.SetName("Drobe");
            list = drob.GetFewNames();
            list.Add("Drob");
            drob.Appointment = "Возврат дробной части числа";
            drob.Description = "Возвращает дробную часть указанного числа";
            drob.Doing = (value) =>
            {
                double num = value[0];
                string number = num.ToString();
                try
                {
                    return double.Parse("0," + number.Split(new char[] { '.', ',' })[1]) * HyperbolicFunctions.Sgn(num);
                }
                catch
                {
                    return 0;
                }
            };

            FuncNames round = Add();
            round.SetName("Around");
            list = round.GetFewNames();
            list.Add("Round");
            round.Appointment = "Округление числа";
            round.Description = "Округляет 1-ое число до количества знаков, указанного 2-ым числом (по умолчанию 0)";
            round.Doing = (value) =>
            {
                double num = value[0];

                try
                {
                    return Math.Round(num, (int)value[1]);
                }
                catch
                {
                    return Math.Round(num);
                }
            };

            FuncNames avgG = Add();
            avgG.SetName("average");
            list = avgG.GetFewNames();
            list.Add("awerage");
            list.Add("avg");
            list.Add("awg");
            list.Add("middle");
            list.Add("mean");
            avgG = avgG.ReplaceWithAddSymwolLast("G");
            avgG.Appointment = "Среднее-геометрическое";
            avgG.Description = "Переумножает все аргументы, из результата извлекает корень в степени, равной количеству аргументов";
            avgG.FuncDoing = (value) =>
            {
                double middle = 1;
                int length = value.Length;
                for (int i = 0; i < length; i++)
                {
                    middle *= value[i];
                }
                return HyperbolicFunctions.Sqrt(middle, length);
            };

            FuncNames avgH = Add();
            avgH.SetName("average");
            list = avgH.GetFewNames();
            list.Add("awerage");
            list.Add("avg");
            list.Add("awg");
            list.Add("middle");
            list.Add("mean");
            avgH = avgH.ReplaceWithAddSymwolLast("H");
            avgH.Appointment = "Среднее-гармоническое";
            avgH.Description = "Складывает обратные числа всем аргументам и на результат делит их количество";
            avgH.FuncDoing = (value) =>
            {
                double middle = 0;
                int length = value.Length;
                for (int i = 0; i < length; i++)
                {
                    double number = value[i];
                    if (number == 0)
                        return double.NaN;
                    middle += 1 / number;
                }
                if (middle == 0)
                    return Double.NaN;
                return length / middle;
            };

            FuncNames avgS = Add();
            avgS.SetName("average");
            list = avgS.GetFewNames();
            list.Add("awerage");
            list.Add("avg");
            list.Add("awg");
            list.Add("middle");
            list.Add("mean");
            avgS = avgS.ReplaceWithAddSymwolLast("S");
            avgS.Appointment = "Среднее-квадратическое";
            avgS.Description = "Складывает квадраты всех аргументов и делит на их количество, и из результата извлекает квадратный корень";
            avgS.FuncDoing = (value) =>
            {
                double middle = 0;
                int length = value.Length;
                for (int i = 0; i < length; i++)
                {
                    double number = value[i];

                    middle += number * number;
                }
                middle /= length;
                return HyperbolicFunctions.Sqrt(middle);
            };

            FuncNames avg = Add();
            avg.SetName("average");
            list = avg.GetFewNames();
            list.Add("awerage");
            list.Add("avg");
            list.Add("awg");
            list.Add("middle");
            list.Add("mean");
            avg = avg.InsertWithAddSymwolLast("A");
            avg.Appointment = "Среднее-арифметическое";
            avg.Description = "Складывает все аргументы и делит на их количество";
            avg.FuncDoing = (value) =>
            {
                double middle = 0;
                int length = value.Length;
                for (int i = 0; i < length; i++)
                {
                    middle += value[i];
                }
                return middle / length;
            };

            FuncNames max = Add();
            max.SetName("maximum");
            list = max.GetFewNames();
            list.Add("max");
            max.SetPsevdoName(25);
            max.Doing = (value) =>
            {
                int length = value.Length;
                double max1 = value[0];
                for (int i = 1; i < length; i++)
                {
                    max1 = Math.Max(max1, value[i]);
                }
                return max1;
            };

            FuncNames min = Add();
            min.SetName("minimum");
            list = min.GetFewNames();
            list.Add("min");
            min.SetPsevdoName(26);
            min.Doing = (value) =>
            {
                int length = value.Length;
                double max1 = value[0];
                for (int i = 1; i < length; i++)
                {
                    max1 = Math.Min(max1, value[i]);
                }
                return max1;
            };

            FuncNames r = Add();
            r.SetName("razmah");
            list = r.GetFewNames();
            list.Add("rasmah");
            list.Add("r");
            r.Appointment = "Размах";
            r.Description = "Размах чисел в массиве - разница между максимальным и минимальным числов в массиве";
            r.FuncDoing = (value) =>
            {
                int length = value.Length;
                double max1 = value[0];
                double min1 = max1;
                for (int i = 1; i < length; i++)
                {
                    max1 = Math.Max(max1, value[i]);
                    min1 = Math.Min(min1, value[i]);
                }
                return Math.Abs(max1 - min1);
                /*
                double first = value[0];
                double second = value[1];
                double min1 = Math.Min(first, second);
                double max1 = Math.Max(first, second);
                return Math.Abs(max1 - min1);
                */
            };

            FuncNames addIf = Add();
            addIf.SetName("additionIf");
            list = addIf.GetFewNames();
            list.Add("addIf");
            list.Add("aditionIf");
            list.Add("slozhenieIf"); ;
            list.Add("slozhIf"); ;
            list.Add("slozIf"); ;
            list.Add("slogIf");
            list.Add("plusIf");
            list.Add("sumaIf");
            list.Add("summaIf");
            list.Add("summIf");
            list.Add("sumIf");
            addIf.SetPsevdoName(57);
            addIf.Doing = (value) =>
            {
                int length = value.Length;
                double sum = 0;
                double number = value[0];
                for (int i = 1; i < length; i++)
                {
                    double item = value[i];
                    if (item == number)
                        sum += item;
                }
                return sum;
            };

            FuncOperator add = AddOperator();
            add.SetName("Addition");
            list = add.GetFewNames();
            list.Add("Add");
            list.Add("Adition");
            list.Add("Slozhenie"); ;
            list.Add("Slozh"); ;
            list.Add("Sloz"); ;
            list.Add("Slog");
            list.Add("Plus");
            list.Add("Suma");
            list.Add("Summa");
            list.Add("Summ");
            list.Add("Sum");
            list.Add("+");
            add.WorkOperator = true;
            add.BinarnFewPriority = 1;
            add.BinarnPriority = 0;
            add.UnarnFewPriority = 7;
            add.UnarnPriority = 0;
            add.ProcentInput = true;
            add.Appointment = "Сумма (сложение)";
            add.Description = "Возвращает сумму всех аргументов";
            add.Doing = (value) =>
            {
                int length = value.Length;
                double sum = 0;
                for (int i = 0; i < length; i++)
                {
                    sum += value[i];
                }
                return sum;
            };
            add.PersentFunction = addMullNext;
            addIf.FewFunction = add;

            FuncOperator sub = AddOperator();
            sub.SetName("Substraction");
            list = sub.GetFewNames();
            list.Add("Deduction");
            list.Add("Vichitaie");
            list.Add("Vichetaie");
            list.Add("Vichit");
            list.Add("Vichet");
            list.Add("Sub");
            list.Add("Mines");
            list.Add("-");
            list.Add("−");
            list.Add("-");
            list.Add("–");
            list.Add("-");
            list.Add("—");
            list.Add("–");
            sub.WorkOperator = true;
            sub.BinarnFewPriority = 1;
            sub.BinarnPriority = 0;
            sub.UnarnFewPriority = 7;
            sub.UnarnPriority = 0;
            sub.ProcentInput = true;
            sub.Appointment = "Разность (вычитание)";
            sub.Description = "Если аргумент 1, то возвращает этот аргумент, умноженный на -1 \n" +
                "В противном случае вычитает из 1-ого аргумента сумму всех последующих аргументов";
            sub.Doing = (value) =>
            {
                int length = value.Length;
                if (length < 2)
                    return -value[0];
                double sum = value[0];
                for (int i = 1; i < length; i++)
                {
                    sum -= value[i];
                }
                return sum;
            };
            sub.PersentFunction = subMullNext;

            FuncNames mullIf = Add();
            mullIf.SetName("mullationIf");
            list = mullIf.GetFewNames();
            list.Add("mullIf");
            list.Add("mulationIf");
            list.Add("mulIf");
            list.Add("umnozhenieIf");
            list.Add("umnozhIf");
            list.Add("umnIf");
            mullIf.SetPsevdoName(58);
            mullIf.Doing = (value) =>
            {
                int length = value.Length;
                double sum = 1;
                double number = value[0];
                for (int i = 1; i < length; i++)
                {
                    double item = value[i];
                    if (item == number)
                        sum *= item;
                }
                return sum;
            };

            FuncOperator mull = AddOperator();
            mull.SetName("Mullation");
            list = mull.GetFewNames();
            list.Add("Mull");
            list.Add("Mulation");
            list.Add("Mul");
            list.Add("Umnozhenie");
            list.Add("Umnozh");
            list.Add("Umn");
            list.Add("*");
            list.Add("×");
            mull.WorkOperator = true;
            mull.BinarnFewPriority = 2;
            mull.BinarnPriority = 0;
            mull.PriorityToBinarn();
            mull.Appointment = "Умножение (произведение)";
            mull.Description = "Произведение всех указанных аргументов";
            this.mull = mull;
            mull.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = 1;
                for (int i = 0; i < length; i++)
                {
                    sum *= value[i];
                }
                return sum;
            };
            mullIf.FewFunction = mull;

            FuncOperator div = AddOperator();
            div.SetName("Division");
            list = div.GetFewNames();
            list.Add("Degree");
            list.Add("Segmentation");
            list.Add("Segment");
            list.Add("Div");
            list.Add("Delenie");
            list.Add("Delen");
            list.Add("÷");
            list.Add("/");
            div.WorkOperator = true;
            div.BinarnFewPriority = 2;
            div.BinarnPriority = 0;
            div.PriorityToBinarn();
            div.Appointment = "Деление (частное)";
            div.Description = "Деление 1-ого аргумента на произведение всех последующих аргументов \n" +
                "Если аргумент 1, то он просто возвращается";
            div.FuncDoing = (value) =>
            {
                int length = value.Length;
                double sum = value[0];
                for (int i = 1; i < length; i++)
                {
                    double b = value[i];
                    if (b == 0)
                    {
                        return double.NaN; ;
                    }
                    sum /= b;
                }
                return sum;
            };

            FuncNames collIf = Add();
            collIf.SetName("collIf");
            list = collIf.GetFewNames();
            list.Add("countIf");
            collIf.SetPsevdoName(56);
            collIf.Doing = (value) =>
            {
                //List<double> list1 = new List<double>();
                int length = value.Length;
                int coll1 = 0;
                double number = value[0];
                for (int i = 1; i < length; i++)
                {
                    if (value[i] == number)
                        coll1++;
                }
                return coll1;
            };

            FuncNames coll = Add();
            coll.SetName("coll");
            list = coll.GetFewNames();
            list.Add("count");
            coll.SetPsevdoName(43);
            coll.Doing = (value) =>
            {
                return value.Length;
            };

            collIf.FewFunction = coll;

            FuncNames copy = Add("Copy");
            copy.Doing = (value) =>
            {
                if (value.Length < 1)
                    return double.NaN; ;
                return value[0];
            };

            FuncNames have = Add("Have");
            have.Doing = (value) =>
            {
                return value.Length > 0 ? 1 : 0;
            };


            FuncNames indexGet = Add();
            indexGet.SetName("IndexOf");
            indexGet.SetPsevdoName(47);
            indexGet.GetFewNames().Add("IndexIf");
            indexGet.GetFewNames().Add("IndexGet");
            indexGet.GetFewNames().Add("FindIndex");
            indexGet.GetFewNames().Add("Index");
            indexGet.IndexFunc = true;
            indexGet.Doing = (value) =>
            {
                int length = value.Length;
                double number = (value[0]);

                List<double> list1 = new List<double>(value);
                list1.RemoveAt(0);
                int indexRet = list1.IndexOf(number) + 1;
                if (indexRet < 0 || indexRet > length - 1)
                {
                    return double.NaN;
                }
                return indexRet;
            };

            FuncNames isAny = Add();


            FuncNames any = Add("Any");

            any.AddFewName("AllowGet");
            any.GetFewNames().Add("Contains");
            any.FewFunction = have;
            any.Doing = (value) =>
            {
                double check = value[0];
                List<double> numbers = new List<double>();
                for (int i = 1; i < value.Length; i++)
                {
                    numbers.Add(value[i]);
                }
                if (numbers.Count < 1)
                    return 0;
                return numbers.Contains(check) ? 1 : 0;
            };

            isAny.FuncDoing = (value) =>
            {
                throw new ManyFuncsOneExceptions(any, value);
            };

            FuncNames get = Add();
            get.SetName("GetOf");
            get.AddFewName("GetIf");
            get.AddFewName("Get");
            get.GetFewNames().Add("FindIf");
            get.GetFewNames().Add("FindOf");
            get.GetFewNames().Add("Find");
            get.SetPsevdoName(46);
            get.Doing = (value) =>
            {
                int length = value.Length;
                int index = (int)(value[0]);
                if (index < 1 || index > length - 1)
                    return double.NaN;
                return value[index];
            };
            get.FewFunction = copy;


            FuncNames fx = Add();
            fx.SetName("fx");
            fx.SetPsevdoName(62);
            fx.AllowFx = false;
            //List<string> listFactorial = factorial.GetFewNames();
            // listFactorial.AddRange(new string[] { "Fact", "Faktorial", "Fakt" });
            fx.Doing = (value) =>
            {
                string fx2 = "";
                try
                {
                    fx2 = FuncGraphicsForm.Fx2;
                    int len = fx2.Length;
                }
                catch
                {
                    fx2 = FuncGraphicsForm.Fx1;
                }
                double y = 0;
                double x = value[0];
                FormulePartList fx1 = MyCalculate.ReplaceByOpenConstNull(fx2, 'x');
                if (MyCalculate.ContainsNoAllowFx(fx1))
                {
                    return double.NaN;
                }
                fx1 = MyCalculate.ConvertToPostfics(fx1);
                y = MyCalculate.CalcByFx(fx1, x);


                return y;
                /*
                double x = value[0];
                String fx1 = MyCalculate.GetFuncions(FuncGraphicsForm.Fx1);
                double y = MyCalculate.GetYByX(fx1, x);
                return y;
                */
            };

            FuncNames no = Add("No");
            //no.SetPsevdoName(83);
            no.GetFewNames().Add("¬");
            no.Appointment = "Логическая инверсия (Логическое \"Не\")";
            no.Description = "Инвертирует передаваемое число: No(1)=0; No(0)=1";
            no.Doing = (value) =>
            {
                int num = HyperbolicFunctions.ToInt(Math.Round(value[0]));
                num = Math.Abs(num);
                num = Math.Min(num, 1);
                return 1 - num;
            };


            FuncOperator moreequals = AddOperator("MoreEquals");
            moreequals.SetPsevdoName(80);
            list = moreequals.GetFewNames();
            list.Add("LangerEquals");
            list.Add("LangEquals");
            list.Add(">=");
            list.Add("≥");
            moreequals.BinarnFewPriority = 1;
            moreequals.BinarnPriority = 3;
            moreequals.PriorityToBinarn();
            moreequals.WorkOperator = true;
            moreequals.Doing = (value) =>
            {
                if (value.Length < 2)
                {
                    throw new FuncsOneArgumentExceptions(value[0], moreequals);
                }
                return value[0] >= value[1] ? 1 : 0;
            };


            FuncOperator lessequals = AddOperator("LessEquals");
            lessequals.SetPsevdoName(81);
            list = lessequals.GetFewNames();
            list.Add("<=");
            list.Add("≤");
            lessequals.BinarnFewPriority = 1;
            lessequals.BinarnPriority = 3;
            lessequals.PriorityToBinarn();
            lessequals.WorkOperator = true;
            lessequals.Doing = (value) =>
            {
                if (value.Length < 2)
                {
                    throw new FuncsOneArgumentExceptions(value[0], lessequals);
                }
                return value[0] <= value[1] ? 1 : 0;
            };


            FuncOperator equals = AddOperator("Equuls");
            equals.SetPsevdoName(76);
            list = equals.GetFewNames();
            list.Add("Equals");
            list.Add("==");
            list.Add("=");
            equals.BinarnFewPriority = 1;
            equals.BinarnPriority = 4;
            equals.PriorityToBinarn();
            equals.WorkOperator = true;
            equals.Doing = (value) =>
            {
                if (value.Length < 2)
                {
                    throw new FuncsOneArgumentExceptions(value[0], equals);
                }
                return value[0] == value[1] ? 1 : 0;
            };

            FuncOperator more = AddOperator("More");
            more.SetPsevdoName(78);
            list = more.GetFewNames();
            list.Add("Langer");
            list.Add("Lang");
            list.Add(">");
            more.BinarnFewPriority = 1;
            more.BinarnPriority = 3;
            more.PriorityToBinarn();
            more.WorkOperator = true;
            more.Doing = (value) =>
            {
                if (value.Length < 2)
                {
                    throw new FuncsOneArgumentExceptions(value[0], more);
                }
                return value[0] > value[1] ? 1 : 0;
            };

            FuncOperator less = AddOperator("Less");
            less.SetPsevdoName(79);
            list = less.GetFewNames();
            list.Add("<");
            less.BinarnFewPriority = 1;
            less.BinarnPriority = 3;
            less.PriorityToBinarn();
            less.WorkOperator = true;
            less.Doing = (value) =>
            {
                if (value.Length < 2)
                {
                    throw new FuncsOneArgumentExceptions(value[0], less);
                }
                return value[0] < value[1] ? 1 : 0;
            };


            FuncNames iif = Add("IIf");
            iif.SetPsevdoName(75);
            iif.GetFewNames().Add("if");
            iif.Doing = (value) =>
            {
                if (value.Length < 3)
                    throw new ArgumentNullException();
                int numberIf = (int)(Math.Round(value[0]));
                if (numberIf == 0)
                {
                    return value[2];
                }
                else
                {
                    return value[1];
                }
            };

            FuncConst pi = AddConst("NumberPi");
            pi.GetFewNames().Add("LOneDiametr");
            list = pi.GetFewNames();
            list.Add("PI");
            list.Add("Pi");
            list.Add("pi");
            list.Add("pI");
            list.Add("π");
            pi.Number = Math.PI;
            pi.Appointment = "Число Pi (Число-Пи)";
            pi.Description = "Данное число - длина окружности с единичным диаметром";

            FuncConst g = AddConst("G");
            g.Number = 9.80665;
            g.Appointment = "Ускорение свободного падения";
            g.Description = "Сила тяжести у тела весом 1 килограмм в земных условиях";

            FuncConst electron = AddConst("ElectronQ");
            electron.Number = -1.602176634 * HyperbolicFunctions.Pow(10, -19);
            electron.Appointment = "Заряд электрона";

            FuncConst proton = AddConst("ProtonQ");
            proton.Number = 1.602176634 * HyperbolicFunctions.Pow(10, -19);
            proton.Appointment = "Заряд протона";

            FuncConst speedLem1 = AddConst("SpeedLemS");
            speedLem1.GetFewNames().Add("CS");
            speedLem1.Number = 300000000;
            speedLem1.Appointment = "Скорость света в вакууме";
            speedLem1.Notes = "Упрощённая скорость света в вакууме";
            speedLem1.Description = "Расстояние, которое свет проходит в вакууме за 1 секунду";

            FuncConst speedLemC = AddConst("SpeedLemC");
            speedLemC.GetFewNames().Add("CC");
            speedLemC.Number = 299796138.625734500539633;
            speedLemC.Appointment = "Скорость света в вакууме";
            speedLemC.Notes = "Точная скорость света в вакууме";
            speedLemC.Description = "Расстояние, которое свет проходит в вакууме за 1 секунду";

            FuncConst speedLemW = AddConst("SpeedLemW");
            speedLemW.GetFewNames().Add("CW");
            speedLemW.Number = 299792458;
            speedLemW.Appointment = "Скорость света в вакууме";
            speedLemW.Notes = "Приближённая скорость света в вакууме";
            speedLemW.Description = "Расстояние, которое свет проходит в вакууме за 1 секунду";

            FuncConst nu = AddConst("MagneticConst");
            nu.GetFewNames().Add("MagnethicConst");
            nu.GetFewNames().Add("MagnethikConst");
            nu.GetFewNames().Add("MagnetikConst");
            nu.GetFewNames().Add("MagnitConst");
            nu.GetFewNames().Add("μ");
            nu.GetFewNames().Add("Nu");
            nu.Number = 4 * Math.PI * Math.Pow(10, -7);
            nu.Appointment = "Магнитная постоянная";
            nu.Notes = "μ = 4*π*(10^(-7)) Генри/метр или μ = 4*π*(10^(-7)) Ньютон/(Ампер^2) ";
            nu.Description = "Физическая константа, скалярная величина, входящая в выражения некоторых законов электромагнетизма" +
                " в виде коэффициента пропорциональности при записи их в форме, соответствующей Международной системе единиц (СИ).";

            FuncNames func;

            FuncConst epsilonW = AddConst("DiElectricConstW");
            List<string> names = epsilonW.GetFewNames();
            names.Add("DiElectrikConstW");
            names.Add("ElectricConstW");
            names.Add("ElectrikConstW");
            names.Add("EpsilonW");
            names.Add("εW");
            epsilonW.Number = 8.85418781762039 * Math.Pow(10, -12);
            func = epsilonW;
            func.Appointment = "Электрическая (диэлектрическая) постоянная";
            func.Notes = "В Фарад/метр или Метр/Генри или (метр^3 * секунда^4 * Ампер^2)/килограмм \n" +
                "Значение константы";
            func.Description = "физическая константа, скалярная величина, входящая в выражения некоторых законов электромагнетизма, в том числе закона Кулона, " +
                "при записи их в рационализованной форме, соответствующей Международной системе единиц (СИ). Определяет напряжённость электрического поля в вакууме, " +
                "где она максимальна, в отличие от ослабляющих напряжённость любых материальных сред.";

            FuncConst epsilonC = AddConst("DiElectricConstC");
            names = epsilonC.GetFewNames();
            names.Add("DiElectrikConstC");
            names.Add("ElectricConstC");
            names.Add("ElectrikConstC");
            names.Add("EpsilonC");
            names.Add("εC");
            epsilonC.Number = 1 / (nu.Number * Math.Pow(speedLemC.Number, 2));
            func = epsilonC;
            func.Appointment = "Электрическая (диэлектрическая) постоянная";
            func.Notes = "В Фарад/метр или Метр/Генри или (метр^3 * секунда^4 * Ампер^2)/килограмм \n" +
                "Значение посчитано, как ε = 1/(μ*(c^2)) \n" +
                "c = " + speedLemC.Number + "м/с - скорость света в вакууме";
            func.Description = "физическая константа, скалярная величина, входящая в выражения некоторых законов электромагнетизма, в том числе закона Кулона, " +
                "при записи их в рационализованной форме, соответствующей Международной системе единиц (СИ). Определяет напряжённость электрического поля в вакууме, " +
                "где она максимальна, в отличие от ослабляющих напряжённость любых материальных сред.";

            FuncConst epsilon = AddConst("DiElectricConst");
            names = epsilon.GetFewNames();
            names.Add("DiElectrikConst");
            names.Add("ElectricConst");
            names.Add("ElectrikConst");
            names.Add("Epsilon");
            names.Add("ε");
            epsilon.Number = (epsilonW.Number + epsilonC.Number) / 2;
            func = epsilon;
            func.Appointment = "Электрическая (диэлектрическая) постоянная";
            func.Notes = "В Фарад/метр или Метр/Генри или (метр^3 * секунда^4 * Ампер^2)/килограмм \n" +
                "Значение посчитано, как ε = (εW+εC)/2 \n" +
                "εW = " + epsilonW.Number + "Ф/м \n" +
                "εС = " + epsilonC.Number + "Ф/м";
            func.Description = "физическая константа, скалярная величина, входящая в выражения некоторых законов электромагнетизма, в том числе закона Кулона, " +
                "при записи их в рационализованной форме, соответствующей Международной системе единиц (СИ). Определяет напряжённость электрического поля в вакууме, " +
                "где она максимальна, в отличие от ослабляющих напряжённость любых материальных сред.";


            FuncConst speedLem = AddConst("SpeedLem");
            speedLem.GetFewNames().Add("C");
            speedLem.Number = (speedLem1.Number + speedLemC.Number + speedLemW.Number) / 3;
            speedLem.Appointment = "Скорость света в вакууме";
            speedLem.Notes = "скорость света в вакууме \n" +
                "Значение посчитано: C = (CS+CW+CC)/3 \n" +
                "CS = " + speedLem1.Number + "м/с \n" +
                "CW = " + speedLemW.Number + "м/с \n" +
                "CC = " + speedLemC.Number + "м/с";
            speedLem.Description = "Расстояние, которое свет проходит в вакууме за 1 секунду";

            ReplaceItemToEnd(speedLemC);
            ReplaceItemToEnd(speedLem);
            ReplaceItemToEnd(or);
            ReplaceItemToEnd(r);
            ReplaceItemToEnd(g);

            sqrtPI.ReplaceWithAddSymwolLast(pi);


            get.SetSpecification(
                "Получить 1-ое число по индексу или условию",
                "Возвращает число по заданному индексу в массиве (индекцсация начинается с 1), которым является 1-ое число" +
                " или возвращает 1-ое число, соответствующее заданному условию"
                );
            any.SetSpecification
                (
                "Существует ли элемент?",
                "Существует ли в массиве число, равное 1-ому числу или соответствующее заданному условию"
                );
            indexGet.SetSpecification
                (
                "Индекс элемента",
                "Индекс элемента в массиве, равного 1-ому числу или соответствующего заданному условию. Индексация начанается с 1. " +
                "Если элемент не найден, то возвращается 0"
                );
            iif.SetSpecification
                (
                "Возврат, в зависимости от выполнения или невыполнения условия",
                "Синтаксис: IIf(«условия»; «число1»; «число2») \n" +
                "Если условие выполнено, то возвращается число1, в противном случае возвращается число2"
                );

            countBetween.SetNamesByFewFuncLast(coll, between);
            sumBetween.SetNamesByFewFuncLast(add, between);
            sumBetween.DeleteNamesWithContainsSymwols('+');

            mullBetween.SetNamesByFewFuncLast(mull, between);
            mullBetween.DeleteNamesWithContainsSymwols("×");
            mullBetween.DeleteNamesWithContainsSymwols('*');

            funcs.Add(any);
            funcs.Add(collIf);
            funcs.Add(addIf);
            funcs.Add(mullIf);
            funcs.Add(get);
            funcs.Add(indexGet);

            isMoreOrZero.SetSpecification("Сравнение с нулём",
                 "Является ли число большим, чем ноль или равным нулю\n" +
                "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию " + isMoreOrZero.GetName() + " без чисел для проверки последующих чисел переданных " +
                "в заданную функцию");

            isLessOrZero.SetSpecification("Сравнение с нулём",
                 "Является ли число меньшим, чем ноль или равным нулю\n" +
                "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию " + isLessOrZero.GetName() + " без чисел для проверки последующих чисел переданных " +
                "в заданную функцию");

            isMoreZero.SetSpecification("Сравнение с нулём",
                 "Является ли число большим, чем ноль\n" +
                "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию " + isMoreZero.GetName() + " без чисел для проверки последующих чисел переданных " +
                "в заданную функцию");

            isLessZero.SetSpecification("Сравнение с нулём",
                 "Является ли число меньшим, чем ноль\n" +
                "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию " + isLessZero.GetName() + " без чисел для проверки последующих чисел переданных " +
                "в заданную функцию");


            isNoZero.SetSpecification("Проверка на ноль", "Является ли число не равным нулю\n" +
                "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию " + isNoZero.GetName() + " без чисел для проверки последующих чисел переданных " +
                "в заданную функцию");

            isZero.SetSpecification("Проверка на ноль", "Является ли число равным нулю\n" +
                "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию " + isZero.GetName() + " без чисел для проверки последующих чисел переданных " +
                "в заданную функцию");

            isInt.SetSpecification("Проверка на целое число", "Является ли число целым\n" +
                "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию " + isInt.GetName() + " без чисел для проверки последующих чисел переданных " +
                "в заданную функцию");

            between.Appointment = "Проверка, нахождения 1-ого числа в диапозоне между двумя последующими";
            between.Description = "Находится ли 1-ое число в диапозоне между двумя последующими \n" +
                "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию between с 2 числами для проверки последующих чисел переданных " +
                "в заданную функцию";

            isAny.SetNamesByFewWithAddFirst("Is", any);
            isAny.SetSpecification("Проверка элементов массива на принадлежность заданному массиву", "" +
                "В функциях " + listToText(funcs) + " для отбора проверяет каждый последующий элемент на принадлежность массиву, переданному " +
                "функции " + isAny.GetName());

            equals.SetSpecification("Сравнение 2-х чисел", "Равны ли 2 числа \n" +
               "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию "+equals.GetName()+" с 1 числом для проверки последующих чисел переданных " +
                "в заданную функцию");


            noequals.SetSpecification("Сравнение 2-х чисел", "Являются ли 2 числа не равными \n" +
               "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию "+noequals.GetName()+" с 1 числом для проверки последующих чисел переданных " +
                "в заданную функцию");

            more.SetSpecification("Сравнение 2-х чисел", "Является ли 1-ое число большим, чем 2-ое число \n" +
               "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию "+more.GetName()+" с 1 числом для проверки последующих чисел переданных " +
                "в заданную функцию");

            less.SetSpecification("Сравнение 2-х чисел", "Является ли 1-ое число меньшим, чем 2-ое число \n" +
               "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию "+less.GetName()+" с 1 числом для проверки последующих чисел переданных " +
                "в заданную функцию");

            moreequals.SetSpecification("Сравнение 2-х чисел", "Является ли 1-ое число большим, чем 2-ое число, или равным 2-ому числу \n" +
               "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию " + moreequals.GetName() + " с 1 числом для проверки последующих чисел переданных " +
                "в заданную функцию");

            lessequals.SetSpecification("Сравнение 2-х чисел", "Является ли 1-ое число меньшим, чем 2-ое число, или равным 2-ому числу \n" +
               "Также в функциях " + listToText(funcs) + " можно 1-ым аргументом указать функцию " + lessequals.GetName() + " с 1 числом для проверки последующих чисел переданных " +
                "в заданную функцию");

            List<FuncNames> funcsEquals = new List<FuncNames>();
            funcsEquals.Add(equals);
            funcsEquals.Add(noequals);
            funcsEquals.Add(more);
            funcsEquals.Add(moreequals);
            funcsEquals.Add(less);
            funcsEquals.Add(lessequals);
            funcsEquals.Add(between);
            funcsEquals.Add(isInt);
            funcsEquals.Add(isZero);
            funcsEquals.Add(isNoZero);
            funcsEquals.Add(isAny);
            funcsEquals.Add(any);
            funcsEquals.Add(equivalention2);
            funcsEquals.Add(isMoreZero);
            funcsEquals.Add(isLessZero);
            funcsEquals.Add(isMoreOrZero);
            funcsEquals.Add(isLessOrZero);

            List<FuncNames> funcsLog = new List<FuncNames>();
            funcsLog.Add(or);
            funcsLog.Add(and);
            funcsLog.Add(xor);
            funcsLog.Add(xor1);
            funcsLog.Add(xor2);
            funcsLog.Add(implication1);
            funcsLog.Add(equivalention1);
            funcsLog.Add(no);
            funcsLog.Add(invertAndB);
            funcsLog.Add(invertOrB);


            string logicalFuncAddDesc = "\n Как логическую эту функцию, можно использовать для того, чтобы совместить условия, такие как: " +
               listToText(funcsEquals) + ", а также условия, созданные с использованием в них выше перечисленных функций при помощи логических операций " +
               "(таких как "+ listToText(funcsLog) + ").\n" +
               " Совмещать эти условия (кроме "+any.GetName()+" и условий, содержащих "+any.GetName()+") при помощи данной функции можно, в том числе в функциях " +
               listToText(funcs) + " для проверки последующих чисел переданных " +
                "в заданную функцию";

            foreach(FuncNames funcLog in funcsLog)
            {
                funcLog.AddDescriptionLast(logicalFuncAddDesc);
            }
            

            string logicalNoAddDesc = "\n Как логическую эту функцию, можно использовать для того, чтобы отрицать условия, такие как: " +
               listToText(funcsEquals) + ", а также условия, созданные с использованием в них выше перечисленных функций при помощи логических операций " +
               "(таких как "+ listToText(funcsLog) + "). \n" +
               " Отрицать эти условия (кроме " + any.GetName() + " и условий, содержащих " + any.GetName() + ") при помощи данной функции можно, в том числе в функциях " +
               listToText(funcs) + " для проверки последующих чисел переданных " +
                "в заданную функцию";
            no.AddDescriptionLast(logicalNoAddDesc);

            string checkFuncDesc = "\n Логические функции " + listToText(funcsLog) + " всегда можно использовать для отрицания данного условия или " +
                "совмещещения данного условия и условий "
                + listToText(funcsEquals) + ", а также условий получившихся с использованием этих условий " +
                "при помощи логический функций. Подробно это описано для каждой из логической функций";

            foreach (FuncNames checkFunc in funcsEquals)
            {
                checkFunc.AddDescriptionLast(checkFuncDesc);
            }
            foreach (FuncNames checkFunc in funcsLog)
            {
                checkFunc.AddDescriptionLast(checkFuncDesc);
            }

            pow.AddFewName("**");
            divInt.AddFewName("//");
            cbrt.AddFewName("∛");

            sin.CanHaveBeforeArgument = false;
            cos.CanHaveBeforeArgument= false;
            tg.CanHaveBeforeArgument = false;
            ctg.CanHaveBeforeArgument = false;
            sec.CanHaveBeforeArgument = false;
            cosec.CanHaveBeforeArgument = false;
            arccos.CanHaveBeforeArgument = false;
            arcsin.CanHaveBeforeArgument = false;
            arctg.CanHaveBeforeArgument = false;
            arcctg.CanHaveBeforeArgument = false;
            arcsec.CanHaveBeforeArgument = false;
            arccosec.CanHaveBeforeArgument = false;
            ln.CanHaveBeforeArgument = false;
            lg.CanHaveBeforeArgument = false;
            rad.CanHaveBeforeArgument = false;
            grad.CanHaveBeforeArgument = false;
            rFromUI.CanHaveBeforeArgument = false;
            iFromUR.CanHaveBeforeArgument = false;
            uFromIR.CanHaveBeforeArgument = false;
            DegToRad = rad;

            plus = add;

            /*
            sin.FuncBeforePower = true;
            cos.FuncBeforePower = true;
            tg.FuncBeforePower = true;
            ctg.FuncBeforePower = true;
            sec.FuncBeforePower = true;
            cosec.FuncBeforePower = true;
            rad.FuncBeforePower = true;
            grad.FuncBeforePower = true;
            */
        }

        public FuncNames DegToRad;

        FuncNames exp;
        public FuncNames Exp => exp;

        public static FuncList Get()
        {
            FuncList funcList = new FuncList();
            /*
            int count = funcList.Count;
            for(int i = 0; i<count; i++)
            {
                funcList.Get(i).SetPsevdoName(i + 1);
            }
            */
            return funcList;
        }

        public string Abs;

        FuncNames absFunc;

        public FuncNames AbsFunc => absFunc;

        FuncNames mull;

        public FuncNames Mull()
        {
            return mull;
        }

        FuncNames plus;
        public FuncNames Plus()
        {
            return plus;
        }

        public int MullLastIndex()
        {
            return Mull().GetAllNames().Count - 1;
        }


        public int PlusLastIndex()
        {
            return Plus().GetAllNames().Count - 1;
        }

        public FormuleFunction FormulePlus()
        {
            return new FormuleFunction(Plus(), PlusLastIndex());
        }
    }
}
