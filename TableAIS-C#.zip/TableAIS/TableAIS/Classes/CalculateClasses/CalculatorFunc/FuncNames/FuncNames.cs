﻿using Microsoft.Office.Core;
using System;
using System.CodeDom;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public delegate double FuncDoing(params double[] data);
    public delegate int FuncDoingInt(params int[] data);
    /// <summary>
    /// Класс - функция для расчётов
    /// </summary>
    public class FuncNames
    {
        private string excelFuncName;

        /// <summary>
        /// Название данной функции в Excel-таблице
        /// </summary>
        public string ExcelFuncName
        {
            get => excelFuncName;
            set => excelFuncName = value;
        }

        

        public void Check()
        {

        }

        public bool AllowReal, IndexFunc;

        /// <summary>
        /// Может ли быть аргумент перед функцией?
        /// </summary>
        bool canHaveBeforeArgument;

        /// <summary>
        /// Имеет ли функция больший приоритет, чем степень
        /// </summary>
        bool funcBeforePower;


        public FuncNames PersentFunction;
        public FuncNames()
        {
            Notes = "";
            ExcelFuncName = "";
            Create();
            fewNames = new List<string>();
            SetPsevdoName(0);
            SetName("");
            AllowFx = true;
            AllowReal = true;
            Description = "";
            FewFunction = this;
            Appointment = "";
            HaveInt = false;
            PersentFunction = this;
            IndexFunc = false;
            CanHaveBeforeArgument = true;
            FuncBeforePower = false;
        }

        public FuncNames FewFunction;

        bool allowFx;

        string description;

        public string GetNameWithNumber()
        {
            return GetName()+" ("+ GetPsevdoNameText()+")";
        }

        /// <summary>
        /// Спецификация функции
        /// </summary>
        public string GetDescription()
        {
            return description;
        }

        /// <summary>
        /// Спецификация функции
        /// </summary>
        public void SetDescription(string value)
        {
            description = value;
        }

        /// <summary>
        /// Описание функции
        /// </summary>
        public string Description
        {
            get => GetDescription(); set => SetDescription(value);
        }

        /// <summary>
        /// Назначение
        /// </summary>
        public string Appointment;

        public bool AllowFx
        {
            get => allowFx; set => allowFx = value;
        }  

        string name;

        public string GetName()
        {
            return GetFewNames()[0].Trim();
            //return name.Trim();
        }

        public void SetName(string value)
        {
            List<string> names = GetFewNames();
            value = value.Trim();
            if (names.Count < 1)
                names.Add(value);
            else
                names[0] = value;
            //AddFewName(value);
            //name = value;
        }

        public string GetLName()
        {
            return "l" + GetName();
        }

        public string GetOName()
        {
            return "o" + GetName();
        }

        public string GetMName()
        {
            return "m" + GetName();
        }

        public string GetDLName()
        {
            return "d" + GetLName();
        }

        public string GetGLName()
        {
            return "g" + GetLName();
        }

        List<string> fewNames;

        public List<string> GetFewNames()
        {
            return fewNames;
        }

        public List<string> GetAllNames()
        {
            List<string> names = new List<string>();
            //names.Add(GetName());
            names.AddRange(GetFewNames());
            return names;
        }

        int psevdoName;

        public int GetPsevdoName()
        {
            return psevdoName;
        }

        public void SetPsevdoName(int value)
        {
            psevdoName = value;
        }

        public string GetPsevdoNameText()
        {
            return "~" + psevdoName + "~";
        }

        /// <summary>
        /// Создание объекта
        /// </summary>
        public virtual void Create()
        {

        }

        public string GetFullCode(string name)
        {
            try
            {
                string code = GetPsevdoNameText();
                if (GetName().ToLower().Trim() == name.ToLower().Trim())
                {
                    return code + "'" + 0 + "'";
                }
                else
                {
                    int index = IndexByFewName(name);
                    if (index < 0)
                        throw new Exception();
                    //index++;
                    return code + "'" + index + "'";

                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public int IndexByFewName(string name)
        {
            int count = GetFewNames().Count();
            for(int i = 0; i < count; i++)
            {
                string fewName = GetFewNames()[i];
                if(fewName.ToLower().Trim() == name.ToLower().Trim())
                    return i;
            }
            return -1;
        }

        public string GetFullCodeByName()
        {
            return GetFullCode(GetName());
            
        }

        public string GetFullCodeByIndex(int index)
        {
            return GetFullCode(GetFewNames()[index]);

        }

        public string GetNameByCode(int code)
        {
            try
            {
                if (code == 0)
                    return GetName();
                else
                    return GetFewNames()[code];
            }
            catch
            {
                return GetName();
            }
            //return GetFewNames()[code - 1];
        }


        public bool EqualsName(string name)
        {
            if(GetName().ToLower() == name.ToLower() || GetName().ToLower().Equals(name.ToLower())) return true;

            int count = GetFewNames().Count;
            for(int i = 0; i<count; i++)
            {
                if (GetFewNames()[i].ToLower() == name.ToLower() || GetFewNames()[i].ToLower().Equals(name.ToLower()))
                    return true;
            }
            return false;
        }

        public bool EqualsPsevdoName(string name)
        {
            return GetPsevdoNameText().ToLower() == name.ToLower() || GetPsevdoNameText().ToLower().Equals(name.ToLower());
        }

        public bool EqualsPsevdoName(int name)
        {
            return GetPsevdoName() == name;
        }

        public bool EqualsLName(string name)
        {
            return GetLName().ToLower() == name.ToLower() || GetLName().ToLower().Equals(name.ToLower()) || GetOName().ToLower() == name.ToLower() || GetOName().ToLower().Equals(name.ToLower());
        }

        public bool EqualsDLName(string name)
        {
            return GetDLName().ToLower() == name.ToLower() || GetDLName().ToLower().Equals(name.ToLower()) || GetGLName().ToLower() == name.ToLower() || GetGLName().ToLower().Equals(name.ToLower());
        }

        public bool EqualsMName(string name)
        {
            return GetMName().ToLower() == name.ToLower() || GetMName().ToLower().Equals(name.ToLower()) ||
                EqualsDLName(name) ||
                EqualsLName(name);
        }

        public event FuncDoing FuncDoingEvent;
        public event FuncDoingInt FuncDoingEventInt;

        public FuncDoing Doing
        {
            get => FuncDoing;
            set => FuncDoing = value;
        }

        public FuncDoing FuncDoing
        {
            get => FuncDoingEvent;
            set => FuncDoingEvent = value;
        }

        public FuncDoingInt DoingInt
        {
            get => FuncDoingInt;
            set => FuncDoingInt = value;
        }

        public FuncDoingInt FuncDoingInt
        {
            get => FuncDoingEventInt;
            set => FuncDoingEventInt = value;
        }

        public double FuncDoingInvoke(params double[] args)
        {
            return Doing?.Invoke(args) ?? 0;
        }

        public double FuncDoingInvokeInt(params int[] args)
        {
            return DoingInt?.Invoke(args) ?? 0;
        }

        bool haveInt;

        /// <summary>
        /// Работает ли функция в целочисленном калькуляторе
        /// </summary>
        public bool HaveInt
        {
            get => haveInt;
            set => haveInt = value;
        }


        public List<string> AllNames
        {
            get
            {
                List<string> names = new List<string>();
                names.Add(GetName());
                names.AddRange(GetFewNames());
                return names;
            }
        }

        /// <summary>
        /// Может ли быть аргумент перед функцией?
        /// </summary>
        public bool CanHaveBeforeArgument { get => canHaveBeforeArgument; set => canHaveBeforeArgument = value; }


        /// <summary>
        /// Имеет ли функция больший приоритет, чем степень
        /// </summary>
        public bool FuncBeforePower { get => funcBeforePower; set => funcBeforePower = value; }

        public bool IsOperator()
        {
            return this is FuncOperator;
        }

        public bool IsConst()
        {
            return this is FuncConst;
        }

        public FuncConst AsConst()
        {
            return this as FuncConst;
        }

        public FuncOperator AsOperator()
        {
            return this as FuncOperator;
        }

        public bool IsWorkOperator()
        {
            if(!IsOperator()) return false;
            else
            {
                return AsOperator().WorkOperator;
            }
        }

        public string GetNamesForm(int count)
        {
            int mod = count % 100;
            if(mod >= 10 && mod <= 20) 
                {
                return count + " названий";
                }
            mod = count % 10;
            if (mod == 0) return "0 названий";
            if (mod == 1) return "1 название";
            if (mod >= 2 && mod <= 4)
            {
                return count + " названия";
            }

            return count + " названий";
        }


        public string GetNameTitle()
        {
            return GetPsevdoName() + ": " + GetName() ;
        }


        public string GetTitle()
        {
            return GetNameTitle() + " ("+ GetNamesForm(GetAllNames().Count)+")";
            //return GetNameTitle() ;
        }

        public override string ToString()
        {
            return GetTitle();
        }

        public string Notes;

        public virtual string GetFuncType() => "Функция";

        public virtual string GetSpecification()
        {
            string text = "";
            text += "Функция: " + GetName() + "\n";
            text += "Другие её обозначения: " + string.Join(", ", GetAllNames()) + "\n";
            text += "Код (псевдокод): " + GetPsevdoName()+"\n";
            text += "Исполняемый псевдокод (Псевдоним): " + GetPsevdoNameText() + "\n";
            text += "Тип: " + GetFuncType() + "\n\n";
            text += "================================= \n\n";

            if(Notes != null && Notes != "" && !Notes.Equals(""))
            {
                text += "Примечания: \n" + Notes + "\n\n";
                text += "================================= \n\n";

            }

            text += "Назначение: \n";
            text += Appointment + "\n \n";
            text += "================================= \n\n";
            text += "Описание: \n";
            text += Description + "\n \n";
            text += "================================= \n\n";

            text += "Разрешена ли передача в функцию аргументов, стоящих перед обозначением функции: \n";
            text += (CanHaveBeforeArgument?"Да":"Нет") + "!\n \n";
            text += "================================= \n\n";

            if (IsWorkOperator())
            {
                text += "\n" +
                    "Приоритет операции: \n";
                text += "Унарной операции: Внешний - " + AsOperator().UnarnFewPriority + ", Собственный - " + AsOperator().UnarnPriority+"\n";
                text += "Бинарной операции: Внешний - " + AsOperator().BinarnFewPriority + ", Собственный - " + AsOperator().BinarnPriority + "\n";
            }

            return text;
        }

        /// <summary>
        /// Импорт спецификации от другой функции
        /// </summary>
        /// <param name="func"></param>
        public void ImportSpecification(FuncNames func)
        {
            Description = func.Description;
            Appointment = func.Appointment;
        }

        /// <summary>
        /// Экспорт спецификации на другую функцию
        /// </summary>
        /// <param name="func"></param>
        public void ExportSpecification(FuncNames func)
        {
            func.ImportSpecification(this);
        }

        public bool IsProcentInput()
        {
            if (!IsWorkOperator())
                return false;
            else
                return AsOperator().ProcentInput;
        }

        public FuncNames AddFewName(string name)
        {
            GetFewNames().Add(name);
            return this;
        }

        public FuncNames AddFewNames(IEnumerable<string> names)
        {
            FuncNames func = this;
            foreach (string s in names)
            { 
                func = func.AddFewName(s);
            }
            return func;
        }

        public FuncNames AddNamesByReplace(string oldChars, string newChars)
        {
            FuncNames func = this;
            List<string> names = GetAllNames().FindAll(n => n.Contains(oldChars));
            for(int i = 0; i< names.Count; i++)
            {
                func = func.AddFewName(names[i].Replace(oldChars, newChars));
            }
            return this;
        }

        public FuncNames InsertWithAddSymwolLast(string chars)
        {
            List<string> names = GetFewNames(), newNames = new List<string>();
            int count = names.Count;

            /*
            if (GetName().Length < 1)
            {
                newNames.Add(GetName() + chars);
                newNames.Add(GetName());
            }
            */

            for(int i = 0; i< count; i++)
            {
                newNames.Add(names[i] + chars);
                newNames.Add(names[i]);
            }

            names.Clear();
            names.AddRange(newNames);
            SetName(names[0]);

            return this;
        }

        public FuncNames ReplaceWithAddSymwolLast(string chars)
        {
            List<string> names = GetFewNames(), newNames = new List<string>();
            int count = names.Count;

            /*
            if (GetName().Length > 0)
            {
                newNames.Add(GetName() + chars);
            }
            */

            for (int i = 0; i < count; i++)
            {
                newNames.Add(names[i] + chars);
            }

            names.Clear();
            names.AddRange(newNames);
            SetName(names[0]);

            return this;
        }


        public FuncNames ReplaceWithAddSymwolFirst(params string[] chars)
        {
            List<string> names = GetFewNames(), newNames = new List<string>();
            int count = names.Count;

            /*
            if (GetName().Length > 0)
            {
                newNames.Add(GetName() + chars);
            }
            */

            int length = chars.Length;

            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < length; j++)
                    newNames.Add(chars[j]+names[i]);
            }

            names.Clear();
            names.AddRange(newNames);
            //SetName(names[0]);

            return this;
        }

        public FuncNames ReplaceWithAddSymwolFirst(FuncNames func)
        {
            return ReplaceWithAddSymwolFirst(func.GetAllNames().ToArray());
        }



        public FuncNames ReplaceWithAddSymwolLast(params string[] chars)
        {
            List<string> names = GetFewNames(), newNames = new List<string>();
            int count = names.Count;

            /*
            if (GetName().Length > 0)
            {
                newNames.Add(GetName() + chars);
            }
            */

            int length = chars.Length;

            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < length; j++)
                    newNames.Add(names[i] + chars[j]);
            }

            names.Clear();
            names.AddRange(newNames);
            //SetName(names[0]);

            return this;
        }

        public FuncNames ReplaceWithAddSymwolLast(FuncNames func)
        {
            return ReplaceWithAddSymwolLast(func.GetAllNames().ToArray());
        }


        public void SetDoubleByInt()
        {
            HaveInt = true;

            FuncDoing = (value) =>
            {
                List<int> ints = new List<int>();
                for (int i = 0; i < value.Length; i++)
                {
                    ints.Add(HyperbolicFunctions.ToInt(value[i]));
                }
                return FuncDoingInvokeInt(ints.ToArray());
            };
        }

        /// <summary>
        /// Устанавливает HaveInt в true и возвращает ссылку на объект, для которого вызван данный метод
        /// </summary>
        /// <returns></returns>
        public FuncNames SetHaveInt()
        {
            HaveInt = true;
            return this;
        }

        public virtual int GetBynarnFewPriority()
        {
            return 3;
        }

        public virtual int GetUnarnFewPriority()
        {
            return 3;
        }

        public virtual int GetBynarnPriority()
        {
            return 0;
        }

        public virtual int GetUnarnPriority()
        {
            return 0;
        }

        public void SetSpecification(String appointment, string description)
        {
            Appointment = appointment;
            Description = description;
        }

        public void SetNamesByFewFuncLast(FuncNames firstFunc, FuncNames replaceLastFunc)
        {
            GetFewNames().Clear();
            GetFewNames().AddRange(firstFunc.GetAllNames());
            ReplaceWithAddSymwolLast(replaceLastFunc);
        }

        public void DeleteNamesWithContainsSymwols(char sign)
        {
            GetFewNames().RemoveAll(n => n.Contains(sign));
        }

        public void DeleteNamesWithContainsSymwols(string name)
        {
            GetFewNames().RemoveAll(n => n.Contains(name));
        }

        public string WidthNumberCollView(int coll)
        {
            string result = "";
            if (coll < 1)
                return "без аргументов";
            

            return result;
        }

        public FuncNames SetNamesByFewWithAddFirst(string first, FuncNames names)
        {
            int count = names.NamesCount();
            GetFewNames().Clear();
            List<String> list = names.GetFewNames();
            for (int i = 0; i < count; i++)
            {
                AddFewName(first + list[i]);
            }

            return this;
        }

        public int NamesCount()
        {
            return GetFewNames().Count();
        }

        public void AddDescriptionLast(string description)
        {
            Description += "\n" + description;
        }
    }
}
