﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Chat;

namespace TableAIS
{
    public class FuncNamesList : List<FuncNames>
    {
        public FuncNamesList() : base()
        {
            Create1();
        }

        public FuncNamesList(int capacity) : base(capacity)
        {
            Create1();
        }

        public FuncNamesList(IEnumerable<FuncNames> collection) : base(collection)
        {
            Create1();
        }

        void Create1()
        {
            Create();
            for(int i = 0; i < Count; i++)
            {
                this[i].SetPsevdoName(i);
            }
        }

        /// <summary>
        /// Создаёт содержимое объекта FuncNamesList
        /// </summary>
        public virtual void Create()
        {

        }

        /// <summary>
        /// Получить функцию по её псевдониму, предполагая, что он равен её позиции в массиве
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public FuncNames GetByPsevdoNameWithIndex(int index)
        {
            return Get(index);
        }

        public List<FuncNames> ToList() => this;

        public bool ContainsByName(string name)
        {
            return ToList().Any(x => x.EqualsName(name));
        }

        public FuncNames GetByName(string name)
        {
            return Find(x => x.EqualsName(name));
        }

        public string GetPsevdoName(string name)
        {
            return GetByName(name).GetPsevdoNameText();
        }

        public string GetNameByPsevdoName(string name)
        {
            return GetByPsevdoName(name).GetName();
        }

        public string GetLName(int name)
        {
            return GetByPsevdoName(name).GetLName();
        }

        public string GetOName(int name)
        {
            return GetByPsevdoName(name).GetOName();
        }

        public string GetMName(int name)
        {
            return GetByPsevdoName(name).GetMName();
        }

        public string GetDLName(int name)
        {
            return GetByPsevdoName(name).GetDLName();
        }

        public string GetGLName(int name)
        {
            return GetByPsevdoName(name).GetGLName();
        }

        public double Invoke(FuncNames func, params double[] args)
        {
            return func.FuncDoingInvoke(args);
        }

        public double InvokeByLName(string lName, params double[] args)
        {
            return Invoke(GetByLName(lName), args);
        }

        public double InvokeByLNameFew(string lName, params double[] args)
        {
            return Invoke(GetByLName(lName).FewFunction, args);
        }

        public double InvokeByDLName(string lName, params double[] args)
        {
            return Invoke(GetByDLName(lName), args);
        }

        public double InvokeByMName(string lName, params double[] args)
        {
            return Invoke(GetByMName(lName), args);
        }

        public double InvokeByMNameFew(string lName, params double[] args)
        {
            return Invoke(GetByMName(lName).FewFunction, args);
        }

        public string ReplaseNames(string text, string name)
        {
            try
            {
                return text.Replace(name, GetPsevdoName(name));
            }
            catch 
            { 
                return text;
            }
        }

        public string ReplaceFuncName(string formule, string psevdpName)
        {
            try
            {
                return formule.ToLower().Trim().Replace(psevdpName.ToLower().Trim(), GetNameByPsevdoName(psevdpName));
            }
            catch
            {
                return formule;
            }
        }

        public string ReplaceNameByCode(string formule, string psevdpName, int code)
        {
            try
            {
                FuncNames func = GetByPsevdoName(psevdpName);
                string codeText = psevdpName+"'"+code+"'";
                return formule.ToLower().Trim().Replace(codeText.ToLower().Trim(), func.GetNameByCode(code));
            }
            catch
            {
                return formule;
            }
        }

        public string ReplaceNameByCode(string formule, string code)
        {
            string[] parts = code.Split('\'');
            return ReplaceNameByCode(formule, parts[0], int.Parse(parts[1]));
        }

        public string ReplaceFunc(string formule)
        {
            int count = Count;
            for(int i = 0; i< count; i++)
            {
                formule = ReplaceFuncName(formule, Get(i).GetPsevdoNameText());
            }
            return formule;
        }

        public string ReplaceFuncByCode(string formule)
        {
            int count = Count;
            for (int i = 0; i < count; i++)
            {
                FuncNames func = Get(i);
                formule = ReplaceNameByCode(formule, func.GetFullCodeByName());
                int count1 = func.GetFewNames().Count();
                for(int j = 0; j < count1; j++)
                {

                    formule = ReplaceNameByCode(formule, func.GetFullCodeByIndex(j));
                }
                formule = ReplaceFuncName(formule, func.GetPsevdoNameText());
            }
            return formule;
        }

        public FuncNames Add()
        {
            Add(new FuncNames());
            return this[Last]; 
        }

        public FuncOperator AddOperator()
        {
            Add(new FuncOperator());
            return this[Last].AsOperator();
        }

        public FuncOperator AddWorkOperator()
        {
            return AddOperator().SetWork();
        }

        public FuncConst AddConst()
        {
            Add(new FuncConst());
            return this[Last].AsConst();
        }

        public FuncConst AddConst(string name)
        {
            FuncConst func = AddConst();
            func.SetName(name);
            return func;
        }

        public FuncNames Add(string name)
        {
            FuncNames func = Add();
            func.SetName(name);
            return func;
        }

        public FuncOperator AddOperator(string name)
        {
            FuncOperator func = AddOperator();
            func.SetName(name);
            return func;
        }

        public FuncOperator AddWorkOperator(string name)
        {
            return AddOperator(name).SetWork();
        }

        public int Last => Count - 1;

        public string Replase(string text)
        {
            text = text.ToLower().Trim();
            int count = Count;
            for(int i = 0; i< count; i++)
            {
                FuncNames func = this[i];
                text = text.Replace(func.GetName().ToLower().Trim(), func.GetPsevdoNameText());
                int count1 = func.GetFewNames().Count;
                for(int j = 0; j < count1; j++)
                {
                    text = text.Replace(func.GetFewNames()[j].ToLower().Trim(), func.GetPsevdoNameText());
                }
            }
            return text;
        }

        public string ReplaseToCode(string text)
        {
            text = text.ToLower().Trim();
            int count = Count;
            for (int i = 0; i < count; i++)
            {
                FuncNames func = this[i];
                string name = func.GetName().ToLower().Trim();
                text = text.Replace(name, func.GetFullCode(name));
                int count1 = func.GetFewNames().Count;
                for (int j = 0; j < count1; j++)
                {
                    name = func.GetFewNames()[j].ToLower().Trim();
                    text = text.Replace(name, func.GetFullCode(name));
                }
            }
            return text;
        }

        public bool ContainsByPsevdoName(string name)
        {
            return ToList().Any(x => x.EqualsPsevdoName(name));
        }

        public FuncNames GetByPsevdoName(int name)
        {
            return Find(x => x.EqualsPsevdoName(name));
        }

        public FuncNames GetByPsevdoName(string name)
        {
            return Find(x => x.EqualsPsevdoName(name));
        }


        public bool ContainsByLName(string name)
        {
            return ToList().Any(x => x.EqualsLName(name));
        }

        public bool ContainsByDLName(string name)
        {
            return ToList().Any(x => x.EqualsDLName(name));
        }

        public FuncNames GetByLName(string name)
        {
            return Find(x => x.EqualsLName(name));
        }

        public FuncNames GetByDLName(string name)
        {
            return Find(x => x.EqualsDLName(name));
        }
        public FuncNames GetByMName(string name)
        {
            return Find(x => x.EqualsMName(name));
        }


        public FuncNames Get(int index)
        {
            return this[index];
        }

        public List<string> AllNamesList
        {
            get
            {
                List<string> list = new List<string>();
                int count = Count;
                for(int i = 0; i < count; i++)
                {
                    list.AddRange(Get(i).AllNames);
                }
                return list;
            }
        }

        public string[] AllNamesArray => AllNamesList.ToArray();

        public List<FuncNames> NoAllowFx => FindAll(f => !f.AllowFx);

        public bool ContainsNoAllowFx(string formule)
        {
            formule = MyCalculate.ChangeBaskets(formule);
            List<FuncNames> list = NoAllowFx;
            int count = list.Count;

            for(int i = 0; i < count; i++)
            {
                FuncNames item = list[i];
                if (formule.Contains(item.GetPsevdoNameText()))
                    return true;
            }

            return false;
        }

        public void Check()
        {

        }

        public static FuncNamesList operator +(FuncNamesList list, FuncNames func)
        {
            list.Add(func);
            return list;
        }

        

        public static FuncNames operator *(FuncNamesList list, int index)
        {
            return list.Get(index);
        }

        public static FuncNames operator *(FuncNamesList list, string name)
        {
            return list.GetByName(name);
        }

        public static int operator *(FuncNamesList list, FuncNames func)
        {
            return list.IndexOf(func);
        }


        public static FuncNamesList operator -(FuncNamesList list, int index)
        {
            list.RemoveAt(index);
            return list;
        }

        public static FuncNamesList operator -(FuncNamesList list, FuncNames func)
        {
            list.Remove(func);
            return list;
        }


        public void ReplaceItemToEnd(FuncNames item)
        {
            int index = IndexByFirstName(item.GetName());
            RemoveAt(index);
            Add(item);
        }


        public int IndexByName(String name)
        {
            int count = Count;
            for (int i = 0; i < count; i++)
            {
                FuncNames func = Get(i);
                if (func.EqualsName(name))
                {
                    return i;
                }
            }
            return -1;
        }


        public int IndexByFirstName(String name)
        {
            int count = Count;
            for (int i = 0; i < count; i++)
            {
                FuncNames func = Get(i);
                if (func.GetName().ToLower().Trim() == name.ToLower().Trim() || func.GetName().Trim().ToLower().Equals(name.ToLower().Trim()))
                {
                    return i;
                }
            }
            return -1;
        }

        public List<string> GetProcentInputOperators()
        {
            List<string> result = new List<string>();

            for(int i = 0; i<Count; i++)
            {
                FuncNames func = Get(i);
                if(func.IsProcentInput())
                {
                    result.Add(func.GetDLName());
                    result.Add(func.GetGLName());
                }
            }

            return result;
        }

        public bool IsProcentInput(string name)
        {
            List<string> result = GetProcentInputOperators();
            for(int i = 0; i < result.Count; i++)
            {
                if (result[i].ToLower().Trim() == name.ToLower().Trim())
                {
                    return true;
                }
            }
            return false;
        }


        public List<FuncNames> FindByName(string names, SortIndex sortIndex)
        {
            return FindByAllNames(names, sortIndex);
        }

        public List<FuncNames> FindByName(string name)
        {
            return FindFuncs(name);
        }

        public List<FuncNames> FindByEndName(string name)
        {
            return FindByEndName(this, name);
        }

        public static List<FuncNames> FindByEndName(List<FuncNames> funcs, string name)
        {
            int length = name.Length;
            List<FuncNames> result = new List<FuncNames>();
            name = name.ToLower().Trim();

            int count = funcs.Count;

            for(int i = 0; i < count; i++)
            {
                FuncNames func = funcs[i];
                List<string> names = func.GetAllNames();
                int count1 = names.Count;
                for(int j = 0; j< count1; j++)
                {
                    string nameF = names[j].ToLower() ;
                    int lengthF = nameF.Length;
                    try
                    {
                        string part = nameF.Substring(lengthF - length);
                        if(part == name || part.Equals(name))
                        {
                            result.Add(func);
                            break;
                        }
                    }
                    catch(Exception e) { }
                    
                }
            }


            return result;
        }

        public List<FuncNames> FindFuncs(string name)
        {
            return FindByAllNames(this, name);
        }


        public  List<FuncNames> FindByAllNames(string names, SortIndex sortIndex)
        {
            List<FuncNames> funcs = Sort(sortIndex);
            return FindByAllNames(funcs, names);
        }

        public static List<FuncNames> FindByAllNames(List<FuncNames> funcs, string names)
        {

            return FindByAllNames(funcs, names.Split(';'));
        }

        public static List<FuncNames> FindByAllNames(List<FuncNames> funcs, string[] names)
           
        {
            if(names.Length < 1)
                return funcs;
            return FindByAllNames(funcs, new List<string>(names));
        }

        public static List<FuncNames> FindByAllNames(List<FuncNames> funcs, List<string> names)
        {
            if (names.Count < 1)
                return funcs;
            List<FuncNames> result = funcs;

            for(int i = 0; i < names.Count; i++)
            {
                result = FindByName(result, names[i]);
            }

            return result;
        }

        public static List<FuncNames> FindByName(List<FuncNames> funcs, string name)
        {
            name = name.ToLower().Trim();
            int length = name.Length;
            int last = length - 1;
            if (length < 1)
                return funcs;
            else
            {
                
                if (name[0] == '#')
                {
                    return funcs.FindAll(f => f.GetAllNames().Any(n => n.ToLower().Substring(0, Math.Min(last, n.Length)) == name.Remove(0, 1)));
                    //return FindAll(f => f.GetName().ToLower().Substring(0, Math.Min(last, f.GetName().Length)) == name.Remove(0, 1));
                }
                if (name[last] == '#')
                {
                    return FindByEndName(funcs, name.Remove(last));
                    //return FindAll(f => f.GetAllNames().Any(n => n.ToLower().Substring(Math.Min(n.Length-last, n.Length)) == name.Remove(last)));
                    //return FindAll(f => f.GetName().ToLower().Substring(f.GetName().Length - last) == name.Remove(0, 1));
                }
                if (name[0] == '$')
                {
                    name = name.Remove(0, 1);

                    return funcs.FindAll(p => p.GetAllNames().Any(n => n.ToLower() == name.ToLower())
                    || p.GetPsevdoNameText() == name
                    || p.GetPsevdoName().ToString() == name);
                }
                return funcs.FindAll(p => p.GetAllNames().Any(n => n.ToLower().Contains(name.ToLower())) || p.GetPsevdoNameText().Contains(name));
            }

            
        }

        public List<FuncNames> Copy()
        {
            List<FuncNames> funcs = new List<FuncNames>();

            for(int i = 0; i<Count; i++)
            {
                funcs.Add(Get(i));
            }

            return funcs;
        }


        public List<FuncNames> Sort(SortIndex sortIndex = SortIndex.None)
        {
            List<FuncNames> funcs = Copy();
            

            int indexSort = (int)sortIndex;
            if(sortIndex == 0)
                return funcs;
            if(indexSort == 3)
            {
                funcs = funcs.FindAll(f => f.IsWorkOperator());

                funcs.Sort((x, y) =>
                {
                    try
                    {
                        FuncOperator opX = x.AsOperator();
                        FuncOperator opY = y.AsOperator();
                        int prX = opX.BinarnFewPriority;
                        int prY = opY.BinarnFewPriority;
                        if(prX != prY)
                        {
                            return (prY - prX)*11;
                        }
                        else
                        {

                            prX = opX.BinarnPriority;
                            prY = opY.BinarnPriority;
                            return prX - prY;
                        }
                    }
                    catch
                    {
                        return 0;
                    }

                });

                return funcs;
            }

            if (indexSort == 4)
            {
                funcs = funcs.FindAll(f => f.IsWorkOperator());

                funcs.Sort((x, y) =>
                {
                    try
                    {
                        FuncOperator opX = x.AsOperator();
                        FuncOperator opY = y.AsOperator();
                        int prX = opX.UnarnFewPriority;
                        int prY = opY.UnarnFewPriority;
                        if (prX != prY)
                        {
                            return (prY - prX) * 11;
                        }
                        else
                        {

                            prX = opX.UnarnPriority;
                            prY = opY.UnarnPriority;
                            return prX - prY;
                        }
                    }
                    catch
                    {
                        return 0;
                    }

                });

                return funcs;
            }


            funcs.Sort((x,y)=>
            {
                try
                {
                    string nameX = x.GetName().ToLower().Trim(), nameY = y.GetName().ToLower().Trim();
                    return nameX.CompareTo(nameY);
                }
                catch
                {
                    return 0;
                }
                
            });

            if(indexSort > 1)
            {
                List<FuncNames> result = new List<FuncNames>();
                int count = funcs.Count;
                for(int i = 0; i< count; i++)
                {
                    result.Add(funcs[count-1-i]);
                }
                funcs = result;
            }

            return funcs;
        }

        public FuncIntList GetFuncsListInt()
        {
            return FuncIntList.Set(this);
        }


        public List<FuncNames> FindIntFunc()
        {
            return FindAll(f => f.HaveInt);
        }

    }

    public enum SortIndex
    {
        None ,
        Up ,
        Down,
        BinarnOperatePriority,
        UnarnOperatePriority
    }
}
