﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Функция-оператор - функция с уклоном на свойства оператора
    /// </summary>
    public class FuncOperator : FuncNames
    {
        /// <summary>
        /// Конструктор для создания объекта
        /// </summary>
        public FuncOperator() : base()
        {
        }
/// <inheritdoc/>

        public override void Create()
        {
            base.Create();
            unarnPriority = 0;
            binarnPriority = 0;
            unarnFewPriority = 0;
            binarnFewPriority = 0;
            WorkOperator = false;
            ProcentInput = false;
        }

        int unarnPriority, binarnPriority;

        int unarnFewPriority, binarnFewPriority;

        /// <summary>
        /// Приоритет выполнения унарной операции
        /// </summary>
        public int UnarnPriority
        {
            get => unarnPriority;
            set => unarnPriority = value;
        }

        /// <summary>
        /// Приоритет выполнения бинарной операции
        /// </summary>
        public int BinarnPriority
        {
            get => binarnPriority;
            set => binarnPriority = value;
        }

        /// <summary>
        /// Внешний приоритет выполнения унарной операции
        /// </summary>
        public int UnarnFewPriority
        {
            get => unarnFewPriority;
            set => unarnFewPriority = value;
        }

        /// <summary>
        /// Внешний приоритет выполнения бинарной операции
        /// </summary>
        public int BinarnFewPriority
        {
            get => binarnFewPriority;
            set => binarnFewPriority = value;
        }


        bool workOperetor;

        public bool WorkOperator
        {
            get => workOperetor;
            set => workOperetor = value;
        }

        /// <summary>
        /// Изменяет ли процент/промиль ход выполнения бинарного оператора
        /// </summary>
        public bool ProcentInput;

        public void PriorityToUnarn()
        {
            BinarnFewPriority = UnarnFewPriority;
            BinarnPriority = UnarnPriority;
        }

        public void PriorityToBinarn()
        {
            UnarnPriority = BinarnPriority;
            UnarnFewPriority = BinarnFewPriority;
        }

        public override string GetFuncType()
        {
            if (IsWorkOperator())
                return "Функция-оператор";
            else
                return base.GetFuncType();
        }

        public FuncOperator SetWork()
        {
            WorkOperator = true;
            return this;
        }

        public FuncOperator SetPriorityByFewOperator(FuncOperator op)
        {
            
            BinarnFewPriority = op.BinarnFewPriority;
            BinarnPriority = op.BinarnPriority;
            UnarnFewPriority = op.UnarnFewPriority;
            UnarnPriority = op.UnarnPriority;


            return this;
        }

        public override int GetBynarnFewPriority()
        {
            return BinarnFewPriority;
        }

        public override int GetBynarnPriority()
        {
            return BinarnPriority;
        }

        public override int GetUnarnFewPriority()
        {
            return UnarnFewPriority;
        }

        public override int GetUnarnPriority()
        {
            return UnarnPriority;
        }
    }
}
