﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class FuncIntList : FuncNamesList
    {
        private FuncIntList(List<FuncNames> list) : base(list.FindAll(f => f.HaveInt)) 
        { 

        }

        public static FuncIntList Set(List<FuncNames> list)
        {
            return new FuncIntList(list);
        }

    }
}
