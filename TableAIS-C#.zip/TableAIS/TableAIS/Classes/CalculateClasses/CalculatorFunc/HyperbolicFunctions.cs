﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public static class HyperbolicFunctions
    {

        public static double LogicalShiftRight(double x, double y)
        {
            int n = (int)y;

            if(n == 0)
                return x;
            if(n < 0)
                return LogicalShiftLeft(x, -y);
            uint m = (uint)((int)x);
            return (int)(m >> n);
        }

        public static double LogicalShiftLeft(double x, double y)
        {
            int n = (int)y;

            if (n == 0)
                return x;
            if (n < 0)
                return LogicalShiftRight(x, -y);

            uint m = (uint)((int)x);
            return (int)(m << n);

        }

        public static double ArithmeticShiftRight(double x, double y)
        {
            int n = (int)y;

            if (n == 0)
                return x;
            if (n < 0)
                return ArithmeticShiftLeft(x, -y);
            int m = ((int)x);
            return (int)(m >> n);
        }

        public static double ArithmeticShiftLeft(double x, double y)
        {
            int n = (int)y;

            if (n == 0)
                return x;
            if (n < 0)
                return ArithmeticShiftRight(x, -y);
            int m = ((int)x);
            return (int)(m << n);
        }


        public static double RoundAcc(double a)
        {
            try
            {
                return RoundExp(a, 14);
            }
            catch (Exception e)
            {
                
            }
            return a;
        }


        /// <summary>
        /// Импликация
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static int Implication(int a, int b)
        {
            return (~a) | b;
        }
        /// <summary>
        /// Эквиваленция
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static int Equivalention(int a, int b)
        {
            
            return ((~a) & (~b)) | (a & b);
        }

        /// <summary>
        /// Импликация
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static int ImplicationLog(int a, int b)
        {
            a = LogN(a);
            b = LogN(b);
            return No(a) | b;
        }

        /// <summary>
        /// Эквиваленция
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static int EquivalentionLog(int a, int b)
        {
            a = LogN(a);
            b = LogN(b);
            return (No(a) & No(b)) | (a & b);
        }

        public static int LogN(int a)
        {
            a = Math.Abs(a);
            a = Math.Min(a, 1);
            return a;
        }

        public static int No(int a)
        {
            return 1 - LogN(a);
        }


        public static double RoundExp(double number)
        {
            return RoundExp(number, 0);
        }

        public static double RoundExp(double number, double digits)
        {
            int digit = ToInt(digits);
            return Convert.ToDouble(number.ToString($"e{digit}"));
        }


        public static int ToInt(double value)
        {
            string number = value.ToString();
            try
            {
                return int.Parse(number.Split(new char[] { '.', ',' })[0]);
            }
            catch
            {
                return 0;
            }
        }

        public static double Random(int a, int b)
        {
            int min = Min(a, b);
            int max = Max(a, b);
            return Random1.Next(min, max+1);
            
        }

        public static double RandomInt(double a, double b)
        {
            return Random((int)a, (int)b);
        }

        public static double Random(double a, double b)
        {
            double min = Min(a, b);
            double max = Max(a, b);
            return Random1.NextDouble() * (max - min) + min;

        }

        public static Random Random1 => new Random();

        public static int Max(int a, int b)
        {
            if (a > b)
            {
                return a;
            }
            else
                return b;
        }

        public static int Min(int a, int b)
        {
            if (a > b)
            {
                return b;
            }
            else
                return a;
        }

        public static double Max(double a, double b)
        {
            if (a > b)
            {
                return a;
            }
            else
                return b;
        }

        public static double Min(double a, double b)
        {
            if (a > b)
            {
                return b;
            }
            else
                return a;
        }


        public static double EX(double x)
        {
            return Pow(Math.E, x);
        }

        public static double EMinesX(double x)
        {
            return EX(-x);
           // return 1/EX(x);
        }

        public static double Sh(double x)
        {
            return (EX(x) - EMinesX(x)) / 2;
        }

        public static double ArSh(double x)
        {
            return Ln(x + Sqrt(Sqr(x) + 1));
        }

        public static double Ch(double x)
        {
            return (EX(x) + EMinesX(x)) / 2;
        }

        public static double ArCh(double x)
        {
            return Ln(x + Sqrt(Sqr(x) - 1));
        }

        public static double Th(double x)
        {
            double ch = Ch(x);
            if (ch == 0)
                throw new Exception();
            return Sh(x) / ch;
        }

        public static double ArTh(double x)
        {
            //double y = 1 - x;
            if (x == 1)
            {
                throw new Exception();
            }
            return Ln((1+x) / (1-x)) / 2;
        }

        public static double Cth(double x)
        {
            double sh = Sh(x);
            if (sh == 0)
            {
                throw new Exception();
            }
            return Ch(x) / sh;
        }

        public static double ArCth(double x)
        {
            //double y = x - 1;
            if (x==1)
            {
                throw new Exception();
            }
            return Ln((x + 1) / (x - 1)) / 2;
        }

        public static double Sch(double x)
        {
            double ch = Ch(x);
            if (ch == 0)
                throw new Exception();
            return 1 / ch;
        }

        public static double ArSch(double x)
        {
            if(x == 0)
            {
                throw new Exception();
            }
            return Ln((1 + Sqrt(1 - Sqr(x))) / x);
        }

        public static double Sgn(double x)
        {
            if (x == 0)
                return 0;
            return x > 0 ? 1 : -1;
        }

        public static int Sgn(int x)
        {
            if (x == 0)
                return 0;
            return x > 0 ? 1 : -1;
        }

        public static double Csch(double x)
        {
            double sh = Sh(x);
            return 1 / sh;
        }

        public static double ArcCsch(double x)
        {
            if (x == 0)
            {
                throw new Exception();
            }

            return Ln((1 + Sgn(x) * Sqrt(1 + Sqr(x))) / x);
        }

        public static double Abs(double x)
        {
            return Math.Abs(x);
        }

        public static double Pow(double x, double y) 
        {
            double result = Math.Pow(x, y);
            double result1 = Math.Abs(result);
            if (double.IsNaN(result1) || double.IsInfinity(result1))
                return double.NaN;
            return result;
            /*
            if (x == 0 && y <= 0)
            {
                return double.NaN;
            }
            else
            {
                double result = Math.Pow(x, y);
                double result1 = Math.Abs(result);
                if(double.IsNaN(result1) || double.IsInfinity(result1))
                    return double.NaN;
                return result;
            }
            */
        }

        public static int PowInt(int x, int y)
        {
            int result = 1;

            for(int i = 0; i<y;i++)
            {
                result *= x;
            }

            return result;
        }

        public static double Sqrt(double x, double y) 
        {
            return Pow(x, 1 / y);
        }

        public static double Sqr(double x)
        {
            return Pow(x, 2);
        }

        public static double Kub(double x)
        {
            return Pow(x, 3);
        }

        public static double Factorial(double x)
        {
            if(x<0)
            {
                throw new Exception();
            }
            if (double.IsNaN(x) || double.IsInfinity(x))
            {
                throw new Exception();
            }
            double max = MaxIteration;
            double result = 1;

            for(int i = 1; i<= x; i++)
            {
                if (i > max)
                    throw new Exception();
                result *= i;
            }
            if(double.IsNaN(result) || double.IsInfinity(result))
            {
                throw new Exception();
            }

            return result;
        }

        public static int Trancate(double x)
        {
            string number = x.ToString();
            try
            {
                return int.Parse(number.Split(new char[] { '.', ',' })[0]);
            }
            catch
            {
                return 0;
            }
        }

        public static double Factorial(double n, double m)
        {
            double max = MaxIteration;
            double result = 1.0;
            if(!IsFromZero(n) || !IsFromZero(m))
                throw new Exception();
            int n1 = Trancate(n);
            int m1 = Trancate(m);
            if (n1 >= 0 && n1 <= 1)
                return 1;

            int k = n1 / m1;
            //k++;
            int r = n1 % m1;
            if (r == 0)
                k--;
            

            for(int i = 0; i <= k; i++)
            {
                if (i > max)
                    throw new Exception();
                //result *= m1*i-r;
                result *= n1 - i * m1;
            }
            

            if (!IsNumber(result))
                throw new Exception();

            return result;
        }

        public static bool IsNumber(double x)
        {
            x = Math.Abs(x);
            return !(double.IsNaN(x) || double.IsInfinity(x));
        }

        public static bool IsFromZero(double x)
        {
            return IsNumber(x) && x >= 0;
        }

        public static bool IsFromZeroToMax(double x)
        {
            return IsFromZero(x) && x<=MaxIteration;
        }

        public static double MaxIteration => Math.Pow(10, 8);

        public static double Pn(double n)
        {
            return Factorial(n);
        }

        public static double Pn(params double[] n)
        {
            int length = n.Length;
            double result = Pn(n[0]);
            for(int i = 1; i < length;i++)
            {
                double p = Pn(n[i]);
                if (p == 0)
                    throw new Exception();
                result /= p;
            }
            return result;
        }

        public static double p(double m, double n)
        {
            return n / m;
        }



        public static double Pk(double k, double n, double p)
        {
            return Cn(k, n) * Pow(p, k) + Pow(1 - p, n - k);
        }

        public static double Am(double n, double m)
        {
            double p = Pn(n - m);
            if (p == 0)
                throw new Exception();
            return Pn(n) / p;
        }

        public static double Ak(double k, double n)
        {
            return Pow(n, k);
        }

        public static double Cn(double m, double n)
        {
            double p = Pn(m);
            if(p == 0)
                throw new Exception();
            return Am(m, n) / p;
        }

        public static double Ck(double k, double n)
        {
            return Cn(k, k + n - 1);
        }

        public static double Sqrt(double x)
        {
            if (x < 0)
                throw new Exception();
            return Sqrt(x, 2);
        }

        public static double Ln(double x)
        {
            if(x <= 0)
                throw new Exception();
            return Math.Log(x);
        }

    }
}
