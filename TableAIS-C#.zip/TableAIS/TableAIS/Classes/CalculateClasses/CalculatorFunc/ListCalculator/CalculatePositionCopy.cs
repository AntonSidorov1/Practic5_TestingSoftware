﻿namespace TableAIS
{
    public class CalculatePositionCopy
    {
        string b, a;

        public string B { get => b; set => b = value; }
        public string A { get => a; set => a = value; }

        public CalculatePositionCopy(string b, string a)
        {
            B = b;
            A = a;
        }

        public CalculatePositionCopy() : this("0", "0")
        {

        }

        public string GetCalculation()
        {
            return B + " = " + A;
        }

        public override string ToString()
        {
            return GetCalculation();
        }

        public CalculatePositionCopy GetThis()
        {
            return this;
        }
    }
}
