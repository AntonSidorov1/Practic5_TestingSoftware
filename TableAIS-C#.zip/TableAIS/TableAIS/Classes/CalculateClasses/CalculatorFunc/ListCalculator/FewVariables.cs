﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class FewVariables
    {


        public string B, A, Buffer, Help;

        public FewVariables() : this("0", "0", "0", "0")
        {
        }



        public FewVariables(string b, string a, string buffer, string help)
        {
            SetByFewObject(b, a, buffer, help);
        }

        public FewVariables(FewVariables variables):this()
        {
            SetByFewObject(variables);
        }

        public static FewVariables Get(FewVariables variables)
        {
            return new FewVariables(variables);
        }

        public static FewVariables Get(string b, string a, string buffer, string help)
        {
            return new FewVariables(b, a, buffer, help);
        }

        public FewVariables SetByFewObject(FewVariables variables)
        {
            return SetByFewObject(variables.B, variables.A, variables.Buffer, variables.Help);
        }

        public FewVariables SetByFewObject(string b, string a, string buffer, string help)
        {
            B = b;
            A = a;
            Buffer = buffer;
            Help = help;
            return this;
        }

        public FewVariables Copy()
        {
            return Get(this); 
        }

        public FewVariables CopyWithCorrect()
        {
            FewVariables fewVariables = new FewVariables();
            if (A == null)
                A = "";
            if (B == null)
                B = "";
            if (Buffer == null)
                Buffer = "";
            if (Help == null)
                Help = null;

            String b = B;
            if (b.Length > 0 && !MyCalculate.DoubleTryParse(b))
            {
                try
                {
                    b = MyCalculate.ReplaceToFullFuncsCodeInteractive(b).ToString();
                }
                catch (Exception e)
                {
                }
            }

            String help = Help;
            if (help.Length > 0 && !MyCalculate.DoubleTryParse(help))
            {
                try
                {
                    help = MyCalculate.ReplaceToFullFuncsCodeInteractive(help).ToString();
                }
                catch (Exception e)
                {
                }
            }

            fewVariables.B = "(" + (b.Length > 0 ? b : "0") + ")";
            fewVariables.A = "(" + (A.Length > 0 && DoubleTryParse(A) ? A : "0") + ")";
            fewVariables.Buffer = "(" + (Buffer.Length > 0 && DoubleTryParse(Buffer) ? Buffer : "0") + ")";
            fewVariables.Help = "(" + (help.Length > 0 ? help : "0") + ")";

            return fewVariables;
        }


        public static bool DoubleTryParse(String text)
        {
            try
            {
                MyCalculate.ToDouble(text);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
    }
}
