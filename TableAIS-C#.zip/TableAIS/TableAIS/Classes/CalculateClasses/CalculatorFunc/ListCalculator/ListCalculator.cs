﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Калькулятор-список
    /// </summary>
    public class ListCalculator : List<PositionCalculate>
    {
        public ListCalculator()
        {
        }

        public ListCalculator(int capacity) : base(capacity)
        {
        }

        public ListCalculator(IEnumerable<PositionCalculate> collection) : base(collection)
        {
        }


        public Func<FewVariables> GetFewVariables;

        public int LastIndex => Count - 1;

        public new void Add(PositionCalculate calculate)
        {
            base.Add(calculate);
            try
            {
                calculate.GetFewVariables = () =>
                    {
                        try
                        {
                            return GetFewVariables?.Invoke() ?? null;
                        }
                        catch
                        {
                            return null;
                        }
                    };
            }
            catch
            {

            }
        }

        public int AddByJson(string json)
        {
            PositionCalculate calculate = new PositionCalculate(json);
            Add(calculate);
            return LastIndex;
        }

        public int AddCopy(PositionCalculate calculate)
        {
            return AddByJson(calculate.GetJsonText());
        }

        public int AddCopyByIndex(int index)
        {
            return AddCopy(this[index]);
        }

        public int AddCopyByIndexWithAToB(int index)
        {
            int index1 = AddCopyByIndex(index);
            Get(index1).CopyAB();
            return index1;
        }

        public int AddCopyByIndexWithCalcBToB(int index)
        {
            int index1 = AddCopyByIndex(index);
            Get(index1).CalculateToB();
            return index1;
        }

        public int AddByJson(JsonObject json)
        {
            PositionCalculate calculate = new PositionCalculate(json);
            Add(calculate);
            return LastIndex;
        }

        public int AddByFile(string path)
        {
            PositionCalculate calculate = PositionCalculate.CreateByFile(path);
            Add(calculate);
            return LastIndex;
        }

        public int Add()
        {
            PositionCalculate calculate = new PositionCalculate();
            Add(calculate);
            return LastIndex;
        }

        public int Add(string formule, string result)
        {
            PositionCalculate calculate = new PositionCalculate(formule, result);
            Add(calculate);
            return LastIndex;
        }

        public int AddAndGetIndex(PositionCalculate calculate)
        {
            Add(calculate);
            return LastIndex;
        }

        public PositionCalculate AddWithGet()
        {
            return this[Add()];
        }

        public PositionCalculate AddWithGet(string formule, string result)
        {
            return this[Add(formule, result)];
        }

        public PositionCalculate AddWithGet(PositionCalculate pos)
        {
            return this[AddAndGetIndex(pos)];
        }

        public JsonArray ToJsonArray()
        {
            JsonArray array = new JsonArray();
            for(int i = 0; i < Count; i++)
            {
                array.Add(this[i].GetJson());
            }
            return array;
        }

        public string ToJsonArrayText() => ToJsonArray().ToString();

        public void ToFile(string path) => File.WriteAllText(path, ToJsonArrayText());

        public int AddArrayByJson(JsonArray array)
        {
            int index = 0;

            int count = array.Count;
            for(int i = 0; i < count; i++)
            {
                index = AddByJson((JsonObject)array[i]);
            }

            return index;
        }

        public int AddArrayByJson(string json)
        {
            return AddArrayByJson((JsonArray)JsonNode.Parse(json));
        }


        public int AddArrayByFile(string path)
        {
            return AddArrayByJson(File.ReadAllText(path));
        }

        public int AddArrayByFile(string[] path)
        {
            int index = 0;
            for(int i = 0; i< path.Length; i++)
            {
                index = AddArrayByFile(path[i]);
            }
            return index;
        }

        public int SetByFile(string[] path)
        {
            int index = SetByFile(path[0]);
            for (int i = 1; i < path.Length; i++)
            {
                index = AddArrayByFile(path[i]);
            }
            return index;
        }

        public int SetByJson(string json)
        {
            Clear();
            return AddArrayByJson(json);
        }

        public int SetByFile(string path)
        {
            return SetByJson(File.ReadAllText(path));
        }


        public static string[] GetFiltersJson => new string[] { "Calculate List | *.clist", "Calculator File | *.calc" };

        public static string[] GetAllFultersJson()
        {
            List<string> filters = new List<string>();

            List<string> partsFilters = new List<string>();
            string[] partsParts = GetFiltersJson;

            for (int i = 0; i < partsParts.Length; i++)
            {
                string[] parts = partsParts[i].Split('|');
                string ext = parts[1].Trim();
                partsFilters.Add(ext);
                filters.Add(parts[0] + " ( " + ext + ") |" + ext);

            }
            string filter = string.Join(";", partsFilters.ToArray());
            filters.Add("All Calculator Filters (" + filter + ")|" + filter);
            string json = "*.json";
            partsFilters.Add(json);
            filters.Add("Json File (" + json + ")|" + json);
            filter = string.Join(";", partsFilters.ToArray());
            filters.Add("All Json Filters (" + filter + ")|" + filter);
            string txt = "*.txt";
            partsFilters.Add(txt);
            filters.Add("Json File (" + txt + ")|" + txt);
            txt = "*.stxt";
            partsFilters.Add(txt);
            filters.Add("Json File (" + txt + ")|" + txt);
            filter = string.Join(";", partsFilters.ToArray());
            filters.Add("All Filters (" + filter + ")|" + filter);
            filters.Add("All Files (*.*)|*.*");
            return filters.ToArray();
        }

        public static string GetFilter()
        {
            return string.Join("|", GetAllFultersJson());
        }

        public string FileFilter => GetFilter();

        public PositionCalculate Get(int index)
        {
            return this[index];
        }

    }
}
