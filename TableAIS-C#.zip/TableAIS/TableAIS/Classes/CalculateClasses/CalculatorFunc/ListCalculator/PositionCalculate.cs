﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Позиция в листовом калькуляторе
    /// </summary>
    public partial class PositionCalculate
    {
        public PositionCalculate() : this("0", "0")
        {
        }

        public PositionCalculate(string formule, string result) : this(0, formule, result)
        {

        }

        public PositionCalculate(int number, string formule, string result)
        {
            Formule = formule;
            Result = result;
            Number = number;
            Help = "";
            Buffer = "";
            AutoReact = true;
            AutoCalculate = true;
            EnterCalculate = true;
        }

        public PositionCalculate(string json) : this()
        {
            SetJson(json);
        }

        public PositionCalculate(JsonObject json) : this()
        {
            SetJson(json);
        }

        public PositionCalculate(int number) : this(0, "0", "0")
        {

        }

        int number;

        /// <summary>
        /// Позиция в списке
        /// </summary>
        public int Number
        {
            get => number; set => number = value;
        }

        string formule;

        /// <summary>
        /// Выражение для расчёта
        /// </summary>
        public string Formule
        {
            get => formule;
            set => formule = value;
        }

        public string B
        {
            get => Formule;
            set => Formule = value;
        }

        string result;

        /// <summary>
        /// Результат вычислений (Значение выражения)
        /// </summary>
        public string Result
        {
            get => result;
            set => result = value;
        }

        public string A
        {
            get => Result;
            set => Result = value;
        }

        public PositionCalculate CopyAB()
        {
            try
            {
                string a = A;
                a = a.Length > 0 ? a : "0";
                B = a;
            }
            catch { }
            return this;

        }

        string buffer, help;

        public string Buffer
        {
            get => buffer;
            set => buffer = value;
        }

        public string Help
        {
            get => help;
            set => help = value;
        }


        /// <summary>
        /// Отображение функции
        /// </summary>
        public string View => FormuleWithChangeBaskets + " = " + Result;

        public string FormuleWithChangeBaskets => MyCalculate.ChangeBaskets(B);

        public PositionCalculate ChangeBaskets()
        {
            B = MyCalculate.ReplaceToFullFuncsCodeInteractive(B);
            //B = MyCalculate.ChangeBaskets(B);
            return this;
        }

        public PositionCalculate AddBaskets()
        {
            B = MyCalculate.AddBasketsInteractive(B);
            //ChangeBaskets();
            //B = "(" + B + ")";
            return this;
        }



        public PositionCalculate DropBaskets()
        {
            B = MyCalculate.DropBasketsInteractive(B);
            return this;
        }

        public PositionCalculate DropVariables()
        {
            FewVariables variables = new FewVariables();
            try
            {
                variables = variables.SetByFewObject(GetFewVariables?.Invoke());
            }
            catch (Exception ex)
            {

            }

            B= MyCalculate.ReplaceByOpenConst(B, A, Help, Buffer, GetFewVariables?.Invoke());
            return this;


            PositionCalculate positionCalculate = ChangeBaskets();
            positionCalculate = positionCalculate.DropFewVariables(variables);
            string b = MyCalculate.FuncViewChange(B, A, Buffer, Help);
            string formuleB = MyCalculate.FuncViewChange(B, A, Buffer, Help, "0");
            b = b.ToLower().Replace("b", MyCalculate.AddBaskets(formuleB));
            positionCalculate.B = b;
            return positionCalculate;
        }



        /// <inheritdoc/>

        public override string ToString()
        {
            return View;
        }

        bool autoCalculate;

        public bool AutoCalculate
        {
            get => autoCalculate;
            set => autoCalculate = value;
        }

        bool enterCalculate;

        public bool EnterCalculate
        {
            get => enterCalculate;
            set => enterCalculate = value;
        }

        public bool AutoCalc => AutoCalculate && AutoReact;

        bool autoReact;

        public bool AutoReact
        {
            get => autoReact;
            set => autoReact = value;
        }

        public PositionCalculate SetB(string formule)
        {
            try
            {
                B = formule;
                if (AutoCalc)
                {
                    try
                    {
                        CalculateB();
                    }
                    catch
                    {
                        A = "";
                    }
                }
            }
            catch { }
            return this;
        }

        public static double Calculate(string formule, string numberA, string numberBuffer, string numberHelp, string formulB)
        {
            return formule == "" ? 0 : MyCalculate.CalculateWithB(formule, numberA, numberBuffer, numberHelp, formulB);
        }

        public static double Calculate(string formule, string numberA, string numberBuffer, string numberHelp)
        {
            return Calculate(formule, numberA, numberBuffer, numberHelp, formule);
        }

        public double Calculate(string formule)
        {
            return MyCalculate.CalculateConvertToPostphics(formule, this, GetFewVariables?.Invoke());
            try
            {
                string formuleB = DropFewVariables(B, GetFewVariables?.Invoke());
                return Calculate(formule, A, Buffer, Help, formuleB);
            }
            catch
            {
                return Calculate(formule, A, Buffer, Help);
            }
        }

        public double CalculateInteractive(string formule, string a, string buffer, string help, FewVariables variables)
        {
            double ret = 0;
            ret = MyCalculate.CalculateConvertToPostphics(formule, a, buffer, help, variables);

            return ret;
        }

        public double CalculateInteractiveB(string a, string buffer, string help, FewVariables variables)
        {
            return CalculateInteractive(B, a, buffer, help, variables);
        }

        public double CalculateInteractiveB(FewVariables few)
        {
            return CalculateInteractiveB(A, Buffer, Help, few);
        }

        public double CalculateInteractiveB()
        {
            return CalculateInteractiveB(GetFewVariables?.Invoke());
        }

        public PositionCalculate CalculateB()
        {
            try
            {
                try
                {
                    A = CalculateInteractiveB().ToString();
                    //CalculateBWithFew(GetFewVariables?.Invoke());
                }
                catch
                {
                    A = CalculateInteractiveB(new FewVariables()).ToString();
                    //A = (Calculate(B)).ToString();
                }
            }
            catch
            {
                A = "";
            }
            return this;
        }

        

        public PositionCalculate CalculateToB()
        {
            string b = B;
            try
            {
                try
                {
                    B = CalculateInteractiveB().ToString();
                    //CalculateToBWithFew(GetFewVariables?.Invoke());
                }
                catch
                {
                    B = CalculateInteractiveB(new FewVariables()).ToString();
                    //B = (Calculate(B)).ToString();
                }
            }
            catch
            {
               B = b;
            }
            return this;
        }

        public PositionCalculate CalculateToBWithFew(FewVariables variables)
        {
            CalculateToBWithFew(variables.A, variables.Buffer, variables.Help, variables.B);
            return this;
        }

        public PositionCalculate CalculateToBWithFew(string numberA, string numberBuffer, string numberHelp, string formuleB)
        {
            string b = B;
            try
            {
                B = (CalculateWithFew(B, numberA, numberBuffer, numberHelp, formuleB)).ToString();
            }
            catch
            {
                B = b;
            }
            return this;
        }

        public PositionCalculate CalculateBWithFew(FewVariables variables)
        {
            CalculateBWithFew(variables.A, variables.Buffer, variables.Help, variables.B);
            return this;
        }

        public PositionCalculate CalculateBWithFew(string numberA, string numberBuffer, string numberHelp, string formuleB)
        {
            try
            {
                A = (CalculateWithFew(B, numberA, numberBuffer, numberHelp, formuleB)).ToString();
            }
            catch
            {
                A = "";
            }
            return this;
        }

        public static string CorrectFormule(string formule)
        {
            try
            {
                formule = formule.Trim();
                formule = formule.Length > 0 ? formule : "0";
                return formule;
            }
            catch
            {
                return 0.ToString();
            }
        }

        public PositionCalculate OpenConsts()
        {
            B = MyCalculate.ReplaceByOpenConst(B);
            return this;
        }

        public PositionCalculate OpenVariables()
        {
            B = MyCalculate.ReplaceByOpenVariables(B, A, Help, Buffer, GetFewVariables?.Invoke());
            return this;
        }

        public PositionCalculate DropFewVariables(string numberA, string numberBuffer, string numberHelp, string formuleB)
        {
            B = MyCalculate.ReplaceByOpenConst(B, numberA, numberHelp, numberBuffer, GetFewVariables?.Invoke());
            //B = DropFewVariables(B, numberA, numberBuffer, numberHelp, formuleB);
            return this;
        }

        public PositionCalculate DropFewVariables(FewVariables variables)
        {
            return DropFewVariables(variables.A, variables.Buffer, variables.Help, variables.B);
        }

        public static string DropFewVariables(string formule, FewVariables variables)
        {
            return DropFewVariables(formule, variables.A, variables.Buffer, variables.Help, variables.B);
        }

        public string DropFewVariables(string formule)
        {
            try
            {
                return DropFewVariables(formule, GetFewVariables?.Invoke());
            }
            catch 
            {
                return formule;
            }
        }

        public static string DropFewVariables(string formule, string numberA, string numberBuffer, string numberHelp, string formuleB)
        {
            formuleB = MyCalculate.ChangeBaskets(formuleB).Trim();
            numberHelp = MyCalculate.ChangeBaskets(numberHelp).Trim();
            formuleB = CorrectFormule(formuleB);
            numberA = CorrectFormule(numberA);
            numberBuffer = CorrectFormule(numberBuffer);
            numberHelp = CorrectFormule(numberHelp);
            formule = MyCalculate.ChangeBaskets(formule);
            formule = formule.ToLower()
                .Replace("@b", "(" + formuleB + ")")
                .Replace("@help", "(" + numberHelp + ")")
                .Replace("@a", "(" + numberA + ")")
                .Replace("@buffer", "@bufer")
                .Replace("@bufer", numberBuffer);
            return MyCalculate.ChangeBaskets(formule).Trim().ToLower();
        }


        public string CalculateWithFew(string formule, FewVariables variables)
        {
            return CalculateWithFew(formule, variables.A, variables.Buffer, variables.Help, variables.B);
        }

        public string CalculateWithFew(string formule)
        {
            return CalculateWithFew(formule, GetFewVariables?.Invoke());
        }

        public string CalculateWithFew(string formule, string numberA, string numberBuffer, string numberHelp, string formuleB)
        {
            return MyCalculate.CalculateConvertToPostphics(formule, GetFewVariablesPos(), new FewVariables(formuleB, numberA, numberBuffer, numberHelp)).ToString();
            formule = DropFewVariables(formule, numberA, numberBuffer, numberHelp, formuleB);
            return (Calculate(formule)).ToString();
        }

        public Func<FewVariables> GetFewVariables;

        public JsonObject GetJson()
        {
            JsonObject json = new JsonObject
            {
                { "B", B },
                { "A", A },
                { "Buffer", Buffer },
                { "Help", Help }
            };
            return json;
        }

        public string GetJsonText()
        {
            return GetJson().ToString();
        }

        public PositionCalculate SetJson(string json)
        {
            return SetJson((JsonObject)JsonNode.Parse(json.ToLower()));
        }

        public void ToFile(string path)
        {
            File.WriteAllText(path.ToLower().Trim(), GetJsonText());
        }

        public PositionCalculate SetByFile(string path)
        {
            return SetJson(File.ReadAllText(path));
        }

        public static PositionCalculate CreateByFile(string path)
        {
            PositionCalculate positionCalculate = new PositionCalculate();
            positionCalculate.SetByFile(path);
            return positionCalculate;
        }

        public PositionCalculate SetJson(JsonObject json)
        {
            AutoReact = false;

            json = (JsonObject)JsonNode.Parse(json.ToString().ToLower());

            try
            {
                B = json["b"].AsValue().ToString();
            }
            catch { }

            try
            {
                B = json["input"].AsValue().ToString();
            }
            catch { }

            try
            {
                A = json["a"].AsValue().ToString();
            }
            catch { }

            try
            {
                A = json["output"].AsValue().ToString();
            }
            catch { }

            try
            {
                Buffer = json["buffer"].AsValue().ToString();
            }
            catch { }
            try
            {
                Buffer = json["bufer"].AsValue().ToString();
            }
            catch { }

            try
            {
                Help = json["help"].AsValue().ToString();
            }
            catch { }
            AutoReact = true;
            return this;
        }


        public static string[] GetFiltersJson => new string[] {"Calculate Position | *.cpos", "Calculator File | *.calc" };

        public static string[] GetAllFultersJson()
        {
            List<string> filters = new List<string>();

            List<string> partsFilters = new List<string>();
            string[] partsParts = GetFiltersJson;

            for(int i = 0; i<partsParts.Length; i++)
            {
                string[] parts = partsParts[i].Split('|');
                string ext = parts[1].Trim();
                partsFilters.Add(ext);
                filters.Add(parts[0] + " ( "+ext+") |"+ext);

            }
            string filter = string.Join(";", partsFilters.ToArray());
            filters.Add("All Calculator Filters (" + filter + ")|" + filter);
            string json = "*.json";
            partsFilters.Add(json);
            filters.Add("Json File (" + json + ")|" + json);
            filter = string.Join(";", partsFilters.ToArray());
            filters.Add("All Json Filters (" + filter + ")|" + filter);
            string txt = "*.txt";
            partsFilters.Add(txt);
            filters.Add("Json File (" + txt + ")|" + txt);
            txt = "*.stxt";
            partsFilters.Add(txt);
            filters.Add("Json File (" + txt + ")|" + txt);
            filter = string.Join(";", partsFilters.ToArray());
            filters.Add("All Filters (" + filter + ")|" + filter);
            filters.Add("All Files (*.*)|*.*");
            return filters.ToArray();
        }

        public static string GetFilter()
        {
            return string.Join("|", GetAllFultersJson());
        }

        public string FileFilter => GetFilter();

        public FewVariables GetFewVariablesPos() => new FewVariables(B, A, Buffer, Help);

        public double CalculateByThis(string formule, char variable = '\0')
        {
            return MyCalculate.CalculateConvertToPostphics(formule, this, GetFewVariables?.Invoke(), variable);
        }


        public CalculatePositionCopy GetCopyB()
        {
            return new CalculatePositionCopy(B, CalculateInteractiveB().ToString());
        }

        public PositionCalculate SetBByPastWithB(CalculatePositionCopy calculate)
        {
            B = calculate.B;
            return this;
        }

        public PositionCalculate SetBByPastWithA(CalculatePositionCopy calculate)
        {
            B = calculate.A;
            return this;
        }

    }
}
