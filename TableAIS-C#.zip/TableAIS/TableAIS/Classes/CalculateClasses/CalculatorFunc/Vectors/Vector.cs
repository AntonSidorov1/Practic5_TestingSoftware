﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace TableAIS
{
    /// <summary>
    /// Вектор в трёхмерном пространстве
    /// </summary>
    public class Vector
    {
        public Vector() : this(0, 0, 0)
        {
        }

        public Vector(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }

        double x, y, z;

        /// <summary>
        /// Координата X
        /// </summary>
        public double X
        {
            get => x;
            set => x = value;
        }

        /// <summary>
        /// Координата Y
        /// </summary>
        public double Y
        {
            get => y;
            set => y = value;
        }


        /// <summary>
        /// Координата Z
        /// </summary>
        public double Z
        {
            get => z;
            set => z = value;
        }

        /// <summary>
        /// Умножение вектора на число
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static Vector Mull(Vector vector, double number)
        {
            return new Vector
            {
                X = vector.X * number,
                Y = vector.Y * number,
                Z = vector.Z * number
            };
        }

        /// <summary>
        /// Прибавление к вектору числа
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static Vector Add(Vector vector, double number)
        {
            return new Vector
            {
                X = vector.X + number,
                Y = vector.Y + number,
                Z = vector.Z + number
            };
        }

        /// <summary>
        /// Уменьшение вектора на число
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static Vector Sub(Vector vector, double number)
        {
            return vector + (-number);
        }

        /// <summary>
        /// Деление вектора на число
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static Vector Div(Vector vector, double number)
        {
            return new Vector
            {
                X = vector.X / number,
                Y = vector.Y / number,
                Z = vector.Z / number
            };
        }

        /// <summary>
        /// Перемножение координат векторов
        /// </summary>
        /// <returns></returns>
        public static Vector MullCoords(Vector vector1, Vector vector2)
        {
            return new Vector
            {
                X = vector1.X * vector2.X,
                Y = vector1.Y * vector2.Y,
                Z = vector1.Z * vector2.Z
            };
        }

        /// <summary>
        /// Деление координат векторов
        /// </summary>
        /// <returns></returns>
        public static Vector DivCoords(Vector vector1, Vector vector2)
        {
            if (vector2.X * vector2.Y * vector2.Z == 0)
                throw new Exception();
            return new Vector
            {
                X = vector1.X / vector2.X,
                Y = vector1.Y / vector2.Y,
                Z = vector1.Z / vector2.Z
            };
        }

        /// <summary>
        /// Сумма координат вектора
        /// </summary>
        /// <returns></returns>
        public double SumCoords()
        {
            return X + Y + Z;
        }

        /// <summary>
        /// Скалярное произведение векторов
        /// </summary>
        /// <param name="vector1"></param>
        /// <param name="vector2"></param>
        /// <returns></returns>
        public static double MullScalar(Vector vector1, Vector vector2)
        {
            return MullCoords(vector1, vector2).SumCoords();
        }

        /// <summary>
        /// Скалярное произведение векторов
        /// </summary>
        /// <param name="vector1"></param>
        /// <param name="vector2"></param>
        /// <returns></returns>
        public static double operator *(Vector vector1, Vector vector2)
        {
            return MullScalar(vector1, vector2);
        }

        /// <summary>
        /// Длина вектора
        /// </summary>
        /// <returns></returns>
        public double Length()
            => Math.Sqrt(this * this);

        /// <summary>
        /// Умножение вектора на число
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static Vector operator *(Vector vector, double number)
        {
            return Mull(vector, number);
        }

        /// <summary>
        /// Прибавление к вектору числа
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static Vector operator +(Vector vector, double number)
        {
            return Add(vector, number);
        }

        public static Vector operator ++(Vector vector)
        {
            return vector + 1;
        }

        public static Vector operator --(Vector vector)
        {
            return vector - 1;
        }


        /// <summary>
        /// Уменьшение вектора на число
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static Vector operator -(Vector vector, double number)
        {
            return Sub(vector, number);
        }

        /// <summary>
        /// Деление вектора на число
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static Vector operator /(Vector vector, double number)
        {
            return Div(vector, number);
        }

        /// <summary>
        /// Умножение вектора на число
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static Vector operator *(double number, Vector vector)
        {
            return Mull(vector, number);
        }


        /// <summary>
        /// Противоположный вектор
        /// </summary>
        /// <param name="vector"></param>
        /// <returns></returns>
        public static Vector Opposite(Vector vector)
        {
            return vector * (-1);
        }


        /// <summary>
        /// Противоположный вектор
        /// </summary>
        /// <param name="vector"></param>
        /// <returns></returns>
        public static Vector operator -(Vector vector)
        {
            return Opposite(vector);
        }

        /// <summary>
        /// Тот же вектор
        /// </summary>
        /// <param name="vector"></param>
        /// <returns></returns>
        public static Vector operator +(Vector vector)
        {
            return vector;
        }

        /// <summary>
        /// Сложение двух векторов
        /// </summary>
        /// <param name="vector1"></param>
        /// <param name="vector2"></param>
        /// <returns></returns>
        public static Vector Add(Vector vector1, Vector vector2)
        {
            Vector vector = new Vector()
            {
                X = vector1.X + vector2.X,
                Y = vector1.Y + vector2.Y,
                Z = vector1.Z + vector2.Z
            };
            return vector;
        }

        /// <summary>
        /// Вычитание двух векторов
        /// </summary>
        /// <param name="vector1"></param>
        /// <param name="vector2"></param>
        /// <returns></returns>
        public static Vector Mines(Vector vector1, Vector vector2)
        {
            return vector1 + (-vector2);
        }

        /// <summary>
        /// Вычитание двух векторов
        /// </summary>
        /// <param name="vector1"></param>
        /// <param name="vector2"></param>
        /// <returns></returns>
        public static Vector operator -(Vector vector1, Vector vector2)
        {
            return Mines(vector1, vector2);
        }


        /// <summary>
        /// Сложение двух векторов
        /// </summary>
        /// <param name="vector1"></param>
        /// <param name="vector2"></param>
        /// <returns></returns>
        public static Vector operator +(Vector vector1, Vector vector2)
        {
            return Add(vector1, vector2);
        }

        /// <summary>
        /// Векторное произведение векторов
        /// </summary>
        /// <param name="vector1"></param>
        /// <param name="vector2"></param>
        /// <returns></returns>
        public static Vector MullVectors(Vector vector1, Vector vector2)
        {
            return new Vector()
            {
                X = vector1.Y * vector2.Z - vector2.Y * vector1.Z,
                Y = -(vector1.X * vector2.Z - vector2.X * vector1.Z),

                Z = vector1.X * vector2.Y - vector2.X * vector1.Y,

            };
        }

        /// <summary>
        /// Смешанное произведение векторов
        /// </summary>
        /// <param name="vector1"></param>
        /// <param name="vector2"></param>
        /// <param name="vector3"></param>
        /// <returns></returns>
        public static double Mull(Vector vector1, Vector vector2, Vector vector3)
        {
            return MullVectors(vector1, vector2) * vector3;
        }

        /// <summary>
        /// Отображение вектора
        /// </summary>
        /// <returns></returns>
        public string View()
        {
            return $"{{{X}; {Y}; {Z}}}";
        }

        /// <summary>
        /// Отображение вектора
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return View();
        }

        
    }
}
