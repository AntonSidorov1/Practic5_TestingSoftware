﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS
{
    public class CalculatorMemoryItem
    {
        public CalculatorMemoryItem()
        {
            Create();
        }

        public CalculatorMemoryItem(string formule) : this()
        {
            Formule = MyCalculate.ReplaceToFullFuncsCodeInteractive(formule);
        }

        public CalculatorMemoryItem(List<CalculatorMemoryItem> calculatorMemoryItems):this()
        {
            MakeNumber(calculatorMemoryItems);
        }

        public CalculatorMemoryItem(string formule, List<CalculatorMemoryItem> calculatorMemoryItems) : this(calculatorMemoryItems)
        {
            Formule = MyCalculate.ReplaceToFullFuncsCodeInteractive(formule);
        }



        public virtual void Create()
        {
            Number = "";
            Formule = "";
        }

        public static char[] SymwolCodes => CodesConvert.SymwolCodes;

        public static Random R = new Random();

        public static string MakeNumber()
        {
            string result = "";
            char[] codes = SymwolCodes;
            int length = codes.Length;
            int last = length - 1;

            for (int i = 0; i < 4; i++)
            {
                int pos = R.Next(0, length);
                while(pos > last || pos < 0)
                {
                    if (pos > last)
                        pos--;
                    else
                        pos++;
                }
                result += codes[pos];

            }

            return result;
        }

        string number;

        public string Number
        {
            get => number; set => number = value;
        }

        public string MakeNumber(List<CalculatorMemoryItem> items)
        {
            string number = "";
            
            while(number.Trim().Length<1 || items.Any(i => i.Number.ToLower().Trim() == number.ToLower().Trim()))
            {
                number = MakeNumber();
            }


            Number = number;
            return number;
        }

        string formule;

        public string Formule
        {
            get
            {
                string formule = this.formule;
                try
                {
                    if (formule.Length < 1)
                        throw new Exception();
                    return MyCalculate.ReplaceToFullFuncsCodeInteractive(formule);
                }
                catch
                {
                    return 0.ToString();
                }
            }

            set
            {
                formule = MyCalculate.ReplaceToFullFuncsCodeInteractive(value);
            }
        }

        public string FormuleAddBaskets() => MyCalculate.AddBasketsInteractive(formule);

        public string GetValue(string a, string bufer, string help) => 
            MyCalculate.CalculateConvertToPostphics(formule, a, help, bufer).ToString();
            //MyCalculate.Calculate(CalculatorString.History.ReplaceFormuleNull(Formule.ToLower().Replace("help", help)), "A", a, bufer, help).ToString();

        public string GetValueFormule(string a, string bufer, string help) =>
            MyCalculate.CalculateConvertToPostphics(formule, a, help, bufer).ToString();
        //MyCalculate.Calculate(formule, "A", a, bufer, help).ToString();

        public string Variable
        {
            get => VariableValue;
        }

        public string VariableText => VariableValueText;

        public override string ToString()
        {
            return Number +$" - \"{Formule}\"";
        }

        public string VariableValue
        {
            get => "~@" + Number;
        }

        public string VariableValueText => $"{{{VariableValue}}}";

        public string ReplaceFormule(string formule, string a, string bufer, string help)
        {
            formule = formule.ToLower();
            if (formule.Contains(VariableText.ToLower()))
                formule = formule.Trim().ToLower().Replace(VariableText.ToLower(), $"({MyCalculate.ChangeBaskets(Formule)})");
            //if (formule.Contains(VariableValueText.ToLower()))
              //  formule = formule.Trim().ToLower().Replace(VariableValueText.ToLower(), $"({GetValue(a, bufer, help)}");
            return formule;
        }

        /*
        public string ReplaceValue(string formule, string a, string bufer, string help)
        {
            formule = formule.ToLower();
            if (formule.Contains(VariableValueText.ToLower()))
                formule = formule.Trim().ToLower().Replace(VariableValueText.ToLower(), $"({GetValue(a, bufer, help)})");
            //if (formule.Contains(VariableValueText.ToLower()))
            //  formule = formule.Trim().ToLower().Replace(VariableValueText.ToLower(), $"({GetValue(a, bufer, help)}");
            return formule;
        }
        */

        public string ReplaceFormuleNull(string formule, string a, string bufer, string help)
        {
            formule = formule.ToLower();
            CalculatorString.History.ReplaceFormule(formule, a, bufer, help);
            formule = formule.Trim().ToLower().Replace(VariableText.ToLower(), VariableValueText);
            if (formule.Contains(VariableValueText.ToLower()))
                formule = formule.Trim().ToLower().Replace(VariableValueText.ToLower(), $"({GetValue(a, bufer, help)})");
            return formule;
        }

        public string ReplaceFormuleNull(string formule)
        {
            //Formule.ToLower().Replace("help", "(0)");
            formule = formule.Trim().ToLower().Replace(VariableText.ToLower(), VariableValueText);
            formule = formule.Trim().ToLower().Replace("{~M}".ToLower(), VariableValueText);
            formule = formule.Trim().ToLower().Replace(VariableValueText.ToLower(), $"({0})");
            
            return formule;
        }


        public bool IsThisIndex(string formule, int index)
        {
            string help = VariableValueText.ToLower().Trim();
            formule = formule.ToLower();
            try
            {
                int length = help.Length;
                for (int i = 0; i < length; i++)
                {
                    char sign = formule[index + i];
                    if (sign != help[i])
                    {
                        return false;
                    }
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

    }
}
