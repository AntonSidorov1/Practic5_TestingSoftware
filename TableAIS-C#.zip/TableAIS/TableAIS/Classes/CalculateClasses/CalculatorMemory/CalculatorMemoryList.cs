﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class CalculatorMemoryList : List<CalculatorMemoryItem>
    {
        public CalculatorMemoryList() : base()
        {
        }

        public CalculatorMemoryList(int capacity) : base(capacity)
        {
        }

        public CalculatorMemoryList(IEnumerable<CalculatorMemoryItem> collection) : base(collection)
        {
        }

        public CalculatorMemoryItem Add(string formule)
        {
            CalculatorMemoryItem item = new CalculatorMemoryItem(formule, this);
            Add(item);
            return item;
        }


        public CalculatorMemoryItem Insert(int index, string formule)
        {
            CalculatorMemoryItem item = new CalculatorMemoryItem(formule, this);
            Insert(index, item);
            return item;
        }

        public CalculatorMemoryItem Get(int index)
        {
            return this[index];
        }

        public string ReplaceFormule(string formule, string a, string buffer, string help)
        {
            int count = Count;
            for(int i = 0; i<count; i++)
            {
                formule = Get(i).ReplaceFormule(formule, a, buffer, help);
            }
            return formule;
        }

        public string ReplaceFormuleNull(string formule, string a, string buffer, string help)
        {
            int count = Count;
            for (int i = 0; i < count; i++)
            {
                formule = Get(i).ReplaceFormuleNull(formule, a, buffer, help);
            }
            return formule;
        }

        public string ReplaceFormuleNull(string formule)
        {
            int count = Count;
            for (int i = 0; i < count; i++)
            {
                formule = Get(i).ReplaceFormuleNull(formule);
            }
            return formule;
        }


        public List<string> VariablesList
        {
            get
            {
                List<string> list = new List<string>();

                for(int i = 0; i< Count; i++)
                {
                    list.Add(Get(i).VariableText);
                }

                return list;
            }
        }

        public string[] VariablesArray => VariablesList.ToArray();

        public string[] ToArray(string a, string buffer, string help)
        {
            List<string> list = new List<string>();
            for(int i =0; i< Count; i++)
            {
                list.Add(Get(i).GetValue(a, buffer, help));
            }
            return list.ToArray();
        }

        public string ToMass(string a, string buffer, string help)
        {
            return ";("+string.Join(";", ToArray(a, buffer, help))+")";
        }

        public CalculatorMemoryItem FindByNumber(string variableValueText)
        {
            return Find(m => m.VariableValueText.ToLower().Trim() == variableValueText.ToLower().Trim());
        }

        public int FindIndexByNumber(string variableValueText)
        {
            return FindIndex(m => m.VariableValueText.ToLower().Trim() == variableValueText.ToLower().Trim());
        }

        public List<string> GetFormulesList()
        {
            
            List<string> list = new List<string>();
            if(Count < 1)
            {
                list.Add("0");
                return list;
            }

            foreach(CalculatorMemoryItem item in this)
            {
                list.Add(item.FormuleAddBaskets());
            }

            return list;
        }

        public string[] GetFormulesArray()
        {
            return GetFormulesList().ToArray();
        }

        public string GetFormulesListText()
        {
            return ";(" + string.Join(";", GetFormulesArray()) + ")";
        }

        public static string MemoryListVariable()
        {
            return "{~M}";
        }

        public static bool IsMemoryListVariable(string formule, int index)
        {
            string m = MemoryListVariable().ToLower();
            formule = formule.ToLower();
            try
            {
                for (int i = 0; i < m.Length; i++)
                {
                    char sign = m[i];
                    char signCheck = formule[index + i];
                    if(sign != signCheck)
                        return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }

        public static CalculatorMemoryList History()
        {
            return CalculatorString.History;
        }

        public static string FormulersListText()
        {
            return History().GetFormulesListText();
        }
    }
}
