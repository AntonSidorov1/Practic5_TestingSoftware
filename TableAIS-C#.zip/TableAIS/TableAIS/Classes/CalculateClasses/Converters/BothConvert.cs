﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class BothConvert : MetrsConvert
    {
        public BothConvert() : base()
        {
        }

        public BothConvert(string name) : base(name)
        {
        }

        public override void Create()
        {
            base.Create();
            ConvertFrom = (value) => To(value);
        }

        public double RunConvert(double value)
        {
            return ConvertFrom(value);
        }

        public Func<double, double> ConvertRun
        {
            get => ConvertTo; set => ConvertTo = value;
        }
    }
}
