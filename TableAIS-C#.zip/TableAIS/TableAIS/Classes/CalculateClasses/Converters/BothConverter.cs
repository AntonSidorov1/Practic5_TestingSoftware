﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class BothConverter : ConverterList
    {
        public override void DeleteNoCondition()
        {
            base.DeleteNoCondition();
            MetrsConvertsList.RemoveAll(c => c.IsNoBoth());
        }

        public BothConverter() : base()
        {
        }

        

        public override MetrsConvert GetCreate(string name)
        {
            DeleteNoCondition();
            return new BothConvert(name);
        }

        public BothConvert AddBoth(string name)
        {
            return Add(name).AsBoth();
        }

        public double RunConvert(double value, int index)
        {
            return Get(index).AsBoth().RunConvert(value);
        }

        public double RunConvertFrom(double value)
        {
            return RunConvert(value, FromIndex);
        }

        public double RunConvertTo(double value)
        {
            return RunConvert(value, ToIndex);
        }

    }
}
