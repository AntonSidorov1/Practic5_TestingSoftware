﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Конвертер дольных и кратных единиц
    /// </summary>
    public class MullAndSubConverter : PokazatelConverter
    {
        public MullAndSubConverter() : base()
        {
            AddPokazatel("Обычные").Pokezatel = 0;
            AddPokazatel("Дольные").Pokezatel = -1;
            AddPokazatel("Кратные").Pokezatel = -1;

        }

    }
}
