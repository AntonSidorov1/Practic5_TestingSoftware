﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class NameDouble : NameConverter
    {
        double value;

        public double GetValue()
        {
            return value;
        }

        public double SetValue(double value)
        {
            this.value = value;
            return GetValue();
        }

        public double Value
        {
            get => GetValue();
            set => SetValue(value);
        }

        public NameDouble() : base()
        {
        }

        public NameDouble(string name, double value) : base(name)
        {
            Value = value;
        }

        public NameDouble( double value) : base()
        {
            Value = value;
        }

        public NameDouble(string name) : base(name)
        {
        }

        public override void Create()
        {
            base.Create();
            Value = 10;
        }
    }
}
