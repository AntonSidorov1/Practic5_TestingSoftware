﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class PokazatelConvert : BothConvert
    {
        public PokazatelConvert() : base()
        {
        }

        public PokazatelConvert(string name) : base(name)
        {
        }

        double pokezatel;

        public double Pokezatel
        {
            get => pokezatel; set => pokezatel = value;
        }

        public override void Create()
        {
            base.Create();
            Pokezatel = 0;
            ConvertRun = (value) => Math.Pow(value, Pokezatel);

        }
    }
}
