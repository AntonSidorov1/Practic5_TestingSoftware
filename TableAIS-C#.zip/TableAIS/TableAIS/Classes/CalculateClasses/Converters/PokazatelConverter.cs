﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class PokazatelConverter : BothConverter
    {
        public PokazatelConverter() : base()
        {
        }

        public override void DeleteNoCondition()
        {
            base.DeleteNoCondition();
            MetrsConvertsList.RemoveAll(c => c.IsNoStepen());
        }

        public override MetrsConvert GetCreate(string name)
        {
            DeleteNoCondition();
            return new PokazatelConvert(name);
        }

        public PokazatelConvert AddPokazatel(string name)
        {
            return AddBoth(name).AsPokazatel();
        }
    }
}
