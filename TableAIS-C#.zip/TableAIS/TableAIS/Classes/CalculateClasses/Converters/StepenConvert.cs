﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class StepenConvert : MetrsConvert
    {
        int doubleIndexFrom, doubleIndexTo;

        public int DoubleIndexFrom
        {
            get => doubleIndexFrom; set => doubleIndexFrom = value;
        }

        public int DoubleIndexTo
        {
            get => doubleIndexTo; set => doubleIndexTo = value;
        }

        public int PokazatelIndexFrom
        {
            get => PokazatelsList.FromIndex; set => PokazatelsList.FromIndex = value;
        }

        public int PokazatelIndexTo
        {
            get => PokazatelsList.ToIndex; set => PokazatelsList.ToIndex = value;
        }

        public int MullAndSubConverterIndexFrom
        {
            get => MullAndSubConverter.FromIndex; set => MullAndSubConverter.FromIndex = value;
        }

        public int MullAndSubConverterIndexTo
        {
            get => MullAndSubConverter.ToIndex; set => MullAndSubConverter.ToIndex = value;
        }

        List<NameDouble> numbers;
        PokazatelConverter pokazatels;
        public PokazatelConverter PokazatelsList => pokazatels;
        MullAndSubConverter mullAndSubConverter;
        public MullAndSubConverter MullAndSubConverter => mullAndSubConverter;

        

        public StepenConvert() : base()
        {

        }

        public StepenConvert(string name) : base(name)
        {
        }

        public override void Create()
        {
            base.Create();
            DoubleIndexFrom = 0;
            DoubleIndexTo = 0;
            numbers = new List<NameDouble>();
            pokazatels = new PokazatelConverter();
            mullAndSubConverter = new MullAndSubConverter();

        }
    }
}
