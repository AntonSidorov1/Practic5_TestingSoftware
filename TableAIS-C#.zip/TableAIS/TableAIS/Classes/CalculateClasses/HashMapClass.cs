﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class HashMapClass<ObjectType, IndexType> : StackList<IndexObject<ObjectType, IndexType>>
    {
        public HashMapClass() : base()
        {
        }

        public HashMapClass(int capacity) : base(capacity)
        {
        }

        public HashMapClass(IEnumerable<IndexObject<ObjectType, IndexType>> collection) : base(collection)
        {
        }

        public void Put(ObjectType objectResourse, IndexType index)
        {
            Put(new IndexObject<ObjectType, IndexType>(objectResourse, index));
        }

        public void put(ObjectType objectResourse, IndexType index)
        {
            Put(new IndexObject<ObjectType, IndexType>(objectResourse, index));
        }

        public IndexType GetIndex(ObjectType objectResourse)
        {
            return Find(o => o.ObjectResurse.Equals(objectResourse)).Index;
        }

        public bool Contains(ObjectType objectResourse)
        {
            return FindIndex(o => o.ObjectResurse.Equals(objectResourse)) >= 0;
        }
    }
}
