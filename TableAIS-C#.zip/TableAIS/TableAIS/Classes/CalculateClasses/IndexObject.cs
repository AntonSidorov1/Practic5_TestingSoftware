﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class IndexObject<ObjectTipe, IndexType>
    {
        public IndexObject()
        {
        }

        public IndexObject(ObjectTipe objectResourse, IndexType index)
        {
            Index = index;
            ObjectResurse = objectResourse;
        }

        IndexType index;

        public IndexType Index
        {
            get => index; set => index = value;
        }

        ObjectTipe objectResurse;

        public ObjectTipe ObjectResurse
        {
            get => objectResurse; set => objectResurse = value;
        }

        public override string ToString()
        {
            return ObjectResurse + ":" + Index;
        }
    }
}
