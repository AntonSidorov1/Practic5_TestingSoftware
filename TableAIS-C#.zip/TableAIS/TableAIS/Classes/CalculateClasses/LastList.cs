﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class LastList<T> : List<T>
    {
        public LastList() : base()
        {
            Index = 0;
        }

        int index;

        public int Index
        {
            get => index;
            set => index = value;
        }

        public T GetByIndex() => Get(index);

        public T Get(int index)
        {
            return this[index];
        }

        public T Set(int index, T value)
        {
            this[index] = value;
            return Get(index);
        }

        public int Last() => Count - 1;

        public T GetLast()
        {
            int last = Last();
            return Get(last);
        }

        public T SetLast(T value)
        {
            int last = Last();
            return Set(last, value);
        }

        public void RemoveLast()
        {
            RemoveAt(Last());
        }

        
    }
}
