﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class LastListInt : LastList<int>
    {
        public LastListInt() : base()
        {
        }

        public int Add()
        {
            Add(0);
            return GetLast();
        }

        public int LastAdd()
        {
            int item = GetLast();
            return SetLast(++item);

        }

        public int LastSub()
        {
            int item = GetLast();
            return SetLast(--item);

        }

    }
}
