﻿//using Microsoft.Office.Interop.Excel;
//using Microsoft.Office.Interop.Word;
using Microsoft.Office.Interop.Word;
using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Windows.Foundation;

namespace TableAIS
{
    public class MyCalculate
    {

        public static double CalculateConvertToPostphics(string formule, PositionCalculate variables,
                                                         PositionCalculate fewVariables, char variable = 'x')
        {
            return CalculateConvertToPostphics(formule, variables, fewVariables.GetFewVariablesPos(), variable);
        }

        public static double CalculateConvertToPostphics(string formule, PositionCalculate variables,
                                                         FewVariables fewVariables, char variable = 'x')
        {
            return CalculateConvertToPostphics(formule, variables.GetFewVariablesPos(), fewVariables, variable);
        }

        public static double CalculateConvertToPostphics(string formule, FewVariables variables,
                                                     FewVariables fewVariables, char variable = 'x')
        {
            return CalculateConvertToPostphics(formule, variables.A, variables.B, variables.Help, variables.Buffer,
                    fewVariables.A, fewVariables.B, fewVariables.Help, fewVariables.Buffer, variable);
        }

        public static FuncList GetFuncs()
        {
            return ValueHelper.GetFuncsList();
        }

        public static string GetStringNumber(string formule, int positions)
        {
            String strNumber = "";
            bool hasDot = false;
            int length = formule.Length;
            for (int i = positions; i < length; i++)
            {
                char symwol = formule[i];
                if (symwol == ' ')
                {
                    strNumber += " ";
                    continue;
                }

                if (symwol == ',' || symwol == '.')
                {
                    if (i == positions)
                    {

                        strNumber += "0";

                    }
                    if (hasDot)
                    {
                        break;
                    }
                    else
                    {
                        strNumber += ",";
                    }
                }
                else if (char.IsDigit(symwol))
                {
                    strNumber += symwol;
                }
                else
                {
                    break;
                }
            }
            string result = strNumber;
            return result;
        }

        public static string ReplaceToFullFuncsCode(string formule)
        {
            return GetFuncs().ReplaseToCode(formule);
        }

        public static FormulePartList ReplaceByOpenConst(string formule, char variable = '\0')
        {
            FormulePartList formuleParts = ReplaceToFullFuncsCodeInteractive(formule, variable);
            formuleParts = OpenConst(formuleParts);
            return formuleParts;
        }

        public static bool IsHelp(string formule, int index)
        {
            string help = "help";
            formule = formule.ToLower();
            try
            {
                for (int i = 0; i < 4; i++)
                {
                    char sign = formule[index + i];
                    if (sign != help[i])
                    {
                        return false;
                    }
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        public static bool IsBuffer(string formule, int index)
        {
            string help = "buffer";
            formule = formule.ToLower();
            try
            {
                for (int i = 0; i < 4; i++)
                {
                    char sign = formule[index + i];
                    if (sign != help[i])
                    {
                        return false;
                    }
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        public static bool IsBufer(string formule, int index)
        {
            string help = "bufer";
            formule = formule.ToLower();
            try
            {
                for (int i = 0; i < 4; i++)
                {
                    char sign = formule[index + i];
                    if (sign != help[i])
                    {
                        return false;
                    }
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        public static bool IsFxX(string formule, int index)
        {
            string help = "{~X}";
            help = help.ToLower();
            formule = formule.ToLower();
            formule = formule.ToLower();
            try
            {
                for (int i = 0; i < 4; i++)
                {
                    char sign = formule[index + i];
                    if (sign != help[i])
                    {
                        return false;
                    }
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        public static bool IsMemory(string formule, int index)
        {
            return CalculatorMemoryList.IsMemoryListVariable(formule, index);
            string help = "{~M}";
            help = help.ToLower();
            formule = formule.ToLower();
            formule = formule.ToLower();
            try
            {
                for (int i = 0; i < 4; i++)
                {
                    char sign = formule[index + i];
                    if (sign != help[i])
                    {
                        return false;
                    }
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        public static bool IsFxY(string formule, int index)
        {
            string help = "{~Y}";
            help = help.ToLower();
            formule = formule.ToLower();
            formule = formule.ToLower();
            try
            {
                for (int i = 0; i < 4; i++)
                {
                    char sign = formule[index + i];
                    if (sign != help[i])
                    {
                        return false;
                    }
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        public static FormulePartList OpenConst(FormulePartList list)
        {
            FormulePartList partList = new FormulePartList();

            int count = list.Count;
            for (int i = 0; i < count; i++)
            {
                try
                {
                    FormulePart part = list[i];
                    if (part.IsExp)
                    {
                        if (i == 0)
                        {
                            partList.AddOpenBasket(false);
                            partList.Add(new FormuleNumber(Math.E));
                            partList.AddCloseBasket(false);
                            continue;
                        }
                        else
                        {
                            int j = i - 1;
                            FormulePart partTest = list[j];
                            if (partTest.IsOpenBasket)
                            {
                                partList.AddOpenBasket(false);
                                partList.Add(new FormuleNumber(Math.E));
                                partList.AddCloseBasket(false);
                                continue;
                            }
                            else if (partTest.IsArraySplit)
                            {
                                partList.AddOpenBasket(false);
                                partList.Add(new FormuleNumber(Math.E));
                                partList.AddCloseBasket(false);
                                continue;
                            }
                            else if (partTest.IsOperation && !partTest.IsExp)
                            {
                                FormuleOperation func = partTest.AsOperation;
                                if (func.IsFunction)
                                {
                                    if (func.AsFunction.Function.IsConst())
                                    {
                                        partList.Add(part.Copy());
                                        continue;
                                    }
                                }
                                if (func.AllowReal)
                                {
                                    partList.AddOpenBasket(false);
                                    partList.Add(new FormuleNumber(Math.E));
                                    partList.AddCloseBasket(false);
                                    continue;
                                }
                            }
                        }
                    }
                    else if (part.IsFunction)
                    {
                        FuncNames func = part.AsFunction.Function;
                        if (func.IsConst())
                        {
                            partList.AddOpenBasket(false);
                            partList.Add(new FormuleNumber(func.AsConst().Number));
                            partList.AddCloseBasket(false);
                            continue;
                        }
                    }
                    partList.Add(part.Copy());
                }
                catch
                {

                }
            }

            return partList;
        }

        public static FormulePartList AddBasketsInteractive(String formule, char variable = '\0')
        {
            FormulePartList formuleParts = ReplaceToFullFuncsCodeInteractive(formule, variable);
            formuleParts.Insert(0, new FormuleOpenBasket(false));
            formuleParts.Add(new FormuleCloseBasket(false));
            return formuleParts;
        }

        public static FormulePartList DropBasketsInteractive(String formule, char variable = '\0')
        {
            FormulePartList parts = ReplaceToFullFuncsCodeInteractive(formule, variable);

            int open = 0;
            if (parts.Count < 1)
                return parts;
            if (!parts[0].IsOpenBasket)
                return parts;
            open++;
            int count = parts.Count;
            int last = count - 1;
            for (int i = 1; i < count; i++)
            {
                if (parts[i].IsOpenBasket)
                    open++;
                if (parts[i].IsCloseBasket)
                    open--;
                if (open < 0)
                    return parts;
                if (open == 0 && i < last)
                    return parts;
            }
            if (open == 0)
            {
                parts.RemoveAt(0);
                parts.RemoveLast();
            }

            return parts;
        }

        public static FormulePartList ReplaceToFullFuncsCodeInteractive(String formule, char variable = '\0')
        {
            VariablesList memory = new VariablesList();
            memory.DogCount = 3;
            CalculatorMemoryList memoryList = CalculatorString.History;
            for (int i = 0; i < memoryList.Count; i++)
            {
                memory.Add(memoryList[i].VariableValueText);
            }
            VariablesList variables = new VariablesList();
            variables.Add("@help");
            variables.Add("@buffer");
            variables.Add("@bufer");
            variables.Add("@b");
            variables.Add("@a");
            variables.Add("help");
            variables.Add("buffer");
            variables.Add("bufer");
            variables.Add("{~X}");
            variables.Add("{~Y}");
            variables.Add("{~M}");

            formule = formule.Replace("`", "°");
            formule = formule.Replace("''", "`");
            formule = formule.Replace("'", "' ");
            formule = formule.Replace("`", "'' ");

            formule = memory.ReplaceToCode(formule);
            formule = variables.ReplaceToCode(formule);
            formule = GetFuncs().ReplaseToCode(formule);
            formule = variables.ReplaceByCode(formule);
            formule = memory.ReplaceByCode(formule);
            return ConvertToInteractive(formule, variable);
        }

        public static FormulePartList ReplaceByOpenVariables(string formule, string a, string help, string buffer, char variable = '\0')
        {
            return ReplaceByOpenVariables(formule, a, formule, help, buffer, new FewVariables(formule, a, buffer, help), variable);
        }

        public static FormulePartList ReplaceByOpenVariables(string formule, string a, string help, string buffer, FewVariables fewVariables, char variable = '\0')
        {
            return ReplaceByOpenVariables(formule, a, formule, help, buffer, fewVariables, variable);
        }

        public static FormulePartList ReplaceByOpenVariables(string formule, string a, string b, string help, string buffer, char variable = '\0')
        {
            return ReplaceByOpenVariables(formule, a, b, help, buffer, new FewVariables(b, a, buffer, help), variable);
        }

        public static FormulePartList ReplaceByOpenVariables(string formule, string a, string b, string help, string buffer
            , string fewA, string fewB, string fewHelp, string fewBuffer, char variable = '\0')
        {
            return ReplaceByOpenVariables(formule, a, b, help, buffer, new FewVariables(fewB, fewA, fewBuffer, fewHelp), variable);
        }

        public static FormulePartList ReplaceByOpenVariables(string formule, string a, string b, string help, string buffer, FewVariables fewVariables, char variable = '\0')
        {
            FormulePartList formuleParts = ReplaceToFullFuncsCodeInteractive(formule, variable);
            formuleParts = OpenVariables(formuleParts, a, b, buffer, help, fewVariables);
            return formuleParts;
        }

        public static FormulePartList ReplaceByOpenConstNull(string formule, char variable = '\0')
        {
            return ReplaceByOpenConst(formule, "0", "0", "0", "0", variable);
        }
        public static FormulePartList ReplaceByOpenConst(string formule, string a, string b, string help, string buffer
            , string fewA, string fewB, string fewHelp, string fewBuffer, char variable = '\0')
        {
            return ReplaceByOpenConst(formule, a, b, help, buffer, new FewVariables(fewB, fewA, fewBuffer, fewHelp), variable);
        }


        public static FormulePartList ReplaceByOpenConst(string formule, string a, string help, string buffer, char variable = '\0')
        {
            return ReplaceByOpenConst(formule, a, formule, help, buffer, new FewVariables(formule, a, buffer, help), variable);
        }

        public static FormulePartList ReplaceByOpenConst(string formule, string a, string help, string buffer, FewVariables fewVariables, char variable = '\0')
        {
            return ReplaceByOpenConst(formule, a, formule, help, buffer, fewVariables, variable);
        }

        public static FormulePartList ReplaceByOpenConst(string formule, string a, string b, string help, string buffer, char variable = '\0')
        {
            return ReplaceByOpenConst(formule, a, b, help, buffer, new FewVariables(b, a, buffer, help), variable);
        }

        public static FormulePartList ReplaceByOpenConst(string formule, string a, string b, string help, string buffer, FewVariables fewVariables, char variable = '\0')
        {
            FormulePartList formuleParts = ReplaceToFullFuncsCodeInteractive(formule, variable);
            formuleParts = OpenConst(formuleParts, a, b, buffer, help, fewVariables);
            return formuleParts;
        }

        public static FormulePartList OpenConst(FormulePartList formule, string a, string b, string help, string buffer)
        {
            return OpenConst(formule, a, b, help, buffer, new FewVariables(b, a, buffer, help));
            // return OpenConst(OpenVariables(formule, a, b, help, buffer));
        }

        public static FormulePartList OpenConst(FormulePartList formule, string a, string b, string help, string buffer, FewVariables fewVariables)
        {
            //return OpenConst(formule, a, b, help, buffer, new FewVariables(b, a, buffer, help));
            return OpenConst(OpenVariables(formule, a, b, help, buffer, fewVariables));
        }

        public static FormulePartList OpenVariables(FormulePartList formule, string a, string b, string help, string buffer)
        {
            return OpenVariables(formule, a, b, help, buffer, new FewVariables(b, a, buffer, help));
        }

        public static FormulePartList OpenVariables(FormulePartList formule, string a, string b, string help, string buffer, FewVariables fewVariables)
        {
            return OpenVariables(formule, a, b, help, buffer, CalculatorString.History, fewVariables);
        }

        public static double ToDouble(String text)
        {
            try
            {
                return Double.Parse(text);
            }
            catch (Exception e)
            {
                try
                {
                    return Double.Parse(text.Replace('.', ','));
                }
                catch (Exception ex)
                {
                    return Double.Parse(text.Replace(',', '.'));
                }
            }

        }

        public static bool DoubleTryParse(String value)
        {
            try
            {
                double num = ToDouble(value);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public static FormulePartList OpenVariables(FormulePartList formule, string a, string b, string help, string buffer, CalculatorMemoryList memory, FewVariables fewVariables)
        {
            FormulePartList partList = new FormulePartList();

            fewVariables = fewVariables.CopyWithCorrect();

            if (help.Length < 1)
                help = "0";
            if (b.Length < 1)
            {
                b = "0";
            }


            if (DoubleTryParse(help))
                help = "(" + help + ")";
            else if (help.Length > 0)
                help = AddBasketsInteractive(help).ToString();
            else
                help = "(0)";


            if (DoubleTryParse(b))
                b = "(" + b + ")";
            else if (b.Length > 0)
                b = AddBasketsInteractive(b).ToString();
            else
                b = "(0)";



            double numA = 0;
            double numBuffer = 0;
            try
            {
                numA = double.Parse(a);
            }
            catch { }

            try
            {
                numBuffer = double.Parse(buffer);
            }
            catch
            {

            }

            for (int j = 0; j < 12; j++)
            {
                bool isHelp = false;
                partList = new FormulePartList();
                for (int i = 0; i < formule.Count; i++)
                {
                    FormulePart part = formule[i];
                    if (part.ToString().ToLower() == "help")
                    {
                        partList.AddFormule(help);
                        isHelp = true;
                    }
                    else if (part.ToString().ToLower() == "@help")
                    {
                        partList.AddFormule(fewVariables.Help);
                        isHelp = true;
                    }
                    else if (part.ToString().ToLower() == "b")
                    {
                        partList.AddFormule(b);
                        isHelp = true;
                    }
                    else if (part.ToString().ToLower() == "@b")
                    {
                        partList.AddFormule(fewVariables.B);
                        isHelp = true;
                    }
                    else if (part.ToString().ToLower() == "{~M}".ToLower())
                    {
                        try
                        {
                            partList.AddFormule(memory.GetFormulesListText());
                            isHelp = true;
                        }
                        catch (Exception ex)
                        {
                            partList.AddFormule(";(0)");
                        }
                    
                    }
                    else if (IsMemoryVar(part))
                    {
                        try
                        {
                            CalculatorMemoryItem item = memory.FindByNumber(part);
                            partList.AddFormule(item.FormuleAddBaskets());
                            isHelp = true;
                        }
                        catch
                        {
                            partList.AddFormule("(0)");
                        }
                    }

                    else
                    {
                        partList.Add(part.Copy());
                    }
                }
                formule = partList;
                if (!isHelp)
                {
                    break;
                }

            }
            partList = new FormulePartList();

            for (int i = 0; i < formule.Count; i++)
            {
                FormulePart part = formule[i];
                if (part.ToString().ToLower() == "a")
                {
                    partList.AddOpenBasket(false);
                    partList.AddNumber(numA);
                    partList.AddCloseBasket(false);
                }
                else if (part.ToString().ToLower() == "@a")
                {
                    partList.AddFormule(fewVariables.A);
                }
                else if (part.ToString().ToLower() == "buffer" || part.ToString().ToLower() == "bufer")
                {
                    partList.AddOpenBasket(false);
                    partList.AddNumber(numBuffer);
                    partList.AddCloseBasket(false);
                }
                else if (part.ToString().ToLower() == "@buffer" || part.ToString().ToLower() == "@bufer")
                {
                    partList.AddFormule(fewVariables.Buffer);
                }
                else if (part.ToString().Replace("@", "").ToLower() == "b" || part.ToString().Replace("@", "").ToLower() == "help")
                {
                    partList.AddOpenBasket(false);
                    partList.AddNumber(0);
                    partList.AddCloseBasket(false);
                }
                else if (part.ToString().ToLower() == "{~X}".ToLower())
                {
                    try
                    {
                        partList.AddFormule(ArrayX);
                    }
                    catch
                    {
                        partList.AddFormule("(0)");
                    }
                }
                else if (part.ToString().ToLower() == "{~Y}".ToLower())
                {
                    try
                    {
                        partList.AddFormule(ArrayY);
                    }
                    catch
                    {
                        partList.AddFormule("(0)");
                    }
                }
                else if (part.ToString().ToLower() == "{~M}".ToLower())
                {
                        partList.AddFormule(";(0)");
                    
                }
                else if (IsMemoryVar(part))
                {

                    partList.AddFormule("(0)");
                }
                else
                {
                    partList.Add(part.Copy());
                }

            }

            return partList;
        }

        public static bool IsMemoryVar(string text)
        {
            try
            {
                return text.Substring(0, 3) == "{~@";
            }
            catch
            {
                return false;
            }
        }


        public static string ConvertToInteractiveToFormule(String formule, char variable = '\0')
        {
            return ConvertToInteractive(formule, variable);
        }


        public static FormulePartList ConvertToInteractive(String formule, char variable = '\0')
        {
            return ConvertToInteractive(formule, CalculatorString.History, variable);
        }

        public static FormulePartList ConvertToInteractive(String formule, CalculatorMemoryList memory, char variable = '\0')
        {
            formule = formule.Replace("⁡〖".Trim(), "(");
            formule = formule.Replace("〗".Trim(), ")");
            formule = formule.Replace("⁡〖", "(");
            formule = formule.Replace("〗", ")");
            formule = formule.Replace((char)12310, '(');
            formule = formule.Replace('〗', ')');
            formule = formule.Replace('_', ' ').Trim();
            //StackList<FormuleOpenBasket> opens = new StackList<FormuleOpenBasket>();

            FormulePartList partList = new FormulePartList();

            if (variable != '\0')
            {
                variable = char.ToLower(variable);
            }

            int length = formule.Length;

            ListObjects<bool> moduls = new ListObjects<bool>();
            StackList<FormuleOpenBasket> openBaskets = new StackList<FormuleOpenBasket>();
            openBaskets.Push(new FormuleOpenBasket(false));
            moduls.Add(false);
            int last = length - 1;
            for (int i = 0; i < length; i++)
            {
                FormuleOpenBasket openBasket = openBaskets.Peek();
                bool abs = openBasket.Abs;
                int openCount = openBaskets.Count();
                char num = formule[i];
                if (num == ' ')
                    continue;
                if(num == '°')
                {
                    partList.Add(new FormuleUgleOperator(0));
                    continue;
                }
                if (num == '\'')
                {
                    if (i < last)
                    {
                        if (formule[i + 1] == '\'')
                        {
                            partList.Add(new FormuleUgleOperator(2));
                            i++;
                        }
                        else
                            partList.Add(new FormuleUgleOperator(1));
                    }
                    else
                        partList.Add(new FormuleUgleOperator(1));
                    continue;
                }


                if (num == '.' || char.IsDigit(num) || num == ',')
                {
                    string number = GetStringNumber(formule, i);
                    number = number.Replace('.', ',');
                    i += number.Length - 1;
                    number = number.Trim();
                    number = number.Replace(" ", "");
                    partList = partList.AddNumberWithThis(ToDouble(number));
                    continue;
                }

                if (num == '|')
                {
                    if (i == 0 || partList.Count < 1)
                        abs = false;
                    else
                    {
                        int j = i - 1;
                        FormulePart part = partList.GetLast();
                        if (part.IsNumber || part.IsCloseBasket)
                            abs = true;
                        if (part.IsArraySplit || part.IsOpenBasket)
                            abs = false;
                        if (part.IsFunction)
                        {
                            abs = part.AsFunction.Function.IsConst();
                        }
                    }
                    if (!abs)
                    {
                        FormuleOpenBasket open = partList.AddOpenBasketWithReturn(true);
                        openBaskets.Push(open);

                        if (i < formule.Length - 1)
                        {
                            char check = formule[i + 1];
                            if (check == '(')
                                i++;
                        }
                    }
                    else
                    {
                        partList = partList.AddCloseBasketWithThis(true);
                        if (openBaskets.Count > 1)
                            openBaskets.Pop().Abs = true;
                        else
                            partList.Insert(0, new FormuleOpenBasket(true));
                    }
                    continue;
                }

                if (num == 'a' || num == variable)
                {
                    partList = partList.AddStaticVariableWithThis(num + "");
                    continue;
                }
                if (num == 'h')
                {
                    if (IsHelp(formule, i))
                    {
                        string help = "help";
                        partList = partList.AddStaticVariableWithThis(help);
                        i += help.Length - 1;
                        continue;
                    }
                }
                if (num == 'b')
                {
                    if (IsBuffer(formule, i))
                    {
                        string help = "buffer";
                        partList = partList.AddStaticVariableWithThis(help);
                        i += help.Length - 1;
                        continue;
                    }
                    if (IsBufer(formule, i))
                    {
                        string help = "bufer";
                        partList = partList.AddStaticVariableWithThis(help);
                        i += help.Length - 1;
                        continue;
                    }
                    partList = partList.AddStaticVariableWithThis(num + "");
                    continue;
                }
                if (num == '{')
                {
                    if (IsFxX(formule, i))
                    {
                        string help = "{~X}";
                        partList = partList.AddStaticVariableWithThis(help);
                        i += help.Length - 1;
                        continue;
                    }
                    if (IsFxY(formule, i))
                    {
                        string help = "{~Y}";
                        partList = partList.AddStaticVariableWithThis(help);
                        i += help.Length - 1;
                        continue;
                    }
                    if (CalculatorMemoryList.IsMemoryListVariable(formule, i))
                    {
                            string help = CalculatorMemoryList.MemoryListVariable();
                       
                            partList = partList.AddStaticVariableWithThis(help);
                            i += help.Length - 1;

                        continue;
                    }
                    if (i < last)
                    {
                        int j = i + 1;
                        char check = formule[j];
                        if (check == '~')
                        {
                            if (j < last)
                            {
                                check = formule[j + 1];
                                if (check == '@')
                                {
                                    for (int k = 0; k < memory.Count; k++)
                                    {
                                        CalculatorMemoryItem item = memory[k];
                                        if (item.IsThisIndex(formule, i))
                                        {
                                            string variable1 = item.VariableValueText;
                                            partList = partList.AddMemoryVariableWithThis(variable1);
                                            i += variable1.Length - 1;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (num == '@')
                {
                    i++;
                    char num1 = formule[i];
                    if (num1 == 'a')
                    {
                        partList = partList.AddStaticVariableWithThis("@a");
                        continue;
                    }

                    if (num1 == 'h')
                    {
                        if (IsHelp(formule, i))
                        {
                            string help = "help";
                            partList = partList.AddStaticVariableWithThis("@" + help);
                            i += help.Length - 1;
                            continue;
                        }
                    }
                    if (num1 == 'b')
                    {
                        if (IsBuffer(formule, i))
                        {
                            string help = "buffer";
                            partList = partList.AddStaticVariableWithThis("@" + help);
                            i += help.Length - 1;
                            continue;
                        }
                        if (IsBufer(formule, i))
                        {
                            string help = "bufer";
                            partList = partList.AddStaticVariableWithThis("@" + help);
                            i += help.Length - 1;
                            continue;
                        }
                        partList = partList.AddStaticVariableWithThis("@b");
                        continue;
                    }
                }

                if (num == '(')
                {
                    FormuleOpenBasket open = partList.AddOpenBasketWithReturn(false);
                    openBaskets.Push(open);
                    continue;
                }
                if (num == ')')
                {
                    abs = openBaskets.Peek().Abs;
                    if (i < formule.Length - 1)
                    {
                        char check = formule[i + 1];
                        if (check == '|')
                        {
                            i++;
                            abs = true;
                        }
                    }
                    partList = partList.AddCloseBasketWithThis(abs);
                    if (openBaskets.Count > 1)
                        openBaskets.Pop().Abs = abs;
                    else
                        partList.Insert(0, new FormuleOpenBasket(abs));
                    continue;
                }
                if (num == ';')
                {
                    partList = partList.AddArraySplitWithThis();
                    continue;
                }
                if (num == 'e')
                {
                    partList = partList.AddExpWithThis();
                    continue;
                }
                if (num == '~')
                {
                    i++;

                    string psevdoCode = IntNumber(i, formule);
                    i += psevdoCode.Length;
                    int code = int.Parse(psevdoCode);
                    int j = i + 1;
                    FormuleFunction function;
                    try
                    {
                        num = formule[j];
                        if (num != '\'')
                        {
                            function = partList.AddFunctionWithReturn(code);
                            //continue;
                        }
                        else
                        {
                            i = j + 1;
                            string nameID = IntNumber(i, formule);
                            i += nameID.Length;

                            function = partList.AddFunctionWithReturn(code, int.Parse(nameID));
                        }
                    }
                    catch
                    {
                        function = partList.AddFunctionWithReturn(code);
                    }

                }

            }

            while (openBaskets.Count > 1)
            {
                partList.AddCloseBasket(openBaskets.Pop().Abs);
            }

            FormulePartList formuleParts = partList;
            partList = new FormulePartList();
            int count = formuleParts.Count;
            last = count - 1;
            FuncList funcNames = GetFuncs();
            int mull = funcNames.Mull().GetPsevdoName();
            int id = funcNames.MullLastIndex();
            bool openLast = false;

            for (int i = 0; i < count; i++)
            {
                FormulePart part = formuleParts.Get(i);
                if(part.IsNumber || part.IsOpenBasket)
                {
                    if(i>0)
                    {
                        int j = i - 1;
                        FormulePart partCheck = formuleParts.Get(j);
                        if(partCheck.IsFunction)
                        {
                            partList.Add(part);
                            continue;
                        }
                    }
                }
                if (i > 0 && partList.Count > 0)
                {
                    FormulePart partLast = formuleParts.Get(i - 1);
                    if(partLast.IsAdditionFunction() && !part.IsPlusFunction() && (!part.IsClosePart() || part.IsConst()))
                    {
                        partList.Add(funcNames.FormulePlus());
                        partList.Add(part);
                        continue;
                    }

                    if (part.IsOpenBasket && i < last)
                    {
                        FormulePart partNext = formuleParts.Get(i + 1);
                        if (!partNext.IsCloseBasket)
                        {
                            if (partLast.IsNumber || partLast.IsCloseBasket || partLast.IsConst())
                            {
                                partList.AddFunction(mull, id);
                            }
                            else if (partLast.IsExp)
                            {
                                int j = i - 1;
                                if (j > 0)
                                {
                                    partLast = formuleParts.Get(j - 1);
                                    if (!partLast.IsNoOpenOrExp())
                                        partList.AddFunction(mull, id);
                                }
                                else
                                    partList.AddFunction(mull, id);


                            }
                        }
                        else
                        {
                            if (partLast.IsCloseBasket)
                            {
                                i++;
                                continue;
                            }
                            else if (part.AsBaskets.Abs)
                            {
                                i++;
                                continue;
                            }
                        }
                    }
                    else if (part.IsConst())
                    {
                        if (partLast.IsClosePart())
                        {
                            partList.AddFunction(mull, id);
                        }
                        else if (partLast.IsExp)
                        {
                            int j = i - 1;
                            if (j > 0)
                            {
                                partLast = formuleParts.Get(j - 1);
                                if (!partLast.IsNoOpenOrExp())
                                    partList.AddFunction(mull, id);
                            }
                            else
                                partList.AddFunction(mull, id);


                        }
                        
                    }
                    else if (part.IsExp && i == last)
                    {
                        if (partLast.IsNoOpen())
                            partList.AddFunction(mull, id);
                        else if (partLast.IsExp)
                        {
                            int j = i - 1;
                            if (j > 0)
                            {
                                partLast = formuleParts.Get(j - 1);
                                if (!partLast.IsNoOpenOrExp())
                                    partList.AddFunction(mull, id);
                            }
                            else
                                partList.AddFunction(mull, id);


                        }

                    }
                    else if (part.IsExp && i < last)
                    {
                        FormulePart partNext = formuleParts.Get(i + 1);
                        if (partNext.IsCloseBasket && !partLast.IsOpenBasket)
                            if (partLast.IsNoOpen())
                                partList.AddFunction(mull, id);
                            else if (partLast.IsExp)
                            {
                                int j = i - 1;
                                if (j > 0)
                                {
                                    partLast = formuleParts.Get(j - 1);
                                    if (!partLast.IsNoOpenOrExp())
                                        partList.AddFunction(mull, id);
                                }
                                else
                                    partList.AddFunction(mull, id);


                            }
                    }
                    else if (part.IsNoCanHaveBeforeArgument())
                    {
                        if (partLast.IsClosePart())
                        {
                            partList.AddFunction(mull, id);
                        }
                        else if (partLast.IsExp)
                        {
                            int j = i - 1;
                            if (j > 0)
                            {
                                partLast = formuleParts.Get(j - 1);
                                if (!partLast.IsNoOpenOrExp())
                                    partList.AddFunction(mull, id);
                            }
                            else
                                partList.AddFunction(mull, id);


                        }


                    }
                }

                else if (i < last)
                {
                    FormulePart partLast = formuleParts.Get(i + 1);
                    if ((part.IsOpenBasket || part.IsNoCanHaveBeforeArgument()) && partLast.IsCloseBasket)
                    {
                        i++;
                        continue;
                    }
                }
                partList.Add(part);
            }


            return partList;
        }


        public static FormulePartList ConvertToPostfics(FormulePartList partList)
        {
            partList.Insert(0, new FormuleOpenBasket(false));
            partList.Add(new FormuleCloseBasket(false));
            FormulePartList tokens = new FormulePartList();
            FormuleStackList stack = new FormuleStackList();
            stack.Push();
            bool afterOpen = false;

            int count = partList.Count;
            int last = count - 1;
            for (int i = 0; i < count; i++)
            {
                FormuleStack formuleStack = stack.Peek();
                FormulePart part = partList.GetCopy(i);
                if (!part.IsCloseBasket && !part.IsArraySplit)
                {
                    afterOpen = false;
                }
                else if (formuleStack.LastFunction && formuleStack.IsNoEmpty())
                {
                    //formuleStack.Peek().OperandsCount--;
                }
                formuleStack.LastFunction = false;

                if (part.IsNumber || part.IsStaticVariable)
                {
                    tokens.Add(part);
                    formuleStack.LastOperate = true;
                    continue;
                }

                if (part.IsArraySplit)
                {
                    bool noHaveOperands = formuleStack.IsEmpty();
                    formuleStack.FirstOperate = true;
                    formuleStack.LastOperate = false;
                    while (formuleStack.IsNoEmpty())
                    {
                        tokens.Add(formuleStack.Pop());
                    }
                    formuleStack.ReservOpen();
                    if (i == last || i == 0)
                        continue;
                    FormulePart part1 = partList.Get(i + 1);
                    if (part1.IsCloseOperator)
                        continue;
                    if (afterOpen)
                        continue;
                    formuleStack.OperandsCount++;
                    continue;
                }

                if (part.IsOpenBasket)
                {
                    formuleStack = stack.Push();
                    afterOpen = true;
                    continue;
                }
                if (part.IsCloseBasket)
                {
                    if (afterOpen)
                        formuleStack.OperandsCount = 0;

                    FormuleBaskets basket = part.AsCloseBasket;
                    while (formuleStack.IsNoEmpty())
                    {
                        tokens.Add(formuleStack.Pop());
                    }
                    formuleStack.ReservOpen();
                    stack.RemoveLast();
                    if (basket.Abs)
                        tokens.AddFunctionWithReturn(GetFuncs().AbsFunc).OperandsCount = formuleStack.OperandsCount;
                    else
                    {

                        if (stack.IsNoEmpty())
                        {
                            FormuleStack formuleStack1 = stack.Peek();
                            if (formuleStack1.IsNoEmpty())
                            {
                                FormuleOperation function = formuleStack1.Peek();
                                function.OperandsCount--;
                                function.OperandsCount += formuleStack.OperandsCount;
                            }
                            else
                            {

                                formuleStack1.ReservOperandsCount += formuleStack.OperandsCount - 1;
                            }
                        }
                    }
                    if (stack.IsNoEmpty())
                    {
                        stack.Peek().LastOperate = true;
                    }
                    continue;
                }
                if (part.IsOperation)
                {
                    formuleStack.LastFunction = true;
                    FormuleOperation operation = part.AsOperation;
                    operation.FirstOperate = formuleStack.FirstOperate;
                    formuleStack.FirstOperate = false;
                    operation.LastOperate = formuleStack.LastOperate;
                    formuleStack.LastOperate = false;
                    
                    if (operation.LastOperate)
                    {
                        operation.Operate = true;
                        operation.OperandsCount = 2;

                        int countR = formuleStack.GetAndClearReservOperandsCount();
                        if (countR > 0)
                        {
                            operation.OperandsCount += countR;
                            operation.Operate = false;
                        }
                    }
                    else
                    {
                        operation.OperandsCount = 1;
                        operation.Operate = false;
                    }
                    if(operation.IsUgleOperator())
                    {
                        operation.LastOperate = true;
                        //operation.OperandsCount = 1;
                        
                            operation.OperandsCount--;
                    }
                    else if (i < last)
                    {
                        FormulePart partCheck = partList.Get(i + 1);
                        if (partCheck.IsOperation)
                        {
                            FormuleOperation opCheck = partCheck.AsOperation;
                            if (!operation.AllowWithOperator && opCheck.IsOperator)
                            {
                                operation.OperandsCount--;
                                formuleStack.LastOperate = true;
                            }
                        }
                        else if (partCheck.IsCloseOperator)
                        {
                            operation.OperandsCount--;
                            formuleStack.LastOperate = false;
                        }
                    }
                    else
                    {
                        operation.OperandsCount--;
                    }
                    if (formuleStack.IsNoEmpty())
                    {
                        while (IsMorePriority(operation, formuleStack))
                        {
                            tokens.Add(formuleStack.Pop());
                        }
                    }
                    formuleStack.Push(operation);
                    if(operation.IsUgleOperator())
                    {
                        formuleStack.LastOperate = true;
                    }
                }

            }

            FormuleStack formuleStack2 = stack.Pop();
            while (formuleStack2.IsNoEmpty())
            {
                tokens.Add(formuleStack2.Pop());
            }
            formuleStack2.ReservOpen();
            FuncList funcs1 = GetFuncs();
            tokens.AddFunctionWithReturn(funcs1.Mull()).OperandsCount = formuleStack2.OperandsCount;

            return tokens;
        }


        public static double CalculateConvertToPostphics(string formule, double a, string help, double buffer, char variable = '\0')
        {
            return CalculateConvertToPostphics(formule, a.ToString(), help, buffer.ToString(), variable);
        }

        public static double CalculateConvertToPostphics(string formule, string a, string help, string buffer, char variable = '\0')
        {
            return CalculateConvertToPostphics(formule, a, formule, help, buffer, variable);
        }

        public static double CalculateConvertToPostphics(string formule, string a, string b, string help, string buffer, char variable = '\0')
        {
            FormulePartList formuleParts = ReplaceByOpenConst(formule, a, b, buffer, help, variable);
            return CalculateWithConvertToPostfics(formuleParts);
        }

        public static FormulePartList ConvertToPostphicsToFx(string formule, string a, string b, string help, string buffer)
        {
            return ConvertToPostphics(formule, a, b, help, buffer, 'x');
        }

        public static FormulePartList ConvertToPostphics(string formule, string a, string b, string help, string buffer, char variable = '\0')
        {
            FormulePartList formuleParts = ReplaceByOpenConst(formule, a, b, buffer, help, variable);
            return ConvertToPostfics(formuleParts);
        }

        public static double CalculateConvertToPostphics(string formule, string a, string b, string help, string buffer,
            string fewA, string fewB, string fewHelp, string fewBuffer, char variable = '\0')
        {
            return CalculateConvertToPostphics(formule, a, b, help, buffer, new FewVariables(fewA, fewB, fewBuffer, fewHelp), variable);
        }

        public static FormulePartList ConvertToPostphics(string formule, string a, string help, string buffer, FewVariables few, char variable = '\0')
        {
            return ConvertToPostphics(formule, a, formule, help, buffer, few, variable);
        }

        public static FormulePartList ConvertToPostphics(string formule, string a, string b, string help, string buffer, FewVariables few, char variable = '\0')
        {
            FormulePartList formuleParts = ReplaceByOpenConst(formule, a, b, buffer, help, few, variable);
            return ConvertToPostfics(formuleParts);
        }

        public static double CalculateConvertToPostphics(string formule, string a, string help, string buffer, FewVariables few, char variable = '\0')
        {
            return CalculateConvertToPostphics(formule, a, formule, help, buffer, few, variable);
        }

        public static double CalculateConvertToPostphics(string formule, string a, string b, string help, string buffer, FewVariables few, char variable = '\0')
        {
            FormulePartList formuleParts = ReplaceByOpenConst(formule, a, b, buffer, help, few, variable);
            return CalculateWithConvertToPostfics(formuleParts);
        }

        public static FormulePartList ReplaceByFx(FormulePartList formuleParts, double num, char variable = 'x')
        {
            FormulePartList result = new FormulePartList();

            foreach (FormulePart part in formuleParts)
            {
                if (part.IsStaticVariable && part.ToString().ToLower() == (variable + "").ToLower())
                {
                    result.AddNumber(num);
                }
                else
                {
                    result.Add(part.Copy());
                }

            }

            return result;
        }

        public static double CalcByFx(FormulePartList tokens, double num, char variable = 'x')
        {
            return CalculateByPostphics(ReplaceByFx(tokens, num, variable));
        }

        public static bool ContainsNoAllowFx(FormulePartList formuleParts)
        {
            foreach (FormulePart part in formuleParts)
            {
                if (part.IsFunction)
                {
                    if (!part.AsFunction.Function.AllowFx)
                        return true;
                }
            }


            return false;
        }


        public static double CalculateByPostphics(FormulePartList tokens)
        {
            double result = 0;
            string test = tokens.GetFormuleArr();

            ListStack<FormuleOperand> stack = new ListStack<FormuleOperand>();

            int count = tokens.Count;
            int last = count - 1;

            for (int i = 0; i < count; i++)
            {
                FormulePart part = tokens.Get(i);
                if (part.IsNumber)
                {
                    stack.Push(part.AsNumber);
                    continue;
                }
                if (part.IsOperation)
                {



                    FormuleOperation operate = part.AsOperation;


                    // Черновой вариант
                    if (i == last)
                        operate.OperandsCount = stack.Count;

                    List<double> numbers = new List<double>();
                    int countO = operate.OperandsCount;
                    //List<FormuleOperand> operands = new List<FormuleOperand>();
                    if (countO == 0)
                    {
                        try
                        {
                            double ret = operate.RunCalc(new double[0]);
                            stack.Push(new FormuleNumber(ret));
                        }
                        catch (ManyFuncsOneExceptions e)
                        {
                            stack.Push(new FormuleManyFuncsArgExceptions(e));
                        }
                        catch
                        {
                            stack.Push(new FormuleNumber(double.NaN));

                        }
                        continue;
                    }
                    List<FormuleOperand> operands = new List<FormuleOperand>();
                    for (int j = 0; j < countO; j++)
                    {
                        operands.Insert(0, stack.GetByLast(j));
                    }
                    List<FormuleOperand> check1 = operands.FindAll(o => o.IsFuncOneException || o.IsManyFuncsArgExceptions);
                    if (check1.Count > 1 || (check1.Count == 1 && operands.Count == 1))
                    {

                        stack.RemoveByLast(countO);
                        if (operate.IsFunction)
                        {

                            ManyFuncsOneExceptions exceptions = new ManyFuncsOneExceptions(operate.AsFunction.Function);
                            exceptions.AddRange(check1);
                            stack.Push(new FormuleManyFuncsArgExceptions(exceptions));
                        }
                        continue;
                    }

                    for (int j = 0; j < countO - 1; j++)
                    {
                        numbers.Insert(0, stack.Pop().AsNumber.Number);
                    }

                    FormuleOperand operand = stack.Pop();

                    if (operand.IsNumber)
                    {
                        numbers.Insert(0, operand.AsNumber.Number);
                    }
                    else if (operand.IsManyFuncsArgExceptions)
                    {
                        List<double> checkNumbers = numbers;
                        numbers = new List<double>();
                        if (operate.IsFunction)
                        {
                            operate = new FormuleFunction(operate.AsFunction.Function.FewFunction);
                        }
                        if (operate.IndexFunc)
                        {
                            numbers.Add(1);
                        }
                        FormulePartList parts = operand.AsManyFuncsArgExceptions.Postfics();

                        foreach (double num in checkNumbers)
                        {
                            double res = MyCalculate.CalcByFx(parts, num, 'N');
                            if (operate.IndexFunc)
                            {
                                numbers.Add(res);
                            }
                            else if (res == 1)
                            {
                                numbers.Add(num);
                            }
                        }
                    }
                    else if (operand.IsFuncOneException)
                    {
                        List<double> checkNumbers = numbers;
                        numbers = new List<double>();
                        if (operate.IsFunction)
                        {
                            operate = new FormuleFunction(operate.AsFunction.Function.FewFunction);
                        }
                        if (operate.IndexFunc)
                        {
                            numbers.Add(1);
                        }
                        FuncNames check = operand.AsFuncOneException.Function;
                        double numCheck = operand.AsFuncOneException.Argument;
                        foreach (double num in checkNumbers)
                        {
                            double res = check.FuncDoingInvoke(num, numCheck);
                            if (operate.IndexFunc)
                            {
                                numbers.Add(res);
                            }
                            else if (res == 1)
                            {
                                numbers.Add(num);
                            }
                        }
                    }


                    try
                    {
                        double ret = operate.RunCalc(numbers.ToArray());
                        stack.Push(new FormuleNumber(ret));
                    }
                    catch (FuncsOneArgumentExceptions e)
                    {
                        stack.Push(new FormuleFuncsOneExceptions(e));
                    }
                    catch (ManyFuncsOneExceptions e)
                    {
                        stack.Push(new FormuleManyFuncsArgExceptions(e));
                    }
                    catch (NumCalcException e)
                    {
                        if (operate.FirstOperate || i >= last)
                        {
                            stack.Push(new FormuleNumber(e.Number));
                        }
                        else
                        {
                            int j = i + 1;
                            FormulePart part1 = tokens.Get(j);
                            if (!part1.IsFunction)
                            {
                                stack.Push(new FormuleNumber(e.Number));
                            }
                            else
                            {
                                stack.Push(new FormuleNumber(e.Number));
                                tokens.Set(j, part1.AsFunction.CopyByPersent());
                            }
                        }
                    }
                    catch
                    {
                        stack.Push(new FormuleNumber(double.NaN));
                    }
                }
            }

            result = stack.Pop().AsNumber.Number;

            if (double.IsNaN(result) || double.IsInfinity(result))
            {
                throw new Exception();
            }

            return result;
        }

        public static double CalculateWithConvertToPostfics(FormulePartList partList)
        {
            return CalculateByPostphics(ConvertToPostfics(partList));
        }

        public static bool IsMorePriority(FormuleOperation op, FormuleStack formuleStack)
        {
            if (!op.IsDoingByOperator)
            {
                return false;
            }
            if (formuleStack.IsEmpty())
                return false;
            FormuleOperation lastOp = formuleStack.Peek();
            if (op.IsMoreFewPriority(lastOp))
                return true;
            if (op.RealFewPriority == lastOp.RealFewPriority)
                return lastOp.RealPriority <= op.RealPriority;
            return false;
        }

        public static char FindSymwol(string text, int startID, int step)
        {
            int length = text.Length;
            int last = length - 1;
            int checkID = startID + step;
            if (checkID < 0 || checkID > last)
            {
                return ' ';
            }
            int i = checkID;
            char check = text[i];
            while (check == ' ' && i > -1 && i < length)
            {
                check = text[i];
                i += step;
            }
            return check;
        }

        public static string IntNumber(int one, string text)
        {
            string result = "";

            for (int i = one; i < text.Length; i++)
            {
                char sign = text[i];
                if (!char.IsDigit(sign))
                {
                    break;
                }
                result += sign;
            }


            return result;
        }


        public static double GetResultHelp(String formule, double numberA, double numberBuffer)
        {
            return GetResultHelp(formule, numberA.ToString(), numberBuffer.ToString());
        }

        public static double GetResultHelp(String formule, String numberA, String numberBuffer)
        {
            return CalculateConvertToPostphics(formule, numberA, formule, numberBuffer);
        }

        public static double GetResultHelp(String formule, double numberA, double numberBuffer, string b)
        {
            return GetResultHelp(formule, numberA.ToString(), numberBuffer.ToString(), b);
        }

        public static double GetResultHelp(String formule, String numberA, String numberBuffer, string b)
        {
            return CalculateConvertToPostphics(formule, numberA, b, formule, numberBuffer);
        }


        public static double CalculateWithMemory(string formule, string numberA, string numberBuffer, string numberHelp, char variable = '\0')
        {
            return CalculateConvertToPostphics(formule, numberA, numberHelp, numberBuffer, variable);
        }

        public static string OpenMemoryVariables(string formule)
        {
            return OpenMemoryVariables(formule, CalculatorString.History);
        }

        public static string OpenMemoryVariables(string formule, CalculatorMemoryList list)
        {

            string result = formule;
            try
            {
                int count = list.Count;
                for (int i = 0; i < count; i++)
                {
                    formule = formule.ToLower().Replace(list[i].VariableText.ToLower(), "{~@" + i + "}");
                }
                return formule;
            }
            catch
            {
                return formule;
            }
        }

        public static string CloseMemoryVariables(string formule)
        {
            return CloseMemoryVariables(formule, CalculatorString.History);
        }

        public static string CloseMemoryVariables(string formule, CalculatorMemoryList list)
        {

            string result = formule;
            try
            {
                int count = list.Count;
                for (int i = 0; i < count; i++)
                {
                    formule = formule.ToLower().Replace("{~@" + i + "}", list[i].VariableText);
                }
                return formule;
            }
            catch
            {
                return formule;
            }
        }

        public static string ConvertMemoryVariablesNull(string formule, CalculatorMemoryList list, string a, string buffer, string help)
        {
            string numberHelp = help;
            numberHelp = ChangeBaskets(numberHelp);
            help = numberHelp;
            string result = formule;
            try
            {
                return list.ReplaceFormuleNull(result, a, buffer, help);
            }
            catch
            {
                return formule;
            }
        }

        public static double Calculate(string formule, string signA, string numberA, string numberBuffer, string numberHelp, char variable = '0')
        {
            return CalculateConvertToPostphics(formule, numberA, numberHelp, numberBuffer, variable);
        }

        public static double Calculate(string formule, string signA, string numberA, string numberBuffer, char variable = '0')
        {
            return CalculateConvertToPostphics(formule, numberA, formule, numberBuffer, variable);
        }

        public static string ReplaceM(string formule, string numberA, string numberBuffer, string numberHelp)
        {
            formule = formule.ToLower();
            string m = "{~M}";
            m = m.ToLower();
            if (formule.Contains(m))
            {
                formule = formule.Replace(m, CalculatorString.History.ToMass(numberA, numberBuffer, numberHelp));
            }
            return formule;
        }

        public static string ReplaceHelp(string formule, string b, string help)
        {
            string numberHelp = help;
            numberHelp = ChangeBaskets(numberHelp);

            formule = OpenMemoryVariables(formule);

            formule = formule.ToLower().Replace("Help".ToLower(), $"({numberHelp})");
            formule = OpenMemoryVariables(formule);
            formule = formule.ToLower().Replace("Help".ToLower(), $"({numberHelp})");
            formule = OpenMemoryVariables(formule);
            formule = formule.ToLower().Replace("Help".ToLower(), $"({numberHelp})");

            return ReplaceB(formule, b);
        }

        public static string ReplaceB(string formule, string b)
        {
            formule = OpenMemoryVariables(formule);
            formule = formule.ToLower().Replace("buffer", ArrX + 1);
            formule = formule.ToLower().Replace("bufer", ArrX + 2);

            formule = GetFuncs().ReplaseToCode(formule);

            string numberX = AddBaskets(b);
            b = numberX;

            formule = formule.ToLower().Replace("b", b);
            formule = ChangeBaskets(GetFuncs().ReplaceFuncByCode(formule));

            formule = formule.ToLower().Replace(ArrX + 1, "Buffer");
            formule = formule.ToLower().Replace(ArrX + 2, "Bufer");

            formule = CloseMemoryVariables(formule);
            return formule;
        }

        const string ArrX = "{~1}";

        public static string ViewX(string formule, string numberX)
        {
            // string numberHelp = help;
            formule = ChangeBaskets(formule);
            //  help = numberHelp;
            formule = OpenMemoryVariables(formule);
            formule = GetFuncs().ReplaseToCode(formule);

            formule = formule.ToLower().Replace("{~X}".ToLower(), ArrX);
            try
            {
                double result = double.Parse(numberX.Replace(".", ","));
                if (result < 0)
                    throw new Exception();
            }
            catch
            {
                numberX = "(" + ChangeBaskets(numberX) + ")";
            }
            formule = formule.ToLower().Replace("x", numberX);
            formule = formule.ToLower().Replace(ArrX, "{~X}");
            formule = ChangeBaskets(GetFuncs().ReplaceFuncByCode(formule));
            formule = CloseMemoryVariables(formule);

            return formule;
        }



        public static string FuncViewChange(string formule, string numberA, string numberBuffer, string numberHelp, char variable = '\0')
        {
            return ReplaceByOpenConst(formule, numberA, numberHelp, numberBuffer, variable);
        }

        public static string FuncViewChange(string formule, string numberA, string numberBuffer, string numberHelp, string formuleB, char variable = '\0')
        {
            return ReplaceByOpenConst(formule, numberA, formuleB, numberHelp, numberBuffer, variable);
        }

        public static double CalculateWithB(string formule, string numberA, string numberBuffer, string numberHelp, string formuleB, char variable = '\0')
        {
            return CalculateConvertToPostphics(formule, numberA, formuleB, numberHelp, numberBuffer, variable);
        }

        public static string CalculateFunc(string formule, string numberA, string numberBuffer, string numberHelp, char variable = '\0')
        {
            return ReplaceByOpenConst(formule, numberA, numberHelp, numberBuffer, variable).ToString();
        }

        public static string ArrayX
        {
            get
            {
                return FuncGraphicsForm.MasX;
            }
        }

        public static string ArrayY
        {
            get
            {
                return FuncGraphicsForm.MasY;
            }
        }

        public static double Calculate1(string formule, char variable = '\0')
        {
            return CalculateByPostphics(ConvertToPostfics(ConvertToInteractive(formule, variable)));
        }

        public static bool IsE(char symwol)
        {
            return char.ToLower(symwol) == 'e';
        }

        public static string DropBaskets(string text, char variable = '\0')
        {
            return DropBasketsInteractive(text, variable);
        }

        public static string AddBaskets(string formule, char variable = '\0')
        {
            return AddBasketsInteractive(formule, variable);
        }


        public static string ChangeBaskets(string text, char variable = '\0')
        {
            return ReplaceToFullFuncsCodeInteractive(text, variable);
        }

    }
}
