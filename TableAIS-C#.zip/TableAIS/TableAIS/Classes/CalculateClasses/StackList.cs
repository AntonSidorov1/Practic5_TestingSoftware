﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class StackList<T> : List<T>
    {
        public StackList() : base()
        {
            Create();
        }

        public StackList(int capacity) : base(capacity)
        {
            Create();
        }

        public StackList(IEnumerable<T> collection) : base(collection)
        {
            Create();
        }

        public virtual void Create()
        {

        }

        public int Size() => Count;
        public int size() => Size();

        public int Last => Count - 1;
        public T Get(int index)
        {
            return this[index];
        }

        public void Set(int index, T value)
        {
            this[index] = value;
        }

        public void SetLast(T value)
        {
            Set(Last, value);
        }

        public T Peek()
        {
            return Get(Last);
        }



        public bool IsEmpty() => Count < 1;

        public bool IsNoEmpty() => !IsEmpty();

        public void DeleteLast()
        {
            RemoveAt(Last);
        }

        public T Pop()
        {
            T ret = Peek();
            DeleteLast();
            return ret;
        }

        public void Push(T item)
        {
            Add(item);
        }

        public void Put(T item)
        {
            Push(item);
        }

        public void put(T item)
        {
            Put(item);
        }


        public void push(T item)
        {
            Push(item);
        }
    }
}
