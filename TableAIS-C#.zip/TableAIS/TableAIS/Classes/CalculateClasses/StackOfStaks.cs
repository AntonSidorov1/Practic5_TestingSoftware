﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class StackOfStaks<T> : Stack<Stack<T>>

    {
        public StackOfStaks() : base()
        {
        }

        public StackOfStaks(int capacity) : base(capacity)
        {
        }

        public StackOfStaks(IEnumerable<Stack<T>> collection) : base(collection)
        {
        }

        public Stack<T> Add()
        {
            Stack<T> stack = new Stack<T>();
            Push(stack);
            return stack;
        }
    }
}
