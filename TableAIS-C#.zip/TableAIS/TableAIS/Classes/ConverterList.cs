﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class ConverterList
    {
        public ConverterList()
        {
            metrsConverts = new List<MetrsConvert>();
            try
            {
                Create();
            }
            catch { }

        }

        public void Create()
        {
            FromIndex = -1;
            ToIndex = -1;
        }

        protected List<MetrsConvert> metrsConverts;

        public List<MetrsConvert> MetrsConvertsList => metrsConverts;

        public MetrsConvert[] MetrsConvertsArray => MetrsConvertsList.ToArray();

        int fromIndex, toIndex;

        public virtual int FromIndex
        {
            get => fromIndex; set => fromIndex = value;
        }

        public virtual int ToIndex
        {
            get => toIndex; set => toIndex = value;
        }

        public MetrsConvert From => MetrsConvertsList[FromIndex];
        public MetrsConvert To => MetrsConvertsList[ToIndex];

        public MetrsConvertMaker Converter => new MetrsConvertMaker(From, To);

        public virtual double Convert(double value) => Converter.Convert(value);

        public double ConvertTo(int index, double value) => Get(index).To(value);

        public double ConvertFrom(int index, double value) => Get(index).From(value);

        public double Convert(int from, int to, double value) => ConvertTo(to, ConvertFrom(from, value));
        public double Convert(IndexesConvert indexes, double value) => Convert(indexes.FromIndex, indexes.ToIndex, value);

        public MetrsConvert Add(string name)
        {
            MetrsConvert convert =GetCreate(name);
            MetrsConvertsList.Add(convert);
            return convert;
        }

        public virtual MetrsConvert GetCreate(string name)
        {
            return new MetrsConvert(name);
        }

        public virtual void DeleteNoCondition()
        {

        }

        public MetrsConvert Get(int index)
        {
            DeleteNoCondition();
            return metrsConverts[index];
        }

        public MetrsConvert Get(string name)
        {
            
            return Get(metrsConverts.FindIndex(m => m.Name == name));
        }

        public double FromDo(int index, double value)
        {
            return Get(index).From(value);
        }

        public double FromDo(double value) => FromDo(FromIndex, value);

        public double FromDo(string name, double value)
        {
            return Get(name).From(value);
        }

        public double ToDo(int index, double value)
        {
            return Get(index).To(value);
        }

        public double ToDo(double value) => ToDo(ToIndex, value);

        public double ToDo(string name, double value)
        {
            return Get(name).To(value);
        }

        public MetrsConvert GetFrom()
        {
            return MetrsConvertsList[FromIndex];
        }

        public MetrsConvert GetTo()
        {
            return MetrsConvertsList[ToIndex];
        }
    }
}
