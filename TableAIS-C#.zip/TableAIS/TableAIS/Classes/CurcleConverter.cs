﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    internal class CurcleConverter : ConverterList
    {
        public CurcleConverter() : base() 
        {
            MetrsConvert convert = Add("Радиус");
            convert.ConvertFrom = (value) => value;
            convert.ConvertTo = (value) => value;

            convert = Add("Диаметр");
            convert.ConvertFrom = (value) => value / 2;
            convert.ConvertTo = (value) => value*2;

            convert = Add("Длина окружности");
            convert.ConvertFrom = (value) => value / (2*Math.PI);
            convert.ConvertTo = (value) => value * (2 * Math.PI);

            convert = Add("Длина полуокружности");
            convert.ConvertFrom = (value) => FromDo("Длина окружности", value*2);
            convert.ConvertTo = (value) => ToDo("Длина окружности", value) / 2;


            convert = Add("Площадь круга");
            convert.ConvertFrom = (value) =>
            {
                if(value >= 0)
                    return Math.Sqrt(value/Math.PI);
                else
                    return -Math.Sqrt(-value / Math.PI);
            };
            convert.ConvertTo = (value) => Math.Pow(value, 2)*Math.PI;

            convert = Add("Площадь полукруга");
            convert.ConvertFrom = (value) => FromDo("Площадь круга", value * 2);
            convert.ConvertTo = (value) => ToDo("Площадь круга", value) / 2;

            convert = Add("Площадь сферы");
            convert.ConvertFrom = (value) =>
            {
                if (value >= 0)
                    return Math.Sqrt(value / (4.0*Math.PI));
                else
                    return -Math.Sqrt(-value / (4.0 * Math.PI));
            };
            convert.ConvertTo = (value) => Math.Pow(value, 2) * (4 * Math.PI);


            convert = Add("Объём шара");
            convert.ConvertFrom = (value) =>
            {
                if (value >= 0)
                    return Math.Pow((value*3) / (4.0 * Math.PI), 1/3.0);
                else
                    return -Math.Pow((-value * 3) / (4.0 * Math.PI), 1 / 3.0);
            };
            convert.ConvertTo = (value) => Math.Pow(value, 3) * (4 * Math.PI)/3.0;

            convert = Add("Площадь полусферы");
            convert.ConvertFrom = (value) =>
            {
                if (value >= 0)
                    return Math.Sqrt(value / (2.0 * Math.PI));
                else
                    return -Math.Sqrt(-value / (2.0 * Math.PI));
            };
            convert.ConvertTo = (value) => Math.Pow(value, 2) * (2 * Math.PI);

            convert = Add("Объём полушара");
            convert.ConvertFrom = (value) =>
            {
                if (value >= 0)
                    return Math.Pow((value * 3) / (2.0 * Math.PI), 1 / 3.0);
                else
                    return -Math.Pow((-value * 3) / (2.0 * Math.PI), 1 / 3.0);
            };
            convert.ConvertTo = (value) => Math.Pow(value, 3) * (2 * Math.PI) / 3.0;

        }


    }
}
