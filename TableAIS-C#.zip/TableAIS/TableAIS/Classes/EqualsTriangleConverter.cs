﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS.Classes
{
    public class EqualsTriangleConverter : ConverterList
    {
        /// <summary>
        /// Конвертер параметров равностороннего треугольника
        /// </summary>
        public EqualsTriangleConverter() : base()
        {
            MetrsConvert convert = Add("Сторона");
            convert.ConvertFrom = (value) => { return value; };
            convert.ConvertTo = (value) => { return value; };

            convert = Add("Радиус описанной окружности");
            convert.ConvertFrom = (value) => { return value*3/Math.Sqrt(3); };
            convert.ConvertTo = (value) => {
                double a = value;
                a *= Math.Sqrt(3);
                a /= 3;
                return a;
            };
            MetrsConvert curcle1 = convert;

            convert = Add("Диаметр описанной окружности");
            convert.ConvertFrom = (value) => { return curcle1.From(value/2); };
            convert.ConvertTo = (value) => {
                return curcle1.To(value*2);
            };

            convert = Add("Длина описанной окружности");
            convert.ConvertFrom = (value) => { return curcle1.From(value /( 2*Math.PI)); };
            convert.ConvertTo = (value) => {
                return curcle1.To(value ) * (2 * Math.PI);
            };

            convert = Add("Площадь круга с описанной окружностью");
            convert.ConvertFrom = (value) => {
                int number = 1;
                if (value < 0)
                {
                    value = -value;
                    number *= (-1);
                }
                return curcle1.From(Math.Sqrt(value / (Math.PI)))*number; };
            convert.ConvertTo = (value) => {
                return Math.Pow(curcle1.To(value), 2) * (Math.PI);
            };

            convert = Add("Радиус вписанной окружности");
            convert.ConvertFrom = (value) => { return value * 6 / Math.Sqrt(3); };
            convert.ConvertTo = (value) => {
                double a = value;
                a *= Math.Sqrt(3);
                a /= 6;
                return a;
            };
            MetrsConvert curcle2 = convert;


            convert = Add("Диаметр вписанной окружности");
            convert.ConvertFrom = (value) => { return curcle2.From(value / 2); };
            convert.ConvertTo = (value) => {
                return curcle2.To(value)* 2;
            };

            convert = Add("Длина вписанной окружности");
            convert.ConvertFrom = (value) => { return curcle2.From(value / (2 * Math.PI)); };
            convert.ConvertTo = (value) => {
                return curcle2.To(value) * (2 * Math.PI);
            };

            convert = Add("Площадь круга с вписанной окружностью");
            convert.ConvertFrom = (value) => {
                int number = 1;
                if (value < 0)
                {
                    value = -value;
                    number *= (-1);
                }
                return curcle2.From(Math.Sqrt(value / (Math.PI)))*number; };
            convert.ConvertTo = (value) => {
                return Math.Pow(curcle2.To(value), 2) * (Math.PI);
            };

            convert = Add("Площадь");
            convert.ConvertFrom = (value) => 
            {
                double a = value;
                a *= 4;
                a /= Math.Sqrt(3);
                if(a < 0)
                {
                    return -Math.Sqrt(-a);
                }
                return Math.Sqrt(a);
            };
            convert.ConvertTo = (value) => 
            {
                double a = value;
                a *= value;
                a *= Math.Sqrt(3);
                a /= 4;
                return a;
            };

            convert = Add("Высота");
            convert.ConvertFrom = (value) =>
            {
                double a = value;
                a /= (Math.Sqrt(3) / 2);
                return a;
            };
            convert.ConvertTo = (value) =>
            {
                double a = value;
                a *= (Math.Sqrt(3)/2);
                return a;
            };

        }

    }
}
