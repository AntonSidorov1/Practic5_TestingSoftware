﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Исключение, вызванное из аргументов, переданных функции
    /// </summary>
    public abstract class FuncArgumentsExceptions : FuncDoingException
    {
        protected FuncArgumentsExceptions(FuncNames featcher) : this(featcher, "Исключение, вызванное из аргументов, переданных функции")
        {
        }

        protected FuncArgumentsExceptions(FuncNames featcher, string message) : base(featcher, message)
        {
        }
    }
}
