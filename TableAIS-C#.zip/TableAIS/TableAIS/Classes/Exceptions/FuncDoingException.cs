﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class FuncDoingException : Exception
    {
        public FuncDoingException(FuncNames featcher) : this(featcher, "Исключение вызванное при работе функции "+ featcher.GetNameWithNumber())
        {
        }

        public FuncDoingException(FuncNames featcher, string message) : base(message)
        {
            Featcher = featcher;
        }


        FuncNames featcher;

        /// <summary>
        /// Функция
        /// </summary>
        public FuncNames Featcher
        {
            get => featcher;
            set => featcher = value;
        }

        /// <summary>
        /// Выполнить код функции
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public abstract double Run(double number);
    }
}
