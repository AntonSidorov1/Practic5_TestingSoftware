﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class FuncsOneArgumentExceptions : FuncArgumentsExceptions
    {
        public FuncsOneArgumentExceptions(double argument, FuncNames featcher) : this(argument, featcher, "Вызванная функция должна иметь 2 аргумента")
        {
        }

        public FuncsOneArgumentExceptions(double argument, FuncNames featcher, string message) : base(featcher, "Исключение вызванное при работе функции " + featcher.GetNameWithNumber()+":\n"+message)
        {
            Argument = argument;
        }

        double argument;

        /// <summary>
        /// Аргумент функции
        /// </summary>
        public double Argument
        {
            get => argument;
            set => argument = value;
        }
/// <inheritdoc/>

        public override double Run(double number)
        {
            return Featcher.FuncDoingInvoke(number, argument);
        }
    }
}
