﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class ManyFuncsOneExceptions : FuncArgumentsExceptions
    {
        FormulePartList partList;
        public ManyFuncsOneExceptions(FuncNames featcher) : this(featcher, "При вызове функции было несколько исключений вида FuncArgumentException")
        {
        }

        public ManyFuncsOneExceptions(FuncNames featcher, params double[] numbers):this(featcher)
        {
            AddVarN();
            AddNumbers(numbers);
        }

        public void AddVarN()
        {
            partList.AddStaticVariable("N");
        }

        public ManyFuncsOneExceptions(FuncNames featcher, string message) : base(featcher, "Исключение вызванное при работе функции " + featcher.GetNameWithNumber() + ":\n" + message)
        {
            partList = new FormulePartList();
            partList.AddFunction(featcher);
            partList.AddOpenBasket(false);
        }

        public void AddNumber(double number)
        {
            partList.AddFormule(";" + number);
        }

        public void AddNumbers(params double[] numbers)
        {
            foreach(double number in numbers)
            {
                AddNumber(number);
            }
        }

        public void Add(FuncsOneArgumentExceptions funcsOneArgument)
        {
           
            partList.AddFunction(funcsOneArgument.Featcher);
            partList.AddOpenBasket(false);
            partList.AddStaticVariable("N");
            partList.AddArraySplit();
            partList.AddNumber(funcsOneArgument.Argument);
            partList.AddCloseBasket(false);
            partList.AddArraySplit();
        }

        public void Add(ManyFuncsOneExceptions funcsOneArgument)
        {

            partList.AddRange(funcsOneArgument.AddBaskets());
            //partList.AddNumber(funcsOneArgument.Argument);
            partList.AddArraySplit();
        }

        public void AddRange(IEnumerable<FuncsOneArgumentExceptions> values)
        {
            foreach (FuncsOneArgumentExceptions func in values)
            {
                Add(func);
            }
        }

        public void AddRange(IEnumerable<FormuleOperand> values)
        {
            foreach (FormuleOperand func in values)
            {
                if (func.IsFuncOneException)
                    Add(func.AsFuncOneException.Exception);

                if (func.IsManyFuncsArgExceptions)
                    Add(func.AsManyFuncsArgExceptions.Exception);
            }
        }


        public FormulePartList Postfics() => MyCalculate.ConvertToPostfics(MyCalculate.ReplaceToFullFuncsCodeInteractive(partList, 'N'));

        public override double Run(double number)
        {
            return MyCalculate.CalcByFx(Postfics(), number, 'N');
        }

        public FormulePartList AddBaskets()
        {
            return MyCalculate.AddBasketsInteractive(partList, 'N');
        }
    }
}
