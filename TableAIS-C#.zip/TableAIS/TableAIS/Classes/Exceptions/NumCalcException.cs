﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    class NumCalcException : Exception
    {
        public NumCalcException(double number) : this(number, "Результат работы функции может быть обраблтан разными способами")
        {
            Number = number;
        }

        public NumCalcException(double number, string message) : base(message)
        {
            Number = number;
        }


        double number;

        public double Number
        {
            get => number; set => number = value;
        }
    }
}
