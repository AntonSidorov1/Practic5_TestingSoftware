﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    internal class FuncConverter : BynarConverter
    {
        public FuncConverter() : base()
        {
            MetrsConvert convert = Add("z");
            convert.ConvertFrom = (z) => z;
            convert.ConvertTo = (z) => z;

            convert = Add("z%");
            convert.ConvertFrom = (z) => z*100;
            convert.ConvertTo = (z) => z/100;

            convert = Add("1-(z%)");
            convert.ConvertFrom = (z) => (1-z) * 100;
            convert.ConvertTo = (z) => 1-z / 100;

            convert = Add("|z|%");
            convert.ConvertFrom = (z) => Math.Abs(z) * 100;
            convert.ConvertTo = (z) => Math.Abs(z) / 100;

            convert = Add("1-|z|%");
            convert.ConvertFrom = (z) => (1-Math.Abs(z)) * 100;
            convert.ConvertTo = (z) => 1- Math.Abs(z) / 100;

            convert = Add("-|z|%");
            convert.ConvertFrom = (z) => -Math.Abs(z) * 100;
            convert.ConvertTo = (z) => -Math.Abs(z) / 100;

            convert = Add("1/z");
            convert.ConvertFrom = (z) =>
            {
                if (z == 0)
                    throw new ArgumentException();
                return 1 / z;
            };
            convert.ConvertTo = convert.ConvertFrom;

            convert = Add("-1/z");
            convert.ConvertFrom = (z) =>
            {
                if (z == 0)
                    throw new ArgumentException();
                return -1 / z;
            };
            convert.ConvertTo = convert.ConvertFrom;

            convert = Add("1/|z|");
            convert.ConvertFrom = (z) =>
            {
                return FromDo("1/z", Math.Abs(z));
            };
            convert.ConvertTo = convert.ConvertFrom;

            convert = Add("-1/|z|");
            convert.ConvertFrom = (z) =>
            {
                return -FromDo("1/z", Math.Abs(z));
            };
            convert.ConvertTo = convert.ConvertFrom;

            convert = Add("2*z");
            convert.ConvertFrom = (z) => z/2;
            convert.ConvertTo = (z) => z*2;

            convert = Add("z*PI");
            convert.ConvertFrom = (z) => z / Math.PI;
            convert.ConvertTo = (z) => z * Math.PI;

            convert = Add("z/PI");
            convert.ConvertFrom = (z) => z * Math.PI;
            convert.ConvertTo = (z) => z / Math.PI;

            convert = Add("z*E");
            convert.ConvertFrom = (z) => z / Math.E;
            convert.ConvertTo = (z) => z * Math.E;

            convert = Add("z/E");
            convert.ConvertFrom = (z) => z * Math.E;
            convert.ConvertTo = (z) => z / Math.E;

            convert = Add("z/2");
            convert.ConvertFrom = (z) => z * 2;
            convert.ConvertTo = (z) => z / 2;

            convert = Add("|z|");
            convert.ConvertFrom = (z) => Math.Abs(z);
            convert.ConvertTo = (z) => Math.Abs(z);

            convert = Add("z^2");
            convert.ConvertFrom = (z) =>
                {
                    if (z < 0)
                        return -Math.Sqrt( -z);
                    else
                        return Math.Sqrt(z);
            };
            convert.ConvertTo = (z) => Math.Pow(z, 2);

            convert = Add("-|z|");
            convert.ConvertFrom = (z) => -Math.Abs(z);
            convert.ConvertTo = (z) => -Math.Abs(z);

            convert = Add("z^2");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0)
                    return -Math.Sqrt(-z);
                else
                    return Math.Sqrt(z);
            };
            convert.ConvertTo = (z) => Math.Pow(z, 2);

            convert = Add("z^3");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0)
                    return -Math.Pow( -z, 1/3.0);
                else
                    return Math.Pow(z, 1 / 3.0);
            };
            convert.ConvertTo = (z) => Math.Pow(z, 3);

            convert = Add("z^(1/2)");
            convert.ConvertTo = (z) =>
            {
                if (z < 0)
                    return -Math.Sqrt(-z);
                else
                    return Math.Sqrt(z);
            };
            convert.ConvertFrom = (z) => Math.Pow(z, 2);
            MetrsConvert sqvr = convert;

            convert = Add("z^(1/3)");
            convert.ConvertTo = (z) =>
            {
                if (z < 0)
                    return -Math.Pow(-z, 1 / 3.0);
                else
                    return Math.Pow(z, 1 / 3.0);
            };
            convert.ConvertFrom = (z) => Math.Pow(z, 3);
            MetrsConvert kubSqvr = convert;

            convert = Add("2^z");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0)
                    throw new ArgumentException();
                else
                    return Math.Log(z, 2);
            };
            convert.ConvertTo = (z) => Math.Pow(2, z);

            convert = Add("2^(-z)");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0)
                    throw new ArgumentException();
                else
                    return -Math.Log(z, 2);
            };
            convert.ConvertTo = (z) => Math.Pow(2, -z);


            convert = Add("log(2, z)");
            convert.ConvertTo = (z) =>
            {
                if (z < 0 || z == 1)
                    throw new ArgumentException();
                else
                    return Math.Log(z, 2);
            };
            convert.ConvertFrom = (z) =>
            {
                
                return Math.Pow(2, z);
            };


            convert = Add("2^(1/z)");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0 || z == 1)
                    throw new ArgumentException();
                else
                    return 1/Math.Log(z, 2);
            };

            convert.ConvertTo = (z) => {
                if (z == 0)
                    throw new ArgumentException();
                return Math.Pow(2, 1/z);
            };

            convert = Add("10^z");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0)
                    throw new ArgumentException();
                else
                    return Math.Log10(z);
            };
            convert.ConvertTo = (z) => Math.Pow(10, z);

            convert = Add("10^(-z)");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0)
                    throw new ArgumentException();
                else
                    return -Math.Log10(z);
            };
            convert.ConvertTo = (z) => Math.Pow(10, -z);


            convert = Add("lg(z)");
            convert.ConvertTo = (z) =>
            {
                if (z < 0 || z == 1)
                    throw new ArgumentException();
                else
                    return 1 / Math.Log10(z);
            };
            convert.ConvertFrom = (z) => Math.Pow(10, z);


            convert = Add("10^(1/z)");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0 || z == 1)
                    throw new ArgumentException();
                else
                    return 1 / Math.Log10(z);
            };

            convert.ConvertTo = (z) => {
                if (z == 0)
                    throw new ArgumentException();
                return Math.Pow(2, 1/z);
            };

            convert = Add("e^z");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0)
                    throw new ArgumentException();
                else
                    return Math.Log(z);
            };
            convert.ConvertTo = (z) => Math.Pow(Math.E, z);

            convert = Add("pi^z");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0)
                    throw new ArgumentException();
                else
                    return Math.Log(z, Math.PI);
            };
            convert.ConvertTo = (z) => Math.Pow(Math.PI, z);

            convert = Add("e^(-z)");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0)
                    throw new ArgumentException();
                else
                    return -Math.Log(z);
            };
            convert.ConvertTo = (z) => Math.Pow(Math.E, -z);

            convert = Add("pi^(-z)");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0)
                    throw new ArgumentException();
                else
                    return -Math.Log(z, Math.PI);
            };
            convert.ConvertTo = (z) => Math.Pow(Math.PI, -z);


            convert = Add("ln(z)");
            convert.ConvertTo = (z) =>
            {
                if (z < 0 || z == 1)
                    throw new ArgumentException();
                else
                    return Math.Log(z);
            };
            convert.ConvertFrom = (z) => Math.Pow(Math.E, z);

            convert = Add("log(pi, z)");
            convert.ConvertTo = (z) =>
            {
                if (z < 0 || z == 1)
                    throw new ArgumentException();
                else
                    return Math.Log(z, Math.PI);
            };
            convert.ConvertFrom = (z) => Math.Pow(Math.PI, z);


            convert = Add("e^(1/z)");
            convert.ConvertFrom = (z) =>
            {
                if (z < 0 || z == 1)
                    throw new ArgumentException();
                else
                    return 1 / Math.Log(z);
            };

            convert.ConvertTo = (z) => {
                if (z == 0)
                    throw new ArgumentException();
                return Math.Pow(2, 1 / z);
            };


            BynarConvert bynar = AddBynar("Max(x, y)");
            bynar.Calculate = (x, y) => Math.Max(x, y);

            bynar = AddBynar("Min(x, y)");
            bynar.Calculate = (x, y) => Math.Min(x, y);

            bynar = AddBynar("Среднее(x, y)");
            bynar.Calculate = (x, y) => (x + y) / 2;

            bynar = AddBynar("Размах(x, y)");
            bynar.Calculate = (x, y) =>
            {
                double min = Math.Min(x, y);
                double max = Math.Max(x, y);
                return Math.Abs(max - min);
            };

            bynar = AddBynar("Округить x до y знаков");
            bynar.Calculate = (x, y) => Math.Round(x, (int)y);

            bynar = AddBynar("Округить y до x знаков");
            bynar.Calculate = (x, y) => Math.Round(y, (int)x);

            bynar = AddBynar("y");
            bynar.Calculate = (x, y) => y;

            bynar = AddBynar("x");
            bynar.Calculate = (x, y) => x;

            bynar = AddBynar("x+y");
            bynar.Calculate = (x, y) => x+y;

            bynar = AddBynar("x-y");
            bynar.Calculate = (x, y) => x - y;

            bynar = AddBynar("y-x");
            bynar.Calculate = (x, y) => y - x;

            bynar = AddBynar("x*y");
            bynar.Calculate = (x, y) => x * y;

            bynar = AddBynar("x/y");
            bynar.Calculate = (x, y) =>
            {
                if (y == 0)
                    throw new ArgumentException();
                return x / y;
            };

            bynar = AddBynar("y/x");
            bynar.Calculate = (x, y) => {
                if (x == 0)
                    throw new ArgumentException();
                return y / x;
            };


            bynar = AddBynar("x^y");
            bynar.Calculate = (x, y) =>
            {
                if(x == 0 && y <= 0)
                    throw new ArgumentException();
                return Math.Pow(x, y);
            };

            bynar = AddBynar("y^x");
            bynar.Calculate = (x, y) =>
            {
                if (x <= 0 && y == 0)
                    throw new ArgumentException();
                return Math.Pow(y, x);
            };


            bynar = AddBynar("x+y%");
            bynar.Calculate = (x, y) => x + x*(y/100);

            bynar = AddBynar("y+x%");
            bynar.Calculate = (x, y) => y + y * (x / 100);

            bynar = AddBynar("x-y%");
            bynar.Calculate = (x, y) => x - x * (y / 100);

            bynar = AddBynar("y-x%");
            bynar.Calculate = (x, y) => y - y * (x / 100);

            bynar = AddBynar("x*y%");
            bynar.Calculate = (x, y) => x *  (y / 100);

            bynar = AddBynar("y*x%");
            bynar.Calculate = (x, y) => y *  (x / 100);

            bynar = AddBynar("x/y%");
            bynar.Calculate = (x, y) =>
            {
                if(x == 0 || y == 0)
                    throw new ArgumentException();
                return x / (y / 100);
            };

            bynar = AddBynar("y/x%");
            bynar.Calculate = (x, y) =>
            {
                if (x == 0 || y == 0)
                    throw new ArgumentException();
                return y / (x / 100);
            };


            bynar = AddBynar("(x^2)+(y^2)");
            bynar.Calculate = (x, y) => Math.Pow(x, 2) + Math.Pow(y, 2);

            bynar = AddBynar("(x^2)-(y^2)");
            bynar.Calculate = (x, y) => Math.Pow(x, 2) - Math.Pow(y, 2);

            bynar = AddBynar("(y^2)-(x^2)");
            bynar.Calculate = (x, y) => Math.Pow(y, 2) - Math.Pow(x, 2);

            bynar = AddBynar("((x^2)+(y^2))^(1/2)");
            bynar.Calculate = (x, y) => sqvr.To(Math.Pow(x, 2) + Math.Pow(y, 2));

            bynar = AddBynar("((x^2)-(y^2))^(1/2)");
            bynar.Calculate = (x, y) => sqvr.To(Math.Pow(x, 2) - Math.Pow(y, 2));

            bynar = AddBynar("((y^2)-(x^2))^(1/2)");
            bynar.Calculate = (x, y) => sqvr.To(Math.Pow(y, 2) - Math.Pow(x, 2));

            bynar = AddBynar("(x^3)+(y^3)");
            bynar.Calculate = (x, y) => Math.Pow(x, 3) + Math.Pow(y, 3);

            bynar = AddBynar("(x^3)-(y^3)");
            bynar.Calculate = (x, y) => Math.Pow(x, 3) - Math.Pow(y, 3);

            bynar = AddBynar("(y^3)-(x^3)");
            bynar.Calculate = (x, y) => Math.Pow(y, 3) - Math.Pow(x, 3);

            bynar = AddBynar("((x^3)+(y^3))^(1/3)");
            bynar.Calculate = (x, y) => kubSqvr.To( Math.Pow(x, 3) + Math.Pow(y, 3));

            bynar = AddBynar("((x^3)-(y^3))^(1/3)");
            bynar.Calculate = (x, y) => kubSqvr.To( Math.Pow(x, 3) - Math.Pow(y, 3));

            bynar = AddBynar("((y^3)-(x^3))^(1/3)");
            bynar.Calculate = (x, y) => kubSqvr.To( Math.Pow(y, 3) - Math.Pow(x, 3));

            bynar = AddBynar("(x+y)^2");
            bynar.Calculate = (x, y) => Math.Pow(x + y, 2);

            bynar = AddBynar("(x-y)^2");
            bynar.Calculate = (x, y) => Math.Pow(x - y, 2);

            bynar = AddBynar("(y-x)^2");
            bynar.Calculate = (x, y) => Math.Pow(y - x, 2);

            bynar = AddBynar("(x+y)^3");
            bynar.Calculate = (x, y) => Math.Pow(x + y, 3);

            bynar = AddBynar("(x-y)^3");
            bynar.Calculate = (x, y) => Math.Pow(x - y, 3);

            bynar = AddBynar("(y-x)^3");
            bynar.Calculate = (x, y) => Math.Pow(y - x, 3);

            bynar = AddBynar("(x+y)^(1/2)");
            bynar.Calculate = (x, y) => sqvr.To(x + y);

            bynar = AddBynar("(x-y)^(1/2)");
            bynar.Calculate = (x, y) => sqvr.To(x - y);

            bynar = AddBynar("(y-x)^(1/2)");
            bynar.Calculate = (x, y) => sqvr.To(y - x);

            bynar = AddBynar("(x+y)^(1/3)");
            bynar.Calculate = (x, y) => kubSqvr.To(x + y);

            bynar = AddBynar("(x-y)^(1/3)");
            bynar.Calculate = (x, y) => kubSqvr.To(x - y);

            bynar = AddBynar("(y-x)^(1/3)");
            bynar.Calculate = (x, y) => kubSqvr.To(y - x);

            bynar = AddBynar("log(x, y)");
            bynar.Calculate = (x, y) =>
            {
                if (x <= 0 || x == 1 || y <= 0)
                    throw new Exception();
                return Math.Log(y, x);
            };

            bynar = AddBynar("log(y, x)");
            bynar.Calculate = (x, y) =>
            {
                double z = x;
                x = y;
                y = z;
                if (x <= 0 || x == 1 || y <= 0)
                    throw new Exception();
                return Math.Log(y, x);
            };

            bynar = AddBynar("x\\y");
            bynar.Calculate = (x, y) => CalculatorFunc.Stepen(x, y);

            bynar = AddBynar("x-/-y");
            bynar.Calculate = (x, y) => CalculatorFunc.Stepen(x, y);


            bynar = AddBynar("y\\x");
            bynar.Calculate = (x, y) => CalculatorFunc.Stepen(y, x);

            bynar = AddBynar("y-/-x");
            bynar.Calculate = (x, y) => CalculatorFunc.Stepen(y, x);


        }
    }
}
