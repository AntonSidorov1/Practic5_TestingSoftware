﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    internal class GrardusesConverter : ConverterList
    {
        public GrardusesConverter() : base()
        {
            MetrsConvert convert = Add("Градусы Цельсия");
            convert.ConvertFrom = (value) => value;
            convert.ConvertTo = (value) => value;

            convert = Add("Кельвины");
            convert.ConvertFrom = (value) => value-273.15;
            convert.ConvertTo = (value) => value+273.15;

            convert = Add("Фарангейты");
            convert.ConvertFrom = (value) => 5*(value - 32)/9;
            convert.ConvertTo = (value) => 9*value/5 + 32;



        }
    }
}
