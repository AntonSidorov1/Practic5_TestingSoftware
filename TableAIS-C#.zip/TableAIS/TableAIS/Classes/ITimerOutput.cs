﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    internal interface ITimerOutput
    {
        void Update();

       //int a=>0;

    }
}
