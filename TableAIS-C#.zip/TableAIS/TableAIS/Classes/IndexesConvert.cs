﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class IndexesConvert
    {
        public IndexesConvert() : this(-1, -1)
        {
        }

        public IndexesConvert(int from, int to)
        {
            FromIndex = from;
            ToIndex = to;
        }

        int toIndex, fromIndex;

        public int ToIndex
        {
            get { return toIndex; }
            set { toIndex = value; }
        }

        public int FromIndex
        {
            get => fromIndex;
            set => fromIndex = value;
        }
    }
}
