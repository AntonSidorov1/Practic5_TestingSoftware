﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class LengthBigConverter : AbstractBigConverter
    {
        LengthConverter converter;
        public LengthBigConverter(int stepen) : base()
        {
            LengthConverter = new LengthConverter(stepen);
        }

        public int Stepen
        {
            get => LengthConverter.Stepen;
            set => LengthConverter.Stepen = value;
        }

        public override double VariantFrom(double value)
        {
            return LengthConverter.FromDo(value);
        }

        public override double VariantTo(double value)
        {
            return LengthConverter.ToDo(value);
        }

        public int LengthFromIndex
        {
            get => LengthConverter.FromIndex;
            set => LengthConverter.FromIndex = value;
        }

        public int LengthToIndex
        {
            get => LengthConverter.ToIndex;
            set => LengthConverter.ToIndex = value;
        }

        public MetrsConvert[] LengthList
            => LengthConverter.MetrsConvertsArray;

        public LengthConverter LengthConverter
        {
            get => converter;
            set => converter = value;
        }
    }
}
