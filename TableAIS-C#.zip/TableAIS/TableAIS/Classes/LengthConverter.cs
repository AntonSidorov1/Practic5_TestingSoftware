﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class LengthConverter : ConverterList
    {
        int stepen;

        public int Stepen
        {
            get => stepen; set => stepen = value;
        }

        public int StepenMines
        {
            get => Stepen - 1;
            set => Stepen = value + 1;
        }

        public LengthConverter():this(1)
        {

        }

        public LengthConverter(int stepenPlus) : base()
        {
            Stepen = stepenPlus;
            MetrsConvert convert = Add("Метры");
            convert.ConvertFrom = (value) => { return value; };
            convert.ConvertTo = (value) => { return value; };

            convert = Add("Дюймы");
            convert.ConvertFrom = (value) => { return value * Math.Pow(0.025400000025908, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(0.025400000025908, Stepen); };

            convert = Add("Мили");
            convert.ConvertFrom = (value) => { return value * Math.Pow(1609.269391696169939, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(1609.269391696169939, Stepen); };

            convert = Add("Ярды");
            convert.ConvertFrom = (value) => { return value * Math.Pow(0.91439998610112, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(0.91439998610112, Stepen); };

            convert = Add("Морские мили");
            convert.ConvertFrom = (value) => { return value * Math.Pow(1851.851851851851852, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(1851.851851851851852, Stepen); };

            convert = Add("Фатомы");
            convert.ConvertFrom = (value) => { return value * Math.Pow(1.828800164445711, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(1.828800164445711, Stepen); };

            convert = Add("Фарлонги");
            convert.ConvertFrom = (value) => { return value * Math.Pow(201.166767250050292, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(201.166767250050292, Stepen); };

            convert = Add("Фурлонги");
            convert.ConvertFrom = (value) => { return value * Math.Pow(201.168, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(201.168, Stepen); };

            convert = Add("Чейны");
            convert.ConvertFrom = (value) => { return value * Math.Pow(20.1168, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(20.1168, Stepen); };

            convert = Add("Кабельтовы");
            convert.ConvertFrom = (value) => { return value * Math.Pow(185.2, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(185.2, Stepen); };

            convert = Add("Вершки");
            convert.ConvertFrom = (value) => { return value * Math.Pow(0.04445, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(0.04445, Stepen); };

            convert = Add("Аршины");
            convert.ConvertFrom = (value) => { return value * Math.Pow(0.7112, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(0.7112, Stepen); };

            convert = Add("Футы");
            convert.ConvertFrom = (value) => { return value * Math.Pow(0.304799999536704, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(0.304799999536704, Stepen); };

            convert = Add("Четверти");
            convert.ConvertFrom = (value) => { return value *Math.Pow(2.133562, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(2.133562, Stepen); };

            convert = Add("Сажени");
            convert.ConvertFrom = (value) => { return value / Math.Pow(0.54, Stepen); };
            convert.ConvertTo = (value) => { return value * Math.Pow(0.54, Stepen); };

            convert = Add("Децеметры");
            convert.ConvertFrom = (value) => { return value/10 / Math.Pow(10, StepenMines); };
            convert.ConvertTo = (value) => { return value*10 * Math.Pow(10, StepenMines); };

            convert = Add("Сантиметры");
            convert.ConvertFrom = (value) => { return value / 100/Math.Pow(100, StepenMines); };
            convert.ConvertTo = (value) => { return value * 100* Math.Pow(100, StepenMines); };
            MetrsConvert santimetrs = convert;

            convert = Add("Миллиметры");
            convert.ConvertFrom = (value) => { return value / Math.Pow(10, 3)/ Math.Pow(1000, StepenMines); };
            convert.ConvertTo = (value) => { return value * 1000*Math.Pow(1000, StepenMines); };

            convert = Add("Ангстремы");
            convert.ConvertFrom = (value) => { return value / Math.Pow(10, 10) / Math.Pow(10, StepenMines*10); };
            convert.ConvertTo = (value) => { return value * Math.Pow(10, 10)* Math.Pow(10, StepenMines * 10); };

            convert = Add("Тоу");
            convert.ConvertFrom = (value) => { return value /Math.Pow((2.54* Math.Pow(10.0, -5.0)), Stepen); };
            convert.ConvertTo = (value) => { return value * Math.Pow((2.54 * Math.Pow(10.0, -5.0)), Stepen); };

            convert = Add("Микрометры");
            convert.ConvertFrom = (value) => { return value / Math.Pow(10, 6) / Math.Pow(10, StepenMines * 6); };
            convert.ConvertTo = (value) => { return value * Math.Pow(10, 6)* Math.Pow(10, StepenMines * 6); };

            convert = Add("Нанометры");
            convert.ConvertFrom = (value) => { return value / Math.Pow(10, 9)/ Math.Pow(10, StepenMines * 9); };
            convert.ConvertTo = (value) => { return value * Math.Pow(10, 9)* Math.Pow(10, StepenMines * 9); };

            convert = Add("Пикометры");
            convert.ConvertFrom = (value) => { return value / Math.Pow(10, 12)/ Math.Pow(10, StepenMines * 12); };
            convert.ConvertTo = (value) => { return value * Math.Pow(10, 12)* Math.Pow(10, StepenMines * 12); };

            convert = Add("Декаметры");
            convert.ConvertFrom = (value) => { return value * Math.Pow(10, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(10, Stepen); };

            convert = Add("Гектометры");
            convert.ConvertFrom = (value) => { return value * Math.Pow(100, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(100, Stepen); };

            string kilometers = "Километры";
            convert = Add(kilometers);
            convert.ConvertFrom = (value) => { return value * Math.Pow(1000, Stepen); };
            convert.ConvertTo = (value) => { return value / Math.Pow(1000, Stepen); };

            convert = Add("Мегаметры");
            convert.ConvertFrom = (value) => { return value * Math.Pow(10, 6)* Math.Pow(10, StepenMines * 6); };
            convert.ConvertTo = (value) => { return value / Math.Pow(10, 6)/ Math.Pow(10, StepenMines * 6); };

            convert = Add("Гигаметры");
            convert.ConvertFrom = (value) => { return value * Math.Pow(10, 9)* Math.Pow(10, StepenMines * 9); };
            convert.ConvertTo = (value) => { return value / Math.Pow(10, 9)/ Math.Pow(10, StepenMines * 9); };

            convert = Add("Тераметры");
            convert.ConvertFrom = (value) => { return value * Math.Pow(10, 12)* Math.Pow(10, StepenMines * 12); };
            convert.ConvertTo = (value) => { return value / Math.Pow(10, 12)/ Math.Pow(10, StepenMines * 12); };

            string astranoms = "Астрономические единицы";
            double astranom = 149597582.503066750441;
            convert = Add(astranoms);
            convert.ConvertFrom = (value) => FromDo(kilometers, value * Math.Pow(astranom, Stepen));
            convert.ConvertTo = (value) => ToDo(kilometers, value / Math.Pow(astranom, Stepen));

            double astranom1 = 150000000;
            convert = Add(astranoms + " (Упрощённо)");
            convert.ConvertFrom = (value) => FromDo(kilometers, value * Math.Pow(astranom1, Stepen));
            convert.ConvertTo = (value) => ToDo(kilometers, value / Math.Pow(astranom1, Stepen));

            string lun = "Лунные расстояния";
            double luns = 0.00257;
            convert = Add(lun);
            convert.ConvertFrom = (value) => FromDo(astranoms, value * Math.Pow(luns, Stepen));
            convert.ConvertTo = (value) => ToDo(astranoms, value / Math.Pow(luns, Stepen));

            convert = Add("Лунные расстояния 2 ");
            double luns1 = 38400983.065166468261587;
            luns1 = Math.Pow(luns1, Stepen);
            convert.ConvertFrom = (value) => { return value * luns1; };
            convert.ConvertTo = (value) => { return value / luns1; };

            string svet = "Световые года";
            double svets = 63241.0770842663;
            svets = Math.Pow(svets, Stepen);
            convert = Add(svet);
            convert.ConvertFrom = (value) => FromDo(astranoms, value * svets);
            convert.ConvertTo = (value) => ToDo(astranoms, value / svets);

            string parsec = "Парсеки";
            double parsecs = 3.26156377716743;
            parsecs = Math.Pow(parsecs, Stepen);
            convert = Add(parsec);
            convert.ConvertFrom = (value) => FromDo(svet, value * parsecs);
            convert.ConvertTo = (value) => ToDo(svet, value / parsecs);
            MetrsConvert parsecsParse = convert;

            MetrsConvert metrsConvert = Add("Декапарсеки");
            metrsConvert.ConvertTo = (value) => parsecsParse.To(value) / Math.Pow(10, Stepen);
            metrsConvert.ConvertFrom = (value) => parsecsParse.From(value * Math.Pow(10, Stepen));

            metrsConvert = Add("Гектопарсеки");
            metrsConvert.ConvertTo = (value) => parsecsParse.To(value) / Math.Pow(100, Stepen);
            metrsConvert.ConvertFrom = (value) => parsecsParse.From(value * Math.Pow(100, Stepen));

            metrsConvert = Add("Децепарсеки");
            metrsConvert.ConvertFrom = (value) => parsecsParse.From(value / Math.Pow(10, Stepen));
            metrsConvert.ConvertTo = (value) => parsecsParse.To(value ) * Math.Pow(10, Stepen);

            metrsConvert = Add("Сантипарсеки");
            metrsConvert.ConvertFrom = (value) => parsecsParse.From(value / Math.Pow(100, Stepen));
            metrsConvert.ConvertTo = (value) => parsecsParse.To(value ) * Math.Pow(100, Stepen);

            int stepen = 3;
            stepen *= Stepen;
            convert = Add("Милипарсеки");
            convert.ConvertFrom = (value) => parsecsParse.ConvertFrom(value/Math.Pow(10, stepen));
            convert.ConvertTo = (value) => parsecsParse.ConvertTo(value)* Math.Pow(10, stepen);

            convert = Add("Килопарсеки");
            convert.ConvertFrom = (value) => parsecsParse.ConvertFrom(value * Math.Pow(10, stepen));
            convert.ConvertTo = (value) => parsecsParse.ConvertTo(value) / Math.Pow(10, stepen);

            int stepen1 = 6;
            stepen1 *= Stepen;
            convert = Add("Микропарсеки");
            convert.ConvertFrom = (value) => parsecsParse.ConvertFrom(value / Math.Pow(10, stepen1));
            convert.ConvertTo = (value) => parsecsParse.ConvertTo(value) * Math.Pow(10, stepen1);

            convert = Add("Мегапарсеки");
            convert.ConvertFrom = (value) => parsecsParse.ConvertFrom(value * Math.Pow(10, stepen1));
            convert.ConvertTo = (value) => parsecsParse.ConvertTo(value) / Math.Pow(10, stepen1);

            int stepen2 = 9;
            stepen2 *= Stepen;
            convert = Add("Нанопарсеки");
            convert.ConvertFrom = (value) => parsecsParse.ConvertFrom(value / Math.Pow(10, stepen2));
            convert.ConvertTo = (value) => parsecsParse.ConvertTo(value) * Math.Pow(10, stepen2);

            convert = Add("Гигапарсеки");
            convert.ConvertFrom = (value) => parsecsParse.ConvertFrom(value * Math.Pow(10, stepen2));
            convert.ConvertTo = (value) => parsecsParse.ConvertTo(value) / Math.Pow(10, stepen2);

            int stepen3 = 12;
            stepen3 *= Stepen;
            convert = Add("Пикопарсеки");
            convert.ConvertFrom = (value) => parsecsParse.ConvertFrom(value / Math.Pow(10, stepen3));
            convert.ConvertTo = (value) => parsecsParse.ConvertTo(value) * Math.Pow(10, stepen3);

            convert = Add("Терапарсеки");
            convert.ConvertFrom = (value) => parsecsParse.ConvertFrom(value * Math.Pow(10, stepen3));
            convert.ConvertTo = (value) => parsecsParse.ConvertTo(value) / Math.Pow(10, stepen3);

            convert = Add("Пяди");
            MetrsConvert pyad = convert;
            convert.ConvertFrom = (value) => santimetrs.From(value * Math.Pow(17.78, Stepen));
            convert.ConvertTo = (value) => santimetrs.To(value) / Math.Pow(17.78, Stepen);

            convert = Add("Ладони");
            MetrsConvert hands = convert;
            convert.ConvertFrom = (value) => santimetrs.From(value * Math.Pow(7.5, Stepen));
            convert.ConvertTo = (value) => santimetrs.To(value) / Math.Pow(7.5, Stepen);

            convert = Add("Локти");
            MetrsConvert lokot = convert;
            convert.ConvertFrom = (value) => hands.From(value * Math.Pow(6, Stepen));
            convert.ConvertTo = (value) => hands.To(value) / Math.Pow(6, Stepen);

            convert = Add("Аршины (рука)");
            MetrsConvert arshin = convert;
            convert.ConvertFrom = (value) => santimetrs.From(value * Math.Pow(71.12, Stepen));
            convert.ConvertTo = (value) => santimetrs.To(value) / Math.Pow(71.12, Stepen);

            convert = Add("Вёрсты");
            MetrsConvert verts = convert;
            convert.ConvertFrom = (value) => arshin.From(value * Math.Pow(1500, Stepen));
            convert.ConvertTo = (value) => arshin.To(value) / Math.Pow(1500, Stepen);

            convert = Add("Футы (нога)");
            MetrsConvert phoot = convert;
            convert.ConvertFrom = (value) => santimetrs.From(value * Math.Pow(30.48, Stepen));
            convert.ConvertTo = (value) => santimetrs.To(value) / Math.Pow(30.48, Stepen);

            convert = Add("Шаги (нога)");
            MetrsConvert step = convert;
            convert.ConvertFrom = (value) => santimetrs.From(value * Math.Pow(71, Stepen));
            convert.ConvertTo = (value) => santimetrs.To(value) / Math.Pow(71, Stepen);

            convert = Add("Косые сажени");
            MetrsConvert kosSazhen = convert;
            convert.ConvertFrom = (value) => value*Math.Pow(2.48, Stepen);
            convert.ConvertTo = (value) => value / Math.Pow(2.48, Stepen);

            convert = Add("Маховые сажени");
            MetrsConvert mahSazhen = convert;
            convert.ConvertFrom = (value) => value * Math.Pow(1.78, Stepen);
            convert.ConvertTo = (value) => value / Math.Pow(1.78, Stepen);

            double rod = 5.0292;
            rod = Math.Pow(rod, Stepen);
            convert = Add("Роды");
            convert.ConvertFrom = (value) => value * rod;
            convert.ConvertTo = (value) => value / rod;

            double link = 0.201168;
            link = Math.Pow(link, Stepen);
            convert = Add("Линки");
            convert.ConvertFrom = (value) => value * link;
            convert.ConvertTo = (value) => value / link;

            convert = Add("Звенья");
            convert.ConvertFrom = (value) => value * link;
            convert.ConvertTo = (value) => value / link;

            double rod1 = SquareConverter.LengthRod;
            rod1 = Math.Pow(rod1, Stepen);
            convert = Add("Роды (от площади)");
            convert.ConvertFrom = (value) => value * rod1;
            convert.ConvertTo = (value) => value / rod1;

            double rod2 = SquareConverter.Link;
            rod2 = Math.Pow(rod2, Stepen);
            convert = Add("Звенья (от площади)");
            convert.ConvertFrom = (value) => value * rod2;
            convert.ConvertTo = (value) => value / rod2;

            convert = Add("Линки (от площади)");
            convert.ConvertFrom = (value) => value * rod2;
            convert.ConvertTo = (value) => value / rod2;

        }
    }
    
}
