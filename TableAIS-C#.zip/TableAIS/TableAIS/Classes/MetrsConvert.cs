﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Конвертер единиц измерения
    /// </summary>
    public class MetrsConvert : NameConverter
    {
        public MetrsConvert() : this("") {

        }

        public MetrsConvert(string name) : base()
        {
            Name = name;
        }

        Func<double, double> convertFrom, convertTo;

        public Func<double, double> ConvertFrom
        {
            get => convertFrom; set => convertFrom = value;
        }

        public Func<double, double> ConvertTo
        {
            get => convertTo; set => convertTo = value;
        }

        public double From(double value) => ConvertFrom?.Invoke(value)??0;
        public double To(double value) => ConvertTo?.Invoke(value) ?? 0;

        public bool IsBoth()
        {
            return this is BothConvert;
        }

        public bool IsNoBoth()
        {
            return !IsBoth();
        }

        public BothConvert AsBoth()
        {
            return this as BothConvert;
        }

        public bool IsStepen()
        {
            return this is StepenConvert;
        }

        public bool IsNoStepen()
        {
            return !IsStepen();
        }

        public StepenConvert AsStepen()
        {
            return this as StepenConvert;
        }

        public bool IsPokazatel()
        {
            return this is PokazatelConvert;
        }

        public bool IsNoPokazatel()
        {
            return !IsPokazatel();
        }

        public PokazatelConvert AsPokazatel()
        {
            return this as PokazatelConvert;
        }

    }
}
