﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class MetrsConvertMaker : AbstractConverter
    {
        public MetrsConvertMaker() : this(new MetrsConvert(), new MetrsConvert())
        {
        }

        public MetrsConvertMaker(MetrsConvert from, MetrsConvert to) : base()
        {
            From = from;
            To = to;
        }

        MetrsConvert from, to;

        public MetrsConvert From
        {
            get => from; set => from = value;
        }

        public MetrsConvert To
        {
            get => to; set => to = value;
        }

        public override string NameConvert => From.NameConvert + " -> " + To.NameConvert;

        public double Convert(double value)
        {
            return To.To(From.From(value));
        }
    }
}
