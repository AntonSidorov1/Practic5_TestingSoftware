﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class NameConverter : AbstractConverter
    {
        public NameConverter() : base()
        {
            Create();
        }

        public NameConverter(string name):this()
        {
            Name = name;
        }

        public virtual void Create()
        {
            Name = "";
        }


        string name;

        public string Name
        {
            get => name; set => name = value;
        }

        public override string NameConvert => Name;

    }
}
