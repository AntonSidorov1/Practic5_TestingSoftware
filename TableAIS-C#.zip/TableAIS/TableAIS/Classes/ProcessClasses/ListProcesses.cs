﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class ListProcesses : List<ProcessClass>
    {
        public ListProcesses()
        {
        }

        public ListProcesses(int capacity) : base(capacity)
        {
        }

        public ListProcesses(IEnumerable<ProcessClass> collection) : base(collection)
        {
        }

        public ListProcesses(IEnumerable<Process> list)
        {
            SetByProcessList(list);
        }

        public ListProcesses SetByProcessList(IEnumerable<Process> list)
        {
            foreach (Process process in list)
            {
                Add(new ProcessClass(process));
            }

            return this;
        }

        public static ListProcesses GetByName(string name)
        {
            return ProcessClass.GetByName(name);
        }
    }
}
