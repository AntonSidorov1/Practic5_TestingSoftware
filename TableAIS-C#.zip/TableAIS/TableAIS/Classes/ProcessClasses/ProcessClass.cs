﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class ProcessClass
    {
        public ProcessClass()
        {
            Name = "";
            PID = 0;
        }

        public string Name;
        public int PID;

        public int Id
        {
            get => PID;
            set => PID = value;
        }

        public string ProcessName
        {
            get => Name;
            set => Name = value;
        }

        public string GetInfo()
        {
            return Name+"-"+PID;
        }

        public override string ToString()
        {
            return GetInfo();
        }

        public void SetProcess(Process value)
        {
            Process process = value;
            Name = process.ProcessName;
            PID = process.Id;
        }

        public void SetProcess(ProcessClass value)
        {
            ProcessClass process = value;
            Name = process.ProcessName;
            PID = process.Id;
        }

        public ProcessClass(Process process) : this()
        {
            SetProcess(process);
        }

        public ProcessClass(ProcessClass process) : this()
        {
            SetProcess(process);
        }

        public static ListProcesses GetByName(string name)
        {
            return new ListProcesses(Process.GetProcessesByName(name));
        }

        public static ProcessClass GetByID(int id)
        {
            return new ProcessClass(Process.GetProcessById(id));
        }

        public static ProcessClass GetCurrentProcess()
        {
            return new ProcessClass(Process.GetCurrentProcess());
        }

        public Process GetProcess() => Process.GetProcessById(PID);

        public ProcessClass Copy() => new ProcessClass(this);
    }
}
