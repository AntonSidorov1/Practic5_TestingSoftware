﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS.Classes
{
    public static class PropertiesHelper
    {
        /// <summary>
        /// Постоянный буфер
        /// </summary>
        public static string Buffer
        {
            get => Properties.Settings.Default.Buffer;
            set
            {
                Properties.Settings.Default.Buffer = value;
                Properties.Settings.Default.Save();
            }
        }

        /// <summary>
        /// Очистить постоянный буфер
        /// </summary>
        public static void ClearBuffer()
        {
            Buffer = "";
        }

    }
}
