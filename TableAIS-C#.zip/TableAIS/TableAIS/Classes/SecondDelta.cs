﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS.Classes
{
    public class SecondDelta
    {
        DateTime timeStart;

        bool isTimer;

        public void StartMines(TimeSpan span)
        {
            TimeStart = TimeStart.Subtract(span);
        }

        public void SetFull(string text)
        {
            StartNowMines(Full(text));
        }

        public void AddFull(string text)
        {
            StartMines(Full(text));
        }

        public void SubFull(string text)
        {
            StartAdd(Full(text));
        }

        public static TimeSpan Full(string text)
        {
            int hour, minute, second, millisecond;
            text = text.Replace('.', ',');
            string[] parts = text.Split(':');
            hour = int.Parse(parts[0]);
            minute = int.Parse(parts[1]);
            try
            {
                double seconds = double.Parse(parts[2]);
                TimeSpan secondSpan = TimeSpan.FromSeconds(seconds);
                second = secondSpan.Seconds;
                millisecond = secondSpan.Milliseconds;
            }
            catch
            {
                second = 0;
                millisecond = 0;
            }
            return new TimeSpan(0, hour, minute, second, millisecond);
        }

        public static TimeSpan MinutesFull(string text)
        {
            string[] parts = text.Split(':');
            int minute = int.Parse(parts[0]);
            int hour = minute / 60;
            minute %= 60;
            text = String.Join(":", hour, minute, parts[1]);
            return Full(text);
        }

        public void SetPlusHours(string text)
        {
            StartNowMines(MinutesFull(text));
        }

        public void AddPlusHours(string text)
        {
            StartMines(MinutesFull(text));
        }

        public void SubPlusHours(string text)
        {
            StartAdd(MinutesFull(text));
        }

        public static TimeSpan HourMinutes(string text)
        {
            text = text.Replace('.', ',');
            string[] parts = text.Split(':');
            int hour = int.Parse(parts[0]);
            double minutes = double.Parse(parts[1]);
            TimeSpan minutesSpan = TimeSpan.FromMinutes(minutes);
            int minute = minutesSpan.Minutes;
            int second = minutesSpan.Seconds;
            int millisecond = minutesSpan.Milliseconds;
            text = hour + ":" + minute + ":" + second+"."+millisecond;
            return Full(text);
            

        }

        public void SetHourMinutes(string text)
        {
            StartNowMines(HourMinutes(text));
        }

        public void AddHourMinutes(string text)
        {
            StartMines(HourMinutes(text));
        }

        public void SubHourMinutes(string text)
        {
            StartAdd(HourMinutes(text));
        }

        public void SetMilliseconds(double milliseconds)
        {
            
            TimeSpan ts = TimeSpan.FromMilliseconds(milliseconds);
            StartNowMines(ts);
        }

        public void SetSeconds(double seconds)
        {

            TimeSpan ts = TimeSpan.FromSeconds(seconds);
            StartNowMines(ts);
        }

        public void SetMinutes(double minutes)
        {

            TimeSpan ts = TimeSpan.FromMinutes(minutes);
            StartNowMines(ts);
        }

        public void SetHours(double hours)
        {

            TimeSpan ts = TimeSpan.FromHours(hours);
            StartNowMines(ts);
        }

        public void AddMilliseconds(double milliseconds)
        {

            TimeSpan ts = TimeSpan.FromMilliseconds(milliseconds);
            StartMines(ts);
        }

        public void AddSeconds(double seconds)
        {

            TimeSpan ts = TimeSpan.FromSeconds(seconds);
            StartMines(ts);
        }

        public void AddMinutes(double minutes)
        {

            TimeSpan ts = TimeSpan.FromMinutes(minutes);
            StartMines(ts);
        }

        public void AddHours(double hours)
        {

            TimeSpan ts = TimeSpan.FromHours(hours);
            StartMines(ts);
        }

        public void SubMilliseconds(double milliseconds)
        {

            TimeSpan ts = TimeSpan.FromMilliseconds(milliseconds);
            StartAdd(ts);
        }

        public void SubSeconds(double seconds)
        {

            TimeSpan ts = TimeSpan.FromSeconds(seconds);
            StartMines(ts);
        }

        public void SubMinutes(double minutes)
        {

            TimeSpan ts = TimeSpan.FromMinutes(minutes);
            StartAdd(ts);
        }

        public void SubHours(double hours)
        {

            TimeSpan ts = TimeSpan.FromHours(hours);
            StartAdd(ts);
        }

        public void SetTime(int hour, int minute, int second, int microsecond)
        {
            TimeSpan ts = new TimeSpan(0,hour, minute, second, microsecond);
            StartNowMines(ts);
        }

        




        bool changePoint;

        public bool ChangePoint
        {
            get => changePoint; set => changePoint = value;
        }

        public void StartMines()
        {
            TimeSpan span = TimeSpan;
            StartNowMines(span);
        }

        public void StartNowMines(TimeSpan span)
        {
            
            Clear();
            StartMines(span);
        }

        public void StartNowMines(SecondDelta timeSpan) 
        {
            StartNowMines(timeSpan.TimeSpan);
            ChangePoint = timeSpan.ChangePoint;
            OutputIndex = timeSpan.OutputIndex;
            TimerOutput[] thisOutputs = GetTimeOutput();
            TimerOutput[] viewOutputs  = timeSpan.GetTimeOutput();
            int thisLength = thisOutputs.Length;
            int viewLength = viewOutputs.Length;
            int length = Math.Min(thisLength, viewLength);
            for (int i = 0; i < length; i++)
            {
                thisOutputs[i].Round = viewOutputs[i].Round;
            }
        }

        public void StartNowMines(List<SecondDelta> secondDeltas, int index)
        {
            StartNowMines(secondDeltas[index]);
        }

        public SecondDelta(SecondDelta timeSpan) : this()
        {
            StartNowMines(timeSpan);
        }

        public SecondDelta Save()
        {
            return new SecondDelta(this);
        }

        public void Save(List<SecondDelta> secondDeltas)
        {
            secondDeltas.Add(Save());
        }

        public void StartAdd(TimeSpan span)
        {
            TimeStart = TimeStart.Add(span);
        }

        public DateTime TimeStart { get { return timeStart; } set { timeStart = value; } }

        DateTime timeEnd;

        public DateTime TimeEnd { get { return timeEnd; } set { timeEnd = value; } }

        public void TimeEndWithNow(DateTime time)
        {
            TimeEnd = time;
            StartMines();
        }

        public TimeSpan TimeSpan
        {
            get => TimeEnd - TimeStart;
            set => TimeEnd = TimeStart + value;
        }

        public TimeSpan TimeOutputWithIsTimer()
        {
            return IsTimer ? TimerDelta() : TimeSpan;
        }

        public int MilisecondsDelta
        {
            get => Math.Max(TimeOutputWithIsTimer().Milliseconds, 0);
        }

        public int SecondsDelta
        {
            get => Math.Max(TimeOutputWithIsTimer().Seconds, 0);
        }

        public double FullSecondsDelta
            => SecondsDelta + MilisecondsDelta / 1000.0;

        public int MinutesDelta
        {
            get => Math.Max(TimeOutputWithIsTimer().Minutes, 0);
        }

        public double FullMinutesDelta
            => MinutesDelta + FullSecondsDelta / 60.0;

        public double MinutesSecondsDelta
            => MinutesDelta * 60.0 + FullSecondsDelta;


        public int HoursDelta
        {
            get =>  Math.Max(TimeOutputWithIsTimer().Hours, 0);
        }

        public bool IsTimerEnd()
        {
            return IsTimer && HoursDelta <= 0 && MinutesDelta <= 0 && SecondsDelta <= 0 && MilisecondsDelta <= 0;
        }

        public double FullHoursDelta
            => HoursDelta + FullMinutesDelta / 60.0;

        public double HoursSecondsDelta
            => HoursDelta * 3600.0 + MinutesSecondsDelta;

        public double HoursSecondsDeltaWithOutMilliseconds
            => HoursDelta * 3600.0 + MinutesDelta * 60 + SecondsDelta;

        public double HoursMinutesDelta
            => HoursDelta * 60.0 + FullMinutesDelta;

        public string VisualTime()
        {
            return $"{HoursDelta.ToString("00")}:{MinutesDelta.ToString("00")}:{FormatOutput(FullSecondsDelta, Math.Min(TimerOutput[0].GetRound(), 3), 2, false)}";
        }

        public static string FormatOutput(double number, int round, int signs, bool mast = true)
        {
            number = Math.Round(number, round);
            string format = "";
            for(int i = 0; i < signs; i++)
            {
                format += "0";
            }
            if(round >0)
            {
                format += ".";
                for(int i = 0; i<round; i++)
                {
                    if (mast)
                        format += "0";
                    else
                        format += "#";
                }
            }
            return number.ToString(format);
        }

        public string VisulSeconds()
        {

            int round = TimerOutput[1].GetRound();
            int milliSeconds = MilisecondsDelta;
            if (round == 0)
            {
                return $"{HoursDelta.ToString("00")}:{MinutesDelta.ToString("00")}:{SecondsDelta.ToString("00")}";
            }
            else if(round == 1)
            {
                milliSeconds /= 100;
                return $"{HoursDelta.ToString("00")}:{MinutesDelta.ToString("00")}:{SecondsDelta.ToString("00")}.{milliSeconds}";
            }
            else if(round == 2)
            {
                milliSeconds /= 10;
                return $"{HoursDelta.ToString("00")}:{MinutesDelta.ToString("00")}:{SecondsDelta.ToString("00")}.{milliSeconds.ToString("00")}";
            }
            else
            return $"{HoursDelta.ToString("00")}:{MinutesDelta.ToString("00")}:{SecondsDelta.ToString("00")}.{MilisecondsDelta.ToString("000")}";
        }

        public string VisualSecondTime()
        {
            return $"{HoursDelta.ToString("00")}:{MinutesDelta.ToString("00")}:{SecondsDelta.ToString("00")}";
        }

        public string VisualMinutesTime()
        {
            return $"{HoursDelta.ToString("00")}:{FormatOutput(FullMinutesDelta, TimerOutput[9].GetRound(), 2, false)}";
        }

        public string VisualMinutesTimeVisoutSeconds()
        {
            return $"{HoursDelta.ToString("00")}:{MinutesDelta.ToString("00")}";
        }

        public string VisualHours()
        {
            int round = TimerOutput[7].GetRound();
            return $"{FormatOutput(Math.Round(FullHoursDelta, round),round, 1, false)}";
        }

        public string VisualDatas()
        {
            ChangeTime();
            string text = "";

            
            text += $"Полное время: {VisualTime()} \n";
            text += $"Упрощённое время: {VisulSeconds()} \n";
            text += $"Без милисекунд: {VisualSecondTime()} \n";
            text += $"Через минуты (Часы и минуты): {VisualMinutesTime()} \n";
            text += $"Без секунд {VisualMinutesTimeVisoutSeconds()} \n";
            text += $"Часы: {VisualHours()} \n";
            text += $"Без милисекунд: {VisualHourSecond()} \n";
            text += $"Минуты: {VisualHoursMinutesDelta()} \n";
            text += $"Без милисекунд {VisualMinutesWithOutMilliseconds()} \n";
            text += $"Секунды: {VisualHoursSecondsDelta()} \n";
            text += $"Без милисекунд: {HoursSecondsDeltaWithOutMilliseconds} \n";
            text += $"Плюс часы: {MinutesAllSecondsFull()} \n";
            text += $"Без милисекунд: {MinutesAllSeconds()} \n";
            text += $"Милисекунды: {MilliSecondsAll} \n";
            text += $"Всё: {TimeAll()} \n";

            return text;
        }

        public double MinutesWithOutMilliseconds
        {
            get
            {
                return HoursDelta * 60 + MinutesDelta + SecondsDelta / 60.0;
            }
        }

        public string VisualMinutesWithOutMilliseconds()
        {
            int round = TimerOutput[5].GetRound();
            return FormatOutput(Math.Round(MinutesWithOutMilliseconds, round), round, 1, false); 
        }

        public string VisualHoursMinutesDelta()
        {
            int round = TimerOutput[6].GetRound();
            return FormatOutput(Math.Round(HoursMinutesDelta, round), round, 1, false);
        }

        public string VisualHoursSecondsDelta()
        {
            int round = TimerOutput[4].GetRound();
            return FormatOutput(Math.Round(HoursSecondsDelta, round), round, 1, false);
        }

        public double HourSecond
        {
            get => HoursDelta + (MinutesDelta + SecondsDelta / 60.0) / 60;
        }

        public string VisualHourSecond()
        {
            int round = TimerOutput[10].GetRound();
            return FormatOutput(Math.Round(HourSecond, round), round, 1, false);
        }

        public void Add(int hour, int minute, int second, int milliSeconds) 
        {
            Add(new TimeSpan(0,hour, minute, second, milliSeconds));
        }

        public void Mines(int hour, int minute, int second, int milliSeconds)
        {
            Add(-hour, -minute, -second, -milliSeconds);
        }

        public void Add(decimal hour, decimal minute, decimal second, decimal milliSeconds)
        {
            Add((int)hour, (int)minute, (int)second, (int)milliSeconds);
        }

        public void AddWithNow(decimal hour, decimal minute, decimal second, decimal milliSeconds)
        {
            Add(hour, minute, second, milliSeconds);
            StartMines();
        }

        public void Mines(decimal hour, decimal minute, decimal second, decimal milliSeconds)
        {
            Mines((int)hour, (int)minute, (int)second, (int)milliSeconds);
        }

        public void MinesWithNow(decimal hour, decimal minute, decimal second, decimal milliSeconds)
        {
            Mines(hour, minute, second, milliSeconds);
            StartMines();
        }

        public void Add(TimeSpan time)
        {
            DateTime time1 = TimeEnd;
            time1 = time1.Add(time);
            TimeEnd = time1;
        }


        public string VisulDatasNewLine() => VisualDatas().Replace("\n", Environment.NewLine);

        public override string ToString() => Output();

        public void DateEndNow() => TimeEnd = DateTime.Now;
        public void DateStartNow() => TimeStart = DateTime.Now;

        public void Clear()
        {
            DateTime time = DateTime.Now;
            timeStart = time;
            timeEnd = time;
        }

        public SecondDelta()
        {
            ChangePoint = true;
            Clear();
            TimerTime = TimeSpan.Zero;
            timeOutput = new TimerOutput[15];
            IsTimer = false;
            timeOutput[0] = new TimerOutput(TimeOutput.Full, "Полное", 3);
            timeOutput[1] = new TimerOutput(TimeOutput.FullWithMillisecond, "Упрощённое", 3);
            timeOutput[2] = new TimerOutput(TimeOutput.FullWithoutMillisecond, "Без милисекунд");
            timeOutput[3] = new TimerOutput(TimeOutput.Second, "Секунды без милисекунд");
            timeOutput[4] = new TimerOutput(TimeOutput.SecondMillisecond, "Секунды", 3);
            timeOutput[5] = new TimerOutput(TimeOutput.Minute, "Минуты без милисекунд", 4);
            timeOutput[6] = new TimerOutput(TimeOutput.MinuteSecond, "Минуты", 4);
            timeOutput[7] = new TimerOutput(TimeOutput.Hour, "Часы", 4);
            timeOutput[8] = new TimerOutput(TimeOutput.FullWithoutSecond, "Полное без секунд (Часы и минуты)");
            timeOutput[9] = new TimerOutput(TimeOutput.HourMinute, "Часы и минуты", 4);
            timeOutput[10] = new TimerOutput(TimeOutput.HourSecond, "Часы без милисекунд", 4);
            timeOutput[11] = new TimerOutput(TimeOutput.MilliSeconds, "Милисекунды");
            timeOutput[12] = new TimerOutput(TimeOutput.HourAdd, "Плюс часы", 3);
            timeOutput[13] = new TimerOutput(TimeOutput.HourAddWithOutMillisecond, "Плюс часы, без милисекунд");
            timeOutput[14] = new TimerOutput(TimeOutput.All, "Весь");

        }

        private TimeSpan timerTime;

        public TimerOutput[ ] GetTimeOutput()
        {
            return timeOutput;
        }

        public int GetRound(int outputIndex) => timeOutput[outputIndex].GetRound();

        public int GetRound() => GetRound(OutputIndex);

        public void SetRound(int outputIndex, int round) => timeOutput[outputIndex].SetRound(round);

        public void SetRound(int outputIndex, decimal round) => SetRound(outputIndex, (int)round);
        public void SetRound(decimal round) => SetRound(OutputIndex, (int)round);

        public object[] Outputs
        {
            get
            {
                List<object> outputs = new List<object>();
                for(int i = 0; i < timeOutput.Length; i++)
                {
                    outputs.Add(timeOutput[i]);
                }
                return outputs.ToArray();
            }
        }

        public SecondDelta(DateTime timeEnd):this()
        {
            TimeEnd = timeEnd;
        }

        public SecondDelta(DateTime timeStart, DateTime timeEnd):this(timeEnd)
        {
            TimeStart= timeStart;
        }

        public SecondDelta(DateTime timeStart, TimeSpan timeSpan):this()
        {
            TimeStart = timeStart;
            TimeSpan = timeSpan;
        }


        public void ChangeTime()
        {
            if(TimeEnd < TimeStart)
            {
                DateTime time = TimeStart;
                timeStart = timeEnd;
                timeEnd = time;
            }
        }

        TimerOutput[] timeOutput;

        public TimerOutput[] TimerOutput => timeOutput;
            

        public string Output(TimeOutput timeOutput)
        {
            string text = "";

            switch(timeOutput)
            {
                case TimeOutput.Full:
                    text = VisualTime(); break;
                case TimeOutput.FullWithMillisecond:
                    text = VisulSeconds(); break;
                case TimeOutput.FullWithoutMillisecond:
                    text = VisualSecondTime(); break;
                case TimeOutput.Second:
                    text = HoursSecondsDeltaWithOutMilliseconds.ToString(); break;
                case TimeOutput.SecondMillisecond:
                    text = VisualHoursSecondsDelta().ToString(); break;
                case TimeOutput.Minute:
                    text = VisualMinutesWithOutMilliseconds().ToString(); break;
                case TimeOutput.MinuteSecond:
                    text = VisualHoursMinutesDelta().ToString(); break;
                case TimeOutput.Hour:
                    text = VisualHours().ToString(); break;
                case TimeOutput.FullWithoutSecond:
                    text = VisualMinutesTimeVisoutSeconds();
                    break;
                case TimeOutput.HourMinute:
                    text = VisualMinutesTime();
                    break;
                case TimeOutput.HourSecond:
                    text = VisualHourSecond().ToString();
                    break;
                case TimeOutput.All:
                    text = TimeAll(); break;
                case TimeOutput.MilliSeconds:
                    text = MilliSecondsAll.ToString();
                    break;
                case TimeOutput.HourAddWithOutMillisecond:
                    text = MinutesAllSeconds();
                    break;
                case TimeOutput.HourAdd:
                    text = MinutesAllSecondsFull();
                    break;
                default: text = ""; break;

            }

            return text;
        }

        public string TimeAll()
        {
            return HoursDelta.ToString("00") + ":" + MinutesDelta.ToString("00") + ":" + SecondsDelta.ToString("00") + "." + MilisecondsDelta.ToString("000");
        }

        public string Output(int index) => Output(TimerOutput[index].GetOutputView());

        int outputIndex;

        public int OutputIndex
        {
            get => outputIndex;
            set => outputIndex = value;
        }

        public TimerOutput OutputFormat()
        {
            return TimerOutput[outputIndex];
        }

        public string OutputName()
        {
            return OutputFormat().MessageOutputView;
        }

        public string Output()
        {
            return Output(OutputIndex);
        }

        public long MilliSecondsAll => ((long)MilisecondsDelta) + SecondsDelta * 1000 + MinutesDelta * 60 * 1000 + HoursDelta * 3600 * 1000;

        public int MinutesAll => HoursDelta * 60 + MinutesDelta;

        /// <summary>
        /// true - таймер; false - секундомер
        /// </summary>
        public bool IsTimer { get => IsTimer1; set => IsTimer1 = value; }

        /// <summary>
        /// true - таймер; false - секундомер
        /// </summary>
        public bool IsTimer1 { get => IsTimer2; set => IsTimer2 = value; }

        /// <summary>
        /// true - таймер; false - секундомер
        /// </summary>
        public bool IsTimer2 { get => isTimer; set => isTimer = value; }

        /// <summary>
        /// Время, на которое заведён таймер
        /// </summary>
        public TimeSpan TimerTime { get => timerTime; set => timerTime = value; }

        /// <summary>
        /// Оставшееся время на таймере
        /// </summary>
        /// <returns></returns>
        public TimeSpan TimerDelta()
        {
            return TimerTime - TimeSpan;
        }

        public string MinutesAllSeconds()
        {
            return MinutesAll.ToString("00") + ":" + SecondsDelta.ToString("00");
        }

        public string MinutesAllSecondsFull()
        {
            
            string format = "";
            int round = TimerOutput[12].Round;
            if (round < 1)
                return MinutesAllSeconds();
            round = Math.Min(round, 3);
            for(int i =0; i < round; i++)
            {
                format += "0";
            }
            round = 3 - round;
            int milliSeconds = MilisecondsDelta;
            for (int i = 0; i < round; i++)
            {
                milliSeconds /= 10;
            }
            return MinutesAllSeconds() + "." + milliSeconds.ToString(format);
        }

    }

    
    public enum Save
    {
        None,
        Excel,
        TCP
    }
}
