﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace TableAIS
{
    public class ParamsPermissions : SecurityPozitions
    {
        public ParamsPermissions() : base()
        {
        }

        public ParamsPermissions(bool all, string name) : this()
        {
            All = all;
            Name = name;
        }

        public ParamsPermissions(int capacity) : base(capacity)
        {
        }

        public ParamsPermissions(IEnumerable<SecurityItem> collection) : base(collection)
        {
        }

        public override void SetList()
        {
            base.SetList();
            Add(0, "Запретить");
            Add(1, "Разрешить до окончания сеанса работы приложения");
            Add(2, "Всегда разрешать");

            All = false;
            Name = "";
        }

        public bool Allowed => SelectionIndex > 0;

        public bool All
        {
            get => SelectionIndex == 2;
            set
            {
                if (value)
                {
                    SelectionIndex = 2;
                }
            }
        }

        public ParamsPermissions(bool all) : this(all, "")
        {
            
        }

        public bool GetAll()
        {
            return SelectionIndex == 2;
        }

        public void SetAll(bool value)
        {
            if (value)
            {
                SelectionIndex = 2;
            }
        }

        string name;

        public string GetName()
        {
            return name;
        }

        public void SetName(string value)
        {
            name = value;
        }


        public string Name
        {
            get => name; set => name = value;
        }


        public ParamsPermissions(string name) : this(false, name) 
        {
            
        }

        public void SetByJson(JsonObject jsonObject)
        {
            All = ((bool)jsonObject["All"].AsValue());
            Name = ((string)jsonObject["Name"].AsValue());
        }

        

        public JsonObject ToJson()
        {
            JsonObject jsonObject = new JsonObject
            {
                { "name", Name },
                { "All", All }
            };

            return jsonObject;
        }
    }
}
