﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public static class SecurityHelper
    {
        public static ParamsPermissions EnternetPermissions,
            TcpPermissions,
            UdpPermissins,
            TcpSender,
            TcpRecipient,
            UdpSender,
            UdpRecipient;



        public static void SetPermissions()
        {
            SecurityPermissions security = SecurityPermissions.Default;
            EnternetPermissions = new ParamsPermissions(security.EnternetPermissions, "Сетевой обмен");
            TcpPermissions = new ParamsPermissions(security.TcpPermissions, "Обмен по протоколу TCP");
            UdpPermissins = new ParamsPermissions(security.UdpPermissions, "Обмен по протоколу UDP");
            TcpSender = new ParamsPermissions(security.TcpSender, "Отправка по протоколу TCP");
            TcpRecipient = new ParamsPermissions(security.TcpRecipient, "Получение по протоколу TCP");
            UdpSender = new ParamsPermissions(security.UdpSender, "Отправка по протоколу UDP");
            UdpRecipient = new ParamsPermissions(security.UdpRecipient, "Получение по протоколу UDP");
        }

        public static void SavePermissions()
        {
            SecurityPermissions security = SecurityPermissions.Default;
            security.EnternetPermissions = EnternetPermissions.All;
            security.TcpPermissions = TcpPermissions.All;
            security.UdpPermissions = UdpPermissins.All;
            security.TcpSender = TcpSender.All;
            security.UdpSender = UdpSender.All;
            security.UdpRecipient = UdpRecipient.All;
            security.TcpRecipient = TcpRecipient.All;
            security.Save();

        }

        public static bool EnternetAllowed => EnternetPermissions.Allowed;

        public static bool TcpAllowed => TcpPermissions.Allowed && EnternetAllowed;
        public static bool UdpAllowed => UdpPermissins.Allowed && EnternetAllowed;

        public static bool TcpSendAllowed => TcpAllowed && TcpSender.Allowed;
        public static bool TcpReciveAllowed => TcpAllowed && TcpRecipient.Allowed;

        public static bool UdpSendAllowed => UdpAllowed && UdpSender.Allowed;
        public static bool UdpReciveAllowed => UdpAllowed && UdpRecipient.Allowed;

    }
}
