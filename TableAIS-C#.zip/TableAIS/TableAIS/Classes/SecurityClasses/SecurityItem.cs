﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class SecurityItem
    {
        public SecurityItem() : this(0, "")
        {
        }

        public SecurityItem(int id, string description)
        {
            SetID(id);
            SetDescription(description);
        }

        public SecurityItem(string description) : this(0, description)
        {
        }

        public SecurityItem(int id):this(id, "")
        {

        }

        int id;
        string description;

        public int GetID()
        {
            return id;
        }

        public void SetID(int value)
        {
            id = value;
        }

        public string GetDescription()
        {
            return description;
        }

        public void SetDescription(string value)
        {
            description = value;
        }

        public int ID
        {
            get => GetID(); set => SetID(value);
        }


        public string Description
        {
            get => GetDescription(); set => SetDescription(value);
        }

        public override string ToString()
        {
            return Description;
        }

    }
}
