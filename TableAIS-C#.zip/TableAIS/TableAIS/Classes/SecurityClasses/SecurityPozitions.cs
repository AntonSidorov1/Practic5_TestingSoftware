﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class SecurityPozitions : List<SecurityItem>
    {
        public SecurityPozitions() : base()
        {
            SetList();
        }

        public SecurityPozitions(int capacity) : base(capacity)
        {
            SetList();
        }

        public SecurityPozitions(IEnumerable<SecurityItem> collection) : base(collection)
        {
            SetList();
        }

        public virtual void SetList()
        {

        }

        public SecurityItem Add(int id, string description)
        {
            SecurityItem item = new SecurityItem(id, description);
            Add(item);
            return item;
        }

        public SecurityItem Add()
        {
            SecurityItem item = new SecurityItem();
            Add(item);
            return item;
        }

        int selectionIndex;

        public int GetSelectionIndex()
        {
            return selectionIndex;
        }

        public void SetSelectionIndex(int value)
        {
            selectionIndex = value;
        }


        public int SelectionIndex
        {
            get => selectionIndex; set => selectionIndex = value;
        }

        public SecurityItem GetByID(int id)
        {
            return Find(s => s.ID == id);
        }

        public SecurityItem GetBySelectionIndex()
        {
            return GetByID(SelectionIndex);
        }



    }
}
