﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class SpeedConvertes : ThirdConverter
    {
        public SpeedConvertes() : base()
        {

            UpMetrs = new LengthConverter();
            DownMetrs = new TimeConverter();

            MetrsConvert first = FirstOperation;
            first.Name = "м/с";

            double speedLum = 299796138.625734500539633;
            MetrsConvert convert = Add("Скорости света (точно)");
            convert.ConvertFrom = (value) => value*speedLum;
            convert.ConvertTo = (value) => value/speedLum;

            double speedLum1 = 300000000;
            convert = Add("Скорости света (Упрощённо)");
            convert.ConvertFrom = (value) => value * speedLum1;
            convert.ConvertTo = (value) => value / speedLum1;

            double mah = 340.298101136595658;
            convert = Add("Числа Маха");
            convert.ConvertFrom = (value) => value * mah;
            convert.ConvertTo = (value) => value / mah;

            double mah1 = 330;
            convert = Add("Числа Маха (приближённо)");
            convert.ConvertFrom = (value) => value * mah1;
            convert.ConvertTo = (value) => value / mah1;

            double uzel = 0.514444444444444444444444444444;
            convert = Add("Узлы");
            convert.ConvertFrom = (value) => value * uzel;
            convert.ConvertTo = (value) => value / uzel;

            double uzel1 = 0.514;
            convert = Add("Узлы (приближённо)");
            convert.ConvertFrom = (value) => value * uzel1;
            convert.ConvertTo = (value) => value / uzel1;

        }
    }
}
