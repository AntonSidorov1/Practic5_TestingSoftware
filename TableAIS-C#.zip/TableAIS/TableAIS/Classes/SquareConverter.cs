﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class SquareConverter : LengthBigConverter
    {
        public SquareConverter() : base(2)
        {
            NameFirst = "Квадратные метры";

            MetrsConvert convert = Add("Ары");
            convert.ConvertTo = (value) => value / 100;
            convert.ConvertFrom = (value) => value * 100;

            convert = Add("Сотки");
            convert.ConvertTo = (value) => value / 100;
            convert.ConvertFrom = (value) => value * 100;

            convert = Add("Гектары");
            convert.ConvertTo = (value) => value / 10000;
            convert.ConvertFrom = (value) => value * 10000;

            convert = Add("Акры");
            double akr = 4046.944556859571024;
            convert.ConvertTo = (value) => value / akr;
            convert.ConvertFrom = (value) => value * akr;

            convert = Add("Квадратные роды");
            double rod = Rod;
            convert.ConvertTo = (value) => value / rod;
            convert.ConvertFrom = (value) => value * rod;

        }

        public const double Rod = 25.292827712845468;
        public static double LengthRod => Math.Sqrt(Rod);

        public static double Link => LengthRod / 25;
    }
}
