﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{

    public class ThirdConverter : AbstractBigConverter
    {
        public ThirdConverter() : base()
        {
            

            UpMetrs = new ConverterList();
            DownMetrs = new ConverterList();

        }

        ConverterList upMetrs, downMetrs;

        public ConverterList UpMetrs
        {
            get => upMetrs;
            set => upMetrs = value;
        }

        public int FromUp
        {
            get => UpMetrs.FromIndex;
            set => UpMetrs.FromIndex = value;
        }

        public int FromDown
        {
            get => DownMetrs.ToIndex;
            set => DownMetrs.ToIndex = value;
        }

        public int ToUp
        {
            get => UpMetrs.ToIndex;
            set => UpMetrs.ToIndex = value;
        }

        public int ToDown
        {
            get => DownMetrs.FromIndex;
            set => DownMetrs.FromIndex = value;
        }

        public ConverterList DownMetrs
        {
            get => downMetrs;
            set => downMetrs = value;
        }

        public MetrsConvert[] DownArray => DownMetrs.MetrsConvertsArray;
        public MetrsConvert[] UpArray => UpMetrs.MetrsConvertsArray;

        public double UpFrom(double value) => UpMetrs.FromDo(value);
        public double UpTo(double value) => UpMetrs.ToDo(value);

        public double DownFrom(double value) => DownMetrs.ToDo(value);
        public double DownTo(double value) => DownMetrs.FromDo(value);

        public double UpToDownFrom(double value) => DownFrom(UpFrom(value));
        public double UpToDownTo(double value) => DownTo(UpTo(value));

        public override double VariantFrom(double value)
        {
            return UpToDownFrom(value);
        }

        public override double VariantTo(double value)
        {
            return UpToDownTo(value); 
        }
    }
}
