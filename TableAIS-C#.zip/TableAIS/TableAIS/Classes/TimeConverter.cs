﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class TimeConverter : ConverterList
    {
        public TimeConverter() : base()
        {
            MetrsConvert metrs = Add("Секунды");
            metrs.ConvertFrom = (value) => value;
            metrs.ConvertTo = (value) => value;

            metrs = Add("Миллисекунды");
            metrs.ConvertFrom = (value) => value/1000;
            metrs.ConvertTo = (value) => value*1000;

            metrs = Add("Сантисекунды");
            metrs.ConvertFrom = (value) => value / 100;
            metrs.ConvertTo = (value) => value * 100;

            metrs = Add("Децесекунды");
            metrs.ConvertFrom = (value) => value / 10;
            metrs.ConvertTo = (value) => value * 10;

            metrs = Add("Минуты");
            metrs.ConvertFrom = (value) => value * 60;
            metrs.ConvertTo = (value) => value / 60;

            metrs = Add("Часы");
            metrs.ConvertFrom = (value) => FromDo("Минуты", value * 60);
            metrs.ConvertTo = (value) => ToDo("Минуты", value / 60);

            metrs = Add("Дни");
            metrs.ConvertFrom = (value) => FromDo("Часы", value * 12);
            metrs.ConvertTo = (value) => ToDo("Часы", value / 12);

            metrs = Add("Недели");
            metrs.ConvertFrom = (value)=> FromDo("Дни", value * 7);
            metrs.ConvertTo = (value) => ToDo("Дни", value / 7);

            metrs = Add("Года");
            metrs.ConvertFrom = (value) => FromDo("Дни", value * 365);
            metrs.ConvertTo = (value) => ToDo("Дни", value / 365);
            MetrsConvert years = metrs;

            metrs = Add("Века");
            metrs.ConvertFrom = (value)=> years.From(value * 100);
            metrs.ConvertTo = (value) => years.To(value / 100);

            metrs = Add("Декасекунды");
            metrs.ConvertFrom = (value) => value * 10;
            metrs.ConvertTo = (value) => value / 10;

            metrs = Add("Гектасекунды");
            metrs.ConvertFrom = (value) => value * 100;
            metrs.ConvertTo = (value) => value / 100;

            metrs = Add("Килосекунды");
            metrs.ConvertFrom = (value) => value * 1000;
            metrs.ConvertTo = (value) => value / 1000;

            metrs = Add("Микросекунды");
            metrs.ConvertFrom = (value) => value / Math.Pow(10, 6);
            metrs.ConvertTo = (value) => value * Math.Pow(10, 6);

            metrs = Add("Мегасекунды");
            metrs.ConvertFrom = (value) => value * Math.Pow(10, 6);
            metrs.ConvertTo = (value) => value / Math.Pow(10, 6);

            metrs = Add("Наносекунды");
            metrs.ConvertFrom = (value) => value / Math.Pow(10, 9);
            metrs.ConvertTo = (value) => value * Math.Pow(10, 9);

            metrs = Add("Гигасекунды");
            metrs.ConvertFrom = (value) => value * Math.Pow(10, 9);
            metrs.ConvertTo = (value) => value / Math.Pow(10, 9);

            metrs = Add("Пикосекунды");
            metrs.ConvertFrom = (value) => value / Math.Pow(10, 12);
            metrs.ConvertTo = (value) => value * Math.Pow(10, 12);

            metrs = Add("Терасекунды");
            metrs.ConvertFrom = (value) => value * Math.Pow(10, 12);
            metrs.ConvertTo = (value) => value / Math.Pow(10, 12);


        }
    }
}
