﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS.Classes
{

    public enum TimeOutput
    {
        Full,
        FullWithMillisecond,
        FullWithoutMillisecond,
        FullWithoutSecond,
        Second,
        Minute,
        Hour,
        SecondMillisecond,
        MinuteSecond,
        HourMinute,
        HourSecond,
        All,
        MilliSeconds,
        HourAdd,
        HourAddWithOutMillisecond
    }


    public class TimerOutput
    {
        private TimeOutput outputView;

        public TimeOutput OutputView
        {
            get => GetOutputView();
            set => SetOutputView(value);
        }

        public TimeOutput GetOutputView()
        {
            return outputView;
        }

        public void SetOutputView(TimeOutput value)
        {
            outputView = value;
        }

        private string messageOutputView;

        public string GetMessageOutputView()
        {
            return messageOutputView;
        }

        public string MessageOutputView
        {
            get => GetMessageOutputView();
            set => SetMessageOutputView(value);
        }

        public void SetMessageOutputView(string value)
        {
            messageOutputView = value;
        }

        private int round;

        public int Round
        {
            get => GetRound();
            set => SetRound(value);
        }

        public int GetRound()
        {
            return round;
        }

        public void SetRound(int value)
        {
            round = value;
        }

        public override string ToString() => GetMessageOutputView();

        public TimerOutput()
        {
            SetOutputView(TimeOutput.Full);
            SetMessageOutputView("");
            SetRound(0);
        }

        public TimerOutput(TimeOutput timer, string message, int round = 0) : this()
        {
            SetOutputView(timer);
            SetMessageOutputView(message);
            SetRound(round);
        }

        public TimerOutput(TimerOutput timeOutput) : this(timeOutput.GetOutputView(), timeOutput.GetMessageOutputView(), timeOutput.GetRound())
        {

        }

    }

}
