﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS.Classes
{
    internal class TimerOutputSettings : TimerOutput, ITimerOutput
    {
        public TimerOutputSettings()
        {
        }

        public TimerOutputSettings(TimerOutput timeOutput) : base(timeOutput)
        {
        }

        public TimerOutputSettings(TimeOutput timer, string message, int round = 0) : base(timer, message, round)
        {
        }

        public void Update()
        {
            
        }
    }
}
