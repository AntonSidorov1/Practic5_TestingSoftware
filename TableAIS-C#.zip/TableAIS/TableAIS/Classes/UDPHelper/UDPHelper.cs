﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace TableAIS
{
    public static  class UDPHelper
    {
        static int udpPortClient, udpPortServer;
        public static int UdpPortClient
        {
            get => udpPortClient;
            set => udpPortClient = value;
        }

        public static int UdpPortServer
        {
            get => udpPortServer;
            set => udpPortServer = value;
        }

        static Thread udpThread;
        static UdpClient udpClient, udpServer;

        public static UdpClient ThisServer => UdpServer;

        public static UdpClient UdpClient
        {
            get => udpClient;
            set => udpClient = value;
        }

        public static UdpClient sender
        {
            get => UdpClient;
            set => UdpClient = value;
        }

        public static UdpClient UdpServer
        {
            get => udpServer;
            set => udpServer = value;
        }

        public static Thread UdpThread
        {
            get => udpThread;
            set => udpThread = value;
        }

        public static Thread ServerThread
        {
            get => UdpThread;
            set => UdpThread = value;
        }
        

        public static void Send(string datagram, string remoteIPAddress, int clientPort)
        {
            if(!ClientStarting || !SecurityHelper.UdpSendAllowed)
            {
                throw new Exception();
            }
            Thread send = new Thread(() => SendInThread(datagram, remoteIPAddress, clientPort));
            send.Start();
        }

        private static void SendInThread(string datagram, string remoteIPAddress, int clientPort)
        {
            try
            {
                sender.Close();
            }
            catch { }

            try
            {
                // Создаем UdpClient
                sender = new UdpClient(UdpPortClient);
            }
            catch
            {
                sender = new UdpClient();
            }

            // Создаем endPoint по информации об удаленном хосте
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(remoteIPAddress), clientPort);

            try
            {
                // Преобразуем данные в массив байтов
                byte[] bytes = Encoding.UTF8.GetBytes(datagram);

                // Отправляем данные
                sender.Send(bytes, bytes.Length, endPoint);
                mainForm.BeginInvoke(new Action(() =>
                {
                    try
                    {
                        GetMessage("Успешно");
                    }
                    catch { }
                }));
            }
            catch (Exception ex)
            {
                try
                {
                    mainForm.BeginInvoke(new Action(() =>
                    {
                        try
                        {
                            GetMessage("Ошибка!!!");
                        }
                        catch { }
                    }));
                }
                catch { }
            }
            finally
            {
                // Закрыть соединение
                sender.Close();
            }
        }

        public static Action<string> GetMessage;
        public static MainForm mainForm => TcpHelper.mainForm;

        public static bool ServerStarting, ClientStarting;

        public static void ServerStop()
        {
            try
            {
                ServerStarting = false;
                try
                {
                    ServerThread.Abort();
                }
                catch { }
                try
                {
                    ServerThread.Interrupt();
                }
                catch { }
                try
                {
                    ThisServer.Close();
                }
                catch
                {

                }
            }
            catch { }
        }

        public static void ServerStart()
        {
            ServerStarting = true;
            ServerThread = new Thread(ServerWork);
            ServerThread.Start();
        }

        public static void ServerWork()
        {
            try
            {
                IPEndPoint endPoint = null;
                UdpServer = new UdpClient(UdpPortServer);
                UdpClient server = UdpServer;
                while (ServerStarting)
                {
                    byte[] bytes = server.Receive(ref endPoint);
                    string data = Encoding.UTF8.GetString(bytes);
                    if (!SecurityHelper.UdpReciveAllowed)
                        continue;
                    try
                    {
                        mainForm.BeginInvoke(new Action(() =>
                        {
                            try
                            {
                                FilesList files = MainForm.Files;
                                bool haveValue = true;
                                string name = "";
                                if (!files.SetValueOfJsonNet(data, out haveValue, out name))
                                {
                                    try
                                    {
                                        if (haveValue)
                                            files.NotificationView(name, $"Была предотвращена попытка безуспешной передачи текста значению \"{name}\" с другого устройства по протоколу UDP \n" +
                                                $"Текст сохранён в сетевой буфер данного значения, откуда вы его можете присвоить значению \n" +
                                                $"Просмотреть изменения значения...");
                                        else
                                            throw new Exception();
                                    }
                                    catch(Exception e )
                                    {
                                        throw e;
                                    }
                                }
                            }
                            catch
                            {
                                Buffer.Text = data;
                            }
                        }));
                    }
                    catch { }

                }
            }
            catch
            {

            }
            finally 
            { 
                ServerStop();
            }
        }
    }
}
