﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    /// <summary>
    /// Соотношение углов
    /// </summary>
    public enum UgolNumber
    {
        /// <summary>
        /// Введённый
        /// </summary>
        Now,
        /// <summary>
        /// Половинный
        /// </summary>
        Half,
        /// <summary>
        /// Двойной
        /// </summary>
        Dual
    }

    /// <summary>
    /// Соотношение угла и окружности
    /// </summary>
    public enum CircleUgol
    {
        /// <summary>
        /// Центральный
        /// </summary>
        Central,
        /// <summary>
        /// Боковой угол треугольника из радиуса и хорды
        /// </summary>
        SideCentral,
        /// <summary>
        /// Угол, смежный углу между радиусом и касательной
        /// </summary>
        AdjacentSideCentral,
        /// <summary>
        /// Смежный (180-a)
        /// </summary>
        Adjacent,
        /// <summary>
        /// Больший угол в окружности (360-a)
        /// </summary>
        Big,
        /// <summary>
        /// Вписанный угол
        /// </summary>
        Inscribed,
        /// <summary>
        /// Описанный угол
        /// </summary>
        Described,
        /// <summary>
        /// Боковой угол треугольника с описанным углом
        /// </summary>
        SideDescribed,
        /// <summary>
        /// По сумме 90
        /// </summary>
        Ugol90,
        /// <summary>
        /// Половинный угол
        /// </summary>
        Half,
        /// <summary>
        /// Двойной угол
        /// </summary>
        Dual,
        /// <summary>
        /// Угол, смежный вписанному
        /// </summary>
        AdjacentInscribed
    }

    public class CircleUgolClass
    {
        public CircleUgol CircleUgol;
        public string Name;
        public override string ToString()
        {
            return Name;
        }

        public CircleUgolClass(string name, CircleUgol c)
        {
            CircleUgol = c;
            Name = name;
        }

        public CircleUgolClass(CircleUgol c) : this("", c)
        {

        }

        public CircleUgolClass(string name) : this(name, CircleUgol.Central)
        {

        }

        public CircleUgolClass() : this("Центральный угол")
        {

        }

    }

    public class CircleUgolsList : LastList<CircleUgolClass>
    {
        public CircleUgolsList() : base()
        {
        }

        public CircleUgolClass Add(string name, CircleUgol circleUgol)
        {
            CircleUgolClass ugolClass = new CircleUgolClass(name, circleUgol);
            Add(ugolClass);
            return ugolClass;
        }

        public CircleUgolClass Add(string name)
        {
            CircleUgolClass ugolClass = new CircleUgolClass(name);
            Add(ugolClass);
            return ugolClass;
        }

        public CircleUgolClass Add(CircleUgol circleUgol)
        {
            CircleUgolClass ugolClass = new CircleUgolClass( circleUgol);
            Add(ugolClass);
            return ugolClass;
        }

        public CircleUgolClass Add()
        {
            CircleUgolClass ugolClass = new CircleUgolClass();
            Add(ugolClass);
            return ugolClass;
        }

        public CircleUgol GetCircleUgolByIndex() => GetByIndex().CircleUgol;
    }


    public class CircleUgolsListNormal : CircleUgolsList
    {
        public CircleUgolsListNormal()
        {
            Add();
            Add("Угол между радиусом и хордой", CircleUgol.SideCentral);
            Add("Вписанный угол", CircleUgol.Inscribed);
            Add("Описанный угол", CircleUgol.Described);
            Add("Угол между радиусом и касательной", CircleUgol.SideDescribed);
            Add("Угол, смежный углу между радиусом и касательной", CircleUgol.AdjacentSideCentral);
            Add("Двойной угол", CircleUgol.Dual);
            Add("Половинный угол", CircleUgol.Half);
            Add("Смежный угол (180-x)", CircleUgol.Adjacent);
            Add("Угол смежный вписанному", CircleUgol.AdjacentInscribed);
            Add("Больший/меньший угол (360-x)", CircleUgol.Big);
            Add("По сумме прямой (90-x)", CircleUgol.Ugol90);
        }
    }

    public class CircleUgolsListNormalTransfer : CircleUgolsListNormal
    {
        public CircleUgolsListNormalTransfer() : base()
        {
            IndexFrom1 = 0;
            IndexFrom2 = 0;
            IndexFrom3 = 0;
            IndexTo1 = 0;
            IndexTo2 = 0;
            IndexTo3 = 0;
        }

        public int IndexFrom1, IndexFrom2, IndexFrom3;
        public int IndexTo1, IndexTo2, IndexTo3;

        public CircleUgol GetFromByIndex1() => Get(IndexFrom1).CircleUgol;
        public CircleUgol GetFromByIndex2() => Get(IndexFrom2).CircleUgol;
        public CircleUgol GetFromByIndex3() => Get(IndexFrom3).CircleUgol;

        public CircleUgol GetToByIndex1() => Get(IndexTo1).CircleUgol;
        public CircleUgol GetToByIndex2() => Get(IndexTo2).CircleUgol;
        public CircleUgol GetToByIndex3() => Get(IndexTo3).CircleUgol;
    }


    /// <summary>
    /// Ковертер единиц измерения угла
    /// </summary>
    public class UgolsConverter : ConverterList
    {
        public double ConvertUgol(double value, CircleUgol circleUgol)
        {
            if(circleUgol == CircleUgol.SideCentral)
            {
                return ConvertUgol(value, CircleUgol.Adjacent) / 2;
            }
            if(circleUgol == CircleUgol.SideDescribed)
            {
                return 90 - ConvertUgol(value, CircleUgol.SideCentral);
            }

            if (circleUgol == CircleUgol.AdjacentSideCentral)
            {
                return 180 - ConvertUgol(value, CircleUgol.SideCentral);
            }

            if (circleUgol == CircleUgol.Half)
                return value / 2;
            if (circleUgol == CircleUgol.Dual)
                return value * 2;
            if (circleUgol == CircleUgol.Central)
            {
                return value;
            }
            if(circleUgol == CircleUgol.Inscribed)
            {
                return value / 2;
            }
            if(circleUgol == CircleUgol.AdjacentInscribed)
            {
                return 180 - ConvertUgol(value, CircleUgol.Inscribed);
            }
            if(circleUgol == CircleUgol.Adjacent)
            {
                return 180 - value;
            }
            if(circleUgol == CircleUgol.Ugol90)
            {
                return 90 - value;
            }
            if(circleUgol == CircleUgol.Big)
            {
                return 360 - value;
            }
            if(circleUgol == CircleUgol.Described)
            {
                value = 180 - value;
                value /= 2;
                value = 90 - value;
                value *= 2;
                value = 180 - value;
                return value;
            }
            return value;
        }

        public double ConvertUgolRet(double value, CircleUgol circleUgol)
        {
            if (circleUgol == CircleUgol.SideCentral)
            {
                return ConvertUgol(value*2, CircleUgol.Adjacent);
            }
            if (circleUgol == CircleUgol.SideDescribed)
            {
                return ConvertUgolRet(90 - value, CircleUgol.SideCentral);
            }
            if (circleUgol == CircleUgol.Half)
                return value * 2;
            if (circleUgol == CircleUgol.Dual)
                return value / 2;
            if (circleUgol == CircleUgol.Inscribed)
            {
                return value * 2;
            }
            if (circleUgol == CircleUgol.AdjacentInscribed)
            {
                return ConvertUgolRet(180-value, CircleUgol.Inscribed);
            }

            if (circleUgol == CircleUgol.AdjacentSideCentral)
            {
                return ConvertUgolRet(180-value, CircleUgol.SideCentral);
            }

            else
                return ConvertUgol(value, circleUgol);
        }

        public double ConvertUgol(double value, CircleUgol circleUgol1, CircleUgol circleUgol2, CircleUgol circleUgol3)
        {
            return ConvertUgol(ConvertUgol(ConvertUgol(value, circleUgol1), circleUgol2), circleUgol3);
        }

        public double ConvertUgolRet(double value, CircleUgol circleUgol1, CircleUgol circleUgol2, CircleUgol circleUgol3)
        {
            return ConvertUgolRet(ConvertUgolRet(ConvertUgolRet(value, circleUgol1), circleUgol2), circleUgol3);
        }


        UgolNumber ugolNumber;

        /// <summary>
        /// Соотношение угла
        /// </summary>
        public UgolNumber UgolNumber { get { return ugolNumber; } set { ugolNumber = value; } }

        public double UgolDelta()
        {
            return UgolNumber == UgolNumber.Half ? 0.5 : UgolNumber == UgolNumber.Dual ? 2 : 1;
        }

        TimeConverter timeConverter;

        public CircleUgol CircleFrom1 => CircleList.GetFromByIndex1();
        public CircleUgol CircleFrom2 => CircleList.GetFromByIndex2();
        public CircleUgol CircleFrom3 => CircleList.GetFromByIndex3();

        public CircleUgol CircleTo1 => CircleList.GetToByIndex1();
        public CircleUgol CircleTo2 => CircleList.GetToByIndex2();
        public CircleUgol CircleTo3 => CircleList.GetToByIndex3();

        public CircleUgolsListNormalTransfer CircleList;

        public double ConvertUgolFromRet(double value)
        {
            return ConvertUgol(value, CircleFrom1, CircleFrom2, CircleFrom3);
        }

        public double ConvertUgolFrom(double value)
        {
            return ConvertUgolRet(value, CircleFrom1, CircleFrom2, CircleFrom3);
        }

        public double ConvertUgolTo(double value)
        {
            return ConvertUgol(value, CircleTo1, CircleTo2, CircleTo3);
        }

        public double ConvertUgolToRet(double value)
        {
            return ConvertUgolRet(value, CircleTo1, CircleTo2, CircleTo3);
        }

        public double FromUgol(double delta)
        {
            delta = ConvertUgolFrom(delta);
            return delta;
        }

        public double ToUgol(double delta)
        {
            delta = ConvertUgolTo(delta);
            return delta;
        }

        public double FromUgolRet(double delta)
        {
            delta = ConvertUgolFromRet(delta);
            return delta;
        }

        public double ToUgolRet(double delta)
        {
            delta = ConvertUgolToRet(delta);
            return delta;
        }

        double radius;

        public double Radius
        {
            get => radius;
            set => radius = value;
        }

        public override double Convert(double value)
        {
            return Convert(value, 1);
        }

        public double Convert(double value, double radius)
        {
            Radius = radius;
            return base.Convert(value);
        }

        public int IndexTransferFrom1
        {
            get => CircleList.IndexFrom1;
            set => CircleList.IndexFrom1 = value;
        }

        public int IndexTransferFrom2
        {
            get => CircleList.IndexFrom2;
            set => CircleList.IndexFrom2 = value;
        }

        public int IndexTransferFrom3
        {
            get => CircleList.IndexFrom3; set => CircleList.IndexFrom3 = value;
        }

        public int IndexTransferTo1
        {
            get => CircleList.IndexTo1; 
            set => CircleList.IndexTo1 = value;
        }

        public int IndexTransferTo2
        {
            get => CircleList.IndexTo2; set => CircleList.IndexTo2 = value;
        }

        public int IndexTransferTo3
        {
            get => CircleList.IndexTo3; set => CircleList.IndexTo3 = value;
        }

        public static double Radian(double gradus)
        {
            return gradus * 2 * Math.PI / 360;
        }

        public static double Gradus(double radian)
        {
            return (radian * 360) / (2 * Math.PI);
        }

        public static double SinRad(double radian)
        {
            return Sin(Gradus(radian));
        }

        public static double CosRad(double radian)
        {
            return Cos(Gradus(radian));
        }

        public static double SecRad(double radian)
        {
            return Sec(Gradus(radian));
        }

        public static double CosecRad(double radian)
        {
            return Cosec(Gradus(radian));
        }

        public static double Sec(double gradus)
        {
            double result = Cos(gradus);
            if (result == 0)
                throw new Exception();
            return 1 / result;
        }

        public static double Cosec(double gradus)
        {
            double result = Sin(gradus);
            if (result == 0)
                throw new Exception();
            return 1 / result;
        }

        public static double Arccosec(double value)
        {
            if(value == 0)
                throw new Exception();
            return Arcsin(1 / value);
        }

        public static double Arcsec(double value)
        {
            if (value == 0)
                throw new Exception();
            return Arccos(1 / value);
        }

        public static double CtgRad(double radian)
        {
            return Ctg(Gradus(radian));
        }

        public static double TgRad(double radian)
        {
            return Tg(Gradus(radian));
        }

        public static double Sin(double gradus)
        {
            double value = gradus;
            double result = value;

            if (Math.Abs(result) > 90)
            {
                double result1 = Math.Abs(result);
                result1 /= result;
                double result2 = Math.Abs(result);
                double result3 = result2 / 180;
                int result4 = (int)Math.Truncate(result3);
                result2 -= 180 * result4;
                result2 *= Math.Pow(-1, result4);
                result2 *= result1;
                result = result2;
            }

            if (result == 90)
            {
                return 1;
            }
            if (result == -90)
            {
                return -1;
            }
            if (result == 0)
            {
                return 0;
            }


            value = Radian(result);
            return Math.Sin(value);
        }

        public static double Cos(double gradus)
        {
            double value = gradus;
            double result = Math.Abs(value);

            if (result > 360)
            {
                double result1 = result / 360;
                int result2 = (int)Math.Truncate(result1);
                result -= 360 * result2;

            }

            if (result > 180)
            {
                result -= 180;
                result = Math.Abs(result);
                result -= 180;

            }

            result = Math.Abs(result);

            if (result == 0)
            {
                return 1;
            }
            if (result == 180)
            {
                return -1;
            }
            if (result == 90)
            {
                return 0;
            }

            value = Radian(result);
            return Math.Cos(value);
        }

        public static double Tg(double gradus)
        {
            double sin = Sin(gradus);
            double cos = Cos(gradus);
            if (cos == 0)
                throw new Exception();
            return sin / cos;
        }

        public static double Ctg(double gradus)
        {
            double sin = Sin(gradus);
            double cos = Cos(gradus);
            if (sin == 0)
                throw new Exception();
            return cos / sin;
        }

        public static double ArcsinRad(double value)
        {
            return Radian(Arcsin(value));
        }

        public static double ArccosRad(double value)
        {
            return Radian(Arccos(value));
        }

        public static double ArccosecRad(double value)
        {
            return Radian(Arccosec(value));
        }

        public static double ArcsecRad(double value)
        {
            return Radian(Arcsec(value));
        }

        public static double ArctgRad(double value)
        {
            return Radian(Arctg(value));
        }

        public static double ArcctgRad(double value)
        {
            return Radian(Arcctg(value));
        }

        public static double Arcsin(double value)
        {
            double result = value;
            if (Math.Abs(result) > 1)
                throw new Exception();
            if (result == 0)
            {
                return 0;
            }
            if (result == 1)
                return 90;
            if (result == -1)
                return -90;


            return Gradus(Math.Asin(result));
        }

        public static double Arccos(double value)
        {
            
            double result = value;
            if (Math.Abs(result) > 1)
                throw new Exception();
            if (result == 0)
            {
                return 90;
            }
            if (result == 1)
                return 0;
            if (result == -1)
                return 180;


            return Gradus(Math.Acos(result));
        }

        public static double Arctg(double value)
        {
            double result = Math.Pow(value, 2) + 1;
            result = Math.Sqrt(result);
            result = value / result;
            return Arcsin(result);
            /*

            if(value == 0)
            {
                return 0;
            }
            double result = Math.Pow(value, 2);
            double result1 = value / Math.Abs(value);

            //result = 1 - result;
            //result = 1 / result;
            result++;
            if (result >= 0)
                result = Math.Sqrt(result);
            else
                result = -Math.Sqrt(-result);
            result *= result1;
            //result = value / result;
            result = 1 / result;

            return Arccos(result);
            */
        }

        public static double Arcctg(double value)
        {
            double result = Math.Pow(value, 2) + 1;
            result = Math.Sqrt(result);
            result = value / result;
            return Arccos(result);
            /*
            if (value == 0)
            {
                return  90;
            }
            double result = Math.Pow(value, 2);
            double result1 = value / Math.Abs(value);

            //result = 1 - result;
            // result = 1 / result;
            result++;
            if (result >= 0)
                result = Math.Sqrt(result);
            else
                result = -Math.Sqrt(-result);
            result *= result1;
            result = 1 / result;

            return Arcsin(result);
            */
        }

        public static double UgolMinesSin(double gradus)
        {
            return Radian(gradus)-Sin(gradus);
        }

        public static double UgolSegment(double result)
        {
            return UgolSegment(result, 10, Math.Pow(10.0, -16));
        }

        public static double UgolSegment(double sqr, double radius)
        {
            return UgolSegment(2 * sqr / radius);
        }

        public static double UgolSegment(double result, double interval, double e)
        {
            double startValue = 0;
            double endValue = startValue + 180;
            double startValue1 = Radian(startValue);
            double endValue1 = Radian(endValue);
            if(result >= startValue1 && result <= endValue1)
                return UgolSegment(result, interval, e, startValue, endValue);
            else if(result > endValue1)
            {
                while(result > endValue1)
                {
                    startValue += 180;
                    endValue = startValue + 180;
                    startValue1 = Radian(startValue);
                    endValue1 = Radian(endValue);
                }
            }
            else
            {
                while (result < startValue1)
                {
                    startValue -= 180;
                    endValue = startValue + 180;
                    startValue1 = Radian(startValue);
                    endValue1 = Radian(endValue);
                }
            }
            return UgolSegment(result, interval, e, startValue, endValue);
        }

        public static double UgolSegment(double result, double interval, double e, double startValue, double endValue)
        {
            double startValue1 = Radian(startValue);
            double endValue1 = Radian(endValue);

            if (result > endValue1 || result < startValue1)
                throw new Exception();
            double x1 = startValue;
            bool have = false;
            double value1 = UgolMinesSin(x1);

            while(have)
            {
                x1 = startValue;
                //have = true;
                double x2 = x1 + interval;
                double x11 = UgolMinesSin(x1);
                double x12 = UgolMinesSin(x2);

                
                    while (value1 < endValue && !(x11 <= result && x12 >= result))
                    {
                        x1 += interval;
                    x2 += interval;
                    x11 = UgolMinesSin(x1);
                    x12 = UgolMinesSin(x2);
                    if (result > x11 && result < x11+e)
                        value1 = x11;
                    else if (result < x12 && result > x12 - e)
                        value1 = x12;
                    else
                        value1 = (x11 + x12) / 2;
                }
                    double value2 = UgolMinesSin(value1);
                double value = Math.Abs(value2 - result);
                if(value < e)
                {
                    have = true;
                }
                else
                {
                    have = false;
                    startValue = x1;
                    endValue = x1 + interval;

                    interval /= 10;
                }
            }

            double ugol = value1;

            return Gradus(ugol);
        }


        public UgolsConverter() : base()
        {
            CircleList = new CircleUgolsListNormalTransfer();

            Radius = 1;
            UgolNumber = UgolNumber.Now;

            timeConverter = new TimeConverter();
            MetrsConvert convert = Add("Градусы");
            convert.ConvertFrom = (value) => FromUgol(value ) /UgolDelta();
            convert.ConvertTo = (value) => ToUgol( value) * UgolDelta();
            MetrsConvert gradus = convert;

            convert = Add("Радианы");
            convert.ConvertFrom = (value) => gradus.From(value / (2 * Math.PI / 360));
            convert.ConvertTo = (value) => gradus.To(value) * (2 * Math.PI / 360);
            MetrsConvert radian = convert;

            convert = Add("Угловые минуты");
            convert.ConvertFrom = (value) => gradus.From(value / 60);
            convert.ConvertTo = (value) => gradus.To(value) * 60;

            convert = Add("Угловые секунды");
            convert.ConvertFrom = (value) => gradus.From(value / 3600);
            convert.ConvertTo = (value) => gradus.To(value) * 3600;
            MetrsConvert seconds = convert;

            convert = Add("Угловое время");
            convert.ConvertFrom = (value) => seconds.From(TimeConverter.FromDo(value));
            convert.ConvertTo = (value) => seconds.To(TimeConverter.ToDo(value));
            MetrsConvert time = convert;

            convert = Add("Количество окружностей (кругов)");
            convert.ConvertTo = (value) => gradus.To(value) / 360;
            convert.ConvertFrom = (value) => gradus.From(value * 360);
            MetrsConvert convertCurcle = convert;

            convert = Add("Количество полуокружностей (полукругов)");
            convert.ConvertTo = (value) => convertCurcle.To(value) *2;
            convert.ConvertFrom = (value) => convertCurcle.From(value / 2);

            convert = Add("Количество четвертей окружностей (кругов)");
            convert.ConvertTo = (value) => convertCurcle.To(value) * 4;
            convert.ConvertFrom = (value) => convertCurcle.From(value / 4);

            convert = Add("Единичная окружность");
            convert.ConvertFrom = (value) =>
            {
                return (radian.From(value));
            };
            convert.ConvertTo = (value) =>
            {
                return radian.To(( value));
            };
            MetrsConvert circle = convert;

            convert = Add("Единичный круг");
            convert.ConvertFrom = (value) =>
            {
                return circle.From(value * 2);
            };
            convert.ConvertTo = (value) =>
            {
                return circle.To(value)/2;
            };
            MetrsConvert circle1 = convert;

            convert = Add("Единичная полуокружность");
            convert.ConvertFrom = (value) =>
            {
                return circle.From(value*2);
            };
            convert.ConvertTo = (value) =>
            {
                return circle.To(value)/2;
            };
            MetrsConvert polocircle = convert;

            convert = Add("Единичный полукруг");
            convert.ConvertFrom = (value) =>
            {
                return circle1.From(value * 2);
            };
            convert.ConvertTo = (value) =>
            {
                return circle1.To(value) / 2;
            };

            convert = Add("Синус");
            convert.ConvertTo = (value) =>
            {
                return Sin(gradus.To(value));
                value = gradus.To(value);
                double result = value;

                if (Math.Abs(result) > 90)
                {
                    double result1 = Math.Abs(result);
                    result1 /= result;
                    double result2 = Math.Abs(result);
                    double result3 = result2 / 180;
                    int result4 = (int)Math.Truncate(result3);
                    result2 -= 180 * result4;
                    result2 *= Math.Pow(-1, result4);
                    result2 *= result1;

                }

                if (result == 90)
                {
                    return 1;
                }
                if (result == -90)
                {
                    return -1;
                }
                if (result == 0)
                {
                    return 0;
                }


                value = gradus.From(value);
                return Math.Sin(radian.To(value));
            };
            convert.ConvertFrom = (value) =>
            {
                return gradus.From(Arcsin(value));
                double result = value;
                if (Math.Abs(result) > 1)
                    throw new Exception();
                if (result == 0)
                {
                    return gradus.From(0);
                }
                if (result == 1)
                    return gradus.From(90);
                if (result == -1)
                    return gradus.From(-90);


                return radian.From(Math.Asin(result));
            };

            MetrsConvert sin = convert;

            convert = Add("Косинус");
            convert.ConvertTo = (value) =>
            {
                return Cos(gradus.To(value));
                value = gradus.To(value);
                double result = Math.Abs(value);

                if (result > 180)
                {
                    double result1 = result / 360;
                    int result2 = (int)Math.Truncate(result1);
                    result -= 360 * result2;

                }

                if (result == 0)
                {
                    return 1;
                }
                if (result == 180)
                {
                    return -1;
                }
                if (result == 90)
                {
                    return 0;
                }

                value = gradus.From(value);
                return Math.Cos(radian.To(value));
            };
            convert.ConvertFrom = (value) =>
            {
                return gradus.From(Arccos(value));
                double result = value;
                if (Math.Abs(result) > 1)
                    throw new Exception();
                if (result == 0)
                {
                    return gradus.From(90);
                }
                if (result == 1)
                    return gradus.From(0);
                if (result == -1)
                    return gradus.From(180);


                return radian.From(Math.Acos(result));
            };

            MetrsConvert cos = convert;

            convert = Add("Тангенс");
            convert.ConvertTo = (value) =>
            {
                return Tg(gradus.To(value));
                double result = 0;

                double a = sin.To(value);
                double b = cos.To(value);
                if (b == 0)
                    throw new Exception();
                result = a / b;

                return result;
            };
            convert.ConvertFrom = (value) =>
                {
                    return gradus.From(Arctg(value));
                    double result = Math.Pow(value, 2);
                    double result1 = result/Math.Abs(result);
                    result = 1 - result;
                    result = 1 / result;
                    result = Math.Sqrt(result) * result1;

                    return cos.From(value);
                };
            MetrsConvert tg = convert;

            convert = Add("Катангенс");
            convert.ConvertTo = (value) =>
            {
                return Ctg(gradus.To(value));
                double result = 0;

                double b = sin.To(value);
                double a = cos.To(value);
                if (b == 0)
                    throw new Exception();
                result = a / b;

                return result;
            };
            convert.ConvertFrom = (value) =>
            {
                return gradus.From(Arcctg(value));
                double result = Math.Pow(value, 2);
                double result1 = result / Math.Abs(result);
                result = 1 - result;
                result = 1 / result;
                result = Math.Sqrt(result) * result1;

                return sin.From(value);
            };
            MetrsConvert ctg = convert;

            convert = Add("Секанс");
            convert.ConvertFrom = (value) =>
            {
                if (value == 0)
                    throw new Exception();
                return cos.From(1 / value);
            };
            convert.ConvertTo = (value) =>
            {
                double result = cos.To(value);
                if (result == 0)
                    throw new Exception();
                return 1/result;
            };

            convert = Add("Косеканс");
            convert.ConvertFrom = (value) =>
            {
                if (value == 0)
                    throw new Exception();
                return sin.From(1 / value);
            };
            convert.ConvertTo = (value) =>
            {
                double result = sin.To(value);
                if (result == 0)
                    throw new Exception();
                return 1/result;
            };

            convert = Add("Длина дуги окружности (Требуется радиус)");
            convert.ConvertFrom = (value) => circle.From(value * radius);
            convert.ConvertTo = (value) => circle.To(value) * radius;
            MetrsConvert duga = convert;

            convert = Add("Площадь сектора (Требуется радиус)");
            convert.ConvertFrom = (value) => duga.From(value /(radius/2));
            convert.ConvertTo = (value) => duga.To(value) * radius / 2;
            MetrsConvert sector = convert;

            convert = Add("Высота равнобедренного треугольника из радиусов");
            convert.ConvertTo = (value) => radius * Cos(gradus.To(value)/2);
            convert.ConvertFrom = (value) =>
            {
                double result = value / radius;


                result = (gradus.From(Arccos(result) * 2));

                return result;
            };
            MetrsConvert height = convert;

            convert = Add("Хорда (Основание равнобедренного треугольника из радиусов)");
            convert.ConvertTo = (value) =>
            {
                value = gradus.To(value);
                double result = 2 * Math.Pow(radius, 2) * (1 - Sin(value));
                if (result < 0)
                    return -Math.Sqrt(-result);
                return Math.Sqrt(result);
            };
            convert.ConvertFrom = (value) =>
            {
                double result = Math.Pow(value, 2);
                double radius = Math.Pow(Radius, 2);

                result = (result / (2 * Math.Pow(radius, 2))) - 1;
                result = gradus.From(Arcsin(result));

                return result;
            };

            convert = Add("Хорда через центральный угол (Требуется радиус)");
            convert.ConvertTo = (value) =>
            {
                value = gradus.To(value) / 2;
                return 2 * Radius * Sin(value);
            };
            convert.ConvertFrom = (value) =>
            {
                double result = Arcsin(value / (2 * Radius)) * 2;
                return gradus.From(value);
            };
            MetrsConvert horda = convert;

            convert = Add("Боковая сторона треугольника из хорды и стороны описанного угла (Требуется радиус)");
            convert.ConvertTo = (value) =>
            {
                double value1 = gradus.To(value);
                return (horda.To(value)/2)/ Cos(value1 / 2);
            };
            convert.ConvertFrom = (value) =>
            {
                double radius = Radius;
                if (radius == 0)
                    throw new Exception();
                return gradus.From(Arctg(value / radius) * 2);
                //return value*sin.From(value / (2 * Radius)) * 2;
            };
            MetrsConvert side = convert;

            convert = Add("Высота треугольника из хорды и сторон описанного угла (Требуется радиус)");
            convert.ConvertTo = (value) =>
            {
                double value1 = gradus.To(value);
                return side.To(value) * Sin(value1 / 2);
            };
            convert.ConvertFrom = (value) =>
            {
                double radius = Radius;
                if (radius == 0)
                    throw new Exception();
                double a = value / radius;
                // r*(tg(x)*sin(x))=value
                // (tg(x)*sin(x))=value/r
                // sin(x)^2=a*cos(x)
                // 1 - cos(x)^2-a*cos(x)=0

                double D = Math.Pow(a, 2) + 4;
                if (D < 0)
                    throw new Exception();
                else if (D == 0)
                    {
                    return cos.From(value)*2;
                }
                double x1 = -(a + Math.Sqrt(D)) /2;
                double x2 = -(a - Math.Sqrt(D)) / 2;
                double x = Math.Min(x1, x2);
                return gradus.From(Arccos(x) * 2);

                //throw new Exception();
                //return value*sin.From(value / (2 * Radius)) * 2;
            };
            MetrsConvert hide1 = convert;

            convert = Add("Площадь треугольника из хорды и стороны описанного угла (Требуется радиус)");
            convert.ConvertTo = (value) =>
            {
                return horda.To(value) * hide1.To(value) / 2;
            };
            convert.ConvertFrom = (value) =>
            {
                double radius = Radius;
                if (radius == 0)
                    throw new Exception();
                double a = value / radius;
                double ugol = 0;
                if(a < 0)
                    ugol = -Math.Sqrt(-a);
                else
                    ugol = Math.Sqrt(a);
                double x = ugol;
                return gradus.From(Arccos(x) * 2);

               // throw new Exception();
                //return value*sin.From(value / (2 * Radius)) * 2;
            };
            MetrsConvert sqr1 = convert;



            convert = Add("Площадь равнобедренного треугольника из радиусов и хорды");
            convert.ConvertTo = (value) => Math.Pow(radius, 2) * cos.To(value) / 2;
            convert.ConvertFrom = (value) =>
            {
                double result = value;
                result *= 2;
                double radius = Math.Pow(Radius, 2);
                result /= radius;

                result = (sin.From(result));

                return result;
            };
            MetrsConvert triangle = convert;

            convert = Add("Высота сегмента (Требуется радиус)");
            convert.ConvertTo = (value) => Radius - height.To(value);
            convert.ConvertFrom = (value) => height.From(Radius - value);

            convert = Add("Площадь сегмента (Требуется радиус)");
            convert.ConvertTo = (value) =>
                {
                    double result = value;
                    return sector.To(value) - triangle.To(result);
                };
            convert.ConvertFrom = (value) =>
            {
                return gradus.From(UgolSegment(value, Radius));
                double radius = Math.Pow(Radius, 2);
                if (radius == 0)
                    throw new Exception();
                double result = 2 * value / radius;
                result *= 6;
                if (result < 0)
                    result = -Math.Pow(-result, 1 / 3.0);
                else
                    result = Math.Pow(result, 1 / 3.0);

                return radian.From(result);
            };

            convert = Add("Расстояние от центра окружности для пересечения касательных, образующих центральный угол (Требуется радиус)");
            convert.ConvertTo = (value) => height.To(value)+hide1.To(value);
            convert.ConvertFrom = (value) =>
            {
                double radius = Radius;
                if (radius == 0)
                    throw new Exception();
                double a = value / radius;
                double b = 1 - 1 / radius;
                // r*(tg(x)*sin(x))+cos(x)=value
                // (tg(x)*sin(x))+cos(x)/r=value/r
                // sin(x)^2+(cos(x)^2)/r=a*cos(x)
                // 1 - cos(x)^2+(cos(x)^2)/r-a*cos(x)=0
                // -(1-1/r)*cos(x)^2-a*cos(x)+1=0

                double D = Math.Pow(a, 2) + 4*b;
                if (D < 0)
                    throw new Exception();
                else if (D == 0)
                {
                    return cos.From(value) * 2;
                }
                b *= 2;
                double x1 = -(a + Math.Sqrt(D)) / b;
                double x2 = -(a - Math.Sqrt(D)) / b;
                double x = Math.Min(x1, x2);
                return gradus.From(Arccos(x) * 2);
                throw new Exception();
            };
            MetrsConvert hide2 = convert;


            convert = Add("Высота треугольника, образованного касательными, 2 из которых образуют описанный угол (Требуется радиус)");
            convert.ConvertTo = (value) => hide2.To(value) - radius;
            convert.ConvertFrom = (value) => hide2.From(value + radius);
            MetrsConvert height1 = convert;

            convert = Add("Основание треугольника, образованного касательными, 2 из которых образуют описанный угол (Требуется радиус)");
            convert.ConvertTo = (value) =>
            {
                double gradus1 = gradus.To(value);
                gradus1 = (180 - gradus1) / 2;
                return (height1.To(value) * Tg(gradus1))*2;

            };
            MetrsConvert tangent = convert;

            convert = Add("Площадь треугольника, образованного касательными, 2 из которых образуют описанный угол (Требуется радиус)");
            convert.ConvertTo = (value) =>
            {
                return (tangent.To(value) * height1.To(value)) / 2;

            };

            convert = Add("Боковая сторона треугольника, образованного касательными, 2 из которых образуют описанный угол (Требуется радиус)");
            convert.ConvertTo = (value) =>
            {
                double gradus1 = gradus.To(value);
                gradus1 = (180 - gradus1) / 2;
                return height1.To(value) * Cos(gradus1);

            };



        }

        public TimeConverter TimeConverter { get { return timeConverter; } }

        public MetrsConvert[] TimeConverterArray => TimeConverter.MetrsConvertsArray;

        public int FromTimeIndex
        {
            get => TimeConverter.ToIndex;
            set => TimeConverter.ToIndex = value;
        }

        public int ToTimeIndex
        {
            get { return TimeConverter.ToIndex; }
            set => TimeConverter.ToIndex = value;
        }

    }
}
