﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public static class ValueHelper
    {

        public static FuncList FuncsList;

        public static FuncList GetFuncsList()
        {
            try
            {
                FuncList funcList = FuncsList;
                funcList.Check();
                if (funcList == null || funcList.Equals(null) || funcList is null)
                    throw new NullReferenceException();
                return funcList;
            }
            catch (Exception e)
            {
                FuncsList = FuncList.Get();
                return GetFuncsList();
            }
        }


        public static Action<string> SetTextAction;

        public static void SetText(string text)
        {
            try
            {
                SetTextAction?.Invoke(text);
            }
            catch { }
        }

        public static Func<string> GetTextAction;

        public static string GetText()
        {
            try
            {
                return GetTextAction?.Invoke()??"";
            }
            catch {
                return "";
            }
        }

        public static ListCalculator ListCalculator;
    }
}
