﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{

    public delegate void ToExcelChanged(ValueOfList valueOfList, ExcelFile excelFile);

    public delegate void ExcelChangingName(string path, string oldName, string newName, ExcelFile file);
    public delegate string InputFromExcel(ValueOfList valueOfList, ExcelFile excelFile);

    public class ExcelFile : FileOfFile
    {
        public event ExcelChangingName ExcelChangingName;

        public void ExcelChangingNameInvoke(string oldName, string newName)
        {
            ExcelChangingName?.Invoke(Path, oldName, newName, this);
        }

        protected override void ListNameChanged(string oldName, string newName)
        {
            ExcelChangingNameInvoke(oldName, newName);
        }

        public ExcelFile()
        {
        }

        public ExcelFile(string name) : base(name)
        {
        }

        public ExcelFile(string name, string path) : base(name, path)
        {
        }

        public ExcelFile(FilesList parent) : base(parent)
        {
        }

        public ExcelFile(FilesList parent, string name) : base(parent, name)
        {
        }

        public ExcelFile(FilesList parent, string name, string path) : base(parent, name, path)
        {
        }



        public override void Output(ValueOfList value)
        {
            ToExcelChangedInvoke(value);
        }

        public event ToExcelChanged ToExcelChanged;

        public void ToExcelChangedInvoke(ValueOfList valueOfList)
        {
            ToExcelChanged?.Invoke(valueOfList, this);
        }

        public override string Input(ValueOfList valueOfList)
        {
            ListFile list = valueOfList.List;
            int column = valueOfList.ColumnIndex;
            int row = valueOfList.RowIndex;
            return InputFromExcelInvoke(valueOfList);

        }

        public event InputFromExcel InputFromExcel;

        public string InputFromExcelInvoke( ValueOfList valueOfList)
        {
            return InputFromExcel?.Invoke(valueOfList, this);
        }
    }
}
