﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public delegate void SavedThisValue(FileAtValueThis file, ValueOfList value, string message);
    public class FileAtValueThis : FileWithValueFind
    {
        public FileAtValueThis(FilesList parent) : base(parent)
        {
        }

        public FileAtValueThis(FilesList parent, string name) : base(parent, name)
        {
        }

        public override void Output(ValueOfList value)
        {
            try
            {
                value.TransferThisAll();
                SavedInvoke(value, "Успешно");
            }
            catch
            {
                SavedInvoke(value, "Ошибка!!!");
            }
        }

        public event SavedThisValue Saved;

        public void SavedInvoke(ValueOfList value, string message)
        {
            Saved?.Invoke(this, value, message);
        }

        public override string Input(ValueOfList valueOfList)
        {
            return valueOfList.Value;
        }
    }
}
