﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class FileOfFile : ValuesFile
    {
        public override string GetPath()
        {
            return Path;
        }

        protected FileOfFile()
        {
        }

        protected FileOfFile(string name) : base(name)
        {
        }

        public FileOfFile(string name, string path):this(name)
        {
            Path = path;
        }

        protected FileOfFile(FilesList parent) : base(parent)
        {
        }

        protected FileOfFile(FilesList parent, string name) : base(parent, name)
        {
        }

        public FileOfFile(FilesList parent, string name, string path) : this(parent, name)
        {
            Path = path;
        }

        protected override void CreateSettings()
        {
            base.CreateSettings();
            Path = "";
        }

        string path;

        public string Path
        {
            get => path;
            set => path = value.Replace("/", "\\");
        }

        public string FullName
        {
            get => Path;
            set => Path = value;
        }

        public string[] PartsPath
        {
            get => Path.Split(new char[] { '/', '\\' });
            set => Path = String.Join("/", value);
        }

        public int PathLength => PartsPath.Length;
        public int PathLast => PathLength - 1;

        public string NameFileInPath
        {
            get => PartsPath[PathLast];
            set => PartsPath[PathLast] = value;
        }


        public virtual string ExcecutablePath
        {
            get => Path.Replace('/', '\\');
            set => Path = value;
        }

        public string StartupPath
        {
            get
            {
                List<string> parts = new List<string>(PartsPath);
                parts.RemoveAt(PathLast);
                return string.Join("\\", parts.ToArray());
            }
            set
            {
                string startupPath = value.Replace('/', '\\');
                string[] parts = startupPath.Split('\\');
                List<string> parts1 = new List<string>(parts);
                parts1.Add(NameFileInPath);
                PartsPath = parts1.ToArray();
            }
        }

    }
}
