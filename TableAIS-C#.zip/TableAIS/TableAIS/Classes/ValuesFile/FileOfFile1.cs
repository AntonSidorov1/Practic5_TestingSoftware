﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class FileOfFile1 : FileOfFile
    {
        
        public FileOfFile1(FilesList parent, string name, string path) : base(parent, name, path)
        {
        }

        public override string GetPath()
        {
            return ExcecutablePath;
        }

        public override string ExcecutablePath { get => StartupPath+"\\"+NameFileInPath; set => base.ExcecutablePath = value; }
    }
}
