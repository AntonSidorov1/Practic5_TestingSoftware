﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class FileOutput : ValueOutput
    {
        public FileOutput()
        {
            CreateSettings();
        }

        public FileOutput(string name): base(name)
        {

        }

        bool allowPutByNetwork;

        /// <summary>
        /// Разрешиать получение текста по сети
        /// </summary>
        public bool AllowPutByNetwork
        {
            get => allowPutByNetwork;
            set => allowPutByNetwork = value;
        }

        /// <summary>
        /// Разрешить загрузку текста по сети
        /// </summary>
        public virtual bool AllowLoadByNetwork
        {
            get => AllowPutByNetwork;
        }


        /// <summary>
        /// Запретить получение текста по сети
        /// </summary>
        public bool NoAllowPutByNet
        {
            get => !AllowPutByNetwork; set => AllowPutByNetwork = !value;
        }


        public abstract void Output();

        public void Rename(string name)
        {
            Name = name;
        }

        public ValueOfList AsValueOfList() => this as ValueOfList;
        public bool IsValueOfList() => this is ValueOfList;


        public ListFile AsList() => this as ListFile;
        public bool IsfList() => this is ListFile;

    }
}
