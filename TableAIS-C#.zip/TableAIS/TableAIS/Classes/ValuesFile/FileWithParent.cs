﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class FileWithParent : FileOfFile
    {
        public FileWithParent(FilesList parent) : base(parent)
        {
        }

        public FileWithParent(FilesList parent, string name) : base(parent, name)
        {
        }

        public FileWithParent(FilesList parent, string name, string path) : base(parent, name, path)
        {
        }

    }
}
