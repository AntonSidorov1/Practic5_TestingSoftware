﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class FileWithValueFind : FileWithParent
    {
        protected FileWithValueFind(FilesList parent) : base(parent)
        {
        }

        protected FileWithValueFind(FilesList parent, string name) : base(parent, name)
        {
        }


        public ValueOfList GetValueByFindList(string name)
        {
            return Parent.GetValue(Name);
        }

        public ValueOfList GetValuesByFindList(ValueOutput name)
        {
            return Parent.GetValue(Name);
        }
    }
}
