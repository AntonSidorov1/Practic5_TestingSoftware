﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace TableAIS
{

    public delegate void Changed(object[] list);
    public delegate void Changed1(object[] list, FileOutput file);
    public class FilesList : ValueOutput
    {
        
        public FilesList() : base()
        {
            
        }

        public FilesList(string name) : base(name)
        {
        }

        protected override void CreateSettings()
        {
            base.CreateSettings();
            values = new List<ValuesFile>();
        }

        List<ValuesFile> values;

        public ValuesFile Get(int index) => values[index];
        public ValuesFile Get(string name) => values.Find(x => x.Name.ToLower() == name.ToLower());

        public bool Contains(string name) => values.Any(x => x.Name.ToLower() == name.ToLower()) ;

        public ValueOfList GetValue(string name) => values.Find(x => x.ContainsValue(name)).GetValue(name);
        public void SetValueByName(string name, string value) => GetValue(name).SetValue(value);

        public ValueOfList GetValue(ValueOutput name) => GetValue(name.Name);

        public bool ContainsValue(string name)
        {
            try
            {
                if(NoRightName(name))
                    return true;
                if(Count < 1)
                    return false;
                return values.Any(x => x.ContainsValue(name));
            }
            catch
            { return false; }
        }

        public NoneFile AddNone(string name)
        {
            
            return (NoneFile)Add(new NoneFile(this, name));
        }


        public TextFile AddText(string name, string path)
        {

            return (TextFile)Add(new TextFile(this, name, path));
        }


        public FileAtValueThis AddAtThis(string name)
        {

            return (FileAtValueThis)Add(new FileAtValueThis(this, name));
        }


        public ExcelFile AddExcel(string name)
        {

            return (ExcelFile)Add(new ExcelFile(this, name));
        }

        public ExcelFile AddExcel(string name, string path)
        {

            return (ExcelFile)Add(new ExcelFile(this, name, path));
        }

        public TcpFile AddTCP(string name, string address)
        {

            return (TcpFile)Add(new TcpFile(this, name, address));
        }

        public UdpFile AddUDP(string name, string address)
        {

            return (UdpFile)Add(new UdpFile(this, name, address));
        }

        public ValuesFile Add(ValuesFile file)
        {
            file.Parent = this;
            CheckName(file.Name);

            values.Add(file);
            ChangedInvoke();
            return Get(file.Name);
        }

        public void CheckName(string name)
        {
            if (Contains(name))
                throw new Exception("Файл с таким именем уже существует");
            if (name == "")
                throw new Exception("Имя файла не может быть пустым");
        }

        public void TransferValue(string startValueName, string endValueName)
        {
            if (startValueName == endValueName || startValueName.Equals(endValueName) || endValueName.Equals(startValueName))
                return;
            string value = GetValue(startValueName).Value;
            GetValue(endValueName).SetValue(value);
        }

        public void TransferValue(ValueOutput startValue, string endValueName)
        {
            TransferValue(startValue.Name, endValueName);
        }

        public void ChangedInvoke()
        {
            Changed?.Invoke(GetObjects());
        }

        public object[] GetObjects()
        {
            return values.ToArray();
        }

        public event Changed Changed;

        public void Delete(int index)
        {
            values.RemoveAt(index);
            ChangedInvoke();
        }

        public FileOutput Rename(int index, string newName)
        {
            FileOutput file = Get(index);
            if (file.Name == newName)
                return file;
            CheckName(newName);
            file.Name = newName;
            ChangedInvoke();
            return file;

        }

        public void SetValueWithOutput(string name, string value)
        {
            ValueOfList list = GetValue(name);
            list.ValueFormat = value;
            list.Output();
        }

        public int IndexOf(string name) => values.FindIndex(x => x.Name == name);

        public int IndexByName(string name) => IndexOf(name);
        public int IndexByName(FileOutput file) => IndexByName(file.Name);


        public int IndexOfFormat(string name)
        {
            int index = IndexOf(name);
            if(index < 0 || index >= Count)
            {
                throw new Exception("Файл с таким именем не найден");
            }
            return IndexOf(name);
        }

        public int Count => values.Count;

        public bool NoContainsValue(string nameValue)=>!ContainsValue(nameValue);

        public void CopyValue(string nameStartValue, string nameEndValue)
        {
            if (NoContainsValue(nameStartValue))
                throw new Exception("Начального значения не сущеаствует");
            ValueOfList startValue = GetValue(nameStartValue);
            string value = startValue.ValuePoint;
            SetValue(nameEndValue, value);
        }

        public void CopyValueWithJsonView(string nameStartValue, string nameEndValue)
        {
            if (NoContainsValue(nameStartValue))
                throw new Exception("Начального значения не сущеаствует");
           
            string value = GetJsonOfValue(nameStartValue);
            SetValue(nameEndValue, value);
        }

        public void CopyValueFromJsonView(string nameStartValue, string nameEndValue)
        {
            if (NoContainsValue(nameStartValue))
                throw new Exception("Начального значения не сущеаствует");

            string value = GetValue(nameStartValue).ValuePoint;
            SetJsonOfValue(nameEndValue, value);
        }

        public void SetValue(string nameValue, string value)
        {
            if(nameValue.Length < 1)
            {
                throw new Exception("Конечное значение должно иметь название");
            }
            if(!ContainsValue(nameValue))
            {
                throw new Exception("Конечного значения не существует");
            }
            ValueOfList endValue = GetValue(nameValue);
            endValue.SetValue(value);
        }

        public string GetJsonOfValue(string valueName)
        {
            string nameValue = valueName;
            if (NoContainsValue(nameValue))
            {
                throw new Exception("Начального значения не существует");
            }
            return GetValue(nameValue).ToJson();
        }


        public void SetJsonOfValue(string valueName, string jsonValue)
        {
            string nameValue = valueName;
            if (NoContainsValue(nameValue))
            {
                throw new Exception("Конечного значения не существует");
            }
            GetValue(nameValue).FromJson(jsonValue);
        }

        public bool SetValueOfJsonNet(string json, out bool haveValue, out string name)
        {
            JsonObject obj = (JsonObject)JsonNode.Parse(json);
            name = obj["name"].ToString();
            haveValue = ContainsValue(name);
            if (!haveValue)
            {
                return false;
            }
            if (!AllowPutByNet(name))
            {
                try
                {
                    SetValueOfJsonNetBuffer(json);
                }
                catch { }
                return false;
            }
            try
            {
                SetValueOfJson(json);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void SetValueOfJson(string json)
        {
            JsonObject obj = (JsonObject)JsonNode.Parse(json);
            string name = obj["name"].ToString();
            if(NameIsValue(name))
            {
                string value = obj["value"]["value"].ToString();
                GetText?.Invoke(value);
                
            }
            else if(NameIsJson(name))
            {
                GetText?.Invoke(obj["value"].ToString());
            }
            else if(NameIsValueBuffer(name))
            {
                ToBuffer?.Invoke(obj["value"]["value"].ToString());
            }
            else if(NameIsJsonBuffer(name))
            {
                ToBuffer?.Invoke(obj["value"].ToString());
            }
            

            if (NoRightName(name))
                return;
            ValueOfList valueOfList = GetValue(name);
            if(valueOfList.NecessarilyAuthorization)
            {
                try
                {
                    string password = obj["password"].ToString();
                    if (valueOfList.Password != password)
                    {
                        throw new Exception("Неверный пароль");
                    }
                }
                catch 
                {
                    if(valueOfList.Password.Length > 0)
                        throw new Exception("Неверный пароль");
                }
            }
            valueOfList.FromJson(obj["value"].ToString());
        }

        public void SetValueOfJsonNetBuffer(string json)
        {
            JsonObject obj = (JsonObject)JsonNode.Parse(json);
            string name = obj["name"].ToString();
            ValueOfList valueOfList = GetValue(name);
            valueOfList.NetBuffer = obj["value"]["value"].ToString();
        }

        public bool NoValueNames(string name)
        {
            return NameIsValue(name) || NameIsJson(name) || NameIsValueBuffer(name) || NameIsJsonBuffer(name) || NameIsBuffer(name);
        }

        public bool AllowPutByNet(string valueNet)
        {
            try
            {
                if(NoRightName(valueNet)) return true;
                if(!ContainsValue(valueNet))
                {
                    return false;
                }
                return GetValue(valueNet).AllowLoadByNetwork;
            }
            catch {
            return false;}
        }

        public bool CorrectPassword(string valueNet, string password)
        {
            try
            {
                if (NoRightName(valueNet)) return true;
                if (!ContainsValue(valueNet))
                {
                    return false;
                }
                ValueOfList valueOfList = GetValue(valueNet);
                if (!valueOfList.NecessarilyAuthorization)
                    return true;
                return GetValue(valueNet).Password == password;
            }
            catch
            {
                return false;
            }
        }

        public void NotificationView(string name, string message)
        {
            GetValue(name).ShowNotificationViewInvoke(message);
        }

        public bool NameIsValue(string name)
        {
            return name.ToLower() == "value" || name.ToLower() == "значение";
        }

        public bool NameIsValueBuffer(string name)
        {
            string[] parts = name.Split('-');
            if(parts.Length != 2)
                return false;
            return NameIsValue(parts[0]) &&
                NameIsBuffer(parts[1]);
        }

        public bool NameIsJsonBuffer(string name)
        {
            string[] parts = name.Split('-');
            if (parts.Length != 2)
                return false;
            return NameIsJson(parts[0]) &&
                NameIsBuffer(parts[1]);
        }

        public bool NameIsBuffer(string name)
        {
            return name.ToLower() == "buffer" || name.ToLower() == "буфер"
                || name.ToLower() == "bufer" || name.ToLower() == "буффер";
        }

        public bool NameIsJson(string name)
        {
            return name.ToLower() == "json";
        }

        public bool NoRightName(string name)
        {
            return NameIsValue(name)
                || NameIsJson(name)
                || NameIsValueBuffer(name)
                || NameIsJsonBuffer(name)
                || NameIsBuffer(name)
                || NoValueNames(name);
        }

        public event GetText GetText;
        public event GetText ToBuffer;
    }

    public delegate void GetText(string value);
    

}
