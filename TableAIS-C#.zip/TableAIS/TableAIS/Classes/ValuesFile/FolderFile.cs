﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS
{
    public abstract class FolderFile : FileOfFile1
    {
        public FolderFile(FilesList parent, string name, string path) : base(parent, name, path)
        {
        }

        public string Folder
        {
            get => ExcecutablePath; set => ExcecutablePath = value;
        }

        public override void Output(ValueOfList value)
        {
            string executablePath = ExcecutablePath.Replace('/', '\\');
            int length = executablePath.Length;
            int last = length - 1;
            if (executablePath[last] == '\\') 
            { 
                executablePath = executablePath.Substring(0, last);
            }
            string path = executablePath + "\\" + value.NameFile;
            SaveFile(value, path);
        }

        public override string Input(ValueOfList value)
        {
            string executablePath = ExcecutablePath.Replace('/', '\\');
            int length = executablePath.Length;
            int last = length - 1;
            if (executablePath[last] == '\\')
            {
                executablePath = executablePath.Substring(0, last);
            }
            string path = executablePath + "\\" + value.NameFile;
            return LoadFile(value, path);
        }

        public abstract void SaveFile(ValueOfList value, string filePath);
        public abstract string LoadFile(ValueOfList value, string filePath);
    }
}
