﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class ListFile<T> : FileOutput
        where T: FileOutput
    {
        public ListFile(T file): base()
        {
            CreateParent(file);
        }

        public ListFile(T file, string name) : base(name)
        {
            CreateParent(file);
        }

        protected void CreateParent(T file)
        {
            parentA = file;
        }

        private T parent;

        protected T parentA
        {
            get => parent;
            set => parent = value;
        }

        public T Parent => parent;

        public override void Output()
        {
            OutputValue();
        }

        public abstract void OutputValue();


        public abstract int Index { get; }

        public override bool AllowLoadByNetwork => base.AllowLoadByNetwork && Parent.AllowLoadByNetwork;


    }

    public  class ListFile : ListFile<ValuesFile>
    {
        public ListFile(ValuesFile file) : base(file)
        {
        }

        public ListFile(ValuesFile file, string name) : base(file, name)
        {
        }

        protected override void CreateSettings()
        {
            base.CreateSettings();
            rows = new List<ValueOfList>();
            AllowPutByNetwork = true;
        }

        public void Output(ValueOfList value)
        {
            Parent.Output(value);
        }

        public void OutputValue(int index) => Output(Get(index));
        


        public List<ValueOfList> rows;

        public int IndexOf(ValueOfList value) => rows.IndexOf(value);

        public override int Index => Parent.IndexOf(this);


        public List<ValueOfList> values => rows;
        public List<ValueOfList> list => rows;

        public ValueOfList Get(int index) => values[index];

        public override void OutputValue()
        {
            
        }


       
        public ValueOfList Get(string name) => values.Find(x => x.Name.ToLower() == name.ToLower());

        public bool Contains(string name) => values.Any(x => x.Name.ToLower() == name.ToLower());

        public ValueOfList GetValue(string name) => Get(name);
        public bool ContainsValue(string name) => Contains(name);


        public ValueOfList[] ArrayList() => list.ToArray();

        public void ChangedInvoke()
        {
            Changed?.Invoke(GetObjects(), this);
        }

        public object[] GetObjects()
        {
            return ArrayList();
        }

        public event Changed1 Changed;

        public ValueOfList AddValue(string name)
        {
            CheckName(name);
            list.Add(new ValueOfList(this, name));
            ChangedInvoke();
            return Get(name);
        }

        public ValueOfList AddValue(string name, FilesList files)
        {
            CheckName(name, files);
            return AddValue(name);
        }

        public ValueOfList AddValue()
        {
            while (true)
            {
                try
                {
                    string name = "Value-" + DateTime.Now.ToString();
                    return AddValue(name);
                }
                catch
                {

                }
            }
        }

        public ValueOfList AddValue(FilesList files)
        {
            while (true)
            {
                try
                {
                    string name = "Value-" + DateTime.Now.ToString();
                    return AddValue(name, files);
                }
                catch
                {

                }
            }
        }


        public void CheckName(string name)
        {
            if (ContainsValueView(name))
                throw new Exception("Значение с таким именем уже существует в файле");
            if (name == "")
                throw new Exception("Имя значения не может быть пустым");
        }

        public void CheckName(string name, FilesList files)
        {
            if (ContainsValueView(name, files))
                throw new Exception("Значение с таким именем уже существует в файле");
            if (name == "")
                throw new Exception("Имя значения не может быть пустым");
        }

        public bool ContainsValueView(string name) => Parent.ContainsValue(name);


        public bool ContainsValueView(string name, FilesList list)
            => list.ContainsValue(name);

        public ValueOfList GetValueView(string name, FilesList list)
            => list.GetValue(name);

        public void Delete(int index)
        {
            list.RemoveAt(index);
            ChangedInvoke();
        }

        public ValueOfList Rename(int index, string newName)
        {
            ValueOfList file = Get(index);
            if (file.Name == newName)
                return file;
            CheckName(newName);
            file.Name = newName;
            ChangedInvoke();
            return file;

        }

        public ValueOfList Rename(int index, string newName, FilesList files)
        {
            ValueOfList file = Get(index);
            if (file.Name == newName)
                return file;
            CheckName(newName);
            return Rename(index, newName);
        }

        public int IndexOf(string name) => values.FindIndex(x => x.Name == name);

        public int IndexOfFormat(string name)
        {
            int index = IndexOf(name);
            if (index < 0 || index >= Count)
            {
                throw new Exception("Значение с таким именем не найдено");
            }
            return IndexOf(name);
        }

        public int Count => values.Count;

        public ValuesFile File => Parent;

        public int GetIndexAtList(FilesList filesList) => File.GetIndexAtList(filesList);

    }

}
