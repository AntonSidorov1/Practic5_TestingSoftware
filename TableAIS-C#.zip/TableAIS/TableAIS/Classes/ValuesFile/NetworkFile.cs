﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class NetworkFile : ValuesFile
    {
        public NetworkFile(string address) : base()
        {
            this.Address = address;
        }

        public NetworkFile(FilesList parent, string address) : base(parent)
        {
            Address = address;
        }

        public NetworkFile(string name, string address) : base(name)
        {
            Address = address;
        }

        public NetworkFile(FilesList parent, string name, string address) : base(parent, name)
        {
            Address = address;
        }


        string ipAddress;

        public string IpAddress
        {
            get => ipAddress; set => ipAddress = value;
        }

        int port;

        public int Port
        {
            get => port; set => port = value;
        }

        public override string GetPath()
        {
            return Address;
        }

        public string Address
        {
            get => IpAddress + ":" + Port;
            set
            {
                string address = value;
                string[] parts = address.Split(':');
                IpAddress = parts[0];
                Port = Convert.ToInt32(parts[1]);
            }
        }

    }
}
