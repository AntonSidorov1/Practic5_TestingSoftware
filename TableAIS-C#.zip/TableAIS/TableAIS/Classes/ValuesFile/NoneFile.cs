﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class NoneFile : ValuesFile
    {
        public NoneFile()
        {
        }

        public NoneFile(string name) : base(name)
        {
        }

        public NoneFile(FilesList parent) : base(parent)
        {
        }

        public NoneFile(FilesList parent, string name) : base(parent, name)
        {
        }

        public override string GetPath()
        {
            return "";
        }

        public override string Input(ValueOfList valueOfList)
        {
            return valueOfList.Value;
        }

        public override void Output(ValueOfList value)
        {
            
        }
    }
}
