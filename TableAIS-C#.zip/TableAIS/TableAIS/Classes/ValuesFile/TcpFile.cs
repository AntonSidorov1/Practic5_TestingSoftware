﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public delegate void SavingTcpFile(TcpFile file, ValueOfList value, string jsonServerView, string serverAddress);

    public class TcpFile : NetworkFile
    {
        protected override void CreateSettings()
        {
            base.CreateSettings();
            IpAddress = "127.0.0.1";
            Port = 9000;
        }

        public TcpFile(string address) : base(address)
        {
            //Address = address;
        }

        public TcpFile(string name, string address) : base(name, address)
        {
            
        }

        public TcpFile(FilesList parent, string address) : base(parent, address)
        {
            //Address=address;
        }

        public TcpFile(FilesList parent, string name, string address) : base(parent, name, address)
        {
            //Address = address;
        }

        public override void Output(ValueOfList value)
        {
            SavingTcpFileInvoke(value);
        }

        public event SavingTcpFile SavingTcpFile;

        public void SavingTcpFileInvoke(ValueOfList valueOfList)
        {
            SavingTcpFile?.Invoke(this, valueOfList, valueOfList.ToClientJson(), Address);
        }

        public override string Input(ValueOfList valueOfList)
        {
            return valueOfList.Value;
        }
    }
}
