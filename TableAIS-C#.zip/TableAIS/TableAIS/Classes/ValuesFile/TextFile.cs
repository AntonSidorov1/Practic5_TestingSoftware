﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public class TextFile : FolderFile
    {
        public TextFile(FilesList parent, string name, string path) : base(parent, name, path)
        {
        }

        public override string LoadFile(ValueOfList value, string filePath)
        {
            return File.ReadAllText(filePath);
        }

        public override void SaveFile(ValueOfList value, string filePath)
        {
            File.WriteAllText(filePath, value.Value);

        }
    }
}
