﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public delegate void SavingUdpFile(UdpFile file, ValueOfList value, string jsonServerView, string serverAddress);
    public class UdpFile : NetworkFile
    {

        public event SavingUdpFile SavingUdpFile;

        public UdpFile(FilesList parent, string address) : base(parent, address)
        {
        }

        public UdpFile(FilesList parent, string name, string address) : base(parent, name, address)
        {
        }

        public override void Output(ValueOfList value)
        {
            SavingUdpFileInvoke(value);
        }

        protected override void CreateSettings()
        {
            base.CreateSettings();
            IpAddress = "127.0.0.1";
            Port = 9020;
        }

        public void SavingUdpFileInvoke(ValueOfList valueOfList)
        {
            SavingUdpFile?.Invoke(this, valueOfList, valueOfList.ToClientJson(), Address);
        }

        public override string Input(ValueOfList valueOfList)
        {
            return valueOfList.Value;
        }
    }
}
