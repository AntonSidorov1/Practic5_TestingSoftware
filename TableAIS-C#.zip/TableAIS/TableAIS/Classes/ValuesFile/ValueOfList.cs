﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using Newtonsoft.Json;
using System.Text.Json.Nodes;
using System.Runtime.CompilerServices;
using Windows.ApplicationModel.VoiceCommands;

namespace TableAIS
{
    public delegate void FromExcelChanged(ValueOfList value, ExcelFile excel);
    public delegate void BufferChanging(ValueOfList value);


    public delegate void ShowNotificationView(ValueOfList value, string message);


    public class ValueOfList : ListFile<ListFile>
    {
        public event ShowNotificationView ShowNotificationView;

        public void ShowNotificationViewInvoke(string message)
        {
            try
            {
                ShowNotificationView?.Invoke(this, message);
            }
            catch { }
        }


        public string InputText(ValuesFile file)
        {
            return file.Input(this);
        }

        public string InputText()
        {

            return InputText(File);

        }

        public string Input(ValuesFile file)
        {

            ValueFormat = InputText(file);
            return Value;

        }

        public string Input()
        {

            return Input(File);
        }

        public string NameFile
        {
            get => NameAtServer;
            set => NameAtServer = value;
        }

        public string TcpServerAddress => File.AsTCP().Address;

        public event ValueChanged Changed;

        public event BufferChanging ToBufferChanging;
        public event BufferChanging FromBufferChanging;

        public void ToBuffer()
        {
            ToBufferChanging?.Invoke(this);
        }

        public void FromBuffer()
        {
            FromBufferChanging?.Invoke(this);
        }

        public void ChangedInvoke()
        {
            Changed?.Invoke(this);
        }


        protected override void CreateSettings()
        {
            base.CreateSettings();
            ValueFormat = "";
            AutoSave = false;
            AutoWhrite = false;
            RowIndex = 1;
            ColumnIndex = 1;
            AddRowIndex = 0;
            AddColumnIndex = 0;
            ChangeRow = false;
            ChangeColumn = false;
            changePointList = new ChangePointList();
            ChangePointIndex = 0;
            NameAtServer = "name";
            CurrentCell = false;
            valuesThis = new List<string>();
            RunNotificationWrite = true;
            RunNotificationSave = true;
            AllowPutByNetwork = false;
            NetBuffer = "";
            FillNetBuffer = false;
            NecessarilyAuthorization = false;
            Password = "";
            ServerPassword = "";
        }

        public string ServerPassword;

        string netBuffer;

        bool fillNetBuffer;

        public bool FillNetBuffer
        {
            get => fillNetBuffer;
            set => fillNetBuffer = value;
        }

        /// <summary>
        /// Сетевой буфер значения
        /// </summary>
        public string NetBuffer
        {
            get => netBuffer; set => SetNetBuffer(value);
        }

        public void SetNetBuffer(string netBuffer)
        {
            FillNetBuffer = true;
            this.netBuffer = netBuffer;
        }

        public void LoadNetBuffer()
        {
            try
            {
                if (FillNetBuffer)
                    SetValue(NetBuffer);
            }
            catch { }
        }

        public void LoadNetBufferWithClear()
        {
            LoadNetBuffer();
            ClearNetBuffer();
        }

        public void ClearNetBuffer()
        {
            NetBuffer = "";
            FillNetBuffer = false;
        }

        //public override bool AllowLoadByNetwork => base.AllowLoadByNetwork && List.AllowLoadByNetwork;

        public ValueOfList(ListFile file) : base(file)
        {
        }

        public ValueOfList() : base(new ListFile(new NoneFile()))
        {
        }

        public ValueOfList(ListFile file, string name) : base(file, name)
        {
        }

        public bool NecessarilyAuthorization;
        public string Password;
        

        public override int Index => Parent.IndexOf(this);
        

        public int ListIndex => Parent.Index;

        string nameAtServer;

        public string NameAtServer
        {
            get => nameAtServer;
            set => nameAtServer = value;
        }



        public override void OutputValue()
        {
            Parent.Output(this);
        }

        bool autoSave;

        public bool AutoSave
        {
            get => autoSave;
            set => autoSave = value;
        }


        bool autoWrite;
        public bool AutoWhrite
        {
            get => autoWrite;
            set => autoWrite = value;
        }

        public void Save()
        {
            Output();
            if (NoCurrentCell && IsExcel())
                ChangeCell();

            if (RunNotificationSave)
            {
                ShowNotificationViewInvoke($"Текст значения с именем {Name} был сохранён \n Просмотреть изменения значения...");
            }

        }

        public ValuesFile File => Parent.Parent;
        public ListFile List => Parent;

        string valueText;

        public string Value
        {
            get => valueText;
            set => valueText = value.Replace(Environment.NewLine, "\n");
        }

        public string ValueFormat
        {
            get => Value.Replace("\n", Environment.NewLine);
            set => Value = value;
        }

        public string ValuePoint
        {
            get
            {
                string valueText = Value;
                ChangePoint change = ChangePointMethod();
                if (change == TableAIS.ChangePoint.Point)
                {
                    valueText = valueText.Replace(',', '.');
                }
                else
                if (change == TableAIS.ChangePoint.Virgule)
                {
                    valueText = valueText.Replace('.', ',');
                }
                return valueText;
            }
            set
            {
                Value = value;
            }
        }

        int rowIndex;
        public int RowIndex
        {
            get => rowIndex;
            set => rowIndex = value;
        }


        int columnIndex;
        public int ColumnIndex
        {
            get => columnIndex;
            set => columnIndex = value;
        }

        public string ValueWithSave
        {
            get => ValueFormat;
            set => SetValue(value, true);
        }

        public void SetValue(string value, bool save = true)
        {
            ValueFormat = value;
            ChangedInvoke();

            if(RunNotificationWrite && save)
            {
                ShowNotificationViewInvoke($"В значение с именем {Name} был записан текст \n Просмотреть изменения значения...");
            }

            if (autoSave && save)
            {
                Save();
                FromExcelChangedInvoke();
                
            }
           // Get();


        }


        bool runNotificationWrite, runNotificationSave;

        public bool RunNotificationWrite
        {
            get => runNotificationWrite; set => runNotificationWrite = value;
        }

        public bool RunNotificationSave
        {
            get => runNotificationSave; set => runNotificationSave = value;
        }

        public int GetIndexAtList(FilesList filesList) => File.GetIndexAtList(filesList);

        public event FromExcelChanged FromExcelChanged;

        public void FromExcelChangedInvoke()
        {
            if (File.IsExcel())
                FromExcelChanged?.Invoke(this, File.AsExcel());
        }

        public void SetCell(decimal row, decimal collumn)
        {
            RowIndex = Math.Max((int)row, 1);
            ColumnIndex = Math.Max((int)collumn, 1);
            FromExcelChangedInvoke();
        }

        public void ChangeCell()
        {
            AddRow();
            AddColumn();
        }

        public void SetRow(decimal row)
        {
            SetCell(row, ColumnIndex);
            
        }

        public void AddRow()
        {
            if (ChangeRow)
                SetRow(RowIndex + (ChangeRow ? AddRowIndex : 0));
        }

        public void AddColumn()
        {
            if (ChangeColumn)
                SetColumn(ColumnIndex + (ChangeColumn ? AddColumnIndex : 0));
        }

        public void SetColumn(decimal column)
        {
            SetCell(RowIndex, column);
        }

        public void Get()
        {
            FromExcelChangedInvoke();
        }

        public bool IsExcel() => File.IsExcel();

        public bool IsAtThis() => File.IsAtThis();

        public bool IsTCP() => File.IsTCP();

        public bool IsUDP() => File.IsUDP();

        public bool IsNetwork() => File.IsNetwork();
        public bool IsFolder() => File.IsFolder();
        public bool IsFileOrServer() => File.IsFileOrServer();

        public decimal AddRowIndex { get => addRow; set => addRow = value; }
        decimal addRow;

        public decimal AddColumnIndex { get => addColumn; set => addColumn = value; }
        decimal addColumn;

        bool changeRow;
        public bool ChangeRow
        {
            get => changeRow;
            set => changeRow = value;
        }

        bool changeColumn;

        public bool ChangeColumn
        {
            get => changeColumn;
            set => changeColumn = value;
        }

        ChangePointList changePointList;

        public ChangePointVisual[] ChangePointList() => changePointList.ToArray();

        int changePointIndex;

        public int ChangePointIndex
        {
            get => changePointIndex;
            set => changePointIndex = Math.Max(0, Math.Min(value, changePointList.LastIndex));
        }

        public ChangePointVisual ChangePoint() => changePointList.Get(ChangePointIndex);

        public ChangePoint ChangePointMethod() => ChangePoint().Method;


        public string ToJson()
        {

            JsonObject json = new JsonObject
            {
                { "name", Name },
                { "value", ValuePoint }
            };

            return json.ToString();
        }

        public string ToClientJson()
        {
            JsonObject json = (JsonObject)JsonNode.Parse(ToJson());
            JsonObject obj = new JsonObject
            {
                { "value", json },
                { "name", NameAtServer },
                {"password", ServerPassword }
            };
            return obj.ToString();
        }

        public void FromJson(string json)
        {
            JsonObject obj = (JsonObject)JsonNode.Parse(json);
            SetValue(obj["value"].ToString());
        }

        public string ValueOfSet
        {
            get => ValuePoint;
            set => SetValue(value);
        }


        bool currentCell;

        public bool CurrentCell
        {
            get => currentCell;
            set => currentCell = value;
        }

        public bool NoCurrentCell
        {
            get => !CurrentCell;
            set => CurrentCell = !value;
        }

        public void Transfer(FilesList filesList, string endValueName)
        {
            filesList.TransferValue(this, endValueName);
        }

        public void Transfer(string endValueName)
        {
            Transfer(FilesList, endValueName);
        }

        public FilesList FilesList => File.Parent;

        List<string> valuesThis;

        public bool ContainsValueThis(string name)
        {
            return valuesThis.Contains(name);
        }

        public string[] ValuesThis => valuesThis.ToArray();

        public void AddValueThis(string name)
        {
            if (!ContainsValueThis(name) && name.Trim() != "")
            {
                valuesThis.Add(name);
                ChangedInvoke();
            }
        }

        public void DeleteValueThis(int index)
        {
            valuesThis.RemoveAt(index);
            ChangedInvoke();
        }

        public void TransferThisAll()
        {
            FilesList filesList = FilesList;
            int length = ValuesThis.Length;
            for(int i = 0; i < length; i++)
            {
                Transfer(filesList, ValuesThis[i]);
            }
        }

        public int ValuesCount => valuesThis.Count;
        public int ValueLast  => ValuesCount - 1;

        public int IndexValue(string name)
        {
            return valuesThis.IndexOf(name);
        }

        public void TransferThisAll(FilesList filesList)
        {
            int errors = 0;
            int length = ValuesThis.Length;
            for (int i = 0; i < length; i++)
            {
                try
                {
                    Transfer(filesList, ValuesThis[i]);
                }
                catch
                {
                    errors++;
                }
            }
            if (errors >= length)
                throw new ArgumentException();
        }
    }

    /// <summary>
    /// Замена точки/запятой
    /// </summary>
    public enum ChangePoint
    {
        /// <summary>
        /// Нет
        /// </summary>
        None,
        /// <summary>
        /// Но точку
        /// </summary>
        Point,
        /// <summary>
        /// На запятую
        /// </summary>
        Virgule
    }


    /// <summary>
    /// Замена точки/запятой с текстовым отображением
    /// </summary>
    public class ChangePointVisual
    {
        

        /// <summary>
        /// Метод замены
        /// </summary>
        ChangePoint changePoint;


        /// <summary>
        /// Метод замены
        /// </summary>
        public ChangePoint ChangePoint
        {
            get => changePoint; set => changePoint = value;
        }

        /// <summary>
        /// Метод замены
        /// </summary>
        public ChangePoint Method
        {
            get => ChangePoint; set => ChangePoint = value;
        }

        /// <summary>
        /// Визуальное отображение замены
        /// </summary>
        string changePointText;

        /// <summary>
        /// Визуальное отображение замены
        /// </summary>
        public string ChangePointText
        {
            get => changePointText; set => changePointText = value;
        }

        public ChangePointVisual(ChangePoint changePoint, string changePointText)
        {
            ChangePoint = changePoint;
            ChangePointText = changePointText;
        }

        public ChangePointVisual() : this(ChangePoint.None, "Нет")
        {

        }

        public override string ToString()
        {
            return ChangePointText;
        }

    }

    /// <summary>
    /// Список методов замены точки на запятую
    /// </summary>
    public class ChangePointList
    {
        ChangePointVisual[] changePointVisual;

        public ChangePointVisual[] ToArray() => changePointVisual;


        public int Count => changePointVisual.Length;


        public int LastIndex => Count - 1;

        public ChangePointList()
        {
            List<ChangePointVisual> list = new List<ChangePointVisual>
            {
                new ChangePointVisual(),
                new ChangePointVisual(ChangePoint.Point, "На точку"),
                new ChangePointVisual(ChangePoint.Virgule, "На запятую")
            };
            changePointVisual = list.ToArray();
        }

        public ChangePointVisual Get(int index) => changePointVisual[index];

        


    }
}
