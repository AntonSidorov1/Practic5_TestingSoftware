﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public abstract class ValueOutput
    {
        public ValueOutput()
        {
            CreateSettings();
        }

        public ValueOutput(string name) : this()
        {
            Name = name;
        }


        protected virtual void CreateSettings()
        {
            Name = string.Empty;
        }

        string name = "";

        public string Name
        {
            get => name; set => name = value;
        }

        public override string ToString() => Name;

    }
}
