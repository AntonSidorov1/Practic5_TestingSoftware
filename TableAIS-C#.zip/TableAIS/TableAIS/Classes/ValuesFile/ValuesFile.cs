﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS
{
    public delegate void ValueChanged(ValueOfList valueOfList);
    public abstract class ValuesFile : FileOutput
    {
        public abstract string Input(ValueOfList valueOfList);

        public int GetIndexAtList(FilesList filesList) => filesList.IndexByName(this);
        public bool IsNone() => this is NoneFile;
        public bool IsExcel() => this is ExcelFile;
        public bool IsTCP() => this is TcpFile;
        public bool IsUDP() => this is UdpFile;
        public bool IsAtThis() => this is FileAtValueThis;

        public bool IsNetwork() => this is NetworkFile;

        public bool IsFolder() => this is FolderFile;

        public bool IsFileOrServer() => IsNetwork() || IsFolder();


        public NoneFile AsNone() => this as NoneFile;
        public ExcelFile AsExcel() => this as ExcelFile;
        public TcpFile AsTCP() => this as TcpFile;

        public ValuesFile() : base()
        {
        }

        public ValuesFile(FilesList parent) : this()
        {
            Parent = parent;
        }

        public ValuesFile(FilesList parent, string name) : this(name)
        {
            Parent = parent;
        }

        public ValuesFile(string name) : base(name)
        {
        }

        FilesList parent;

        public FilesList Parent
        {
            get => parent; set => parent = value;
        }

        protected override void CreateSettings()
        {
            base.CreateSettings();
            list = new List<ListFile>();
            Parent = new FilesList();
            AllowPutByNetwork = true;
        }

        

        List<ListFile> list;

        public ListFile Get(int index) => list[index];

        public ListFile Get(string name) => list.Find(x => x.Name.ToLower() == name.ToLower());


        public override void Output()
        {
            
        }

        public void OutputValue(ListFile list, int index)=>Output(list.Get(index));

        public abstract void Output (ValueOfList value);


        public int IndexOf(ListFile value) => list.IndexOf(value);

        public ValueOfList Get(int listIndex, int index) => Get(listIndex).Get(index);


        public ListFile[] ArrayList() => list.ToArray();

        public void ChangedInvoke()
        {
            Changed?.Invoke(GetObjects(), this);
        }

        public object[] GetObjects()
        {
            return ArrayList();
        }

        public event Changed1 Changed;

        public  ListFile AddList(string name)
        {
            CheckName(name);
            list.Add(new ListFile(this, name));
            ChangedInvoke();
            ListNameChanged("", name);
            return Get(name);
        }

        public bool Contains(string name) => list.Any(x => x.Name.ToLower() == name.ToLower());


        public void CheckName(string name)
        {
            if (Contains(name))
                throw new Exception("Лист с таким именем уже существует");
            if (name == "")
                throw new Exception("Имя листа не может быть пустым");
        }


        public ValueOfList GetValue(string name) => list.Find(x => x.ContainsValue(name)).GetValue(name);
        public bool ContainsValue(string name) => list.Any(x => x.ContainsValue(name));

        public bool ContainsValueView(string name, FilesList list)
            => list.ContainsValue(name);

        public ValueOfList GetValueView(string name, FilesList list)
            => list.GetValue(name);


        public virtual void Delete(int index)
        {
            string name = Get(index).Name;
            list.RemoveAt(index);
            ChangedInvoke();
            ListNameChanged(name, "");
        }

        protected virtual void ListNameChanged(string oldName, string newName)
        {

        }

        public abstract string GetPath();

        public FileOutput Rename(int index, string newName)
        {
            FileOutput file = Get(index);
            string oldName = file.Name;
            if (oldName == newName)
                return file;
            CheckName(newName);
            file.Name = newName;
            ChangedInvoke();
            ListNameChanged(oldName, newName);
            return file;

        }

        List<ListFile> values => list;

        public int IndexOf(string name) => values.FindIndex(x => x.Name == name);

        public int IndexOfFormat(string name)
        {
            int index = IndexOf(name);
            if (index < 0 || index >= Count)
            {
                throw new Exception("Лист с таким именем не найден");
            }
            return IndexOf(name);
        }

        public int Count => values.Count;

    }
}
