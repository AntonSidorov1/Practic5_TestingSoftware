﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAIS.Classes
{
    public class VolumeConverter : LengthBigConverter
    {
        public VolumeConverter() : base(3)
        {
            NameFirst = "Кубические метры";
            MetrsConvert metrsConvert = Add("Литры");
            MetrsConvert litr = metrsConvert;
            metrsConvert.ConvertFrom = (value) => value / 1000;
            metrsConvert.ConvertTo = (value) => value * 1000;

            metrsConvert = Add("Декалитры");
            metrsConvert.ConvertFrom = (value) => litr.From(value * 10);
            metrsConvert.ConvertTo = (value) => litr.To(value / 10);

            metrsConvert = Add("Гектолитры");
            metrsConvert.ConvertFrom = (value) => litr.From(value * 100);
            metrsConvert.ConvertTo = (value) => litr.To(value / 100);

            metrsConvert = Add("Килолитры");
            metrsConvert.ConvertFrom = (value) => litr.From(value * 1000);
            metrsConvert.ConvertTo = (value) => litr.To(value / 1000);

            metrsConvert = Add("Мегалитры");
            metrsConvert.ConvertFrom = (value) => litr.From(value * Math.Pow(10, 6));
            metrsConvert.ConvertTo = (value) => litr.To(value / Math.Pow(10, 6));

            metrsConvert = Add("Гигалитры");
            metrsConvert.ConvertFrom = (value) => litr.From(value * Math.Pow(10, 9));
            metrsConvert.ConvertTo = (value) => litr.To(value / Math.Pow(10, 9));

            metrsConvert = Add("Тералитры");
            metrsConvert.ConvertFrom = (value) => litr.From(value * Math.Pow(10, 12));
            metrsConvert.ConvertTo = (value) => litr.To(value / Math.Pow(10, 12));

            metrsConvert = Add("Децелитры");
            metrsConvert.ConvertTo = (value) => litr.To(value * 10);
            metrsConvert.ConvertFrom = (value) => litr.From(value / 10);

            metrsConvert = Add("Сантилитры");
            metrsConvert.ConvertTo = (value) => litr.To(value * 100);
            metrsConvert.ConvertFrom = (value) => litr.From(value / 100);

            metrsConvert = Add("Милилитры");
            metrsConvert.ConvertTo = (value) => litr.To(value * 1000);
            metrsConvert.ConvertFrom = (value) => litr.From(value / 1000);

            metrsConvert = Add("Микролитры");
            metrsConvert.ConvertTo = (value) => litr.To(value * Math.Pow(10, 6));
            metrsConvert.ConvertFrom = (value) => litr.From(value / Math.Pow(10, 6));

            metrsConvert = Add("Нанолитры");
            metrsConvert.ConvertTo = (value) => litr.To(value * Math.Pow(10, 9));
            metrsConvert.ConvertFrom = (value) => litr.From(value / Math.Pow(10, 9));

            metrsConvert = Add("Пиколитры");
            metrsConvert.ConvertTo = (value) => litr.To(value * Math.Pow(10, 12));
            metrsConvert.ConvertFrom = (value) => litr.From(value / Math.Pow(10, 12));

            metrsConvert = Add("Арк-футы");
            metrsConvert.ConvertFrom = (value) => value * 1233.501911927963488;
            metrsConvert.ConvertTo = (value) => value / 1233.501911927963488;

            metrsConvert = Add("Английские галлоны");
            metrsConvert.ConvertFrom = (value) => value * 0.0045466091880673;
            metrsConvert.ConvertTo = (value) => value / 0.0045466091880673;

            metrsConvert = Add("Галлоны США");
            metrsConvert.ConvertFrom = (value) => value * 0.0037854117834;
            metrsConvert.ConvertTo = (value) => value / 0.0037854117834;

            metrsConvert = Add("Английские жидкие унции");
            metrsConvert.ConvertFrom = (value) => value * (0.2841 / Math.Pow(10, 4));
            metrsConvert.ConvertTo = (value) => value / (0.2841 / Math.Pow(10, 4));

            metrsConvert = Add("Жидкие унции США");
            metrsConvert.ConvertFrom = (value) => value * (0.2927 / Math.Pow(10, 4));
            metrsConvert.ConvertTo = (value) => value / (0.2927 / Math.Pow(10, 4));

            metrsConvert = Add("Чайные ложки (Анг)");
            metrsConvert.ConvertFrom = (value) => value * (5.91938802083333333333/Math.Pow(10, 6));
            metrsConvert.ConvertTo = (value) => value / (5.91938802083333333333 / Math.Pow(10, 6));

            metrsConvert = Add("Столовые ложки (Анг)");
            metrsConvert.ConvertFrom = (value) => value * (1.77581640625 / Math.Pow(10, 5));
            metrsConvert.ConvertTo = (value) => value / (1.77581640625 / Math.Pow(10, 5));

            metrsConvert = Add("Чашки (Анг)");
            metrsConvert.ConvertFrom = (value) => value * (0.284130625 / Math.Pow(10, 3));
            metrsConvert.ConvertTo = (value) => value / (0.284130625 / Math.Pow(10, 3));

            metrsConvert = Add("Пинты (Анг)");
            metrsConvert.ConvertFrom = (value) => value * (0.56826125 / Math.Pow(10, 3));
            metrsConvert.ConvertTo = (value) => value / (0.56826125 / Math.Pow(10, 3));

            metrsConvert = Add("Кварты (Анг)");
            metrsConvert.ConvertFrom = (value) => value * (0.11365225 / Math.Pow(10, 2));
            metrsConvert.ConvertTo = (value) => value / (0.11365225 / Math.Pow(10, 2));


            metrsConvert = Add("Чайные ложки (США)");
            metrsConvert.ConvertFrom = (value) => value * (4.92892159375 / Math.Pow(10, 6));
            metrsConvert.ConvertTo = (value) => value / (4.92892159375 / Math.Pow(10, 6));

            metrsConvert = Add("Столовые ложки (США)");
            metrsConvert.ConvertFrom = (value) => value * (1.478676478125 / Math.Pow(10, 5));
            metrsConvert.ConvertTo = (value) => value / (1.478676478125 / Math.Pow(10, 5));

            metrsConvert = Add("Чашки (США)");
            metrsConvert.ConvertFrom = (value) => value * (0.2365882365 / Math.Pow(10, 3));
            metrsConvert.ConvertTo = (value) => value / (0.2365882365 / Math.Pow(10, 3));

            metrsConvert = Add("Пинты (США)");
            metrsConvert.ConvertFrom = (value) => value * (0.473176473 / Math.Pow(10, 3));
            metrsConvert.ConvertTo = (value) => value / (0.473176473 / Math.Pow(10, 3));

            metrsConvert = Add("Кварты (США)");
            metrsConvert.ConvertFrom = (value) => value * (0.946352946 / Math.Pow(10, 3));
            metrsConvert.ConvertTo = (value) => value / (0.946352946 / Math.Pow(10, 3));


            metrsConvert = Add("Баррели");
            metrsConvert.ConvertFrom = (value) => value * (0.158987294928);
            metrsConvert.ConvertTo = (value) => value / (0.158987294928);

        }
    }
}
