﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS
{
    public class ButtonClickView : Button
    {
        public ButtonClickView() : base()
        {
            Click += ButtonClickView_Click;
            
        }

        private void ButtonClickView_Click(object sender, EventArgs e)
        {
            RunClickView_Click(sender, e);
        }

        private void RunClickView_Click(object sender, EventArgs e)
        {
            Capture = false;
            ClickView?.Invoke(sender, e, this, Text);
        }



        public event ClickView ClickView;

        public void RunClickView()
        {
            RunClickView_Click(this, new EventArgs());
        }
        
    }

    public delegate void ClickView(object sender, EventArgs e, Control control, string text);
}
