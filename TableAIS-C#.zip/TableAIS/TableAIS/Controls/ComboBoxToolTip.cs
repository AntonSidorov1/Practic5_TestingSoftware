﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS.Controls
{
    public class ComboBoxToolTip : ComboBox
    {
        ToolTip output;
        public ComboBoxToolTip()
        {
            output = new ToolTip();
            TextChanged += ComboBoxToolTip_TextChanged;
            SelectedIndexChanged += ComboBoxToolTip_TextChanged;
            DropDownStyle = ComboBoxStyle.DropDownList;
            DropDownWidth = 200;
        }

        private void ComboBoxToolTip_TextChanged(object sender, EventArgs e)
        {
            output.SetToolTip(this, Text);
            MySeclectedIndexChanged?.Invoke(sender, new EventArgs(), this, SelectedIndex);
        }

        public event MySeclectedIndexChanged MySeclectedIndexChanged;
    }

    public delegate void MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex);
}
