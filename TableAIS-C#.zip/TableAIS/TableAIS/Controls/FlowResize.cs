﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS
{
    public class FlowResize : FlowLayoutPanel
    {
        public FlowResize() : base()
        {
            WrapContents = false;
            AutoScroll = true;
            FlowDirection = FlowDirection.TopDown;
            SizeChanged += FlowResize_SizeChanged;
            WithDelta = 35;
        }

        int withDelta;

        public int WithDelta
        {
            get => withDelta; set => withDelta = value;
        }

        private void FlowResize_SizeChanged(object sender, EventArgs e)
        {
            int width = Width - WithDelta;
            ControlCollection controls = Controls;
            int count = controls.Count;
            for(int i = 0; i < count; i++)
            {
                controls[i].Width = width;
            }
        }
    }
}
