﻿namespace TableAIS.Controls
{
    partial class MemoryCalculateControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelBorder = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonR = new System.Windows.Forms.Button();
            this.buttonPlus = new System.Windows.Forms.Button();
            this.buttonMemoryWrite = new System.Windows.Forms.Button();
            this.buttonMines = new System.Windows.Forms.Button();
            this.buttonHistory = new System.Windows.Forms.Button();
            this.buttonWriteAndClear = new System.Windows.Forms.Button();
            this.panelBorder.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBorder
            // 
            this.panelBorder.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelBorder.Controls.Add(this.tableLayoutPanel1);
            this.panelBorder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBorder.Location = new System.Drawing.Point(0, 0);
            this.panelBorder.Name = "panelBorder";
            this.panelBorder.Size = new System.Drawing.Size(263, 40);
            this.panelBorder.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.buttonR, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonPlus, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonMemoryWrite, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonMines, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonHistory, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonWriteAndClear, 4, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(259, 36);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // buttonR
            // 
            this.buttonR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonR.Location = new System.Drawing.Point(119, 0);
            this.buttonR.Margin = new System.Windows.Forms.Padding(0);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(38, 36);
            this.buttonR.TabIndex = 3;
            this.buttonR.Text = "MR";
            this.buttonR.UseVisualStyleBackColor = true;
            this.buttonR.Click += new System.EventHandler(this.buttonR_Click);
            // 
            // buttonPlus
            // 
            this.buttonPlus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPlus.Location = new System.Drawing.Point(81, 0);
            this.buttonPlus.Margin = new System.Windows.Forms.Padding(0);
            this.buttonPlus.Name = "buttonPlus";
            this.buttonPlus.Size = new System.Drawing.Size(38, 36);
            this.buttonPlus.TabIndex = 2;
            this.buttonPlus.Text = "M+";
            this.buttonPlus.UseVisualStyleBackColor = true;
            this.buttonPlus.Click += new System.EventHandler(this.buttonPlus_Click);
            // 
            // buttonMemoryWrite
            // 
            this.buttonMemoryWrite.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMemoryWrite.Location = new System.Drawing.Point(0, 0);
            this.buttonMemoryWrite.Margin = new System.Windows.Forms.Padding(0);
            this.buttonMemoryWrite.Name = "buttonMemoryWrite";
            this.buttonMemoryWrite.Size = new System.Drawing.Size(43, 36);
            this.buttonMemoryWrite.TabIndex = 0;
            this.buttonMemoryWrite.Text = "->M";
            this.buttonMemoryWrite.UseVisualStyleBackColor = true;
            this.buttonMemoryWrite.Click += new System.EventHandler(this.buttonMemoryWrite_Click);
            // 
            // buttonMines
            // 
            this.buttonMines.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMines.Location = new System.Drawing.Point(43, 0);
            this.buttonMines.Margin = new System.Windows.Forms.Padding(0);
            this.buttonMines.Name = "buttonMines";
            this.buttonMines.Size = new System.Drawing.Size(38, 36);
            this.buttonMines.TabIndex = 1;
            this.buttonMines.Text = "M-";
            this.buttonMines.UseVisualStyleBackColor = true;
            this.buttonMines.Click += new System.EventHandler(this.buttonMines_Click);
            // 
            // buttonHistory
            // 
            this.buttonHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonHistory.Location = new System.Drawing.Point(205, 0);
            this.buttonHistory.Margin = new System.Windows.Forms.Padding(0);
            this.buttonHistory.Name = "buttonHistory";
            this.buttonHistory.Size = new System.Drawing.Size(54, 36);
            this.buttonHistory.TabIndex = 4;
            this.buttonHistory.Text = "История";
            this.buttonHistory.UseVisualStyleBackColor = true;
            this.buttonHistory.Click += new System.EventHandler(this.buttonHistory_Click);
            // 
            // buttonWriteAndClear
            // 
            this.buttonWriteAndClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonWriteAndClear.Location = new System.Drawing.Point(157, 0);
            this.buttonWriteAndClear.Margin = new System.Windows.Forms.Padding(0);
            this.buttonWriteAndClear.Name = "buttonWriteAndClear";
            this.buttonWriteAndClear.Size = new System.Drawing.Size(48, 36);
            this.buttonWriteAndClear.TabIndex = 3;
            this.buttonWriteAndClear.Text = "MRC";
            this.buttonWriteAndClear.UseVisualStyleBackColor = true;
            this.buttonWriteAndClear.Click += new System.EventHandler(this.buttonWriteAndClear_Click);
            // 
            // MemoryCalculateControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelBorder);
            this.Name = "MemoryCalculateControl";
            this.Size = new System.Drawing.Size(263, 40);
            this.Load += new System.EventHandler(this.MemoryCalculateControl_Load);
            this.panelBorder.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelBorder;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button buttonMemoryWrite;
        private System.Windows.Forms.Button buttonMines;
        private System.Windows.Forms.Button buttonPlus;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.Button buttonHistory;
        private System.Windows.Forms.Button buttonWriteAndClear;
    }
}
