﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS.Controls
{
    public partial class MemoryCalculateControl : UserControl
    {
        public MemoryCalculateControl()
        {
            InitializeComponent();
            fewInvoke = false;
        }

        private void MemoryCalculateControl_Load(object sender, EventArgs e)
        {

        }

        public BorderStyle BorderStule
        {
            get => panelBorder.BorderStyle;
            set => panelBorder.BorderStyle = value;
        }

        public string WriteText
        {
            get => buttonMemoryWrite.Text;
            set => buttonMemoryWrite.Text = value;
        }

        public string MinesText
        {
            get => buttonMines.Text; set => buttonMines.Text = value;
        }

        public string PlusText
        {
            get => buttonPlus.Text; set => buttonPlus.Text = value;
        }

        public string RText
        {
            get => buttonR.Text; set => buttonR.Text = value;
        }

        public string Historytext
        {
            get => buttonHistory.Text; set => buttonHistory.Text = value;
        }

        public string WriteAndClearText
        {
            get => buttonWriteAndClear.Text;
            set => buttonWriteAndClear.Text = value;
        }

        private void buttonMemoryWrite_Click(object sender, EventArgs e)
        {
            try
            {
                WriteInvoke();
            }
            catch { }
        }

        public event Action Write, Plus, Mines, MR, History, WriteClear;

        public void PlusInvoke()
        {
            Plus?.Invoke();
            if(FewInvoke)
            {
                try
                {
                    Few.PlusInvoke();
                }
                catch
                {

                }
            }

        }

        public void WriteClearInvoke()
        {
            WriteClear?.Invoke();
            if (FewInvoke)
            {
                try
                {
                    Few.WriteClearInvoke();
                }
                catch
                {

                }
            }

        }

        public void MinesInvoke()
        {
            Mines?.Invoke();
            if (FewInvoke)
            {
                try
                {
                    Few.MinesInvoke();
                }
                catch
                {

                }
            }
        }

        public void WriteInvoke()
        {
            Write?.Invoke();
            if (FewInvoke)
            {
                try
                {
                    Few.WriteInvoke();
                }
                catch
                {

                }
            }
        }

        public void MRInvoke()
        {
            MR?.Invoke();
            if (FewInvoke)
            {
                try
                {
                    Few.MRInvoke();
                }
                catch
                {

                }
            }
        }

        public void HistoryInvoke()
        {
            History?.Invoke();
            if (FewInvoke)
            {
                try
                {
                    Few.HistoryInvoke();
                }
                catch
                {

                }
            }
        }

        private void buttonHistory_Click(object sender, EventArgs e)
        {
            try
            {
                HistoryInvoke();
            }
            catch { }
        }

        private void buttonR_Click(object sender, EventArgs e)
        {
            try
            {
                MRInvoke();
            }
            catch { }
        }

        private void buttonPlus_Click(object sender, EventArgs e)
        {
            try
            {
                PlusInvoke();
            }
            catch { }
        }

        private void buttonMines_Click(object sender, EventArgs e)
        {
            try
            {
                MinesInvoke();
            }
            catch { }
        }

        private void buttonWriteAndClear_Click(object sender, EventArgs e)
        {
            try
            {
                WriteClearInvoke();
            }
            catch { }
        }

        MemoryCalculateControl few;

        public MemoryCalculateControl Few
        {
            get { return few; }
            set { few = value; }
        }

        bool fewInvoke;

        public bool FewInvoke
        { get { return fewInvoke; }
        set { fewInvoke = value; } }
    }
}
