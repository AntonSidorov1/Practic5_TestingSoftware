﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS
{
    public class MyRadioButton : RadioButton
    {
        public MyRadioButton() : base()
        {
            CheckedChanged += MyRadioButton_CheckedChanged;
        }

        private void MyRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            OnChecked(e);
        }

        public void RetCheckedListener()
        {
            MyRadioButton_CheckedChanged(this, new EventArgs());
        }

         void OnChecked(EventArgs e)
        {
            OnChecked(e, Checked);
        }

         void OnChecked(EventArgs e, bool checkedFlag)
        {
            MyCheckedChanged(this, this, e, checkedFlag);
            if(checkedFlag)
            {
                SetChecked(this, this, e);
            }
            else
            {
                DropChecked(this, this, e);
            }
        }

        public event ControlChangeListener SetChecked, DropChecked;
        public event CheckedChangeListener MyCheckedChanged;
    }

    public delegate void ControlChangeListener(Control control, object sender, EventArgs e);

    public delegate void CheckedChangeListener(Control control, object sender, EventArgs e, bool checkedFlag);

}
