﻿namespace TableAIS
{
    partial class NumbericUser
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBoxTitle = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelView = new System.Windows.Forms.TableLayoutPanel();
            this.numericValue = new System.Windows.Forms.NumericUpDown();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonOK = new System.Windows.Forms.Button();
            this.timerClearVisible = new System.Windows.Forms.Timer(this.components);
            this.groupBoxTitle.SuspendLayout();
            this.tableLayoutPanelView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericValue)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxTitle
            // 
            this.groupBoxTitle.Controls.Add(this.tableLayoutPanelView);
            this.groupBoxTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxTitle.Location = new System.Drawing.Point(0, 0);
            this.groupBoxTitle.Name = "groupBoxTitle";
            this.groupBoxTitle.Size = new System.Drawing.Size(150, 82);
            this.groupBoxTitle.TabIndex = 0;
            this.groupBoxTitle.TabStop = false;
            this.groupBoxTitle.Text = "groupBox1";
            // 
            // tableLayoutPanelView
            // 
            this.tableLayoutPanelView.ColumnCount = 2;
            this.tableLayoutPanelView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanelView.Controls.Add(this.numericValue, 0, 0);
            this.tableLayoutPanelView.Controls.Add(this.buttonClear, 1, 0);
            this.tableLayoutPanelView.Controls.Add(this.buttonOK, 0, 1);
            this.tableLayoutPanelView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelView.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanelView.Name = "tableLayoutPanelView";
            this.tableLayoutPanelView.RowCount = 2;
            this.tableLayoutPanelView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanelView.Size = new System.Drawing.Size(144, 61);
            this.tableLayoutPanelView.TabIndex = 0;
            // 
            // numericValue
            // 
            this.numericValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericValue.Location = new System.Drawing.Point(3, 3);
            this.numericValue.Name = "numericValue";
            this.numericValue.Size = new System.Drawing.Size(88, 22);
            this.numericValue.TabIndex = 0;
            this.numericValue.ValueChanged += new System.EventHandler(this.numericValue_ValueChanged);
            // 
            // buttonClear
            // 
            this.buttonClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClear.Location = new System.Drawing.Point(97, 3);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(44, 26);
            this.buttonClear.TabIndex = 1;
            this.buttonClear.Text = "C";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.VisibleChanged += new System.EventHandler(this.buttonClear_VisibleChanged);
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonOK
            // 
            this.tableLayoutPanelView.SetColumnSpan(this.buttonOK, 2);
            this.buttonOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonOK.Location = new System.Drawing.Point(3, 35);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(138, 23);
            this.buttonOK.TabIndex = 2;
            this.buttonOK.Text = "ОК";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.button1_Click);
            // 
            // timerClearVisible
            // 
            this.timerClearVisible.Enabled = true;
            this.timerClearVisible.Tick += new System.EventHandler(this.timerClearVisible_Tick);
            // 
            // NumbericUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBoxTitle);
            this.Name = "NumbericUser";
            this.Size = new System.Drawing.Size(150, 82);
            this.Load += new System.EventHandler(this.NumbericUser_Load);
            this.groupBoxTitle.ResumeLayout(false);
            this.tableLayoutPanelView.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericValue)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxTitle;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelView;
        private System.Windows.Forms.NumericUpDown numericValue;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Timer timerClearVisible;
    }
}
