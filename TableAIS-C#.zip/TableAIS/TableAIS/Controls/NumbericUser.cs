﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS
{
    public partial class NumbericUser : UserControl
    {
        public NumbericUser()
        {
            InitializeComponent();
        }

        private void NumbericUser_Load(object sender, EventArgs e)
        {

        }

        public string Title
        {
            get => groupBoxTitle.Text;
            set => groupBoxTitle.Text = value;
        }

        private void numericValue_ValueChanged(object sender, EventArgs e)
        {
            ValueChanged?.Invoke(this, e, Value);
        }

        public decimal Value
        {
            get => numericValue.Value;
            set => numericValue.Value = value;
        }

        public decimal Macimum
        {
            get => numericValue.Maximum;
            set => numericValue.Maximum = value;
        }

        public decimal Minimum
        {
            get => numericValue.Minimum;
            set => numericValue.Minimum = value;
        }

        public decimal Maximum
        {
            get => Macimum;
            set => Macimum = value;
        }

        public decimal Increment
        {
            get => Incriment;
            set => Incriment = value;
        }

        public decimal Incriment
        {
            get => incriment;
            set => incriment = value;
        }

        public event ValueChangedControl ValueChanged;


        decimal defaultValue = 0;

        public decimal Default
        {
            get => defaultValue;
            set => defaultValue = value;
        }

        public decimal DefaultValue
        {
            get => Default;
            set => Default = value;
        }

        public void Clear()
        {
            decimal defaultV = Math.Min(Default, Maximum);
            defaultV = Math.Max(defaultV, Minimum);
            Value = defaultV;
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        public bool NoReadOnly
        {
            get => !ReadOnly;
            set => ReadOnly = !value;
        }

        public bool ReadOnly
        {
            get => numericValue.ReadOnly;
            set => numericValue.ReadOnly = value;
        }

        decimal incriment = 1;

        private void timerClearVisible_Tick(object sender, EventArgs e)
        {
            buttonClear.Visible = NoReadOnly;
            numericValue.Increment = NoReadOnly ? incriment : 0;
            tableLayoutPanelView.RowStyles[1].Height = VisibleOK ? 35 : 1;
        }

        public bool VisibleOK
        {
            get => buttonOK.Visible;
            set => buttonOK.Visible = value;
        }

        private void buttonClear_VisibleChanged(object sender, EventArgs e)
        {
            bool visible = (sender as Button).Visible;
            tableLayoutPanelView.ColumnStyles[1].Width = visible ? 50 : 1;

        }

        public decimal RealIncrement => numericValue.Increment;
        public decimal RealIncriment => RealIncrement;

        public void RunValueChange()
        {
            ValueChanged?.Invoke(this, new EventArgs(), Value);
        }
    }

    public delegate void ValueChangedControl(object sender, EventArgs e, decimal value);


}
