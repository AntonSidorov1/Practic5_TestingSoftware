﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS
{
    public class TextBoxWithLine : TextBox
    {
        public TextBoxWithLine() : base() 
        {
            TextChanged += TextBoxWithLine_TextChanged;
        }

        public event ValueLinesChanged ValueLinesChanged;

        private void TextBoxWithLine_TextChanged(object sender, EventArgs e)
        {
            try
            {
                ValueLinesChanged?.Invoke(sender, e, this, Text, TextWithLineBreaks);

            }
            catch { }
        }

        public string Value
        {
            get => Text.Replace(Environment.NewLine, "\n");
            set => Text = value.Replace("\n", Environment.NewLine);
        }

        public string TextWithLineBreaks
        {
            get => Value;
            set => Value = value;
        }
    }
    public delegate void ValueLinesChanged(object sender, EventArgs e, Control control, string text, string textWithLineBreaks);
}
