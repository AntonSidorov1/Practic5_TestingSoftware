﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS
{
    public partial class TextBoxWithTitle : UserControl
    {
        public TextBoxWithTitle()
        {
            InitializeComponent();
            ClearingByReadonly = false;
            ValueType = TextTitleType.Text;
            AllowNegative = true;
            EnterAllow = true;
        }

        public bool UseSystemPasswordChar
        {
            get => textBoxValue.UseSystemPasswordChar;
            set => textBoxValue.UseSystemPasswordChar = value;
        }

        TextTitleType valueType;
        bool allowNegative, enterAllow;

        public bool EnterAllow
        {
            get => enterAllow; set => enterAllow = value;
        }

        /// <summary>
        /// Позволять отрицательне числа (при ValueType != Text)
        /// </summary>
        public bool AllowNegative
        {
            get => allowNegative; set => allowNegative = value;
        }

        /// <summary>
        /// Тип ввода
        /// </summary>
        public TextTitleType ValueType
        {
            get => valueType; set => valueType = value;
        }

        public ScrollBars ScrollBars
        {
            get => textBoxValue.ScrollBars;
            set => textBoxValue.ScrollBars = value;
        }

        public bool MultiLine
        {
            get => textBoxValue.Multiline;
            set => textBoxValue.Multiline = value;
        }

        bool changed;
        private void TextBuffer_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void TextBoxWithTitle_Load(object sender, EventArgs e)
        {

        }

        public string Title
        {
            get => groupBoxTitle.Text;
            set => groupBoxTitle.Text = value;
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        public event TextValueChanged Cleared, EnterKeyDown, EnterKeyUp;

        public void Clear()
        {
            textBoxValue.Clear();
            try
            {
                Cleared?.Invoke(this, new EventArgs(), Value);
            }
            catch { }
        }

        public Color ValueBackColor
        {
            get => TextBoxValue.BackColor;
            set => TextBoxValue.BackColor = value;
        }

        public Color ValueForeColor
        {
            get => TextBoxValue.ForeColor; set => TextBoxValue.ForeColor = value;
        }

        public bool VisibleOK
        {
            get => buttonOK.Visible;
            set => buttonOK.Visible = value;
        }

        public string Value
        {
            get => textBoxValue.Text;
            set => textBoxValue.Text = value;
        }

        public string ValueText
        {
            get => ValueWithLineBreaks;
            set => ValueWithLineBreaks = value;
        }

        public string ValueWithLineBreaks
        {
            get => Value.Replace(Environment.NewLine, "\n");
            set => Value = value.Replace("\n", Environment.NewLine);
        }

        public string TextWithLineBreaks
        {
            get => ValueWithLineBreaks;
            set => ValueWithLineBreaks = value;
        }

        public bool ReadOnly
        {
            get => textBoxValue.ReadOnly;
            set => textBoxValue.ReadOnly = value;
        }

        bool clearingByReadOnly;

        /// <summary>
        /// Можно ли пользоваться кнопкой сброса, если ReadOnly=true
        /// </summary>
        public bool ClearingByReadonly
        {
            get => clearingByReadOnly;
            set => clearingByReadOnly = value;
        }

        public bool NoReadOnly
        {
            get => !ReadOnly;
            set => ReadOnly = !value;
        }

        /// <summary>
        /// Можно ли пользоваться кнопкой сброса
        /// </summary>
        public bool Clearing => NoReadOnly || ClearingByReadonly;

        private void buttonClear_VisibleChanged(object sender, EventArgs e)
        {
            tableLayoutPanel1.ColumnStyles[1].Width = (sender as Button).Visible? 50: 1;
        }

        string oldText;

        private void textBoxValue_TextChanged(object sender, EventArgs e)
        {
            ValueChanged?.Invoke(this, e, Value);
            if (Value.Length < 1)
            {
                oldText = "";
                return;
            }

            try
            {

                if(ValueType == TextTitleType.Char)
                {
                    if(Value.Length > 1)
                    {
                        Value = Value.Substring(Value.Length - 1);
                    }
                }

                if (ValueType == TextTitleType.Int || ValueType == TextTitleType.Double)
                {
                    if(Value == "-" && AllowNegative)
                    {
                        oldText = Value;
                        return;
                    }
                    if (ValueType == TextTitleType.Int)
                    {
                        int n = int.Parse(Value);
                        if (n < 0 && !AllowNegative)
                            throw new Exception();
                    }
                    if (ValueType == TextTitleType.Double)
                    {
                        double n = double.Parse(Value);
                        if (n < 0 && !AllowNegative)
                            throw new Exception();
                    }
                }

                

            }
            catch {
                try
                {
                    int length = oldText.Length;
                    Value = oldText;
                }
                catch {
                    Value = "";
                }
            }

            oldText = Value;

        }

        public event TextValueChanged ValueChanged;

        private void timerClearVisible_Tick(object sender, EventArgs e)
        {
            buttonClear.Visible = Clearing;
            tableLayoutPanel1.RowStyles[1].Height = VisibleOK ? 35 : 1;
        }

        private void timerBuffer_Tick(object sender, EventArgs e)
        {
            
        }

        public TextBox TextBoxValue => textBoxValue;

        public static implicit operator TextBox(TextBoxWithTitle textBox)
        {
            return textBox.TextBoxValue;
        }

        private void buttonOK_VisibleChanged(object sender, EventArgs e)
        {
            
        }

        public int SelectionStart
        {
            get => TextBoxValue.SelectionStart;
            set => TextBoxValue.SelectionStart = value;
        }

        public void RunKey(char key)
        {
            try
            {
                textBoxValue_KeyPress(this, new KeyPressEventArgs(key));
            }
            catch { }
        }

        private void textBoxValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            char sign = e.KeyChar;
            if(ValueType != TextTitleType.Text && sign == '-' && ValueType != TextTitleType.Char)
            {
                e.Handled = true;
                if (AllowNegative)
                {
                    if(Value.Length < 1)
                    {
                        e.Handled = false;

                        ValueKeyPress?.Invoke(this, e);
                        return;
                    }
                    if(Value == "-")
                    {
                        Value = "";
                    }
                    else if(ValueType == TextTitleType.Double) 
                    try
                    {
                        double num = MyCalculate.ToDouble(Value);
                        Value = (num * (-1)).ToString();
                    }
                    catch { }
                   else if (ValueType == TextTitleType.Int)
                        try
                        {
                            int num = int.Parse(Value);
                            Value = (num * (-1)).ToString();
                        }
                        catch { }
                    else if(ValueType == TextTitleType.Bynary)
                    {
                        if (Value[0] == '-')
                        {
                            Value = Value.Remove(0, 1);
                        }
                        else
                        {
                            Value = '-' + Value;
                        }
                    }
                }
                ValueKeyPress?.Invoke(this, e);
                return;
            }

            if(ValueType == TextTitleType.Char)
            {
                Value = "";
                ValueKeyPress?.Invoke(this, e);
                return;

            }

            if(sign == 8)
            {
                ValueKeyPress?.Invoke(this, e);
                return;
            }

            if (sign == 27)
            {
                ValueKeyPress?.Invoke(this, e);
                if (e.Handled == false)
                {
                    Value = "";
                }
                e.Handled = true;
                return;
            }

            if (ValueType == TextTitleType.Int)
            {
                if(!char.IsDigit(sign))
                {
                    e.Handled = true;
                }
            }
            else if(ValueType == TextTitleType.Double)
            {
                if(sign == '.')
                {
                    e.KeyChar = ',';
                }
                sign = e.KeyChar;
                if(sign == ',')
                {
                    if(SelectionStart == 1)
                    {
                        if (Value[0] == '-')
                        {
                            e.Handled = true;
                        }
                    }
                    if(Value.Contains(','))
                    {
                        e.Handled= true;
                    }
                    if(SelectionStart == 0)
                    {
                        ValueKeyPress?.Invoke(this, e);
                        if(e.Handled == false)
                        {
                            Value = "0," + Value;
                        }
                        e.Handled = true;
                        return;
                    }

                }
                else if(!char.IsDigit(sign))
                {
                    e.Handled = true;
                }
            }
            else if(ValueType == TextTitleType.Bynary)
            {
                if(sign != '0' && sign != '1')
                {
                    e.Handled = true;
                }
            }
            ValueKeyPress?.Invoke(this, e);


        }
         
        public event EventHandler<KeyPressEventArgs> ValueKeyPress;
        public event KeyEventHandler ValueKeyDown, ValueKeyUp;

        private void textBoxValue_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                ValueKeyUp?.Invoke(this, e);

                if (EnterAllow && e.KeyCode == Keys.Enter)
                {
                    try
                    {
                        EnterKeyDown?.Invoke(this, new EventArgs(), Value);
                    }
                    catch { }
                }
            }
            catch { }
        }

        private void textBoxValue_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                ValueKeyDown?.Invoke(this, e);

                if (EnterAllow && e.KeyCode == Keys.Enter)
                {
                    try
                    {
                        EnterKeyUp?.Invoke(this, new EventArgs(), Value);
                    }
                    catch { }
                }
            }
            catch { }
        }

        public void RunTextDouble(string text)
        {
            string fewText = Value.Replace(" ", "").Replace("\t", "") + text;
            if(MyCalculate.DoubleTryParse(fewText))
            {
                Value = (fewText);
            }
        }
    }

    public delegate void TextValueChanged(Control control, EventArgs e, string value);

   public enum TextTitleType
    {
        Text,
        Int,
        Double,
        Char,
        Bynary
    }

}
