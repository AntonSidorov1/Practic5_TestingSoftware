﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS.Controls
{
    /// <summary>
    /// Текст части формулы
    /// </summary>
    public class TextFormulePartControl : TextBoxWithLine
    {
        public TextFormulePartControl() : base()
        {
            KeyPress += TextFormulePartControl_KeyPress;
        }

        private void TextFormulePartControl_KeyPress(object sender, KeyPressEventArgs e)
        {
            string text = Value;
            string value = text;
            int start = SelectionStart;
            int length = text.Length;

            try
            {
                ThisKeyPress?.Invoke(this, text, start, ref text, e);
            }
            catch { }

            int backSpace = 8;
            int enter = 13;
            char key = e.KeyChar;
            if (key == backSpace && start == 0)
            {
                try
                {
                    BackSpaceStartKeyPress?.Invoke(this, text, start, ref text, e);
                }
                catch { }
            }
            if (key == enter)
            {
                try
                {
                    BackSpaceStartKeyPress?.Invoke(this, text, start, ref text, e);
                }
                catch { }
            }
            if (value != text)
            {
                Value = text;
                try
                {
                    start = Math.Min(start, text.Length);
                    SelectionStart = start;
                }
                catch { }
            }

        }

        public event TextFormuleKeyPress EnterKeyPressEnd, BackSpaceStartKeyPress, ThisKeyPress;
        
    }

    public delegate void TextFormuleKeyPress(Control control, string text, int selectionStart, ref string changeText, KeyPressEventArgs e);
}
