﻿using System.Collections.Generic;
using Excel = Microsoft.Office.Interop.Excel;

namespace TableAIS
{
    public static class ExcelPatern
    {
        public static Excel._Application ExcelApplication;
        public static List<Excel._Workbook> Workbooks;
        public static Excel._Worksheet Worksheet;
        public static Excel.Range Range;

        public static Excel._Application excelApp
        {
            get => ExcelApplication;
            set => ExcelApplication = value;
        }
    }
}
