﻿namespace TableAIS
{
    partial class BynaryWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BynaryWindow));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSaveBynary = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBinaryMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBinaryToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBynaryFromLast = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBynaryFromMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBynaryFromClipbord = new System.Windows.Forms.ToolStripMenuItem();
            this.flowResize4 = new TableAIS.FlowResize();
            this.checkBoxAllowNegative2 = new System.Windows.Forms.CheckBox();
            this.checkBoxAutoNum = new System.Windows.Forms.CheckBox();
            this.checkBoxEnterBynary = new System.Windows.Forms.CheckBox();
            this.textBoxNum = new TableAIS.TextBoxWithTitle();
            this.textBoxBynary = new TableAIS.TextBoxWithTitle();
            this.flowResize1 = new TableAIS.FlowResize();
            this.buttonToBynary = new System.Windows.Forms.Button();
            this.buttonFromBynary = new System.Windows.Forms.Button();
            this.flowResize2 = new TableAIS.FlowResize();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonNoneCode = new System.Windows.Forms.RadioButton();
            this.radioButtonDirectCode = new System.Windows.Forms.RadioButton();
            this.radioButtonRetCode = new System.Windows.Forms.RadioButton();
            this.radioButtonDopeCode = new System.Windows.Forms.RadioButton();
            this.checkBoxRunBynary = new System.Windows.Forms.CheckBox();
            this.flowResize3 = new TableAIS.FlowResize();
            this.checkBoxAllowNegative = new System.Windows.Forms.CheckBox();
            this.checkBoxAutoBynary = new System.Windows.Forms.CheckBox();
            this.checkBoxEnterNum = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.вывестиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSaveNum = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonNumMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonNumClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonNumFromLast = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonNumFromMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonNumFromClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.сКалькулятораToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromCalculatorA = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromCalculatorB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromCalculatorBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromCalculatorHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.вКалькуляторToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToCalculatorA = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToCalculatorB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToCalculatorBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToCalculatorHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.flowResize4.SuspendLayout();
            this.flowResize1.SuspendLayout();
            this.flowResize2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.flowResize3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(530, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(223, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(782, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(778, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(413, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Двоичное представление числа";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 504);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(782, 23);
            this.panel2.TabIndex = 9;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 89);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(782, 415);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel2);
            this.tabPage1.Location = new System.Drawing.Point(4, 30);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(774, 381);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Перевод в двоичное представление";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.97374F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.02626F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 240F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.flowResize4, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.textBoxNum, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.textBoxBynary, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.flowResize1, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.flowResize2, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.flowResize3, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 2, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(768, 375);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.menuStrip2, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(530, 128);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(235, 119);
            this.tableLayoutPanel5.TabIndex = 7;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem6});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(235, 29);
            this.menuStrip2.TabIndex = 0;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSaveBynary,
            this.buttonBinaryMain,
            this.buttonBinaryToClipboard});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(93, 25);
            this.toolStripMenuItem2.Text = "Вывести";
            // 
            // buttonSaveBynary
            // 
            this.buttonSaveBynary.Name = "buttonSaveBynary";
            this.buttonSaveBynary.Size = new System.Drawing.Size(287, 26);
            this.buttonSaveBynary.Text = "На предыдущий экран";
            this.buttonSaveBynary.Click += new System.EventHandler(this.buttonSaveBynary_Click);
            // 
            // buttonBinaryMain
            // 
            this.buttonBinaryMain.Name = "buttonBinaryMain";
            this.buttonBinaryMain.Size = new System.Drawing.Size(287, 26);
            this.buttonBinaryMain.Text = "На главный экран";
            this.buttonBinaryMain.Click += new System.EventHandler(this.buttonBinaryMain_Click);
            // 
            // buttonBinaryToClipboard
            // 
            this.buttonBinaryToClipboard.Name = "buttonBinaryToClipboard";
            this.buttonBinaryToClipboard.Size = new System.Drawing.Size(287, 26);
            this.buttonBinaryToClipboard.Text = "В буфер обмена";
            this.buttonBinaryToClipboard.Click += new System.EventHandler(this.buttonBinaryToClipboard_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonBynaryFromLast,
            this.buttonBynaryFromMain,
            this.buttonBynaryFromClipbord});
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(81, 25);
            this.toolStripMenuItem6.Text = "Ввести";
            // 
            // buttonBynaryFromLast
            // 
            this.buttonBynaryFromLast.Name = "buttonBynaryFromLast";
            this.buttonBynaryFromLast.Size = new System.Drawing.Size(293, 26);
            this.buttonBynaryFromLast.Text = "С предыдущего экрана";
            this.buttonBynaryFromLast.Click += new System.EventHandler(this.buttonBynaryFromLast_Click);
            // 
            // buttonBynaryFromMain
            // 
            this.buttonBynaryFromMain.Name = "buttonBynaryFromMain";
            this.buttonBynaryFromMain.Size = new System.Drawing.Size(293, 26);
            this.buttonBynaryFromMain.Text = "С главного экрана";
            this.buttonBynaryFromMain.Click += new System.EventHandler(this.buttonBynaryFromMain_Click);
            // 
            // buttonBynaryFromClipbord
            // 
            this.buttonBynaryFromClipbord.Name = "buttonBynaryFromClipbord";
            this.buttonBynaryFromClipbord.Size = new System.Drawing.Size(293, 26);
            this.buttonBynaryFromClipbord.Text = "Из буфера обмена";
            this.buttonBynaryFromClipbord.Click += new System.EventHandler(this.buttonBynaryFromClipbord_Click);
            // 
            // flowResize4
            // 
            this.flowResize4.AutoScroll = true;
            this.flowResize4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize4.Controls.Add(this.checkBoxAllowNegative2);
            this.flowResize4.Controls.Add(this.checkBoxAutoNum);
            this.flowResize4.Controls.Add(this.checkBoxEnterBynary);
            this.flowResize4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize4.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize4.Location = new System.Drawing.Point(309, 128);
            this.flowResize4.Name = "flowResize4";
            this.flowResize4.Size = new System.Drawing.Size(215, 119);
            this.flowResize4.TabIndex = 5;
            this.flowResize4.WithDelta = 35;
            this.flowResize4.WrapContents = false;
            // 
            // checkBoxAllowNegative2
            // 
            this.checkBoxAllowNegative2.Checked = true;
            this.checkBoxAllowNegative2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAllowNegative2.Location = new System.Drawing.Point(3, 3);
            this.checkBoxAllowNegative2.Name = "checkBoxAllowNegative2";
            this.checkBoxAllowNegative2.Size = new System.Drawing.Size(180, 68);
            this.checkBoxAllowNegative2.TabIndex = 1;
            this.checkBoxAllowNegative2.Text = "Разрешить отрицательные числа";
            this.checkBoxAllowNegative2.UseVisualStyleBackColor = true;
            this.checkBoxAllowNegative2.CheckedChanged += new System.EventHandler(this.checkBoxAllowNegative2_CheckedChanged);
            // 
            // checkBoxAutoNum
            // 
            this.checkBoxAutoNum.AutoSize = true;
            this.checkBoxAutoNum.Checked = true;
            this.checkBoxAutoNum.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAutoNum.Location = new System.Drawing.Point(3, 77);
            this.checkBoxAutoNum.Name = "checkBoxAutoNum";
            this.checkBoxAutoNum.Size = new System.Drawing.Size(145, 25);
            this.checkBoxAutoNum.TabIndex = 2;
            this.checkBoxAutoNum.Text = "Автоперевод";
            this.checkBoxAutoNum.UseVisualStyleBackColor = true;
            // 
            // checkBoxEnterBynary
            // 
            this.checkBoxEnterBynary.AutoSize = true;
            this.checkBoxEnterBynary.Checked = true;
            this.checkBoxEnterBynary.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxEnterBynary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxEnterBynary.Location = new System.Drawing.Point(3, 108);
            this.checkBoxEnterBynary.Name = "checkBoxEnterBynary";
            this.checkBoxEnterBynary.Size = new System.Drawing.Size(181, 25);
            this.checkBoxEnterBynary.TabIndex = 3;
            this.checkBoxEnterBynary.Text = "Перевод по Enter";
            this.checkBoxEnterBynary.UseVisualStyleBackColor = true;
            this.checkBoxEnterBynary.CheckedChanged += new System.EventHandler(this.checkBoxEnterBynary_CheckedChanged);
            // 
            // textBoxNum
            // 
            this.textBoxNum.AllowNegative = true;
            this.textBoxNum.ClearingByReadonly = false;
            this.textBoxNum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxNum.EnterAllow = true;
            this.textBoxNum.Location = new System.Drawing.Point(4, 4);
            this.textBoxNum.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNum.MultiLine = false;
            this.textBoxNum.Name = "textBoxNum";
            this.textBoxNum.NoReadOnly = true;
            this.textBoxNum.ReadOnly = false;
            this.textBoxNum.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxNum.SelectionStart = 0;
            this.textBoxNum.Size = new System.Drawing.Size(298, 117);
            this.textBoxNum.TabIndex = 0;
            this.textBoxNum.Title = "Исходное число";
            this.textBoxNum.Value = "";
            this.textBoxNum.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxNum.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxNum.ValueType = TableAIS.TextTitleType.Int;
            this.textBoxNum.VisibleOK = true;
            this.textBoxNum.EnterKeyDown += new TableAIS.TextValueChanged(this.textBoxNum_EnterKeyDown);
            this.textBoxNum.ValueChanged += new TableAIS.TextValueChanged(this.textBoxNum_ValueChanged);
            // 
            // textBoxBynary
            // 
            this.textBoxBynary.AllowNegative = true;
            this.textBoxBynary.ClearingByReadonly = false;
            this.textBoxBynary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxBynary.EnterAllow = true;
            this.textBoxBynary.Location = new System.Drawing.Point(4, 129);
            this.textBoxBynary.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxBynary.MultiLine = false;
            this.textBoxBynary.Name = "textBoxBynary";
            this.textBoxBynary.NoReadOnly = true;
            this.textBoxBynary.ReadOnly = false;
            this.textBoxBynary.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxBynary.SelectionStart = 0;
            this.textBoxBynary.Size = new System.Drawing.Size(298, 117);
            this.textBoxBynary.TabIndex = 1;
            this.textBoxBynary.Title = "Двоичное представление числа";
            this.textBoxBynary.Value = "";
            this.textBoxBynary.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxBynary.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxBynary.ValueType = TableAIS.TextTitleType.Bynary;
            this.textBoxBynary.VisibleOK = true;
            this.textBoxBynary.EnterKeyDown += new TableAIS.TextValueChanged(this.textBoxBynary_EnterKeyDown);
            this.textBoxBynary.ValueChanged += new TableAIS.TextValueChanged(this.textBoxBynary_ValueChanged);
            // 
            // flowResize1
            // 
            this.flowResize1.AutoScroll = true;
            this.flowResize1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize1.Controls.Add(this.buttonToBynary);
            this.flowResize1.Controls.Add(this.buttonFromBynary);
            this.flowResize1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize1.Location = new System.Drawing.Point(3, 253);
            this.flowResize1.Name = "flowResize1";
            this.flowResize1.Size = new System.Drawing.Size(300, 119);
            this.flowResize1.TabIndex = 2;
            this.flowResize1.WithDelta = 35;
            this.flowResize1.WrapContents = false;
            // 
            // buttonToBynary
            // 
            this.buttonToBynary.Location = new System.Drawing.Point(3, 3);
            this.buttonToBynary.Name = "buttonToBynary";
            this.buttonToBynary.Size = new System.Drawing.Size(265, 73);
            this.buttonToBynary.TabIndex = 0;
            this.buttonToBynary.Text = "Перевести число в двоичное представление";
            this.buttonToBynary.UseVisualStyleBackColor = true;
            this.buttonToBynary.Click += new System.EventHandler(this.buttonToBynary_Click);
            // 
            // buttonFromBynary
            // 
            this.buttonFromBynary.Location = new System.Drawing.Point(3, 82);
            this.buttonFromBynary.Name = "buttonFromBynary";
            this.buttonFromBynary.Size = new System.Drawing.Size(265, 77);
            this.buttonFromBynary.TabIndex = 1;
            this.buttonFromBynary.Text = "Перевести двоичное представление в число";
            this.buttonFromBynary.UseVisualStyleBackColor = true;
            this.buttonFromBynary.Click += new System.EventHandler(this.buttonFromBynary_Click);
            // 
            // flowResize2
            // 
            this.flowResize2.AutoScroll = true;
            this.flowResize2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize2.Controls.Add(this.groupBox1);
            this.flowResize2.Controls.Add(this.checkBoxRunBynary);
            this.flowResize2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize2.Location = new System.Drawing.Point(309, 253);
            this.flowResize2.Name = "flowResize2";
            this.flowResize2.Size = new System.Drawing.Size(215, 119);
            this.flowResize2.TabIndex = 3;
            this.flowResize2.WithDelta = 35;
            this.flowResize2.WrapContents = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel3);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(180, 200);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Вывод двоичного представления";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.radioButtonNoneCode, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.radioButtonDirectCode, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.radioButtonRetCode, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.radioButtonDopeCode, 0, 4);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 5;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.99813F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(174, 167);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // radioButtonNoneCode
            // 
            this.radioButtonNoneCode.AutoSize = true;
            this.radioButtonNoneCode.Checked = true;
            this.radioButtonNoneCode.Location = new System.Drawing.Point(3, 23);
            this.radioButtonNoneCode.Name = "radioButtonNoneCode";
            this.radioButtonNoneCode.Size = new System.Drawing.Size(145, 25);
            this.radioButtonNoneCode.TabIndex = 0;
            this.radioButtonNoneCode.TabStop = true;
            this.radioButtonNoneCode.Text = "Обычный код";
            this.radioButtonNoneCode.UseVisualStyleBackColor = true;
            this.radioButtonNoneCode.CheckedChanged += new System.EventHandler(this.radioButtonNoneCode_CheckedChanged);
            // 
            // radioButtonDirectCode
            // 
            this.radioButtonDirectCode.AutoSize = true;
            this.radioButtonDirectCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonDirectCode.Location = new System.Drawing.Point(3, 59);
            this.radioButtonDirectCode.Name = "radioButtonDirectCode";
            this.radioButtonDirectCode.Size = new System.Drawing.Size(168, 30);
            this.radioButtonDirectCode.TabIndex = 1;
            this.radioButtonDirectCode.TabStop = true;
            this.radioButtonDirectCode.Text = "Прямой код";
            this.radioButtonDirectCode.UseVisualStyleBackColor = true;
            this.radioButtonDirectCode.CheckedChanged += new System.EventHandler(this.radioButtonNoneCode_CheckedChanged);
            // 
            // radioButtonRetCode
            // 
            this.radioButtonRetCode.AutoSize = true;
            this.radioButtonRetCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonRetCode.Location = new System.Drawing.Point(3, 95);
            this.radioButtonRetCode.Name = "radioButtonRetCode";
            this.radioButtonRetCode.Size = new System.Drawing.Size(168, 30);
            this.radioButtonRetCode.TabIndex = 2;
            this.radioButtonRetCode.TabStop = true;
            this.radioButtonRetCode.Text = "Обратный код";
            this.radioButtonRetCode.UseVisualStyleBackColor = true;
            this.radioButtonRetCode.Click += new System.EventHandler(this.radioButtonNoneCode_CheckedChanged);
            // 
            // radioButtonDopeCode
            // 
            this.radioButtonDopeCode.AutoSize = true;
            this.radioButtonDopeCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonDopeCode.Location = new System.Drawing.Point(3, 131);
            this.radioButtonDopeCode.Name = "radioButtonDopeCode";
            this.radioButtonDopeCode.Size = new System.Drawing.Size(168, 33);
            this.radioButtonDopeCode.TabIndex = 3;
            this.radioButtonDopeCode.TabStop = true;
            this.radioButtonDopeCode.Text = "Дополнительный код";
            this.radioButtonDopeCode.UseVisualStyleBackColor = true;
            this.radioButtonDopeCode.CheckedChanged += new System.EventHandler(this.radioButtonNoneCode_CheckedChanged);
            // 
            // checkBoxRunBynary
            // 
            this.checkBoxRunBynary.Location = new System.Drawing.Point(3, 209);
            this.checkBoxRunBynary.Name = "checkBoxRunBynary";
            this.checkBoxRunBynary.Size = new System.Drawing.Size(180, 53);
            this.checkBoxRunBynary.TabIndex = 1;
            this.checkBoxRunBynary.Text = "Дополнять до 32-х разрядов";
            this.checkBoxRunBynary.UseVisualStyleBackColor = true;
            this.checkBoxRunBynary.CheckedChanged += new System.EventHandler(this.radioButtonNoneCode_CheckedChanged);
            // 
            // flowResize3
            // 
            this.flowResize3.AutoScroll = true;
            this.flowResize3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize3.Controls.Add(this.checkBoxAllowNegative);
            this.flowResize3.Controls.Add(this.checkBoxAutoBynary);
            this.flowResize3.Controls.Add(this.checkBoxEnterNum);
            this.flowResize3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize3.Location = new System.Drawing.Point(309, 3);
            this.flowResize3.Name = "flowResize3";
            this.flowResize3.Size = new System.Drawing.Size(215, 119);
            this.flowResize3.TabIndex = 4;
            this.flowResize3.WithDelta = 35;
            this.flowResize3.WrapContents = false;
            // 
            // checkBoxAllowNegative
            // 
            this.checkBoxAllowNegative.Checked = true;
            this.checkBoxAllowNegative.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAllowNegative.Location = new System.Drawing.Point(3, 3);
            this.checkBoxAllowNegative.Name = "checkBoxAllowNegative";
            this.checkBoxAllowNegative.Size = new System.Drawing.Size(180, 68);
            this.checkBoxAllowNegative.TabIndex = 0;
            this.checkBoxAllowNegative.Text = "Разрешить отрицательные числа";
            this.checkBoxAllowNegative.UseVisualStyleBackColor = true;
            this.checkBoxAllowNegative.CheckedChanged += new System.EventHandler(this.checkBoxAllowNegative_CheckedChanged);
            // 
            // checkBoxAutoBynary
            // 
            this.checkBoxAutoBynary.AutoSize = true;
            this.checkBoxAutoBynary.Checked = true;
            this.checkBoxAutoBynary.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAutoBynary.Location = new System.Drawing.Point(3, 77);
            this.checkBoxAutoBynary.Name = "checkBoxAutoBynary";
            this.checkBoxAutoBynary.Size = new System.Drawing.Size(145, 25);
            this.checkBoxAutoBynary.TabIndex = 1;
            this.checkBoxAutoBynary.Text = "Автоперевод";
            this.checkBoxAutoBynary.UseVisualStyleBackColor = true;
            // 
            // checkBoxEnterNum
            // 
            this.checkBoxEnterNum.AutoSize = true;
            this.checkBoxEnterNum.Checked = true;
            this.checkBoxEnterNum.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxEnterNum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxEnterNum.Location = new System.Drawing.Point(3, 108);
            this.checkBoxEnterNum.Name = "checkBoxEnterNum";
            this.checkBoxEnterNum.Size = new System.Drawing.Size(181, 25);
            this.checkBoxEnterNum.TabIndex = 2;
            this.checkBoxEnterNum.Text = "Перевод по Enter";
            this.checkBoxEnterNum.UseVisualStyleBackColor = true;
            this.checkBoxEnterNum.CheckedChanged += new System.EventHandler(this.checkBoxEnterNum_CheckedChanged);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(530, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(235, 119);
            this.tableLayoutPanel4.TabIndex = 6;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вывестиToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(235, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // вывестиToolStripMenuItem
            // 
            this.вывестиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSaveNum,
            this.buttonNumMain,
            this.buttonNumClipboard,
            this.вКалькуляторToolStripMenuItem});
            this.вывестиToolStripMenuItem.Name = "вывестиToolStripMenuItem";
            this.вывестиToolStripMenuItem.Size = new System.Drawing.Size(93, 25);
            this.вывестиToolStripMenuItem.Text = "Вывести";
            // 
            // buttonSaveNum
            // 
            this.buttonSaveNum.Name = "buttonSaveNum";
            this.buttonSaveNum.Size = new System.Drawing.Size(287, 26);
            this.buttonSaveNum.Text = "На предыдущий экран";
            this.buttonSaveNum.Click += new System.EventHandler(this.buttonSaveNum_Click);
            // 
            // buttonNumMain
            // 
            this.buttonNumMain.Name = "buttonNumMain";
            this.buttonNumMain.Size = new System.Drawing.Size(287, 26);
            this.buttonNumMain.Text = "На главный экран";
            this.buttonNumMain.Click += new System.EventHandler(this.buttonNumMain_Click);
            // 
            // buttonNumClipboard
            // 
            this.buttonNumClipboard.Name = "buttonNumClipboard";
            this.buttonNumClipboard.Size = new System.Drawing.Size(287, 26);
            this.buttonNumClipboard.Text = "В буфер обмена";
            this.buttonNumClipboard.Click += new System.EventHandler(this.buttonNumClipboard_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonNumFromLast,
            this.buttonNumFromMain,
            this.buttonNumFromClipboard,
            this.сКалькулятораToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(81, 25);
            this.toolStripMenuItem1.Text = "Ввести";
            // 
            // buttonNumFromLast
            // 
            this.buttonNumFromLast.Name = "buttonNumFromLast";
            this.buttonNumFromLast.Size = new System.Drawing.Size(293, 26);
            this.buttonNumFromLast.Text = "С предыдущего экрана";
            this.buttonNumFromLast.Click += new System.EventHandler(this.buttonNumFromLast_Click);
            // 
            // buttonNumFromMain
            // 
            this.buttonNumFromMain.Name = "buttonNumFromMain";
            this.buttonNumFromMain.Size = new System.Drawing.Size(293, 26);
            this.buttonNumFromMain.Text = "С главного экрана";
            this.buttonNumFromMain.Click += new System.EventHandler(this.buttonNumFromMain_Click);
            // 
            // buttonNumFromClipboard
            // 
            this.buttonNumFromClipboard.Name = "buttonNumFromClipboard";
            this.buttonNumFromClipboard.Size = new System.Drawing.Size(293, 26);
            this.buttonNumFromClipboard.Text = "Из буфера обмена";
            this.buttonNumFromClipboard.Click += new System.EventHandler(this.buttonNumFromClipboard_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 30);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(774, 381);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Данные в калькуляторе";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // сКалькулятораToolStripMenuItem
            // 
            this.сКалькулятораToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonFromCalculatorA,
            this.buttonFromCalculatorB,
            this.buttonFromCalculatorBuffer,
            this.buttonFromCalculatorHelp});
            this.сКалькулятораToolStripMenuItem.Name = "сКалькулятораToolStripMenuItem";
            this.сКалькулятораToolStripMenuItem.Size = new System.Drawing.Size(293, 26);
            this.сКалькулятораToolStripMenuItem.Text = "С калькулятора";
            // 
            // buttonFromCalculatorA
            // 
            this.buttonFromCalculatorA.Name = "buttonFromCalculatorA";
            this.buttonFromCalculatorA.Size = new System.Drawing.Size(224, 26);
            this.buttonFromCalculatorA.Text = "A";
            this.buttonFromCalculatorA.Click += new System.EventHandler(this.buttonFromCalculatorA_Click);
            // 
            // buttonFromCalculatorB
            // 
            this.buttonFromCalculatorB.Name = "buttonFromCalculatorB";
            this.buttonFromCalculatorB.Size = new System.Drawing.Size(224, 26);
            this.buttonFromCalculatorB.Text = "B";
            this.buttonFromCalculatorB.Click += new System.EventHandler(this.buttonFromCalculatorB_Click);
            // 
            // buttonFromCalculatorBuffer
            // 
            this.buttonFromCalculatorBuffer.Name = "buttonFromCalculatorBuffer";
            this.buttonFromCalculatorBuffer.Size = new System.Drawing.Size(224, 26);
            this.buttonFromCalculatorBuffer.Text = "Buffer";
            this.buttonFromCalculatorBuffer.Click += new System.EventHandler(this.buttonFromCalculatorBuffer_Click);
            // 
            // buttonFromCalculatorHelp
            // 
            this.buttonFromCalculatorHelp.Name = "buttonFromCalculatorHelp";
            this.buttonFromCalculatorHelp.Size = new System.Drawing.Size(224, 26);
            this.buttonFromCalculatorHelp.Text = "Help";
            this.buttonFromCalculatorHelp.Click += new System.EventHandler(this.buttonFromCalculatorHelp_Click);
            // 
            // вКалькуляторToolStripMenuItem
            // 
            this.вКалькуляторToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToCalculatorA,
            this.buttonToCalculatorB,
            this.buttonToCalculatorBuffer,
            this.buttonToCalculatorHelp});
            this.вКалькуляторToolStripMenuItem.Name = "вКалькуляторToolStripMenuItem";
            this.вКалькуляторToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.вКалькуляторToolStripMenuItem.Text = "В калькулятор";
            // 
            // buttonToCalculatorA
            // 
            this.buttonToCalculatorA.Name = "buttonToCalculatorA";
            this.buttonToCalculatorA.Size = new System.Drawing.Size(224, 26);
            this.buttonToCalculatorA.Text = "A";
            this.buttonToCalculatorA.Click += new System.EventHandler(this.buttonToCalculatorA_Click);
            // 
            // buttonToCalculatorB
            // 
            this.buttonToCalculatorB.Name = "buttonToCalculatorB";
            this.buttonToCalculatorB.Size = new System.Drawing.Size(224, 26);
            this.buttonToCalculatorB.Text = "B";
            this.buttonToCalculatorB.Click += new System.EventHandler(this.buttonToCalculatorB_Click);
            // 
            // buttonToCalculatorBuffer
            // 
            this.buttonToCalculatorBuffer.Name = "buttonToCalculatorBuffer";
            this.buttonToCalculatorBuffer.Size = new System.Drawing.Size(224, 26);
            this.buttonToCalculatorBuffer.Text = "Buffer";
            this.buttonToCalculatorBuffer.Click += new System.EventHandler(this.buttonToCalculatorBuffer_Click);
            // 
            // buttonToCalculatorHelp
            // 
            this.buttonToCalculatorHelp.Name = "buttonToCalculatorHelp";
            this.buttonToCalculatorHelp.Size = new System.Drawing.Size(224, 26);
            this.buttonToCalculatorHelp.Text = "Help";
            this.buttonToCalculatorHelp.Click += new System.EventHandler(this.buttonToCalculatorHelp_Click);
            // 
            // BynaryWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(782, 553);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "BynaryWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Двоичное представление числа";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.flowResize4.ResumeLayout(false);
            this.flowResize4.PerformLayout();
            this.flowResize1.ResumeLayout(false);
            this.flowResize2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.flowResize3.ResumeLayout(false);
            this.flowResize3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private TextBoxWithTitle textBoxNum;
        private TextBoxWithTitle textBoxBynary;
        private FlowResize flowResize1;
        private System.Windows.Forms.Button buttonToBynary;
        private System.Windows.Forms.Button buttonFromBynary;
        private FlowResize flowResize2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.RadioButton radioButtonNoneCode;
        private System.Windows.Forms.RadioButton radioButtonDirectCode;
        private System.Windows.Forms.RadioButton radioButtonRetCode;
        private System.Windows.Forms.RadioButton radioButtonDopeCode;
        private System.Windows.Forms.CheckBox checkBoxRunBynary;
        private FlowResize flowResize3;
        private FlowResize flowResize4;
        private System.Windows.Forms.CheckBox checkBoxAllowNegative;
        private System.Windows.Forms.CheckBox checkBoxAllowNegative2;
        private System.Windows.Forms.CheckBox checkBoxAutoBynary;
        private System.Windows.Forms.CheckBox checkBoxAutoNum;
        private System.Windows.Forms.CheckBox checkBoxEnterNum;
        private System.Windows.Forms.CheckBox checkBoxEnterBynary;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem вывестиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSaveNum;
        private System.Windows.Forms.ToolStripMenuItem buttonNumMain;
        private System.Windows.Forms.ToolStripMenuItem buttonNumClipboard;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem buttonSaveBynary;
        private System.Windows.Forms.ToolStripMenuItem buttonBinaryMain;
        private System.Windows.Forms.ToolStripMenuItem buttonBinaryToClipboard;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem buttonBynaryFromLast;
        private System.Windows.Forms.ToolStripMenuItem buttonBynaryFromMain;
        private System.Windows.Forms.ToolStripMenuItem buttonBynaryFromClipbord;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonNumFromLast;
        private System.Windows.Forms.ToolStripMenuItem buttonNumFromMain;
        private System.Windows.Forms.ToolStripMenuItem buttonNumFromClipboard;
        private System.Windows.Forms.ToolStripMenuItem сКалькулятораToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonFromCalculatorA;
        private System.Windows.Forms.ToolStripMenuItem buttonFromCalculatorB;
        private System.Windows.Forms.ToolStripMenuItem buttonFromCalculatorBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonFromCalculatorHelp;
        private System.Windows.Forms.ToolStripMenuItem вКалькуляторToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToCalculatorA;
        private System.Windows.Forms.ToolStripMenuItem buttonToCalculatorB;
        private System.Windows.Forms.ToolStripMenuItem buttonToCalculatorBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonToCalculatorHelp;
    }
}