﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class BynaryWindow : Form
    {

       


        public event Func<string> SetFromMain;
        public event Func<double> GetA, GetB, GetBuffer, GetHelp;
        public event Action<double> SetA, SetB, SetBuffer, SetHelp;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public event Func<string> SetNumberFromMain;

        public string SetNumberFromMainInvoke()
        {
            return SetNumberFromMain?.Invoke()??"";
        }


        public BynaryWindow()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public BynaryWindow(Save save):this()
        {
            Save = save;
        }

        public BynaryWindow(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void buttonToBynary_Click(object sender, EventArgs e)
        {
            try
            {
                string bynary = "";
                int number = int.Parse(textBoxNum.Value);


                bynary = !radioButtonDopeCode.Checked ? BynaryCode.BynaryInt(Math.Abs(number)) : BynaryCode.DopeCode(number);

                if (checkBoxRunBynary.Checked)
                {
                    while (bynary.Length < 32)
                    {
                        bynary = "0" + bynary;
                    }
                }

                if (number < 0)
                {
                    if (radioButtonNoneCode.Checked)
                    {
                        bynary = "-" + bynary;
                    }
                    else if (radioButtonDirectCode.Checked)
                    {
                        while (bynary.Length < 31)
                        {
                            bynary = "0" + bynary;
                        }
                        if (bynary.Length < 32)
                            bynary = "1" + bynary;
                        else
                        {
                            bynary = "1" + bynary.Remove(0, 1);
                        }
                    }
                    else if (radioButtonRetCode.Checked)
                    {
                        while (bynary.Length < 32)
                        {
                            bynary = "0" + bynary;
                        }
                        bynary = BynaryCode.Invert(bynary);
                    }
                    else
                    {

                    }
                }

                copyBynary = false;
                if (textBoxBynary.Value != bynary)
                    textBoxBynary.Value = bynary;
                copyBynary = true;
            }
            catch (Exception ex)
            {

            }
        }

        bool copyBynary = true;

        private void buttonFromBynary_Click(object sender, EventArgs e)
        {
            try
            {
                string bynary = textBoxBynary.Value;

                int number = 0;
                if(radioButtonDirectCode.Checked)
                {
                    number = BynaryCode.IntByDirectCode(bynary);
                }
                else if(radioButtonRetCode.Checked)
                {
                    number = BynaryCode.IntByRetCode(bynary);
                }
                else if (radioButtonDopeCode.Checked)
                {
                    number = BynaryCode.IntByDopeCode(bynary);
                }
                else
                {
                    number = BynaryCode.IntByNoneCode(bynary);
                }

                /*
                char first = bynary[0];
                bool negative = false;
                if(first == '-')
                {
                    negative = true;
                    bynary = bynary.Remove(0, 1);
                }
                int number = BynaryCode.BynaryInt(bynary);
                if (negative)
                    number *= -1;
                */
                string num = number.ToString();
                if(copyBynary)
                    textBoxNum.Value = num;
            }
            catch { }
        }

        private void checkBoxAllowNegative_CheckedChanged(object sender, EventArgs e)
        {
            bool allowNegative = checkBoxAllowNegative.Checked;
            textBoxNum.AllowNegative = allowNegative;
            textBoxBynary.AllowNegative = allowNegative;
            checkBoxAllowNegative2.Checked = allowNegative;
            if(!allowNegative)
            {
                textBoxNum.Value = textBoxNum.Value.Replace("-", "");
                textBoxBynary.Value = textBoxBynary.Value.Replace("-", "");
            }
        }

        private void checkBoxAllowNegative2_CheckedChanged(object sender, EventArgs e)
        {
            bool allowNegative = checkBoxAllowNegative2.Checked;
            checkBoxAllowNegative.Checked = allowNegative;
        }

        private void textBoxNum_ValueChanged(Control control, EventArgs e, string value)
        {
            if(checkBoxAutoBynary.Checked)
            {
                buttonToBynary_Click(buttonToBynary, e);
            }
        }

        private void radioButtonNoneCode_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxAutoBynary.Checked)
            {
                buttonToBynary_Click(buttonToBynary, e);
            }
        }

        private void textBoxBynary_ValueChanged(Control control, EventArgs e, string value)
        {
            if (checkBoxAutoNum.Checked)
            {
                buttonFromBynary_Click(buttonFromBynary, e);
            }
        }

        private void textBoxNum_EnterKeyDown(Control control, EventArgs e, string value)
        {
            buttonToBynary_Click(buttonToBynary, e);
        }

        private void checkBoxEnterNum_CheckedChanged(object sender, EventArgs e)
        {
            textBoxNum.EnterAllow = checkBoxEnterNum.Checked;
        }

        private void checkBoxEnterBynary_CheckedChanged(object sender, EventArgs e)
        {
            textBoxBynary.EnterAllow = checkBoxEnterNum.Checked;
        }

        private void textBoxBynary_EnterKeyDown(Control control, EventArgs e, string value)
        {
            buttonFromBynary_Click(buttonToBynary, e);
        }

        private void buttonSaveNum_Click(object sender, EventArgs e)
        {
            SaveV(textBoxNum.Value);
        }


        public void SaveV(string text)
        {
            try
            {
                MetrOutput1?.Invoke(text, Save);
            }
            catch
            {

            }
        }

        public void WriteMain(string text)
        {
            try
            {
                ValueHelper.SetText(text);
            }
            catch { }
        }

        private void buttonSaveBynary_Click(object sender, EventArgs e)
        {
            SaveV(textBoxBynary.Value);
        }

        private void buttonNumMain_Click(object sender, EventArgs e)
        {
            WriteMain(textBoxNum.Value);
        }

        private void buttonBinaryMain_Click(object sender, EventArgs e)
        {
            WriteMain(textBoxBynary.Value);
        }

        void WriteToClipboard(string text)
        {
            try
            {
                Clipboard.SetText(text);
            }
            catch { }
        }

        private void buttonNumClipboard_Click(object sender, EventArgs e)
        {
            WriteToClipboard(textBoxNum.Value);
        }

        private void buttonBinaryToClipboard_Click(object sender, EventArgs e)
        {
            WriteToClipboard(textBoxBynary.Value);
        }

        string FromLast()
        {
            try
            {
                return SetNumberFromMain?.Invoke();
            }
            catch {
                return "";
            }
        }

        string FromMain()
        {
            return ValueHelper.GetText();
        }

        string FromClipboard()
        {
            try
            {
                return Clipboard.GetText();
            }
            catch
            {
                return "";
            }
        }

        string NumFrom(string num)
        {
            if (num.Length < 1)
                return "";
            return int.Parse(num).ToString();
        }

        

        string BynaryFrom(string code)
        {
            return BynaryCode.AsBynaryCode(code);
        }

        private void buttonNumFromLast_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxNum.Value = NumFrom(FromLast());
            }
            catch
            {

            }
        }

        private void buttonNumFromMain_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxNum.Value = NumFrom(FromMain());
            }
            catch
            {

            }
        }

        private void buttonNumFromClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxNum.Value = NumFrom(FromClipboard());
            }
            catch
            {

            }
        }

        private void buttonBynaryFromLast_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxBynary.Value = BynaryFrom(FromLast());
            }
            catch
            {

            }
        }

        private void buttonToCalculatorA_Click(object sender, EventArgs e)
        {
            try
            {
                SetA?.Invoke(double.Parse(textBoxNum.Value));
            }
            catch { }
        }

        private void buttonToCalculatorB_Click(object sender, EventArgs e)
        {
            try
            {
                SetB?.Invoke(double.Parse(textBoxNum.Value));
            }
            catch { }
        }

        private void buttonToCalculatorBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                SetBuffer?.Invoke(double.Parse(textBoxNum.Value));
            }
            catch { }
        }

        private void buttonToCalculatorHelp_Click(object sender, EventArgs e)
        {
            try
            {
                SetHelp?.Invoke(double.Parse(textBoxNum.Value));
            }
            catch { }
        }

        private void buttonFromCalculatorB_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxNum.Value = HyperbolicFunctions.ToInt(GetB?.Invoke() ?? 0).ToString();
            }
            catch { }
        }

        private void buttonFromCalculatorBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxNum.Value = HyperbolicFunctions.ToInt(GetBuffer?.Invoke() ?? 0).ToString();
            }
            catch { }
        }

        private void buttonFromCalculatorHelp_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxNum.Value = HyperbolicFunctions.ToInt(GetHelp?.Invoke() ?? 0).ToString();
            }
            catch { }
        }

        private void buttonBynaryFromMain_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxBynary.Value = BynaryFrom(FromMain());
            }
            catch
            {

            }
        }

        private void buttonBynaryFromClipbord_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxBynary.Value = BynaryFrom(FromClipboard());
            }
            catch
            {

            }
        }

        private void buttonFromCalculatorA_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxNum.Value = HyperbolicFunctions.ToInt(GetA?.Invoke()??0).ToString();
            }
            catch { }
        }
    }
}
