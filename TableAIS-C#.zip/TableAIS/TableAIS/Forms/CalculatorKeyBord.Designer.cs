﻿namespace TableAIS
{
    partial class CalculatorKeyBord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CalculatorKeyBord));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonPersentA = new TableAIS.ButtonClickView();
            this.buttonLogBA = new TableAIS.ButtonClickView();
            this.buttonLogAB = new TableAIS.ButtonClickView();
            this.buttonSqrtBA = new TableAIS.ButtonClickView();
            this.buttonSetAB = new TableAIS.ButtonClickView();
            this.buttonSqrtAB = new TableAIS.ButtonClickView();
            this.buttonAdd = new TableAIS.ButtonClickView();
            this.buttonClickMinesB = new TableAIS.ButtonClickView();
            this.buttonMinesA = new TableAIS.ButtonClickView();
            this.buttonMul = new TableAIS.ButtonClickView();
            this.buttonDivB = new TableAIS.ButtonClickView();
            this.buttonDivA = new TableAIS.ButtonClickView();
            this.buttonPowB = new TableAIS.ButtonClickView();
            this.buttonPowA = new TableAIS.ButtonClickView();
            this.buttonAB = new TableAIS.ButtonClickView();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.radioButtonCurcleA = new System.Windows.Forms.ToolStripMenuItem();
            this.вывестиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWrite = new System.Windows.Forms.ToolStripMenuItem();
            this.наПредыдущийЭкранToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteAToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOutputWrite = new System.Windows.Forms.ToolStripMenuItem();
            this.записатьВырToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAequalsB = new System.Windows.Forms.ToolStripMenuItem();
            this.наПредыдущийЭкранToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAequalsBMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAequalsBToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBequalsA = new System.Windows.Forms.ToolStripMenuItem();
            this.наПредыдущийЭкранToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBequalsAMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBequalsAToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonPersentB = new TableAIS.ButtonClickView();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonSubKubA = new TableAIS.ButtonClickView();
            this.buttonSubKubB = new TableAIS.ButtonClickView();
            this.buttonSumKub = new TableAIS.ButtonClickView();
            this.buttonKubSubA = new TableAIS.ButtonClickView();
            this.buttonKubSubB = new TableAIS.ButtonClickView();
            this.buttonKubSum = new TableAIS.ButtonClickView();
            this.buttonSubSqvsA = new TableAIS.ButtonClickView();
            this.buttonSubSqvsB = new TableAIS.ButtonClickView();
            this.buttonSumSqvs = new TableAIS.ButtonClickView();
            this.buttonSubA = new TableAIS.ButtonClickView();
            this.buttonSqvSum = new TableAIS.ButtonClickView();
            this.buttonSqvSumB = new TableAIS.ButtonClickView();
            this.buttonAMinesBPersent = new TableAIS.ButtonClickView();
            this.buttonAPlusBPersent = new TableAIS.ButtonClickView();
            this.buttonBMinesAPersent = new TableAIS.ButtonClickView();
            this.buttonBPlusAPersent = new TableAIS.ButtonClickView();
            this.buttonMaxAB = new TableAIS.ButtonClickView();
            this.buttonADivBPersent = new TableAIS.ButtonClickView();
            this.buttonAMullBPersent = new TableAIS.ButtonClickView();
            this.buttonBDivAPersent = new TableAIS.ButtonClickView();
            this.buttonBMulAPersent = new TableAIS.ButtonClickView();
            this.buttonMinAB = new TableAIS.ButtonClickView();
            this.buttonAvgAB = new TableAIS.ButtonClickView();
            this.buttonRAB = new TableAIS.ButtonClickView();
            this.buttonChangeAB = new TableAIS.ButtonClickView();
            this.buttonStepenAB = new System.Windows.Forms.Button();
            this.buttonStepenBA = new System.Windows.Forms.Button();
            this.buttonStepen1AB = new System.Windows.Forms.Button();
            this.buttonStepen1BA = new System.Windows.Forms.Button();
            this.groupBox45 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel48 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip5 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.runPastResult = new System.Windows.Forms.ToolStripMenuItem();
            this.runNextResult = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteResult = new System.Windows.Forms.ToolStripMenuItem();
            this.addResult = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip4 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.runPast2 = new System.Windows.Forms.ToolStripMenuItem();
            this.runNext2 = new System.Windows.Forms.ToolStripMenuItem();
            this.delete2 = new System.Windows.Forms.ToolStripMenuItem();
            this.add2 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox54 = new System.Windows.Forms.GroupBox();
            this.comboBoxResultTo = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox53 = new System.Windows.Forms.GroupBox();
            this.comboBoxResultFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox52 = new System.Windows.Forms.GroupBox();
            this.comboBoxBynarCalculate = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox50 = new System.Windows.Forms.GroupBox();
            this.comboBox2To = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox51 = new System.Windows.Forms.GroupBox();
            this.comboBox1To = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.comboBox2From = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel50 = new System.Windows.Forms.TableLayoutPanel();
            this.radioBynarInputY1 = new System.Windows.Forms.RadioButton();
            this.radioBynarInputY0 = new System.Windows.Forms.RadioButton();
            this.radioBynarInputYB = new System.Windows.Forms.RadioButton();
            this.radioBynarInputYA = new System.Windows.Forms.RadioButton();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel49 = new System.Windows.Forms.TableLayoutPanel();
            this.radioBynarInputX1 = new System.Windows.Forms.RadioButton();
            this.radioBynarInputX0 = new System.Windows.Forms.RadioButton();
            this.radioBynarInputXB = new System.Windows.Forms.RadioButton();
            this.radioBynarInputXA = new System.Windows.Forms.RadioButton();
            this.groupBox48 = new System.Windows.Forms.GroupBox();
            this.comboBox1From = new TableAIS.Controls.ComboBoxToolTip();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.действиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.перейтиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runPast1 = new System.Windows.Forms.ToolStripMenuItem();
            this.runNext1 = new System.Windows.Forms.ToolStripMenuItem();
            this.delete1 = new System.Windows.Forms.ToolStripMenuItem();
            this.add1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBynarCalculate = new System.Windows.Forms.Button();
            this.textBoxIndexes = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonSgnB = new System.Windows.Forms.Button();
            this.buttonIntA = new System.Windows.Forms.Button();
            this.tableLayoutPanel51 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonAbsBM = new TableAIS.ButtonClickView();
            this.buttonAbsAM = new TableAIS.ButtonClickView();
            this.buttonClickView31 = new TableAIS.ButtonClickView();
            this.buttonClickView32 = new TableAIS.ButtonClickView();
            this.buttonLgB = new TableAIS.ButtonClickView();
            this.buttonLgA = new TableAIS.ButtonClickView();
            this.buttonLnA = new TableAIS.ButtonClickView();
            this.buttonPowEA = new TableAIS.ButtonClickView();
            this.buttonPowEB = new TableAIS.ButtonClickView();
            this.buttonRetA = new TableAIS.ButtonClickView();
            this.buttonRetB = new TableAIS.ButtonClickView();
            this.buttonMul2B = new TableAIS.ButtonClickView();
            this.buttonDiv2B = new TableAIS.ButtonClickView();
            this.buttonA1 = new TableAIS.ButtonClickView();
            this.buttonSqrtA = new TableAIS.ButtonClickView();
            this.buttonSqrtB = new TableAIS.ButtonClickView();
            this.buttonPow2 = new TableAIS.ButtonClickView();
            this.buttonPow3 = new TableAIS.ButtonClickView();
            this.buttonPowA2 = new TableAIS.ButtonClickView();
            this.buttonPowA3 = new TableAIS.ButtonClickView();
            this.buttonIncA = new TableAIS.ButtonClickView();
            this.buttonDecA = new TableAIS.ButtonClickView();
            this.buttonPow2B = new TableAIS.ButtonClickView();
            this.buttonPow2A = new TableAIS.ButtonClickView();
            this.buttonMulB2 = new TableAIS.ButtonClickView();
            this.buttonMul2A = new TableAIS.ButtonClickView();
            this.buttonB1 = new TableAIS.ButtonClickView();
            this.buttonLnB = new TableAIS.ButtonClickView();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonAbsB = new TableAIS.ButtonClickView();
            this.buttonAbsA = new TableAIS.ButtonClickView();
            this.buttonClickView29 = new TableAIS.ButtonClickView();
            this.buttonClickView30 = new TableAIS.ButtonClickView();
            this.buttonPlusB1 = new TableAIS.ButtonClickView();
            this.buttonMines1B = new TableAIS.ButtonClickView();
            this.buttonPersent1A = new TableAIS.ButtonClickView();
            this.buttonPersent1B = new TableAIS.ButtonClickView();
            this.button1AB = new TableAIS.ButtonClickView();
            this.buttonIntB = new System.Windows.Forms.Button();
            this.buttonDrobB = new System.Windows.Forms.Button();
            this.buttonDrobA = new System.Windows.Forms.Button();
            this.buttonSgnA = new System.Windows.Forms.Button();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.memoryA = new TableAIS.Controls.MemoryCalculateControl();
            this.memoryBuffer = new TableAIS.Controls.MemoryCalculateControl();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxA = new System.Windows.Forms.TextBox();
            this.buttonClearA = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxB = new System.Windows.Forms.TextBox();
            this.buttonBackSpace = new System.Windows.Forms.Button();
            this.buttonClearB = new System.Windows.Forms.Button();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonBufferA = new TableAIS.ButtonClickView();
            this.buttonBufferB = new TableAIS.ButtonClickView();
            this.buttonABuffer = new TableAIS.ButtonClickView();
            this.textBoxBuffer = new System.Windows.Forms.TextBox();
            this.buttonBBuffer = new TableAIS.ButtonClickView();
            this.buttonBufferClear = new TableAIS.ButtonClickView();
            this.memoryB = new TableAIS.Controls.MemoryCalculateControl();
            this.checkBoxAutoOutput = new System.Windows.Forms.CheckBox();
            this.checkBoxAutoWrite = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonTallRadBA = new TableAIS.ButtonClickView();
            this.buttonSqrRadBA = new TableAIS.ButtonClickView();
            this.buttonRadLenBA = new TableAIS.ButtonClickView();
            this.buttonLenRadBA = new TableAIS.ButtonClickView();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonTallGradBA = new TableAIS.ButtonClickView();
            this.buttonSqrGradBA = new TableAIS.ButtonClickView();
            this.buttonGradLenBA = new TableAIS.ButtonClickView();
            this.buttonLenGradBA = new TableAIS.ButtonClickView();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonRetTallB = new System.Windows.Forms.Button();
            this.buttonSqrTruangleB = new TableAIS.ButtonClickView();
            this.buttonRetSqrB = new System.Windows.Forms.Button();
            this.buttonTallB = new TableAIS.ButtonClickView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonSqrTruangleCatetsB = new TableAIS.ButtonClickView();
            this.buttonSqrTruangleCatetsA = new TableAIS.ButtonClickView();
            this.buttonSqrTruangleCatets = new TableAIS.ButtonClickView();
            this.buttonCatetSqrtB = new TableAIS.ButtonClickView();
            this.buttonCatetSqrtA = new TableAIS.ButtonClickView();
            this.buttonGipotenuzeB = new TableAIS.ButtonClickView();
            this.buttonGipotenuzeA = new TableAIS.ButtonClickView();
            this.buttonCatetA = new TableAIS.ButtonClickView();
            this.buttonCatetB = new TableAIS.ButtonClickView();
            this.buttonGipotenuze = new TableAIS.ButtonClickView();
            this.buttonKatetSqrA = new TableAIS.ButtonClickView();
            this.buttonKatetSqrB = new TableAIS.ButtonClickView();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonRetTallA = new System.Windows.Forms.Button();
            this.buttonSqrTruangleA = new TableAIS.ButtonClickView();
            this.buttonRetSqrA = new System.Windows.Forms.Button();
            this.buttonTallA = new TableAIS.ButtonClickView();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonTallRadAB = new TableAIS.ButtonClickView();
            this.buttonSqrRadAB = new TableAIS.ButtonClickView();
            this.buttonRadLenAB = new TableAIS.ButtonClickView();
            this.buttonLenRadAB = new TableAIS.ButtonClickView();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonTallGradAB = new TableAIS.ButtonClickView();
            this.buttonSqrGradAB = new TableAIS.ButtonClickView();
            this.buttonGradLenAB = new TableAIS.ButtonClickView();
            this.buttonLenGradAB = new TableAIS.ButtonClickView();
            this.groupBox83 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel71 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox84 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel72 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonEqualsTriangleA = new System.Windows.Forms.RadioButton();
            this.radioButtonEqualsTriangleB = new System.Windows.Forms.RadioButton();
            this.comboBoxEqualsTriangleFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxEqualsTriangleTo = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonEqualsLenTriangleConvert = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonGradB = new TableAIS.ButtonClickView();
            this.buttonGradA = new TableAIS.ButtonClickView();
            this.buttonRadB = new TableAIS.ButtonClickView();
            this.buttonRadA = new TableAIS.ButtonClickView();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButtonCurcleB = new System.Windows.Forms.RadioButton();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.comboBoxCurcleFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.comboBoxCurcleTo = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonCurcleCalculate = new TableAIS.ButtonClickView();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel38 = new System.Windows.Forms.TableLayoutPanel();
            this.radioASinA = new System.Windows.Forms.RadioButton();
            this.radioASinB = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel37 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonAtg = new TableAIS.ButtonClickView();
            this.buttonAcos = new TableAIS.ButtonClickView();
            this.buttonArcSin = new TableAIS.ButtonClickView();
            this.tableLayoutPanel36 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonActg = new TableAIS.ButtonClickView();
            this.buttonAsec = new TableAIS.ButtonClickView();
            this.buttonAcosec = new TableAIS.ButtonClickView();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel32 = new System.Windows.Forms.TableLayoutPanel();
            this.radioASinGrad = new System.Windows.Forms.RadioButton();
            this.radioASinRad = new System.Windows.Forms.RadioButton();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel35 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonSec = new TableAIS.ButtonClickView();
            this.buttonCosec = new TableAIS.ButtonClickView();
            this.buttonCtg = new TableAIS.ButtonClickView();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.radioSinA = new System.Windows.Forms.RadioButton();
            this.radioSinB = new System.Windows.Forms.RadioButton();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.radioSinGrad = new System.Windows.Forms.RadioButton();
            this.radioSinRad = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel34 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonTg = new TableAIS.ButtonClickView();
            this.buttonCos = new TableAIS.ButtonClickView();
            this.buttonSin = new TableAIS.ButtonClickView();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel39 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel40 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonTimeA = new System.Windows.Forms.RadioButton();
            this.radioButtonTimeB = new System.Windows.Forms.RadioButton();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel41 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.comboBoxTimeFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.comboBoxTimeTo = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonTimeCalculate = new TableAIS.ButtonClickView();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel42 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel43 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonMetrA = new System.Windows.Forms.RadioButton();
            this.radioButtonMetrB = new System.Windows.Forms.RadioButton();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel44 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox38 = new System.Windows.Forms.GroupBox();
            this.comboBoxMetrFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox39 = new System.Windows.Forms.GroupBox();
            this.comboBoxMetrTo = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonLengthConvert = new TableAIS.ButtonClickView();
            this.groupBox40 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel45 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox41 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel46 = new System.Windows.Forms.TableLayoutPanel();
            this.radioGradusA = new System.Windows.Forms.RadioButton();
            this.radioGradusB = new System.Windows.Forms.RadioButton();
            this.groupBox42 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel47 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox43 = new System.Windows.Forms.GroupBox();
            this.comboBoxGradusFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox44 = new System.Windows.Forms.GroupBox();
            this.comboBoxGradusTo = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonGradusConvert = new TableAIS.ButtonClickView();
            this.groupBox55 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel52 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox64 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel57 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox65 = new System.Windows.Forms.GroupBox();
            this.comboBoxSpeedTimeTo = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox66 = new System.Windows.Forms.GroupBox();
            this.comboBoxSpeedTimeFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox56 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel53 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox57 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel54 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonSpeedB = new System.Windows.Forms.RadioButton();
            this.radioButtonSpeedA = new System.Windows.Forms.RadioButton();
            this.buttonSpeedConvert = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox58 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel55 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox60 = new System.Windows.Forms.GroupBox();
            this.comboBoxSpeedTo = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox59 = new System.Windows.Forms.GroupBox();
            this.comboBoxSpeedFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox61 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel56 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox63 = new System.Windows.Forms.GroupBox();
            this.comboBoxSpeedLengthTo = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox62 = new System.Windows.Forms.GroupBox();
            this.comboBoxSpeedLengthFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox67 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel58 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox72 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel61 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox73 = new System.Windows.Forms.GroupBox();
            this.comboBoxSqrLengthTo = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox74 = new System.Windows.Forms.GroupBox();
            this.comboBoxSqrLengthFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox68 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel59 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonSqrA = new System.Windows.Forms.RadioButton();
            this.radioButtonSqrB = new System.Windows.Forms.RadioButton();
            this.buttonSqrConvert = new System.Windows.Forms.Button();
            this.groupBox69 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel60 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox71 = new System.Windows.Forms.GroupBox();
            this.comboBoxSqrTo = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox70 = new System.Windows.Forms.GroupBox();
            this.comboBoxSqrFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox75 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel62 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox76 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel63 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox77 = new System.Windows.Forms.GroupBox();
            this.comboBoxKubLengthTo = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox78 = new System.Windows.Forms.GroupBox();
            this.comboBoxKubLengthFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox79 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel64 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonKubA = new System.Windows.Forms.RadioButton();
            this.radioButtonKubB = new System.Windows.Forms.RadioButton();
            this.buttonKubConvert = new System.Windows.Forms.Button();
            this.groupBox80 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel65 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox81 = new System.Windows.Forms.GroupBox();
            this.comboBoxKubTo = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox82 = new System.Windows.Forms.GroupBox();
            this.comboBoxKubFrom = new TableAIS.Controls.ComboBoxToolTip();
            this.groupBox85 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanelInputB = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel75 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonClickView49 = new TableAIS.ButtonClickView();
            this.buttonClickView47 = new TableAIS.ButtonClickView();
            this.buttonClickView48 = new TableAIS.ButtonClickView();
            this.buttonClickView53 = new TableAIS.ButtonClickView();
            this.buttonMulX2 = new TableAIS.ButtonClickView();
            this.buttonSet = new System.Windows.Forms.Button();
            this.buttonDecB = new TableAIS.ButtonClickView();
            this.tableLayoutPanel68 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonClickView12 = new TableAIS.ButtonClickView();
            this.buttonClickView13 = new TableAIS.ButtonClickView();
            this.buttonClickView14 = new TableAIS.ButtonClickView();
            this.buttonClickView15 = new TableAIS.ButtonClickView();
            this.buttonClickView27 = new TableAIS.ButtonClickView();
            this.tableLayoutPanel67 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonClickView25 = new TableAIS.ButtonClickView();
            this.buttonClickView24 = new TableAIS.ButtonClickView();
            this.buttonClickView26 = new TableAIS.ButtonClickView();
            this.buttonClickView11 = new TableAIS.ButtonClickView();
            this.buttonClickView28 = new TableAIS.ButtonClickView();
            this.tableLayoutPanel66 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonClickView19 = new TableAIS.ButtonClickView();
            this.buttonClickView20 = new TableAIS.ButtonClickView();
            this.buttonClickView22 = new TableAIS.ButtonClickView();
            this.buttonClickView23 = new TableAIS.ButtonClickView();
            this.buttonIncB = new TableAIS.ButtonClickView();
            this.tableLayoutPanel70 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonClickView5 = new TableAIS.ButtonClickView();
            this.buttonClickView6 = new TableAIS.ButtonClickView();
            this.buttonClickView7 = new TableAIS.ButtonClickView();
            this.buttonClickView8 = new TableAIS.ButtonClickView();
            this.buttonClickView9 = new TableAIS.ButtonClickView();
            this.buttonClickView40 = new TableAIS.ButtonClickView();
            this.tableLayoutPanel69 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonNumberB = new TableAIS.ButtonClickView();
            this.buttonClickView2 = new TableAIS.ButtonClickView();
            this.buttonClickView3 = new TableAIS.ButtonClickView();
            this.buttonClickView1 = new TableAIS.ButtonClickView();
            this.buttonClickView4 = new TableAIS.ButtonClickView();
            this.buttonClickView10 = new TableAIS.ButtonClickView();
            this.buttonClickView16 = new TableAIS.ButtonClickView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.секундомерToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClickSecondMetr = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSecondsSaved = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonInputMainForm = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonIntCalculator = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonInputMainFormReal = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBFromClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteB1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteBMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteBToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonMines = new System.Windows.Forms.Button();
            this.buttonAbs = new TableAIS.ButtonClickView();
            this.buttonRet = new TableAIS.ButtonClickView();
            this.buttonDivX2 = new TableAIS.ButtonClickView();
            this.buttonClickView18 = new TableAIS.ButtonClickView();
            this.buttonBA = new TableAIS.ButtonClickView();
            this.buttonClickView33 = new TableAIS.ButtonClickView();
            this.buttonMinesAbs = new TableAIS.ButtonClickView();
            this.buttonMinesRet = new TableAIS.ButtonClickView();
            this.buttonMinesX = new TableAIS.ButtonClickView();
            this.buttonAbsRet = new TableAIS.ButtonClickView();
            this.buttonMinesAbsRet = new TableAIS.ButtonClickView();
            this.buttonClickView35 = new TableAIS.ButtonClickView();
            this.buttonClickView36 = new TableAIS.ButtonClickView();
            this.buttonClickView37 = new TableAIS.ButtonClickView();
            this.buttonClickView38 = new TableAIS.ButtonClickView();
            this.buttonPlusBasketes = new TableAIS.ButtonClickView();
            this.buttonMinesBasketes = new TableAIS.ButtonClickView();
            this.buttonChangeBaskets = new TableAIS.ButtonClickView();
            this.buttonClickView21 = new TableAIS.ButtonClickView();
            this.buttonClickView34 = new TableAIS.ButtonClickView();
            this.buttonClickView17 = new TableAIS.ButtonClickView();
            this.buttonChangeAbsBaskets = new TableAIS.ButtonClickView();
            this.buttonPersent = new TableAIS.ButtonClickView();
            this.buttonPlusAbs = new TableAIS.ButtonClickView();
            this.buttonClickView39 = new TableAIS.ButtonClickView();
            this.buttonClickView41 = new TableAIS.ButtonClickView();
            this.buttonClickView42 = new TableAIS.ButtonClickView();
            this.buttonClickView43 = new TableAIS.ButtonClickView();
            this.buttonClickView44 = new TableAIS.ButtonClickView();
            this.buttonClickView45 = new TableAIS.ButtonClickView();
            this.buttonClickView46 = new TableAIS.ButtonClickView();
            this.buttonClickView50 = new TableAIS.ButtonClickView();
            this.buttonClickView51 = new TableAIS.ButtonClickView();
            this.buttonClickView52 = new TableAIS.ButtonClickView();
            this.groupBox86 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel73 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxFunc = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonAddFunc = new System.Windows.Forms.Button();
            this.buttonAddFuncs = new System.Windows.Forms.Button();
            this.groupBox87 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel74 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxMemory = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonSetMemory = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.timerMemory = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.groupBox45.SuspendLayout();
            this.tableLayoutPanel48.SuspendLayout();
            this.menuStrip5.SuspendLayout();
            this.menuStrip4.SuspendLayout();
            this.groupBox54.SuspendLayout();
            this.groupBox53.SuspendLayout();
            this.groupBox52.SuspendLayout();
            this.groupBox50.SuspendLayout();
            this.groupBox51.SuspendLayout();
            this.groupBox49.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.tableLayoutPanel50.SuspendLayout();
            this.groupBox46.SuspendLayout();
            this.tableLayoutPanel49.SuspendLayout();
            this.groupBox48.SuspendLayout();
            this.menuStrip3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel51.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.groupBox83.SuspendLayout();
            this.tableLayoutPanel71.SuspendLayout();
            this.groupBox84.SuspendLayout();
            this.tableLayoutPanel72.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.tableLayoutPanel37.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.tableLayoutPanel32.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.tableLayoutPanel35.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.tableLayoutPanel39.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.tableLayoutPanel40.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.tableLayoutPanel41.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.groupBox34.SuspendLayout();
            this.groupBox35.SuspendLayout();
            this.tableLayoutPanel42.SuspendLayout();
            this.groupBox36.SuspendLayout();
            this.tableLayoutPanel43.SuspendLayout();
            this.groupBox37.SuspendLayout();
            this.tableLayoutPanel44.SuspendLayout();
            this.groupBox38.SuspendLayout();
            this.groupBox39.SuspendLayout();
            this.groupBox40.SuspendLayout();
            this.tableLayoutPanel45.SuspendLayout();
            this.groupBox41.SuspendLayout();
            this.tableLayoutPanel46.SuspendLayout();
            this.groupBox42.SuspendLayout();
            this.tableLayoutPanel47.SuspendLayout();
            this.groupBox43.SuspendLayout();
            this.groupBox44.SuspendLayout();
            this.groupBox55.SuspendLayout();
            this.tableLayoutPanel52.SuspendLayout();
            this.groupBox64.SuspendLayout();
            this.tableLayoutPanel57.SuspendLayout();
            this.groupBox65.SuspendLayout();
            this.groupBox66.SuspendLayout();
            this.groupBox56.SuspendLayout();
            this.tableLayoutPanel53.SuspendLayout();
            this.groupBox57.SuspendLayout();
            this.tableLayoutPanel54.SuspendLayout();
            this.groupBox58.SuspendLayout();
            this.tableLayoutPanel55.SuspendLayout();
            this.groupBox60.SuspendLayout();
            this.groupBox59.SuspendLayout();
            this.groupBox61.SuspendLayout();
            this.tableLayoutPanel56.SuspendLayout();
            this.groupBox63.SuspendLayout();
            this.groupBox62.SuspendLayout();
            this.groupBox67.SuspendLayout();
            this.tableLayoutPanel58.SuspendLayout();
            this.groupBox72.SuspendLayout();
            this.tableLayoutPanel61.SuspendLayout();
            this.groupBox73.SuspendLayout();
            this.groupBox74.SuspendLayout();
            this.groupBox68.SuspendLayout();
            this.tableLayoutPanel59.SuspendLayout();
            this.groupBox69.SuspendLayout();
            this.tableLayoutPanel60.SuspendLayout();
            this.groupBox71.SuspendLayout();
            this.groupBox70.SuspendLayout();
            this.groupBox75.SuspendLayout();
            this.tableLayoutPanel62.SuspendLayout();
            this.groupBox76.SuspendLayout();
            this.tableLayoutPanel63.SuspendLayout();
            this.groupBox77.SuspendLayout();
            this.groupBox78.SuspendLayout();
            this.groupBox79.SuspendLayout();
            this.tableLayoutPanel64.SuspendLayout();
            this.groupBox80.SuspendLayout();
            this.tableLayoutPanel65.SuspendLayout();
            this.groupBox81.SuspendLayout();
            this.groupBox82.SuspendLayout();
            this.flowLayoutPanelInputB.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel75.SuspendLayout();
            this.tableLayoutPanel68.SuspendLayout();
            this.tableLayoutPanel67.SuspendLayout();
            this.tableLayoutPanel66.SuspendLayout();
            this.tableLayoutPanel70.SuspendLayout();
            this.tableLayoutPanel69.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox86.SuspendLayout();
            this.tableLayoutPanel73.SuspendLayout();
            this.groupBox87.SuspendLayout();
            this.tableLayoutPanel74.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(621, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(283, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(933, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(933, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(929, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(504, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 488);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(933, 39);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.57766F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.42234F));
            this.tableLayoutPanel2.Controls.Add(this.groupBox2, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.groupBox3, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel10, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox4, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.flowLayoutPanelInputB, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(933, 399);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.flowLayoutPanel2);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(456, 113);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(474, 138);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Бинарно вычислить выходной параметр";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.AutoScroll = true;
            this.flowLayoutPanel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowLayoutPanel2.Controls.Add(this.tableLayoutPanel6);
            this.flowLayoutPanel2.Controls.Add(this.groupBox45);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel2.Font = new System.Drawing.Font("Lucida Sans Unicode", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 30);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(468, 105);
            this.flowLayoutPanel2.TabIndex = 8;
            this.flowLayoutPanel2.WrapContents = false;
            this.flowLayoutPanel2.SizeChanged += new System.EventHandler(this.flowLayoutPanelInputB_SizeChanged);
            this.flowLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel2_Paint);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 5;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.Controls.Add(this.buttonPersentA, 3, 4);
            this.tableLayoutPanel6.Controls.Add(this.buttonLogBA, 3, 2);
            this.tableLayoutPanel6.Controls.Add(this.buttonLogAB, 2, 2);
            this.tableLayoutPanel6.Controls.Add(this.buttonSqrtBA, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.buttonSetAB, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonSqrtAB, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.buttonAdd, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickMinesB, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonMinesA, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonMul, 2, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonDivB, 3, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonDivA, 4, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonPowB, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonPowA, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonAB, 4, 2);
            this.tableLayoutPanel6.Controls.Add(this.menuStrip2, 0, 4);
            this.tableLayoutPanel6.Controls.Add(this.buttonPersentB, 2, 4);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel9, 0, 5);
            this.tableLayoutPanel6.Controls.Add(this.buttonAMinesBPersent, 0, 9);
            this.tableLayoutPanel6.Controls.Add(this.buttonAPlusBPersent, 1, 9);
            this.tableLayoutPanel6.Controls.Add(this.buttonBMinesAPersent, 2, 9);
            this.tableLayoutPanel6.Controls.Add(this.buttonBPlusAPersent, 3, 9);
            this.tableLayoutPanel6.Controls.Add(this.buttonMaxAB, 4, 9);
            this.tableLayoutPanel6.Controls.Add(this.buttonADivBPersent, 0, 10);
            this.tableLayoutPanel6.Controls.Add(this.buttonAMullBPersent, 1, 10);
            this.tableLayoutPanel6.Controls.Add(this.buttonBDivAPersent, 2, 10);
            this.tableLayoutPanel6.Controls.Add(this.buttonBMulAPersent, 3, 10);
            this.tableLayoutPanel6.Controls.Add(this.buttonMinAB, 4, 10);
            this.tableLayoutPanel6.Controls.Add(this.buttonAvgAB, 0, 11);
            this.tableLayoutPanel6.Controls.Add(this.buttonRAB, 3, 11);
            this.tableLayoutPanel6.Controls.Add(this.buttonChangeAB, 2, 11);
            this.tableLayoutPanel6.Controls.Add(this.buttonStepenAB, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.buttonStepenBA, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.buttonStepen1AB, 2, 3);
            this.tableLayoutPanel6.Controls.Add(this.buttonStepen1BA, 3, 3);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 12;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.332568F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333402F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(429, 370);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // buttonPersentA
            // 
            this.buttonPersentA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPersentA.Location = new System.Drawing.Point(258, 123);
            this.buttonPersentA.Name = "buttonPersentA";
            this.buttonPersentA.Size = new System.Drawing.Size(79, 24);
            this.buttonPersentA.TabIndex = 22;
            this.buttonPersentA.Text = "A%";
            this.buttonPersentA.UseVisualStyleBackColor = true;
            this.buttonPersentA.Click += new System.EventHandler(this.buttonPersentA_Click);
            // 
            // buttonLogBA
            // 
            this.buttonLogBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLogBA.Location = new System.Drawing.Point(258, 63);
            this.buttonLogBA.Name = "buttonLogBA";
            this.buttonLogBA.Size = new System.Drawing.Size(79, 24);
            this.buttonLogBA.TabIndex = 18;
            this.buttonLogBA.Text = "Log(B, A)";
            this.buttonLogBA.UseVisualStyleBackColor = true;
            this.buttonLogBA.Click += new System.EventHandler(this.buttonLogBA_Click);
            // 
            // buttonLogAB
            // 
            this.buttonLogAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLogAB.Location = new System.Drawing.Point(173, 63);
            this.buttonLogAB.Name = "buttonLogAB";
            this.buttonLogAB.Size = new System.Drawing.Size(79, 24);
            this.buttonLogAB.TabIndex = 17;
            this.buttonLogAB.Text = "Log(A, B)";
            this.buttonLogAB.UseVisualStyleBackColor = true;
            this.buttonLogAB.Click += new System.EventHandler(this.buttonLogAB_Click);
            // 
            // buttonSqrtBA
            // 
            this.buttonSqrtBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrtBA.Location = new System.Drawing.Point(88, 63);
            this.buttonSqrtBA.Name = "buttonSqrtBA";
            this.buttonSqrtBA.Size = new System.Drawing.Size(79, 24);
            this.buttonSqrtBA.TabIndex = 15;
            this.buttonSqrtBA.Text = "B^(1/A)";
            this.buttonSqrtBA.UseVisualStyleBackColor = true;
            this.buttonSqrtBA.Click += new System.EventHandler(this.buttonSqrtBA_Click);
            // 
            // buttonSetAB
            // 
            this.tableLayoutPanel6.SetColumnSpan(this.buttonSetAB, 2);
            this.buttonSetAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSetAB.Location = new System.Drawing.Point(3, 3);
            this.buttonSetAB.Name = "buttonSetAB";
            this.buttonSetAB.Size = new System.Drawing.Size(164, 24);
            this.buttonSetAB.TabIndex = 1;
            this.buttonSetAB.Text = "Вывести";
            this.buttonSetAB.UseVisualStyleBackColor = true;
            this.buttonSetAB.Click += new System.EventHandler(this.buttonAB_Click);
            // 
            // buttonSqrtAB
            // 
            this.buttonSqrtAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrtAB.Location = new System.Drawing.Point(3, 63);
            this.buttonSqrtAB.Name = "buttonSqrtAB";
            this.buttonSqrtAB.Size = new System.Drawing.Size(79, 24);
            this.buttonSqrtAB.TabIndex = 14;
            this.buttonSqrtAB.Text = "A^(1/B)";
            this.buttonSqrtAB.UseVisualStyleBackColor = true;
            this.buttonSqrtAB.Click += new System.EventHandler(this.buttonSqrtAB_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAdd.Location = new System.Drawing.Point(173, 3);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(79, 24);
            this.buttonAdd.TabIndex = 2;
            this.buttonAdd.Text = "A+B";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonClickView21_Click);
            // 
            // buttonClickMinesB
            // 
            this.buttonClickMinesB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickMinesB.Location = new System.Drawing.Point(258, 3);
            this.buttonClickMinesB.Name = "buttonClickMinesB";
            this.buttonClickMinesB.Size = new System.Drawing.Size(79, 24);
            this.buttonClickMinesB.TabIndex = 3;
            this.buttonClickMinesB.Text = "A-B";
            this.buttonClickMinesB.UseVisualStyleBackColor = true;
            this.buttonClickMinesB.Click += new System.EventHandler(this.buttonClickMinesB_Click);
            // 
            // buttonMinesA
            // 
            this.buttonMinesA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMinesA.Location = new System.Drawing.Point(343, 3);
            this.buttonMinesA.Name = "buttonMinesA";
            this.buttonMinesA.Size = new System.Drawing.Size(83, 24);
            this.buttonMinesA.TabIndex = 4;
            this.buttonMinesA.Text = "B-A";
            this.buttonMinesA.UseVisualStyleBackColor = true;
            this.buttonMinesA.Click += new System.EventHandler(this.buttonMinesA_Click);
            // 
            // buttonMul
            // 
            this.buttonMul.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMul.Location = new System.Drawing.Point(173, 33);
            this.buttonMul.Name = "buttonMul";
            this.buttonMul.Size = new System.Drawing.Size(79, 24);
            this.buttonMul.TabIndex = 5;
            this.buttonMul.Text = "A*B";
            this.buttonMul.UseVisualStyleBackColor = true;
            this.buttonMul.Click += new System.EventHandler(this.buttonMul_Click);
            // 
            // buttonDivB
            // 
            this.buttonDivB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDivB.Location = new System.Drawing.Point(258, 33);
            this.buttonDivB.Name = "buttonDivB";
            this.buttonDivB.Size = new System.Drawing.Size(79, 24);
            this.buttonDivB.TabIndex = 6;
            this.buttonDivB.Text = "A/B";
            this.buttonDivB.UseVisualStyleBackColor = true;
            this.buttonDivB.Click += new System.EventHandler(this.buttonDivB_Click);
            // 
            // buttonDivA
            // 
            this.buttonDivA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDivA.Location = new System.Drawing.Point(343, 33);
            this.buttonDivA.Name = "buttonDivA";
            this.buttonDivA.Size = new System.Drawing.Size(83, 24);
            this.buttonDivA.TabIndex = 7;
            this.buttonDivA.Text = "B/A";
            this.buttonDivA.UseVisualStyleBackColor = true;
            this.buttonDivA.Click += new System.EventHandler(this.buttonDivA_Click);
            // 
            // buttonPowB
            // 
            this.buttonPowB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPowB.Location = new System.Drawing.Point(3, 33);
            this.buttonPowB.Name = "buttonPowB";
            this.buttonPowB.Size = new System.Drawing.Size(79, 24);
            this.buttonPowB.TabIndex = 8;
            this.buttonPowB.Text = "A^B";
            this.buttonPowB.UseVisualStyleBackColor = true;
            this.buttonPowB.Click += new System.EventHandler(this.buttonPowB_Click);
            // 
            // buttonPowA
            // 
            this.buttonPowA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPowA.Location = new System.Drawing.Point(88, 33);
            this.buttonPowA.Name = "buttonPowA";
            this.buttonPowA.Size = new System.Drawing.Size(79, 24);
            this.buttonPowA.TabIndex = 9;
            this.buttonPowA.Text = "B^A";
            this.buttonPowA.UseVisualStyleBackColor = true;
            this.buttonPowA.Click += new System.EventHandler(this.buttonPowA_Click);
            // 
            // buttonAB
            // 
            this.buttonAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAB.Location = new System.Drawing.Point(343, 63);
            this.buttonAB.Name = "buttonAB";
            this.buttonAB.Size = new System.Drawing.Size(83, 24);
            this.buttonAB.TabIndex = 19;
            this.buttonAB.Text = "A=B";
            this.buttonAB.UseVisualStyleBackColor = true;
            this.buttonAB.Click += new System.EventHandler(this.buttonAB_Click_1);
            // 
            // menuStrip2
            // 
            this.tableLayoutPanel6.SetColumnSpan(this.menuStrip2, 2);
            this.menuStrip2.Font = new System.Drawing.Font("Lucida Console", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.radioButtonCurcleA});
            this.menuStrip2.Location = new System.Drawing.Point(0, 120);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(170, 30);
            this.menuStrip2.TabIndex = 20;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // radioButtonCurcleA
            // 
            this.radioButtonCurcleA.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вывестиToolStripMenuItem,
            this.buttonWrite,
            this.buttonOutputWrite,
            this.записатьВырToolStripMenuItem});
            this.radioButtonCurcleA.Font = new System.Drawing.Font("Lucida Console", 7.8F);
            this.radioButtonCurcleA.Name = "radioButtonCurcleA";
            this.radioButtonCurcleA.Size = new System.Drawing.Size(149, 26);
            this.radioButtonCurcleA.Text = "Вывести/записать";
            // 
            // вывестиToolStripMenuItem
            // 
            this.вывестиToolStripMenuItem.Name = "вывестиToolStripMenuItem";
            this.вывестиToolStripMenuItem.Size = new System.Drawing.Size(232, 26);
            this.вывестиToolStripMenuItem.Text = "Вывести";
            this.вывестиToolStripMenuItem.Click += new System.EventHandler(this.buttonAB_Click);
            // 
            // buttonWrite
            // 
            this.buttonWrite.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.наПредыдущийЭкранToolStripMenuItem,
            this.buttonWriteMain,
            this.buttonWriteAToClipboard});
            this.buttonWrite.Name = "buttonWrite";
            this.buttonWrite.Size = new System.Drawing.Size(232, 26);
            this.buttonWrite.Text = "Записать";
            // 
            // наПредыдущийЭкранToolStripMenuItem
            // 
            this.наПредыдущийЭкранToolStripMenuItem.Name = "наПредыдущийЭкранToolStripMenuItem";
            this.наПредыдущийЭкранToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.наПредыдущийЭкранToolStripMenuItem.Text = "На предыдущий экран";
            this.наПредыдущийЭкранToolStripMenuItem.Click += new System.EventHandler(this.buttonWrite_Click);
            // 
            // buttonWriteMain
            // 
            this.buttonWriteMain.Name = "buttonWriteMain";
            this.buttonWriteMain.Size = new System.Drawing.Size(240, 26);
            this.buttonWriteMain.Text = "На главный экран";
            this.buttonWriteMain.Click += new System.EventHandler(this.buttonWriteMain_Click);
            // 
            // buttonWriteAToClipboard
            // 
            this.buttonWriteAToClipboard.Name = "buttonWriteAToClipboard";
            this.buttonWriteAToClipboard.Size = new System.Drawing.Size(240, 26);
            this.buttonWriteAToClipboard.Text = "В буфер обмена";
            this.buttonWriteAToClipboard.Click += new System.EventHandler(this.buttonWriteAToClipboard_Click);
            // 
            // buttonOutputWrite
            // 
            this.buttonOutputWrite.Name = "buttonOutputWrite";
            this.buttonOutputWrite.Size = new System.Drawing.Size(232, 26);
            this.buttonOutputWrite.Text = "Вывести и записать";
            this.buttonOutputWrite.Click += new System.EventHandler(this.buttonOutputWrite_Click);
            // 
            // записатьВырToolStripMenuItem
            // 
            this.записатьВырToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAequalsB,
            this.buttonBequalsA});
            this.записатьВырToolStripMenuItem.Name = "записатьВырToolStripMenuItem";
            this.записатьВырToolStripMenuItem.Size = new System.Drawing.Size(232, 26);
            this.записатьВырToolStripMenuItem.Text = "Записать выражение";
            // 
            // buttonAequalsB
            // 
            this.buttonAequalsB.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.наПредыдущийЭкранToolStripMenuItem1,
            this.buttonAequalsBMain,
            this.buttonAequalsBToClipboard});
            this.buttonAequalsB.Name = "buttonAequalsB";
            this.buttonAequalsB.Size = new System.Drawing.Size(112, 26);
            this.buttonAequalsB.Text = "A=B";
            // 
            // наПредыдущийЭкранToolStripMenuItem1
            // 
            this.наПредыдущийЭкранToolStripMenuItem1.Name = "наПредыдущийЭкранToolStripMenuItem1";
            this.наПредыдущийЭкранToolStripMenuItem1.Size = new System.Drawing.Size(240, 26);
            this.наПредыдущийЭкранToolStripMenuItem1.Text = "На предыдущий экран";
            this.наПредыдущийЭкранToolStripMenuItem1.Click += new System.EventHandler(this.buttonAequalsB_Click);
            // 
            // buttonAequalsBMain
            // 
            this.buttonAequalsBMain.Name = "buttonAequalsBMain";
            this.buttonAequalsBMain.Size = new System.Drawing.Size(240, 26);
            this.buttonAequalsBMain.Text = "На главный экран";
            this.buttonAequalsBMain.Click += new System.EventHandler(this.buttonAequalsBMain_Click);
            // 
            // buttonAequalsBToClipboard
            // 
            this.buttonAequalsBToClipboard.Name = "buttonAequalsBToClipboard";
            this.buttonAequalsBToClipboard.Size = new System.Drawing.Size(240, 26);
            this.buttonAequalsBToClipboard.Text = "В буфер обмена";
            this.buttonAequalsBToClipboard.Click += new System.EventHandler(this.buttonAequalsBToClipboard_Click);
            // 
            // buttonBequalsA
            // 
            this.buttonBequalsA.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.наПредыдущийЭкранToolStripMenuItem2,
            this.buttonBequalsAMain,
            this.buttonBequalsAToClipboard});
            this.buttonBequalsA.Name = "buttonBequalsA";
            this.buttonBequalsA.Size = new System.Drawing.Size(112, 26);
            this.buttonBequalsA.Text = "B=A";
            // 
            // наПредыдущийЭкранToolStripMenuItem2
            // 
            this.наПредыдущийЭкранToolStripMenuItem2.Name = "наПредыдущийЭкранToolStripMenuItem2";
            this.наПредыдущийЭкранToolStripMenuItem2.Size = new System.Drawing.Size(240, 26);
            this.наПредыдущийЭкранToolStripMenuItem2.Text = "На предыдущий экран";
            this.наПредыдущийЭкранToolStripMenuItem2.Click += new System.EventHandler(this.buttonBequalsA_Click);
            // 
            // buttonBequalsAMain
            // 
            this.buttonBequalsAMain.Name = "buttonBequalsAMain";
            this.buttonBequalsAMain.Size = new System.Drawing.Size(240, 26);
            this.buttonBequalsAMain.Text = "На главный экран";
            this.buttonBequalsAMain.Click += new System.EventHandler(this.buttonBequalsAMain_Click);
            // 
            // buttonBequalsAToClipboard
            // 
            this.buttonBequalsAToClipboard.Name = "buttonBequalsAToClipboard";
            this.buttonBequalsAToClipboard.Size = new System.Drawing.Size(240, 26);
            this.buttonBequalsAToClipboard.Text = "В буфер обмена";
            this.buttonBequalsAToClipboard.Click += new System.EventHandler(this.buttonBequalsAToClipboard_Click);
            // 
            // buttonPersentB
            // 
            this.buttonPersentB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPersentB.Location = new System.Drawing.Point(173, 123);
            this.buttonPersentB.Name = "buttonPersentB";
            this.buttonPersentB.Size = new System.Drawing.Size(79, 24);
            this.buttonPersentB.TabIndex = 21;
            this.buttonPersentB.Text = "B%";
            this.buttonPersentB.UseVisualStyleBackColor = true;
            this.buttonPersentB.Click += new System.EventHandler(this.buttonPersentB_Click);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 3;
            this.tableLayoutPanel6.SetColumnSpan(this.tableLayoutPanel9, 5);
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel9.Controls.Add(this.buttonSubKubA, 2, 3);
            this.tableLayoutPanel9.Controls.Add(this.buttonSubKubB, 1, 3);
            this.tableLayoutPanel9.Controls.Add(this.buttonSumKub, 0, 3);
            this.tableLayoutPanel9.Controls.Add(this.buttonKubSubA, 2, 2);
            this.tableLayoutPanel9.Controls.Add(this.buttonKubSubB, 1, 2);
            this.tableLayoutPanel9.Controls.Add(this.buttonKubSum, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.buttonSubSqvsA, 2, 1);
            this.tableLayoutPanel9.Controls.Add(this.buttonSubSqvsB, 1, 1);
            this.tableLayoutPanel9.Controls.Add(this.buttonSumSqvs, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.buttonSubA, 2, 0);
            this.tableLayoutPanel9.Controls.Add(this.buttonSqvSum, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.buttonSqvSumB, 1, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(0, 150);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 4;
            this.tableLayoutPanel6.SetRowSpan(this.tableLayoutPanel9, 4);
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(429, 120);
            this.tableLayoutPanel9.TabIndex = 23;
            // 
            // buttonSubKubA
            // 
            this.buttonSubKubA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSubKubA.Location = new System.Drawing.Point(289, 93);
            this.buttonSubKubA.Name = "buttonSubKubA";
            this.buttonSubKubA.Size = new System.Drawing.Size(137, 24);
            this.buttonSubKubA.TabIndex = 11;
            this.buttonSubKubA.Text = "(B^3)-(A^3)";
            this.buttonSubKubA.UseVisualStyleBackColor = true;
            this.buttonSubKubA.Click += new System.EventHandler(this.buttonSubKubA_Click);
            // 
            // buttonSubKubB
            // 
            this.buttonSubKubB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSubKubB.Location = new System.Drawing.Point(146, 93);
            this.buttonSubKubB.Name = "buttonSubKubB";
            this.buttonSubKubB.Size = new System.Drawing.Size(137, 24);
            this.buttonSubKubB.TabIndex = 10;
            this.buttonSubKubB.Text = "(A^3)-(B^3)";
            this.buttonSubKubB.UseVisualStyleBackColor = true;
            this.buttonSubKubB.Click += new System.EventHandler(this.buttonSubKubB_Click);
            // 
            // buttonSumKub
            // 
            this.buttonSumKub.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSumKub.Location = new System.Drawing.Point(3, 93);
            this.buttonSumKub.Name = "buttonSumKub";
            this.buttonSumKub.Size = new System.Drawing.Size(137, 24);
            this.buttonSumKub.TabIndex = 9;
            this.buttonSumKub.Text = "(A^3)+(B^3)";
            this.buttonSumKub.UseVisualStyleBackColor = true;
            this.buttonSumKub.Click += new System.EventHandler(this.buttonSumKub_Click);
            // 
            // buttonKubSubA
            // 
            this.buttonKubSubA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonKubSubA.Location = new System.Drawing.Point(289, 63);
            this.buttonKubSubA.Name = "buttonKubSubA";
            this.buttonKubSubA.Size = new System.Drawing.Size(137, 24);
            this.buttonKubSubA.TabIndex = 8;
            this.buttonKubSubA.Text = "(B-A)^3";
            this.buttonKubSubA.UseVisualStyleBackColor = true;
            this.buttonKubSubA.Click += new System.EventHandler(this.buttonKubSubA_Click);
            // 
            // buttonKubSubB
            // 
            this.buttonKubSubB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonKubSubB.Location = new System.Drawing.Point(146, 63);
            this.buttonKubSubB.Name = "buttonKubSubB";
            this.buttonKubSubB.Size = new System.Drawing.Size(137, 24);
            this.buttonKubSubB.TabIndex = 7;
            this.buttonKubSubB.Text = "(A-B)^3";
            this.buttonKubSubB.UseVisualStyleBackColor = true;
            this.buttonKubSubB.Click += new System.EventHandler(this.buttonKubSubB_Click);
            // 
            // buttonKubSum
            // 
            this.buttonKubSum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonKubSum.Location = new System.Drawing.Point(3, 63);
            this.buttonKubSum.Name = "buttonKubSum";
            this.buttonKubSum.Size = new System.Drawing.Size(137, 24);
            this.buttonKubSum.TabIndex = 6;
            this.buttonKubSum.Text = "(A+B)^3";
            this.buttonKubSum.UseVisualStyleBackColor = true;
            this.buttonKubSum.Click += new System.EventHandler(this.buttonKubSum_Click);
            // 
            // buttonSubSqvsA
            // 
            this.buttonSubSqvsA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSubSqvsA.Location = new System.Drawing.Point(289, 33);
            this.buttonSubSqvsA.Name = "buttonSubSqvsA";
            this.buttonSubSqvsA.Size = new System.Drawing.Size(137, 24);
            this.buttonSubSqvsA.TabIndex = 5;
            this.buttonSubSqvsA.Text = "(B^2)-(A^2)";
            this.buttonSubSqvsA.UseVisualStyleBackColor = true;
            this.buttonSubSqvsA.Click += new System.EventHandler(this.buttonSubSqvsA_Click);
            // 
            // buttonSubSqvsB
            // 
            this.buttonSubSqvsB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSubSqvsB.Location = new System.Drawing.Point(146, 33);
            this.buttonSubSqvsB.Name = "buttonSubSqvsB";
            this.buttonSubSqvsB.Size = new System.Drawing.Size(137, 24);
            this.buttonSubSqvsB.TabIndex = 4;
            this.buttonSubSqvsB.Text = "(A^2)-(B^2)";
            this.buttonSubSqvsB.UseVisualStyleBackColor = true;
            this.buttonSubSqvsB.Click += new System.EventHandler(this.buttonSubSqvsB_Click);
            // 
            // buttonSumSqvs
            // 
            this.buttonSumSqvs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSumSqvs.Location = new System.Drawing.Point(3, 33);
            this.buttonSumSqvs.Name = "buttonSumSqvs";
            this.buttonSumSqvs.Size = new System.Drawing.Size(137, 24);
            this.buttonSumSqvs.TabIndex = 3;
            this.buttonSumSqvs.Text = "(A^2)+(B^2)";
            this.buttonSumSqvs.UseVisualStyleBackColor = true;
            this.buttonSumSqvs.Click += new System.EventHandler(this.buttonSumSqvs_Click);
            // 
            // buttonSubA
            // 
            this.buttonSubA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSubA.Location = new System.Drawing.Point(289, 3);
            this.buttonSubA.Name = "buttonSubA";
            this.buttonSubA.Size = new System.Drawing.Size(137, 24);
            this.buttonSubA.TabIndex = 2;
            this.buttonSubA.Text = "(B-A)^2";
            this.buttonSubA.UseVisualStyleBackColor = true;
            this.buttonSubA.Click += new System.EventHandler(this.buttonSubA_Click);
            // 
            // buttonSqvSum
            // 
            this.buttonSqvSum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqvSum.Location = new System.Drawing.Point(3, 3);
            this.buttonSqvSum.Name = "buttonSqvSum";
            this.buttonSqvSum.Size = new System.Drawing.Size(137, 24);
            this.buttonSqvSum.TabIndex = 0;
            this.buttonSqvSum.Text = "(A+B)^2";
            this.buttonSqvSum.UseVisualStyleBackColor = true;
            this.buttonSqvSum.Click += new System.EventHandler(this.buttonSqvSum_Click);
            // 
            // buttonSqvSumB
            // 
            this.buttonSqvSumB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqvSumB.Location = new System.Drawing.Point(146, 3);
            this.buttonSqvSumB.Name = "buttonSqvSumB";
            this.buttonSqvSumB.Size = new System.Drawing.Size(137, 24);
            this.buttonSqvSumB.TabIndex = 1;
            this.buttonSqvSumB.Text = "(A-B)^2";
            this.buttonSqvSumB.UseVisualStyleBackColor = true;
            this.buttonSqvSumB.Click += new System.EventHandler(this.buttonSqvSumB_Click);
            // 
            // buttonAMinesBPersent
            // 
            this.buttonAMinesBPersent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAMinesBPersent.Location = new System.Drawing.Point(3, 273);
            this.buttonAMinesBPersent.Name = "buttonAMinesBPersent";
            this.buttonAMinesBPersent.Size = new System.Drawing.Size(79, 24);
            this.buttonAMinesBPersent.TabIndex = 24;
            this.buttonAMinesBPersent.Text = "A-B%";
            this.buttonAMinesBPersent.UseVisualStyleBackColor = true;
            this.buttonAMinesBPersent.Click += new System.EventHandler(this.buttonAMinesBPersent_Click);
            // 
            // buttonAPlusBPersent
            // 
            this.buttonAPlusBPersent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAPlusBPersent.Location = new System.Drawing.Point(88, 273);
            this.buttonAPlusBPersent.Name = "buttonAPlusBPersent";
            this.buttonAPlusBPersent.Size = new System.Drawing.Size(79, 24);
            this.buttonAPlusBPersent.TabIndex = 24;
            this.buttonAPlusBPersent.Text = "A+B%";
            this.buttonAPlusBPersent.UseVisualStyleBackColor = true;
            this.buttonAPlusBPersent.Click += new System.EventHandler(this.buttonAPlusBPersent_Click);
            // 
            // buttonBMinesAPersent
            // 
            this.buttonBMinesAPersent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBMinesAPersent.Location = new System.Drawing.Point(173, 273);
            this.buttonBMinesAPersent.Name = "buttonBMinesAPersent";
            this.buttonBMinesAPersent.Size = new System.Drawing.Size(79, 24);
            this.buttonBMinesAPersent.TabIndex = 24;
            this.buttonBMinesAPersent.Text = "B-A%";
            this.buttonBMinesAPersent.UseVisualStyleBackColor = true;
            this.buttonBMinesAPersent.Click += new System.EventHandler(this.buttonBMinesAPersent_Click);
            // 
            // buttonBPlusAPersent
            // 
            this.buttonBPlusAPersent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBPlusAPersent.Location = new System.Drawing.Point(258, 273);
            this.buttonBPlusAPersent.Name = "buttonBPlusAPersent";
            this.buttonBPlusAPersent.Size = new System.Drawing.Size(79, 24);
            this.buttonBPlusAPersent.TabIndex = 24;
            this.buttonBPlusAPersent.Text = "B+A%";
            this.buttonBPlusAPersent.UseVisualStyleBackColor = true;
            this.buttonBPlusAPersent.Click += new System.EventHandler(this.buttonBPlusAPersent_Click);
            // 
            // buttonMaxAB
            // 
            this.buttonMaxAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMaxAB.Location = new System.Drawing.Point(343, 273);
            this.buttonMaxAB.Name = "buttonMaxAB";
            this.buttonMaxAB.Size = new System.Drawing.Size(83, 24);
            this.buttonMaxAB.TabIndex = 24;
            this.buttonMaxAB.Text = "Max(A, B)";
            this.buttonMaxAB.UseVisualStyleBackColor = true;
            this.buttonMaxAB.Click += new System.EventHandler(this.buttonMaxAB_Click);
            // 
            // buttonADivBPersent
            // 
            this.buttonADivBPersent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonADivBPersent.Location = new System.Drawing.Point(3, 303);
            this.buttonADivBPersent.Name = "buttonADivBPersent";
            this.buttonADivBPersent.Size = new System.Drawing.Size(79, 24);
            this.buttonADivBPersent.TabIndex = 24;
            this.buttonADivBPersent.Text = "A/B%";
            this.buttonADivBPersent.UseVisualStyleBackColor = true;
            this.buttonADivBPersent.Click += new System.EventHandler(this.buttonADivBPersent_Click);
            // 
            // buttonAMullBPersent
            // 
            this.buttonAMullBPersent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAMullBPersent.Location = new System.Drawing.Point(88, 303);
            this.buttonAMullBPersent.Name = "buttonAMullBPersent";
            this.buttonAMullBPersent.Size = new System.Drawing.Size(79, 24);
            this.buttonAMullBPersent.TabIndex = 24;
            this.buttonAMullBPersent.Text = "A*B%";
            this.buttonAMullBPersent.UseVisualStyleBackColor = true;
            this.buttonAMullBPersent.Click += new System.EventHandler(this.buttonAMullBPersent_Click);
            // 
            // buttonBDivAPersent
            // 
            this.buttonBDivAPersent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBDivAPersent.Location = new System.Drawing.Point(173, 303);
            this.buttonBDivAPersent.Name = "buttonBDivAPersent";
            this.buttonBDivAPersent.Size = new System.Drawing.Size(79, 24);
            this.buttonBDivAPersent.TabIndex = 24;
            this.buttonBDivAPersent.Text = "B/A%";
            this.buttonBDivAPersent.UseVisualStyleBackColor = true;
            this.buttonBDivAPersent.Click += new System.EventHandler(this.buttonBDivAPersent_Click);
            // 
            // buttonBMulAPersent
            // 
            this.buttonBMulAPersent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBMulAPersent.Location = new System.Drawing.Point(258, 303);
            this.buttonBMulAPersent.Name = "buttonBMulAPersent";
            this.buttonBMulAPersent.Size = new System.Drawing.Size(79, 24);
            this.buttonBMulAPersent.TabIndex = 24;
            this.buttonBMulAPersent.Text = "B*A%";
            this.buttonBMulAPersent.UseVisualStyleBackColor = true;
            this.buttonBMulAPersent.Click += new System.EventHandler(this.buttonBMulAPersent_Click);
            // 
            // buttonMinAB
            // 
            this.buttonMinAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMinAB.Location = new System.Drawing.Point(343, 303);
            this.buttonMinAB.Name = "buttonMinAB";
            this.buttonMinAB.Size = new System.Drawing.Size(83, 24);
            this.buttonMinAB.TabIndex = 24;
            this.buttonMinAB.Text = "Min(A, B)";
            this.buttonMinAB.UseVisualStyleBackColor = true;
            this.buttonMinAB.Click += new System.EventHandler(this.buttonMinAB_Click);
            // 
            // buttonAvgAB
            // 
            this.tableLayoutPanel6.SetColumnSpan(this.buttonAvgAB, 2);
            this.buttonAvgAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAvgAB.Location = new System.Drawing.Point(3, 333);
            this.buttonAvgAB.Name = "buttonAvgAB";
            this.buttonAvgAB.Size = new System.Drawing.Size(164, 34);
            this.buttonAvgAB.TabIndex = 24;
            this.buttonAvgAB.Text = "Среднее(A, B)";
            this.buttonAvgAB.UseVisualStyleBackColor = true;
            this.buttonAvgAB.Click += new System.EventHandler(this.buttonAvgAB_Click);
            // 
            // buttonRAB
            // 
            this.tableLayoutPanel6.SetColumnSpan(this.buttonRAB, 2);
            this.buttonRAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRAB.Location = new System.Drawing.Point(258, 333);
            this.buttonRAB.Name = "buttonRAB";
            this.buttonRAB.Size = new System.Drawing.Size(168, 34);
            this.buttonRAB.TabIndex = 24;
            this.buttonRAB.Text = "Размах(A, B)";
            this.buttonRAB.UseVisualStyleBackColor = true;
            this.buttonRAB.Click += new System.EventHandler(this.buttonRAB_Click);
            // 
            // buttonChangeAB
            // 
            this.buttonChangeAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonChangeAB.Location = new System.Drawing.Point(173, 333);
            this.buttonChangeAB.Name = "buttonChangeAB";
            this.buttonChangeAB.Size = new System.Drawing.Size(79, 34);
            this.buttonChangeAB.TabIndex = 25;
            this.buttonChangeAB.Text = "A↔B";
            this.buttonChangeAB.UseVisualStyleBackColor = true;
            this.buttonChangeAB.Click += new System.EventHandler(this.buttonChangeAB_Click);
            // 
            // buttonStepenAB
            // 
            this.buttonStepenAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonStepenAB.Location = new System.Drawing.Point(3, 93);
            this.buttonStepenAB.Name = "buttonStepenAB";
            this.buttonStepenAB.Size = new System.Drawing.Size(79, 24);
            this.buttonStepenAB.TabIndex = 26;
            this.buttonStepenAB.Text = "A\\B";
            this.buttonStepenAB.UseVisualStyleBackColor = true;
            this.buttonStepenAB.Click += new System.EventHandler(this.buttonStepenAB_Click);
            // 
            // buttonStepenBA
            // 
            this.buttonStepenBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonStepenBA.Location = new System.Drawing.Point(88, 93);
            this.buttonStepenBA.Name = "buttonStepenBA";
            this.buttonStepenBA.Size = new System.Drawing.Size(79, 24);
            this.buttonStepenBA.TabIndex = 26;
            this.buttonStepenBA.Text = "B\\A";
            this.buttonStepenBA.UseVisualStyleBackColor = true;
            this.buttonStepenBA.Click += new System.EventHandler(this.buttonStepenBA_Click);
            // 
            // buttonStepen1AB
            // 
            this.buttonStepen1AB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonStepen1AB.Location = new System.Drawing.Point(173, 93);
            this.buttonStepen1AB.Name = "buttonStepen1AB";
            this.buttonStepen1AB.Size = new System.Drawing.Size(79, 24);
            this.buttonStepen1AB.TabIndex = 26;
            this.buttonStepen1AB.Text = "A-/-B";
            this.buttonStepen1AB.UseVisualStyleBackColor = true;
            this.buttonStepen1AB.Click += new System.EventHandler(this.buttonStepenAB_Click);
            // 
            // buttonStepen1BA
            // 
            this.buttonStepen1BA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonStepen1BA.Location = new System.Drawing.Point(258, 93);
            this.buttonStepen1BA.Name = "buttonStepen1BA";
            this.buttonStepen1BA.Size = new System.Drawing.Size(79, 24);
            this.buttonStepen1BA.TabIndex = 26;
            this.buttonStepen1BA.Text = "B-/-A";
            this.buttonStepen1BA.UseVisualStyleBackColor = true;
            this.buttonStepen1BA.Click += new System.EventHandler(this.buttonStepenBA_Click);
            // 
            // groupBox45
            // 
            this.groupBox45.Controls.Add(this.tableLayoutPanel48);
            this.groupBox45.Location = new System.Drawing.Point(3, 379);
            this.groupBox45.Name = "groupBox45";
            this.groupBox45.Size = new System.Drawing.Size(429, 280);
            this.groupBox45.TabIndex = 1;
            this.groupBox45.TabStop = false;
            this.groupBox45.Text = "Гибкие функции";
            // 
            // tableLayoutPanel48
            // 
            this.tableLayoutPanel48.ColumnCount = 4;
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel48.Controls.Add(this.menuStrip5, 2, 2);
            this.tableLayoutPanel48.Controls.Add(this.menuStrip4, 1, 3);
            this.tableLayoutPanel48.Controls.Add(this.groupBox54, 3, 1);
            this.tableLayoutPanel48.Controls.Add(this.groupBox53, 2, 1);
            this.tableLayoutPanel48.Controls.Add(this.groupBox52, 2, 0);
            this.tableLayoutPanel48.Controls.Add(this.groupBox50, 1, 2);
            this.tableLayoutPanel48.Controls.Add(this.groupBox51, 0, 2);
            this.tableLayoutPanel48.Controls.Add(this.groupBox49, 1, 1);
            this.tableLayoutPanel48.Controls.Add(this.groupBox47, 1, 0);
            this.tableLayoutPanel48.Controls.Add(this.groupBox46, 0, 0);
            this.tableLayoutPanel48.Controls.Add(this.groupBox48, 0, 1);
            this.tableLayoutPanel48.Controls.Add(this.menuStrip3, 0, 3);
            this.tableLayoutPanel48.Controls.Add(this.buttonBynarCalculate, 2, 3);
            this.tableLayoutPanel48.Controls.Add(this.textBoxIndexes, 3, 2);
            this.tableLayoutPanel48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel48.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel48.Name = "tableLayoutPanel48";
            this.tableLayoutPanel48.RowCount = 4;
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel48.Size = new System.Drawing.Size(423, 254);
            this.tableLayoutPanel48.TabIndex = 0;
            // 
            // menuStrip5
            // 
            this.menuStrip5.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7});
            this.menuStrip5.Location = new System.Drawing.Point(210, 148);
            this.menuStrip5.Name = "menuStrip5";
            this.menuStrip5.Size = new System.Drawing.Size(105, 30);
            this.menuStrip5.TabIndex = 12;
            this.menuStrip5.Text = "menuStrip5";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem8,
            this.deleteResult,
            this.addResult});
            this.toolStripMenuItem7.Font = new System.Drawing.Font("Lucida Console", 7.8F);
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(85, 26);
            this.toolStripMenuItem7.Text = "Действие";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runPastResult,
            this.runNextResult});
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(152, 26);
            this.toolStripMenuItem8.Text = "Перейти";
            // 
            // runPastResult
            // 
            this.runPastResult.Name = "runPastResult";
            this.runPastResult.Size = new System.Drawing.Size(192, 26);
            this.runPastResult.Text = "На предыдущую";
            this.runPastResult.Click += new System.EventHandler(this.runPastResult_Click);
            // 
            // runNextResult
            // 
            this.runNextResult.Name = "runNextResult";
            this.runNextResult.Size = new System.Drawing.Size(192, 26);
            this.runNextResult.Text = "На следующую";
            this.runNextResult.Click += new System.EventHandler(this.runNextResult_Click);
            // 
            // deleteResult
            // 
            this.deleteResult.Name = "deleteResult";
            this.deleteResult.Size = new System.Drawing.Size(152, 26);
            this.deleteResult.Text = "Удалить";
            this.deleteResult.Click += new System.EventHandler(this.deleteResult_Click);
            // 
            // addResult
            // 
            this.addResult.Name = "addResult";
            this.addResult.Size = new System.Drawing.Size(152, 26);
            this.addResult.Text = "Добавить";
            this.addResult.Click += new System.EventHandler(this.addResult_Click);
            // 
            // menuStrip4
            // 
            this.menuStrip4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip4.Location = new System.Drawing.Point(105, 222);
            this.menuStrip4.Name = "menuStrip4";
            this.menuStrip4.Size = new System.Drawing.Size(105, 30);
            this.menuStrip4.TabIndex = 11;
            this.menuStrip4.Text = "menuStrip4";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.delete2,
            this.add2});
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Lucida Console", 7.8F);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(85, 26);
            this.toolStripMenuItem1.Text = "Действие";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runPast2,
            this.runNext2});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(152, 26);
            this.toolStripMenuItem2.Text = "Перейти";
            // 
            // runPast2
            // 
            this.runPast2.Name = "runPast2";
            this.runPast2.Size = new System.Drawing.Size(192, 26);
            this.runPast2.Text = "На предыдущую";
            this.runPast2.Click += new System.EventHandler(this.runPast2_Click);
            // 
            // runNext2
            // 
            this.runNext2.Name = "runNext2";
            this.runNext2.Size = new System.Drawing.Size(192, 26);
            this.runNext2.Text = "На следующую";
            this.runNext2.Click += new System.EventHandler(this.runNext2_Click);
            // 
            // delete2
            // 
            this.delete2.Name = "delete2";
            this.delete2.Size = new System.Drawing.Size(152, 26);
            this.delete2.Text = "Удалить";
            this.delete2.Click += new System.EventHandler(this.delete2_Click);
            // 
            // add2
            // 
            this.add2.Name = "add2";
            this.add2.Size = new System.Drawing.Size(152, 26);
            this.add2.Text = "Добавить";
            this.add2.Click += new System.EventHandler(this.add2_Click);
            // 
            // groupBox54
            // 
            this.groupBox54.Controls.Add(this.comboBoxResultTo);
            this.groupBox54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox54.Location = new System.Drawing.Point(318, 77);
            this.groupBox54.Name = "groupBox54";
            this.groupBox54.Size = new System.Drawing.Size(102, 68);
            this.groupBox54.TabIndex = 8;
            this.groupBox54.TabStop = false;
            this.groupBox54.Text = "Результат в (z)";
            // 
            // comboBoxResultTo
            // 
            this.comboBoxResultTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxResultTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxResultTo.DropDownWidth = 200;
            this.comboBoxResultTo.FormattingEnabled = true;
            this.comboBoxResultTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxResultTo.Name = "comboBoxResultTo";
            this.comboBoxResultTo.Size = new System.Drawing.Size(96, 24);
            this.comboBoxResultTo.TabIndex = 0;
            this.comboBoxResultTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxResultTo_MySeclectedIndexChanged);
            // 
            // groupBox53
            // 
            this.groupBox53.Controls.Add(this.comboBoxResultFrom);
            this.groupBox53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox53.Location = new System.Drawing.Point(213, 77);
            this.groupBox53.Name = "groupBox53";
            this.groupBox53.Size = new System.Drawing.Size(99, 68);
            this.groupBox53.TabIndex = 7;
            this.groupBox53.TabStop = false;
            this.groupBox53.Text = "Результат из (z)";
            // 
            // comboBoxResultFrom
            // 
            this.comboBoxResultFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxResultFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxResultFrom.DropDownWidth = 200;
            this.comboBoxResultFrom.FormattingEnabled = true;
            this.comboBoxResultFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxResultFrom.Name = "comboBoxResultFrom";
            this.comboBoxResultFrom.Size = new System.Drawing.Size(93, 24);
            this.comboBoxResultFrom.TabIndex = 0;
            this.comboBoxResultFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxResultFrom_MySeclectedIndexChanged);
            // 
            // groupBox52
            // 
            this.tableLayoutPanel48.SetColumnSpan(this.groupBox52, 2);
            this.groupBox52.Controls.Add(this.comboBoxBynarCalculate);
            this.groupBox52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox52.Location = new System.Drawing.Point(213, 3);
            this.groupBox52.Name = "groupBox52";
            this.groupBox52.Size = new System.Drawing.Size(207, 68);
            this.groupBox52.TabIndex = 6;
            this.groupBox52.TabStop = false;
            this.groupBox52.Text = "Вычислить";
            // 
            // comboBoxBynarCalculate
            // 
            this.comboBoxBynarCalculate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxBynarCalculate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBynarCalculate.DropDownWidth = 200;
            this.comboBoxBynarCalculate.FormattingEnabled = true;
            this.comboBoxBynarCalculate.Location = new System.Drawing.Point(3, 23);
            this.comboBoxBynarCalculate.Name = "comboBoxBynarCalculate";
            this.comboBoxBynarCalculate.Size = new System.Drawing.Size(201, 24);
            this.comboBoxBynarCalculate.TabIndex = 0;
            this.comboBoxBynarCalculate.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxBynarCalculate_MySeclectedIndexChanged);
            // 
            // groupBox50
            // 
            this.groupBox50.Controls.Add(this.comboBox2To);
            this.groupBox50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox50.Location = new System.Drawing.Point(108, 151);
            this.groupBox50.Name = "groupBox50";
            this.groupBox50.Size = new System.Drawing.Size(99, 68);
            this.groupBox50.TabIndex = 5;
            this.groupBox50.TabStop = false;
            this.groupBox50.Text = "y в (y=z)";
            // 
            // comboBox2To
            // 
            this.comboBox2To.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox2To.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2To.DropDownWidth = 200;
            this.comboBox2To.FormattingEnabled = true;
            this.comboBox2To.Location = new System.Drawing.Point(3, 23);
            this.comboBox2To.Name = "comboBox2To";
            this.comboBox2To.Size = new System.Drawing.Size(93, 24);
            this.comboBox2To.TabIndex = 0;
            this.comboBox2To.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBox2To_MySeclectedIndexChanged);
            // 
            // groupBox51
            // 
            this.groupBox51.Controls.Add(this.comboBox1To);
            this.groupBox51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox51.Location = new System.Drawing.Point(3, 151);
            this.groupBox51.Name = "groupBox51";
            this.groupBox51.Size = new System.Drawing.Size(99, 68);
            this.groupBox51.TabIndex = 4;
            this.groupBox51.TabStop = false;
            this.groupBox51.Text = "x в (x=z)";
            // 
            // comboBox1To
            // 
            this.comboBox1To.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox1To.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1To.DropDownWidth = 200;
            this.comboBox1To.FormattingEnabled = true;
            this.comboBox1To.Location = new System.Drawing.Point(3, 23);
            this.comboBox1To.Name = "comboBox1To";
            this.comboBox1To.Size = new System.Drawing.Size(93, 24);
            this.comboBox1To.TabIndex = 0;
            this.comboBox1To.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBox1To_MySeclectedIndexChanged);
            // 
            // groupBox49
            // 
            this.groupBox49.Controls.Add(this.comboBox2From);
            this.groupBox49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox49.Location = new System.Drawing.Point(108, 77);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Size = new System.Drawing.Size(99, 68);
            this.groupBox49.TabIndex = 3;
            this.groupBox49.TabStop = false;
            this.groupBox49.Text = "y из (y=z)";
            // 
            // comboBox2From
            // 
            this.comboBox2From.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox2From.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2From.DropDownWidth = 200;
            this.comboBox2From.FormattingEnabled = true;
            this.comboBox2From.Location = new System.Drawing.Point(3, 23);
            this.comboBox2From.Name = "comboBox2From";
            this.comboBox2From.Size = new System.Drawing.Size(93, 24);
            this.comboBox2From.TabIndex = 0;
            this.comboBox2From.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBox2From_MySeclectedIndexChanged);
            // 
            // groupBox47
            // 
            this.groupBox47.Controls.Add(this.tableLayoutPanel50);
            this.groupBox47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox47.Location = new System.Drawing.Point(108, 3);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Size = new System.Drawing.Size(99, 68);
            this.groupBox47.TabIndex = 1;
            this.groupBox47.TabStop = false;
            this.groupBox47.Text = "y=";
            // 
            // tableLayoutPanel50
            // 
            this.tableLayoutPanel50.ColumnCount = 2;
            this.tableLayoutPanel50.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel50.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel50.Controls.Add(this.radioBynarInputY1, 0, 1);
            this.tableLayoutPanel50.Controls.Add(this.radioBynarInputY0, 0, 1);
            this.tableLayoutPanel50.Controls.Add(this.radioBynarInputYB, 1, 0);
            this.tableLayoutPanel50.Controls.Add(this.radioBynarInputYA, 0, 0);
            this.tableLayoutPanel50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel50.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel50.Name = "tableLayoutPanel50";
            this.tableLayoutPanel50.RowCount = 2;
            this.tableLayoutPanel50.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel50.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel50.Size = new System.Drawing.Size(93, 42);
            this.tableLayoutPanel50.TabIndex = 0;
            // 
            // radioBynarInputY1
            // 
            this.radioBynarInputY1.AutoSize = true;
            this.radioBynarInputY1.Location = new System.Drawing.Point(3, 24);
            this.radioBynarInputY1.Name = "radioBynarInputY1";
            this.radioBynarInputY1.Size = new System.Drawing.Size(36, 15);
            this.radioBynarInputY1.TabIndex = 3;
            this.radioBynarInputY1.Text = "1";
            this.radioBynarInputY1.UseVisualStyleBackColor = true;
            // 
            // radioBynarInputY0
            // 
            this.radioBynarInputY0.AutoSize = true;
            this.radioBynarInputY0.Location = new System.Drawing.Point(49, 24);
            this.radioBynarInputY0.Name = "radioBynarInputY0";
            this.radioBynarInputY0.Size = new System.Drawing.Size(36, 15);
            this.radioBynarInputY0.TabIndex = 2;
            this.radioBynarInputY0.Text = "0";
            this.radioBynarInputY0.UseVisualStyleBackColor = true;
            // 
            // radioBynarInputYB
            // 
            this.radioBynarInputYB.AutoSize = true;
            this.radioBynarInputYB.Checked = true;
            this.radioBynarInputYB.Location = new System.Drawing.Point(49, 3);
            this.radioBynarInputYB.Name = "radioBynarInputYB";
            this.radioBynarInputYB.Size = new System.Drawing.Size(35, 15);
            this.radioBynarInputYB.TabIndex = 1;
            this.radioBynarInputYB.TabStop = true;
            this.radioBynarInputYB.Text = "B";
            this.radioBynarInputYB.UseVisualStyleBackColor = true;
            // 
            // radioBynarInputYA
            // 
            this.radioBynarInputYA.AutoSize = true;
            this.radioBynarInputYA.Location = new System.Drawing.Point(3, 3);
            this.radioBynarInputYA.Name = "radioBynarInputYA";
            this.radioBynarInputYA.Size = new System.Drawing.Size(37, 15);
            this.radioBynarInputYA.TabIndex = 0;
            this.radioBynarInputYA.Text = "A";
            this.radioBynarInputYA.UseVisualStyleBackColor = true;
            // 
            // groupBox46
            // 
            this.groupBox46.Controls.Add(this.tableLayoutPanel49);
            this.groupBox46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox46.Location = new System.Drawing.Point(3, 3);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Size = new System.Drawing.Size(99, 68);
            this.groupBox46.TabIndex = 0;
            this.groupBox46.TabStop = false;
            this.groupBox46.Text = "x=";
            // 
            // tableLayoutPanel49
            // 
            this.tableLayoutPanel49.ColumnCount = 2;
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel49.Controls.Add(this.radioBynarInputX1, 1, 1);
            this.tableLayoutPanel49.Controls.Add(this.radioBynarInputX0, 0, 1);
            this.tableLayoutPanel49.Controls.Add(this.radioBynarInputXB, 1, 0);
            this.tableLayoutPanel49.Controls.Add(this.radioBynarInputXA, 0, 0);
            this.tableLayoutPanel49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel49.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel49.Name = "tableLayoutPanel49";
            this.tableLayoutPanel49.RowCount = 2;
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel49.Size = new System.Drawing.Size(93, 42);
            this.tableLayoutPanel49.TabIndex = 0;
            // 
            // radioBynarInputX1
            // 
            this.radioBynarInputX1.AutoSize = true;
            this.radioBynarInputX1.Location = new System.Drawing.Point(49, 24);
            this.radioBynarInputX1.Name = "radioBynarInputX1";
            this.radioBynarInputX1.Size = new System.Drawing.Size(36, 15);
            this.radioBynarInputX1.TabIndex = 3;
            this.radioBynarInputX1.Text = "1";
            this.radioBynarInputX1.UseVisualStyleBackColor = true;
            // 
            // radioBynarInputX0
            // 
            this.radioBynarInputX0.AutoSize = true;
            this.radioBynarInputX0.Location = new System.Drawing.Point(3, 24);
            this.radioBynarInputX0.Name = "radioBynarInputX0";
            this.radioBynarInputX0.Size = new System.Drawing.Size(36, 15);
            this.radioBynarInputX0.TabIndex = 2;
            this.radioBynarInputX0.Text = "0";
            this.radioBynarInputX0.UseVisualStyleBackColor = true;
            // 
            // radioBynarInputXB
            // 
            this.radioBynarInputXB.AutoSize = true;
            this.radioBynarInputXB.Location = new System.Drawing.Point(49, 3);
            this.radioBynarInputXB.Name = "radioBynarInputXB";
            this.radioBynarInputXB.Size = new System.Drawing.Size(35, 15);
            this.radioBynarInputXB.TabIndex = 1;
            this.radioBynarInputXB.Text = "B";
            this.radioBynarInputXB.UseVisualStyleBackColor = true;
            // 
            // radioBynarInputXA
            // 
            this.radioBynarInputXA.AutoSize = true;
            this.radioBynarInputXA.Checked = true;
            this.radioBynarInputXA.Location = new System.Drawing.Point(3, 3);
            this.radioBynarInputXA.Name = "radioBynarInputXA";
            this.radioBynarInputXA.Size = new System.Drawing.Size(37, 15);
            this.radioBynarInputXA.TabIndex = 0;
            this.radioBynarInputXA.TabStop = true;
            this.radioBynarInputXA.Text = "A";
            this.radioBynarInputXA.UseVisualStyleBackColor = true;
            // 
            // groupBox48
            // 
            this.groupBox48.Controls.Add(this.comboBox1From);
            this.groupBox48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox48.Location = new System.Drawing.Point(3, 77);
            this.groupBox48.Name = "groupBox48";
            this.groupBox48.Size = new System.Drawing.Size(99, 68);
            this.groupBox48.TabIndex = 2;
            this.groupBox48.TabStop = false;
            this.groupBox48.Text = "x из (x=z)";
            // 
            // comboBox1From
            // 
            this.comboBox1From.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox1From.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1From.DropDownWidth = 200;
            this.comboBox1From.FormattingEnabled = true;
            this.comboBox1From.Location = new System.Drawing.Point(3, 23);
            this.comboBox1From.Name = "comboBox1From";
            this.comboBox1From.Size = new System.Drawing.Size(93, 24);
            this.comboBox1From.TabIndex = 0;
            this.comboBox1From.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBox1From_MySeclectedIndexChanged);
            // 
            // menuStrip3
            // 
            this.menuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.действиеToolStripMenuItem});
            this.menuStrip3.Location = new System.Drawing.Point(0, 222);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(105, 30);
            this.menuStrip3.TabIndex = 10;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // действиеToolStripMenuItem
            // 
            this.действиеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.перейтиToolStripMenuItem,
            this.delete1,
            this.add1});
            this.действиеToolStripMenuItem.Font = new System.Drawing.Font("Lucida Console", 7.8F);
            this.действиеToolStripMenuItem.Name = "действиеToolStripMenuItem";
            this.действиеToolStripMenuItem.Size = new System.Drawing.Size(85, 26);
            this.действиеToolStripMenuItem.Text = "Действие";
            // 
            // перейтиToolStripMenuItem
            // 
            this.перейтиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runPast1,
            this.runNext1});
            this.перейтиToolStripMenuItem.Name = "перейтиToolStripMenuItem";
            this.перейтиToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.перейтиToolStripMenuItem.Text = "Перейти";
            // 
            // runPast1
            // 
            this.runPast1.Name = "runPast1";
            this.runPast1.Size = new System.Drawing.Size(192, 26);
            this.runPast1.Text = "На предыдущую";
            this.runPast1.Click += new System.EventHandler(this.runPast1_Click);
            // 
            // runNext1
            // 
            this.runNext1.Name = "runNext1";
            this.runNext1.Size = new System.Drawing.Size(192, 26);
            this.runNext1.Text = "На следующую";
            this.runNext1.Click += new System.EventHandler(this.runNext1_Click);
            // 
            // delete1
            // 
            this.delete1.Name = "delete1";
            this.delete1.Size = new System.Drawing.Size(152, 26);
            this.delete1.Text = "Удалить";
            this.delete1.Click += new System.EventHandler(this.delete1_Click);
            // 
            // add1
            // 
            this.add1.Name = "add1";
            this.add1.Size = new System.Drawing.Size(152, 26);
            this.add1.Text = "Добавить";
            this.add1.Click += new System.EventHandler(this.add1_Click);
            // 
            // buttonBynarCalculate
            // 
            this.tableLayoutPanel48.SetColumnSpan(this.buttonBynarCalculate, 2);
            this.buttonBynarCalculate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBynarCalculate.Location = new System.Drawing.Point(213, 225);
            this.buttonBynarCalculate.Name = "buttonBynarCalculate";
            this.buttonBynarCalculate.Size = new System.Drawing.Size(207, 26);
            this.buttonBynarCalculate.TabIndex = 9;
            this.buttonBynarCalculate.Text = "Вычислить";
            this.buttonBynarCalculate.UseVisualStyleBackColor = true;
            this.buttonBynarCalculate.Click += new System.EventHandler(this.buttonBynarCalculate_Click);
            // 
            // textBoxIndexes
            // 
            this.textBoxIndexes.BackColor = System.Drawing.Color.White;
            this.textBoxIndexes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxIndexes.Location = new System.Drawing.Point(318, 151);
            this.textBoxIndexes.Name = "textBoxIndexes";
            this.textBoxIndexes.ReadOnly = true;
            this.textBoxIndexes.Size = new System.Drawing.Size(102, 27);
            this.textBoxIndexes.TabIndex = 13;
            this.textBoxIndexes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.flowLayoutPanel4);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.groupBox3.Location = new System.Drawing.Point(3, 257);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(447, 139);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Унарно вычислить выходной параметр";
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.AutoScroll = true;
            this.flowLayoutPanel4.BackColor = System.Drawing.Color.Transparent;
            this.flowLayoutPanel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowLayoutPanel4.Controls.Add(this.tableLayoutPanel7);
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel4.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(3, 24);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(441, 112);
            this.flowLayoutPanel4.TabIndex = 0;
            this.flowLayoutPanel4.WrapContents = false;
            this.flowLayoutPanel4.SizeChanged += new System.EventHandler(this.flowLayoutPanelInputB_SizeChanged);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 5;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel7.Controls.Add(this.buttonSgnB, 2, 8);
            this.tableLayoutPanel7.Controls.Add(this.buttonIntA, 3, 7);
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel51, 2, 3);
            this.tableLayoutPanel7.Controls.Add(this.buttonLgB, 2, 5);
            this.tableLayoutPanel7.Controls.Add(this.buttonLgA, 3, 5);
            this.tableLayoutPanel7.Controls.Add(this.buttonLnA, 1, 5);
            this.tableLayoutPanel7.Controls.Add(this.buttonPowEA, 3, 4);
            this.tableLayoutPanel7.Controls.Add(this.buttonPowEB, 2, 4);
            this.tableLayoutPanel7.Controls.Add(this.buttonRetA, 1, 4);
            this.tableLayoutPanel7.Controls.Add(this.buttonRetB, 0, 4);
            this.tableLayoutPanel7.Controls.Add(this.buttonMul2B, 3, 2);
            this.tableLayoutPanel7.Controls.Add(this.buttonDiv2B, 2, 2);
            this.tableLayoutPanel7.Controls.Add(this.buttonA1, 4, 4);
            this.tableLayoutPanel7.Controls.Add(this.buttonSqrtA, 1, 2);
            this.tableLayoutPanel7.Controls.Add(this.buttonSqrtB, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.buttonPow2, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonPow3, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonPowA2, 2, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonPowA3, 3, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonIncA, 4, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonDecA, 4, 1);
            this.tableLayoutPanel7.Controls.Add(this.buttonPow2B, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.buttonPow2A, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.buttonMulB2, 2, 1);
            this.tableLayoutPanel7.Controls.Add(this.buttonMul2A, 3, 1);
            this.tableLayoutPanel7.Controls.Add(this.buttonB1, 4, 2);
            this.tableLayoutPanel7.Controls.Add(this.buttonLnB, 0, 5);
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel8, 4, 5);
            this.tableLayoutPanel7.Controls.Add(this.buttonClickView29, 0, 3);
            this.tableLayoutPanel7.Controls.Add(this.buttonClickView30, 1, 3);
            this.tableLayoutPanel7.Controls.Add(this.buttonPlusB1, 0, 6);
            this.tableLayoutPanel7.Controls.Add(this.buttonMines1B, 1, 6);
            this.tableLayoutPanel7.Controls.Add(this.buttonPersent1A, 2, 6);
            this.tableLayoutPanel7.Controls.Add(this.buttonPersent1B, 3, 6);
            this.tableLayoutPanel7.Controls.Add(this.button1AB, 4, 6);
            this.tableLayoutPanel7.Controls.Add(this.buttonIntB, 0, 7);
            this.tableLayoutPanel7.Controls.Add(this.buttonDrobB, 0, 8);
            this.tableLayoutPanel7.Controls.Add(this.buttonDrobA, 3, 8);
            this.tableLayoutPanel7.Controls.Add(this.buttonSgnA, 2, 7);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 9;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11038F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11038F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11038F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11038F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11038F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11038F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.1126F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11403F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(409, 311);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // buttonSgnB
            // 
            this.buttonSgnB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSgnB.Location = new System.Drawing.Point(165, 275);
            this.buttonSgnB.Name = "buttonSgnB";
            this.buttonSgnB.Size = new System.Drawing.Size(75, 33);
            this.buttonSgnB.TabIndex = 32;
            this.buttonSgnB.Text = "Sgn(B)";
            this.buttonSgnB.UseVisualStyleBackColor = true;
            this.buttonSgnB.Click += new System.EventHandler(this.buttonSgnB_Click);
            // 
            // buttonIntA
            // 
            this.tableLayoutPanel7.SetColumnSpan(this.buttonIntA, 2);
            this.buttonIntA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonIntA.Location = new System.Drawing.Point(246, 241);
            this.buttonIntA.Name = "buttonIntA";
            this.buttonIntA.Size = new System.Drawing.Size(160, 28);
            this.buttonIntA.TabIndex = 30;
            this.buttonIntA.Text = "Целая часть A";
            this.buttonIntA.UseVisualStyleBackColor = true;
            this.buttonIntA.Click += new System.EventHandler(this.buttonIntA_Click);
            // 
            // tableLayoutPanel51
            // 
            this.tableLayoutPanel51.ColumnCount = 4;
            this.tableLayoutPanel7.SetColumnSpan(this.tableLayoutPanel51, 3);
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel51.Controls.Add(this.buttonAbsBM, 0, 0);
            this.tableLayoutPanel51.Controls.Add(this.buttonAbsAM, 1, 0);
            this.tableLayoutPanel51.Controls.Add(this.buttonClickView31, 2, 0);
            this.tableLayoutPanel51.Controls.Add(this.buttonClickView32, 3, 0);
            this.tableLayoutPanel51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel51.Location = new System.Drawing.Point(162, 102);
            this.tableLayoutPanel51.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel51.Name = "tableLayoutPanel51";
            this.tableLayoutPanel51.RowCount = 1;
            this.tableLayoutPanel51.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel51.Size = new System.Drawing.Size(247, 34);
            this.tableLayoutPanel51.TabIndex = 27;
            // 
            // buttonAbsBM
            // 
            this.buttonAbsBM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAbsBM.Location = new System.Drawing.Point(3, 3);
            this.buttonAbsBM.Name = "buttonAbsBM";
            this.buttonAbsBM.Size = new System.Drawing.Size(55, 28);
            this.buttonAbsBM.TabIndex = 26;
            this.buttonAbsBM.Text = "-|B|";
            this.buttonAbsBM.UseVisualStyleBackColor = true;
            this.buttonAbsBM.Click += new System.EventHandler(this.buttonAbsBM_Click);
            // 
            // buttonAbsAM
            // 
            this.buttonAbsAM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAbsAM.Location = new System.Drawing.Point(64, 3);
            this.buttonAbsAM.Name = "buttonAbsAM";
            this.buttonAbsAM.Size = new System.Drawing.Size(55, 28);
            this.buttonAbsAM.TabIndex = 16;
            this.buttonAbsAM.Text = "-|A|";
            this.buttonAbsAM.UseVisualStyleBackColor = true;
            this.buttonAbsAM.Click += new System.EventHandler(this.buttonAbsAM_Click);
            // 
            // buttonClickView31
            // 
            this.buttonClickView31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView31.Location = new System.Drawing.Point(125, 3);
            this.buttonClickView31.Name = "buttonClickView31";
            this.buttonClickView31.Size = new System.Drawing.Size(55, 28);
            this.buttonClickView31.TabIndex = 18;
            this.buttonClickView31.Text = "B^(-1)";
            this.buttonClickView31.UseVisualStyleBackColor = true;
            this.buttonClickView31.Click += new System.EventHandler(this.buttonRetB_Click);
            // 
            // buttonClickView32
            // 
            this.buttonClickView32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView32.Location = new System.Drawing.Point(186, 3);
            this.buttonClickView32.Name = "buttonClickView32";
            this.buttonClickView32.Size = new System.Drawing.Size(58, 28);
            this.buttonClickView32.TabIndex = 19;
            this.buttonClickView32.Text = "A^(-1)";
            this.buttonClickView32.UseVisualStyleBackColor = true;
            this.buttonClickView32.Click += new System.EventHandler(this.buttonRetA_Click);
            // 
            // buttonLgB
            // 
            this.buttonLgB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLgB.Location = new System.Drawing.Point(165, 173);
            this.buttonLgB.Name = "buttonLgB";
            this.buttonLgB.Size = new System.Drawing.Size(75, 28);
            this.buttonLgB.TabIndex = 25;
            this.buttonLgB.Text = "Lg(B)";
            this.buttonLgB.UseVisualStyleBackColor = true;
            this.buttonLgB.Click += new System.EventHandler(this.buttonLgB_Click);
            // 
            // buttonLgA
            // 
            this.buttonLgA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLgA.Location = new System.Drawing.Point(246, 173);
            this.buttonLgA.Name = "buttonLgA";
            this.buttonLgA.Size = new System.Drawing.Size(75, 28);
            this.buttonLgA.TabIndex = 24;
            this.buttonLgA.Text = "Lg(A)";
            this.buttonLgA.UseVisualStyleBackColor = true;
            this.buttonLgA.Click += new System.EventHandler(this.buttonLgA_Click);
            // 
            // buttonLnA
            // 
            this.buttonLnA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLnA.Location = new System.Drawing.Point(84, 173);
            this.buttonLnA.Name = "buttonLnA";
            this.buttonLnA.Size = new System.Drawing.Size(75, 28);
            this.buttonLnA.TabIndex = 23;
            this.buttonLnA.Text = "Ln(A)";
            this.buttonLnA.UseVisualStyleBackColor = true;
            this.buttonLnA.Click += new System.EventHandler(this.buttonLnA_Click);
            // 
            // buttonPowEA
            // 
            this.buttonPowEA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPowEA.Location = new System.Drawing.Point(246, 139);
            this.buttonPowEA.Name = "buttonPowEA";
            this.buttonPowEA.Size = new System.Drawing.Size(75, 28);
            this.buttonPowEA.TabIndex = 21;
            this.buttonPowEA.Text = "e^A";
            this.buttonPowEA.UseVisualStyleBackColor = true;
            this.buttonPowEA.Click += new System.EventHandler(this.buttonPowEA_Click);
            // 
            // buttonPowEB
            // 
            this.buttonPowEB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPowEB.Location = new System.Drawing.Point(165, 139);
            this.buttonPowEB.Name = "buttonPowEB";
            this.buttonPowEB.Size = new System.Drawing.Size(75, 28);
            this.buttonPowEB.TabIndex = 20;
            this.buttonPowEB.Text = "e^B";
            this.buttonPowEB.UseVisualStyleBackColor = true;
            this.buttonPowEB.Click += new System.EventHandler(this.buttonPowEB_Click);
            // 
            // buttonRetA
            // 
            this.buttonRetA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRetA.Location = new System.Drawing.Point(84, 139);
            this.buttonRetA.Name = "buttonRetA";
            this.buttonRetA.Size = new System.Drawing.Size(75, 28);
            this.buttonRetA.TabIndex = 19;
            this.buttonRetA.Text = "1/A";
            this.buttonRetA.UseVisualStyleBackColor = true;
            this.buttonRetA.Click += new System.EventHandler(this.buttonRetA_Click);
            // 
            // buttonRetB
            // 
            this.buttonRetB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRetB.Location = new System.Drawing.Point(3, 139);
            this.buttonRetB.Name = "buttonRetB";
            this.buttonRetB.Size = new System.Drawing.Size(75, 28);
            this.buttonRetB.TabIndex = 18;
            this.buttonRetB.Text = "1/B";
            this.buttonRetB.UseVisualStyleBackColor = true;
            this.buttonRetB.Click += new System.EventHandler(this.buttonRetB_Click);
            // 
            // buttonMul2B
            // 
            this.buttonMul2B.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMul2B.Location = new System.Drawing.Point(246, 71);
            this.buttonMul2B.Name = "buttonMul2B";
            this.buttonMul2B.Size = new System.Drawing.Size(75, 28);
            this.buttonMul2B.TabIndex = 17;
            this.buttonMul2B.Text = "A/2";
            this.buttonMul2B.UseVisualStyleBackColor = true;
            this.buttonMul2B.Click += new System.EventHandler(this.buttonMul2B_Click);
            // 
            // buttonDiv2B
            // 
            this.buttonDiv2B.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDiv2B.Location = new System.Drawing.Point(165, 71);
            this.buttonDiv2B.Name = "buttonDiv2B";
            this.buttonDiv2B.Size = new System.Drawing.Size(75, 28);
            this.buttonDiv2B.TabIndex = 16;
            this.buttonDiv2B.Text = "B/2";
            this.buttonDiv2B.UseVisualStyleBackColor = true;
            this.buttonDiv2B.Click += new System.EventHandler(this.buttonDiv2B_Click);
            // 
            // buttonA1
            // 
            this.buttonA1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonA1.Location = new System.Drawing.Point(327, 139);
            this.buttonA1.Name = "buttonA1";
            this.buttonA1.Size = new System.Drawing.Size(79, 28);
            this.buttonA1.TabIndex = 15;
            this.buttonA1.Text = "A*(-1)";
            this.buttonA1.UseVisualStyleBackColor = true;
            this.buttonA1.Click += new System.EventHandler(this.buttonA1_Click);
            // 
            // buttonSqrtA
            // 
            this.buttonSqrtA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrtA.Location = new System.Drawing.Point(84, 71);
            this.buttonSqrtA.Name = "buttonSqrtA";
            this.buttonSqrtA.Size = new System.Drawing.Size(75, 28);
            this.buttonSqrtA.TabIndex = 13;
            this.buttonSqrtA.Text = "A^(1/2)";
            this.buttonSqrtA.UseVisualStyleBackColor = true;
            this.buttonSqrtA.Click += new System.EventHandler(this.buttonSqrtA_Click);
            // 
            // buttonSqrtB
            // 
            this.buttonSqrtB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrtB.Location = new System.Drawing.Point(3, 71);
            this.buttonSqrtB.Name = "buttonSqrtB";
            this.buttonSqrtB.Size = new System.Drawing.Size(75, 28);
            this.buttonSqrtB.TabIndex = 12;
            this.buttonSqrtB.Text = "B^(1/2)";
            this.buttonSqrtB.UseVisualStyleBackColor = true;
            this.buttonSqrtB.Click += new System.EventHandler(this.buttonSqrtB_Click);
            // 
            // buttonPow2
            // 
            this.buttonPow2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPow2.Location = new System.Drawing.Point(3, 3);
            this.buttonPow2.Name = "buttonPow2";
            this.buttonPow2.Size = new System.Drawing.Size(75, 28);
            this.buttonPow2.TabIndex = 0;
            this.buttonPow2.Text = "B^2";
            this.buttonPow2.UseVisualStyleBackColor = true;
            this.buttonPow2.Click += new System.EventHandler(this.buttonPow2_Click);
            // 
            // buttonPow3
            // 
            this.buttonPow3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPow3.Location = new System.Drawing.Point(84, 3);
            this.buttonPow3.Name = "buttonPow3";
            this.buttonPow3.Size = new System.Drawing.Size(75, 28);
            this.buttonPow3.TabIndex = 1;
            this.buttonPow3.Text = "B^3";
            this.buttonPow3.UseVisualStyleBackColor = true;
            this.buttonPow3.Click += new System.EventHandler(this.buttonPow3_Click);
            // 
            // buttonPowA2
            // 
            this.buttonPowA2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPowA2.Location = new System.Drawing.Point(165, 3);
            this.buttonPowA2.Name = "buttonPowA2";
            this.buttonPowA2.Size = new System.Drawing.Size(75, 28);
            this.buttonPowA2.TabIndex = 2;
            this.buttonPowA2.Text = "A^2";
            this.buttonPowA2.UseVisualStyleBackColor = true;
            this.buttonPowA2.Click += new System.EventHandler(this.buttonPowA2_Click);
            // 
            // buttonPowA3
            // 
            this.buttonPowA3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPowA3.Location = new System.Drawing.Point(246, 3);
            this.buttonPowA3.Name = "buttonPowA3";
            this.buttonPowA3.Size = new System.Drawing.Size(75, 28);
            this.buttonPowA3.TabIndex = 3;
            this.buttonPowA3.Text = "A^3";
            this.buttonPowA3.UseVisualStyleBackColor = true;
            this.buttonPowA3.Click += new System.EventHandler(this.buttonPowA3_Click);
            // 
            // buttonIncA
            // 
            this.buttonIncA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonIncA.Location = new System.Drawing.Point(327, 3);
            this.buttonIncA.Name = "buttonIncA";
            this.buttonIncA.Size = new System.Drawing.Size(79, 28);
            this.buttonIncA.TabIndex = 6;
            this.buttonIncA.Text = "A++";
            this.buttonIncA.UseVisualStyleBackColor = true;
            this.buttonIncA.Click += new System.EventHandler(this.buttonIncA_Click);
            // 
            // buttonDecA
            // 
            this.buttonDecA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDecA.Location = new System.Drawing.Point(327, 37);
            this.buttonDecA.Name = "buttonDecA";
            this.buttonDecA.Size = new System.Drawing.Size(79, 28);
            this.buttonDecA.TabIndex = 7;
            this.buttonDecA.Text = "A--";
            this.buttonDecA.UseVisualStyleBackColor = true;
            this.buttonDecA.Click += new System.EventHandler(this.buttonDecA_Click);
            // 
            // buttonPow2B
            // 
            this.buttonPow2B.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPow2B.Location = new System.Drawing.Point(3, 37);
            this.buttonPow2B.Name = "buttonPow2B";
            this.buttonPow2B.Size = new System.Drawing.Size(75, 28);
            this.buttonPow2B.TabIndex = 8;
            this.buttonPow2B.Text = "2^B";
            this.buttonPow2B.UseVisualStyleBackColor = true;
            this.buttonPow2B.Click += new System.EventHandler(this.buttonPow2B_Click);
            // 
            // buttonPow2A
            // 
            this.buttonPow2A.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPow2A.Location = new System.Drawing.Point(84, 37);
            this.buttonPow2A.Name = "buttonPow2A";
            this.buttonPow2A.Size = new System.Drawing.Size(75, 28);
            this.buttonPow2A.TabIndex = 9;
            this.buttonPow2A.Text = "2^A";
            this.buttonPow2A.UseVisualStyleBackColor = true;
            this.buttonPow2A.Click += new System.EventHandler(this.buttonPow2A_Click);
            // 
            // buttonMulB2
            // 
            this.buttonMulB2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMulB2.Location = new System.Drawing.Point(165, 37);
            this.buttonMulB2.Name = "buttonMulB2";
            this.buttonMulB2.Size = new System.Drawing.Size(75, 28);
            this.buttonMulB2.TabIndex = 10;
            this.buttonMulB2.Text = "B*2";
            this.buttonMulB2.UseVisualStyleBackColor = true;
            this.buttonMulB2.Click += new System.EventHandler(this.buttonMulB2_Click);
            // 
            // buttonMul2A
            // 
            this.buttonMul2A.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMul2A.Location = new System.Drawing.Point(246, 37);
            this.buttonMul2A.Name = "buttonMul2A";
            this.buttonMul2A.Size = new System.Drawing.Size(75, 28);
            this.buttonMul2A.TabIndex = 11;
            this.buttonMul2A.Text = "A*2";
            this.buttonMul2A.UseVisualStyleBackColor = true;
            this.buttonMul2A.Click += new System.EventHandler(this.buttonMul2A_Click);
            // 
            // buttonB1
            // 
            this.buttonB1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonB1.Location = new System.Drawing.Point(327, 71);
            this.buttonB1.Name = "buttonB1";
            this.buttonB1.Size = new System.Drawing.Size(79, 28);
            this.buttonB1.TabIndex = 14;
            this.buttonB1.Text = "B*(-1)";
            this.buttonB1.UseVisualStyleBackColor = true;
            this.buttonB1.Click += new System.EventHandler(this.buttonB1_Click);
            // 
            // buttonLnB
            // 
            this.buttonLnB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLnB.Location = new System.Drawing.Point(3, 173);
            this.buttonLnB.Name = "buttonLnB";
            this.buttonLnB.Size = new System.Drawing.Size(75, 28);
            this.buttonLnB.TabIndex = 22;
            this.buttonLnB.Text = "Ln(B)";
            this.buttonLnB.UseVisualStyleBackColor = true;
            this.buttonLnB.Click += new System.EventHandler(this.buttonLnB_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.buttonAbsB, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.buttonAbsA, 1, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(324, 170);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(85, 34);
            this.tableLayoutPanel8.TabIndex = 26;
            // 
            // buttonAbsB
            // 
            this.buttonAbsB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAbsB.Location = new System.Drawing.Point(3, 3);
            this.buttonAbsB.Name = "buttonAbsB";
            this.buttonAbsB.Size = new System.Drawing.Size(36, 28);
            this.buttonAbsB.TabIndex = 26;
            this.buttonAbsB.Text = "|B|";
            this.buttonAbsB.UseVisualStyleBackColor = true;
            this.buttonAbsB.Click += new System.EventHandler(this.buttonAbsB_Click);
            // 
            // buttonAbsA
            // 
            this.buttonAbsA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAbsA.Location = new System.Drawing.Point(45, 3);
            this.buttonAbsA.Name = "buttonAbsA";
            this.buttonAbsA.Size = new System.Drawing.Size(37, 28);
            this.buttonAbsA.TabIndex = 16;
            this.buttonAbsA.Text = "|A|";
            this.buttonAbsA.UseVisualStyleBackColor = true;
            this.buttonAbsA.Click += new System.EventHandler(this.buttonAbsA_Click);
            // 
            // buttonClickView29
            // 
            this.buttonClickView29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView29.Location = new System.Drawing.Point(3, 105);
            this.buttonClickView29.Name = "buttonClickView29";
            this.buttonClickView29.Size = new System.Drawing.Size(75, 28);
            this.buttonClickView29.TabIndex = 12;
            this.buttonClickView29.Text = "√B";
            this.buttonClickView29.UseVisualStyleBackColor = true;
            this.buttonClickView29.Click += new System.EventHandler(this.buttonSqrtB_Click);
            // 
            // buttonClickView30
            // 
            this.buttonClickView30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView30.Location = new System.Drawing.Point(84, 105);
            this.buttonClickView30.Name = "buttonClickView30";
            this.buttonClickView30.Size = new System.Drawing.Size(75, 28);
            this.buttonClickView30.TabIndex = 13;
            this.buttonClickView30.Text = "√A";
            this.buttonClickView30.UseVisualStyleBackColor = true;
            this.buttonClickView30.Click += new System.EventHandler(this.buttonSqrtA_Click);
            // 
            // buttonPlusB1
            // 
            this.buttonPlusB1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPlusB1.Location = new System.Drawing.Point(3, 207);
            this.buttonPlusB1.Name = "buttonPlusB1";
            this.buttonPlusB1.Size = new System.Drawing.Size(75, 28);
            this.buttonPlusB1.TabIndex = 28;
            this.buttonPlusB1.Text = "B++";
            this.buttonPlusB1.UseVisualStyleBackColor = true;
            this.buttonPlusB1.ClickView += new TableAIS.ClickView(this.buttonPlusB1_ClickView);
            // 
            // buttonMines1B
            // 
            this.buttonMines1B.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMines1B.Location = new System.Drawing.Point(84, 207);
            this.buttonMines1B.Name = "buttonMines1B";
            this.buttonMines1B.Size = new System.Drawing.Size(75, 28);
            this.buttonMines1B.TabIndex = 28;
            this.buttonMines1B.Text = "B--";
            this.buttonMines1B.UseVisualStyleBackColor = true;
            this.buttonMines1B.ClickView += new TableAIS.ClickView(this.buttonMines1B_ClickView);
            // 
            // buttonPersent1A
            // 
            this.buttonPersent1A.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPersent1A.Location = new System.Drawing.Point(165, 207);
            this.buttonPersent1A.Name = "buttonPersent1A";
            this.buttonPersent1A.Size = new System.Drawing.Size(75, 28);
            this.buttonPersent1A.TabIndex = 28;
            this.buttonPersent1A.Text = "A%";
            this.buttonPersent1A.UseVisualStyleBackColor = true;
            this.buttonPersent1A.ClickView += new TableAIS.ClickView(this.buttonPersent1A_ClickView);
            // 
            // buttonPersent1B
            // 
            this.buttonPersent1B.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPersent1B.Location = new System.Drawing.Point(246, 207);
            this.buttonPersent1B.Name = "buttonPersent1B";
            this.buttonPersent1B.Size = new System.Drawing.Size(75, 28);
            this.buttonPersent1B.TabIndex = 28;
            this.buttonPersent1B.Text = "B%";
            this.buttonPersent1B.UseVisualStyleBackColor = true;
            this.buttonPersent1B.ClickView += new TableAIS.ClickView(this.buttonPersent1B_ClickView);
            // 
            // button1AB
            // 
            this.button1AB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1AB.Location = new System.Drawing.Point(327, 207);
            this.button1AB.Name = "button1AB";
            this.button1AB.Size = new System.Drawing.Size(79, 28);
            this.button1AB.TabIndex = 28;
            this.button1AB.Text = "=B";
            this.button1AB.UseVisualStyleBackColor = true;
            this.button1AB.Click += new System.EventHandler(this.button1AB_Click);
            // 
            // buttonIntB
            // 
            this.tableLayoutPanel7.SetColumnSpan(this.buttonIntB, 2);
            this.buttonIntB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonIntB.Location = new System.Drawing.Point(3, 241);
            this.buttonIntB.Name = "buttonIntB";
            this.buttonIntB.Size = new System.Drawing.Size(156, 28);
            this.buttonIntB.TabIndex = 29;
            this.buttonIntB.Text = "Целая часть B";
            this.buttonIntB.UseVisualStyleBackColor = true;
            this.buttonIntB.Click += new System.EventHandler(this.buttonIntB_Click);
            // 
            // buttonDrobB
            // 
            this.tableLayoutPanel7.SetColumnSpan(this.buttonDrobB, 2);
            this.buttonDrobB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDrobB.Location = new System.Drawing.Point(3, 275);
            this.buttonDrobB.Name = "buttonDrobB";
            this.buttonDrobB.Size = new System.Drawing.Size(156, 33);
            this.buttonDrobB.TabIndex = 29;
            this.buttonDrobB.Text = "Дробная часть B";
            this.buttonDrobB.UseVisualStyleBackColor = true;
            this.buttonDrobB.Click += new System.EventHandler(this.buttonDrobB_Click);
            // 
            // buttonDrobA
            // 
            this.tableLayoutPanel7.SetColumnSpan(this.buttonDrobA, 2);
            this.buttonDrobA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDrobA.Location = new System.Drawing.Point(246, 275);
            this.buttonDrobA.Name = "buttonDrobA";
            this.buttonDrobA.Size = new System.Drawing.Size(160, 33);
            this.buttonDrobA.TabIndex = 30;
            this.buttonDrobA.Text = "Дробная часть A";
            this.buttonDrobA.UseVisualStyleBackColor = true;
            this.buttonDrobA.Click += new System.EventHandler(this.buttonDrobA_Click);
            // 
            // buttonSgnA
            // 
            this.buttonSgnA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSgnA.Location = new System.Drawing.Point(165, 241);
            this.buttonSgnA.Name = "buttonSgnA";
            this.buttonSgnA.Size = new System.Drawing.Size(75, 28);
            this.buttonSgnA.TabIndex = 31;
            this.buttonSgnA.Text = "Sgn(A)";
            this.buttonSgnA.UseVisualStyleBackColor = true;
            this.buttonSgnA.Click += new System.EventHandler(this.buttonSgnA_Click);
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 3;
            this.tableLayoutPanel2.SetColumnSpan(this.tableLayoutPanel10, 2);
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.85339F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.41575F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.73085F));
            this.tableLayoutPanel10.Controls.Add(this.memoryA, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.memoryBuffer, 1, 1);
            this.tableLayoutPanel10.Controls.Add(this.tableLayoutPanel4, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.tableLayoutPanel11, 2, 0);
            this.tableLayoutPanel10.Controls.Add(this.memoryB, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.checkBoxAutoOutput, 0, 2);
            this.tableLayoutPanel10.Controls.Add(this.checkBoxAutoWrite, 1, 2);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel10.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 3;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(933, 110);
            this.tableLayoutPanel10.TabIndex = 6;
            // 
            // memoryA
            // 
            this.memoryA.BorderStule = System.Windows.Forms.BorderStyle.Fixed3D;
            this.memoryA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memoryA.Few = null;
            this.memoryA.FewInvoke = true;
            this.memoryA.Historytext = "История";
            this.memoryA.Location = new System.Drawing.Point(287, 50);
            this.memoryA.Margin = new System.Windows.Forms.Padding(0);
            this.memoryA.MinesText = "M-";
            this.memoryA.Name = "memoryA";
            this.memoryA.PlusText = "M+";
            this.memoryA.RText = "MR";
            this.memoryA.Size = new System.Drawing.Size(283, 30);
            this.memoryA.TabIndex = 5;
            this.memoryA.WriteAndClearText = "MRC";
            this.memoryA.WriteText = "->M";
            // 
            // memoryBuffer
            // 
            this.memoryBuffer.BorderStule = System.Windows.Forms.BorderStyle.Fixed3D;
            this.memoryBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memoryBuffer.Few = null;
            this.memoryBuffer.FewInvoke = true;
            this.memoryBuffer.Historytext = "История";
            this.memoryBuffer.Location = new System.Drawing.Point(570, 50);
            this.memoryBuffer.Margin = new System.Windows.Forms.Padding(0);
            this.memoryBuffer.MinesText = "M-";
            this.memoryBuffer.Name = "memoryBuffer";
            this.memoryBuffer.PlusText = "M+";
            this.memoryBuffer.RText = "MR";
            this.memoryBuffer.Size = new System.Drawing.Size(363, 30);
            this.memoryBuffer.TabIndex = 4;
            this.memoryBuffer.WriteAndClearText = "MRC";
            this.memoryBuffer.WriteText = "->M";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanel4.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBoxA, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.buttonClearA, 2, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(290, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(277, 44);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 44);
            this.label2.TabIndex = 0;
            this.label2.Text = "A=";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxA
            // 
            this.textBoxA.BackColor = System.Drawing.Color.White;
            this.textBoxA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxA.Location = new System.Drawing.Point(36, 3);
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.ReadOnly = true;
            this.textBoxA.Size = new System.Drawing.Size(214, 34);
            this.textBoxA.TabIndex = 1;
            // 
            // buttonClearA
            // 
            this.buttonClearA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearA.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonClearA.Location = new System.Drawing.Point(256, 3);
            this.buttonClearA.Name = "buttonClearA";
            this.buttonClearA.Size = new System.Drawing.Size(18, 38);
            this.buttonClearA.TabIndex = 2;
            this.buttonClearA.Text = "C";
            this.buttonClearA.UseVisualStyleBackColor = true;
            this.buttonClearA.Click += new System.EventHandler(this.buttonClearA_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.textBoxB, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonBackSpace, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonClearB, 3, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(281, 44);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "B=";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxB
            // 
            this.textBoxB.BackColor = System.Drawing.Color.White;
            this.textBoxB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxB.Location = new System.Drawing.Point(35, 3);
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.ReadOnly = true;
            this.textBoxB.Size = new System.Drawing.Size(180, 34);
            this.textBoxB.TabIndex = 1;
            // 
            // buttonBackSpace
            // 
            this.buttonBackSpace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBackSpace.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonBackSpace.Location = new System.Drawing.Point(221, 3);
            this.buttonBackSpace.Name = "buttonBackSpace";
            this.buttonBackSpace.Size = new System.Drawing.Size(31, 38);
            this.buttonBackSpace.TabIndex = 2;
            this.buttonBackSpace.Text = "<-";
            this.buttonBackSpace.UseVisualStyleBackColor = true;
            this.buttonBackSpace.Click += new System.EventHandler(this.buttonBackSpace_Click);
            // 
            // buttonClearB
            // 
            this.buttonClearB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearB.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonClearB.Location = new System.Drawing.Point(258, 3);
            this.buttonClearB.Name = "buttonClearB";
            this.buttonClearB.Size = new System.Drawing.Size(20, 38);
            this.buttonClearB.TabIndex = 3;
            this.buttonClearB.Text = "C";
            this.buttonClearB.UseVisualStyleBackColor = true;
            this.buttonClearB.Click += new System.EventHandler(this.buttonClearB_Click);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 6;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel11.Controls.Add(this.buttonBufferA, 4, 0);
            this.tableLayoutPanel11.Controls.Add(this.buttonBufferB, 5, 0);
            this.tableLayoutPanel11.Controls.Add(this.buttonABuffer, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.textBoxBuffer, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.buttonBBuffer, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.buttonBufferClear, 3, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(573, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(357, 44);
            this.tableLayoutPanel11.TabIndex = 2;
            // 
            // buttonBufferA
            // 
            this.buttonBufferA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBufferA.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonBufferA.Location = new System.Drawing.Point(280, 3);
            this.buttonBufferA.Name = "buttonBufferA";
            this.buttonBufferA.Size = new System.Drawing.Size(34, 38);
            this.buttonBufferA.TabIndex = 4;
            this.buttonBufferA.Text = "<A";
            this.buttonBufferA.UseVisualStyleBackColor = true;
            this.buttonBufferA.Click += new System.EventHandler(this.buttonBufferA_Click);
            // 
            // buttonBufferB
            // 
            this.buttonBufferB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBufferB.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonBufferB.Location = new System.Drawing.Point(320, 3);
            this.buttonBufferB.Name = "buttonBufferB";
            this.buttonBufferB.Size = new System.Drawing.Size(34, 38);
            this.buttonBufferB.TabIndex = 3;
            this.buttonBufferB.Text = "<B";
            this.buttonBufferB.UseVisualStyleBackColor = true;
            this.buttonBufferB.Click += new System.EventHandler(this.buttonBufferB_Click);
            // 
            // buttonABuffer
            // 
            this.buttonABuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonABuffer.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonABuffer.Location = new System.Drawing.Point(43, 3);
            this.buttonABuffer.Name = "buttonABuffer";
            this.buttonABuffer.Size = new System.Drawing.Size(34, 38);
            this.buttonABuffer.TabIndex = 2;
            this.buttonABuffer.Text = "A>";
            this.buttonABuffer.UseVisualStyleBackColor = true;
            this.buttonABuffer.Click += new System.EventHandler(this.buttonABuffer_Click);
            // 
            // textBoxBuffer
            // 
            this.textBoxBuffer.BackColor = System.Drawing.Color.White;
            this.textBoxBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxBuffer.Location = new System.Drawing.Point(83, 3);
            this.textBoxBuffer.Name = "textBoxBuffer";
            this.textBoxBuffer.ReadOnly = true;
            this.textBoxBuffer.Size = new System.Drawing.Size(151, 34);
            this.textBoxBuffer.TabIndex = 0;
            // 
            // buttonBBuffer
            // 
            this.buttonBBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBBuffer.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonBBuffer.Location = new System.Drawing.Point(3, 3);
            this.buttonBBuffer.Name = "buttonBBuffer";
            this.buttonBBuffer.Size = new System.Drawing.Size(34, 38);
            this.buttonBBuffer.TabIndex = 1;
            this.buttonBBuffer.Text = "B>";
            this.buttonBBuffer.UseVisualStyleBackColor = true;
            this.buttonBBuffer.Click += new System.EventHandler(this.buttonBBuffer_Click);
            // 
            // buttonBufferClear
            // 
            this.buttonBufferClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBufferClear.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonBufferClear.Location = new System.Drawing.Point(240, 3);
            this.buttonBufferClear.Name = "buttonBufferClear";
            this.buttonBufferClear.Size = new System.Drawing.Size(34, 38);
            this.buttonBufferClear.TabIndex = 5;
            this.buttonBufferClear.Text = "C";
            this.buttonBufferClear.UseVisualStyleBackColor = true;
            this.buttonBufferClear.Click += new System.EventHandler(this.buttonBufferClear_Click);
            // 
            // memoryB
            // 
            this.memoryB.BorderStule = System.Windows.Forms.BorderStyle.Fixed3D;
            this.memoryB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memoryB.Few = null;
            this.memoryB.FewInvoke = true;
            this.memoryB.Historytext = "История";
            this.memoryB.Location = new System.Drawing.Point(0, 50);
            this.memoryB.Margin = new System.Windows.Forms.Padding(0);
            this.memoryB.MinesText = "M-";
            this.memoryB.Name = "memoryB";
            this.memoryB.PlusText = "M+";
            this.memoryB.RText = "MR";
            this.memoryB.Size = new System.Drawing.Size(287, 30);
            this.memoryB.TabIndex = 3;
            this.memoryB.WriteAndClearText = "MRC";
            this.memoryB.WriteText = "->M";
            // 
            // checkBoxAutoOutput
            // 
            this.checkBoxAutoOutput.AutoSize = true;
            this.checkBoxAutoOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoOutput.Location = new System.Drawing.Point(3, 83);
            this.checkBoxAutoOutput.Name = "checkBoxAutoOutput";
            this.checkBoxAutoOutput.Size = new System.Drawing.Size(281, 24);
            this.checkBoxAutoOutput.TabIndex = 6;
            this.checkBoxAutoOutput.Text = "Автоматически вычислять A";
            this.checkBoxAutoOutput.UseVisualStyleBackColor = true;
            this.checkBoxAutoOutput.CheckedChanged += new System.EventHandler(this.checkBoxAutoOutput_CheckedChanged);
            // 
            // checkBoxAutoWrite
            // 
            this.checkBoxAutoWrite.AutoSize = true;
            this.checkBoxAutoWrite.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoWrite.Location = new System.Drawing.Point(290, 83);
            this.checkBoxAutoWrite.Name = "checkBoxAutoWrite";
            this.checkBoxAutoWrite.Size = new System.Drawing.Size(277, 24);
            this.checkBoxAutoWrite.TabIndex = 7;
            this.checkBoxAutoWrite.Text = "Автозапись A";
            this.checkBoxAutoWrite.UseVisualStyleBackColor = true;
            this.checkBoxAutoWrite.CheckedChanged += new System.EventHandler(this.checkBoxAutoWrite_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.flowLayoutPanel1);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(456, 257);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(474, 139);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Инженерые функции";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowLayoutPanel1.Controls.Add(this.groupBox5);
            this.flowLayoutPanel1.Controls.Add(this.groupBox83);
            this.flowLayoutPanel1.Controls.Add(this.groupBox17);
            this.flowLayoutPanel1.Controls.Add(this.groupBox18);
            this.flowLayoutPanel1.Controls.Add(this.groupBox23);
            this.flowLayoutPanel1.Controls.Add(this.groupBox30);
            this.flowLayoutPanel1.Controls.Add(this.groupBox35);
            this.flowLayoutPanel1.Controls.Add(this.groupBox40);
            this.flowLayoutPanel1.Controls.Add(this.groupBox55);
            this.flowLayoutPanel1.Controls.Add(this.groupBox67);
            this.flowLayoutPanel1.Controls.Add(this.groupBox75);
            this.flowLayoutPanel1.Controls.Add(this.groupBox85);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Font = new System.Drawing.Font("Lucida Sans Unicode", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 30);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(468, 106);
            this.flowLayoutPanel1.TabIndex = 0;
            this.flowLayoutPanel1.WrapContents = false;
            this.flowLayoutPanel1.SizeChanged += new System.EventHandler(this.flowLayoutPanelInputB_SizeChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tableLayoutPanel12);
            this.groupBox5.Location = new System.Drawing.Point(3, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(428, 480);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Треугольник";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.groupBox8, 1, 1);
            this.tableLayoutPanel12.Controls.Add(this.groupBox6, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.groupBox7, 0, 1);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.25991F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.74009F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(422, 454);
            this.tableLayoutPanel12.TabIndex = 0;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.tableLayoutPanel16);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Location = new System.Drawing.Point(214, 153);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(205, 298);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Сторона B; Угол A";
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Controls.Add(this.groupBox14, 0, 1);
            this.tableLayoutPanel16.Controls.Add(this.groupBox10, 0, 0);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 37.6569F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 62.3431F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(199, 272);
            this.tableLayoutPanel16.TabIndex = 1;
            // 
            // groupBox14
            // 
            this.tableLayoutPanel16.SetColumnSpan(this.groupBox14, 2);
            this.groupBox14.Controls.Add(this.tableLayoutPanel21);
            this.groupBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox14.Location = new System.Drawing.Point(0, 102);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(199, 170);
            this.groupBox14.TabIndex = 2;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Равнобедренный треуголник";
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Controls.Add(this.groupBox15, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.groupBox16, 0, 0);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel21.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 144F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(193, 144);
            this.tableLayoutPanel21.TabIndex = 0;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.tableLayoutPanel22);
            this.groupBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox15.Location = new System.Drawing.Point(99, 3);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(91, 138);
            this.groupBox15.TabIndex = 1;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Радианы";
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 1;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel22.Controls.Add(this.buttonTallRadBA, 0, 3);
            this.tableLayoutPanel22.Controls.Add(this.buttonSqrRadBA, 0, 2);
            this.tableLayoutPanel22.Controls.Add(this.buttonRadLenBA, 0, 1);
            this.tableLayoutPanel22.Controls.Add(this.buttonLenRadBA, 0, 0);
            this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 4;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(85, 112);
            this.tableLayoutPanel22.TabIndex = 0;
            // 
            // buttonTallRadBA
            // 
            this.buttonTallRadBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTallRadBA.Location = new System.Drawing.Point(3, 87);
            this.buttonTallRadBA.Name = "buttonTallRadBA";
            this.buttonTallRadBA.Size = new System.Drawing.Size(79, 22);
            this.buttonTallRadBA.TabIndex = 3;
            this.buttonTallRadBA.Text = "Высота";
            this.buttonTallRadBA.UseVisualStyleBackColor = true;
            this.buttonTallRadBA.Click += new System.EventHandler(this.buttonTallRadBA_Click);
            // 
            // buttonSqrRadBA
            // 
            this.buttonSqrRadBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrRadBA.Location = new System.Drawing.Point(3, 59);
            this.buttonSqrRadBA.Name = "buttonSqrRadBA";
            this.buttonSqrRadBA.Size = new System.Drawing.Size(79, 22);
            this.buttonSqrRadBA.TabIndex = 2;
            this.buttonSqrRadBA.Text = "Площадь";
            this.buttonSqrRadBA.UseVisualStyleBackColor = true;
            this.buttonSqrRadBA.Click += new System.EventHandler(this.buttonSqrRadBA_Click);
            // 
            // buttonRadLenBA
            // 
            this.buttonRadLenBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRadLenBA.Location = new System.Drawing.Point(3, 31);
            this.buttonRadLenBA.Name = "buttonRadLenBA";
            this.buttonRadLenBA.Size = new System.Drawing.Size(79, 22);
            this.buttonRadLenBA.TabIndex = 1;
            this.buttonRadLenBA.Text = "Сторона";
            this.buttonRadLenBA.UseVisualStyleBackColor = true;
            this.buttonRadLenBA.Click += new System.EventHandler(this.buttonRadLenBA_Click);
            // 
            // buttonLenRadBA
            // 
            this.buttonLenRadBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLenRadBA.Location = new System.Drawing.Point(3, 3);
            this.buttonLenRadBA.Name = "buttonLenRadBA";
            this.buttonLenRadBA.Size = new System.Drawing.Size(79, 22);
            this.buttonLenRadBA.TabIndex = 0;
            this.buttonLenRadBA.Text = "Основание";
            this.buttonLenRadBA.UseVisualStyleBackColor = true;
            this.buttonLenRadBA.Click += new System.EventHandler(this.buttonLenRadBA_Click);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.tableLayoutPanel23);
            this.groupBox16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox16.Location = new System.Drawing.Point(3, 3);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(90, 138);
            this.groupBox16.TabIndex = 0;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Градусы";
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 1;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel23.Controls.Add(this.buttonTallGradBA, 0, 3);
            this.tableLayoutPanel23.Controls.Add(this.buttonSqrGradBA, 0, 2);
            this.tableLayoutPanel23.Controls.Add(this.buttonGradLenBA, 0, 1);
            this.tableLayoutPanel23.Controls.Add(this.buttonLenGradBA, 0, 0);
            this.tableLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 4;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(84, 112);
            this.tableLayoutPanel23.TabIndex = 0;
            // 
            // buttonTallGradBA
            // 
            this.buttonTallGradBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTallGradBA.Location = new System.Drawing.Point(3, 87);
            this.buttonTallGradBA.Name = "buttonTallGradBA";
            this.buttonTallGradBA.Size = new System.Drawing.Size(78, 22);
            this.buttonTallGradBA.TabIndex = 3;
            this.buttonTallGradBA.Text = "Высота";
            this.buttonTallGradBA.UseVisualStyleBackColor = true;
            this.buttonTallGradBA.Click += new System.EventHandler(this.buttonTallGradBA_Click);
            // 
            // buttonSqrGradBA
            // 
            this.buttonSqrGradBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrGradBA.Location = new System.Drawing.Point(3, 59);
            this.buttonSqrGradBA.Name = "buttonSqrGradBA";
            this.buttonSqrGradBA.Size = new System.Drawing.Size(78, 22);
            this.buttonSqrGradBA.TabIndex = 2;
            this.buttonSqrGradBA.Text = "Площадь";
            this.buttonSqrGradBA.UseVisualStyleBackColor = true;
            this.buttonSqrGradBA.Click += new System.EventHandler(this.buttonSqrGradBA_Click);
            // 
            // buttonGradLenBA
            // 
            this.buttonGradLenBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonGradLenBA.Location = new System.Drawing.Point(3, 31);
            this.buttonGradLenBA.Name = "buttonGradLenBA";
            this.buttonGradLenBA.Size = new System.Drawing.Size(78, 22);
            this.buttonGradLenBA.TabIndex = 1;
            this.buttonGradLenBA.Text = "Сторона";
            this.buttonGradLenBA.UseVisualStyleBackColor = true;
            this.buttonGradLenBA.Click += new System.EventHandler(this.buttonGradLenBA_Click);
            // 
            // buttonLenGradBA
            // 
            this.buttonLenGradBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLenGradBA.Location = new System.Drawing.Point(3, 3);
            this.buttonLenGradBA.Name = "buttonLenGradBA";
            this.buttonLenGradBA.Size = new System.Drawing.Size(78, 22);
            this.buttonLenGradBA.TabIndex = 0;
            this.buttonLenGradBA.Text = "Основание";
            this.buttonLenGradBA.UseVisualStyleBackColor = true;
            this.buttonLenGradBA.Click += new System.EventHandler(this.buttonLenGradBA_Click);
            // 
            // groupBox10
            // 
            this.tableLayoutPanel16.SetColumnSpan(this.groupBox10, 2);
            this.groupBox10.Controls.Add(this.tableLayoutPanel17);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox10.Location = new System.Drawing.Point(3, 3);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(193, 96);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Равносторонний треугольник";
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 2;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.Controls.Add(this.buttonRetTallB, 1, 1);
            this.tableLayoutPanel17.Controls.Add(this.buttonSqrTruangleB, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.buttonRetSqrB, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.buttonTallB, 0, 1);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 2;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(187, 70);
            this.tableLayoutPanel17.TabIndex = 0;
            // 
            // buttonRetTallB
            // 
            this.buttonRetTallB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRetTallB.Location = new System.Drawing.Point(96, 38);
            this.buttonRetTallB.Name = "buttonRetTallB";
            this.buttonRetTallB.Size = new System.Drawing.Size(88, 29);
            this.buttonRetTallB.TabIndex = 3;
            this.buttonRetTallB.Text = "Сторона";
            this.buttonRetTallB.UseVisualStyleBackColor = true;
            this.buttonRetTallB.Click += new System.EventHandler(this.buttonRetTallB_Click);
            // 
            // buttonSqrTruangleB
            // 
            this.buttonSqrTruangleB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrTruangleB.Location = new System.Drawing.Point(3, 3);
            this.buttonSqrTruangleB.Name = "buttonSqrTruangleB";
            this.buttonSqrTruangleB.Size = new System.Drawing.Size(87, 29);
            this.buttonSqrTruangleB.TabIndex = 0;
            this.buttonSqrTruangleB.Text = "Площадь";
            this.buttonSqrTruangleB.UseVisualStyleBackColor = true;
            this.buttonSqrTruangleB.Click += new System.EventHandler(this.buttonSqrTruangleB_Click);
            // 
            // buttonRetSqrB
            // 
            this.buttonRetSqrB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRetSqrB.Location = new System.Drawing.Point(96, 3);
            this.buttonRetSqrB.Name = "buttonRetSqrB";
            this.buttonRetSqrB.Size = new System.Drawing.Size(88, 29);
            this.buttonRetSqrB.TabIndex = 1;
            this.buttonRetSqrB.Text = "Сторона";
            this.buttonRetSqrB.UseVisualStyleBackColor = true;
            this.buttonRetSqrB.Click += new System.EventHandler(this.buttonRetSqrB_Click);
            // 
            // buttonTallB
            // 
            this.buttonTallB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTallB.Location = new System.Drawing.Point(3, 38);
            this.buttonTallB.Name = "buttonTallB";
            this.buttonTallB.Size = new System.Drawing.Size(87, 29);
            this.buttonTallB.TabIndex = 2;
            this.buttonTallB.Text = "Высота";
            this.buttonTallB.UseVisualStyleBackColor = true;
            this.buttonTallB.Click += new System.EventHandler(this.buttonTallB_Click);
            // 
            // groupBox6
            // 
            this.tableLayoutPanel12.SetColumnSpan(this.groupBox6, 2);
            this.groupBox6.Controls.Add(this.tableLayoutPanel13);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(3, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(416, 144);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Прямоугольный треугольник";
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 3;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.Controls.Add(this.buttonSqrTruangleCatetsB, 2, 3);
            this.tableLayoutPanel13.Controls.Add(this.buttonSqrTruangleCatetsA, 2, 2);
            this.tableLayoutPanel13.Controls.Add(this.buttonSqrTruangleCatets, 2, 1);
            this.tableLayoutPanel13.Controls.Add(this.buttonCatetSqrtB, 1, 2);
            this.tableLayoutPanel13.Controls.Add(this.buttonCatetSqrtA, 1, 1);
            this.tableLayoutPanel13.Controls.Add(this.buttonGipotenuzeB, 0, 2);
            this.tableLayoutPanel13.Controls.Add(this.buttonGipotenuzeA, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.buttonCatetA, 2, 0);
            this.tableLayoutPanel13.Controls.Add(this.buttonCatetB, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.buttonGipotenuze, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.buttonKatetSqrA, 0, 3);
            this.tableLayoutPanel13.Controls.Add(this.buttonKatetSqrB, 1, 3);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Font = new System.Drawing.Font("Lucida Sans Unicode", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 4;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.99813F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(410, 118);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // buttonSqrTruangleCatetsB
            // 
            this.buttonSqrTruangleCatetsB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrTruangleCatetsB.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonSqrTruangleCatetsB.Location = new System.Drawing.Point(275, 90);
            this.buttonSqrTruangleCatetsB.Name = "buttonSqrTruangleCatetsB";
            this.buttonSqrTruangleCatetsB.Size = new System.Drawing.Size(132, 25);
            this.buttonSqrTruangleCatetsB.TabIndex = 9;
            this.buttonSqrTruangleCatetsB.Text = "(B*B)/2";
            this.buttonSqrTruangleCatetsB.UseVisualStyleBackColor = true;
            this.buttonSqrTruangleCatetsB.Click += new System.EventHandler(this.buttonSqrTruangleCatetsB_Click);
            // 
            // buttonSqrTruangleCatetsA
            // 
            this.buttonSqrTruangleCatetsA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrTruangleCatetsA.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonSqrTruangleCatetsA.Location = new System.Drawing.Point(275, 61);
            this.buttonSqrTruangleCatetsA.Name = "buttonSqrTruangleCatetsA";
            this.buttonSqrTruangleCatetsA.Size = new System.Drawing.Size(132, 23);
            this.buttonSqrTruangleCatetsA.TabIndex = 8;
            this.buttonSqrTruangleCatetsA.Text = "(A*A)/2";
            this.buttonSqrTruangleCatetsA.UseVisualStyleBackColor = true;
            this.buttonSqrTruangleCatetsA.Click += new System.EventHandler(this.buttonSqrTruangleCatetsA_Click);
            // 
            // buttonSqrTruangleCatets
            // 
            this.buttonSqrTruangleCatets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrTruangleCatets.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonSqrTruangleCatets.Location = new System.Drawing.Point(275, 32);
            this.buttonSqrTruangleCatets.Name = "buttonSqrTruangleCatets";
            this.buttonSqrTruangleCatets.Size = new System.Drawing.Size(132, 23);
            this.buttonSqrTruangleCatets.TabIndex = 7;
            this.buttonSqrTruangleCatets.Text = "(A*B)/2";
            this.buttonSqrTruangleCatets.UseVisualStyleBackColor = true;
            this.buttonSqrTruangleCatets.Click += new System.EventHandler(this.buttonSqrTruangleCatets_Click);
            // 
            // buttonCatetSqrtB
            // 
            this.buttonCatetSqrtB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCatetSqrtB.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonCatetSqrtB.Location = new System.Drawing.Point(139, 61);
            this.buttonCatetSqrtB.Name = "buttonCatetSqrtB";
            this.buttonCatetSqrtB.Size = new System.Drawing.Size(130, 23);
            this.buttonCatetSqrtB.TabIndex = 6;
            this.buttonCatetSqrtB.Text = "B/(2^(1/2))";
            this.buttonCatetSqrtB.UseVisualStyleBackColor = true;
            this.buttonCatetSqrtB.Click += new System.EventHandler(this.buttonCatetSqrtB_Click);
            // 
            // buttonCatetSqrtA
            // 
            this.buttonCatetSqrtA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCatetSqrtA.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonCatetSqrtA.Location = new System.Drawing.Point(139, 32);
            this.buttonCatetSqrtA.Name = "buttonCatetSqrtA";
            this.buttonCatetSqrtA.Size = new System.Drawing.Size(130, 23);
            this.buttonCatetSqrtA.TabIndex = 5;
            this.buttonCatetSqrtA.Text = "A/(2^(1/2))";
            this.buttonCatetSqrtA.UseVisualStyleBackColor = true;
            this.buttonCatetSqrtA.Click += new System.EventHandler(this.buttonCatetSqrtA_Click);
            // 
            // buttonGipotenuzeB
            // 
            this.buttonGipotenuzeB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonGipotenuzeB.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonGipotenuzeB.Location = new System.Drawing.Point(3, 61);
            this.buttonGipotenuzeB.Name = "buttonGipotenuzeB";
            this.buttonGipotenuzeB.Size = new System.Drawing.Size(130, 23);
            this.buttonGipotenuzeB.TabIndex = 4;
            this.buttonGipotenuzeB.Text = "B*(2^(1/2))";
            this.buttonGipotenuzeB.UseVisualStyleBackColor = true;
            this.buttonGipotenuzeB.Click += new System.EventHandler(this.buttonGipotenuzeB_Click);
            // 
            // buttonGipotenuzeA
            // 
            this.buttonGipotenuzeA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonGipotenuzeA.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonGipotenuzeA.Location = new System.Drawing.Point(3, 32);
            this.buttonGipotenuzeA.Name = "buttonGipotenuzeA";
            this.buttonGipotenuzeA.Size = new System.Drawing.Size(130, 23);
            this.buttonGipotenuzeA.TabIndex = 3;
            this.buttonGipotenuzeA.Text = "A*(2^(1/2))";
            this.buttonGipotenuzeA.UseVisualStyleBackColor = true;
            this.buttonGipotenuzeA.Click += new System.EventHandler(this.buttonGipotenuzeA_Click);
            // 
            // buttonCatetA
            // 
            this.buttonCatetA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCatetA.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonCatetA.Location = new System.Drawing.Point(275, 3);
            this.buttonCatetA.Name = "buttonCatetA";
            this.buttonCatetA.Size = new System.Drawing.Size(132, 23);
            this.buttonCatetA.TabIndex = 2;
            this.buttonCatetA.Text = "((B^2)-(A^2))^(1/2)";
            this.buttonCatetA.UseVisualStyleBackColor = true;
            this.buttonCatetA.Click += new System.EventHandler(this.buttonCatetA_Click);
            // 
            // buttonCatetB
            // 
            this.buttonCatetB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCatetB.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonCatetB.Location = new System.Drawing.Point(139, 3);
            this.buttonCatetB.Name = "buttonCatetB";
            this.buttonCatetB.Size = new System.Drawing.Size(130, 23);
            this.buttonCatetB.TabIndex = 1;
            this.buttonCatetB.Text = "((A^2)-(B^2))^(1/2)";
            this.buttonCatetB.UseVisualStyleBackColor = true;
            this.buttonCatetB.Click += new System.EventHandler(this.buttonCatetB_Click);
            // 
            // buttonGipotenuze
            // 
            this.buttonGipotenuze.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonGipotenuze.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.buttonGipotenuze.Location = new System.Drawing.Point(3, 3);
            this.buttonGipotenuze.Name = "buttonGipotenuze";
            this.buttonGipotenuze.Size = new System.Drawing.Size(130, 23);
            this.buttonGipotenuze.TabIndex = 0;
            this.buttonGipotenuze.Text = "((A^2)+(B^2))^(1/2)";
            this.buttonGipotenuze.UseVisualStyleBackColor = true;
            this.buttonGipotenuze.Click += new System.EventHandler(this.buttonGipotenuze_Click);
            // 
            // buttonKatetSqrA
            // 
            this.buttonKatetSqrA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonKatetSqrA.Location = new System.Drawing.Point(3, 90);
            this.buttonKatetSqrA.Name = "buttonKatetSqrA";
            this.buttonKatetSqrA.Size = new System.Drawing.Size(130, 25);
            this.buttonKatetSqrA.TabIndex = 10;
            this.buttonKatetSqrA.Text = "2*A/B";
            this.buttonKatetSqrA.UseVisualStyleBackColor = true;
            this.buttonKatetSqrA.Click += new System.EventHandler(this.buttonKatetSqrA_Click);
            // 
            // buttonKatetSqrB
            // 
            this.buttonKatetSqrB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonKatetSqrB.Location = new System.Drawing.Point(139, 90);
            this.buttonKatetSqrB.Name = "buttonKatetSqrB";
            this.buttonKatetSqrB.Size = new System.Drawing.Size(130, 25);
            this.buttonKatetSqrB.TabIndex = 10;
            this.buttonKatetSqrB.Text = "2*B/A";
            this.buttonKatetSqrB.UseVisualStyleBackColor = true;
            this.buttonKatetSqrB.Click += new System.EventHandler(this.buttonKatetSqrB_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.tableLayoutPanel14);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(3, 153);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(205, 298);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Сторона A; Угол B";
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.Controls.Add(this.groupBox9, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.groupBox11, 0, 1);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 2;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38.07531F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 61.92469F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(199, 272);
            this.tableLayoutPanel14.TabIndex = 0;
            // 
            // groupBox9
            // 
            this.tableLayoutPanel14.SetColumnSpan(this.groupBox9, 2);
            this.groupBox9.Controls.Add(this.tableLayoutPanel15);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox9.Location = new System.Drawing.Point(3, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(193, 97);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Равносторонний треугольник";
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Controls.Add(this.buttonRetTallA, 1, 1);
            this.tableLayoutPanel15.Controls.Add(this.buttonSqrTruangleA, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.buttonRetSqrA, 1, 0);
            this.tableLayoutPanel15.Controls.Add(this.buttonTallA, 0, 1);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(187, 71);
            this.tableLayoutPanel15.TabIndex = 0;
            // 
            // buttonRetTallA
            // 
            this.buttonRetTallA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRetTallA.Location = new System.Drawing.Point(96, 38);
            this.buttonRetTallA.Name = "buttonRetTallA";
            this.buttonRetTallA.Size = new System.Drawing.Size(88, 30);
            this.buttonRetTallA.TabIndex = 3;
            this.buttonRetTallA.Text = "Сторона";
            this.buttonRetTallA.UseVisualStyleBackColor = true;
            this.buttonRetTallA.Click += new System.EventHandler(this.buttonRetTallA_Click);
            // 
            // buttonSqrTruangleA
            // 
            this.buttonSqrTruangleA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrTruangleA.Location = new System.Drawing.Point(3, 3);
            this.buttonSqrTruangleA.Name = "buttonSqrTruangleA";
            this.buttonSqrTruangleA.Size = new System.Drawing.Size(87, 29);
            this.buttonSqrTruangleA.TabIndex = 0;
            this.buttonSqrTruangleA.Text = "Площадь";
            this.buttonSqrTruangleA.UseVisualStyleBackColor = true;
            this.buttonSqrTruangleA.Click += new System.EventHandler(this.buttonSqrTruangleA_Click);
            // 
            // buttonRetSqrA
            // 
            this.buttonRetSqrA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRetSqrA.Location = new System.Drawing.Point(96, 3);
            this.buttonRetSqrA.Name = "buttonRetSqrA";
            this.buttonRetSqrA.Size = new System.Drawing.Size(88, 29);
            this.buttonRetSqrA.TabIndex = 1;
            this.buttonRetSqrA.Text = "Сторона";
            this.buttonRetSqrA.UseVisualStyleBackColor = true;
            this.buttonRetSqrA.Click += new System.EventHandler(this.buttonRetSqrA_Click);
            // 
            // buttonTallA
            // 
            this.buttonTallA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTallA.Location = new System.Drawing.Point(3, 38);
            this.buttonTallA.Name = "buttonTallA";
            this.buttonTallA.Size = new System.Drawing.Size(87, 30);
            this.buttonTallA.TabIndex = 2;
            this.buttonTallA.Text = "Высота";
            this.buttonTallA.UseVisualStyleBackColor = true;
            this.buttonTallA.Click += new System.EventHandler(this.buttonTallA_Click);
            // 
            // groupBox11
            // 
            this.tableLayoutPanel14.SetColumnSpan(this.groupBox11, 2);
            this.groupBox11.Controls.Add(this.tableLayoutPanel18);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox11.Location = new System.Drawing.Point(0, 103);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(199, 169);
            this.groupBox11.TabIndex = 1;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Равнобедренный треуголник";
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Controls.Add(this.groupBox13, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.groupBox12, 0, 0);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel18.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 143F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(193, 143);
            this.tableLayoutPanel18.TabIndex = 0;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.tableLayoutPanel20);
            this.groupBox13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox13.Location = new System.Drawing.Point(99, 3);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(91, 137);
            this.groupBox13.TabIndex = 1;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Радианы";
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 1;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel20.Controls.Add(this.buttonTallRadAB, 0, 3);
            this.tableLayoutPanel20.Controls.Add(this.buttonSqrRadAB, 0, 2);
            this.tableLayoutPanel20.Controls.Add(this.buttonRadLenAB, 0, 1);
            this.tableLayoutPanel20.Controls.Add(this.buttonLenRadAB, 0, 0);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 4;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(85, 111);
            this.tableLayoutPanel20.TabIndex = 0;
            // 
            // buttonTallRadAB
            // 
            this.buttonTallRadAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTallRadAB.Location = new System.Drawing.Point(3, 84);
            this.buttonTallRadAB.Name = "buttonTallRadAB";
            this.buttonTallRadAB.Size = new System.Drawing.Size(79, 24);
            this.buttonTallRadAB.TabIndex = 3;
            this.buttonTallRadAB.Text = "Высота";
            this.buttonTallRadAB.UseVisualStyleBackColor = true;
            this.buttonTallRadAB.Click += new System.EventHandler(this.buttonTallRadAB_Click);
            // 
            // buttonSqrRadAB
            // 
            this.buttonSqrRadAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrRadAB.Location = new System.Drawing.Point(3, 57);
            this.buttonSqrRadAB.Name = "buttonSqrRadAB";
            this.buttonSqrRadAB.Size = new System.Drawing.Size(79, 21);
            this.buttonSqrRadAB.TabIndex = 2;
            this.buttonSqrRadAB.Text = "Площадь";
            this.buttonSqrRadAB.UseVisualStyleBackColor = true;
            this.buttonSqrRadAB.Click += new System.EventHandler(this.buttonSqrRadAB_Click);
            // 
            // buttonRadLenAB
            // 
            this.buttonRadLenAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRadLenAB.Location = new System.Drawing.Point(3, 30);
            this.buttonRadLenAB.Name = "buttonRadLenAB";
            this.buttonRadLenAB.Size = new System.Drawing.Size(79, 21);
            this.buttonRadLenAB.TabIndex = 1;
            this.buttonRadLenAB.Text = "Сторона";
            this.buttonRadLenAB.UseVisualStyleBackColor = true;
            this.buttonRadLenAB.Click += new System.EventHandler(this.buttonRadLenAB_Click);
            // 
            // buttonLenRadAB
            // 
            this.buttonLenRadAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLenRadAB.Location = new System.Drawing.Point(3, 3);
            this.buttonLenRadAB.Name = "buttonLenRadAB";
            this.buttonLenRadAB.Size = new System.Drawing.Size(79, 21);
            this.buttonLenRadAB.TabIndex = 0;
            this.buttonLenRadAB.Text = "Основание";
            this.buttonLenRadAB.UseVisualStyleBackColor = true;
            this.buttonLenRadAB.Click += new System.EventHandler(this.buttonLenRadAB_Click);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.tableLayoutPanel19);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox12.Location = new System.Drawing.Point(3, 3);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(90, 137);
            this.groupBox12.TabIndex = 0;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Градусы";
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel19.Controls.Add(this.buttonTallGradAB, 0, 3);
            this.tableLayoutPanel19.Controls.Add(this.buttonSqrGradAB, 0, 2);
            this.tableLayoutPanel19.Controls.Add(this.buttonGradLenAB, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.buttonLenGradAB, 0, 0);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 4;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(84, 111);
            this.tableLayoutPanel19.TabIndex = 0;
            // 
            // buttonTallGradAB
            // 
            this.buttonTallGradAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTallGradAB.Location = new System.Drawing.Point(3, 84);
            this.buttonTallGradAB.Name = "buttonTallGradAB";
            this.buttonTallGradAB.Size = new System.Drawing.Size(78, 24);
            this.buttonTallGradAB.TabIndex = 3;
            this.buttonTallGradAB.Text = "Высота";
            this.buttonTallGradAB.UseVisualStyleBackColor = true;
            this.buttonTallGradAB.Click += new System.EventHandler(this.buttonTallGradAB_Click);
            // 
            // buttonSqrGradAB
            // 
            this.buttonSqrGradAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrGradAB.Location = new System.Drawing.Point(3, 57);
            this.buttonSqrGradAB.Name = "buttonSqrGradAB";
            this.buttonSqrGradAB.Size = new System.Drawing.Size(78, 21);
            this.buttonSqrGradAB.TabIndex = 2;
            this.buttonSqrGradAB.Text = "Площадь";
            this.buttonSqrGradAB.UseVisualStyleBackColor = true;
            this.buttonSqrGradAB.Click += new System.EventHandler(this.buttonSqrGradAB_Click);
            // 
            // buttonGradLenAB
            // 
            this.buttonGradLenAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonGradLenAB.Location = new System.Drawing.Point(3, 30);
            this.buttonGradLenAB.Name = "buttonGradLenAB";
            this.buttonGradLenAB.Size = new System.Drawing.Size(78, 21);
            this.buttonGradLenAB.TabIndex = 1;
            this.buttonGradLenAB.Text = "Сторона";
            this.buttonGradLenAB.UseVisualStyleBackColor = true;
            this.buttonGradLenAB.Click += new System.EventHandler(this.buttonGradLenAB_Click);
            // 
            // buttonLenGradAB
            // 
            this.buttonLenGradAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLenGradAB.Location = new System.Drawing.Point(3, 3);
            this.buttonLenGradAB.Name = "buttonLenGradAB";
            this.buttonLenGradAB.Size = new System.Drawing.Size(78, 21);
            this.buttonLenGradAB.TabIndex = 0;
            this.buttonLenGradAB.Text = "Основание";
            this.buttonLenGradAB.UseVisualStyleBackColor = true;
            this.buttonLenGradAB.Click += new System.EventHandler(this.buttonLenGradAB_Click);
            // 
            // groupBox83
            // 
            this.groupBox83.Controls.Add(this.tableLayoutPanel71);
            this.groupBox83.Location = new System.Drawing.Point(3, 489);
            this.groupBox83.Name = "groupBox83";
            this.groupBox83.Size = new System.Drawing.Size(429, 100);
            this.groupBox83.TabIndex = 1;
            this.groupBox83.TabStop = false;
            this.groupBox83.Text = "Равносторонний треугольник";
            // 
            // tableLayoutPanel71
            // 
            this.tableLayoutPanel71.ColumnCount = 5;
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel71.Controls.Add(this.groupBox84, 0, 0);
            this.tableLayoutPanel71.Controls.Add(this.comboBoxEqualsTriangleFrom, 2, 0);
            this.tableLayoutPanel71.Controls.Add(this.label4, 1, 0);
            this.tableLayoutPanel71.Controls.Add(this.label5, 3, 0);
            this.tableLayoutPanel71.Controls.Add(this.comboBoxEqualsTriangleTo, 4, 0);
            this.tableLayoutPanel71.Controls.Add(this.buttonEqualsLenTriangleConvert, 1, 1);
            this.tableLayoutPanel71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel71.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel71.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel71.Name = "tableLayoutPanel71";
            this.tableLayoutPanel71.RowCount = 2;
            this.tableLayoutPanel71.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel71.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel71.Size = new System.Drawing.Size(423, 74);
            this.tableLayoutPanel71.TabIndex = 0;
            // 
            // groupBox84
            // 
            this.groupBox84.Controls.Add(this.tableLayoutPanel72);
            this.groupBox84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox84.Location = new System.Drawing.Point(0, 0);
            this.groupBox84.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox84.Name = "groupBox84";
            this.tableLayoutPanel71.SetRowSpan(this.groupBox84, 2);
            this.groupBox84.Size = new System.Drawing.Size(79, 74);
            this.groupBox84.TabIndex = 0;
            this.groupBox84.TabStop = false;
            this.groupBox84.Text = "Вход";
            // 
            // tableLayoutPanel72
            // 
            this.tableLayoutPanel72.ColumnCount = 1;
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel72.Controls.Add(this.radioButtonEqualsTriangleA, 0, 0);
            this.tableLayoutPanel72.Controls.Add(this.radioButtonEqualsTriangleB, 0, 1);
            this.tableLayoutPanel72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel72.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel72.Name = "tableLayoutPanel72";
            this.tableLayoutPanel72.RowCount = 2;
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel72.Size = new System.Drawing.Size(73, 48);
            this.tableLayoutPanel72.TabIndex = 0;
            // 
            // radioButtonEqualsTriangleA
            // 
            this.radioButtonEqualsTriangleA.AutoSize = true;
            this.radioButtonEqualsTriangleA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonEqualsTriangleA.Location = new System.Drawing.Point(3, 3);
            this.radioButtonEqualsTriangleA.Name = "radioButtonEqualsTriangleA";
            this.radioButtonEqualsTriangleA.Size = new System.Drawing.Size(67, 18);
            this.radioButtonEqualsTriangleA.TabIndex = 0;
            this.radioButtonEqualsTriangleA.Text = "A";
            this.radioButtonEqualsTriangleA.UseVisualStyleBackColor = true;
            // 
            // radioButtonEqualsTriangleB
            // 
            this.radioButtonEqualsTriangleB.AutoSize = true;
            this.radioButtonEqualsTriangleB.Checked = true;
            this.radioButtonEqualsTriangleB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonEqualsTriangleB.Location = new System.Drawing.Point(3, 27);
            this.radioButtonEqualsTriangleB.Name = "radioButtonEqualsTriangleB";
            this.radioButtonEqualsTriangleB.Size = new System.Drawing.Size(67, 18);
            this.radioButtonEqualsTriangleB.TabIndex = 1;
            this.radioButtonEqualsTriangleB.TabStop = true;
            this.radioButtonEqualsTriangleB.Text = "B";
            this.radioButtonEqualsTriangleB.UseVisualStyleBackColor = true;
            // 
            // comboBoxEqualsTriangleFrom
            // 
            this.comboBoxEqualsTriangleFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEqualsTriangleFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEqualsTriangleFrom.DropDownWidth = 200;
            this.comboBoxEqualsTriangleFrom.FormattingEnabled = true;
            this.comboBoxEqualsTriangleFrom.Location = new System.Drawing.Point(112, 3);
            this.comboBoxEqualsTriangleFrom.Name = "comboBoxEqualsTriangleFrom";
            this.comboBoxEqualsTriangleFrom.Size = new System.Drawing.Size(136, 24);
            this.comboBoxEqualsTriangleFrom.TabIndex = 1;
            this.comboBoxEqualsTriangleFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxEqualsTriangle_MySeclectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(82, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 37);
            this.label4.TabIndex = 2;
            this.label4.Text = "Из";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(254, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 37);
            this.label5.TabIndex = 3;
            this.label5.Text = "В";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxEqualsTriangleTo
            // 
            this.comboBoxEqualsTriangleTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEqualsTriangleTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEqualsTriangleTo.DropDownWidth = 200;
            this.comboBoxEqualsTriangleTo.FormattingEnabled = true;
            this.comboBoxEqualsTriangleTo.Location = new System.Drawing.Point(284, 3);
            this.comboBoxEqualsTriangleTo.Name = "comboBoxEqualsTriangleTo";
            this.comboBoxEqualsTriangleTo.Size = new System.Drawing.Size(136, 24);
            this.comboBoxEqualsTriangleTo.TabIndex = 4;
            this.comboBoxEqualsTriangleTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxEqualsTriangleTo_MySeclectedIndexChanged);
            // 
            // buttonEqualsLenTriangleConvert
            // 
            this.tableLayoutPanel71.SetColumnSpan(this.buttonEqualsLenTriangleConvert, 4);
            this.buttonEqualsLenTriangleConvert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonEqualsLenTriangleConvert.Location = new System.Drawing.Point(82, 40);
            this.buttonEqualsLenTriangleConvert.Name = "buttonEqualsLenTriangleConvert";
            this.buttonEqualsLenTriangleConvert.Size = new System.Drawing.Size(338, 31);
            this.buttonEqualsLenTriangleConvert.TabIndex = 5;
            this.buttonEqualsLenTriangleConvert.Text = "Вычислить";
            this.buttonEqualsLenTriangleConvert.UseVisualStyleBackColor = true;
            this.buttonEqualsLenTriangleConvert.Click += new System.EventHandler(this.buttonEqualsLenTriangleConvert_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.tableLayoutPanel24);
            this.groupBox17.Location = new System.Drawing.Point(3, 595);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(419, 76);
            this.groupBox17.TabIndex = 1;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Угол";
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 4;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel24.Controls.Add(this.buttonGradB, 3, 0);
            this.tableLayoutPanel24.Controls.Add(this.buttonGradA, 2, 0);
            this.tableLayoutPanel24.Controls.Add(this.buttonRadB, 1, 0);
            this.tableLayoutPanel24.Controls.Add(this.buttonRadA, 0, 0);
            this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(413, 50);
            this.tableLayoutPanel24.TabIndex = 0;
            // 
            // buttonGradB
            // 
            this.buttonGradB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonGradB.Location = new System.Drawing.Point(312, 3);
            this.buttonGradB.Name = "buttonGradB";
            this.buttonGradB.Size = new System.Drawing.Size(98, 44);
            this.buttonGradB.TabIndex = 3;
            this.buttonGradB.Text = "Grad(B)";
            this.buttonGradB.UseVisualStyleBackColor = true;
            this.buttonGradB.Click += new System.EventHandler(this.buttonGradB_Click);
            // 
            // buttonGradA
            // 
            this.buttonGradA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonGradA.Location = new System.Drawing.Point(209, 3);
            this.buttonGradA.Name = "buttonGradA";
            this.buttonGradA.Size = new System.Drawing.Size(97, 44);
            this.buttonGradA.TabIndex = 2;
            this.buttonGradA.Text = "Grad(A)";
            this.buttonGradA.UseVisualStyleBackColor = true;
            this.buttonGradA.Click += new System.EventHandler(this.buttonGradA_Click);
            // 
            // buttonRadB
            // 
            this.buttonRadB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRadB.Location = new System.Drawing.Point(106, 3);
            this.buttonRadB.Name = "buttonRadB";
            this.buttonRadB.Size = new System.Drawing.Size(97, 44);
            this.buttonRadB.TabIndex = 1;
            this.buttonRadB.Text = "Rad(B)";
            this.buttonRadB.UseVisualStyleBackColor = true;
            this.buttonRadB.Click += new System.EventHandler(this.buttonRadB_Click);
            // 
            // buttonRadA
            // 
            this.buttonRadA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRadA.Location = new System.Drawing.Point(3, 3);
            this.buttonRadA.Name = "buttonRadA";
            this.buttonRadA.Size = new System.Drawing.Size(97, 44);
            this.buttonRadA.TabIndex = 0;
            this.buttonRadA.Text = "Rad(A)";
            this.buttonRadA.UseVisualStyleBackColor = true;
            this.buttonRadA.Click += new System.EventHandler(this.buttonRadA_Click);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.tableLayoutPanel25);
            this.groupBox18.Location = new System.Drawing.Point(3, 677);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(419, 151);
            this.groupBox18.TabIndex = 2;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Окружность";
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 2;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Controls.Add(this.groupBox19, 0, 0);
            this.tableLayoutPanel25.Controls.Add(this.groupBox20, 1, 0);
            this.tableLayoutPanel25.Controls.Add(this.buttonCurcleCalculate, 0, 1);
            this.tableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 2;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(413, 125);
            this.tableLayoutPanel25.TabIndex = 0;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.tableLayoutPanel26);
            this.groupBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox19.Location = new System.Drawing.Point(3, 3);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(97, 79);
            this.groupBox19.TabIndex = 0;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Ввод";
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 1;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel26.Controls.Add(this.radioButton2, 0, 1);
            this.tableLayoutPanel26.Controls.Add(this.radioButtonCurcleB, 0, 0);
            this.tableLayoutPanel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel26.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 2;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(91, 53);
            this.tableLayoutPanel26.TabIndex = 0;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButton2.Location = new System.Drawing.Point(3, 29);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(85, 21);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "A";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButtonCurcleB
            // 
            this.radioButtonCurcleB.AutoSize = true;
            this.radioButtonCurcleB.Checked = true;
            this.radioButtonCurcleB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonCurcleB.Location = new System.Drawing.Point(3, 3);
            this.radioButtonCurcleB.Name = "radioButtonCurcleB";
            this.radioButtonCurcleB.Size = new System.Drawing.Size(85, 20);
            this.radioButtonCurcleB.TabIndex = 0;
            this.radioButtonCurcleB.TabStop = true;
            this.radioButtonCurcleB.Text = "B";
            this.radioButtonCurcleB.UseVisualStyleBackColor = true;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.tableLayoutPanel27);
            this.groupBox20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox20.Location = new System.Drawing.Point(106, 3);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(304, 79);
            this.groupBox20.TabIndex = 1;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Преобразовывать";
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 2;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel27.Controls.Add(this.groupBox21, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.groupBox22, 1, 0);
            this.tableLayoutPanel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 1;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(298, 53);
            this.tableLayoutPanel27.TabIndex = 0;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.comboBoxCurcleFrom);
            this.groupBox21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox21.Location = new System.Drawing.Point(3, 3);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(143, 47);
            this.groupBox21.TabIndex = 0;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Из";
            // 
            // comboBoxCurcleFrom
            // 
            this.comboBoxCurcleFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxCurcleFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCurcleFrom.DropDownWidth = 200;
            this.comboBoxCurcleFrom.FormattingEnabled = true;
            this.comboBoxCurcleFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxCurcleFrom.Name = "comboBoxCurcleFrom";
            this.comboBoxCurcleFrom.Size = new System.Drawing.Size(137, 24);
            this.comboBoxCurcleFrom.TabIndex = 0;
            this.comboBoxCurcleFrom.SelectedIndexChanged += new System.EventHandler(this.comboBoxCurcleFrom_SelectedIndexChanged);
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.comboBoxCurcleTo);
            this.groupBox22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox22.Location = new System.Drawing.Point(152, 3);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(143, 47);
            this.groupBox22.TabIndex = 1;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "В";
            // 
            // comboBoxCurcleTo
            // 
            this.comboBoxCurcleTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxCurcleTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCurcleTo.DropDownWidth = 200;
            this.comboBoxCurcleTo.FormattingEnabled = true;
            this.comboBoxCurcleTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxCurcleTo.Name = "comboBoxCurcleTo";
            this.comboBoxCurcleTo.Size = new System.Drawing.Size(137, 24);
            this.comboBoxCurcleTo.TabIndex = 1;
            this.comboBoxCurcleTo.SelectedIndexChanged += new System.EventHandler(this.comboBoxCurcleTo_SelectedIndexChanged);
            // 
            // buttonCurcleCalculate
            // 
            this.tableLayoutPanel25.SetColumnSpan(this.buttonCurcleCalculate, 2);
            this.buttonCurcleCalculate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCurcleCalculate.Location = new System.Drawing.Point(3, 88);
            this.buttonCurcleCalculate.Name = "buttonCurcleCalculate";
            this.buttonCurcleCalculate.Size = new System.Drawing.Size(407, 34);
            this.buttonCurcleCalculate.TabIndex = 2;
            this.buttonCurcleCalculate.Text = "Вычислить";
            this.buttonCurcleCalculate.UseVisualStyleBackColor = true;
            this.buttonCurcleCalculate.Click += new System.EventHandler(this.buttonCurcleCalculate_Click);
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.tableLayoutPanel28);
            this.groupBox23.Location = new System.Drawing.Point(3, 834);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(419, 240);
            this.groupBox23.TabIndex = 3;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Тригонометрические функции";
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.ColumnCount = 2;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Controls.Add(this.groupBox26, 1, 0);
            this.tableLayoutPanel28.Controls.Add(this.groupBox24, 0, 0);
            this.tableLayoutPanel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel28.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 1;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 214F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(413, 214);
            this.tableLayoutPanel28.TabIndex = 0;
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.tableLayoutPanel31);
            this.groupBox26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox26.Location = new System.Drawing.Point(209, 3);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(201, 208);
            this.groupBox26.TabIndex = 1;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Обратные";
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.ColumnCount = 2;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.23077F));
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.76923F));
            this.tableLayoutPanel31.Controls.Add(this.groupBox29, 1, 0);
            this.tableLayoutPanel31.Controls.Add(this.tableLayoutPanel37, 0, 1);
            this.tableLayoutPanel31.Controls.Add(this.tableLayoutPanel36, 0, 1);
            this.tableLayoutPanel31.Controls.Add(this.groupBox27, 0, 0);
            this.tableLayoutPanel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel31.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 2;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(195, 182);
            this.tableLayoutPanel31.TabIndex = 0;
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.tableLayoutPanel38);
            this.groupBox29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox29.Location = new System.Drawing.Point(99, 3);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(93, 83);
            this.groupBox29.TabIndex = 5;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "Входной параметр";
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel38.ColumnCount = 1;
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.Controls.Add(this.radioASinA, 0, 1);
            this.tableLayoutPanel38.Controls.Add(this.radioASinB, 0, 2);
            this.tableLayoutPanel38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel38.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel38.Margin = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 3;
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(87, 57);
            this.tableLayoutPanel38.TabIndex = 0;
            // 
            // radioASinA
            // 
            this.radioASinA.AutoSize = true;
            this.radioASinA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioASinA.Location = new System.Drawing.Point(3, 13);
            this.radioASinA.Name = "radioASinA";
            this.radioASinA.Size = new System.Drawing.Size(81, 17);
            this.radioASinA.TabIndex = 0;
            this.radioASinA.TabStop = true;
            this.radioASinA.Text = "A";
            this.radioASinA.UseVisualStyleBackColor = true;
            // 
            // radioASinB
            // 
            this.radioASinB.AutoSize = true;
            this.radioASinB.Checked = true;
            this.radioASinB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioASinB.Location = new System.Drawing.Point(3, 36);
            this.radioASinB.Name = "radioASinB";
            this.radioASinB.Size = new System.Drawing.Size(81, 18);
            this.radioASinB.TabIndex = 1;
            this.radioASinB.TabStop = true;
            this.radioASinB.Text = "B";
            this.radioASinB.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel37
            // 
            this.tableLayoutPanel37.ColumnCount = 1;
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel37.Controls.Add(this.buttonAtg, 0, 2);
            this.tableLayoutPanel37.Controls.Add(this.buttonAcos, 0, 1);
            this.tableLayoutPanel37.Controls.Add(this.buttonArcSin, 0, 0);
            this.tableLayoutPanel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel37.Location = new System.Drawing.Point(3, 92);
            this.tableLayoutPanel37.Name = "tableLayoutPanel37";
            this.tableLayoutPanel37.RowCount = 3;
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel37.Size = new System.Drawing.Size(90, 87);
            this.tableLayoutPanel37.TabIndex = 4;
            // 
            // buttonAtg
            // 
            this.buttonAtg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAtg.Location = new System.Drawing.Point(3, 61);
            this.buttonAtg.Name = "buttonAtg";
            this.buttonAtg.Size = new System.Drawing.Size(84, 23);
            this.buttonAtg.TabIndex = 3;
            this.buttonAtg.Text = "arctg";
            this.buttonAtg.UseVisualStyleBackColor = true;
            this.buttonAtg.Click += new System.EventHandler(this.buttonAtg_Click);
            // 
            // buttonAcos
            // 
            this.buttonAcos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAcos.Location = new System.Drawing.Point(3, 32);
            this.buttonAcos.Name = "buttonAcos";
            this.buttonAcos.Size = new System.Drawing.Size(84, 23);
            this.buttonAcos.TabIndex = 2;
            this.buttonAcos.Text = "arcsin";
            this.buttonAcos.UseVisualStyleBackColor = true;
            this.buttonAcos.Click += new System.EventHandler(this.buttonAcos_Click);
            // 
            // buttonArcSin
            // 
            this.buttonArcSin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonArcSin.Location = new System.Drawing.Point(3, 3);
            this.buttonArcSin.Name = "buttonArcSin";
            this.buttonArcSin.Size = new System.Drawing.Size(84, 23);
            this.buttonArcSin.TabIndex = 1;
            this.buttonArcSin.Text = "arcsin";
            this.buttonArcSin.UseVisualStyleBackColor = true;
            this.buttonArcSin.Click += new System.EventHandler(this.buttonArcSin_Click);
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.ColumnCount = 1;
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel36.Controls.Add(this.buttonActg, 0, 2);
            this.tableLayoutPanel36.Controls.Add(this.buttonAsec, 0, 1);
            this.tableLayoutPanel36.Controls.Add(this.buttonAcosec, 0, 0);
            this.tableLayoutPanel36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel36.Location = new System.Drawing.Point(99, 92);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 3;
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(93, 87);
            this.tableLayoutPanel36.TabIndex = 3;
            // 
            // buttonActg
            // 
            this.buttonActg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonActg.Location = new System.Drawing.Point(3, 61);
            this.buttonActg.Name = "buttonActg";
            this.buttonActg.Size = new System.Drawing.Size(87, 23);
            this.buttonActg.TabIndex = 6;
            this.buttonActg.Text = "arcctg";
            this.buttonActg.UseVisualStyleBackColor = true;
            this.buttonActg.Click += new System.EventHandler(this.buttonActg_Click);
            // 
            // buttonAsec
            // 
            this.buttonAsec.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAsec.Location = new System.Drawing.Point(3, 32);
            this.buttonAsec.Name = "buttonAsec";
            this.buttonAsec.Size = new System.Drawing.Size(87, 23);
            this.buttonAsec.TabIndex = 5;
            this.buttonAsec.Text = "arcsec";
            this.buttonAsec.UseVisualStyleBackColor = true;
            this.buttonAsec.Click += new System.EventHandler(this.buttonAsec_Click);
            // 
            // buttonAcosec
            // 
            this.buttonAcosec.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAcosec.Location = new System.Drawing.Point(3, 3);
            this.buttonAcosec.Name = "buttonAcosec";
            this.buttonAcosec.Size = new System.Drawing.Size(87, 23);
            this.buttonAcosec.TabIndex = 4;
            this.buttonAcosec.Text = "arccosec";
            this.buttonAcosec.UseVisualStyleBackColor = true;
            this.buttonAcosec.Click += new System.EventHandler(this.buttonAcosec_Click);
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.tableLayoutPanel32);
            this.groupBox27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox27.Location = new System.Drawing.Point(3, 3);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(90, 83);
            this.groupBox27.TabIndex = 0;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "Мера угла";
            // 
            // tableLayoutPanel32
            // 
            this.tableLayoutPanel32.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel32.ColumnCount = 1;
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.Controls.Add(this.radioASinGrad, 0, 1);
            this.tableLayoutPanel32.Controls.Add(this.radioASinRad, 0, 2);
            this.tableLayoutPanel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel32.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel32.Name = "tableLayoutPanel32";
            this.tableLayoutPanel32.RowCount = 3;
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel32.Size = new System.Drawing.Size(84, 57);
            this.tableLayoutPanel32.TabIndex = 0;
            // 
            // radioASinGrad
            // 
            this.radioASinGrad.AutoSize = true;
            this.radioASinGrad.Checked = true;
            this.radioASinGrad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioASinGrad.Location = new System.Drawing.Point(3, 13);
            this.radioASinGrad.Name = "radioASinGrad";
            this.radioASinGrad.Size = new System.Drawing.Size(78, 17);
            this.radioASinGrad.TabIndex = 0;
            this.radioASinGrad.TabStop = true;
            this.radioASinGrad.Text = "Градусы";
            this.radioASinGrad.UseVisualStyleBackColor = true;
            // 
            // radioASinRad
            // 
            this.radioASinRad.AutoSize = true;
            this.radioASinRad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioASinRad.Location = new System.Drawing.Point(3, 36);
            this.radioASinRad.Name = "radioASinRad";
            this.radioASinRad.Size = new System.Drawing.Size(78, 18);
            this.radioASinRad.TabIndex = 1;
            this.radioASinRad.TabStop = true;
            this.radioASinRad.Text = "Радианы";
            this.radioASinRad.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.tableLayoutPanel29);
            this.groupBox24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox24.Location = new System.Drawing.Point(3, 3);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(200, 208);
            this.groupBox24.TabIndex = 0;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Прямые";
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 2;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel29.Controls.Add(this.tableLayoutPanel35, 1, 1);
            this.tableLayoutPanel29.Controls.Add(this.groupBox28, 1, 0);
            this.tableLayoutPanel29.Controls.Add(this.groupBox25, 0, 0);
            this.tableLayoutPanel29.Controls.Add(this.tableLayoutPanel34, 0, 1);
            this.tableLayoutPanel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel29.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel29.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 2;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(194, 182);
            this.tableLayoutPanel29.TabIndex = 0;
            // 
            // tableLayoutPanel35
            // 
            this.tableLayoutPanel35.ColumnCount = 1;
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel35.Controls.Add(this.buttonSec, 0, 1);
            this.tableLayoutPanel35.Controls.Add(this.buttonCosec, 0, 0);
            this.tableLayoutPanel35.Controls.Add(this.buttonCtg, 0, 2);
            this.tableLayoutPanel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel35.Location = new System.Drawing.Point(100, 92);
            this.tableLayoutPanel35.Name = "tableLayoutPanel35";
            this.tableLayoutPanel35.RowCount = 3;
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel35.Size = new System.Drawing.Size(91, 87);
            this.tableLayoutPanel35.TabIndex = 3;
            // 
            // buttonSec
            // 
            this.buttonSec.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSec.Location = new System.Drawing.Point(3, 32);
            this.buttonSec.Name = "buttonSec";
            this.buttonSec.Size = new System.Drawing.Size(85, 23);
            this.buttonSec.TabIndex = 5;
            this.buttonSec.Text = "sec";
            this.buttonSec.UseVisualStyleBackColor = true;
            this.buttonSec.Click += new System.EventHandler(this.buttonSec_Click);
            // 
            // buttonCosec
            // 
            this.buttonCosec.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCosec.Location = new System.Drawing.Point(3, 3);
            this.buttonCosec.Name = "buttonCosec";
            this.buttonCosec.Size = new System.Drawing.Size(85, 23);
            this.buttonCosec.TabIndex = 4;
            this.buttonCosec.Text = "cosec";
            this.buttonCosec.UseVisualStyleBackColor = true;
            this.buttonCosec.Click += new System.EventHandler(this.buttonCosec_Click);
            // 
            // buttonCtg
            // 
            this.buttonCtg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCtg.Location = new System.Drawing.Point(3, 61);
            this.buttonCtg.Name = "buttonCtg";
            this.buttonCtg.Size = new System.Drawing.Size(85, 23);
            this.buttonCtg.TabIndex = 3;
            this.buttonCtg.Text = "ctg";
            this.buttonCtg.UseVisualStyleBackColor = true;
            this.buttonCtg.Click += new System.EventHandler(this.buttonCtg_Click);
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.tableLayoutPanel33);
            this.groupBox28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox28.Location = new System.Drawing.Point(100, 3);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(91, 83);
            this.groupBox28.TabIndex = 1;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Входной параметр";
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel33.ColumnCount = 1;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.Controls.Add(this.radioSinA, 0, 1);
            this.tableLayoutPanel33.Controls.Add(this.radioSinB, 0, 2);
            this.tableLayoutPanel33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel33.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel33.Margin = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 3;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(85, 57);
            this.tableLayoutPanel33.TabIndex = 0;
            // 
            // radioSinA
            // 
            this.radioSinA.AutoSize = true;
            this.radioSinA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioSinA.Location = new System.Drawing.Point(3, 13);
            this.radioSinA.Name = "radioSinA";
            this.radioSinA.Size = new System.Drawing.Size(79, 17);
            this.radioSinA.TabIndex = 0;
            this.radioSinA.Text = "A";
            this.radioSinA.UseVisualStyleBackColor = true;
            // 
            // radioSinB
            // 
            this.radioSinB.AutoSize = true;
            this.radioSinB.Checked = true;
            this.radioSinB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioSinB.Location = new System.Drawing.Point(3, 36);
            this.radioSinB.Name = "radioSinB";
            this.radioSinB.Size = new System.Drawing.Size(79, 18);
            this.radioSinB.TabIndex = 1;
            this.radioSinB.TabStop = true;
            this.radioSinB.Text = "B";
            this.radioSinB.UseVisualStyleBackColor = true;
            this.radioSinB.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.tableLayoutPanel30);
            this.groupBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox25.Location = new System.Drawing.Point(3, 3);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(91, 83);
            this.groupBox25.TabIndex = 0;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Мера угла";
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel30.ColumnCount = 1;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.Controls.Add(this.radioSinGrad, 0, 1);
            this.tableLayoutPanel30.Controls.Add(this.radioSinRad, 0, 2);
            this.tableLayoutPanel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 3;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(85, 57);
            this.tableLayoutPanel30.TabIndex = 0;
            // 
            // radioSinGrad
            // 
            this.radioSinGrad.AutoSize = true;
            this.radioSinGrad.Checked = true;
            this.radioSinGrad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioSinGrad.Location = new System.Drawing.Point(3, 13);
            this.radioSinGrad.Name = "radioSinGrad";
            this.radioSinGrad.Size = new System.Drawing.Size(79, 17);
            this.radioSinGrad.TabIndex = 0;
            this.radioSinGrad.TabStop = true;
            this.radioSinGrad.Text = "Градусы";
            this.radioSinGrad.UseVisualStyleBackColor = true;
            // 
            // radioSinRad
            // 
            this.radioSinRad.AutoSize = true;
            this.radioSinRad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioSinRad.Location = new System.Drawing.Point(3, 36);
            this.radioSinRad.Name = "radioSinRad";
            this.radioSinRad.Size = new System.Drawing.Size(79, 18);
            this.radioSinRad.TabIndex = 1;
            this.radioSinRad.Text = "Радианы";
            this.radioSinRad.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.ColumnCount = 1;
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel34.Controls.Add(this.buttonTg, 0, 2);
            this.tableLayoutPanel34.Controls.Add(this.buttonCos, 0, 1);
            this.tableLayoutPanel34.Controls.Add(this.buttonSin, 0, 0);
            this.tableLayoutPanel34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel34.Location = new System.Drawing.Point(3, 92);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 3;
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(91, 87);
            this.tableLayoutPanel34.TabIndex = 2;
            // 
            // buttonTg
            // 
            this.buttonTg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTg.Location = new System.Drawing.Point(3, 61);
            this.buttonTg.Name = "buttonTg";
            this.buttonTg.Size = new System.Drawing.Size(85, 23);
            this.buttonTg.TabIndex = 2;
            this.buttonTg.Text = "tg";
            this.buttonTg.UseVisualStyleBackColor = true;
            this.buttonTg.Click += new System.EventHandler(this.buttonTg_Click);
            // 
            // buttonCos
            // 
            this.buttonCos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCos.Location = new System.Drawing.Point(3, 32);
            this.buttonCos.Name = "buttonCos";
            this.buttonCos.Size = new System.Drawing.Size(85, 23);
            this.buttonCos.TabIndex = 1;
            this.buttonCos.Text = "cos";
            this.buttonCos.UseVisualStyleBackColor = true;
            this.buttonCos.Click += new System.EventHandler(this.buttonCos_Click);
            // 
            // buttonSin
            // 
            this.buttonSin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSin.Location = new System.Drawing.Point(3, 3);
            this.buttonSin.Name = "buttonSin";
            this.buttonSin.Size = new System.Drawing.Size(85, 23);
            this.buttonSin.TabIndex = 0;
            this.buttonSin.Text = "sin";
            this.buttonSin.UseVisualStyleBackColor = true;
            this.buttonSin.Click += new System.EventHandler(this.buttonSin_Click);
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.tableLayoutPanel39);
            this.groupBox30.Location = new System.Drawing.Point(3, 1080);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(419, 151);
            this.groupBox30.TabIndex = 4;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "Время";
            // 
            // tableLayoutPanel39
            // 
            this.tableLayoutPanel39.ColumnCount = 2;
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel39.Controls.Add(this.groupBox31, 0, 0);
            this.tableLayoutPanel39.Controls.Add(this.groupBox32, 1, 0);
            this.tableLayoutPanel39.Controls.Add(this.buttonTimeCalculate, 0, 1);
            this.tableLayoutPanel39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel39.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel39.Name = "tableLayoutPanel39";
            this.tableLayoutPanel39.RowCount = 2;
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68F));
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel39.Size = new System.Drawing.Size(413, 125);
            this.tableLayoutPanel39.TabIndex = 0;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.tableLayoutPanel40);
            this.groupBox31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox31.Location = new System.Drawing.Point(3, 3);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(97, 79);
            this.groupBox31.TabIndex = 0;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "Ввод";
            // 
            // tableLayoutPanel40
            // 
            this.tableLayoutPanel40.ColumnCount = 1;
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel40.Controls.Add(this.radioButtonTimeA, 0, 1);
            this.tableLayoutPanel40.Controls.Add(this.radioButtonTimeB, 0, 0);
            this.tableLayoutPanel40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel40.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel40.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel40.Name = "tableLayoutPanel40";
            this.tableLayoutPanel40.RowCount = 2;
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel40.Size = new System.Drawing.Size(91, 53);
            this.tableLayoutPanel40.TabIndex = 0;
            // 
            // radioButtonTimeA
            // 
            this.radioButtonTimeA.AutoSize = true;
            this.radioButtonTimeA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonTimeA.Location = new System.Drawing.Point(3, 29);
            this.radioButtonTimeA.Name = "radioButtonTimeA";
            this.radioButtonTimeA.Size = new System.Drawing.Size(85, 21);
            this.radioButtonTimeA.TabIndex = 1;
            this.radioButtonTimeA.Text = "A";
            this.radioButtonTimeA.UseVisualStyleBackColor = true;
            // 
            // radioButtonTimeB
            // 
            this.radioButtonTimeB.AutoSize = true;
            this.radioButtonTimeB.Checked = true;
            this.radioButtonTimeB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonTimeB.Location = new System.Drawing.Point(3, 3);
            this.radioButtonTimeB.Name = "radioButtonTimeB";
            this.radioButtonTimeB.Size = new System.Drawing.Size(85, 20);
            this.radioButtonTimeB.TabIndex = 0;
            this.radioButtonTimeB.TabStop = true;
            this.radioButtonTimeB.Text = "B";
            this.radioButtonTimeB.UseVisualStyleBackColor = true;
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.tableLayoutPanel41);
            this.groupBox32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox32.Location = new System.Drawing.Point(106, 3);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(304, 79);
            this.groupBox32.TabIndex = 1;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "Преобразовывать";
            // 
            // tableLayoutPanel41
            // 
            this.tableLayoutPanel41.ColumnCount = 2;
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel41.Controls.Add(this.groupBox33, 0, 0);
            this.tableLayoutPanel41.Controls.Add(this.groupBox34, 1, 0);
            this.tableLayoutPanel41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel41.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel41.Name = "tableLayoutPanel41";
            this.tableLayoutPanel41.RowCount = 1;
            this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel41.Size = new System.Drawing.Size(298, 53);
            this.tableLayoutPanel41.TabIndex = 0;
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.comboBoxTimeFrom);
            this.groupBox33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox33.Location = new System.Drawing.Point(3, 3);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(143, 47);
            this.groupBox33.TabIndex = 0;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "Из";
            // 
            // comboBoxTimeFrom
            // 
            this.comboBoxTimeFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxTimeFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTimeFrom.DropDownWidth = 200;
            this.comboBoxTimeFrom.FormattingEnabled = true;
            this.comboBoxTimeFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxTimeFrom.Name = "comboBoxTimeFrom";
            this.comboBoxTimeFrom.Size = new System.Drawing.Size(137, 24);
            this.comboBoxTimeFrom.TabIndex = 0;
            this.comboBoxTimeFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxTimeFrom_MySeclectedIndexChanged);
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.comboBoxTimeTo);
            this.groupBox34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox34.Location = new System.Drawing.Point(152, 3);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Size = new System.Drawing.Size(143, 47);
            this.groupBox34.TabIndex = 1;
            this.groupBox34.TabStop = false;
            this.groupBox34.Text = "В";
            // 
            // comboBoxTimeTo
            // 
            this.comboBoxTimeTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxTimeTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTimeTo.DropDownWidth = 200;
            this.comboBoxTimeTo.FormattingEnabled = true;
            this.comboBoxTimeTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxTimeTo.Name = "comboBoxTimeTo";
            this.comboBoxTimeTo.Size = new System.Drawing.Size(137, 24);
            this.comboBoxTimeTo.TabIndex = 1;
            this.comboBoxTimeTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxTimeTo_MySeclectedIndexChanged);
            // 
            // buttonTimeCalculate
            // 
            this.tableLayoutPanel39.SetColumnSpan(this.buttonTimeCalculate, 2);
            this.buttonTimeCalculate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTimeCalculate.Location = new System.Drawing.Point(3, 88);
            this.buttonTimeCalculate.Name = "buttonTimeCalculate";
            this.buttonTimeCalculate.Size = new System.Drawing.Size(407, 34);
            this.buttonTimeCalculate.TabIndex = 2;
            this.buttonTimeCalculate.Text = "Вычислить";
            this.buttonTimeCalculate.UseVisualStyleBackColor = true;
            this.buttonTimeCalculate.Click += new System.EventHandler(this.buttonTimeCalculate_Click);
            // 
            // groupBox35
            // 
            this.groupBox35.Controls.Add(this.tableLayoutPanel42);
            this.groupBox35.Location = new System.Drawing.Point(3, 1237);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Size = new System.Drawing.Size(419, 151);
            this.groupBox35.TabIndex = 5;
            this.groupBox35.TabStop = false;
            this.groupBox35.Text = "Длина (Расстояние)";
            // 
            // tableLayoutPanel42
            // 
            this.tableLayoutPanel42.ColumnCount = 2;
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel42.Controls.Add(this.groupBox36, 0, 0);
            this.tableLayoutPanel42.Controls.Add(this.groupBox37, 1, 0);
            this.tableLayoutPanel42.Controls.Add(this.buttonLengthConvert, 0, 1);
            this.tableLayoutPanel42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel42.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel42.Name = "tableLayoutPanel42";
            this.tableLayoutPanel42.RowCount = 2;
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68F));
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel42.Size = new System.Drawing.Size(413, 125);
            this.tableLayoutPanel42.TabIndex = 0;
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.tableLayoutPanel43);
            this.groupBox36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox36.Location = new System.Drawing.Point(3, 3);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(97, 79);
            this.groupBox36.TabIndex = 0;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "Ввод";
            // 
            // tableLayoutPanel43
            // 
            this.tableLayoutPanel43.ColumnCount = 1;
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel43.Controls.Add(this.radioButtonMetrA, 0, 1);
            this.tableLayoutPanel43.Controls.Add(this.radioButtonMetrB, 0, 0);
            this.tableLayoutPanel43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel43.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel43.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel43.Name = "tableLayoutPanel43";
            this.tableLayoutPanel43.RowCount = 2;
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel43.Size = new System.Drawing.Size(91, 53);
            this.tableLayoutPanel43.TabIndex = 0;
            // 
            // radioButtonMetrA
            // 
            this.radioButtonMetrA.AutoSize = true;
            this.radioButtonMetrA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonMetrA.Location = new System.Drawing.Point(3, 29);
            this.radioButtonMetrA.Name = "radioButtonMetrA";
            this.radioButtonMetrA.Size = new System.Drawing.Size(85, 21);
            this.radioButtonMetrA.TabIndex = 1;
            this.radioButtonMetrA.Text = "A";
            this.radioButtonMetrA.UseVisualStyleBackColor = true;
            // 
            // radioButtonMetrB
            // 
            this.radioButtonMetrB.AutoSize = true;
            this.radioButtonMetrB.Checked = true;
            this.radioButtonMetrB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonMetrB.Location = new System.Drawing.Point(3, 3);
            this.radioButtonMetrB.Name = "radioButtonMetrB";
            this.radioButtonMetrB.Size = new System.Drawing.Size(85, 20);
            this.radioButtonMetrB.TabIndex = 0;
            this.radioButtonMetrB.TabStop = true;
            this.radioButtonMetrB.Text = "B";
            this.radioButtonMetrB.UseVisualStyleBackColor = true;
            // 
            // groupBox37
            // 
            this.groupBox37.Controls.Add(this.tableLayoutPanel44);
            this.groupBox37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox37.Location = new System.Drawing.Point(106, 3);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Size = new System.Drawing.Size(304, 79);
            this.groupBox37.TabIndex = 1;
            this.groupBox37.TabStop = false;
            this.groupBox37.Text = "Преобразовывать";
            // 
            // tableLayoutPanel44
            // 
            this.tableLayoutPanel44.ColumnCount = 2;
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel44.Controls.Add(this.groupBox38, 0, 0);
            this.tableLayoutPanel44.Controls.Add(this.groupBox39, 1, 0);
            this.tableLayoutPanel44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel44.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel44.Name = "tableLayoutPanel44";
            this.tableLayoutPanel44.RowCount = 1;
            this.tableLayoutPanel44.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel44.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel44.Size = new System.Drawing.Size(298, 53);
            this.tableLayoutPanel44.TabIndex = 0;
            // 
            // groupBox38
            // 
            this.groupBox38.Controls.Add(this.comboBoxMetrFrom);
            this.groupBox38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox38.Location = new System.Drawing.Point(3, 3);
            this.groupBox38.Name = "groupBox38";
            this.groupBox38.Size = new System.Drawing.Size(143, 47);
            this.groupBox38.TabIndex = 0;
            this.groupBox38.TabStop = false;
            this.groupBox38.Text = "Из";
            // 
            // comboBoxMetrFrom
            // 
            this.comboBoxMetrFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxMetrFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMetrFrom.DropDownWidth = 200;
            this.comboBoxMetrFrom.FormattingEnabled = true;
            this.comboBoxMetrFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxMetrFrom.Name = "comboBoxMetrFrom";
            this.comboBoxMetrFrom.Size = new System.Drawing.Size(137, 24);
            this.comboBoxMetrFrom.TabIndex = 0;
            this.comboBoxMetrFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxMetrFrom_MySeclectedIndexChanged);
            // 
            // groupBox39
            // 
            this.groupBox39.Controls.Add(this.comboBoxMetrTo);
            this.groupBox39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox39.Location = new System.Drawing.Point(152, 3);
            this.groupBox39.Name = "groupBox39";
            this.groupBox39.Size = new System.Drawing.Size(143, 47);
            this.groupBox39.TabIndex = 1;
            this.groupBox39.TabStop = false;
            this.groupBox39.Text = "В";
            // 
            // comboBoxMetrTo
            // 
            this.comboBoxMetrTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxMetrTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMetrTo.DropDownWidth = 200;
            this.comboBoxMetrTo.FormattingEnabled = true;
            this.comboBoxMetrTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxMetrTo.Name = "comboBoxMetrTo";
            this.comboBoxMetrTo.Size = new System.Drawing.Size(137, 24);
            this.comboBoxMetrTo.TabIndex = 1;
            this.comboBoxMetrTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxMetrTo_MySeclectedIndexChanged);
            // 
            // buttonLengthConvert
            // 
            this.tableLayoutPanel42.SetColumnSpan(this.buttonLengthConvert, 2);
            this.buttonLengthConvert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLengthConvert.Location = new System.Drawing.Point(3, 88);
            this.buttonLengthConvert.Name = "buttonLengthConvert";
            this.buttonLengthConvert.Size = new System.Drawing.Size(407, 34);
            this.buttonLengthConvert.TabIndex = 2;
            this.buttonLengthConvert.Text = "Вычислить";
            this.buttonLengthConvert.UseVisualStyleBackColor = true;
            this.buttonLengthConvert.Click += new System.EventHandler(this.buttonLengthConvert_Click);
            // 
            // groupBox40
            // 
            this.groupBox40.Controls.Add(this.tableLayoutPanel45);
            this.groupBox40.Location = new System.Drawing.Point(3, 1394);
            this.groupBox40.Name = "groupBox40";
            this.groupBox40.Size = new System.Drawing.Size(419, 151);
            this.groupBox40.TabIndex = 6;
            this.groupBox40.TabStop = false;
            this.groupBox40.Text = "Температура";
            // 
            // tableLayoutPanel45
            // 
            this.tableLayoutPanel45.ColumnCount = 2;
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel45.Controls.Add(this.groupBox41, 0, 0);
            this.tableLayoutPanel45.Controls.Add(this.groupBox42, 1, 0);
            this.tableLayoutPanel45.Controls.Add(this.buttonGradusConvert, 0, 1);
            this.tableLayoutPanel45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel45.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel45.Name = "tableLayoutPanel45";
            this.tableLayoutPanel45.RowCount = 2;
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68F));
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel45.Size = new System.Drawing.Size(413, 125);
            this.tableLayoutPanel45.TabIndex = 0;
            // 
            // groupBox41
            // 
            this.groupBox41.Controls.Add(this.tableLayoutPanel46);
            this.groupBox41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox41.Location = new System.Drawing.Point(3, 3);
            this.groupBox41.Name = "groupBox41";
            this.groupBox41.Size = new System.Drawing.Size(97, 79);
            this.groupBox41.TabIndex = 0;
            this.groupBox41.TabStop = false;
            this.groupBox41.Text = "Ввод";
            // 
            // tableLayoutPanel46
            // 
            this.tableLayoutPanel46.ColumnCount = 1;
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel46.Controls.Add(this.radioGradusA, 0, 1);
            this.tableLayoutPanel46.Controls.Add(this.radioGradusB, 0, 0);
            this.tableLayoutPanel46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel46.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel46.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel46.Name = "tableLayoutPanel46";
            this.tableLayoutPanel46.RowCount = 2;
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel46.Size = new System.Drawing.Size(91, 53);
            this.tableLayoutPanel46.TabIndex = 0;
            // 
            // radioGradusA
            // 
            this.radioGradusA.AutoSize = true;
            this.radioGradusA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioGradusA.Location = new System.Drawing.Point(3, 29);
            this.radioGradusA.Name = "radioGradusA";
            this.radioGradusA.Size = new System.Drawing.Size(85, 21);
            this.radioGradusA.TabIndex = 1;
            this.radioGradusA.Text = "A";
            this.radioGradusA.UseVisualStyleBackColor = true;
            // 
            // radioGradusB
            // 
            this.radioGradusB.AutoSize = true;
            this.radioGradusB.Checked = true;
            this.radioGradusB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioGradusB.Location = new System.Drawing.Point(3, 3);
            this.radioGradusB.Name = "radioGradusB";
            this.radioGradusB.Size = new System.Drawing.Size(85, 20);
            this.radioGradusB.TabIndex = 0;
            this.radioGradusB.TabStop = true;
            this.radioGradusB.Text = "B";
            this.radioGradusB.UseVisualStyleBackColor = true;
            // 
            // groupBox42
            // 
            this.groupBox42.Controls.Add(this.tableLayoutPanel47);
            this.groupBox42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox42.Location = new System.Drawing.Point(106, 3);
            this.groupBox42.Name = "groupBox42";
            this.groupBox42.Size = new System.Drawing.Size(304, 79);
            this.groupBox42.TabIndex = 1;
            this.groupBox42.TabStop = false;
            this.groupBox42.Text = "Преобразовывать";
            // 
            // tableLayoutPanel47
            // 
            this.tableLayoutPanel47.ColumnCount = 2;
            this.tableLayoutPanel47.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel47.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel47.Controls.Add(this.groupBox43, 0, 0);
            this.tableLayoutPanel47.Controls.Add(this.groupBox44, 1, 0);
            this.tableLayoutPanel47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel47.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel47.Name = "tableLayoutPanel47";
            this.tableLayoutPanel47.RowCount = 1;
            this.tableLayoutPanel47.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel47.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel47.Size = new System.Drawing.Size(298, 53);
            this.tableLayoutPanel47.TabIndex = 0;
            // 
            // groupBox43
            // 
            this.groupBox43.Controls.Add(this.comboBoxGradusFrom);
            this.groupBox43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox43.Location = new System.Drawing.Point(3, 3);
            this.groupBox43.Name = "groupBox43";
            this.groupBox43.Size = new System.Drawing.Size(143, 47);
            this.groupBox43.TabIndex = 0;
            this.groupBox43.TabStop = false;
            this.groupBox43.Text = "Из";
            // 
            // comboBoxGradusFrom
            // 
            this.comboBoxGradusFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxGradusFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxGradusFrom.DropDownWidth = 200;
            this.comboBoxGradusFrom.FormattingEnabled = true;
            this.comboBoxGradusFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxGradusFrom.Name = "comboBoxGradusFrom";
            this.comboBoxGradusFrom.Size = new System.Drawing.Size(137, 24);
            this.comboBoxGradusFrom.TabIndex = 0;
            this.comboBoxGradusFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxGradusFrom_MySeclectedIndexChanged);
            // 
            // groupBox44
            // 
            this.groupBox44.Controls.Add(this.comboBoxGradusTo);
            this.groupBox44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox44.Location = new System.Drawing.Point(152, 3);
            this.groupBox44.Name = "groupBox44";
            this.groupBox44.Size = new System.Drawing.Size(143, 47);
            this.groupBox44.TabIndex = 1;
            this.groupBox44.TabStop = false;
            this.groupBox44.Text = "В";
            // 
            // comboBoxGradusTo
            // 
            this.comboBoxGradusTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxGradusTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxGradusTo.DropDownWidth = 200;
            this.comboBoxGradusTo.FormattingEnabled = true;
            this.comboBoxGradusTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxGradusTo.Name = "comboBoxGradusTo";
            this.comboBoxGradusTo.Size = new System.Drawing.Size(137, 24);
            this.comboBoxGradusTo.TabIndex = 1;
            this.comboBoxGradusTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxGradusTo_MySeclectedIndexChanged);
            // 
            // buttonGradusConvert
            // 
            this.tableLayoutPanel45.SetColumnSpan(this.buttonGradusConvert, 2);
            this.buttonGradusConvert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonGradusConvert.Location = new System.Drawing.Point(3, 88);
            this.buttonGradusConvert.Name = "buttonGradusConvert";
            this.buttonGradusConvert.Size = new System.Drawing.Size(407, 34);
            this.buttonGradusConvert.TabIndex = 2;
            this.buttonGradusConvert.Text = "Вычислить";
            this.buttonGradusConvert.UseVisualStyleBackColor = true;
            this.buttonGradusConvert.Click += new System.EventHandler(this.buttonGradusConvert_Click);
            // 
            // groupBox55
            // 
            this.groupBox55.Controls.Add(this.tableLayoutPanel52);
            this.groupBox55.Location = new System.Drawing.Point(3, 1551);
            this.groupBox55.Name = "groupBox55";
            this.groupBox55.Size = new System.Drawing.Size(419, 320);
            this.groupBox55.TabIndex = 7;
            this.groupBox55.TabStop = false;
            this.groupBox55.Text = "Скорость (линейная)";
            // 
            // tableLayoutPanel52
            // 
            this.tableLayoutPanel52.ColumnCount = 2;
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel52.Controls.Add(this.groupBox64, 1, 1);
            this.tableLayoutPanel52.Controls.Add(this.groupBox56, 0, 0);
            this.tableLayoutPanel52.Controls.Add(this.groupBox61, 0, 1);
            this.tableLayoutPanel52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel52.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel52.Name = "tableLayoutPanel52";
            this.tableLayoutPanel52.RowCount = 2;
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel52.Size = new System.Drawing.Size(413, 294);
            this.tableLayoutPanel52.TabIndex = 0;
            // 
            // groupBox64
            // 
            this.groupBox64.Controls.Add(this.tableLayoutPanel57);
            this.groupBox64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox64.Location = new System.Drawing.Point(209, 203);
            this.groupBox64.Name = "groupBox64";
            this.groupBox64.Size = new System.Drawing.Size(201, 88);
            this.groupBox64.TabIndex = 2;
            this.groupBox64.TabStop = false;
            this.groupBox64.Text = "Преобразовывать время";
            // 
            // tableLayoutPanel57
            // 
            this.tableLayoutPanel57.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel57.ColumnCount = 2;
            this.tableLayoutPanel57.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel57.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel57.Controls.Add(this.groupBox65, 1, 0);
            this.tableLayoutPanel57.Controls.Add(this.groupBox66, 0, 0);
            this.tableLayoutPanel57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel57.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel57.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel57.Name = "tableLayoutPanel57";
            this.tableLayoutPanel57.RowCount = 1;
            this.tableLayoutPanel57.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel57.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel57.Size = new System.Drawing.Size(195, 62);
            this.tableLayoutPanel57.TabIndex = 0;
            // 
            // groupBox65
            // 
            this.groupBox65.Controls.Add(this.comboBoxSpeedTimeTo);
            this.groupBox65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox65.Location = new System.Drawing.Point(100, 3);
            this.groupBox65.Name = "groupBox65";
            this.groupBox65.Size = new System.Drawing.Size(92, 56);
            this.groupBox65.TabIndex = 1;
            this.groupBox65.TabStop = false;
            this.groupBox65.Text = "В";
            // 
            // comboBoxSpeedTimeTo
            // 
            this.comboBoxSpeedTimeTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSpeedTimeTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpeedTimeTo.DropDownWidth = 200;
            this.comboBoxSpeedTimeTo.FormattingEnabled = true;
            this.comboBoxSpeedTimeTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxSpeedTimeTo.Name = "comboBoxSpeedTimeTo";
            this.comboBoxSpeedTimeTo.Size = new System.Drawing.Size(86, 24);
            this.comboBoxSpeedTimeTo.TabIndex = 0;
            this.comboBoxSpeedTimeTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxSpeedTimeTo_MySeclectedIndexChanged);
            // 
            // groupBox66
            // 
            this.groupBox66.Controls.Add(this.comboBoxSpeedTimeFrom);
            this.groupBox66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox66.Location = new System.Drawing.Point(3, 3);
            this.groupBox66.Name = "groupBox66";
            this.groupBox66.Size = new System.Drawing.Size(91, 56);
            this.groupBox66.TabIndex = 0;
            this.groupBox66.TabStop = false;
            this.groupBox66.Text = "Из";
            // 
            // comboBoxSpeedTimeFrom
            // 
            this.comboBoxSpeedTimeFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSpeedTimeFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpeedTimeFrom.DropDownWidth = 200;
            this.comboBoxSpeedTimeFrom.FormattingEnabled = true;
            this.comboBoxSpeedTimeFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxSpeedTimeFrom.Name = "comboBoxSpeedTimeFrom";
            this.comboBoxSpeedTimeFrom.Size = new System.Drawing.Size(85, 24);
            this.comboBoxSpeedTimeFrom.TabIndex = 0;
            this.comboBoxSpeedTimeFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxSpeedTimeFrom_MySeclectedIndexChanged);
            // 
            // groupBox56
            // 
            this.tableLayoutPanel52.SetColumnSpan(this.groupBox56, 2);
            this.groupBox56.Controls.Add(this.tableLayoutPanel53);
            this.groupBox56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox56.Location = new System.Drawing.Point(3, 3);
            this.groupBox56.Name = "groupBox56";
            this.groupBox56.Size = new System.Drawing.Size(407, 194);
            this.groupBox56.TabIndex = 0;
            this.groupBox56.TabStop = false;
            this.groupBox56.Text = "Ввод/Вывод";
            // 
            // tableLayoutPanel53
            // 
            this.tableLayoutPanel53.ColumnCount = 2;
            this.tableLayoutPanel53.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel53.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel53.Controls.Add(this.groupBox57, 0, 0);
            this.tableLayoutPanel53.Controls.Add(this.buttonSpeedConvert, 1, 0);
            this.tableLayoutPanel53.Controls.Add(this.label3, 0, 3);
            this.tableLayoutPanel53.Controls.Add(this.groupBox58, 1, 1);
            this.tableLayoutPanel53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel53.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel53.Name = "tableLayoutPanel53";
            this.tableLayoutPanel53.RowCount = 4;
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel53.Size = new System.Drawing.Size(401, 168);
            this.tableLayoutPanel53.TabIndex = 0;
            // 
            // groupBox57
            // 
            this.groupBox57.Controls.Add(this.tableLayoutPanel54);
            this.groupBox57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox57.Location = new System.Drawing.Point(3, 3);
            this.groupBox57.Name = "groupBox57";
            this.tableLayoutPanel53.SetRowSpan(this.groupBox57, 2);
            this.groupBox57.Size = new System.Drawing.Size(93, 88);
            this.groupBox57.TabIndex = 0;
            this.groupBox57.TabStop = false;
            this.groupBox57.Text = "Ввод";
            // 
            // tableLayoutPanel54
            // 
            this.tableLayoutPanel54.ColumnCount = 1;
            this.tableLayoutPanel54.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel54.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel54.Controls.Add(this.radioButtonSpeedB, 0, 0);
            this.tableLayoutPanel54.Controls.Add(this.radioButtonSpeedA, 0, 1);
            this.tableLayoutPanel54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel54.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel54.Name = "tableLayoutPanel54";
            this.tableLayoutPanel54.RowCount = 2;
            this.tableLayoutPanel54.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel54.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel54.Size = new System.Drawing.Size(87, 62);
            this.tableLayoutPanel54.TabIndex = 0;
            // 
            // radioButtonSpeedB
            // 
            this.radioButtonSpeedB.AutoSize = true;
            this.radioButtonSpeedB.Checked = true;
            this.radioButtonSpeedB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonSpeedB.Location = new System.Drawing.Point(3, 3);
            this.radioButtonSpeedB.Name = "radioButtonSpeedB";
            this.radioButtonSpeedB.Size = new System.Drawing.Size(81, 25);
            this.radioButtonSpeedB.TabIndex = 0;
            this.radioButtonSpeedB.TabStop = true;
            this.radioButtonSpeedB.Text = "B";
            this.radioButtonSpeedB.UseVisualStyleBackColor = true;
            // 
            // radioButtonSpeedA
            // 
            this.radioButtonSpeedA.AutoSize = true;
            this.radioButtonSpeedA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonSpeedA.Location = new System.Drawing.Point(3, 34);
            this.radioButtonSpeedA.Name = "radioButtonSpeedA";
            this.radioButtonSpeedA.Size = new System.Drawing.Size(81, 25);
            this.radioButtonSpeedA.TabIndex = 1;
            this.radioButtonSpeedA.TabStop = true;
            this.radioButtonSpeedA.Text = "A";
            this.radioButtonSpeedA.UseVisualStyleBackColor = true;
            // 
            // buttonSpeedConvert
            // 
            this.buttonSpeedConvert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSpeedConvert.Location = new System.Drawing.Point(102, 3);
            this.buttonSpeedConvert.Name = "buttonSpeedConvert";
            this.buttonSpeedConvert.Size = new System.Drawing.Size(296, 44);
            this.buttonSpeedConvert.TabIndex = 1;
            this.buttonSpeedConvert.Text = "Вычислить";
            this.buttonSpeedConvert.UseVisualStyleBackColor = true;
            this.buttonSpeedConvert.Click += new System.EventHandler(this.buttonSpeedConvert_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.tableLayoutPanel53.SetColumnSpan(this.label3, 2);
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(395, 30);
            this.label3.TabIndex = 2;
            this.label3.Text = "Выбранный вариант - \"длина/время\"";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox58
            // 
            this.groupBox58.Controls.Add(this.tableLayoutPanel55);
            this.groupBox58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox58.Location = new System.Drawing.Point(102, 53);
            this.groupBox58.Name = "groupBox58";
            this.tableLayoutPanel53.SetRowSpan(this.groupBox58, 2);
            this.groupBox58.Size = new System.Drawing.Size(296, 82);
            this.groupBox58.TabIndex = 3;
            this.groupBox58.TabStop = false;
            this.groupBox58.Text = "Преобразовать";
            // 
            // tableLayoutPanel55
            // 
            this.tableLayoutPanel55.ColumnCount = 2;
            this.tableLayoutPanel55.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel55.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel55.Controls.Add(this.groupBox60, 1, 0);
            this.tableLayoutPanel55.Controls.Add(this.groupBox59, 0, 0);
            this.tableLayoutPanel55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel55.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel55.Name = "tableLayoutPanel55";
            this.tableLayoutPanel55.RowCount = 1;
            this.tableLayoutPanel55.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel55.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel55.Size = new System.Drawing.Size(290, 56);
            this.tableLayoutPanel55.TabIndex = 0;
            // 
            // groupBox60
            // 
            this.groupBox60.Controls.Add(this.comboBoxSpeedTo);
            this.groupBox60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox60.Location = new System.Drawing.Point(148, 3);
            this.groupBox60.Name = "groupBox60";
            this.groupBox60.Size = new System.Drawing.Size(139, 50);
            this.groupBox60.TabIndex = 1;
            this.groupBox60.TabStop = false;
            this.groupBox60.Text = "Из";
            // 
            // comboBoxSpeedTo
            // 
            this.comboBoxSpeedTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSpeedTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpeedTo.DropDownWidth = 200;
            this.comboBoxSpeedTo.FormattingEnabled = true;
            this.comboBoxSpeedTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxSpeedTo.Name = "comboBoxSpeedTo";
            this.comboBoxSpeedTo.Size = new System.Drawing.Size(133, 24);
            this.comboBoxSpeedTo.TabIndex = 0;
            this.comboBoxSpeedTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxSpeedTo_MySeclectedIndexChanged);
            // 
            // groupBox59
            // 
            this.groupBox59.Controls.Add(this.comboBoxSpeedFrom);
            this.groupBox59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox59.Location = new System.Drawing.Point(3, 3);
            this.groupBox59.Name = "groupBox59";
            this.groupBox59.Size = new System.Drawing.Size(139, 50);
            this.groupBox59.TabIndex = 0;
            this.groupBox59.TabStop = false;
            this.groupBox59.Text = "Из";
            // 
            // comboBoxSpeedFrom
            // 
            this.comboBoxSpeedFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSpeedFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpeedFrom.DropDownWidth = 200;
            this.comboBoxSpeedFrom.FormattingEnabled = true;
            this.comboBoxSpeedFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxSpeedFrom.Name = "comboBoxSpeedFrom";
            this.comboBoxSpeedFrom.Size = new System.Drawing.Size(133, 24);
            this.comboBoxSpeedFrom.TabIndex = 0;
            this.comboBoxSpeedFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxSpeedFrom_MySeclectedIndexChanged);
            // 
            // groupBox61
            // 
            this.groupBox61.Controls.Add(this.tableLayoutPanel56);
            this.groupBox61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox61.Location = new System.Drawing.Point(3, 203);
            this.groupBox61.Name = "groupBox61";
            this.groupBox61.Size = new System.Drawing.Size(200, 88);
            this.groupBox61.TabIndex = 1;
            this.groupBox61.TabStop = false;
            this.groupBox61.Text = "Преобразовывать длину";
            // 
            // tableLayoutPanel56
            // 
            this.tableLayoutPanel56.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel56.ColumnCount = 2;
            this.tableLayoutPanel56.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel56.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel56.Controls.Add(this.groupBox63, 1, 0);
            this.tableLayoutPanel56.Controls.Add(this.groupBox62, 0, 0);
            this.tableLayoutPanel56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel56.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel56.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel56.Name = "tableLayoutPanel56";
            this.tableLayoutPanel56.RowCount = 1;
            this.tableLayoutPanel56.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel56.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel56.Size = new System.Drawing.Size(194, 62);
            this.tableLayoutPanel56.TabIndex = 0;
            // 
            // groupBox63
            // 
            this.groupBox63.Controls.Add(this.comboBoxSpeedLengthTo);
            this.groupBox63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox63.Location = new System.Drawing.Point(100, 3);
            this.groupBox63.Name = "groupBox63";
            this.groupBox63.Size = new System.Drawing.Size(91, 56);
            this.groupBox63.TabIndex = 1;
            this.groupBox63.TabStop = false;
            this.groupBox63.Text = "В";
            // 
            // comboBoxSpeedLengthTo
            // 
            this.comboBoxSpeedLengthTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSpeedLengthTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpeedLengthTo.DropDownWidth = 200;
            this.comboBoxSpeedLengthTo.FormattingEnabled = true;
            this.comboBoxSpeedLengthTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxSpeedLengthTo.Name = "comboBoxSpeedLengthTo";
            this.comboBoxSpeedLengthTo.Size = new System.Drawing.Size(85, 24);
            this.comboBoxSpeedLengthTo.TabIndex = 0;
            this.comboBoxSpeedLengthTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxSpeedLengthTo_MySeclectedIndexChanged);
            // 
            // groupBox62
            // 
            this.groupBox62.Controls.Add(this.comboBoxSpeedLengthFrom);
            this.groupBox62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox62.Location = new System.Drawing.Point(3, 3);
            this.groupBox62.Name = "groupBox62";
            this.groupBox62.Size = new System.Drawing.Size(91, 56);
            this.groupBox62.TabIndex = 0;
            this.groupBox62.TabStop = false;
            this.groupBox62.Text = "Из";
            // 
            // comboBoxSpeedLengthFrom
            // 
            this.comboBoxSpeedLengthFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSpeedLengthFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpeedLengthFrom.DropDownWidth = 200;
            this.comboBoxSpeedLengthFrom.FormattingEnabled = true;
            this.comboBoxSpeedLengthFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxSpeedLengthFrom.Name = "comboBoxSpeedLengthFrom";
            this.comboBoxSpeedLengthFrom.Size = new System.Drawing.Size(85, 24);
            this.comboBoxSpeedLengthFrom.TabIndex = 0;
            this.comboBoxSpeedLengthFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxSpeedLengthFrom_MySeclectedIndexChanged);
            // 
            // groupBox67
            // 
            this.groupBox67.Controls.Add(this.tableLayoutPanel58);
            this.groupBox67.Location = new System.Drawing.Point(3, 1877);
            this.groupBox67.Name = "groupBox67";
            this.groupBox67.Size = new System.Drawing.Size(420, 180);
            this.groupBox67.TabIndex = 8;
            this.groupBox67.TabStop = false;
            this.groupBox67.Text = "Площадь";
            // 
            // tableLayoutPanel58
            // 
            this.tableLayoutPanel58.ColumnCount = 2;
            this.tableLayoutPanel58.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel58.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel58.Controls.Add(this.groupBox72, 1, 1);
            this.tableLayoutPanel58.Controls.Add(this.groupBox68, 0, 0);
            this.tableLayoutPanel58.Controls.Add(this.buttonSqrConvert, 1, 0);
            this.tableLayoutPanel58.Controls.Add(this.groupBox69, 0, 1);
            this.tableLayoutPanel58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel58.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel58.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel58.Name = "tableLayoutPanel58";
            this.tableLayoutPanel58.RowCount = 2;
            this.tableLayoutPanel58.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel58.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel58.Size = new System.Drawing.Size(414, 154);
            this.tableLayoutPanel58.TabIndex = 0;
            // 
            // groupBox72
            // 
            this.groupBox72.BackColor = System.Drawing.Color.Transparent;
            this.groupBox72.Controls.Add(this.tableLayoutPanel61);
            this.groupBox72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox72.Location = new System.Drawing.Point(210, 59);
            this.groupBox72.Name = "groupBox72";
            this.groupBox72.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox72.Size = new System.Drawing.Size(201, 92);
            this.groupBox72.TabIndex = 3;
            this.groupBox72.TabStop = false;
            this.groupBox72.Text = "Выбранный вариант (длина в квадрате)";
            // 
            // tableLayoutPanel61
            // 
            this.tableLayoutPanel61.ColumnCount = 2;
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel61.Controls.Add(this.groupBox73, 1, 0);
            this.tableLayoutPanel61.Controls.Add(this.groupBox74, 0, 0);
            this.tableLayoutPanel61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel61.Location = new System.Drawing.Point(0, 20);
            this.tableLayoutPanel61.Margin = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel61.Name = "tableLayoutPanel61";
            this.tableLayoutPanel61.RowCount = 1;
            this.tableLayoutPanel61.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel61.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel61.Size = new System.Drawing.Size(201, 72);
            this.tableLayoutPanel61.TabIndex = 0;
            // 
            // groupBox73
            // 
            this.groupBox73.Controls.Add(this.comboBoxSqrLengthTo);
            this.groupBox73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox73.Location = new System.Drawing.Point(103, 3);
            this.groupBox73.Name = "groupBox73";
            this.groupBox73.Size = new System.Drawing.Size(95, 66);
            this.groupBox73.TabIndex = 1;
            this.groupBox73.TabStop = false;
            this.groupBox73.Text = "В";
            // 
            // comboBoxSqrLengthTo
            // 
            this.comboBoxSqrLengthTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSqrLengthTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSqrLengthTo.DropDownWidth = 200;
            this.comboBoxSqrLengthTo.FormattingEnabled = true;
            this.comboBoxSqrLengthTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxSqrLengthTo.Name = "comboBoxSqrLengthTo";
            this.comboBoxSqrLengthTo.Size = new System.Drawing.Size(89, 24);
            this.comboBoxSqrLengthTo.TabIndex = 1;
            this.comboBoxSqrLengthTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxSqrLengthTo_MySeclectedIndexChanged);
            // 
            // groupBox74
            // 
            this.groupBox74.Controls.Add(this.comboBoxSqrLengthFrom);
            this.groupBox74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox74.Location = new System.Drawing.Point(3, 3);
            this.groupBox74.Name = "groupBox74";
            this.groupBox74.Size = new System.Drawing.Size(94, 66);
            this.groupBox74.TabIndex = 0;
            this.groupBox74.TabStop = false;
            this.groupBox74.Text = "Из";
            // 
            // comboBoxSqrLengthFrom
            // 
            this.comboBoxSqrLengthFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSqrLengthFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSqrLengthFrom.DropDownWidth = 200;
            this.comboBoxSqrLengthFrom.FormattingEnabled = true;
            this.comboBoxSqrLengthFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxSqrLengthFrom.Name = "comboBoxSqrLengthFrom";
            this.comboBoxSqrLengthFrom.Size = new System.Drawing.Size(88, 24);
            this.comboBoxSqrLengthFrom.TabIndex = 0;
            this.comboBoxSqrLengthFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxSqrLengthFrom_MySeclectedIndexChanged);
            // 
            // groupBox68
            // 
            this.groupBox68.Controls.Add(this.tableLayoutPanel59);
            this.groupBox68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox68.Location = new System.Drawing.Point(3, 3);
            this.groupBox68.Name = "groupBox68";
            this.groupBox68.Size = new System.Drawing.Size(201, 50);
            this.groupBox68.TabIndex = 0;
            this.groupBox68.TabStop = false;
            this.groupBox68.Text = "Ввод";
            // 
            // tableLayoutPanel59
            // 
            this.tableLayoutPanel59.ColumnCount = 2;
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel59.Controls.Add(this.radioButtonSqrA, 1, 0);
            this.tableLayoutPanel59.Controls.Add(this.radioButtonSqrB, 0, 0);
            this.tableLayoutPanel59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel59.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel59.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel59.Name = "tableLayoutPanel59";
            this.tableLayoutPanel59.RowCount = 1;
            this.tableLayoutPanel59.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel59.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanel59.Size = new System.Drawing.Size(195, 24);
            this.tableLayoutPanel59.TabIndex = 0;
            // 
            // radioButtonSqrA
            // 
            this.radioButtonSqrA.AutoSize = true;
            this.radioButtonSqrA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonSqrA.Location = new System.Drawing.Point(100, 3);
            this.radioButtonSqrA.Name = "radioButtonSqrA";
            this.radioButtonSqrA.Size = new System.Drawing.Size(92, 18);
            this.radioButtonSqrA.TabIndex = 1;
            this.radioButtonSqrA.Text = "A";
            this.radioButtonSqrA.UseVisualStyleBackColor = true;
            // 
            // radioButtonSqrB
            // 
            this.radioButtonSqrB.AutoSize = true;
            this.radioButtonSqrB.Checked = true;
            this.radioButtonSqrB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonSqrB.Location = new System.Drawing.Point(3, 3);
            this.radioButtonSqrB.Name = "radioButtonSqrB";
            this.radioButtonSqrB.Size = new System.Drawing.Size(91, 18);
            this.radioButtonSqrB.TabIndex = 0;
            this.radioButtonSqrB.TabStop = true;
            this.radioButtonSqrB.Text = "B";
            this.radioButtonSqrB.UseVisualStyleBackColor = true;
            // 
            // buttonSqrConvert
            // 
            this.buttonSqrConvert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSqrConvert.Location = new System.Drawing.Point(217, 10);
            this.buttonSqrConvert.Margin = new System.Windows.Forms.Padding(10);
            this.buttonSqrConvert.Name = "buttonSqrConvert";
            this.buttonSqrConvert.Size = new System.Drawing.Size(187, 36);
            this.buttonSqrConvert.TabIndex = 1;
            this.buttonSqrConvert.Text = "Вычислить";
            this.buttonSqrConvert.UseVisualStyleBackColor = true;
            this.buttonSqrConvert.Click += new System.EventHandler(this.buttonSqrConvert_Click);
            // 
            // groupBox69
            // 
            this.groupBox69.BackColor = System.Drawing.Color.Transparent;
            this.groupBox69.Controls.Add(this.tableLayoutPanel60);
            this.groupBox69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox69.Location = new System.Drawing.Point(3, 59);
            this.groupBox69.Name = "groupBox69";
            this.groupBox69.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox69.Size = new System.Drawing.Size(201, 92);
            this.groupBox69.TabIndex = 2;
            this.groupBox69.TabStop = false;
            this.groupBox69.Text = "Преобразовывать";
            // 
            // tableLayoutPanel60
            // 
            this.tableLayoutPanel60.ColumnCount = 2;
            this.tableLayoutPanel60.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel60.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel60.Controls.Add(this.groupBox71, 1, 0);
            this.tableLayoutPanel60.Controls.Add(this.groupBox70, 0, 0);
            this.tableLayoutPanel60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel60.Location = new System.Drawing.Point(0, 20);
            this.tableLayoutPanel60.Margin = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel60.Name = "tableLayoutPanel60";
            this.tableLayoutPanel60.RowCount = 1;
            this.tableLayoutPanel60.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel60.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel60.Size = new System.Drawing.Size(201, 72);
            this.tableLayoutPanel60.TabIndex = 0;
            // 
            // groupBox71
            // 
            this.groupBox71.Controls.Add(this.comboBoxSqrTo);
            this.groupBox71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox71.Location = new System.Drawing.Point(103, 3);
            this.groupBox71.Name = "groupBox71";
            this.groupBox71.Size = new System.Drawing.Size(95, 66);
            this.groupBox71.TabIndex = 1;
            this.groupBox71.TabStop = false;
            this.groupBox71.Text = "В";
            // 
            // comboBoxSqrTo
            // 
            this.comboBoxSqrTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSqrTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSqrTo.DropDownWidth = 200;
            this.comboBoxSqrTo.FormattingEnabled = true;
            this.comboBoxSqrTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxSqrTo.Name = "comboBoxSqrTo";
            this.comboBoxSqrTo.Size = new System.Drawing.Size(89, 24);
            this.comboBoxSqrTo.TabIndex = 1;
            this.comboBoxSqrTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxSqrTo_MySeclectedIndexChanged);
            // 
            // groupBox70
            // 
            this.groupBox70.Controls.Add(this.comboBoxSqrFrom);
            this.groupBox70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox70.Location = new System.Drawing.Point(3, 3);
            this.groupBox70.Name = "groupBox70";
            this.groupBox70.Size = new System.Drawing.Size(94, 66);
            this.groupBox70.TabIndex = 0;
            this.groupBox70.TabStop = false;
            this.groupBox70.Text = "Из";
            // 
            // comboBoxSqrFrom
            // 
            this.comboBoxSqrFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSqrFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSqrFrom.DropDownWidth = 200;
            this.comboBoxSqrFrom.FormattingEnabled = true;
            this.comboBoxSqrFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxSqrFrom.Name = "comboBoxSqrFrom";
            this.comboBoxSqrFrom.Size = new System.Drawing.Size(88, 24);
            this.comboBoxSqrFrom.TabIndex = 0;
            this.comboBoxSqrFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxSqrFrom_MySeclectedIndexChanged);
            // 
            // groupBox75
            // 
            this.groupBox75.Controls.Add(this.tableLayoutPanel62);
            this.groupBox75.Location = new System.Drawing.Point(3, 2063);
            this.groupBox75.Name = "groupBox75";
            this.groupBox75.Size = new System.Drawing.Size(420, 180);
            this.groupBox75.TabIndex = 9;
            this.groupBox75.TabStop = false;
            this.groupBox75.Text = "Объём";
            // 
            // tableLayoutPanel62
            // 
            this.tableLayoutPanel62.ColumnCount = 2;
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel62.Controls.Add(this.groupBox76, 1, 1);
            this.tableLayoutPanel62.Controls.Add(this.groupBox79, 0, 0);
            this.tableLayoutPanel62.Controls.Add(this.buttonKubConvert, 1, 0);
            this.tableLayoutPanel62.Controls.Add(this.groupBox80, 0, 1);
            this.tableLayoutPanel62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel62.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel62.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel62.Name = "tableLayoutPanel62";
            this.tableLayoutPanel62.RowCount = 2;
            this.tableLayoutPanel62.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel62.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel62.Size = new System.Drawing.Size(414, 154);
            this.tableLayoutPanel62.TabIndex = 0;
            // 
            // groupBox76
            // 
            this.groupBox76.BackColor = System.Drawing.Color.Transparent;
            this.groupBox76.Controls.Add(this.tableLayoutPanel63);
            this.groupBox76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox76.Location = new System.Drawing.Point(210, 59);
            this.groupBox76.Name = "groupBox76";
            this.groupBox76.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox76.Size = new System.Drawing.Size(201, 92);
            this.groupBox76.TabIndex = 3;
            this.groupBox76.TabStop = false;
            this.groupBox76.Text = "Выбранный вариант (длина в кубе)";
            // 
            // tableLayoutPanel63
            // 
            this.tableLayoutPanel63.ColumnCount = 2;
            this.tableLayoutPanel63.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel63.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel63.Controls.Add(this.groupBox77, 1, 0);
            this.tableLayoutPanel63.Controls.Add(this.groupBox78, 0, 0);
            this.tableLayoutPanel63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel63.Location = new System.Drawing.Point(0, 20);
            this.tableLayoutPanel63.Margin = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel63.Name = "tableLayoutPanel63";
            this.tableLayoutPanel63.RowCount = 1;
            this.tableLayoutPanel63.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel63.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel63.Size = new System.Drawing.Size(201, 72);
            this.tableLayoutPanel63.TabIndex = 0;
            // 
            // groupBox77
            // 
            this.groupBox77.Controls.Add(this.comboBoxKubLengthTo);
            this.groupBox77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox77.Location = new System.Drawing.Point(103, 3);
            this.groupBox77.Name = "groupBox77";
            this.groupBox77.Size = new System.Drawing.Size(95, 66);
            this.groupBox77.TabIndex = 1;
            this.groupBox77.TabStop = false;
            this.groupBox77.Text = "В";
            // 
            // comboBoxKubLengthTo
            // 
            this.comboBoxKubLengthTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxKubLengthTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxKubLengthTo.DropDownWidth = 200;
            this.comboBoxKubLengthTo.FormattingEnabled = true;
            this.comboBoxKubLengthTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxKubLengthTo.Name = "comboBoxKubLengthTo";
            this.comboBoxKubLengthTo.Size = new System.Drawing.Size(89, 24);
            this.comboBoxKubLengthTo.TabIndex = 1;
            this.comboBoxKubLengthTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxKubLengthTo_MySeclectedIndexChanged);
            // 
            // groupBox78
            // 
            this.groupBox78.Controls.Add(this.comboBoxKubLengthFrom);
            this.groupBox78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox78.Location = new System.Drawing.Point(3, 3);
            this.groupBox78.Name = "groupBox78";
            this.groupBox78.Size = new System.Drawing.Size(94, 66);
            this.groupBox78.TabIndex = 0;
            this.groupBox78.TabStop = false;
            this.groupBox78.Text = "Из";
            // 
            // comboBoxKubLengthFrom
            // 
            this.comboBoxKubLengthFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxKubLengthFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxKubLengthFrom.DropDownWidth = 200;
            this.comboBoxKubLengthFrom.FormattingEnabled = true;
            this.comboBoxKubLengthFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxKubLengthFrom.Name = "comboBoxKubLengthFrom";
            this.comboBoxKubLengthFrom.Size = new System.Drawing.Size(88, 24);
            this.comboBoxKubLengthFrom.TabIndex = 0;
            this.comboBoxKubLengthFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxKubLengthFrom_MySeclectedIndexChanged);
            // 
            // groupBox79
            // 
            this.groupBox79.Controls.Add(this.tableLayoutPanel64);
            this.groupBox79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox79.Location = new System.Drawing.Point(3, 3);
            this.groupBox79.Name = "groupBox79";
            this.groupBox79.Size = new System.Drawing.Size(201, 50);
            this.groupBox79.TabIndex = 0;
            this.groupBox79.TabStop = false;
            this.groupBox79.Text = "Ввод";
            // 
            // tableLayoutPanel64
            // 
            this.tableLayoutPanel64.ColumnCount = 2;
            this.tableLayoutPanel64.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel64.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel64.Controls.Add(this.radioButtonKubA, 1, 0);
            this.tableLayoutPanel64.Controls.Add(this.radioButtonKubB, 0, 0);
            this.tableLayoutPanel64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel64.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel64.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel64.Name = "tableLayoutPanel64";
            this.tableLayoutPanel64.RowCount = 1;
            this.tableLayoutPanel64.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel64.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanel64.Size = new System.Drawing.Size(195, 24);
            this.tableLayoutPanel64.TabIndex = 0;
            // 
            // radioButtonKubA
            // 
            this.radioButtonKubA.AutoSize = true;
            this.radioButtonKubA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonKubA.Location = new System.Drawing.Point(100, 3);
            this.radioButtonKubA.Name = "radioButtonKubA";
            this.radioButtonKubA.Size = new System.Drawing.Size(92, 18);
            this.radioButtonKubA.TabIndex = 1;
            this.radioButtonKubA.Text = "A";
            this.radioButtonKubA.UseVisualStyleBackColor = true;
            // 
            // radioButtonKubB
            // 
            this.radioButtonKubB.AutoSize = true;
            this.radioButtonKubB.Checked = true;
            this.radioButtonKubB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonKubB.Location = new System.Drawing.Point(3, 3);
            this.radioButtonKubB.Name = "radioButtonKubB";
            this.radioButtonKubB.Size = new System.Drawing.Size(91, 18);
            this.radioButtonKubB.TabIndex = 0;
            this.radioButtonKubB.TabStop = true;
            this.radioButtonKubB.Text = "B";
            this.radioButtonKubB.UseVisualStyleBackColor = true;
            // 
            // buttonKubConvert
            // 
            this.buttonKubConvert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonKubConvert.Location = new System.Drawing.Point(217, 10);
            this.buttonKubConvert.Margin = new System.Windows.Forms.Padding(10);
            this.buttonKubConvert.Name = "buttonKubConvert";
            this.buttonKubConvert.Size = new System.Drawing.Size(187, 36);
            this.buttonKubConvert.TabIndex = 1;
            this.buttonKubConvert.Text = "Вычислить";
            this.buttonKubConvert.UseVisualStyleBackColor = true;
            this.buttonKubConvert.Click += new System.EventHandler(this.buttonKubConvert_Click);
            // 
            // groupBox80
            // 
            this.groupBox80.BackColor = System.Drawing.Color.Transparent;
            this.groupBox80.Controls.Add(this.tableLayoutPanel65);
            this.groupBox80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox80.Location = new System.Drawing.Point(3, 59);
            this.groupBox80.Name = "groupBox80";
            this.groupBox80.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox80.Size = new System.Drawing.Size(201, 92);
            this.groupBox80.TabIndex = 2;
            this.groupBox80.TabStop = false;
            this.groupBox80.Text = "Преобразовывать";
            // 
            // tableLayoutPanel65
            // 
            this.tableLayoutPanel65.ColumnCount = 2;
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel65.Controls.Add(this.groupBox81, 1, 0);
            this.tableLayoutPanel65.Controls.Add(this.groupBox82, 0, 0);
            this.tableLayoutPanel65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel65.Location = new System.Drawing.Point(0, 20);
            this.tableLayoutPanel65.Margin = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel65.Name = "tableLayoutPanel65";
            this.tableLayoutPanel65.RowCount = 1;
            this.tableLayoutPanel65.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel65.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel65.Size = new System.Drawing.Size(201, 72);
            this.tableLayoutPanel65.TabIndex = 0;
            // 
            // groupBox81
            // 
            this.groupBox81.Controls.Add(this.comboBoxKubTo);
            this.groupBox81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox81.Location = new System.Drawing.Point(103, 3);
            this.groupBox81.Name = "groupBox81";
            this.groupBox81.Size = new System.Drawing.Size(95, 66);
            this.groupBox81.TabIndex = 1;
            this.groupBox81.TabStop = false;
            this.groupBox81.Text = "В";
            // 
            // comboBoxKubTo
            // 
            this.comboBoxKubTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxKubTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxKubTo.DropDownWidth = 200;
            this.comboBoxKubTo.FormattingEnabled = true;
            this.comboBoxKubTo.Location = new System.Drawing.Point(3, 23);
            this.comboBoxKubTo.Name = "comboBoxKubTo";
            this.comboBoxKubTo.Size = new System.Drawing.Size(89, 24);
            this.comboBoxKubTo.TabIndex = 1;
            this.comboBoxKubTo.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxKubTo_MySeclectedIndexChanged);
            // 
            // groupBox82
            // 
            this.groupBox82.Controls.Add(this.comboBoxKubFrom);
            this.groupBox82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox82.Location = new System.Drawing.Point(3, 3);
            this.groupBox82.Name = "groupBox82";
            this.groupBox82.Size = new System.Drawing.Size(94, 66);
            this.groupBox82.TabIndex = 0;
            this.groupBox82.TabStop = false;
            this.groupBox82.Text = "Из";
            // 
            // comboBoxKubFrom
            // 
            this.comboBoxKubFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxKubFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxKubFrom.DropDownWidth = 200;
            this.comboBoxKubFrom.FormattingEnabled = true;
            this.comboBoxKubFrom.Location = new System.Drawing.Point(3, 23);
            this.comboBoxKubFrom.Name = "comboBoxKubFrom";
            this.comboBoxKubFrom.Size = new System.Drawing.Size(88, 24);
            this.comboBoxKubFrom.TabIndex = 0;
            this.comboBoxKubFrom.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxKubFrom_MySeclectedIndexChanged);
            // 
            // groupBox85
            // 
            this.groupBox85.Location = new System.Drawing.Point(3, 2249);
            this.groupBox85.Name = "groupBox85";
            this.groupBox85.Size = new System.Drawing.Size(200, 100);
            this.groupBox85.TabIndex = 10;
            this.groupBox85.TabStop = false;
            this.groupBox85.Text = "Конвертер углов";
            // 
            // flowLayoutPanelInputB
            // 
            this.flowLayoutPanelInputB.AutoScroll = true;
            this.flowLayoutPanelInputB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowLayoutPanelInputB.Controls.Add(this.groupBox1);
            this.flowLayoutPanelInputB.Controls.Add(this.groupBox86);
            this.flowLayoutPanelInputB.Controls.Add(this.groupBox87);
            this.flowLayoutPanelInputB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelInputB.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanelInputB.Location = new System.Drawing.Point(3, 113);
            this.flowLayoutPanelInputB.Name = "flowLayoutPanelInputB";
            this.flowLayoutPanelInputB.Size = new System.Drawing.Size(447, 138);
            this.flowLayoutPanelInputB.TabIndex = 8;
            this.flowLayoutPanelInputB.WrapContents = false;
            this.flowLayoutPanelInputB.SizeChanged += new System.EventHandler(this.flowLayoutPanelInputB_SizeChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel5);
            this.groupBox1.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(412, 370);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ввести B";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 7;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28531F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28531F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28531F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28531F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28531F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28531F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28816F));
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel75, 2, 5);
            this.tableLayoutPanel5.Controls.Add(this.buttonMulX2, 4, 7);
            this.tableLayoutPanel5.Controls.Add(this.buttonSet, 6, 9);
            this.tableLayoutPanel5.Controls.Add(this.buttonDecB, 6, 1);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel68, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel67, 3, 3);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel66, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.buttonIncB, 6, 0);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel70, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView40, 5, 6);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel69, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView10, 4, 1);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView16, 4, 2);
            this.tableLayoutPanel5.Controls.Add(this.menuStrip1, 0, 9);
            this.tableLayoutPanel5.Controls.Add(this.buttonMines, 2, 8);
            this.tableLayoutPanel5.Controls.Add(this.buttonAbs, 0, 8);
            this.tableLayoutPanel5.Controls.Add(this.buttonRet, 1, 8);
            this.tableLayoutPanel5.Controls.Add(this.buttonDivX2, 3, 7);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView18, 6, 2);
            this.tableLayoutPanel5.Controls.Add(this.buttonBA, 6, 8);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView33, 5, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonMinesAbs, 0, 7);
            this.tableLayoutPanel5.Controls.Add(this.buttonMinesRet, 1, 7);
            this.tableLayoutPanel5.Controls.Add(this.buttonMinesX, 2, 7);
            this.tableLayoutPanel5.Controls.Add(this.buttonAbsRet, 3, 6);
            this.tableLayoutPanel5.Controls.Add(this.buttonMinesAbsRet, 4, 6);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView35, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView36, 1, 6);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView37, 2, 6);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView38, 6, 6);
            this.tableLayoutPanel5.Controls.Add(this.buttonPlusBasketes, 4, 9);
            this.tableLayoutPanel5.Controls.Add(this.buttonMinesBasketes, 5, 9);
            this.tableLayoutPanel5.Controls.Add(this.buttonChangeBaskets, 4, 8);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView21, 4, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView34, 5, 1);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView17, 5, 2);
            this.tableLayoutPanel5.Controls.Add(this.buttonChangeAbsBaskets, 4, 7);
            this.tableLayoutPanel5.Controls.Add(this.buttonPersent, 3, 8);
            this.tableLayoutPanel5.Controls.Add(this.buttonPlusAbs, 5, 8);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView39, 6, 7);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView41, 4, 4);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView42, 6, 4);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView43, 2, 4);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView44, 3, 4);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView45, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView46, 5, 4);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView50, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView51, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.buttonClickView52, 0, 4);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 24);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 10;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.889891F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.889891F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.891556F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.889891F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.888307F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.98794F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.889891F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.892828F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.889579F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.890229F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(406, 343);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // tableLayoutPanel75
            // 
            this.tableLayoutPanel75.ColumnCount = 6;
            this.tableLayoutPanel5.SetColumnSpan(this.tableLayoutPanel75, 5);
            this.tableLayoutPanel75.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel75.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel75.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel75.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel75.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel75.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel75.Controls.Add(this.buttonClickView49, 1, 0);
            this.tableLayoutPanel75.Controls.Add(this.buttonClickView47, 3, 0);
            this.tableLayoutPanel75.Controls.Add(this.buttonClickView48, 4, 0);
            this.tableLayoutPanel75.Controls.Add(this.buttonClickView53, 0, 0);
            this.tableLayoutPanel75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel75.Location = new System.Drawing.Point(117, 168);
            this.tableLayoutPanel75.Name = "tableLayoutPanel75";
            this.tableLayoutPanel75.RowCount = 1;
            this.tableLayoutPanel75.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel75.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel75.Size = new System.Drawing.Size(286, 31);
            this.tableLayoutPanel75.TabIndex = 0;
            // 
            // buttonClickView49
            // 
            this.tableLayoutPanel75.SetColumnSpan(this.buttonClickView49, 2);
            this.buttonClickView49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView49.Location = new System.Drawing.Point(50, 3);
            this.buttonClickView49.Name = "buttonClickView49";
            this.buttonClickView49.Size = new System.Drawing.Size(88, 25);
            this.buttonClickView49.TabIndex = 0;
            this.buttonClickView49.Text = "buffer";
            this.buttonClickView49.UseVisualStyleBackColor = true;
            this.buttonClickView49.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView47
            // 
            this.buttonClickView47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView47.Location = new System.Drawing.Point(144, 3);
            this.buttonClickView47.Name = "buttonClickView47";
            this.buttonClickView47.Size = new System.Drawing.Size(41, 25);
            this.buttonClickView47.TabIndex = 0;
            this.buttonClickView47.Text = "A";
            this.buttonClickView47.UseVisualStyleBackColor = true;
            this.buttonClickView47.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView48
            // 
            this.tableLayoutPanel75.SetColumnSpan(this.buttonClickView48, 2);
            this.buttonClickView48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView48.Location = new System.Drawing.Point(191, 3);
            this.buttonClickView48.Name = "buttonClickView48";
            this.buttonClickView48.Size = new System.Drawing.Size(92, 25);
            this.buttonClickView48.TabIndex = 0;
            this.buttonClickView48.Text = "bufer";
            this.buttonClickView48.UseVisualStyleBackColor = true;
            this.buttonClickView48.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView53
            // 
            this.buttonClickView53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView53.Location = new System.Drawing.Point(3, 3);
            this.buttonClickView53.Name = "buttonClickView53";
            this.buttonClickView53.Size = new System.Drawing.Size(41, 25);
            this.buttonClickView53.TabIndex = 0;
            this.buttonClickView53.Text = ";";
            this.buttonClickView53.UseVisualStyleBackColor = true;
            this.buttonClickView53.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonMulX2
            // 
            this.buttonMulX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMulX2.Location = new System.Drawing.Point(288, 238);
            this.buttonMulX2.Name = "buttonMulX2";
            this.buttonMulX2.Size = new System.Drawing.Size(51, 27);
            this.buttonMulX2.TabIndex = 11;
            this.buttonMulX2.Text = "x*2";
            this.buttonMulX2.UseVisualStyleBackColor = true;
            this.buttonMulX2.Click += new System.EventHandler(this.buttonMulX2_Click);
            // 
            // buttonSet
            // 
            this.buttonSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSet.Location = new System.Drawing.Point(345, 304);
            this.buttonSet.Name = "buttonSet";
            this.buttonSet.Size = new System.Drawing.Size(58, 36);
            this.buttonSet.TabIndex = 5;
            this.buttonSet.Text = "=";
            this.buttonSet.UseVisualStyleBackColor = true;
            this.buttonSet.Click += new System.EventHandler(this.buttonSet_Click);
            // 
            // buttonDecB
            // 
            this.buttonDecB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDecB.Location = new System.Drawing.Point(345, 36);
            this.buttonDecB.Name = "buttonDecB";
            this.buttonDecB.Size = new System.Drawing.Size(58, 27);
            this.buttonDecB.TabIndex = 5;
            this.buttonDecB.Text = "B--";
            this.buttonDecB.UseVisualStyleBackColor = true;
            this.buttonDecB.Click += new System.EventHandler(this.buttonDecB_Click);
            // 
            // tableLayoutPanel68
            // 
            this.tableLayoutPanel68.ColumnCount = 5;
            this.tableLayoutPanel5.SetColumnSpan(this.tableLayoutPanel68, 4);
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel68.Controls.Add(this.buttonClickView12, 0, 0);
            this.tableLayoutPanel68.Controls.Add(this.buttonClickView13, 1, 0);
            this.tableLayoutPanel68.Controls.Add(this.buttonClickView14, 2, 0);
            this.tableLayoutPanel68.Controls.Add(this.buttonClickView15, 3, 0);
            this.tableLayoutPanel68.Controls.Add(this.buttonClickView27, 4, 0);
            this.tableLayoutPanel68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel68.Location = new System.Drawing.Point(3, 69);
            this.tableLayoutPanel68.Name = "tableLayoutPanel68";
            this.tableLayoutPanel68.RowCount = 1;
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel68.Size = new System.Drawing.Size(222, 27);
            this.tableLayoutPanel68.TabIndex = 8;
            // 
            // buttonClickView12
            // 
            this.buttonClickView12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView12.Location = new System.Drawing.Point(0, 0);
            this.buttonClickView12.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView12.Name = "buttonClickView12";
            this.buttonClickView12.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView12.TabIndex = 0;
            this.buttonClickView12.Text = "+";
            this.buttonClickView12.UseVisualStyleBackColor = true;
            this.buttonClickView12.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView13
            // 
            this.buttonClickView13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView13.Location = new System.Drawing.Point(44, 0);
            this.buttonClickView13.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView13.Name = "buttonClickView13";
            this.buttonClickView13.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView13.TabIndex = 0;
            this.buttonClickView13.Text = "-";
            this.buttonClickView13.UseVisualStyleBackColor = true;
            this.buttonClickView13.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView14
            // 
            this.buttonClickView14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView14.Location = new System.Drawing.Point(88, 0);
            this.buttonClickView14.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView14.Name = "buttonClickView14";
            this.buttonClickView14.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView14.TabIndex = 0;
            this.buttonClickView14.Text = "*";
            this.buttonClickView14.UseVisualStyleBackColor = true;
            this.buttonClickView14.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView15
            // 
            this.buttonClickView15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView15.Location = new System.Drawing.Point(132, 0);
            this.buttonClickView15.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView15.Name = "buttonClickView15";
            this.buttonClickView15.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView15.TabIndex = 0;
            this.buttonClickView15.Text = "/";
            this.buttonClickView15.UseVisualStyleBackColor = true;
            this.buttonClickView15.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView27
            // 
            this.buttonClickView27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView27.Location = new System.Drawing.Point(176, 0);
            this.buttonClickView27.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView27.Name = "buttonClickView27";
            this.buttonClickView27.Size = new System.Drawing.Size(46, 27);
            this.buttonClickView27.TabIndex = 0;
            this.buttonClickView27.Text = "÷";
            this.buttonClickView27.UseVisualStyleBackColor = true;
            this.buttonClickView27.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // tableLayoutPanel67
            // 
            this.tableLayoutPanel67.ColumnCount = 5;
            this.tableLayoutPanel5.SetColumnSpan(this.tableLayoutPanel67, 4);
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel67.Controls.Add(this.buttonClickView25, 0, 0);
            this.tableLayoutPanel67.Controls.Add(this.buttonClickView24, 1, 0);
            this.tableLayoutPanel67.Controls.Add(this.buttonClickView26, 2, 0);
            this.tableLayoutPanel67.Controls.Add(this.buttonClickView11, 3, 0);
            this.tableLayoutPanel67.Controls.Add(this.buttonClickView28, 4, 0);
            this.tableLayoutPanel67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel67.Location = new System.Drawing.Point(174, 102);
            this.tableLayoutPanel67.Name = "tableLayoutPanel67";
            this.tableLayoutPanel67.RowCount = 1;
            this.tableLayoutPanel67.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel67.Size = new System.Drawing.Size(229, 27);
            this.tableLayoutPanel67.TabIndex = 8;
            // 
            // buttonClickView25
            // 
            this.buttonClickView25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView25.Location = new System.Drawing.Point(0, 0);
            this.buttonClickView25.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView25.Name = "buttonClickView25";
            this.buttonClickView25.Size = new System.Drawing.Size(45, 27);
            this.buttonClickView25.TabIndex = 0;
            this.buttonClickView25.Text = "π";
            this.buttonClickView25.UseVisualStyleBackColor = true;
            this.buttonClickView25.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView24
            // 
            this.buttonClickView24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView24.Location = new System.Drawing.Point(45, 0);
            this.buttonClickView24.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView24.Name = "buttonClickView24";
            this.buttonClickView24.Size = new System.Drawing.Size(45, 27);
            this.buttonClickView24.TabIndex = 0;
            this.buttonClickView24.Text = "^";
            this.buttonClickView24.UseVisualStyleBackColor = true;
            this.buttonClickView24.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView26
            // 
            this.buttonClickView26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView26.Location = new System.Drawing.Point(90, 0);
            this.buttonClickView26.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView26.Name = "buttonClickView26";
            this.buttonClickView26.Size = new System.Drawing.Size(45, 27);
            this.buttonClickView26.TabIndex = 0;
            this.buttonClickView26.Text = "×";
            this.buttonClickView26.UseVisualStyleBackColor = true;
            this.buttonClickView26.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView11
            // 
            this.buttonClickView11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView11.Location = new System.Drawing.Point(135, 0);
            this.buttonClickView11.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView11.Name = "buttonClickView11";
            this.buttonClickView11.Size = new System.Drawing.Size(45, 27);
            this.buttonClickView11.TabIndex = 0;
            this.buttonClickView11.Text = ",";
            this.buttonClickView11.UseVisualStyleBackColor = true;
            this.buttonClickView11.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView28
            // 
            this.buttonClickView28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView28.Location = new System.Drawing.Point(180, 0);
            this.buttonClickView28.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView28.Name = "buttonClickView28";
            this.buttonClickView28.Size = new System.Drawing.Size(49, 27);
            this.buttonClickView28.TabIndex = 0;
            this.buttonClickView28.Text = "√";
            this.buttonClickView28.UseVisualStyleBackColor = true;
            this.buttonClickView28.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // tableLayoutPanel66
            // 
            this.tableLayoutPanel66.ColumnCount = 4;
            this.tableLayoutPanel5.SetColumnSpan(this.tableLayoutPanel66, 3);
            this.tableLayoutPanel66.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel66.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel66.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel66.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel66.Controls.Add(this.buttonClickView19, 0, 0);
            this.tableLayoutPanel66.Controls.Add(this.buttonClickView20, 1, 0);
            this.tableLayoutPanel66.Controls.Add(this.buttonClickView22, 2, 0);
            this.tableLayoutPanel66.Controls.Add(this.buttonClickView23, 3, 0);
            this.tableLayoutPanel66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel66.Location = new System.Drawing.Point(3, 102);
            this.tableLayoutPanel66.Name = "tableLayoutPanel66";
            this.tableLayoutPanel66.RowCount = 1;
            this.tableLayoutPanel66.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel66.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel66.Size = new System.Drawing.Size(165, 27);
            this.tableLayoutPanel66.TabIndex = 8;
            // 
            // buttonClickView19
            // 
            this.buttonClickView19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView19.Location = new System.Drawing.Point(0, 0);
            this.buttonClickView19.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView19.Name = "buttonClickView19";
            this.buttonClickView19.Size = new System.Drawing.Size(41, 27);
            this.buttonClickView19.TabIndex = 0;
            this.buttonClickView19.Text = "(";
            this.buttonClickView19.UseVisualStyleBackColor = true;
            this.buttonClickView19.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView20
            // 
            this.buttonClickView20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView20.Location = new System.Drawing.Point(41, 0);
            this.buttonClickView20.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView20.Name = "buttonClickView20";
            this.buttonClickView20.Size = new System.Drawing.Size(41, 27);
            this.buttonClickView20.TabIndex = 0;
            this.buttonClickView20.Text = ")";
            this.buttonClickView20.UseVisualStyleBackColor = true;
            this.buttonClickView20.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView22
            // 
            this.buttonClickView22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView22.Location = new System.Drawing.Point(82, 0);
            this.buttonClickView22.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView22.Name = "buttonClickView22";
            this.buttonClickView22.Size = new System.Drawing.Size(41, 27);
            this.buttonClickView22.TabIndex = 0;
            this.buttonClickView22.Text = "|";
            this.buttonClickView22.UseVisualStyleBackColor = true;
            this.buttonClickView22.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView23
            // 
            this.buttonClickView23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView23.Location = new System.Drawing.Point(123, 0);
            this.buttonClickView23.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView23.Name = "buttonClickView23";
            this.buttonClickView23.Size = new System.Drawing.Size(42, 27);
            this.buttonClickView23.TabIndex = 0;
            this.buttonClickView23.Text = "%";
            this.buttonClickView23.UseVisualStyleBackColor = true;
            this.buttonClickView23.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonIncB
            // 
            this.buttonIncB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonIncB.Location = new System.Drawing.Point(345, 3);
            this.buttonIncB.Name = "buttonIncB";
            this.buttonIncB.Size = new System.Drawing.Size(58, 27);
            this.buttonIncB.TabIndex = 4;
            this.buttonIncB.Text = "B++";
            this.buttonIncB.UseVisualStyleBackColor = true;
            this.buttonIncB.Click += new System.EventHandler(this.buttonIncB_Click);
            // 
            // tableLayoutPanel70
            // 
            this.tableLayoutPanel70.ColumnCount = 5;
            this.tableLayoutPanel5.SetColumnSpan(this.tableLayoutPanel70, 4);
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel70.Controls.Add(this.buttonClickView5, 0, 0);
            this.tableLayoutPanel70.Controls.Add(this.buttonClickView6, 1, 0);
            this.tableLayoutPanel70.Controls.Add(this.buttonClickView7, 2, 0);
            this.tableLayoutPanel70.Controls.Add(this.buttonClickView8, 3, 0);
            this.tableLayoutPanel70.Controls.Add(this.buttonClickView9, 4, 0);
            this.tableLayoutPanel70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel70.Location = new System.Drawing.Point(3, 36);
            this.tableLayoutPanel70.Name = "tableLayoutPanel70";
            this.tableLayoutPanel70.RowCount = 1;
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel70.Size = new System.Drawing.Size(222, 27);
            this.tableLayoutPanel70.TabIndex = 8;
            // 
            // buttonClickView5
            // 
            this.buttonClickView5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView5.Location = new System.Drawing.Point(0, 0);
            this.buttonClickView5.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView5.Name = "buttonClickView5";
            this.buttonClickView5.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView5.TabIndex = 0;
            this.buttonClickView5.Text = "5";
            this.buttonClickView5.UseVisualStyleBackColor = true;
            this.buttonClickView5.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView6
            // 
            this.buttonClickView6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView6.Location = new System.Drawing.Point(44, 0);
            this.buttonClickView6.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView6.Name = "buttonClickView6";
            this.buttonClickView6.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView6.TabIndex = 0;
            this.buttonClickView6.Text = "6";
            this.buttonClickView6.UseVisualStyleBackColor = true;
            this.buttonClickView6.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView7
            // 
            this.buttonClickView7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView7.Location = new System.Drawing.Point(88, 0);
            this.buttonClickView7.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView7.Name = "buttonClickView7";
            this.buttonClickView7.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView7.TabIndex = 0;
            this.buttonClickView7.Text = "7";
            this.buttonClickView7.UseVisualStyleBackColor = true;
            this.buttonClickView7.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView8
            // 
            this.buttonClickView8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView8.Location = new System.Drawing.Point(132, 0);
            this.buttonClickView8.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView8.Name = "buttonClickView8";
            this.buttonClickView8.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView8.TabIndex = 0;
            this.buttonClickView8.Text = "8";
            this.buttonClickView8.UseVisualStyleBackColor = true;
            this.buttonClickView8.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView9
            // 
            this.buttonClickView9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView9.Location = new System.Drawing.Point(176, 0);
            this.buttonClickView9.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView9.Name = "buttonClickView9";
            this.buttonClickView9.Size = new System.Drawing.Size(46, 27);
            this.buttonClickView9.TabIndex = 0;
            this.buttonClickView9.Text = "9";
            this.buttonClickView9.UseVisualStyleBackColor = true;
            this.buttonClickView9.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView40
            // 
            this.buttonClickView40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView40.Location = new System.Drawing.Point(288, 205);
            this.buttonClickView40.Name = "buttonClickView40";
            this.buttonClickView40.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView40.TabIndex = 0;
            this.buttonClickView40.Text = "\\";
            this.buttonClickView40.UseVisualStyleBackColor = true;
            this.buttonClickView40.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // tableLayoutPanel69
            // 
            this.tableLayoutPanel69.ColumnCount = 5;
            this.tableLayoutPanel5.SetColumnSpan(this.tableLayoutPanel69, 4);
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel69.Controls.Add(this.buttonNumberB, 0, 0);
            this.tableLayoutPanel69.Controls.Add(this.buttonClickView2, 2, 0);
            this.tableLayoutPanel69.Controls.Add(this.buttonClickView3, 3, 0);
            this.tableLayoutPanel69.Controls.Add(this.buttonClickView1, 1, 0);
            this.tableLayoutPanel69.Controls.Add(this.buttonClickView4, 4, 0);
            this.tableLayoutPanel69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel69.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel69.Name = "tableLayoutPanel69";
            this.tableLayoutPanel69.RowCount = 1;
            this.tableLayoutPanel69.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel69.Size = new System.Drawing.Size(222, 27);
            this.tableLayoutPanel69.TabIndex = 8;
            // 
            // buttonNumberB
            // 
            this.buttonNumberB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonNumberB.Location = new System.Drawing.Point(0, 0);
            this.buttonNumberB.Margin = new System.Windows.Forms.Padding(0);
            this.buttonNumberB.Name = "buttonNumberB";
            this.buttonNumberB.Size = new System.Drawing.Size(44, 27);
            this.buttonNumberB.TabIndex = 0;
            this.buttonNumberB.Text = "0";
            this.buttonNumberB.UseVisualStyleBackColor = true;
            this.buttonNumberB.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            this.buttonNumberB.Click += new System.EventHandler(this.buttonNumberB_Click);
            // 
            // buttonClickView2
            // 
            this.buttonClickView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView2.Location = new System.Drawing.Point(88, 0);
            this.buttonClickView2.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView2.Name = "buttonClickView2";
            this.buttonClickView2.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView2.TabIndex = 0;
            this.buttonClickView2.Text = "2";
            this.buttonClickView2.UseVisualStyleBackColor = true;
            this.buttonClickView2.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView3
            // 
            this.buttonClickView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView3.Location = new System.Drawing.Point(132, 0);
            this.buttonClickView3.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView3.Name = "buttonClickView3";
            this.buttonClickView3.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView3.TabIndex = 0;
            this.buttonClickView3.Text = "3";
            this.buttonClickView3.UseVisualStyleBackColor = true;
            this.buttonClickView3.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView1
            // 
            this.buttonClickView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView1.Location = new System.Drawing.Point(44, 0);
            this.buttonClickView1.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView1.Name = "buttonClickView1";
            this.buttonClickView1.Size = new System.Drawing.Size(44, 27);
            this.buttonClickView1.TabIndex = 0;
            this.buttonClickView1.Text = "1";
            this.buttonClickView1.UseVisualStyleBackColor = true;
            this.buttonClickView1.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            this.buttonClickView1.Click += new System.EventHandler(this.buttonClickView1_Click);
            // 
            // buttonClickView4
            // 
            this.buttonClickView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView4.Location = new System.Drawing.Point(176, 0);
            this.buttonClickView4.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClickView4.Name = "buttonClickView4";
            this.buttonClickView4.Size = new System.Drawing.Size(46, 27);
            this.buttonClickView4.TabIndex = 0;
            this.buttonClickView4.Text = "4";
            this.buttonClickView4.UseVisualStyleBackColor = true;
            this.buttonClickView4.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView10
            // 
            this.buttonClickView10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView10.Location = new System.Drawing.Point(231, 36);
            this.buttonClickView10.Name = "buttonClickView10";
            this.buttonClickView10.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView10.TabIndex = 0;
            this.buttonClickView10.Text = ".";
            this.buttonClickView10.UseVisualStyleBackColor = true;
            this.buttonClickView10.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView16
            // 
            this.buttonClickView16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView16.Location = new System.Drawing.Point(231, 69);
            this.buttonClickView16.Name = "buttonClickView16";
            this.buttonClickView16.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView16.TabIndex = 0;
            this.buttonClickView16.Text = "A";
            this.buttonClickView16.UseVisualStyleBackColor = true;
            this.buttonClickView16.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // menuStrip1
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.menuStrip1, 4);
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.секундомерToolStripMenuItem,
            this.buttonWriteB});
            this.menuStrip1.Location = new System.Drawing.Point(3, 304);
            this.menuStrip1.Margin = new System.Windows.Forms.Padding(3);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(222, 36);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // секундомерToolStripMenuItem
            // 
            this.секундомерToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonClickSecondMetr,
            this.buttonSecondsSaved,
            this.buttonInputMainForm,
            this.buttonIntCalculator,
            this.buttonInputMainFormReal,
            this.buttonBFromClipboard});
            this.секундомерToolStripMenuItem.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.секундомерToolStripMenuItem.Name = "секундомерToolStripMenuItem";
            this.секундомерToolStripMenuItem.Size = new System.Drawing.Size(80, 32);
            this.секундомерToolStripMenuItem.Text = "Из вне";
            // 
            // buttonClickSecondMetr
            // 
            this.buttonClickSecondMetr.Name = "buttonClickSecondMetr";
            this.buttonClickSecondMetr.Size = new System.Drawing.Size(715, 26);
            this.buttonClickSecondMetr.Text = "Измерить входной параметр секундомером";
            this.buttonClickSecondMetr.Click += new System.EventHandler(this.buttonClickSecondMetr_Click);
            // 
            // buttonSecondsSaved
            // 
            this.buttonSecondsSaved.Name = "buttonSecondsSaved";
            this.buttonSecondsSaved.Size = new System.Drawing.Size(715, 26);
            this.buttonSecondsSaved.Text = "Получить входной параметр из сохранённых измерений сееундомером";
            this.buttonSecondsSaved.Click += new System.EventHandler(this.buttonSecondsSaved_Click);
            // 
            // buttonInputMainForm
            // 
            this.buttonInputMainForm.Name = "buttonInputMainForm";
            this.buttonInputMainForm.Size = new System.Drawing.Size(715, 26);
            this.buttonInputMainForm.Text = "С предыдущего экрана";
            this.buttonInputMainForm.Click += new System.EventHandler(this.buttonInputMainForm_Click);
            // 
            // buttonIntCalculator
            // 
            this.buttonIntCalculator.Name = "buttonIntCalculator";
            this.buttonIntCalculator.Size = new System.Drawing.Size(715, 26);
            this.buttonIntCalculator.Text = "С целочисленного калькулятора";
            // 
            // buttonInputMainFormReal
            // 
            this.buttonInputMainFormReal.Name = "buttonInputMainFormReal";
            this.buttonInputMainFormReal.Size = new System.Drawing.Size(715, 26);
            this.buttonInputMainFormReal.Text = "С главного экрана";
            this.buttonInputMainFormReal.Click += new System.EventHandler(this.buttonInputMainFormReal_Click);
            // 
            // buttonBFromClipboard
            // 
            this.buttonBFromClipboard.Name = "buttonBFromClipboard";
            this.buttonBFromClipboard.Size = new System.Drawing.Size(715, 26);
            this.buttonBFromClipboard.Text = "Из буфера обмена";
            this.buttonBFromClipboard.Click += new System.EventHandler(this.buttonBFromClipboard_Click);
            // 
            // buttonWriteB
            // 
            this.buttonWriteB.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonWriteB1,
            this.buttonWriteBMain,
            this.buttonWriteBToClipboard});
            this.buttonWriteB.Name = "buttonWriteB";
            this.buttonWriteB.Size = new System.Drawing.Size(99, 32);
            this.buttonWriteB.Text = "Записать";
            // 
            // buttonWriteB1
            // 
            this.buttonWriteB1.Name = "buttonWriteB1";
            this.buttonWriteB1.Size = new System.Drawing.Size(287, 26);
            this.buttonWriteB1.Text = "На предыдущий экран";
            this.buttonWriteB1.Click += new System.EventHandler(this.buttonWriteB_Click);
            // 
            // buttonWriteBMain
            // 
            this.buttonWriteBMain.Name = "buttonWriteBMain";
            this.buttonWriteBMain.Size = new System.Drawing.Size(287, 26);
            this.buttonWriteBMain.Text = "На главный экран";
            this.buttonWriteBMain.Click += new System.EventHandler(this.buttonWriteBMain_Click);
            // 
            // buttonWriteBToClipboard
            // 
            this.buttonWriteBToClipboard.Name = "buttonWriteBToClipboard";
            this.buttonWriteBToClipboard.Size = new System.Drawing.Size(287, 26);
            this.buttonWriteBToClipboard.Text = "В буфер обмена";
            this.buttonWriteBToClipboard.Click += new System.EventHandler(this.buttonWriteBToClipboard_Click);
            // 
            // buttonMines
            // 
            this.buttonMines.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMines.Location = new System.Drawing.Point(117, 271);
            this.buttonMines.Name = "buttonMines";
            this.buttonMines.Size = new System.Drawing.Size(51, 27);
            this.buttonMines.TabIndex = 7;
            this.buttonMines.Text = "+/-";
            this.buttonMines.UseVisualStyleBackColor = true;
            this.buttonMines.Click += new System.EventHandler(this.buttonMines_Click);
            // 
            // buttonAbs
            // 
            this.buttonAbs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAbs.Location = new System.Drawing.Point(3, 271);
            this.buttonAbs.Name = "buttonAbs";
            this.buttonAbs.Size = new System.Drawing.Size(51, 27);
            this.buttonAbs.TabIndex = 8;
            this.buttonAbs.Text = "|x|";
            this.buttonAbs.UseVisualStyleBackColor = true;
            this.buttonAbs.Click += new System.EventHandler(this.buttonAbs_Click);
            // 
            // buttonRet
            // 
            this.buttonRet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRet.Location = new System.Drawing.Point(60, 271);
            this.buttonRet.Name = "buttonRet";
            this.buttonRet.Size = new System.Drawing.Size(51, 27);
            this.buttonRet.TabIndex = 9;
            this.buttonRet.Text = "1/x";
            this.buttonRet.UseVisualStyleBackColor = true;
            this.buttonRet.Click += new System.EventHandler(this.buttonRet_Click);
            // 
            // buttonDivX2
            // 
            this.buttonDivX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDivX2.Location = new System.Drawing.Point(174, 238);
            this.buttonDivX2.Name = "buttonDivX2";
            this.buttonDivX2.Size = new System.Drawing.Size(51, 27);
            this.buttonDivX2.TabIndex = 10;
            this.buttonDivX2.Text = "x/2";
            this.buttonDivX2.UseVisualStyleBackColor = true;
            this.buttonDivX2.Click += new System.EventHandler(this.buttonDivX2_Click);
            // 
            // buttonClickView18
            // 
            this.buttonClickView18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView18.Location = new System.Drawing.Point(345, 69);
            this.buttonClickView18.Name = "buttonClickView18";
            this.buttonClickView18.Size = new System.Drawing.Size(58, 27);
            this.buttonClickView18.TabIndex = 0;
            this.buttonClickView18.Text = "E";
            this.buttonClickView18.UseVisualStyleBackColor = true;
            this.buttonClickView18.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonBA
            // 
            this.buttonBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBA.Location = new System.Drawing.Point(345, 271);
            this.buttonBA.Name = "buttonBA";
            this.buttonBA.Size = new System.Drawing.Size(58, 27);
            this.buttonBA.TabIndex = 0;
            this.buttonBA.Text = "B=A";
            this.buttonBA.UseVisualStyleBackColor = true;
            this.buttonBA.Click += new System.EventHandler(this.buttonBA_Click);
            // 
            // buttonClickView33
            // 
            this.buttonClickView33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView33.Location = new System.Drawing.Point(288, 3);
            this.buttonClickView33.Name = "buttonClickView33";
            this.buttonClickView33.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView33.TabIndex = 0;
            this.buttonClickView33.Text = "000";
            this.buttonClickView33.UseVisualStyleBackColor = true;
            this.buttonClickView33.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonMinesAbs
            // 
            this.buttonMinesAbs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMinesAbs.Location = new System.Drawing.Point(3, 238);
            this.buttonMinesAbs.Name = "buttonMinesAbs";
            this.buttonMinesAbs.Size = new System.Drawing.Size(51, 27);
            this.buttonMinesAbs.TabIndex = 8;
            this.buttonMinesAbs.Text = "-|x|";
            this.buttonMinesAbs.UseVisualStyleBackColor = true;
            this.buttonMinesAbs.Click += new System.EventHandler(this.buttonMinesAbs_Click);
            // 
            // buttonMinesRet
            // 
            this.buttonMinesRet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMinesRet.Location = new System.Drawing.Point(60, 238);
            this.buttonMinesRet.Name = "buttonMinesRet";
            this.buttonMinesRet.Size = new System.Drawing.Size(51, 27);
            this.buttonMinesRet.TabIndex = 9;
            this.buttonMinesRet.Text = "-1/x";
            this.buttonMinesRet.UseVisualStyleBackColor = true;
            this.buttonMinesRet.Click += new System.EventHandler(this.buttonMinesRet_Click);
            // 
            // buttonMinesX
            // 
            this.buttonMinesX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMinesX.Location = new System.Drawing.Point(117, 238);
            this.buttonMinesX.Name = "buttonMinesX";
            this.buttonMinesX.Size = new System.Drawing.Size(51, 27);
            this.buttonMinesX.TabIndex = 9;
            this.buttonMinesX.Text = "-x";
            this.buttonMinesX.UseVisualStyleBackColor = true;
            this.buttonMinesX.Click += new System.EventHandler(this.buttonMines_Click);
            // 
            // buttonAbsRet
            // 
            this.buttonAbsRet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAbsRet.Location = new System.Drawing.Point(174, 205);
            this.buttonAbsRet.Name = "buttonAbsRet";
            this.buttonAbsRet.Size = new System.Drawing.Size(51, 27);
            this.buttonAbsRet.TabIndex = 9;
            this.buttonAbsRet.Text = "1/|x|";
            this.buttonAbsRet.UseVisualStyleBackColor = true;
            this.buttonAbsRet.Click += new System.EventHandler(this.buttonAbsRet_Click);
            // 
            // buttonMinesAbsRet
            // 
            this.buttonMinesAbsRet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMinesAbsRet.Location = new System.Drawing.Point(231, 205);
            this.buttonMinesAbsRet.Name = "buttonMinesAbsRet";
            this.buttonMinesAbsRet.Size = new System.Drawing.Size(51, 27);
            this.buttonMinesAbsRet.TabIndex = 9;
            this.buttonMinesAbsRet.Text = "-1/|x|";
            this.buttonMinesAbsRet.UseVisualStyleBackColor = true;
            this.buttonMinesAbsRet.Click += new System.EventHandler(this.buttonMinesAbsRet_Click);
            // 
            // buttonClickView35
            // 
            this.buttonClickView35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView35.Location = new System.Drawing.Point(3, 205);
            this.buttonClickView35.Name = "buttonClickView35";
            this.buttonClickView35.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView35.TabIndex = 0;
            this.buttonClickView35.Text = "log";
            this.buttonClickView35.UseVisualStyleBackColor = true;
            this.buttonClickView35.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView36
            // 
            this.buttonClickView36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView36.Location = new System.Drawing.Point(60, 205);
            this.buttonClickView36.Name = "buttonClickView36";
            this.buttonClickView36.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView36.TabIndex = 0;
            this.buttonClickView36.Text = "lg";
            this.buttonClickView36.UseVisualStyleBackColor = true;
            this.buttonClickView36.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView37
            // 
            this.buttonClickView37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView37.Location = new System.Drawing.Point(117, 205);
            this.buttonClickView37.Name = "buttonClickView37";
            this.buttonClickView37.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView37.TabIndex = 0;
            this.buttonClickView37.Text = "ln";
            this.buttonClickView37.UseVisualStyleBackColor = true;
            this.buttonClickView37.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView38
            // 
            this.buttonClickView38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView38.Location = new System.Drawing.Point(345, 205);
            this.buttonClickView38.Name = "buttonClickView38";
            this.buttonClickView38.Size = new System.Drawing.Size(58, 27);
            this.buttonClickView38.TabIndex = 0;
            this.buttonClickView38.Text = "✓";
            this.buttonClickView38.UseVisualStyleBackColor = true;
            this.buttonClickView38.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonPlusBasketes
            // 
            this.buttonPlusBasketes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPlusBasketes.Location = new System.Drawing.Point(231, 304);
            this.buttonPlusBasketes.Name = "buttonPlusBasketes";
            this.buttonPlusBasketes.Size = new System.Drawing.Size(51, 36);
            this.buttonPlusBasketes.TabIndex = 13;
            this.buttonPlusBasketes.Text = "+()";
            this.buttonPlusBasketes.UseVisualStyleBackColor = true;
            this.buttonPlusBasketes.Click += new System.EventHandler(this.buttonPlusBasketes_Click);
            // 
            // buttonMinesBasketes
            // 
            this.buttonMinesBasketes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMinesBasketes.Location = new System.Drawing.Point(288, 304);
            this.buttonMinesBasketes.Name = "buttonMinesBasketes";
            this.buttonMinesBasketes.Size = new System.Drawing.Size(51, 36);
            this.buttonMinesBasketes.TabIndex = 13;
            this.buttonMinesBasketes.Text = "-()";
            this.buttonMinesBasketes.UseVisualStyleBackColor = true;
            this.buttonMinesBasketes.Click += new System.EventHandler(this.buttonMinesBasketes_Click);
            // 
            // buttonChangeBaskets
            // 
            this.buttonChangeBaskets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonChangeBaskets.Location = new System.Drawing.Point(231, 271);
            this.buttonChangeBaskets.Name = "buttonChangeBaskets";
            this.buttonChangeBaskets.Size = new System.Drawing.Size(51, 27);
            this.buttonChangeBaskets.TabIndex = 13;
            this.buttonChangeBaskets.Text = "*()";
            this.buttonChangeBaskets.UseVisualStyleBackColor = true;
            this.buttonChangeBaskets.Click += new System.EventHandler(this.buttonChangeBaskets_Click);
            // 
            // buttonClickView21
            // 
            this.buttonClickView21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView21.Location = new System.Drawing.Point(231, 3);
            this.buttonClickView21.Name = "buttonClickView21";
            this.buttonClickView21.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView21.TabIndex = 0;
            this.buttonClickView21.Text = "00";
            this.buttonClickView21.UseVisualStyleBackColor = true;
            this.buttonClickView21.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView34
            // 
            this.buttonClickView34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView34.Location = new System.Drawing.Point(288, 36);
            this.buttonClickView34.Name = "buttonClickView34";
            this.buttonClickView34.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView34.TabIndex = 0;
            this.buttonClickView34.Text = "0000";
            this.buttonClickView34.UseVisualStyleBackColor = true;
            this.buttonClickView34.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView17
            // 
            this.buttonClickView17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView17.Location = new System.Drawing.Point(288, 69);
            this.buttonClickView17.Name = "buttonClickView17";
            this.buttonClickView17.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView17.TabIndex = 0;
            this.buttonClickView17.Text = "PI";
            this.buttonClickView17.UseVisualStyleBackColor = true;
            this.buttonClickView17.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonChangeAbsBaskets
            // 
            this.buttonChangeAbsBaskets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonChangeAbsBaskets.Location = new System.Drawing.Point(231, 238);
            this.buttonChangeAbsBaskets.Name = "buttonChangeAbsBaskets";
            this.buttonChangeAbsBaskets.Size = new System.Drawing.Size(51, 27);
            this.buttonChangeAbsBaskets.TabIndex = 13;
            this.buttonChangeAbsBaskets.Text = "*||";
            this.buttonChangeAbsBaskets.UseVisualStyleBackColor = true;
            this.buttonChangeAbsBaskets.Visible = false;
            this.buttonChangeAbsBaskets.Click += new System.EventHandler(this.buttonChangeAbsBaskets_Click);
            // 
            // buttonPersent
            // 
            this.buttonPersent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPersent.Location = new System.Drawing.Point(174, 271);
            this.buttonPersent.Name = "buttonPersent";
            this.buttonPersent.Size = new System.Drawing.Size(51, 27);
            this.buttonPersent.TabIndex = 12;
            this.buttonPersent.Text = "x%";
            this.buttonPersent.UseVisualStyleBackColor = true;
            this.buttonPersent.Click += new System.EventHandler(this.buttonPersent_Click);
            // 
            // buttonPlusAbs
            // 
            this.buttonPlusAbs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPlusAbs.Location = new System.Drawing.Point(288, 271);
            this.buttonPlusAbs.Name = "buttonPlusAbs";
            this.buttonPlusAbs.Size = new System.Drawing.Size(51, 27);
            this.buttonPlusAbs.TabIndex = 13;
            this.buttonPlusAbs.Text = "+/-||";
            this.buttonPlusAbs.UseVisualStyleBackColor = true;
            this.buttonPlusAbs.Visible = false;
            this.buttonPlusAbs.Click += new System.EventHandler(this.buttonPlusAbs_Click);
            // 
            // buttonClickView39
            // 
            this.buttonClickView39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView39.Location = new System.Drawing.Point(345, 238);
            this.buttonClickView39.Name = "buttonClickView39";
            this.buttonClickView39.Size = new System.Drawing.Size(58, 27);
            this.buttonClickView39.TabIndex = 0;
            this.buttonClickView39.Text = "-/-";
            this.buttonClickView39.UseVisualStyleBackColor = true;
            this.buttonClickView39.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView41
            // 
            this.buttonClickView41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView41.Location = new System.Drawing.Point(231, 135);
            this.buttonClickView41.Name = "buttonClickView41";
            this.buttonClickView41.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView41.TabIndex = 0;
            this.buttonClickView41.Text = "pi";
            this.buttonClickView41.UseVisualStyleBackColor = true;
            this.buttonClickView41.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView42
            // 
            this.buttonClickView42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView42.Location = new System.Drawing.Point(345, 135);
            this.buttonClickView42.Name = "buttonClickView42";
            this.buttonClickView42.Size = new System.Drawing.Size(58, 27);
            this.buttonClickView42.TabIndex = 0;
            this.buttonClickView42.Text = "e";
            this.buttonClickView42.UseVisualStyleBackColor = true;
            this.buttonClickView42.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView43
            // 
            this.buttonClickView43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView43.Location = new System.Drawing.Point(117, 135);
            this.buttonClickView43.Name = "buttonClickView43";
            this.buttonClickView43.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView43.TabIndex = 0;
            this.buttonClickView43.Text = "Pi";
            this.buttonClickView43.UseVisualStyleBackColor = true;
            this.buttonClickView43.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView44
            // 
            this.buttonClickView44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView44.Location = new System.Drawing.Point(174, 135);
            this.buttonClickView44.Name = "buttonClickView44";
            this.buttonClickView44.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView44.TabIndex = 0;
            this.buttonClickView44.Text = "pI";
            this.buttonClickView44.UseVisualStyleBackColor = true;
            this.buttonClickView44.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView45
            // 
            this.buttonClickView45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView45.Location = new System.Drawing.Point(60, 135);
            this.buttonClickView45.Name = "buttonClickView45";
            this.buttonClickView45.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView45.TabIndex = 0;
            this.buttonClickView45.Text = "PI";
            this.buttonClickView45.UseVisualStyleBackColor = true;
            this.buttonClickView45.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView46
            // 
            this.buttonClickView46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView46.Location = new System.Drawing.Point(288, 135);
            this.buttonClickView46.Name = "buttonClickView46";
            this.buttonClickView46.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView46.TabIndex = 0;
            this.buttonClickView46.Text = "E";
            this.buttonClickView46.UseVisualStyleBackColor = true;
            this.buttonClickView46.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView50
            // 
            this.buttonClickView50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView50.Location = new System.Drawing.Point(60, 168);
            this.buttonClickView50.Name = "buttonClickView50";
            this.buttonClickView50.Size = new System.Drawing.Size(51, 31);
            this.buttonClickView50.TabIndex = 0;
            this.buttonClickView50.Text = "!";
            this.buttonClickView50.UseVisualStyleBackColor = true;
            this.buttonClickView50.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView51
            // 
            this.buttonClickView51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView51.Location = new System.Drawing.Point(3, 168);
            this.buttonClickView51.Name = "buttonClickView51";
            this.buttonClickView51.Size = new System.Drawing.Size(51, 31);
            this.buttonClickView51.TabIndex = 0;
            this.buttonClickView51.Text = "_";
            this.buttonClickView51.UseVisualStyleBackColor = true;
            this.buttonClickView51.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // buttonClickView52
            // 
            this.buttonClickView52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView52.Location = new System.Drawing.Point(3, 135);
            this.buttonClickView52.Name = "buttonClickView52";
            this.buttonClickView52.Size = new System.Drawing.Size(51, 27);
            this.buttonClickView52.TabIndex = 0;
            this.buttonClickView52.Text = " ";
            this.buttonClickView52.UseVisualStyleBackColor = true;
            this.buttonClickView52.ClickView += new TableAIS.ClickView(this.buttonNumberB_ClickView);
            // 
            // groupBox86
            // 
            this.groupBox86.Controls.Add(this.tableLayoutPanel73);
            this.groupBox86.Location = new System.Drawing.Point(3, 379);
            this.groupBox86.Name = "groupBox86";
            this.groupBox86.Size = new System.Drawing.Size(412, 100);
            this.groupBox86.TabIndex = 4;
            this.groupBox86.TabStop = false;
            this.groupBox86.Text = "Элементарные функции";
            // 
            // tableLayoutPanel73
            // 
            this.tableLayoutPanel73.ColumnCount = 2;
            this.tableLayoutPanel73.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel73.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel73.Controls.Add(this.comboBoxFunc, 1, 0);
            this.tableLayoutPanel73.Controls.Add(this.buttonAddFunc, 0, 0);
            this.tableLayoutPanel73.Controls.Add(this.buttonAddFuncs, 0, 1);
            this.tableLayoutPanel73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel73.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel73.Name = "tableLayoutPanel73";
            this.tableLayoutPanel73.RowCount = 2;
            this.tableLayoutPanel73.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel73.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel73.Size = new System.Drawing.Size(406, 67);
            this.tableLayoutPanel73.TabIndex = 0;
            // 
            // comboBoxFunc
            // 
            this.comboBoxFunc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxFunc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFunc.DropDownWidth = 200;
            this.comboBoxFunc.FormattingEnabled = true;
            this.comboBoxFunc.Location = new System.Drawing.Point(206, 3);
            this.comboBoxFunc.Name = "comboBoxFunc";
            this.comboBoxFunc.Size = new System.Drawing.Size(197, 29);
            this.comboBoxFunc.TabIndex = 0;
            // 
            // buttonAddFunc
            // 
            this.buttonAddFunc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAddFunc.Location = new System.Drawing.Point(3, 3);
            this.buttonAddFunc.Name = "buttonAddFunc";
            this.buttonAddFunc.Size = new System.Drawing.Size(197, 27);
            this.buttonAddFunc.TabIndex = 1;
            this.buttonAddFunc.Text = "Добавить";
            this.buttonAddFunc.UseVisualStyleBackColor = true;
            this.buttonAddFunc.Click += new System.EventHandler(this.buttonAddFunc_Click);
            // 
            // buttonAddFuncs
            // 
            this.tableLayoutPanel73.SetColumnSpan(this.buttonAddFuncs, 2);
            this.buttonAddFuncs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAddFuncs.Location = new System.Drawing.Point(3, 36);
            this.buttonAddFuncs.Name = "buttonAddFuncs";
            this.buttonAddFuncs.Size = new System.Drawing.Size(400, 28);
            this.buttonAddFuncs.TabIndex = 2;
            this.buttonAddFuncs.Text = "Вставить функцию из библиотеки";
            this.buttonAddFuncs.UseVisualStyleBackColor = true;
            this.buttonAddFuncs.Click += new System.EventHandler(this.buttonAddFuncs_Click);
            // 
            // groupBox87
            // 
            this.groupBox87.Controls.Add(this.tableLayoutPanel74);
            this.groupBox87.Location = new System.Drawing.Point(3, 485);
            this.groupBox87.Name = "groupBox87";
            this.groupBox87.Size = new System.Drawing.Size(409, 120);
            this.groupBox87.TabIndex = 5;
            this.groupBox87.TabStop = false;
            this.groupBox87.Text = "Ссылки на память (переменные)";
            // 
            // tableLayoutPanel74
            // 
            this.tableLayoutPanel74.ColumnCount = 2;
            this.tableLayoutPanel74.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel74.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel74.Controls.Add(this.comboBoxMemory, 0, 0);
            this.tableLayoutPanel74.Controls.Add(this.buttonSetMemory, 0, 0);
            this.tableLayoutPanel74.Controls.Add(this.button1, 0, 1);
            this.tableLayoutPanel74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel74.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel74.Name = "tableLayoutPanel74";
            this.tableLayoutPanel74.RowCount = 2;
            this.tableLayoutPanel74.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel74.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel74.Size = new System.Drawing.Size(403, 87);
            this.tableLayoutPanel74.TabIndex = 0;
            // 
            // comboBoxMemory
            // 
            this.comboBoxMemory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxMemory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMemory.DropDownWidth = 200;
            this.comboBoxMemory.FormattingEnabled = true;
            this.comboBoxMemory.Location = new System.Drawing.Point(204, 3);
            this.comboBoxMemory.Name = "comboBoxMemory";
            this.comboBoxMemory.Size = new System.Drawing.Size(196, 29);
            this.comboBoxMemory.TabIndex = 3;
            // 
            // buttonSetMemory
            // 
            this.buttonSetMemory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSetMemory.Location = new System.Drawing.Point(3, 3);
            this.buttonSetMemory.Name = "buttonSetMemory";
            this.buttonSetMemory.Size = new System.Drawing.Size(195, 37);
            this.buttonSetMemory.TabIndex = 2;
            this.buttonSetMemory.Text = "Добавить";
            this.buttonSetMemory.UseVisualStyleBackColor = true;
            this.buttonSetMemory.Click += new System.EventHandler(this.buttonSetMemory_Click);
            // 
            // button1
            // 
            this.tableLayoutPanel74.SetColumnSpan(this.button1, 2);
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(3, 46);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(397, 38);
            this.button1.TabIndex = 4;
            this.button1.Text = "Обновить список";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.timerMemory_Tick);
            // 
            // timerMemory
            // 
            this.timerMemory.Interval = 10000;
            this.timerMemory.Tick += new System.EventHandler(this.timerMemory_Tick);
            // 
            // CalculatorKeyBord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(933, 553);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "CalculatorKeyBord";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Кнопочный калькулятор";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.groupBox45.ResumeLayout(false);
            this.tableLayoutPanel48.ResumeLayout(false);
            this.tableLayoutPanel48.PerformLayout();
            this.menuStrip5.ResumeLayout(false);
            this.menuStrip5.PerformLayout();
            this.menuStrip4.ResumeLayout(false);
            this.menuStrip4.PerformLayout();
            this.groupBox54.ResumeLayout(false);
            this.groupBox53.ResumeLayout(false);
            this.groupBox52.ResumeLayout(false);
            this.groupBox50.ResumeLayout(false);
            this.groupBox51.ResumeLayout(false);
            this.groupBox49.ResumeLayout(false);
            this.groupBox47.ResumeLayout(false);
            this.tableLayoutPanel50.ResumeLayout(false);
            this.tableLayoutPanel50.PerformLayout();
            this.groupBox46.ResumeLayout(false);
            this.tableLayoutPanel49.ResumeLayout(false);
            this.tableLayoutPanel49.PerformLayout();
            this.groupBox48.ResumeLayout(false);
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel51.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.tableLayoutPanel19.ResumeLayout(false);
            this.groupBox83.ResumeLayout(false);
            this.tableLayoutPanel71.ResumeLayout(false);
            this.tableLayoutPanel71.PerformLayout();
            this.groupBox84.ResumeLayout(false);
            this.tableLayoutPanel72.ResumeLayout(false);
            this.tableLayoutPanel72.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.tableLayoutPanel24.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel26.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            this.tableLayoutPanel31.ResumeLayout(false);
            this.groupBox29.ResumeLayout(false);
            this.tableLayoutPanel38.ResumeLayout(false);
            this.tableLayoutPanel38.PerformLayout();
            this.tableLayoutPanel37.ResumeLayout(false);
            this.tableLayoutPanel36.ResumeLayout(false);
            this.groupBox27.ResumeLayout(false);
            this.tableLayoutPanel32.ResumeLayout(false);
            this.tableLayoutPanel32.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel35.ResumeLayout(false);
            this.groupBox28.ResumeLayout(false);
            this.tableLayoutPanel33.ResumeLayout(false);
            this.tableLayoutPanel33.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel30.PerformLayout();
            this.tableLayoutPanel34.ResumeLayout(false);
            this.groupBox30.ResumeLayout(false);
            this.tableLayoutPanel39.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.tableLayoutPanel40.ResumeLayout(false);
            this.tableLayoutPanel40.PerformLayout();
            this.groupBox32.ResumeLayout(false);
            this.tableLayoutPanel41.ResumeLayout(false);
            this.groupBox33.ResumeLayout(false);
            this.groupBox34.ResumeLayout(false);
            this.groupBox35.ResumeLayout(false);
            this.tableLayoutPanel42.ResumeLayout(false);
            this.groupBox36.ResumeLayout(false);
            this.tableLayoutPanel43.ResumeLayout(false);
            this.tableLayoutPanel43.PerformLayout();
            this.groupBox37.ResumeLayout(false);
            this.tableLayoutPanel44.ResumeLayout(false);
            this.groupBox38.ResumeLayout(false);
            this.groupBox39.ResumeLayout(false);
            this.groupBox40.ResumeLayout(false);
            this.tableLayoutPanel45.ResumeLayout(false);
            this.groupBox41.ResumeLayout(false);
            this.tableLayoutPanel46.ResumeLayout(false);
            this.tableLayoutPanel46.PerformLayout();
            this.groupBox42.ResumeLayout(false);
            this.tableLayoutPanel47.ResumeLayout(false);
            this.groupBox43.ResumeLayout(false);
            this.groupBox44.ResumeLayout(false);
            this.groupBox55.ResumeLayout(false);
            this.tableLayoutPanel52.ResumeLayout(false);
            this.groupBox64.ResumeLayout(false);
            this.tableLayoutPanel57.ResumeLayout(false);
            this.groupBox65.ResumeLayout(false);
            this.groupBox66.ResumeLayout(false);
            this.groupBox56.ResumeLayout(false);
            this.tableLayoutPanel53.ResumeLayout(false);
            this.tableLayoutPanel53.PerformLayout();
            this.groupBox57.ResumeLayout(false);
            this.tableLayoutPanel54.ResumeLayout(false);
            this.tableLayoutPanel54.PerformLayout();
            this.groupBox58.ResumeLayout(false);
            this.tableLayoutPanel55.ResumeLayout(false);
            this.groupBox60.ResumeLayout(false);
            this.groupBox59.ResumeLayout(false);
            this.groupBox61.ResumeLayout(false);
            this.tableLayoutPanel56.ResumeLayout(false);
            this.groupBox63.ResumeLayout(false);
            this.groupBox62.ResumeLayout(false);
            this.groupBox67.ResumeLayout(false);
            this.tableLayoutPanel58.ResumeLayout(false);
            this.groupBox72.ResumeLayout(false);
            this.tableLayoutPanel61.ResumeLayout(false);
            this.groupBox73.ResumeLayout(false);
            this.groupBox74.ResumeLayout(false);
            this.groupBox68.ResumeLayout(false);
            this.tableLayoutPanel59.ResumeLayout(false);
            this.tableLayoutPanel59.PerformLayout();
            this.groupBox69.ResumeLayout(false);
            this.tableLayoutPanel60.ResumeLayout(false);
            this.groupBox71.ResumeLayout(false);
            this.groupBox70.ResumeLayout(false);
            this.groupBox75.ResumeLayout(false);
            this.tableLayoutPanel62.ResumeLayout(false);
            this.groupBox76.ResumeLayout(false);
            this.tableLayoutPanel63.ResumeLayout(false);
            this.groupBox77.ResumeLayout(false);
            this.groupBox78.ResumeLayout(false);
            this.groupBox79.ResumeLayout(false);
            this.tableLayoutPanel64.ResumeLayout(false);
            this.tableLayoutPanel64.PerformLayout();
            this.groupBox80.ResumeLayout(false);
            this.tableLayoutPanel65.ResumeLayout(false);
            this.groupBox81.ResumeLayout(false);
            this.groupBox82.ResumeLayout(false);
            this.flowLayoutPanelInputB.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel75.ResumeLayout(false);
            this.tableLayoutPanel68.ResumeLayout(false);
            this.tableLayoutPanel67.ResumeLayout(false);
            this.tableLayoutPanel66.ResumeLayout(false);
            this.tableLayoutPanel70.ResumeLayout(false);
            this.tableLayoutPanel69.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox86.ResumeLayout(false);
            this.tableLayoutPanel73.ResumeLayout(false);
            this.groupBox87.ResumeLayout(false);
            this.tableLayoutPanel74.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxA;
        private System.Windows.Forms.TextBox textBoxB;
        private System.Windows.Forms.Button buttonBackSpace;
        private System.Windows.Forms.Button buttonClearB;
        private System.Windows.Forms.Button buttonClearA;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.GroupBox groupBox1;
        private ButtonClickView buttonNumberB;
        private ButtonClickView buttonClickView1;
        private ButtonClickView buttonClickView2;
        private ButtonClickView buttonClickView3;
        private ButtonClickView buttonClickView4;
        private ButtonClickView buttonClickView5;
        private ButtonClickView buttonClickView6;
        private ButtonClickView buttonClickView7;
        private ButtonClickView buttonClickView8;
        private ButtonClickView buttonClickView9;
        private ButtonClickView buttonClickView10;
        private ButtonClickView buttonClickView11;
        private ButtonClickView buttonClickView12;
        private ButtonClickView buttonClickView13;
        private ButtonClickView buttonClickView14;
        private ButtonClickView buttonClickView15;
        private ButtonClickView buttonClickView16;
        private ButtonClickView buttonClickView17;
        private ButtonClickView buttonClickView18;
        private ButtonClickView buttonClickView19;
        private ButtonClickView buttonClickView20;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem секундомерToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonClickSecondMetr;
        private System.Windows.Forms.ToolStripMenuItem buttonSecondsSaved;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private ButtonClickView buttonBA;
        private ButtonClickView buttonSetAB;
        private ButtonClickView buttonAdd;
        private ButtonClickView buttonClickMinesB;
        private ButtonClickView buttonMinesA;
        private ButtonClickView buttonMul;
        private ButtonClickView buttonDivB;
        private ButtonClickView buttonDivA;
        private ButtonClickView buttonPowB;
        private ButtonClickView buttonPowA;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private ButtonClickView buttonPow2;
        private ButtonClickView buttonPow3;
        private ButtonClickView buttonPowA2;
        private ButtonClickView buttonPowA3;
        private ButtonClickView buttonIncB;
        private ButtonClickView buttonDecB;
        private ButtonClickView buttonIncA;
        private ButtonClickView buttonDecA;
        private System.Windows.Forms.Button buttonSet;
        private ButtonClickView buttonPow2B;
        private ButtonClickView buttonPow2A;
        private ButtonClickView buttonMulB2;
        private ButtonClickView buttonMul2A;
        private ButtonClickView buttonSqrtB;
        private ButtonClickView buttonSqrtA;
        private ButtonClickView buttonSqrtAB;
        private ButtonClickView buttonSqrtBA;
        private System.Windows.Forms.Button buttonMines;
        private ButtonClickView buttonB1;
        private ButtonClickView buttonA1;
        private ButtonClickView buttonMul2B;
        private ButtonClickView buttonDiv2B;
        private ButtonClickView buttonRetA;
        private ButtonClickView buttonRetB;
        private ButtonClickView buttonPowEA;
        private ButtonClickView buttonPowEB;
        private ButtonClickView buttonLnB;
        private ButtonClickView buttonLnA;
        private ButtonClickView buttonLgB;
        private ButtonClickView buttonLgA;
        private ButtonClickView buttonAbsB;
        private ButtonClickView buttonAbsA;
        private ButtonClickView buttonLogBA;
        private ButtonClickView buttonLogAB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private ButtonClickView buttonAbs;
        private ButtonClickView buttonRet;
        private ButtonClickView buttonDivX2;
        private ButtonClickView buttonMulX2;
        private ButtonClickView buttonAB;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem radioButtonCurcleA;
        private System.Windows.Forms.ToolStripMenuItem buttonWrite;
        private System.Windows.Forms.ToolStripMenuItem вывестиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonOutputWrite;
        private ButtonClickView buttonPersent;
        private ButtonClickView buttonPersentB;
        private ButtonClickView buttonPersentA;
        private ButtonClickView buttonClickView21;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private ButtonClickView buttonSqvSum;
        private ButtonClickView buttonSqvSumB;
        private ButtonClickView buttonSubA;
        private ButtonClickView buttonSumSqvs;
        private ButtonClickView buttonSubSqvsA;
        private ButtonClickView buttonSubSqvsB;
        private ButtonClickView buttonKubSum;
        private ButtonClickView buttonKubSubB;
        private ButtonClickView buttonKubSubA;
        private ButtonClickView buttonSumKub;
        private ButtonClickView buttonSubKubA;
        private ButtonClickView buttonSubKubB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.TextBox textBoxBuffer;
        private ButtonClickView buttonBBuffer;
        private ButtonClickView buttonBufferA;
        private ButtonClickView buttonBufferB;
        private ButtonClickView buttonABuffer;
        private ButtonClickView buttonBufferClear;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private ButtonClickView buttonGipotenuze;
        private ButtonClickView buttonCatetB;
        private ButtonClickView buttonCatetA;
        private ButtonClickView buttonGipotenuzeA;
        private ButtonClickView buttonGipotenuzeB;
        private ButtonClickView buttonCatetSqrtA;
        private ButtonClickView buttonCatetSqrtB;
        private ButtonClickView buttonSqrTruangleCatets;
        private ButtonClickView buttonSqrTruangleCatetsB;
        private ButtonClickView buttonSqrTruangleCatetsA;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private ButtonClickView buttonSqrTruangleA;
        private System.Windows.Forms.Button buttonRetSqrA;
        private ButtonClickView buttonTallA;
        private System.Windows.Forms.Button buttonRetTallA;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Button buttonRetTallB;
        private ButtonClickView buttonSqrTruangleB;
        private System.Windows.Forms.Button buttonRetSqrB;
        private ButtonClickView buttonTallB;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private ButtonClickView buttonTallGradAB;
        private ButtonClickView buttonSqrGradAB;
        private ButtonClickView buttonGradLenAB;
        private ButtonClickView buttonLenGradAB;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private ButtonClickView buttonTallRadAB;
        private ButtonClickView buttonSqrRadAB;
        private ButtonClickView buttonRadLenAB;
        private ButtonClickView buttonLenRadAB;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private ButtonClickView buttonTallRadBA;
        private ButtonClickView buttonSqrRadBA;
        private ButtonClickView buttonRadLenBA;
        private ButtonClickView buttonLenRadBA;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private ButtonClickView buttonTallGradBA;
        private ButtonClickView buttonSqrGradBA;
        private ButtonClickView buttonGradLenBA;
        private ButtonClickView buttonLenGradBA;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private ButtonClickView buttonGradB;
        private ButtonClickView buttonGradA;
        private ButtonClickView buttonRadB;
        private ButtonClickView buttonRadA;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.RadioButton radioButtonCurcleB;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.GroupBox groupBox22;
        private Controls.ComboBoxToolTip comboBoxCurcleFrom;
        private Controls.ComboBoxToolTip comboBoxCurcleTo;
        private ButtonClickView buttonCurcleCalculate;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.RadioButton radioSinGrad;
        private System.Windows.Forms.RadioButton radioSinRad;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel32;
        private System.Windows.Forms.RadioButton radioASinGrad;
        private System.Windows.Forms.RadioButton radioASinRad;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.RadioButton radioSinA;
        private System.Windows.Forms.RadioButton radioSinB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel36;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel34;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel38;
        private System.Windows.Forms.RadioButton radioASinA;
        private System.Windows.Forms.RadioButton radioASinB;
        private ButtonClickView buttonSin;
        private ButtonClickView buttonCos;
        private ButtonClickView buttonTg;
        private ButtonClickView buttonCtg;
        private ButtonClickView buttonCosec;
        private ButtonClickView buttonSec;
        private ButtonClickView buttonArcSin;
        private ButtonClickView buttonAcos;
        private ButtonClickView buttonAtg;
        private ButtonClickView buttonAcosec;
        private ButtonClickView buttonAsec;
        private ButtonClickView buttonActg;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel39;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel40;
        private System.Windows.Forms.RadioButton radioButtonTimeA;
        private System.Windows.Forms.RadioButton radioButtonTimeB;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel41;
        private System.Windows.Forms.GroupBox groupBox33;
        private Controls.ComboBoxToolTip comboBoxTimeFrom;
        private System.Windows.Forms.GroupBox groupBox34;
        private Controls.ComboBoxToolTip comboBoxTimeTo;
        private ButtonClickView buttonTimeCalculate;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel42;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel43;
        private System.Windows.Forms.RadioButton radioButtonMetrA;
        private System.Windows.Forms.RadioButton radioButtonMetrB;
        private System.Windows.Forms.GroupBox groupBox37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel44;
        private System.Windows.Forms.GroupBox groupBox38;
        private Controls.ComboBoxToolTip comboBoxMetrFrom;
        private System.Windows.Forms.GroupBox groupBox39;
        private Controls.ComboBoxToolTip comboBoxMetrTo;
        private ButtonClickView buttonLengthConvert;
        private System.Windows.Forms.GroupBox groupBox40;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel45;
        private System.Windows.Forms.GroupBox groupBox41;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel46;
        private System.Windows.Forms.RadioButton radioGradusA;
        private System.Windows.Forms.RadioButton radioGradusB;
        private System.Windows.Forms.GroupBox groupBox42;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel47;
        private System.Windows.Forms.GroupBox groupBox43;
        private Controls.ComboBoxToolTip comboBoxGradusFrom;
        private System.Windows.Forms.GroupBox groupBox44;
        private Controls.ComboBoxToolTip comboBoxGradusTo;
        private ButtonClickView buttonGradusConvert;
        private System.Windows.Forms.GroupBox groupBox45;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel48;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel49;
        private System.Windows.Forms.RadioButton radioBynarInputXA;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel50;
        private System.Windows.Forms.RadioButton radioBynarInputY0;
        private System.Windows.Forms.RadioButton radioBynarInputYB;
        private System.Windows.Forms.RadioButton radioBynarInputYA;
        private System.Windows.Forms.RadioButton radioBynarInputX0;
        private System.Windows.Forms.RadioButton radioBynarInputXB;
        private System.Windows.Forms.GroupBox groupBox48;
        private System.Windows.Forms.GroupBox groupBox50;
        private Controls.ComboBoxToolTip comboBox2To;
        private System.Windows.Forms.GroupBox groupBox51;
        private Controls.ComboBoxToolTip comboBox1To;
        private System.Windows.Forms.GroupBox groupBox49;
        private Controls.ComboBoxToolTip comboBox2From;
        private Controls.ComboBoxToolTip comboBox1From;
        private System.Windows.Forms.GroupBox groupBox52;
        private Controls.ComboBoxToolTip comboBoxBynarCalculate;
        private System.Windows.Forms.GroupBox groupBox53;
        private Controls.ComboBoxToolTip comboBoxResultFrom;
        private System.Windows.Forms.GroupBox groupBox54;
        private Controls.ComboBoxToolTip comboBoxResultTo;
        private System.Windows.Forms.Button buttonBynarCalculate;
        private System.Windows.Forms.RadioButton radioBynarInputY1;
        private System.Windows.Forms.RadioButton radioBynarInputX1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.MenuStrip menuStrip4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem runPast2;
        private System.Windows.Forms.ToolStripMenuItem runNext2;
        private System.Windows.Forms.ToolStripMenuItem delete2;
        private System.Windows.Forms.ToolStripMenuItem add2;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem действиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem перейтиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runPast1;
        private System.Windows.Forms.ToolStripMenuItem runNext1;
        private System.Windows.Forms.ToolStripMenuItem delete1;
        private System.Windows.Forms.ToolStripMenuItem add1;
        private System.Windows.Forms.MenuStrip menuStrip5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem runPastResult;
        private System.Windows.Forms.ToolStripMenuItem runNextResult;
        private System.Windows.Forms.ToolStripMenuItem deleteResult;
        private System.Windows.Forms.ToolStripMenuItem addResult;
        private System.Windows.Forms.TextBox textBoxIndexes;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelInputB;
        private ButtonClickView buttonClickView22;
        private ButtonClickView buttonClickView23;
        private ButtonClickView buttonClickView24;
        private ButtonClickView buttonClickView25;
        private ButtonClickView buttonClickView26;
        private ButtonClickView buttonClickView27;
        private ButtonClickView buttonClickView28;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private ButtonClickView buttonClickView29;
        private ButtonClickView buttonClickView30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel51;
        private ButtonClickView buttonAbsBM;
        private ButtonClickView buttonAbsAM;
        private ButtonClickView buttonClickView31;
        private ButtonClickView buttonClickView32;
        private System.Windows.Forms.GroupBox groupBox55;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel52;
        private System.Windows.Forms.GroupBox groupBox56;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel53;
        private System.Windows.Forms.GroupBox groupBox57;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel54;
        private System.Windows.Forms.RadioButton radioButtonSpeedB;
        private System.Windows.Forms.RadioButton radioButtonSpeedA;
        private System.Windows.Forms.Button buttonSpeedConvert;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox58;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel55;
        private System.Windows.Forms.GroupBox groupBox59;
        private System.Windows.Forms.GroupBox groupBox60;
        private Controls.ComboBoxToolTip comboBoxSpeedTo;
        private Controls.ComboBoxToolTip comboBoxSpeedFrom;
        private System.Windows.Forms.GroupBox groupBox61;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel56;
        private System.Windows.Forms.GroupBox groupBox62;
        private System.Windows.Forms.GroupBox groupBox64;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel57;
        private System.Windows.Forms.GroupBox groupBox65;
        private Controls.ComboBoxToolTip comboBoxSpeedTimeTo;
        private System.Windows.Forms.GroupBox groupBox66;
        private Controls.ComboBoxToolTip comboBoxSpeedTimeFrom;
        private System.Windows.Forms.GroupBox groupBox63;
        private Controls.ComboBoxToolTip comboBoxSpeedLengthTo;
        private Controls.ComboBoxToolTip comboBoxSpeedLengthFrom;
        private ButtonClickView buttonClickView33;
        private ButtonClickView buttonMinesAbs;
        private ButtonClickView buttonMinesRet;
        private ButtonClickView buttonMinesX;
        private ButtonClickView buttonClickView34;
        private ButtonClickView buttonAbsRet;
        private ButtonClickView buttonMinesAbsRet;
        private System.Windows.Forms.GroupBox groupBox67;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel58;
        private System.Windows.Forms.GroupBox groupBox68;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel59;
        private System.Windows.Forms.RadioButton radioButtonSqrA;
        private System.Windows.Forms.RadioButton radioButtonSqrB;
        private System.Windows.Forms.Button buttonSqrConvert;
        private System.Windows.Forms.GroupBox groupBox69;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel60;
        private System.Windows.Forms.GroupBox groupBox70;
        private System.Windows.Forms.GroupBox groupBox71;
        private Controls.ComboBoxToolTip comboBoxSqrFrom;
        private System.Windows.Forms.GroupBox groupBox72;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel61;
        private System.Windows.Forms.GroupBox groupBox73;
        private Controls.ComboBoxToolTip comboBoxSqrLengthTo;
        private System.Windows.Forms.GroupBox groupBox74;
        private Controls.ComboBoxToolTip comboBoxSqrLengthFrom;
        private Controls.ComboBoxToolTip comboBoxSqrTo;
        private System.Windows.Forms.GroupBox groupBox75;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel62;
        private System.Windows.Forms.GroupBox groupBox76;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel63;
        private System.Windows.Forms.GroupBox groupBox77;
        private Controls.ComboBoxToolTip comboBoxKubLengthTo;
        private System.Windows.Forms.GroupBox groupBox78;
        private Controls.ComboBoxToolTip comboBoxKubLengthFrom;
        private System.Windows.Forms.GroupBox groupBox79;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel64;
        private System.Windows.Forms.RadioButton radioButtonKubA;
        private System.Windows.Forms.RadioButton radioButtonKubB;
        private System.Windows.Forms.Button buttonKubConvert;
        private System.Windows.Forms.GroupBox groupBox80;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel65;
        private System.Windows.Forms.GroupBox groupBox81;
        private Controls.ComboBoxToolTip comboBoxKubTo;
        private System.Windows.Forms.GroupBox groupBox82;
        private Controls.ComboBoxToolTip comboBoxKubFrom;
        private System.Windows.Forms.ToolStripMenuItem buttonInputMainForm;
        private ButtonClickView buttonClickView35;
        private ButtonClickView buttonClickView36;
        private ButtonClickView buttonClickView37;
        private Controls.MemoryCalculateControl memoryB;
        private Controls.MemoryCalculateControl memoryBuffer;
        private Controls.MemoryCalculateControl memoryA;
        private System.Windows.Forms.CheckBox checkBoxAutoOutput;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteB;
        private System.Windows.Forms.CheckBox checkBoxAutoWrite;
        private ButtonClickView buttonClickView38;
        private System.Windows.Forms.ToolStripMenuItem записатьВырToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAequalsB;
        private System.Windows.Forms.ToolStripMenuItem buttonBequalsA;
        private ButtonClickView buttonPlusBasketes;
        private ButtonClickView buttonMinesBasketes;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel66;
        private ButtonClickView buttonChangeBaskets;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel67;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel68;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel69;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel70;
        private ButtonClickView buttonChangeAbsBaskets;
        private ButtonClickView buttonPlusAbs;
        private ButtonClickView buttonPlusB1;
        private ButtonClickView buttonMines1B;
        private ButtonClickView buttonPersent1A;
        private ButtonClickView buttonPersent1B;
        private ButtonClickView button1AB;
        private ButtonClickView buttonAMinesBPersent;
        private ButtonClickView buttonAPlusBPersent;
        private ButtonClickView buttonBMinesAPersent;
        private ButtonClickView buttonBPlusAPersent;
        private ButtonClickView buttonMaxAB;
        private ButtonClickView buttonADivBPersent;
        private ButtonClickView buttonAMullBPersent;
        private ButtonClickView buttonBDivAPersent;
        private ButtonClickView buttonBMulAPersent;
        private ButtonClickView buttonMinAB;
        private ButtonClickView buttonAvgAB;
        private ButtonClickView buttonRAB;
        private ButtonClickView buttonChangeAB;
        private ButtonClickView buttonKatetSqrA;
        private ButtonClickView buttonKatetSqrB;
        private System.Windows.Forms.GroupBox groupBox83;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel71;
        private System.Windows.Forms.GroupBox groupBox84;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel72;
        private System.Windows.Forms.RadioButton radioButtonEqualsTriangleA;
        private System.Windows.Forms.RadioButton radioButtonEqualsTriangleB;
        private Controls.ComboBoxToolTip comboBoxEqualsTriangleFrom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private Controls.ComboBoxToolTip comboBoxEqualsTriangleTo;
        private System.Windows.Forms.Button buttonEqualsLenTriangleConvert;
        private ButtonClickView buttonClickView40;
        private ButtonClickView buttonClickView39;
        private System.Windows.Forms.Button buttonStepenAB;
        private System.Windows.Forms.Button buttonStepenBA;
        private System.Windows.Forms.Button buttonStepen1AB;
        private System.Windows.Forms.Button buttonStepen1BA;
        private System.Windows.Forms.ToolStripMenuItem buttonIntCalculator;
        private System.Windows.Forms.Button buttonIntB;
        private System.Windows.Forms.Button buttonIntA;
        private System.Windows.Forms.ToolStripMenuItem buttonInputMainFormReal;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteB1;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteBMain;
        private System.Windows.Forms.ToolStripMenuItem наПредыдущийЭкранToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteMain;
        private System.Windows.Forms.ToolStripMenuItem наПредыдущийЭкранToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonAequalsBMain;
        private System.Windows.Forms.ToolStripMenuItem наПредыдущийЭкранToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem buttonBequalsAMain;
        private System.Windows.Forms.GroupBox groupBox85;
        private ButtonClickView buttonClickView41;
        private ButtonClickView buttonClickView42;
        private System.Windows.Forms.Button buttonDrobB;
        private System.Windows.Forms.Button buttonDrobA;
        private ButtonClickView buttonClickView43;
        private ButtonClickView buttonClickView44;
        private ButtonClickView buttonClickView45;
        private ButtonClickView buttonClickView46;
        private System.Windows.Forms.Button buttonSgnB;
        private System.Windows.Forms.Button buttonSgnA;
        private System.Windows.Forms.ToolStripMenuItem buttonBFromClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteBToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteAToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonAequalsBToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonBequalsAToClipboard;
        private System.Windows.Forms.GroupBox groupBox86;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel73;
        private Controls.ComboBoxToolTip comboBoxFunc;
        private System.Windows.Forms.Button buttonAddFunc;
        private ButtonClickView buttonClickView47;
        private ButtonClickView buttonClickView48;
        private ButtonClickView buttonClickView49;
        private System.Windows.Forms.GroupBox groupBox87;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel74;
        private Controls.ComboBoxToolTip comboBoxMemory;
        private System.Windows.Forms.Button buttonSetMemory;
        private System.Windows.Forms.Timer timerMemory;
        private System.Windows.Forms.Button button1;
        private ButtonClickView buttonClickView50;
        private ButtonClickView buttonClickView51;
        private ButtonClickView buttonClickView52;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel75;
        private ButtonClickView buttonClickView53;
        private System.Windows.Forms.Button buttonAddFuncs;
    }
}