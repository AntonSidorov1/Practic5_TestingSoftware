﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using TableAIS.Controls;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class CalculatorKeyBord : Form
    {

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;
        public event Action SecondInput, SecondsSaved, RunBA, RunAB, WriteA, OutputWriteA, WriteB;

        public MemoryCalculateControl FewMemoryA, FewMemoryB, FewMemoryBuffer;

        public CalculatorKeyBord()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;

        }

        public TextBox TextA, TextB, TextBuffer;

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public  CalculatorKeyBord(Save save):this()
        {
            Save = save;
        }

        public CalculatorKeyBord(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            try
            {
                textBoxB.Text = TextB.Text;
            }
            catch(Exception ex)
            {

            }

            try
            {
                textBoxA.Text = TextA.Text;
            }
            catch(Exception ex)
            {

            }

            try
            {
                textBoxIndexes.Text = funcConverter.IndexesText;
            }
            catch
            {

            }

            try
            {
                textBoxBuffer.Text = TextBuffer.Text;
            }
            catch
            {

            }
            
            try
            {
                checkBoxAutoOutput.Checked = AutoOutput.Checked;
            }
            catch
            {

            }

            try
            {
                checkBoxAutoWrite.Checked = AutoWrite.Checked;
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
        CurcleConverter curcleConverter;
        ConverterList timeConverter, lengthConverter, gradusConverter, EqualsLenTriangle;
        BynarConverter funcConverter;
        ThirdConverter speedConverter;
        LengthBigConverter sqrConverter, kubConverter;

        public CheckBox AutoOutput, AutoWrite;

        private void Pattern_Load(object sender, EventArgs e)
        {
            memoryA.Few = FewMemoryA;
            memoryB.Few = FewMemoryB;
            memoryBuffer.Few = FewMemoryBuffer;

            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

            curcleConverter = new CurcleConverter();
            comboBoxCurcleFrom.Items.AddRange(curcleConverter.MetrsConvertsArray);
            comboBoxCurcleTo.Items.AddRange(curcleConverter.MetrsConvertsArray);

            comboBoxCurcleFrom.MySeclectedIndexChanged += ComboBoxCurcleFrom_MySeclectedIndexChanged;
            comboBoxCurcleTo.MySeclectedIndexChanged += ComboBoxCurcleTo_MySeclectedIndexChanged;

            comboBoxCurcleFrom.SelectedIndex = 0;
            comboBoxCurcleTo.SelectedIndex = 0;

            timeConverter = new TimeConverter();

            comboBoxTimeFrom.Items.AddRange(timeConverter.MetrsConvertsArray);
            comboBoxTimeTo.Items.AddRange(timeConverter.MetrsConvertsArray);
            
            comboBoxTimeFrom.SelectedIndex = 0;
            comboBoxTimeTo.SelectedIndex = 0;

            lengthConverter = new LengthConverter();

            comboBoxMetrFrom.Items.AddRange(lengthConverter.MetrsConvertsArray);
            comboBoxMetrTo.Items.AddRange(lengthConverter.MetrsConvertsArray);

            comboBoxMetrFrom.SelectedIndex = 0;
            comboBoxMetrTo.SelectedIndex = 0;

            gradusConverter = new GrardusesConverter();

            comboBoxGradusFrom.Items.AddRange(gradusConverter.MetrsConvertsArray);
            comboBoxGradusTo.Items.AddRange(gradusConverter.MetrsConvertsArray);

            comboBoxGradusFrom.SelectedIndex = 0;
            comboBoxGradusTo.SelectedIndex = 0;

            funcConverter = new FuncConverter();
            //funcConverter.AddResult();
            //funcConverter.AddOperand1();
            //funcConverter.AddOperand2();

            funcConverter.IndexOperand1 = 0;
            funcConverter.IndexOperand2 = 0;
            funcConverter.IndexConvertResult = 0;

            comboBoxBynarCalculate.Items.AddRange(funcConverter.BynarConverts.ToArray());
            comboBoxBynarCalculate.SelectedIndex = 0;

            comboBox1From.Items.AddRange(funcConverter.MetrsConvertsArray);
            comboBox1From.SelectedIndex = 0;

            comboBox2From.Items.AddRange(funcConverter.MetrsConvertsArray);
            comboBox2From.SelectedIndex = 0;

            comboBoxResultFrom.Items.AddRange(funcConverter.MetrsConvertsArray);
            comboBoxResultFrom.SelectedIndex = 0;

            comboBox1To.Items.AddRange(funcConverter.MetrsConvertsArray);
            comboBox1To.SelectedIndex = 0;

            comboBox2To.Items.AddRange(funcConverter.MetrsConvertsArray);
            comboBox2To.SelectedIndex = 0;

            comboBoxResultTo.Items.AddRange(funcConverter.MetrsConvertsArray);
            comboBoxResultTo.SelectedIndex = 0;
            //Width = Width + 1;

            speedConverter = new SpeedConvertes();
            comboBoxSpeedFrom.Items.AddRange(speedConverter.MetrsConvertsArray);
            comboBoxSpeedTo.Items.AddRange(speedConverter.MetrsConvertsArray);
            comboBoxSpeedFrom.SelectedIndex = 0;
            comboBoxSpeedTo.SelectedIndex = 0;

            comboBoxSpeedLengthFrom.Items.AddRange(speedConverter.UpArray);
            comboBoxSpeedLengthFrom.SelectedIndex = 0;
            comboBoxSpeedLengthTo.Items.AddRange(speedConverter.UpArray);
            comboBoxSpeedLengthTo.SelectedIndex = 0;

            comboBoxSpeedTimeFrom.Items.AddRange(speedConverter.DownArray);
            comboBoxSpeedTimeFrom.SelectedIndex = 0;
            comboBoxSpeedTimeTo.Items.AddRange(speedConverter.DownArray);
            comboBoxSpeedTimeTo.SelectedIndex = 0;

            sqrConverter = new SquareConverter();
            comboBoxSqrFrom.Items.AddRange(sqrConverter.MetrsConvertsArray);
            comboBoxSqrFrom.SelectedIndex = 0;
            comboBoxSqrTo.Items.AddRange(sqrConverter.MetrsConvertsArray);
            comboBoxSqrTo.SelectedIndex = 0;

            comboBoxSqrLengthFrom.Items.AddRange(sqrConverter.LengthList);
            comboBoxSqrLengthFrom.SelectedIndex = 0;
            comboBoxSqrLengthTo.Items.AddRange(sqrConverter.LengthList);
            comboBoxSqrLengthTo.SelectedIndex = 0;

            kubConverter = new VolumeConverter();
            comboBoxKubFrom.Items.AddRange(kubConverter.MetrsConvertsArray);
            comboBoxKubFrom.SelectedIndex = 0;
            comboBoxKubTo.Items.AddRange(kubConverter.MetrsConvertsArray);
            comboBoxKubTo.SelectedIndex = 0;

            comboBoxKubLengthFrom.Items.AddRange(kubConverter.LengthList);
            comboBoxKubLengthFrom.SelectedIndex = 0;
            comboBoxKubLengthTo.Items.AddRange(kubConverter.LengthList);
            comboBoxKubLengthTo.SelectedIndex = 0;

            EqualsLenTriangle = new EqualsTriangleConverter();
            comboBoxEqualsTriangleFrom.Items.AddRange(EqualsLenTriangle.MetrsConvertsArray);
            comboBoxEqualsTriangleTo.Items.AddRange(EqualsLenTriangle.MetrsConvertsArray);
            comboBoxEqualsTriangleFrom.SelectedIndex = 0;
            comboBoxEqualsTriangleTo.SelectedIndex = 0;

            comboBoxFunc.Items.AddRange(FuncList.Get().AllNamesArray);
            comboBoxFunc.SelectedIndex = 0;
            timerMemory.Start();

        }

        private void ComboBoxCurcleTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            curcleConverter.ToIndex = selectedIndex;
        }

        private void ComboBoxCurcleFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            curcleConverter.FromIndex = selectedIndex;
        }

        double GetInput(bool isB)
        {
            return isB ? B : A;
        }

        double GetInput(bool isB, bool isZero, bool isOne)
        {
            if(isZero)
            {
                return 0;
            }
            if(isOne)
            {
                return 1;
            }
            return GetInput(isB);
        }

        double ToRad(double value, bool isGrad)
        {
            return isGrad ? Rad(value) : value;
        }

        double ToGrad(double value, bool isRad)
        {
            return isRad ? Grad(value) : value;
        }

        private void buttonBackSpace_Click(object sender, EventArgs e)
        {
            try
            {
                string text = TextB.Text;
                int count = text.Length-1;
                text = text.Substring(0, count);
                TextB.Text = text;
            }
            catch(Exception ex)
            {

            }
        }

        private void buttonClearB_Click(object sender, EventArgs e)
        {
            try
            {
                TextB.Text = "";
            }
            catch(Exception ex)
            {

            }
        }

        private void buttonClearA_Click(object sender, EventArgs e)
        {
            try
            {
                TextA.Text = "";
            }
            catch (Exception ex)
            {

            }
        }

        private void buttonNumberB_ClickView(object sender, EventArgs e, Control control, string text)
        {
            try
            {
                TextB.Text += text;
            }
            catch
            {

            }
        }

        private void buttonAB_Click(object sender, EventArgs e)
        {
            RunAB?.Invoke();
        }

        private void buttonClickView21_Click(object sender, EventArgs e)
        {
            try
            {
                A += B;
            }
            catch
            {

            }
        }

        public static string FormatDouble(int round)
        {
            string format = "0";
            if(round > 0)
            {
                format += ".";
                for(int i = 0; i < round; i++)
                {
                    format += "#";
                }
            }
            return format;
        }

        public double A
        {
            get
            {
                try
                {
                    return double.Parse(TextA.Text);
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                
                TextA.Text = value.ToString();
            }
        }

        public double InputCalculate(string input)
        {
            return CalculatorString.InputCalculate(input, A, Buffer, GetHelpText?.Invoke()??"");
        }

        public event Func<string> GetHelpText;

        public double B
        {
            get
            {

                return InputCalculate(TextB.Text);
                return Convert.ToDouble(
                new DataTable().Compute(
                    TextB.Text.ToUpper().Replace("A", $"({A})").
                    Replace("PI", Math.PI.ToString()).
                    Replace("E", Math.E.ToString()).
                    Replace(',', '.')
                    , null).ToString());

            }
            set
            {
                TextB.Text = value.ToString(FormatDouble());
            }
        }

        public static string FormatDouble() => FormatDouble(100);

        private void buttonClickMinesB_Click(object sender, EventArgs e)
        {
            try
            {
                A -= B;
            }
            catch
            {

            }
        }

        private void buttonMinesA_Click(object sender, EventArgs e)
        {
            try
            {
                A = B - A;
            }
            catch
            {

            }
        }

        private void buttonMul_Click(object sender, EventArgs e)
        {
            try
            {
                A *= B;
            }
            catch
            {

            }
        }

        private void buttonDivB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                if(a!=0)
                A /= a;
            }
            catch
            {

            }
        }

        private void buttonDivA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                if(a!=0)
                A = B / a;
            }
            catch
            {

            }
        }

        private void buttonPowB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                double b = B;
                if (a == 0 && b <= 0)
                    return;
                A = Math.Pow(a, b);
            }
            catch
            {

            }
        }

        private void buttonPowA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                double b = A;
                if (a == 0 && b <= 0)
                    return;
                A = Math.Pow(a, b);
            }
            catch
            {

            }
        }

        private void buttonPow2_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(B, 2);
            }
            catch
            {

            }
        }

        private void buttonPow3_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(B, 3);
            }
            catch
            {

            }
        }

        private void buttonPowA2_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(A, 2);
            }
            catch
            {

            }
        }

        private void buttonPowA3_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(A, 3);
            }
            catch
            {

            }
        }

        private void buttonIncB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                a++;
                B = a;
            }
            catch
            {

            }
        }

        private void buttonDecB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                a--;
                B = a;
            }
            catch
            {

            }
        }

        private void buttonIncA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                a++;
                A = a;
            }
            catch
            {

            }
        }

        private void buttonDecA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                a--;
                A = a;
            }
            catch
            {

            }
        }

        private void buttonSet_Click(object sender, EventArgs e)
        {
            try
            {
                B = B;
            }
            catch
            {

            }
        }

        private void buttonPow2B_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(2, B);
            }
            catch
            {

            }
        }

        private void buttonPow2A_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(2, A);
            }
            catch
            {

            }
        }

        private void buttonMulB2_Click(object sender, EventArgs e)
        {
            try
            {
                A = B * 2;
            }
            catch
            {

            }
        }

        private void buttonMul2A_Click(object sender, EventArgs e)
        {
            try
            {
                A = A * 2;
            }
            catch
            {

            }
        }

        private void buttonSqrtB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                if (a >= 0)
                    A = Math.Sqrt(a);
                else
                    A = -Math.Sqrt(-a);
            }
            catch
            {

            }
        }

        private void buttonSqrtA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                if (a >= 0)
                    A = Math.Sqrt(a);
                else
                    A = -Math.Sqrt(-a);
            }
            catch
            {

            }
        }

        private void buttonSqrtAB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                double b = B;
                if (b == 0)
                {
                    return;
                }
                if (a == 0 && b < 0)
                    return;
                if (a >= 0)
                    A = Math.Pow(a, 1 / b);
                else
                    A = -Math.Pow(-a, 1 / b);
            }
            catch
            {

            }
        }

        private void buttonSqrtBA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                double b = A;
                if (b == 0)
                {
                    return;
                }
                if (a == 0 && b < 0)
                    return;
                if (a >= 0)
                    A = Math.Pow(a, 1 / b);
                else
                    A = -Math.Pow(-a, 1 / b);
            }
            catch
            {

            }
        }

        private void buttonMines_Click(object sender, EventArgs e)
        {
            try
            {
                B *= (-1);
            }
            catch
            {

            }
        }

        private void buttonB1_Click(object sender, EventArgs e)
        {
            try
            {
                A = B* (-1);
            }
            catch
            {

            }
        }

        private void buttonA1_Click(object sender, EventArgs e)
        {
            try
            {
                A *= (-1);
            }
            catch
            {

            }
        }

        private void buttonDiv2B_Click(object sender, EventArgs e)
        {
            try
            {
                A = B / 2;
            }
            catch
            {

            }
        }

        private void buttonMul2B_Click(object sender, EventArgs e)
        {
            try
            {
                A /= 2;
            }
            catch
            {

            }
        }

        private void buttonRetB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                if (a == 0)
                    return;
                A = 1 / a;
            }
            catch
            {

            }
        }

        private void buttonRetA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                if (a == 0)
                    return;
                A = 1 / a;
            }
            catch
            {

            }
        }

        private void buttonPowEB_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(Math.E, B);
            }
            catch
            {

            }
        }

        private void buttonClickView22_Click(object sender, EventArgs e)
        {

        }

        private void buttonPowEA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(Math.E, A);
            }
            catch
            {

            }
        }

        private void buttonLnB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                if(a> 0)
                    A = Math.Log(a);
            }
            catch
            {

            }
        }

        private void buttonLnA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                if (a > 0)
                    A = Math.Log(a);
            }
            catch
            {

            }
        }

        private void buttonLgB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                if (a > 0)
                    A = Math.Log10(a);
            }
            catch
            {

            }
        }

        private void buttonLgA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                if (a > 0)
                    A = Math.Log10(a);
            }
            catch
            {

            }
        }

        private void buttonAbsB_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Abs(B);
            }
            catch
            {

            }
        }

        private void buttonAbsA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Abs(A);
            }
            catch
            {

            }
        }

        private void buttonLogAB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                double b = B;
                if (a <= 0 || a == 1)
                    return;
                if (b <= 0)
                    return;
                A = Math.Log(b, a);
            }
            catch
            {

            }
        }

        private void buttonLogBA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                double b = A;
                if (a <= 0 || a == 1)
                    return;
                if (b <= 0)
                    return;
                A = Math.Log(b, a);
            }
            catch
            {

            }
        }

        private void buttonAbs_Click(object sender, EventArgs e)
        {
            try
            {
                B = Math.Abs(B);
            }
            catch
            {

            }
        }

        private void buttonRet_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                if (a != 0)
                    B = 1 / a;
            }
            catch
            {

            }
        }

        private void buttonDivX2_Click(object sender, EventArgs e)
        {
            try
            {
                B /= 2;
            }
            catch
            {

            }
        }

        private void buttonMulX2_Click(object sender, EventArgs e)
        {
            try
            {
                B *= 2;
            }
            catch
            {

            }
        }

        private void buttonOutputWrite_Click(object sender, EventArgs e)
        {
            OutputWriteA?.Invoke();
        }

        private void buttonPersent_Click(object sender, EventArgs e)
        {
            try
            {
                B /= 100;
            }
            catch
            {

            }
        }

        private void buttonPersentB_Click(object sender, EventArgs e)
        {
            try
            {
                A = B / 100;
            }
            catch
            {

            }
        }

        private void buttonPersentA_Click(object sender, EventArgs e)
        {
            try
            {
                A /= 100;
            }
            catch
            {

            }
        }

        private void buttonSqvSum_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(A + B, 2);
            }
            catch
            {

            }
        }

        private void buttonSqvSumB_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(A - B, 2);
            }
            catch
            {

            }
        }

        private void buttonSubA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(B - A, 2);
            }
            catch
            {

            }
        }

        private void buttonSumSqvs_Click(object sender, EventArgs e)
        {
            try
            {
                A=Math.Pow(A, 2)+Math.Pow(B, 2);
            }
            catch
            {

            }
        }

        private void buttonSubSqvsB_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(A, 2) - Math.Pow(B, 2);
            }
            catch
            {

            }
        }

        private void buttonSubSqvsA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(B, 2) - Math.Pow(A, 2);
            }
            catch
            {

            }
        }

        private void buttonKubSum_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(A + B, 3);
            }
            catch
            {

            }
        }

        private void buttonKubSubB_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(A - B, 3);
            }
            catch
            {

            }
        }

        private void buttonKubSubA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(B - A, 3);
            }
            catch
            {

            }
        }

        private void buttonSumKub_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(A, 3) + Math.Pow(B, 3);
            }
            catch
            {

            }
        }

        private void buttonSubKubB_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(A, 3) - Math.Pow(B, 3);
            }
            catch
            {

            }
        }

        private void buttonSubKubA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Pow(B, 3) - Math.Pow(A, 3);
            }
            catch
            {

            }
        }

        private void buttonBBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    BufferFew = B;
                }
                catch
                {
                    Buffer = B;
                }
            }
            catch
            {

            }
        }

        double Buffer
        {
            get
            {
                return double.Parse(textBoxBuffer.Text);
            }
            set
            {
                textBoxBuffer.Text = value.ToString();
            }
        }

        double BufferFew
        {
            get => double.Parse(TextBuffer.Text.Replace('.', ','));
            set => TextBuffer.Text = value.ToString();
        }

        private void buttonABuffer_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    BufferFew = A;
                }
                catch
                {
                    Buffer = A;
                }
            }
            catch
            {

            }
        }

        private void buttonBufferA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Buffer;
            }
            catch
            {

            }
        }

        private void buttonBufferB_Click(object sender, EventArgs e)
        {
            try
            {
                B = Buffer;
            }
            catch
            {

            }
        }

        private void buttonBufferClear_Click(object sender, EventArgs e)
        {
            try
            {
                TextBuffer.Clear();
            }
            catch
            {
                textBoxBuffer.Clear();
            }
        }

        private void panelBinarFunces_Scroll(object sender, ScrollEventArgs e)
        {
            try
            {
                ActiveControl = textBoxBuffer;
            }
            catch
            {

            }
        }

        private void buttonGipotenuze_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Sqrt(Math.Pow(A, 2) + Math.Pow(B, 2));
            }
            catch
            {

            }
        }

        private void buttonCatetB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Math.Pow(A, 2) - Math.Pow(B, 2);
                if (a >= 0)
                    A = Math.Sqrt(a);
                else
                    A = -Math.Sqrt(-a);
            }
            catch
            {

            }
        }

        private void buttonCatetA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Math.Pow(B, 2) - Math.Pow(A, 2);
                if (a >= 0)
                    A = Math.Sqrt(a);
                else
                    A = -Math.Sqrt(-a);
            }
            catch
            {

            }
        }

        private void buttonGipotenuzeA_Click(object sender, EventArgs e)
        {
            try
            {
                A = A * Math.Sqrt(2);
            }
            catch
            {

            }
        }

        private void buttonGipotenuzeB_Click(object sender, EventArgs e)
        {
            try
            {
                A = B * Math.Sqrt(2);
            }
            catch
            {

            }
        }

        private void buttonCatetSqrtA_Click(object sender, EventArgs e)
        {
            try
            {
                A = A / Math.Sqrt(2);
            }
            catch
            {

            }
        }

        private void buttonCatetSqrtB_Click(object sender, EventArgs e)
        {
            try
            {
                A = B / Math.Sqrt(2);
            }
            catch
            {

            }
        }

        private void buttonSqrTruangleCatets_Click(object sender, EventArgs e)
        {
            try
            {
                A = A * B / 2;
            }
            catch
            {

            }
        }

        private void buttonSqrTruangleCatetsA_Click(object sender, EventArgs e)
        {
            try
            {
                A = A * A / 2;
            }
            catch
            {

            }
        }

        private void buttonSqrTruangleCatetsB_Click(object sender, EventArgs e)
        {
            try
            {
                A = B * B / 2;
            }
            catch
            {

            }
        }

        private void buttonSqrTruangleA_Click(object sender, EventArgs e)
        {
            try
            {
                A = SqrTruangleA(A);
            }
            catch
            {

            }
        }

        double SqrTruangleA(double a)
        {
            return (a * a * Math.Sqrt(3)) / 4;
        }

        private void buttonSqrTruangleB_Click(object sender, EventArgs e)
        {
            try
            {
                A = SqrTruangleA(B);
            }
            catch
            {

            }
        }

        private void buttonRetSqrA_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                a *= 4;
                a /= Math.Sqrt(3);
                if(a>=0)
                    A = Math.Sqrt(a);
                else
                    A = -Math.Sqrt(-a);
            }
            catch
            {

            }
        }

        private void buttonRetSqrB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                a *= 4;
                a /= Math.Sqrt(3);
                if (a >= 0)
                    A = Math.Sqrt(a);
                else
                    A = -Math.Sqrt(-a);
            }
            catch
            {

            }
        }

        private void buttonTallA_Click(object sender, EventArgs e)
        {
            try
            {
                A = TallA(A);
            }
            catch
            {

            }
        }

        private void buttonTallB_Click(object sender, EventArgs e)
        {
            try
            {
                A = TallA(B);
            }
            catch
            {

            }
        }

        private void buttonRetTallA_Click(object sender, EventArgs e)
        {
            try
            {
                A /= Math.Cos(Math.PI / 6);
            }
            catch
            {

            }
        }

        double TallRad(double a, double rad)
        {
            rad /= 2;
            return a*Math.Cos(rad);
        }

        double TallGrad(double a, double grad)
        {
            return TallRad(a, Rad(grad));
        }

        double TallA(double a)
        {
            return TallGrad(a, 60);
        }

        private void buttonRetTallB_Click(object sender, EventArgs e)
        {
            try
            {
                A = B / Math.Cos(Math.PI / 6);
            }
            catch
            {

            }
        }

        private void buttonLenGradAB_Click(object sender, EventArgs e)
        {
            try
            {
                A = LenGrad(A, B);
            }
            catch
            {

            }
        }

        double LenGrad(double a, double grad)
        {
            return LenRad(a, grad * 2 * Math.PI / 360);
        }

        double LenRad(double a, double rad)
        {
            double c = 2*Math.Pow(a, 2)-2*a*a*Math.Cos(rad);
            if(c >= 0)
                return Math.Sqrt(c);
            else
                return -Math.Sqrt(-c);
        }

        double RadLen(double c, double rad)
        {
            c = Math.Pow(c, 2);
            double a = 2-Math.Cos(rad);
            a = c / a;
            if(a >= 0)
                return Math.Sqrt(a);
            else
                return -Math.Sqrt(-a);
        }

        double GradLen(double c, double grad)
        {
            return RadLen(c, grad * 2 * Math.PI / 360);
        }

        private void buttonGradLenAB_Click(object sender, EventArgs e)
        {
            try
            {
                A = GradLen(A, B);
            }
            catch
            {

            }
        }

        private void buttonSqrGradAB_Click(object sender, EventArgs e)
        {
            try
            {
                A = SqrGrad(A, B);
            }
            catch
            {

            }
        }

        double Rad(double grad)
        {
            return grad * Math.PI / 180;
        }

        double Grad(double rad)
        {
            return rad *180/(Math.PI);
        }

        double SqrGrad(double a, double grad)
        {
            return SqrRad(a, Rad(grad));
        }

        double SqrRad(double a, double rad)
        {
            return a * a * Math.Sin(rad) / 2;
        }

        private void buttonTallGradAB_Click(object sender, EventArgs e)
        {
            try
            {
                A = TallGrad(A, B);
            }
            catch
            {

            }
        }

        private void buttonLenRadAB_Click(object sender, EventArgs e)
        {
            try
            {
                A = LenRad(A, B);
            }
            catch
            {

            }
        }

        private void buttonRadLenAB_Click(object sender, EventArgs e)
        {
            try
            {
                A = RadLen(A, B);
            }
            catch
            {

            }
        }

        private void buttonSqrRadAB_Click(object sender, EventArgs e)
        {
            try
            {
                A = SqrRad(A, B);
            }
            catch
            {

            }
        }

        private void buttonTallRadAB_Click(object sender, EventArgs e)
        {
            try
            {
                A = TallRad(A, B);
            }
            catch
            {

            }
        }

        private void buttonLenGradBA_Click(object sender, EventArgs e)
        {
            try
            {
                A = LenGrad(B, A);
            }
            catch
            {

            }
        }

        private void buttonGradLenBA_Click(object sender, EventArgs e)
        {
            try
            {
                A = GradLen(B, A);
            }
            catch
            {

            }
        }

        private void buttonSqrGradBA_Click(object sender, EventArgs e)
        {
            try
            {
                A = SqrGrad(B, A);
            }
            catch
            {

            }
        }

        private void buttonTallGradBA_Click(object sender, EventArgs e)
        {
            try
            {
                A = TallGrad(B, A);
            }
            catch
            {

            }
        }

        private void buttonLenRadBA_Click(object sender, EventArgs e)
        {
            try
            {
                A = LenRad(B, A);
            }
            catch
            {

            }
        }

        private void buttonRadLenBA_Click(object sender, EventArgs e)
        {
            try
            {
                A = RadLen(B, A);
            }
            catch
            {

            }
        }

        private void buttonSqrRadBA_Click(object sender, EventArgs e)
        {
            try
            {
                A = SqrRad(B, A);
            }
            catch
            {

            }
        }

        private void buttonTallRadBA_Click(object sender, EventArgs e)
        {
            try
            {
                A = TallRad(B, A);
            }
            catch
            {

            }
        }

        private void buttonRadA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Rad(A);
            }
            catch
            {

            }
        }

        private void buttonRadB_Click(object sender, EventArgs e)
        {
            try
            {
                A = Rad(B);
            }
            catch
            {

            }
        }

        private void buttonGradA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Grad(A);
            }
            catch
            {

            }
        }

        private void buttonGradB_Click(object sender, EventArgs e)
        {
            try
            {
                A = Grad(B);
            }
            catch
            {

            }
        }

        private void comboBoxCurcleFrom_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                
            }
            catch
            {

            }
        }

        private void comboBoxCurcleTo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void buttonCurcleCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioButtonCurcleB.Checked);
                a = curcleConverter.Convert(a);
                A = a;
            }
            catch
            {

            }
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {

        }

        double ToRadInput(bool isB, bool isGrad)
        {
            return ToRad(GetInput(isB), isGrad);
        }

        double ToGradInput(bool isB, bool isGrad)
        {
            return ToGrad(GetInput(isB), !isGrad);
        }

        double Sin(double value)
        {
            return SinGrad(value);
        }

        public double SinGrad(double gradus)
        {
            double value = gradus;
            double result = value;

            if (Math.Abs(result) > 90)
            {
                double result1 = Math.Abs(result);
                result1 /= result;
                double result2 = Math.Abs(result);
                double result3 = result2 / 180;
                int result4 = (int)Math.Truncate(result3);
                result2 -= 180 * result4;
                result2 *= Math.Pow(-1, result4);
                result2 *= result1;
                result = result2;
            }

            if (result == 90)
            {
                return 1;
            }
            if (result == -90)
            {
                return -1;
            }
            if (result == 0)
            {
                return 0;
            }


            value = result * 2 * Math.PI / 360;
            return Math.Sin(value);
        }


        public static double CosGrad(double gradus)
        {
            double value = gradus;
            double result = Math.Abs(value);

            if (result > 360)
            {
                double result1 = result / 360;
                int result2 = (int)Math.Truncate(result1);
                result -= 360 * result2;

            }

            if(result > 180)
            {
                result -= 180;
                result = Math.Abs(result);
                result -= 180;

            }

            result = Math.Abs(result);

            if (result == 0)
            {
                return 1;
            }
            if (result == 180)
            {
                return -1;
            }
            if (result == 90)
            {
                return 0;
            }

            value = result * 2 * Math.PI / 360;
            return Math.Cos(value);
        }


        double Cos(double value)
        {
            return CosGrad(value);
        }

        double TryRound(double value)
        {
            double a = Math.Round(value, 15);
            if (a == 0)
                return 0;
            else
                return value;
        }

        private void buttonSin_Click(object sender, EventArgs e)
        {
            try
            {
                double a = ToGradInput(radioSinB.Checked, radioSinGrad.Checked);
                A = Sin(a);
            }
            catch
            {

            }
        }

        private void buttonCos_Click(object sender, EventArgs e)
        {
            try
            {
                double a = ToGradInput(radioSinB.Checked, radioSinGrad.Checked);
                A = Cos(a);
            }
            catch
            {

            }
        }

        private void buttonTg_Click(object sender, EventArgs e)
        {
            try
            {
                double a = ToGradInput(radioSinB.Checked, radioSinGrad.Checked);
                double cos = Cos(a);
                if (cos == 0)
                    return;
                A = Sin(a) / cos;
            }
            catch
            {

            }
        }

        private void buttonCtg_Click(object sender, EventArgs e)
        {
            try
            {
                double a = ToGradInput(radioSinB.Checked, radioSinGrad.Checked);
                double cos = Sin(a);
                if (cos == 0)
                    return;
                A = Cos(a) / cos;
            }
            catch
            {

            }
        }

        private void buttonCosec_Click(object sender, EventArgs e)
        {
            try
            {
                double a = ToRadInput(radioSinB.Checked, radioSinGrad.Checked);
                double cos = Sin(a);
                if (cos == 0)
                    return;
                A = 1 / cos;
            }
            catch
            {

            }
        }

        private void buttonSec_Click(object sender, EventArgs e)
        {
            try
            {
                double a = ToRadInput(radioSinB.Checked, radioSinGrad.Checked);
                double cos = Cos(a);
                if (cos == 0)
                    return;
                A = 1 / cos;
            }
            catch
            {

            }
        }

        double Arcsin(double value, bool isGrad)
        {
            bool isRad = !isGrad;
            double a = value;
            if ((a > -1 && a < 0) || (a > 0 && a < 1))
                return ToGrad(Math.Asin(a), isGrad);
            else if (a == 0)
                return 0;
            else if (a == 1)
                return ToRad(90, isRad);
            else if (a == -1)
                return ToRad(-90, isRad);
            throw new ArgumentException();
        }

        private void buttonArcSin_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioASinB.Checked);
                A = Arcsin(a, radioASinGrad.Checked);

            }
            catch
            {

            }
        }

        double Arccos(double value, bool isGrad)
        {
            bool isRad = !isGrad;
            double a = value;
            if ((a > -1 && a < 0) || (a > 0 && a < 1))
                return ToGrad(Math.Acos(a), isGrad);
            else if (a == 0)
                return ToRad(90, isRad); 
            else if (a == 1)
                return ToRad(0, isRad);
            else if (a == -1)
                return ToRad(180, isRad);
            throw new ArgumentException();
        }

        private void buttonAcos_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioASinB.Checked);
                A = Arccos(a, radioASinGrad.Checked);

            }
            catch
            {

            }
        }

        double Arctg(double value, bool isGrad)
        {
            double a = value;
            bool isRad = isGrad;
            a = Math.Atan(a);
            return ToGrad(a, isGrad);
        }

        double Arcctg(double value, bool isGrad)
        {
            double a = value;
            bool isRad = !isGrad;
            if (a == 0)
                return ToRad(90, isRad);
            else
                a = Math.Atan(1 / a);
            return ToGrad(a, isGrad);
        }

        private void buttonAtg_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioASinB.Checked);
                A = Arctg(a, radioASinGrad.Checked);

            }
            catch
            {

            }
        }

        private void buttonAcosec_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioASinB.Checked);
                if (a == 0)
                    return;
                A = Arcsin(1/a, radioASinGrad.Checked);

            }
            catch
            {

            }
        }

        private void buttonAsec_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioASinB.Checked);
                if (a == 0)
                    return;
                A = Arccos(1 / a, radioASinGrad.Checked);

            }
            catch
            {

            }
        }

        private void buttonActg_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioASinB.Checked);
                A = Arcctg( a, radioASinGrad.Checked);

            }
            catch
            {

            }
        }

        private void buttonTimeCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioButtonTimeB.Checked);
                a = timeConverter.Convert(a);
                A = a;
            }
            catch
            {

            }
        }

        private void comboBoxTimeFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                timeConverter.FromIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBoxTimeTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                timeConverter.ToIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void buttonLengthConvert_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioButtonMetrB.Checked);
                a = lengthConverter.Convert(a);
                A = a;
            }
            catch
            {

            }
        }

        private void comboBoxGradusFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                gradusConverter.FromIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBoxGradusTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                gradusConverter.ToIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void buttonGradusConvert_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioGradusB.Checked);
                a = gradusConverter.Convert(a);
                A = a;
            }
            catch
            {

            }
        }

        private void buttonBynarCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double x = GetInput(radioBynarInputXB.Checked, radioBynarInputY0.Checked, radioBynarInputX1.Checked);
                double y = GetInput(radioBynarInputYB.Checked, radioBynarInputY0.Checked, radioBynarInputY1.Checked);
                double z = funcConverter.CalculateResult(x, y);
                A = z;
            }
            catch
            {

            }
        }

        private void comboBoxBynarCalculate_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                funcConverter.BynarIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBoxResultFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                funcConverter.FromIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBoxResultTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                funcConverter.ToIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBox1From_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                funcConverter.GetOperand1().FromIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBox2From_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                funcConverter.GetOperand2().FromIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBox1To_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                funcConverter.GetOperand1().ToIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBox2To_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                funcConverter.GetOperand2().ToIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void runPast1_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.IndexOperand1Mines();
                comboBox1To.SelectedIndex = funcConverter.ToIndex1;
                comboBox1From.SelectedIndex = funcConverter.FromIndex1;
            }
            catch
            {

            }
        }

        private void runNext1_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.IndexOperand1Plus();
                comboBox1To.SelectedIndex = funcConverter.ToIndex1;
                comboBox1From.SelectedIndex = funcConverter.FromIndex1;
            }
            catch
            {

            }
        }

        private void delete1_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.DeleteOperand1();
                comboBox1To.SelectedIndex = funcConverter.ToIndex1;
                comboBox1From.SelectedIndex = funcConverter.FromIndex1;
            }
            catch
            {

            }
        }

        private void add1_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.AddOperand1();
                comboBox1To.SelectedIndex = funcConverter.ToIndex1;
                comboBox1From.SelectedIndex = funcConverter.FromIndex1;
            }
            catch
            {

            }
        }

        private void runPast2_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.IndexOperand2Mines();
                comboBox2To.SelectedIndex = funcConverter.ToIndex2;
                comboBox2From.SelectedIndex = funcConverter.FromIndex2;
            }
            catch
            {

            }
        }

        private void runNext2_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.IndexOperand2Plus();
                comboBox2To.SelectedIndex = funcConverter.ToIndex2;
                comboBox2From.SelectedIndex = funcConverter.FromIndex2;
            }
            catch
            {

            }
        }

        private void delete2_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.DeleteOperand2();
                comboBox2To.SelectedIndex = funcConverter.ToIndex2;
                comboBox2From.SelectedIndex = funcConverter.FromIndex2;
            }
            catch
            {

            }
        }

        private void add2_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.AddOperand2();
                comboBox2To.SelectedIndex = funcConverter.ToIndex2;
                comboBox2From.SelectedIndex = funcConverter.FromIndex2;
            }
            catch
            {

            }
        }

        private void runPastResult_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.IndexResultMines();
                comboBoxResultFrom.SelectedIndex = funcConverter.FromIndex;
                comboBoxResultTo.SelectedIndex = funcConverter.ToIndex;
            }
            catch
            {

            }
        }

        private void runNextResult_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.IndexResultPlus();
                comboBoxResultFrom.SelectedIndex = funcConverter.FromIndex;
                comboBoxResultTo.SelectedIndex = funcConverter.ToIndex;
            }
            catch
            {

            }
        }

        private void deleteResult_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.DeleteResult();
                comboBoxResultFrom.SelectedIndex = funcConverter.FromIndex;
                comboBoxResultTo.SelectedIndex = funcConverter.ToIndex;
            }
            catch
            {

            }
        }

        private void addResult_Click(object sender, EventArgs e)
        {
            try
            {
                funcConverter.AddResult();
                comboBoxResultFrom.SelectedIndex = funcConverter.FromIndex;
                comboBoxResultTo.SelectedIndex = funcConverter.ToIndex;
            }
            catch
            {

            }
        }

        private void buttonAbsBM_Click(object sender, EventArgs e)
        {
            try
            {
                A = -Math.Abs(B);
            }
            catch
            {

            }
        }

        private void buttonAbsAM_Click(object sender, EventArgs e)
        {
            try
            {
                A = -Math.Abs(A);
            }
            catch
            {

            }
        }

        private void flowLayoutPanelInputB_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                FlowLayoutPanel thisPanel = sender as FlowLayoutPanel;
                int with = thisPanel.Width;
                Control.ControlCollection controls = thisPanel.Controls;
                int count = controls.Count;
                Thread thread = new Thread(() =>
                {
                    for(int i = 0; i < count;i++)
                    {
                        try
                        {
                            thisPanel.BeginInvoke(new Action(() =>
                            {
                                try
                                {
                                    controls[i].Width = with - 35;
                                }
                                catch
                                {

                                }
                            }
                            ));
                        }
                        catch
                        {

                        }
                    }
                });
                //thread.Start();

                
                foreach (Control control in controls)
                {
                    control.Width = with - 35;
                }
                
            }
            catch
            {

            }
        }

        private void buttonSpeedConvert_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioButtonSpeedB.Checked);
                A = speedConverter.Convert(a);
            }
            catch
            {

            }
        }

        private void comboBoxSpeedFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                speedConverter.FromIndex = selectedIndex;
            }
            catch { }
        }

        private void comboBoxSpeedTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                speedConverter.ToIndex = selectedIndex;
            }
            catch { }
        }

        private void comboBoxSpeedLengthFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                speedConverter.FromUp = selectedIndex;
            }
            catch { }
        }

        private void comboBoxSpeedLengthTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                speedConverter.ToUp = selectedIndex;
            }
            catch { }
        }

        private void comboBoxSpeedTimeFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                speedConverter.FromDown = selectedIndex;
            }
            catch { }
        }

        private void comboBoxSpeedTimeTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                speedConverter.ToDown = selectedIndex;
            }
            catch { }
        }

        private void buttonMinesAbs_Click(object sender, EventArgs e)
        {
            try
            {
                B = -Math.Abs(B);
            }
            catch
            {

            }
        }

        private void buttonMinesRet_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                if (a != 0)
                    B = -1 / a;
            }
            catch
            {

            }
        }

        private void buttonAbsRet_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                if (a != 0)
                    B = 1 / Math.Abs(a);
            }
            catch
            {

            }
        }

        private void buttonMinesAbsRet_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                if (a != 0)
                    B = -1 / Math.Abs(a);
            }
            catch
            {

            }
        }

        private void buttonSqrConvert_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioButtonSqrB.Checked);
                A = sqrConverter.Convert(a);
            }
            catch
            {

            }
        }

        private void comboBoxSqrFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                sqrConverter.FromIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBoxSqrTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                sqrConverter.ToIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBoxSqrLengthFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                sqrConverter.LengthFromIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void buttonKubConvert_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioButtonKubB.Checked);
                A = kubConverter.Convert(a);
            }
            catch
            {

            }
        }

        private void comboBoxKubFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                kubConverter.FromIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBoxKubTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                kubConverter.ToIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBoxKubLengthFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                kubConverter.LengthFromIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void checkBoxAutoOutput_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                AutoOutput.Checked = (sender as CheckBox).Checked;
            }
            catch { }
        }

        private void buttonAequalsB_Click(object sender, EventArgs e)
        {
            try
            {
                AequalsB?.Invoke(sender, e);
            }
            catch { }
        }

        public event EventHandler AequalsB, BequalsA, AequalsBMain, BequalsAMain;

        /// <summary>
        /// Возвращает, находится ли весь текст в скобках
        /// </summary>
        /// <param name="text"></param>
        /// <param name="countBaskets"></param>
        /// <returns></returns>
        public static bool HaveBaskets(string text)
        {
            text = text.Trim();
            int countBaskets = 0;
            bool have = false; 
            bool have1 = false;
            int count = text.Length;
            if(count < 3)
            {
                return false;
            }
            int last = count -1;

            for(int i = 0; i < count; i++)
            {
                char sign = text[i];
                if(sign == '(')
                {
                    countBaskets++;
                }
                else if (sign == ')')
                {
                    countBaskets--;
                }
                if(((countBaskets == 0 && i < last)||countBaskets<0) && !have1)
                {
                    have1 = true;
                }
            }
            if(!have1)
            {
                have = countBaskets == 0;
            }

            return have;
        }

        public static string DropBaskets(string text)
        {
            text = text.Trim();
            text = ChangeBaskets(text);
            if (HaveBaskets(text))
            {

                text = text.Trim();
                int length = text.Length - 2;
                text = text.Substring(1, length);
                text = text.Trim();

            }
            return text;
        }

        public static string ChangeBaskets(string text)
        {
            return MyCalculate.ReplaceToFullFuncsCodeInteractive(text);
            bool have = true;
            int countBaskets = 0;
            while(have)
            {
                text = text.Trim();
                int count = text.Length;
                int last = count - 1;
                have = false;

                for (int i = 0; i < count; i++)
                {
                    char c = text[i];
                    if (c == '(')
                    {
                        countBaskets++;
                    }
                    else if (c == ')')
                    {
                        countBaskets--;
                    }
                    if(countBaskets < 0)
                    {
                        countBaskets = 0;
                        have = true;
                        text = "(" + text;
                        break;
                    }
                }
            }
            while(countBaskets > 0)
            {
                text += ")";
                countBaskets--;
            }
            return text.Trim();
        }


        private void buttonPlusBasketes_Click(object sender, EventArgs e)
        {
            try
            {
                string text = TextB.Text;

                text = text.Trim();
                text = ChangeBaskets(text);
                text = $"({text})";
                TextB.Text = text ;
            }
            catch { }
        }

        private void buttonMinesBasketes_Click(object sender, EventArgs e)
        {
            try
            {
                string text = TextB.Text;

                text = DropBaskets(text);
                text = text.Trim();
                TextB.Text = text;

            }
            catch { }
        }

        private void buttonClickView1_Click(object sender, EventArgs e)
        {

        }

        private void buttonNumberB_Click(object sender, EventArgs e)
        {

        }

        private void buttonChangeBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                TextB.Text = ChangeBaskets(TextB.Text);
            }
            catch { }
        }

        public string ChangeAbsBaskets(string text)
        {
            string result = "";
            text = "(" + text + ")";
            

            bool have = true;
            LastListInt abs = new LastListInt();
            while(have)
            {
                int countBaskets = 0;
                abs.Clear();
                have = false;
                text = ChangeBaskets(text);
                int count = text.Length;
                int last = count;
                --last;
                for(int i = 0; i < count; i++)
                {
                    char c = text[i];
                    try
                    {
                        countBaskets = abs.GetLast();
                    }
                    catch { }
                    if(c ==  '(')
                    {
                        countBaskets++;
                    }
                    else if(c == ')')
                    {
                        countBaskets--;
                    }
                    else if(c == '|')
                    {
                        if (countBaskets > 0 || abs.Count < 1)
                        {
                            countBaskets = abs.Add();
                        }
                        else
                        {
                            try
                            {
                                abs.RemoveLast();
                            }
                            catch
                            {
                                text = text.Insert(1, "|");
                                abs.Clear();
                                have = true;
                                break;
                            }
                        }
                    }
                    
                    if(countBaskets < 0 && abs.Count > 0)
                    {
                        if(abs.Count > 0)
                        {
                            text = text.Insert(i, "|");
                        }
                        else
                        {
                            text = "(" + text;
                        }
                        abs.Clear();
                        have = true; 
                        break;
                    }
                    else
                    {
                        try
                        {
                            abs.SetLast(countBaskets);
                        }
                        catch { 
                            
                        }
                    }

                }
            }

            return DropBaskets(text.Trim()).Trim();
        }

        public string DropAbsBaskets(string text)
        {
            text = ChangeAbsBaskets(text);
            int count = text.Length;
            int length = count - 2;
            if(HaveAbsBaskets(text))
                text = text.Substring(1, length);
            return text;
        }

        public bool HaveAbsBaskets(string text)
        {
            text = ChangeAbsBaskets(text);
            if(text.Length < 3)
                return false;
            try
            {
                //text = "(" + text + ")";


                bool have = true;
                LastListInt abs = new LastListInt();

                int countBaskets = 0;
                abs.Clear();
                have = false;
                text = ChangeBaskets(text);
                int count = text.Length;
                int last = count;
                --last;
                for (int i = 0; i < count; i++)
                {
                    char c = text[i];
                    try
                    {
                        countBaskets = abs.GetLast();
                    }
                    catch { }
                    if (c == '(')
                    {
                        countBaskets++;
                    }
                    else if (c == ')')
                    {
                        countBaskets--;
                    }
                    else if (c == '|')
                    {
                        if (countBaskets > 0 || abs.Count < 1)
                        {
                            countBaskets = abs.Add();
                        }
                        else
                        {
                            try
                            {
                                abs.RemoveLast();
                                if (abs.Count < 1 && i < last)
                                    throw new Exception();
                                else if (abs.Count < 1 && i >= last)
                                    return true;
                            }
                            catch (Exception e)
                            {
                                throw e;
                            }
                        }
                    }


                    try
                    {
                        abs.SetLast(countBaskets);
                    }
                    catch
                    {

                    }

                }
                throw new Exception();
            }
            catch
            {
                return false;
            }
        }


        private void buttonChangeAbsBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                TextB.Text = ChangeAbsBaskets(TextB.Text);
            }
            catch
            { }
        }

        private void buttonPlusAbs_Click(object sender, EventArgs e)
        {
            try
            {
                string text = TextB.Text;

                text = text.Trim();

                text = ChangeAbsBaskets(text);
                if (!HaveAbsBaskets(text))
                    text = $"|({text})|";
                else
                {
                    text = DropAbsBaskets(text);
                }
                TextB.Text = text;
            }
            catch { }
        }

        private void buttonPlusB1_ClickView(object sender, EventArgs e, Control control, string text)
        {
            try
            {
                double a = B;
                A = ++a;
            }
            catch
            {

            }
        }

        private void buttonMines1B_ClickView(object sender, EventArgs e, Control control, string text)
        {
            try
            {
                double a = B;
                A = --a;
            }
            catch
            {

            }
        }

        private void buttonPersent1A_ClickView(object sender, EventArgs e, Control control, string text)
        {
            try
            {
                double a = A;
                A = a/100;
            }
            catch
            {

            }
        }

        private void buttonPersent1B_ClickView(object sender, EventArgs e, Control control, string text)
        {
            try
            {
                double a = B;
                A = a / 100;
            }
            catch
            {

            }
        }

        private void button1AB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = B;
                A = a;
            }
            catch
            {

            }
        }

        public double APlusBPersent(double a, double b)
        {
            return a + a * b / 100;
        }

        public double AMulBPersent(double a, double b)
        {
            return a * b / 100;
        }

        public double AMinesBPersent(double a, double b)
        {
            return a - a * b / 100;
        }

        public double ADivBPersent(double a, double b)
        {
            if (b == 0)
                throw new Exception();
            return  a / (b / 100);
        }



        private void buttonAMinesBPersent_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = AMinesBPersent(A, B);
            }
            catch
            {

            }
        }

        private void buttonAPlusBPersent_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = APlusBPersent(A, B);
            }
            catch
            {

            }
        }

        private void buttonBMinesAPersent_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = AMinesBPersent(B, A);
            }
            catch
            {

            }
        }

        private void buttonBPlusAPersent_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = APlusBPersent(B, A);
            }
            catch
            {

            }
        }

        private void buttonMaxAB_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = Math.Max(B, A);
            }
            catch
            {

            }
        }

        private void buttonMinAB_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = Math.Min(B, A);
            }
            catch
            {

            }
        }

        private void buttonAvgAB_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = (A + B) / 2;
            }
            catch
            {

            }
        }

        private void buttonRAB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                double b = B;
                double max = Math.Max(a, b);
                double min = Math.Min(a, b);
                A = Math.Abs(max-min);
            }
            catch
            {

            }
        }

        private void buttonAMullBPersent_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = AMulBPersent(A, B);
            }
            catch
            {

            }
        }

        private void buttonBMulAPersent_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = AMulBPersent(B, A);
            }
            catch
            {

            }
        }

        private void buttonADivBPersent_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = ADivBPersent(A, B);
            }
            catch
            {

            }
        }

        private void buttonBDivAPersent_Click(object sender, EventArgs e)
        {
            try
            {
                //double a = A;

                A = ADivBPersent(B, A);
            }
            catch
            {

            }
        }

        private void buttonChangeAB_Click(object sender, EventArgs e)
        {
            try
            {
                double a = A;
                double b= B;
                B = a;
                A = b;
            }
            catch
            {

            }
        }

        public double KatetSqr(double sqr, double katet)
        {
            if (katet == 0)
                throw new Exception();
            return 2 * sqr / katet;
        }

        private void buttonKatetSqrA_Click(object sender, EventArgs e)
        {
            try
            {
                A = KatetSqr(A, B);
            }
            catch { }
        }

        private void comboBoxEqualsTriangle_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                EqualsLenTriangle.FromIndex = selectedIndex;
            }
            catch { }
        }

        private void comboBoxEqualsTriangleTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                EqualsLenTriangle.ToIndex = selectedIndex;
            }
            catch { }
        }

        private void buttonEqualsLenTriangleConvert_Click(object sender, EventArgs e)
        {
            try
            {
                double a = GetInput(radioButtonEqualsTriangleB.Checked);
                a = EqualsLenTriangle.Convert(a);
                A = a;
            }
            catch { }
        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonStepenAB_Click(object sender, EventArgs e)
        {
            try
            {
                A = CalculatorFunc.Stepen(A, B);
            }
            catch
            {

            }
        }

        private void buttonStepenBA_Click(object sender, EventArgs e)
        {
            try
            {
                A = CalculatorFunc.Stepen(B, A);
            }
            catch
            {

            }
        }

        private void buttonIntB_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Truncate(B);
            }
            catch { }
        }

        private void buttonIntA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Math.Truncate(A);
            }
            catch { }
        }

        private void buttonInputMainFormReal_Click(object sender, EventArgs e)
        {
            try
            {
                InputMainFormReal?.Invoke(sender, e);
            }
            catch { }
        }

        private void buttonWriteBMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(textBoxB.Text);
            }
            catch { }
        }

        private void buttonWriteMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(textBoxA.Text);
            }
            catch { }
        }

        private void buttonDrobA_Click(object sender, EventArgs e)
        {
            try
            {
                A = Drobe(A);
            }
            catch { }
        }

        public static double Drobe(double b)
        {
            try
            {
                string text = b.ToString();
                string[] parts = text.Split(new char[] {'.', ','});
                return double.Parse("0," + parts[1])*HyperbolicFunctions.Sgn(b);
            }
            catch
            {
                return 0;
            }
        }

        private void buttonDrobB_Click(object sender, EventArgs e)
        {
            try
            {
                A = Drobe(B);
            }
            catch { }
        }

        private void buttonSgnA_Click(object sender, EventArgs e)
        {
            try
            {
                A = HyperbolicFunctions.Sgn(A);
            }
            catch { }
        }

        private void buttonSgnB_Click(object sender, EventArgs e)
        {
            try
            {
                A = HyperbolicFunctions.Sgn(B);
            }
            catch { }
        }

        private void buttonBFromClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                TextB.Text = Clipboard.GetText();
            }
            catch { }
        }

        private void buttonWriteBToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(TextB.Text);
            }
            catch { }
        }

        private void buttonWriteAToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                TextA.Text = Clipboard.GetText();
            }
            catch { }
        }

        private void buttonAequalsBToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(TextA.Text + "=" + TextB.Text);
            }
            catch { }
        }

        private void buttonBequalsAToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(TextB.Text + "=" + TextA.Text);
            }
            catch { }
        }

        private void buttonAddFunc_Click(object sender, EventArgs e)
        {
            try
            {
                TextB.Text += comboBoxFunc.Text;
            }
            catch { }
        }

        private void buttonSetMemory_Click(object sender, EventArgs e)
        {
            try
            {
                TextB.Text += comboBoxMemory.Text;
            }
            catch { }
        }

        private void timerMemory_Tick(object sender, EventArgs e)
        {
            int index = comboBoxMemory.SelectedIndex;
            try
            {
                comboBoxMemory.Items.Clear();
                comboBoxMemory.Items.AddRange(CalculatorString.History.VariablesArray);
            }
            catch { }

            int count = comboBoxMemory.Items.Count;

            if(index < 0 || index >= count)
            {
                index = 0;
            }

            try
            {
                comboBoxMemory.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonAddFuncs_Click(object sender, EventArgs e)
        {
            FeachersList form = new FeachersList();
            form.InputFunc += Form_InputFunc;

            form.Show();
        }

        private void Form_InputFunc(string obj)
        {
            try
            {
                TextB.Text += obj;
            }
            catch { }
        }

        private void buttonBequalsAMain_Click(object sender, EventArgs e)
        {
            try
            {
                BequalsAMain?.Invoke(sender, e);
            }
            catch { }
        }

        private void buttonAequalsBMain_Click(object sender, EventArgs e)
        {
            try
            {
                AequalsBMain?.Invoke(sender, e);
            }
            catch { }
        }

        private void buttonKatetSqrB_Click(object sender, EventArgs e)
        {
            try
            {
                A = KatetSqr(B, A);
            }
            catch { }
        }

        private void buttonBequalsA_Click(object sender, EventArgs e)
        {
            try
            {
                BequalsA?.Invoke(sender, e);
            }
            catch { }
        }

        private void checkBoxAutoWrite_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                AutoWrite.Checked = (sender as CheckBox).Checked;
            }
            catch { }
        }

        private void buttonWriteB_Click(object sender, EventArgs e)
        {
            try
            {
                WriteB?.Invoke();
            }
            catch { }
        }

        private void comboBoxKubLengthTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                kubConverter.LengthToIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void buttonInputMainForm_Click(object sender, EventArgs e)
        {
            try
            {
                InputMainForm?.Invoke(sender, e);
            }
            catch
            {

            }
        }

        public event EventHandler InputMainForm, InputMainFormReal;

        private void comboBoxSqrLengthTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                sqrConverter.LengthToIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBoxMetrFrom_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                lengthConverter.FromIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void comboBoxMetrTo_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            try
            {
                lengthConverter.ToIndex = selectedIndex;
            }
            catch
            {

            }
        }

        private void buttonAB_Click_1(object sender, EventArgs e)
        {
            try
            {
                A = B;
            }
            catch
            {

            }
        }

        private void buttonWrite_Click(object sender, EventArgs e)
        {
            WriteA?.Invoke();
        }

        private void buttonSecondsSaved_Click(object sender, EventArgs e)
        {
            SecondsSaved?.Invoke();
        }

        private void buttonBA_Click(object sender, EventArgs e)
        {
            RunBA?.Invoke();
        }

        private void buttonClickSecondMetr_Click(object sender, EventArgs e)
        {
            SecondInput?.Invoke();
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
    }
}
