﻿namespace TableAIS
{
    partial class CalculatorMemory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CalculatorMemory));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.listBoxCalculatesList = new System.Windows.Forms.ListBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonClearList = new System.Windows.Forms.Button();
            this.buttonUpdateList = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxBuffer = new TableAIS.TextBoxWithTitle();
            this.textBoxA = new TableAIS.TextBoxWithTitle();
            this.textBoxB = new TableAIS.TextBoxWithTitle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.flowResize2 = new TableAIS.FlowResize();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonInputBuffer = new TableAIS.ButtonClickView();
            this.buttonInputA = new TableAIS.ButtonClickView();
            this.buttonInputB = new TableAIS.ButtonClickView();
            this.buttonInputFormule = new TableAIS.ButtonClickView();
            this.textBoxValue = new TableAIS.TextBoxWithTitle();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.flowResize1 = new TableAIS.FlowResize();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonAddBuffer = new TableAIS.ButtonClickView();
            this.buttonAddA = new TableAIS.ButtonClickView();
            this.buttonAddB = new TableAIS.ButtonClickView();
            this.buttonAddFormule = new TableAIS.ButtonClickView();
            this.timerList = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.записатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWrite = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteMain = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.flowResize2.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.flowResize1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(530, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(223, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(782, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(778, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(413, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 504);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(782, 23);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.listBoxCalculatesList, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 1, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(782, 415);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // listBoxCalculatesList
            // 
            this.listBoxCalculatesList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxCalculatesList.FormattingEnabled = true;
            this.listBoxCalculatesList.ItemHeight = 21;
            this.listBoxCalculatesList.Location = new System.Drawing.Point(10, 10);
            this.listBoxCalculatesList.Margin = new System.Windows.Forms.Padding(10);
            this.listBoxCalculatesList.Name = "listBoxCalculatesList";
            this.tableLayoutPanel2.SetRowSpan(this.listBoxCalculatesList, 2);
            this.listBoxCalculatesList.Size = new System.Drawing.Size(371, 295);
            this.listBoxCalculatesList.TabIndex = 1;
            this.listBoxCalculatesList.Click += new System.EventHandler(this.listBoxCalculatesList_SelectedIndexChanged);
            this.listBoxCalculatesList.SelectedIndexChanged += new System.EventHandler(this.listBoxCalculatesList_SelectedIndexChanged);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.buttonClearList, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonUpdateList, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(391, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(391, 50);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // buttonClearList
            // 
            this.buttonClearList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearList.Location = new System.Drawing.Point(205, 10);
            this.buttonClearList.Margin = new System.Windows.Forms.Padding(10);
            this.buttonClearList.Name = "buttonClearList";
            this.buttonClearList.Size = new System.Drawing.Size(176, 30);
            this.buttonClearList.TabIndex = 1;
            this.buttonClearList.Text = "Очистить список";
            this.buttonClearList.UseVisualStyleBackColor = true;
            this.buttonClearList.Click += new System.EventHandler(this.buttonClearList_Click);
            // 
            // buttonUpdateList
            // 
            this.buttonUpdateList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUpdateList.Location = new System.Drawing.Point(10, 10);
            this.buttonUpdateList.Margin = new System.Windows.Forms.Padding(10);
            this.buttonUpdateList.Name = "buttonUpdateList";
            this.buttonUpdateList.Size = new System.Drawing.Size(175, 30);
            this.buttonUpdateList.TabIndex = 0;
            this.buttonUpdateList.Text = "Обновить список";
            this.buttonUpdateList.UseVisualStyleBackColor = true;
            this.buttonUpdateList.Click += new System.EventHandler(this.buttonUpdateList_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel2.SetColumnSpan(this.tableLayoutPanel4, 2);
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.Controls.Add(this.textBoxBuffer, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBoxA, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBoxB, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 318);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(776, 94);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // textBoxBuffer
            // 
            this.textBoxBuffer.ClearingByReadonly = true;
            this.textBoxBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxBuffer.Location = new System.Drawing.Point(521, 5);
            this.textBoxBuffer.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxBuffer.MultiLine = false;
            this.textBoxBuffer.Name = "textBoxBuffer";
            this.textBoxBuffer.NoReadOnly = false;
            this.textBoxBuffer.ReadOnly = true;
            this.textBoxBuffer.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxBuffer.Size = new System.Drawing.Size(250, 84);
            this.textBoxBuffer.TabIndex = 2;
            this.textBoxBuffer.Title = "Буфер";
            this.textBoxBuffer.Value = "";
            this.textBoxBuffer.ValueBackColor = System.Drawing.Color.White;
            this.textBoxBuffer.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxBuffer.VisibleOK = false;
            this.textBoxBuffer.Cleared += new TableAIS.TextValueChanged(this.textBoxBuffer_Cleared);
            // 
            // textBoxA
            // 
            this.textBoxA.ClearingByReadonly = true;
            this.textBoxA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxA.Location = new System.Drawing.Point(263, 5);
            this.textBoxA.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxA.MultiLine = false;
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.NoReadOnly = false;
            this.textBoxA.ReadOnly = true;
            this.textBoxA.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxA.Size = new System.Drawing.Size(248, 84);
            this.textBoxA.TabIndex = 1;
            this.textBoxA.Title = "A";
            this.textBoxA.Value = "";
            this.textBoxA.ValueBackColor = System.Drawing.Color.White;
            this.textBoxA.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxA.VisibleOK = false;
            this.textBoxA.Cleared += new TableAIS.TextValueChanged(this.textBoxA_Cleared);
            // 
            // textBoxB
            // 
            this.textBoxB.ClearingByReadonly = true;
            this.textBoxB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxB.Location = new System.Drawing.Point(4, 4);
            this.textBoxB.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxB.MultiLine = false;
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.NoReadOnly = false;
            this.textBoxB.ReadOnly = true;
            this.textBoxB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxB.Size = new System.Drawing.Size(250, 86);
            this.textBoxB.TabIndex = 0;
            this.textBoxB.Title = "B";
            this.textBoxB.Value = "";
            this.textBoxB.ValueBackColor = System.Drawing.Color.White;
            this.textBoxB.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxB.VisibleOK = false;
            this.textBoxB.Cleared += new TableAIS.TextValueChanged(this.textBoxB_Cleared);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel5);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(394, 53);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(385, 259);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Значение";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.groupBox3, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.textBoxValue, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonDelete, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.groupBox2, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.menuStrip1, 1, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 3;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(379, 226);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.flowResize2);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(192, 131);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(184, 92);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ввести в";
            // 
            // flowResize2
            // 
            this.flowResize2.AutoScroll = true;
            this.flowResize2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize2.Controls.Add(this.tableLayoutPanel7);
            this.flowResize2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize2.Location = new System.Drawing.Point(3, 30);
            this.flowResize2.Margin = new System.Windows.Forms.Padding(0);
            this.flowResize2.Name = "flowResize2";
            this.flowResize2.Size = new System.Drawing.Size(178, 59);
            this.flowResize2.TabIndex = 1;
            this.flowResize2.WithDelta = 35;
            this.flowResize2.WrapContents = false;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.buttonInputBuffer, 0, 3);
            this.tableLayoutPanel7.Controls.Add(this.buttonInputA, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.buttonInputB, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.buttonInputFormule, 0, 0);
            this.tableLayoutPanel7.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 4;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(143, 120);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // buttonInputBuffer
            // 
            this.buttonInputBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonInputBuffer.Location = new System.Drawing.Point(3, 93);
            this.buttonInputBuffer.Name = "buttonInputBuffer";
            this.buttonInputBuffer.Size = new System.Drawing.Size(137, 24);
            this.buttonInputBuffer.TabIndex = 3;
            this.buttonInputBuffer.Text = "Буфер (число)";
            this.buttonInputBuffer.UseVisualStyleBackColor = true;
            this.buttonInputBuffer.Click += new System.EventHandler(this.buttonInputBuffer_Click);
            // 
            // buttonInputA
            // 
            this.buttonInputA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonInputA.Location = new System.Drawing.Point(3, 63);
            this.buttonInputA.Name = "buttonInputA";
            this.buttonInputA.Size = new System.Drawing.Size(137, 24);
            this.buttonInputA.TabIndex = 2;
            this.buttonInputA.Text = "A (число)";
            this.buttonInputA.UseVisualStyleBackColor = true;
            this.buttonInputA.Click += new System.EventHandler(this.buttonInputA_Click);
            // 
            // buttonInputB
            // 
            this.buttonInputB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonInputB.Location = new System.Drawing.Point(3, 33);
            this.buttonInputB.Name = "buttonInputB";
            this.buttonInputB.Size = new System.Drawing.Size(137, 24);
            this.buttonInputB.TabIndex = 1;
            this.buttonInputB.Text = "B (число)";
            this.buttonInputB.UseVisualStyleBackColor = true;
            this.buttonInputB.Click += new System.EventHandler(this.buttonInputB_Click);
            // 
            // buttonInputFormule
            // 
            this.buttonInputFormule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonInputFormule.Location = new System.Drawing.Point(3, 3);
            this.buttonInputFormule.Name = "buttonInputFormule";
            this.buttonInputFormule.Size = new System.Drawing.Size(137, 24);
            this.buttonInputFormule.TabIndex = 0;
            this.buttonInputFormule.Text = "B (формулу)";
            this.buttonInputFormule.UseVisualStyleBackColor = true;
            this.buttonInputFormule.Click += new System.EventHandler(this.buttonInputFormule_Click);
            // 
            // textBoxValue
            // 
            this.textBoxValue.ClearingByReadonly = true;
            this.tableLayoutPanel5.SetColumnSpan(this.textBoxValue, 2);
            this.textBoxValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxValue.Location = new System.Drawing.Point(4, 4);
            this.textBoxValue.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxValue.MultiLine = true;
            this.textBoxValue.Name = "textBoxValue";
            this.textBoxValue.NoReadOnly = false;
            this.textBoxValue.ReadOnly = true;
            this.textBoxValue.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxValue.Size = new System.Drawing.Size(371, 90);
            this.textBoxValue.TabIndex = 0;
            this.textBoxValue.Title = "Значение";
            this.textBoxValue.Value = "";
            this.textBoxValue.ValueBackColor = System.Drawing.Color.White;
            this.textBoxValue.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxValue.VisibleOK = false;
            // 
            // buttonDelete
            // 
            this.buttonDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDelete.Location = new System.Drawing.Point(3, 101);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(183, 24);
            this.buttonDelete.TabIndex = 1;
            this.buttonDelete.Text = "Удалить";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.flowResize1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 131);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(183, 92);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Добавить из";
            // 
            // flowResize1
            // 
            this.flowResize1.AutoScroll = true;
            this.flowResize1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize1.Controls.Add(this.tableLayoutPanel6);
            this.flowResize1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize1.Location = new System.Drawing.Point(3, 30);
            this.flowResize1.Margin = new System.Windows.Forms.Padding(0);
            this.flowResize1.Name = "flowResize1";
            this.flowResize1.Size = new System.Drawing.Size(177, 59);
            this.flowResize1.TabIndex = 0;
            this.flowResize1.WithDelta = 35;
            this.flowResize1.WrapContents = false;
            this.flowResize1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowResize1_Paint);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.buttonAddBuffer, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.buttonAddA, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.buttonAddB, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonAddFormule, 0, 0);
            this.tableLayoutPanel6.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 4;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(142, 120);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // buttonAddBuffer
            // 
            this.buttonAddBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAddBuffer.Location = new System.Drawing.Point(3, 93);
            this.buttonAddBuffer.Name = "buttonAddBuffer";
            this.buttonAddBuffer.Size = new System.Drawing.Size(136, 24);
            this.buttonAddBuffer.TabIndex = 3;
            this.buttonAddBuffer.Text = "Буфера (число)";
            this.buttonAddBuffer.UseVisualStyleBackColor = true;
            this.buttonAddBuffer.Click += new System.EventHandler(this.buttonAddBuffer_Click);
            // 
            // buttonAddA
            // 
            this.buttonAddA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAddA.Location = new System.Drawing.Point(3, 63);
            this.buttonAddA.Name = "buttonAddA";
            this.buttonAddA.Size = new System.Drawing.Size(136, 24);
            this.buttonAddA.TabIndex = 2;
            this.buttonAddA.Text = "A (число)";
            this.buttonAddA.UseVisualStyleBackColor = true;
            this.buttonAddA.Click += new System.EventHandler(this.buttonAddA_Click);
            // 
            // buttonAddB
            // 
            this.buttonAddB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAddB.Location = new System.Drawing.Point(3, 33);
            this.buttonAddB.Name = "buttonAddB";
            this.buttonAddB.Size = new System.Drawing.Size(136, 24);
            this.buttonAddB.TabIndex = 1;
            this.buttonAddB.Text = "B (число)";
            this.buttonAddB.UseVisualStyleBackColor = true;
            this.buttonAddB.Click += new System.EventHandler(this.buttonAddB_Click);
            // 
            // buttonAddFormule
            // 
            this.buttonAddFormule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAddFormule.Location = new System.Drawing.Point(3, 3);
            this.buttonAddFormule.Name = "buttonAddFormule";
            this.buttonAddFormule.Size = new System.Drawing.Size(136, 24);
            this.buttonAddFormule.TabIndex = 0;
            this.buttonAddFormule.Text = "B (формулу)";
            this.buttonAddFormule.UseVisualStyleBackColor = true;
            this.buttonAddFormule.Click += new System.EventHandler(this.buttonAddFormule_Click);
            // 
            // timerList
            // 
            this.timerList.Enabled = true;
            this.timerList.Interval = 2500;
            this.timerList.Tick += new System.EventHandler(this.timerList_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.записатьToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(189, 98);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(190, 28);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // записатьToolStripMenuItem
            // 
            this.записатьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonWrite,
            this.buttonWriteMain});
            this.записатьToolStripMenuItem.Name = "записатьToolStripMenuItem";
            this.записатьToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.записатьToolStripMenuItem.Text = "Записать";
            // 
            // buttonWrite
            // 
            this.buttonWrite.Name = "buttonWrite";
            this.buttonWrite.Size = new System.Drawing.Size(404, 26);
            this.buttonWrite.Text = "На предыдущий экран перед калькулятором";
            this.buttonWrite.Click += new System.EventHandler(this.buttonWrite_Click);
            // 
            // buttonWriteMain
            // 
            this.buttonWriteMain.Name = "buttonWriteMain";
            this.buttonWriteMain.Size = new System.Drawing.Size(404, 26);
            this.buttonWriteMain.Text = "На главный экран";
            this.buttonWriteMain.Click += new System.EventHandler(this.buttonWriteMain_Click);
            // 
            // CalculatorMemory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(782, 553);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "CalculatorMemory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Память калькулятора";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.flowResize2.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.flowResize1.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ListBox listBoxCalculatesList;
        private System.Windows.Forms.Timer timerList;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button buttonClearList;
        private System.Windows.Forms.Button buttonUpdateList;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private TextBoxWithTitle textBoxB;
        private TextBoxWithTitle textBoxBuffer;
        private TextBoxWithTitle textBoxA;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private TextBoxWithTitle textBoxValue;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private FlowResize flowResize2;
        private FlowResize flowResize1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private ButtonClickView buttonAddBuffer;
        private ButtonClickView buttonAddA;
        private ButtonClickView buttonAddB;
        private ButtonClickView buttonAddFormule;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private ButtonClickView buttonInputBuffer;
        private ButtonClickView buttonInputA;
        private ButtonClickView buttonInputB;
        private ButtonClickView buttonInputFormule;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem записатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonWrite;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteMain;
    }
}