﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class CalculatorMemory : Form
    {
        
        public CalculatorMemoryList History
        {
            get => HistoryFew; set => HistoryFew = value;
        }

        public static CalculatorMemoryList HistoryFew
        {
            get => CalculatorString.History;
            set => CalculatorString.History = value;
        }



        public TextBox TextNumberA;
        public TextBox TextNumberB;
        public TextBox TextBuffer;

        public String FormuleB
        {
            get => TextNumberB.Text;
            set => TextNumberB.Text = value;
        }

        public string TextA
        {
            get => A.ToString();
            set
            {
                try
                {
                    A = Calculate(value);
                }
                catch { }
            }
        }

        public double A
        {
            get
            {
                try
                {
                    return double.Parse(TextNumberA.Text);
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                TextNumberA.Text = value.ToString();
            }
        }

        public double Calculate(string formule)
        {
            return CalculatorString.InputCalculate(formule, A, Buffer, GetHelpText()??"");
        }

        public event Func<string> GetHelpText;


        public string TextB
        {
            get => B.ToString();
            set
            {
                try
                {
                    B = Calculate(value);
                }
                catch { }
            }
        }


        public double B
        {
            get
            {
                try
                {
                    return Calculate(FormuleB);
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                FormuleB = value.ToString();
            }
        }

        public string BufferText
        {
            get => Buffer.ToString();
            set
            {
                try
                {
                    Buffer = Calculate(value);
                }
                catch { }
            }
        }

        public double Buffer
        {
            get
            {
                try
                {
                    return double.Parse(TextBuffer.Text);
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                TextBuffer.Text = value.ToString();
            }
        }

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public CalculatorMemory(CalculatorMemoryList history) : this()
        {
            History = history;
        }

        public CalculatorMemory()
        {
            if(History == null)
                History = new CalculatorMemoryList();
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public CalculatorMemory(Save save):this()
        {
            Save = save;
        }

        public CalculatorMemory(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            try
            {
                textBoxA.Value = TextNumberA.Text;
            }
            catch
            {

            }

            try
            {
                textBoxB.Value = TextNumberB.Text;
            }
            catch
            {

            }

            try
            {
                textBoxBuffer.Value = TextBuffer.Text;
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

            try
            {
                UpdateList();
            }
            catch
            {

            }
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void timerList_Tick(object sender, EventArgs e)
        {

            UpdateList();
        }

        public int SecondIndex
        {
            get => listBoxCalculatesList.SelectedIndex;
            set
            {

                int index = value;
                if (index < 0 && listBoxCalculatesList.Items.Count > 0)
                {
                    SecondIndex = 0;
                    return;
                }
                try
                {
                    index = Math.Min(index, listBoxCalculatesList.Items.Count - 1);
                    listBoxCalculatesList.SelectedIndex = index;
                }
                catch (Exception ex)
                {

                }
            }
        }


        public void UpdateList()
        {

            try
            {
                int index = SecondIndex;
                listBoxCalculatesList.Items.Clear();
                listBoxCalculatesList.Items.AddRange(History.ToArray());
                SecondIndex = index;
            }
            catch (Exception ex)
            {

            }

            ValueOutput();
        }

        public string ValueByHistory => History[SecondIndex].Formule;


        private void listBoxCalculatesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                textBoxValue.Value = ValueByHistory;
            }
            catch
            {

            }
        }

        public void ValueOutput()
        {

        }

        private void buttonUpdateList_Click(object sender, EventArgs e)
        {
            UpdateList();
        }

        private void buttonClearList_Click(object sender, EventArgs e)
        {
            History.Clear();
            UpdateList();
        }

        private void textBoxB_Cleared(Control control, EventArgs e, string value)
        {
            try
            {
                TextNumberB.Text = value;
            }
            catch
            {

            }
        }

        private void textBoxA_Cleared(Control control, EventArgs e, string value)
        {
            try
            {
                TextNumberA.Text = value;
            }
            catch
            {

            }
        }

        private void textBoxBuffer_Cleared(Control control, EventArgs e, string value)
        {
            try
            {
                TextBuffer.Text = value;
            }
            catch
            {

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonAddFormule_Click(object sender, EventArgs e)
        {
            try
            {
                History.Add(FormuleB);
                UpdateList();
            }
            catch
            {

            }
        }

        private void buttonAddB_Click(object sender, EventArgs e)
        {
            try
            {
                History.Add(TextB);
                UpdateList();
            }
            catch
            {

            }
        }

        private void buttonAddA_Click(object sender, EventArgs e)
        {
            try
            {
                History.Add(TextA);
                UpdateList();
            }
            catch
            {

            }
        }

        private void flowResize1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonAddBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                History.Add(BufferText);
                UpdateList();
            }
            catch
            {

            }
        }

        private void buttonInputFormule_Click(object sender, EventArgs e)
        {
            try
            {
                FormuleB = ValueByHistory;
                UpdateList();
            }
            catch { }
        }

        private void buttonInputB_Click(object sender, EventArgs e)
        {
            try
            {
                TextB = ValueByHistory;
                UpdateList();
            }
            catch { }
        }

        private void buttonInputA_Click(object sender, EventArgs e)
        {
            try
            {
                TextA = ValueByHistory;
                UpdateList();
            }
            catch { }
        }

        private void buttonInputBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                BufferText = ValueByHistory;
                UpdateList();
            }
            catch { }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            try
            {
                History.RemoveAt(SecondIndex);
                UpdateList();
            }
            catch
            {

            }
        }

        private void buttonWrite_Click(object sender, EventArgs e)
        {
            try
            {
                MetrOutput1?.Invoke(ValueByHistory, Save);
            }
            catch { }
        }

        private void buttonWriteMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(ValueByHistory);
            }
            catch { }
        }
    }
}
