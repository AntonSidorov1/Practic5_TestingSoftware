﻿namespace TableAIS
{
    partial class CalculatorString
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CalculatorString));
            this.button1 = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.timerView = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonScrollMin = new System.Windows.Forms.Button();
            this.buttonScrollUp1 = new System.Windows.Forms.Button();
            this.buttonScrollMax = new System.Windows.Forms.Button();
            this.buttonScrollUp = new System.Windows.Forms.Button();
            this.buttonScrollDown1 = new System.Windows.Forms.Button();
            this.buttonScrollDown = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.flowResizeMain = new TableAIS.FlowResize();
            this.checkBoxFlagsView = new System.Windows.Forms.CheckBox();
            this.checkBoxViewFx = new System.Windows.Forms.CheckBox();
            this.groupBoxImportFx = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxFc = new TableAIS.TextBoxWithTitle();
            this.textBoxViewFx = new TableAIS.TextBoxWithTitle();
            this.textBoxFunctionConst = new TableAIS.TextBoxWithTitle();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonComputeFc = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.buttonAddFunctionToC = new System.Windows.Forms.Button();
            this.buttonCalcC = new System.Windows.Forms.Button();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonC = new System.Windows.Forms.RadioButton();
            this.radioButtonFc = new System.Windows.Forms.RadioButton();
            this.groupBoxRunC = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonExportC = new System.Windows.Forms.RadioButton();
            this.radioButtonImportC = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxAutoFc = new System.Windows.Forms.CheckBox();
            this.buttonCalcFc = new System.Windows.Forms.Button();
            this.checkBoxEnterFc = new System.Windows.Forms.CheckBox();
            this.menuStrip8 = new System.Windows.Forms.MenuStrip();
            this.исправитьCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddBasketsC = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropBasketsC = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonChangeBasketsC = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropVariableC = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonComputeC = new System.Windows.Forms.ToolStripMenuItem();
            this.cИлиFCВыборОбменСToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вводВыводToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCA = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBufferC = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHelpC = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClipBoardC = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLastWindowC = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonMainWindowC = new System.Windows.Forms.ToolStripMenuItem();
            this.checkBoxFxOutput = new System.Windows.Forms.CheckBox();
            this.checkBoxShowFile = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanelFile = new System.Windows.Forms.TableLayoutPanel();
            this.buttonSaveFile = new System.Windows.Forms.Button();
            this.buttonLoadFile = new System.Windows.Forms.Button();
            this.menuStrip7 = new System.Windows.Forms.MenuStrip();
            this.обменСГлавнымЭкраномToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripJsonDropVariants = new System.Windows.Forms.ToolStripComboBox();
            this.buttonJsonLastWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonJsonMainWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonJsonClipBoard = new System.Windows.Forms.ToolStripMenuItem();
            this.checkBoxInputBView = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanelInputBView = new System.Windows.Forms.TableLayoutPanel();
            this.button7 = new System.Windows.Forms.Button();
            this.buttonKeyBord = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.buttonMenuCalculator = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTimer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonGetSavedSeconds = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromMainForm = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonIntCalculator = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromMainFormReal = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBFromClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.button2 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.checkBoxCorrectView = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanelCorrectView = new System.Windows.Forms.TableLayoutPanel();
            this.buttonRunGrafics = new System.Windows.Forms.Button();
            this.menuStrip5 = new System.Windows.Forms.MenuStrip();
            this.исправитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonChangeFunc1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonChengeBaskets = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddBaskets = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropBaskets = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonInputFeacher = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTestChangeBaskets = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenConsts1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenConsts = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenVariables = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenVariablesAnsConsts = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTestCalc = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonInteractiveEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.другаяОбработкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToVectorCalculator = new System.Windows.Forms.ToolStripMenuItem();
            this.простойКалькуляторToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonListCalculator = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripInputFunc = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip6 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.button9 = new System.Windows.Forms.Button();
            this.buttonClearAll = new System.Windows.Forms.Button();
            this.buttonMemory = new System.Windows.Forms.Button();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonClearOutput = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxInput = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxOutput = new System.Windows.Forms.TextBox();
            this.buttonClearInput = new System.Windows.Forms.Button();
            this.memoryB = new TableAIS.Controls.MemoryCalculateControl();
            this.memoryA = new TableAIS.Controls.MemoryCalculateControl();
            this.buttonCopyBCalcB = new System.Windows.Forms.Button();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonPastCalcBFromBCalcB = new System.Windows.Forms.Button();
            this.buttonPastBFromBCalcB = new System.Windows.Forms.Button();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonCalcA = new System.Windows.Forms.Button();
            this.checkBoxAutoCalcA = new System.Windows.Forms.CheckBox();
            this.buttonCalcATest = new System.Windows.Forms.Button();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonCalcB = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.checkBoxPanelCalcView = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanelCalcView = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxAutoOutput = new System.Windows.Forms.CheckBox();
            this.buttonOutput = new System.Windows.Forms.Button();
            this.checkBoxEnter = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.checkBoxPanelRoundView = new System.Windows.Forms.CheckBox();
            this.tableLayoutViewFx = new System.Windows.Forms.TableLayoutPanel();
            this.buttonRound = new System.Windows.Forms.Button();
            this.numericRound = new System.Windows.Forms.NumericUpDown();
            this.checkBoxAutoRound = new System.Windows.Forms.CheckBox();
            this.checkBoxPanelWriteView = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanelWriteView = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxAutoWrite = new System.Windows.Forms.CheckBox();
            this.buttonSet = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.записатьAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWrite = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteAToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.button6 = new System.Windows.Forms.Button();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.вывестиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.наПредыдущийЭкранToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.наГлавныйЭкранToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вБуферОбменаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.наПредыдущийЭкранToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.наГлавныйЭкранToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.вБуферОбменаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.равенствоВыраженийToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAequalsB1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAequalsB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAequalsBMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAequalsBToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBequalsA1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBequalsA = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBequalsAMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBequalsAToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonCalculateB = new System.Windows.Forms.Button();
            this.menuStrip4 = new System.Windows.Forms.MenuStrip();
            this.записатьBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteBMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteBToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.TextBuffer = new TableAIS.TextBoxWithTitle();
            this.memoryBuffer = new TableAIS.Controls.MemoryCalculateControl();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonABuffer = new System.Windows.Forms.Button();
            this.buttonBufferB = new System.Windows.Forms.Button();
            this.buttonBBuffer = new System.Windows.Forms.Button();
            this.buttonBufferA = new System.Windows.Forms.Button();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonRunHelpToBufer = new System.Windows.Forms.Button();
            this.buttonRunBuferToHelp = new System.Windows.Forms.Button();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxHelp = new TableAIS.TextBoxWithTitle();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonRunHelpToB = new System.Windows.Forms.Button();
            this.buttonRunBToHelp = new System.Windows.Forms.Button();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonRunAToHelp = new System.Windows.Forms.Button();
            this.buttonRunHelpToA = new System.Windows.Forms.Button();
            this.buttonRunHelpToB1 = new System.Windows.Forms.Button();
            this.buttonRunB1ToHelp = new System.Windows.Forms.Button();
            this.memoryHelp = new TableAIS.Controls.MemoryCalculateControl();
            this.buttonCalcHelp = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.labelInfoCount = new System.Windows.Forms.Label();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.button10 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.saveFileCalculator = new System.Windows.Forms.SaveFileDialog();
            this.openFileCalculator = new System.Windows.Forms.OpenFileDialog();
            this.timerViewFx = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.flowResizeMain.SuspendLayout();
            this.groupBoxImportFx.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.groupBoxRunC.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.menuStrip8.SuspendLayout();
            this.tableLayoutPanelFile.SuspendLayout();
            this.menuStrip7.SuspendLayout();
            this.tableLayoutPanelInputBView.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tableLayoutPanelCorrectView.SuspendLayout();
            this.menuStrip5.SuspendLayout();
            this.menuStrip6.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanelCalcView.SuspendLayout();
            this.tableLayoutViewFx.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericRound)).BeginInit();
            this.tableLayoutPanelWriteView.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.menuStrip3.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.menuStrip4.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(621, 25);
            this.button1.Margin = new System.Windows.Forms.Padding(25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(283, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(933, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(933, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(929, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(504, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Калькулятор";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 459);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(933, 68);
            this.panel2.TabIndex = 9;
            // 
            // button4
            // 
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.Location = new System.Drawing.Point(3, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(150, 34);
            this.button4.TabIndex = 0;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // timerView
            // 
            this.timerView.Enabled = true;
            this.timerView.Tick += new System.EventHandler(this.timerView_Tick);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.3913F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 62.6087F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 236F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 278F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel25, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.button12, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.button4, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.flowResizeMain, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.labelInfoCount, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel24, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.button16, 2, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(933, 370);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 6;
            this.tableLayoutPanel2.SetColumnSpan(this.tableLayoutPanel25, 2);
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel25.Controls.Add(this.buttonScrollMin, 5, 0);
            this.tableLayoutPanel25.Controls.Add(this.buttonScrollUp1, 3, 0);
            this.tableLayoutPanel25.Controls.Add(this.buttonScrollMax, 4, 0);
            this.tableLayoutPanel25.Controls.Add(this.buttonScrollUp, 1, 0);
            this.tableLayoutPanel25.Controls.Add(this.buttonScrollDown1, 2, 0);
            this.tableLayoutPanel25.Controls.Add(this.buttonScrollDown, 0, 0);
            this.tableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(3, 43);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(412, 45);
            this.tableLayoutPanel25.TabIndex = 0;
            // 
            // buttonScrollMin
            // 
            this.buttonScrollMin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonScrollMin.Location = new System.Drawing.Point(343, 3);
            this.buttonScrollMin.Name = "buttonScrollMin";
            this.buttonScrollMin.Size = new System.Drawing.Size(66, 39);
            this.buttonScrollMin.TabIndex = 1;
            this.buttonScrollMin.Text = "⇈";
            this.buttonScrollMin.UseVisualStyleBackColor = true;
            this.buttonScrollMin.Click += new System.EventHandler(this.buttonScrollMin_Click);
            // 
            // buttonScrollUp1
            // 
            this.buttonScrollUp1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonScrollUp1.Location = new System.Drawing.Point(204, 0);
            this.buttonScrollUp1.Margin = new System.Windows.Forms.Padding(0);
            this.buttonScrollUp1.Name = "buttonScrollUp1";
            this.buttonScrollUp1.Size = new System.Drawing.Size(68, 45);
            this.buttonScrollUp1.TabIndex = 1;
            this.buttonScrollUp1.Text = "-↑";
            this.buttonScrollUp1.UseVisualStyleBackColor = true;
            this.buttonScrollUp1.Click += new System.EventHandler(this.buttonScrollUp1_Click);
            // 
            // buttonScrollMax
            // 
            this.buttonScrollMax.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonScrollMax.Location = new System.Drawing.Point(275, 3);
            this.buttonScrollMax.Name = "buttonScrollMax";
            this.buttonScrollMax.Size = new System.Drawing.Size(62, 39);
            this.buttonScrollMax.TabIndex = 0;
            this.buttonScrollMax.Text = "⇊";
            this.buttonScrollMax.UseVisualStyleBackColor = true;
            this.buttonScrollMax.Click += new System.EventHandler(this.buttonScrollMax_Click);
            // 
            // buttonScrollUp
            // 
            this.buttonScrollUp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonScrollUp.Location = new System.Drawing.Point(71, 3);
            this.buttonScrollUp.Name = "buttonScrollUp";
            this.buttonScrollUp.Size = new System.Drawing.Size(62, 39);
            this.buttonScrollUp.TabIndex = 1;
            this.buttonScrollUp.Text = "↑";
            this.buttonScrollUp.UseVisualStyleBackColor = true;
            this.buttonScrollUp.Click += new System.EventHandler(this.buttonScrollUp_Click);
            // 
            // buttonScrollDown1
            // 
            this.buttonScrollDown1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonScrollDown1.Location = new System.Drawing.Point(136, 0);
            this.buttonScrollDown1.Margin = new System.Windows.Forms.Padding(0);
            this.buttonScrollDown1.Name = "buttonScrollDown1";
            this.buttonScrollDown1.Size = new System.Drawing.Size(68, 45);
            this.buttonScrollDown1.TabIndex = 0;
            this.buttonScrollDown1.Text = "-↓";
            this.buttonScrollDown1.UseVisualStyleBackColor = true;
            this.buttonScrollDown1.Click += new System.EventHandler(this.buttonScrollDown1_Click);
            // 
            // buttonScrollDown
            // 
            this.buttonScrollDown.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonScrollDown.Location = new System.Drawing.Point(3, 3);
            this.buttonScrollDown.Name = "buttonScrollDown";
            this.buttonScrollDown.Size = new System.Drawing.Size(62, 39);
            this.buttonScrollDown.TabIndex = 0;
            this.buttonScrollDown.Text = "↓";
            this.buttonScrollDown.UseVisualStyleBackColor = true;
            this.buttonScrollDown.Click += new System.EventHandler(this.buttonScrollDown_Click);
            // 
            // button12
            // 
            this.button12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button12.Location = new System.Drawing.Point(657, 43);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(273, 45);
            this.button12.TabIndex = 4;
            this.button12.Text = "Калькулятор-список";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.buttonListCalculator_Click);
            // 
            // flowResizeMain
            // 
            this.flowResizeMain.AutoScroll = true;
            this.flowResizeMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tableLayoutPanel2.SetColumnSpan(this.flowResizeMain, 4);
            this.flowResizeMain.Controls.Add(this.checkBoxFlagsView);
            this.flowResizeMain.Controls.Add(this.checkBoxViewFx);
            this.flowResizeMain.Controls.Add(this.groupBoxImportFx);
            this.flowResizeMain.Controls.Add(this.checkBoxShowFile);
            this.flowResizeMain.Controls.Add(this.tableLayoutPanelFile);
            this.flowResizeMain.Controls.Add(this.checkBoxInputBView);
            this.flowResizeMain.Controls.Add(this.tableLayoutPanelInputBView);
            this.flowResizeMain.Controls.Add(this.checkBoxCorrectView);
            this.flowResizeMain.Controls.Add(this.tableLayoutPanelCorrectView);
            this.flowResizeMain.Controls.Add(this.tableLayoutPanel11);
            this.flowResizeMain.Controls.Add(this.tableLayoutPanel21);
            this.flowResizeMain.Controls.Add(this.checkBoxPanelCalcView);
            this.flowResizeMain.Controls.Add(this.tableLayoutPanelCalcView);
            this.flowResizeMain.Controls.Add(this.checkBoxPanelRoundView);
            this.flowResizeMain.Controls.Add(this.tableLayoutViewFx);
            this.flowResizeMain.Controls.Add(this.checkBoxPanelWriteView);
            this.flowResizeMain.Controls.Add(this.tableLayoutPanelWriteView);
            this.flowResizeMain.Controls.Add(this.tableLayoutPanel13);
            this.flowResizeMain.Controls.Add(this.tableLayoutPanel14);
            this.flowResizeMain.Controls.Add(this.label2);
            this.flowResizeMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResizeMain.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResizeMain.Location = new System.Drawing.Point(3, 94);
            this.flowResizeMain.Name = "flowResizeMain";
            this.flowResizeMain.Size = new System.Drawing.Size(927, 273);
            this.flowResizeMain.TabIndex = 1;
            this.flowResizeMain.WithDelta = 35;
            this.flowResizeMain.WrapContents = false;
            this.flowResizeMain.Paint += new System.Windows.Forms.PaintEventHandler(this.flowResizeMain_Paint);
            // 
            // checkBoxFlagsView
            // 
            this.checkBoxFlagsView.AutoSize = true;
            this.checkBoxFlagsView.Location = new System.Drawing.Point(3, 3);
            this.checkBoxFlagsView.Name = "checkBoxFlagsView";
            this.checkBoxFlagsView.Size = new System.Drawing.Size(350, 25);
            this.checkBoxFlagsView.TabIndex = 1;
            this.checkBoxFlagsView.Text = "Показывать флажки скрытия панелей";
            this.checkBoxFlagsView.UseVisualStyleBackColor = true;
            // 
            // checkBoxViewFx
            // 
            this.checkBoxViewFx.AutoSize = true;
            this.checkBoxViewFx.Location = new System.Drawing.Point(3, 34);
            this.checkBoxViewFx.Name = "checkBoxViewFx";
            this.checkBoxViewFx.Size = new System.Drawing.Size(525, 25);
            this.checkBoxViewFx.TabIndex = 0;
            this.checkBoxViewFx.Text = "Показывать панель с импортом функции f(x) для графика";
            this.checkBoxViewFx.UseVisualStyleBackColor = true;
            // 
            // groupBoxImportFx
            // 
            this.groupBoxImportFx.Controls.Add(this.tableLayoutPanel3);
            this.groupBoxImportFx.Location = new System.Drawing.Point(3, 65);
            this.groupBoxImportFx.Name = "groupBoxImportFx";
            this.groupBoxImportFx.Size = new System.Drawing.Size(892, 264);
            this.groupBoxImportFx.TabIndex = 0;
            this.groupBoxImportFx.TabStop = false;
            this.groupBoxImportFx.Text = "Импорт функции F(x)";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Controls.Add(this.textBoxFc, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.textBoxViewFx, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.textBoxFunctionConst, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel5, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel6, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel17, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.checkBoxFxOutput, 0, 2);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(886, 231);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // textBoxFc
            // 
            this.textBoxFc.AllowNegative = true;
            this.textBoxFc.ClearingByReadonly = true;
            this.textBoxFc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFc.EnterAllow = true;
            this.textBoxFc.Location = new System.Drawing.Point(595, 5);
            this.textBoxFc.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxFc.MultiLine = false;
            this.textBoxFc.Name = "textBoxFc";
            this.textBoxFc.NoReadOnly = false;
            this.textBoxFc.ReadOnly = true;
            this.textBoxFc.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxFc.SelectionStart = 0;
            this.textBoxFc.Size = new System.Drawing.Size(286, 87);
            this.textBoxFc.TabIndex = 3;
            this.textBoxFc.TextWithLineBreaks = "";
            this.textBoxFc.Title = "f(C)=";
            this.textBoxFc.UseSystemPasswordChar = false;
            this.textBoxFc.Value = "";
            this.textBoxFc.ValueBackColor = System.Drawing.Color.White;
            this.textBoxFc.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxFc.ValueText = "";
            this.textBoxFc.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxFc.ValueWithLineBreaks = "";
            this.textBoxFc.VisibleOK = false;
            // 
            // textBoxViewFx
            // 
            this.textBoxViewFx.AllowNegative = true;
            this.textBoxViewFx.ClearingByReadonly = true;
            this.textBoxViewFx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxViewFx.EnterAllow = true;
            this.textBoxViewFx.Location = new System.Drawing.Point(4, 4);
            this.textBoxViewFx.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxViewFx.MultiLine = false;
            this.textBoxViewFx.Name = "textBoxViewFx";
            this.textBoxViewFx.NoReadOnly = false;
            this.textBoxViewFx.ReadOnly = true;
            this.textBoxViewFx.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxViewFx.SelectionStart = 0;
            this.textBoxViewFx.Size = new System.Drawing.Size(287, 89);
            this.textBoxViewFx.TabIndex = 0;
            this.textBoxViewFx.TextWithLineBreaks = "";
            this.textBoxViewFx.Title = "f(x)=";
            this.textBoxViewFx.UseSystemPasswordChar = false;
            this.textBoxViewFx.Value = "";
            this.textBoxViewFx.ValueBackColor = System.Drawing.Color.White;
            this.textBoxViewFx.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxViewFx.ValueText = "";
            this.textBoxViewFx.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxViewFx.ValueWithLineBreaks = "";
            this.textBoxViewFx.VisibleOK = false;
            this.textBoxViewFx.ValueChanged += new TableAIS.TextValueChanged(this.textBoxViewFx_ValueChanged);
            // 
            // textBoxFunctionConst
            // 
            this.textBoxFunctionConst.AllowNegative = true;
            this.textBoxFunctionConst.ClearingByReadonly = false;
            this.textBoxFunctionConst.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFunctionConst.EnterAllow = true;
            this.textBoxFunctionConst.Location = new System.Drawing.Point(299, 4);
            this.textBoxFunctionConst.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFunctionConst.MultiLine = false;
            this.textBoxFunctionConst.Name = "textBoxFunctionConst";
            this.textBoxFunctionConst.NoReadOnly = true;
            this.textBoxFunctionConst.ReadOnly = false;
            this.textBoxFunctionConst.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxFunctionConst.SelectionStart = 0;
            this.textBoxFunctionConst.Size = new System.Drawing.Size(287, 89);
            this.textBoxFunctionConst.TabIndex = 2;
            this.textBoxFunctionConst.TextWithLineBreaks = "";
            this.textBoxFunctionConst.Title = "C=";
            this.textBoxFunctionConst.UseSystemPasswordChar = false;
            this.textBoxFunctionConst.Value = "";
            this.textBoxFunctionConst.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxFunctionConst.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxFunctionConst.ValueText = "";
            this.textBoxFunctionConst.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxFunctionConst.ValueWithLineBreaks = "";
            this.textBoxFunctionConst.VisibleOK = false;
            this.textBoxFunctionConst.EnterKeyDown += new TableAIS.TextValueChanged(this.textBoxFunctionConst_EnterKeyDown);
            this.textBoxFunctionConst.ValueChanged += new TableAIS.TextValueChanged(this.textBoxFunctionConst_ValueChanged);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.buttonComputeFc, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.button11, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonAddFunctionToC, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonCalcC, 0, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 97);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(295, 97);
            this.tableLayoutPanel5.TabIndex = 4;
            // 
            // buttonComputeFc
            // 
            this.buttonComputeFc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonComputeFc.Location = new System.Drawing.Point(150, 51);
            this.buttonComputeFc.Name = "buttonComputeFc";
            this.buttonComputeFc.Size = new System.Drawing.Size(142, 43);
            this.buttonComputeFc.TabIndex = 4;
            this.buttonComputeFc.Text = "Вычислить f(C)";
            this.buttonComputeFc.UseVisualStyleBackColor = true;
            this.buttonComputeFc.Click += new System.EventHandler(this.buttonComputeFc_Click);
            // 
            // button11
            // 
            this.button11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button11.Location = new System.Drawing.Point(3, 3);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(141, 42);
            this.button11.TabIndex = 1;
            this.button11.Text = "Построитель графиков";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.buttonRunGrafics_Click);
            // 
            // buttonAddFunctionToC
            // 
            this.buttonAddFunctionToC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAddFunctionToC.Location = new System.Drawing.Point(150, 3);
            this.buttonAddFunctionToC.Name = "buttonAddFunctionToC";
            this.buttonAddFunctionToC.Size = new System.Drawing.Size(142, 42);
            this.buttonAddFunctionToC.TabIndex = 2;
            this.buttonAddFunctionToC.Text = "Вставить функцию в C";
            this.buttonAddFunctionToC.UseVisualStyleBackColor = true;
            this.buttonAddFunctionToC.Click += new System.EventHandler(this.buttonAddFunctionToC_Click);
            // 
            // buttonCalcC
            // 
            this.buttonCalcC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalcC.Location = new System.Drawing.Point(3, 51);
            this.buttonCalcC.Name = "buttonCalcC";
            this.buttonCalcC.Size = new System.Drawing.Size(141, 43);
            this.buttonCalcC.TabIndex = 3;
            this.buttonCalcC.Text = "Вычислить C";
            this.buttonCalcC.UseVisualStyleBackColor = true;
            this.buttonCalcC.Click += new System.EventHandler(this.buttonCalcC_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.21799F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.78201F));
            this.tableLayoutPanel6.Controls.Add(this.groupBox5, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.groupBoxRunC, 1, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(298, 100);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 97F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(289, 91);
            this.tableLayoutPanel6.TabIndex = 5;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tableLayoutPanel15);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(3, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(89, 85);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Обмен с";
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 1;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel15.Controls.Add(this.radioButtonC, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.radioButtonFc, 0, 1);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(83, 52);
            this.tableLayoutPanel15.TabIndex = 0;
            // 
            // radioButtonC
            // 
            this.radioButtonC.AutoSize = true;
            this.radioButtonC.Checked = true;
            this.radioButtonC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonC.Location = new System.Drawing.Point(3, 3);
            this.radioButtonC.Name = "radioButtonC";
            this.radioButtonC.Size = new System.Drawing.Size(77, 20);
            this.radioButtonC.TabIndex = 0;
            this.radioButtonC.TabStop = true;
            this.radioButtonC.Text = "C";
            this.radioButtonC.UseVisualStyleBackColor = true;
            // 
            // radioButtonFc
            // 
            this.radioButtonFc.AutoSize = true;
            this.radioButtonFc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonFc.Location = new System.Drawing.Point(3, 29);
            this.radioButtonFc.Name = "radioButtonFc";
            this.radioButtonFc.Size = new System.Drawing.Size(77, 20);
            this.radioButtonFc.TabIndex = 1;
            this.radioButtonFc.Text = "f(C)";
            this.radioButtonFc.UseVisualStyleBackColor = true;
            this.radioButtonFc.CheckedChanged += new System.EventHandler(this.radioButtonFc_CheckedChanged);
            // 
            // groupBoxRunC
            // 
            this.groupBoxRunC.Controls.Add(this.tableLayoutPanel16);
            this.groupBoxRunC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxRunC.Location = new System.Drawing.Point(98, 3);
            this.groupBoxRunC.Name = "groupBoxRunC";
            this.groupBoxRunC.Size = new System.Drawing.Size(188, 85);
            this.groupBoxRunC.TabIndex = 1;
            this.groupBoxRunC.TabStop = false;
            this.groupBoxRunC.Text = "Направление обмена";
            this.groupBoxRunC.VisibleChanged += new System.EventHandler(this.groupBoxRunC_VisibleChanged);
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 1;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel16.Controls.Add(this.radioButtonExportC, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.radioButtonImportC, 0, 1);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(182, 52);
            this.tableLayoutPanel16.TabIndex = 0;
            // 
            // radioButtonExportC
            // 
            this.radioButtonExportC.AutoSize = true;
            this.radioButtonExportC.Checked = true;
            this.radioButtonExportC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonExportC.Location = new System.Drawing.Point(3, 3);
            this.radioButtonExportC.Name = "radioButtonExportC";
            this.radioButtonExportC.Size = new System.Drawing.Size(176, 20);
            this.radioButtonExportC.TabIndex = 0;
            this.radioButtonExportC.TabStop = true;
            this.radioButtonExportC.Text = "> (Вывод)";
            this.radioButtonExportC.UseVisualStyleBackColor = true;
            // 
            // radioButtonImportC
            // 
            this.radioButtonImportC.AutoSize = true;
            this.radioButtonImportC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonImportC.Location = new System.Drawing.Point(3, 29);
            this.radioButtonImportC.Name = "radioButtonImportC";
            this.radioButtonImportC.Size = new System.Drawing.Size(176, 20);
            this.radioButtonImportC.TabIndex = 1;
            this.radioButtonImportC.TabStop = true;
            this.radioButtonImportC.Text = "< (Ввод)";
            this.radioButtonImportC.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 3;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel17.Controls.Add(this.checkBoxAutoFc, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.buttonCalcFc, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.checkBoxEnterFc, 2, 0);
            this.tableLayoutPanel17.Controls.Add(this.menuStrip8, 0, 1);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(593, 100);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 2;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(290, 91);
            this.tableLayoutPanel17.TabIndex = 6;
            // 
            // checkBoxAutoFc
            // 
            this.checkBoxAutoFc.AutoSize = true;
            this.checkBoxAutoFc.Checked = true;
            this.checkBoxAutoFc.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAutoFc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoFc.Location = new System.Drawing.Point(133, 3);
            this.checkBoxAutoFc.Name = "checkBoxAutoFc";
            this.checkBoxAutoFc.Size = new System.Drawing.Size(74, 39);
            this.checkBoxAutoFc.TabIndex = 0;
            this.checkBoxAutoFc.Text = "Авто";
            this.checkBoxAutoFc.UseVisualStyleBackColor = true;
            // 
            // buttonCalcFc
            // 
            this.buttonCalcFc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalcFc.Location = new System.Drawing.Point(3, 3);
            this.buttonCalcFc.Name = "buttonCalcFc";
            this.buttonCalcFc.Size = new System.Drawing.Size(124, 39);
            this.buttonCalcFc.TabIndex = 1;
            this.buttonCalcFc.Text = "Сформировать f(C)";
            this.buttonCalcFc.UseVisualStyleBackColor = true;
            this.buttonCalcFc.Click += new System.EventHandler(this.buttonCalcFc_Click);
            // 
            // checkBoxEnterFc
            // 
            this.checkBoxEnterFc.AutoSize = true;
            this.checkBoxEnterFc.Checked = true;
            this.checkBoxEnterFc.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxEnterFc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxEnterFc.Location = new System.Drawing.Point(213, 3);
            this.checkBoxEnterFc.Name = "checkBoxEnterFc";
            this.checkBoxEnterFc.Size = new System.Drawing.Size(74, 39);
            this.checkBoxEnterFc.TabIndex = 2;
            this.checkBoxEnterFc.Text = "Enter";
            this.checkBoxEnterFc.UseVisualStyleBackColor = true;
            // 
            // menuStrip8
            // 
            this.tableLayoutPanel17.SetColumnSpan(this.menuStrip8, 3);
            this.menuStrip8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip8.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip8.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip8.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.исправитьCToolStripMenuItem,
            this.вводВыводToolStripMenuItem});
            this.menuStrip8.Location = new System.Drawing.Point(0, 45);
            this.menuStrip8.Name = "menuStrip8";
            this.menuStrip8.Size = new System.Drawing.Size(290, 46);
            this.menuStrip8.TabIndex = 3;
            this.menuStrip8.Text = "menuStrip8";
            // 
            // исправитьCToolStripMenuItem
            // 
            this.исправитьCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddBasketsC,
            this.buttonDropBasketsC,
            this.buttonChangeBasketsC,
            this.buttonDropVariableC,
            this.buttonComputeC,
            this.cИлиFCВыборОбменСToolStripMenuItem});
            this.исправитьCToolStripMenuItem.Name = "исправитьCToolStripMenuItem";
            this.исправитьCToolStripMenuItem.Size = new System.Drawing.Size(114, 42);
            this.исправитьCToolStripMenuItem.Text = "Исправить";
            // 
            // buttonAddBasketsC
            // 
            this.buttonAddBasketsC.Name = "buttonAddBasketsC";
            this.buttonAddBasketsC.Size = new System.Drawing.Size(504, 26);
            this.buttonAddBasketsC.Text = "Добавить скобки";
            this.buttonAddBasketsC.Click += new System.EventHandler(this.buttonAddBasketsC_Click);
            // 
            // buttonDropBasketsC
            // 
            this.buttonDropBasketsC.Name = "buttonDropBasketsC";
            this.buttonDropBasketsC.Size = new System.Drawing.Size(504, 26);
            this.buttonDropBasketsC.Text = "Удалить внешние скобки";
            this.buttonDropBasketsC.Click += new System.EventHandler(this.buttonDropBasketsC_Click);
            // 
            // buttonChangeBasketsC
            // 
            this.buttonChangeBasketsC.Name = "buttonChangeBasketsC";
            this.buttonChangeBasketsC.Size = new System.Drawing.Size(504, 26);
            this.buttonChangeBasketsC.Text = "Выравнять скобки";
            this.buttonChangeBasketsC.Click += new System.EventHandler(this.buttonChangeBasketsC_Click);
            // 
            // buttonDropVariableC
            // 
            this.buttonDropVariableC.Name = "buttonDropVariableC";
            this.buttonDropVariableC.Size = new System.Drawing.Size(504, 26);
            this.buttonDropVariableC.Text = "Раскрыть переменные";
            this.buttonDropVariableC.Click += new System.EventHandler(this.buttonDropVariableC_Click);
            // 
            // buttonComputeC
            // 
            this.buttonComputeC.Name = "buttonComputeC";
            this.buttonComputeC.Size = new System.Drawing.Size(504, 26);
            this.buttonComputeC.Text = "Вычислить";
            this.buttonComputeC.Click += new System.EventHandler(this.buttonComputeC_Click);
            // 
            // cИлиFCВыборОбменСToolStripMenuItem
            // 
            this.cИлиFCВыборОбменСToolStripMenuItem.Name = "cИлиFCВыборОбменСToolStripMenuItem";
            this.cИлиFCВыборОбменСToolStripMenuItem.Size = new System.Drawing.Size(504, 26);
            this.cИлиFCВыборОбменСToolStripMenuItem.Text = "C или f(C) для функций выше - выбор \"Обмен с\"";
            // 
            // вводВыводToolStripMenuItem
            // 
            this.вводВыводToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCB,
            this.buttonCA,
            this.buttonBufferC,
            this.buttonHelpC,
            this.buttonClipBoardC,
            this.buttonLastWindowC,
            this.buttonMainWindowC});
            this.вводВыводToolStripMenuItem.Name = "вводВыводToolStripMenuItem";
            this.вводВыводToolStripMenuItem.Size = new System.Drawing.Size(127, 42);
            this.вводВыводToolStripMenuItem.Text = "Ввод/Вывод";
            // 
            // buttonCB
            // 
            this.buttonCB.Name = "buttonCB";
            this.buttonCB.Size = new System.Drawing.Size(262, 26);
            this.buttonCB.Text = "B";
            this.buttonCB.Click += new System.EventHandler(this.buttonCB_Click);
            // 
            // buttonCA
            // 
            this.buttonCA.Name = "buttonCA";
            this.buttonCA.Size = new System.Drawing.Size(262, 26);
            this.buttonCA.Text = "A";
            this.buttonCA.Click += new System.EventHandler(this.buttonCA_Click);
            // 
            // buttonBufferC
            // 
            this.buttonBufferC.Name = "buttonBufferC";
            this.buttonBufferC.Size = new System.Drawing.Size(262, 26);
            this.buttonBufferC.Text = "Buffer";
            this.buttonBufferC.Click += new System.EventHandler(this.buttonBufferC_Click);
            // 
            // buttonHelpC
            // 
            this.buttonHelpC.Name = "buttonHelpC";
            this.buttonHelpC.Size = new System.Drawing.Size(262, 26);
            this.buttonHelpC.Text = "Help";
            this.buttonHelpC.Click += new System.EventHandler(this.buttonHelpC_Click);
            // 
            // buttonClipBoardC
            // 
            this.buttonClipBoardC.Name = "buttonClipBoardC";
            this.buttonClipBoardC.Size = new System.Drawing.Size(262, 26);
            this.buttonClipBoardC.Text = "Буфер обмена";
            this.buttonClipBoardC.Click += new System.EventHandler(this.buttonClipBoardC_Click);
            // 
            // buttonLastWindowC
            // 
            this.buttonLastWindowC.Name = "buttonLastWindowC";
            this.buttonLastWindowC.Size = new System.Drawing.Size(262, 26);
            this.buttonLastWindowC.Text = "Предыдущий экран";
            this.buttonLastWindowC.Click += new System.EventHandler(this.buttonLastWindowC_Click);
            // 
            // buttonMainWindowC
            // 
            this.buttonMainWindowC.Name = "buttonMainWindowC";
            this.buttonMainWindowC.Size = new System.Drawing.Size(262, 26);
            this.buttonMainWindowC.Text = "Главный экран";
            this.buttonMainWindowC.Click += new System.EventHandler(this.buttonMainWindowC_Click);
            // 
            // checkBoxFxOutput
            // 
            this.checkBoxFxOutput.AutoSize = true;
            this.checkBoxFxOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxFxOutput.Location = new System.Drawing.Point(3, 197);
            this.checkBoxFxOutput.Name = "checkBoxFxOutput";
            this.checkBoxFxOutput.Size = new System.Drawing.Size(289, 31);
            this.checkBoxFxOutput.TabIndex = 7;
            this.checkBoxFxOutput.Text = "Выводить";
            this.checkBoxFxOutput.UseVisualStyleBackColor = true;
            // 
            // checkBoxShowFile
            // 
            this.checkBoxShowFile.AutoSize = true;
            this.checkBoxShowFile.Location = new System.Drawing.Point(3, 335);
            this.checkBoxShowFile.Name = "checkBoxShowFile";
            this.checkBoxShowFile.Size = new System.Drawing.Size(500, 25);
            this.checkBoxShowFile.TabIndex = 0;
            this.checkBoxShowFile.Text = "Показывать варианты обмена с файлом и json-текстом";
            this.checkBoxShowFile.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelFile
            // 
            this.tableLayoutPanelFile.ColumnCount = 2;
            this.tableLayoutPanelFile.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelFile.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelFile.Controls.Add(this.buttonSaveFile, 0, 0);
            this.tableLayoutPanelFile.Controls.Add(this.buttonLoadFile, 1, 0);
            this.tableLayoutPanelFile.Controls.Add(this.menuStrip7, 0, 1);
            this.tableLayoutPanelFile.Location = new System.Drawing.Point(3, 366);
            this.tableLayoutPanelFile.Name = "tableLayoutPanelFile";
            this.tableLayoutPanelFile.RowCount = 2;
            this.tableLayoutPanelFile.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelFile.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelFile.Size = new System.Drawing.Size(892, 100);
            this.tableLayoutPanelFile.TabIndex = 0;
            // 
            // buttonSaveFile
            // 
            this.buttonSaveFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSaveFile.Location = new System.Drawing.Point(3, 3);
            this.buttonSaveFile.Name = "buttonSaveFile";
            this.buttonSaveFile.Size = new System.Drawing.Size(440, 44);
            this.buttonSaveFile.TabIndex = 0;
            this.buttonSaveFile.Text = "Сохранить в файл";
            this.buttonSaveFile.UseVisualStyleBackColor = true;
            this.buttonSaveFile.Click += new System.EventHandler(this.buttonSaveFile_Click);
            // 
            // buttonLoadFile
            // 
            this.buttonLoadFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLoadFile.Location = new System.Drawing.Point(449, 3);
            this.buttonLoadFile.Name = "buttonLoadFile";
            this.buttonLoadFile.Size = new System.Drawing.Size(440, 44);
            this.buttonLoadFile.TabIndex = 1;
            this.buttonLoadFile.Text = "Загрузить из файла";
            this.buttonLoadFile.UseVisualStyleBackColor = true;
            this.buttonLoadFile.Click += new System.EventHandler(this.buttonLoadFile_Click);
            // 
            // menuStrip7
            // 
            this.menuStrip7.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip7.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip7.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.обменСГлавнымЭкраномToolStripMenuItem});
            this.menuStrip7.Location = new System.Drawing.Point(0, 50);
            this.menuStrip7.Name = "menuStrip7";
            this.menuStrip7.Size = new System.Drawing.Size(446, 29);
            this.menuStrip7.TabIndex = 2;
            this.menuStrip7.Text = "menuStrip7";
            // 
            // обменСГлавнымЭкраномToolStripMenuItem
            // 
            this.обменСГлавнымЭкраномToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripJsonDropVariants,
            this.buttonJsonLastWindow,
            this.buttonJsonMainWindow,
            this.buttonJsonClipBoard});
            this.обменСГлавнымЭкраномToolStripMenuItem.Name = "обменСГлавнымЭкраномToolStripMenuItem";
            this.обменСГлавнымЭкраномToolStripMenuItem.Size = new System.Drawing.Size(133, 25);
            this.обменСГлавнымЭкраномToolStripMenuItem.Text = "Json-формат";
            // 
            // toolStripJsonDropVariants
            // 
            this.toolStripJsonDropVariants.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripJsonDropVariants.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.toolStripJsonDropVariants.Items.AddRange(new object[] {
            "Получить из",
            "Записать в"});
            this.toolStripJsonDropVariants.Name = "toolStripJsonDropVariants";
            this.toolStripJsonDropVariants.Size = new System.Drawing.Size(121, 29);
            // 
            // buttonJsonLastWindow
            // 
            this.buttonJsonLastWindow.Name = "buttonJsonLastWindow";
            this.buttonJsonLastWindow.Size = new System.Drawing.Size(262, 26);
            this.buttonJsonLastWindow.Text = "Предыдущий экран";
            this.buttonJsonLastWindow.Click += new System.EventHandler(this.buttonJsonLastWindow_Click);
            // 
            // buttonJsonMainWindow
            // 
            this.buttonJsonMainWindow.Name = "buttonJsonMainWindow";
            this.buttonJsonMainWindow.Size = new System.Drawing.Size(262, 26);
            this.buttonJsonMainWindow.Text = "Главный экран";
            this.buttonJsonMainWindow.Click += new System.EventHandler(this.buttonJsonMainWindow_Click);
            // 
            // buttonJsonClipBoard
            // 
            this.buttonJsonClipBoard.Name = "buttonJsonClipBoard";
            this.buttonJsonClipBoard.Size = new System.Drawing.Size(262, 26);
            this.buttonJsonClipBoard.Text = "Буфер обмена";
            this.buttonJsonClipBoard.Click += new System.EventHandler(this.buttonJsonClipBoard_Click);
            // 
            // checkBoxInputBView
            // 
            this.checkBoxInputBView.AutoSize = true;
            this.checkBoxInputBView.Location = new System.Drawing.Point(3, 472);
            this.checkBoxInputBView.Name = "checkBoxInputBView";
            this.checkBoxInputBView.Size = new System.Drawing.Size(283, 25);
            this.checkBoxInputBView.TabIndex = 1;
            this.checkBoxInputBView.Text = "Показывать варианты ввода B";
            this.checkBoxInputBView.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelInputBView
            // 
            this.tableLayoutPanelInputBView.ColumnCount = 4;
            this.tableLayoutPanelInputBView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelInputBView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelInputBView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelInputBView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelInputBView.Controls.Add(this.button7, 3, 0);
            this.tableLayoutPanelInputBView.Controls.Add(this.buttonKeyBord, 0, 0);
            this.tableLayoutPanelInputBView.Controls.Add(this.menuStrip1, 2, 1);
            this.tableLayoutPanelInputBView.Controls.Add(this.button2, 1, 0);
            this.tableLayoutPanelInputBView.Controls.Add(this.button8, 0, 1);
            this.tableLayoutPanelInputBView.Location = new System.Drawing.Point(3, 503);
            this.tableLayoutPanelInputBView.Name = "tableLayoutPanelInputBView";
            this.tableLayoutPanelInputBView.RowCount = 2;
            this.tableLayoutPanelInputBView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelInputBView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelInputBView.Size = new System.Drawing.Size(892, 100);
            this.tableLayoutPanelInputBView.TabIndex = 1;
            // 
            // button7
            // 
            this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button7.Location = new System.Drawing.Point(672, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(217, 44);
            this.button7.TabIndex = 8;
            this.button7.Text = "Вычислить B";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.buttonCalculateB_Click);
            // 
            // buttonKeyBord
            // 
            this.buttonKeyBord.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonKeyBord.Location = new System.Drawing.Point(3, 3);
            this.buttonKeyBord.Name = "buttonKeyBord";
            this.buttonKeyBord.Size = new System.Drawing.Size(217, 44);
            this.buttonKeyBord.TabIndex = 4;
            this.buttonKeyBord.Text = "С кнопочного калькулятора";
            this.buttonKeyBord.UseVisualStyleBackColor = true;
            this.buttonKeyBord.Click += new System.EventHandler(this.buttonKeyBord_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonMenuCalculator});
            this.menuStrip1.Location = new System.Drawing.Point(446, 50);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(223, 50);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // buttonMenuCalculator
            // 
            this.buttonMenuCalculator.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.buttonMenuCalculator.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonTimer,
            this.buttonGetSavedSeconds,
            this.buttonFromMainForm,
            this.buttonIntCalculator,
            this.buttonFromMainFormReal,
            this.buttonBFromClipboard});
            this.buttonMenuCalculator.Name = "buttonMenuCalculator";
            this.buttonMenuCalculator.Size = new System.Drawing.Size(135, 46);
            this.buttonMenuCalculator.Text = "Ввести извне";
            // 
            // buttonTimer
            // 
            this.buttonTimer.Name = "buttonTimer";
            this.buttonTimer.Size = new System.Drawing.Size(714, 26);
            this.buttonTimer.Text = "Измерить входной параметр секундомером";
            this.buttonTimer.Click += new System.EventHandler(this.buttonTimer_Click);
            // 
            // buttonGetSavedSeconds
            // 
            this.buttonGetSavedSeconds.Name = "buttonGetSavedSeconds";
            this.buttonGetSavedSeconds.Size = new System.Drawing.Size(714, 26);
            this.buttonGetSavedSeconds.Text = "Получить входной параметр из сохранённых измерений секундомером";
            this.buttonGetSavedSeconds.Click += new System.EventHandler(this.buttonGetSavedSeconds_Click);
            // 
            // buttonFromMainForm
            // 
            this.buttonFromMainForm.Name = "buttonFromMainForm";
            this.buttonFromMainForm.Size = new System.Drawing.Size(714, 26);
            this.buttonFromMainForm.Text = "С предыдущего окна";
            this.buttonFromMainForm.Click += new System.EventHandler(this.buttonFromMainForm_Click);
            // 
            // buttonIntCalculator
            // 
            this.buttonIntCalculator.Name = "buttonIntCalculator";
            this.buttonIntCalculator.Size = new System.Drawing.Size(714, 26);
            this.buttonIntCalculator.Text = "С целочисленного калькулятора";
            // 
            // buttonFromMainFormReal
            // 
            this.buttonFromMainFormReal.Name = "buttonFromMainFormReal";
            this.buttonFromMainFormReal.Size = new System.Drawing.Size(714, 26);
            this.buttonFromMainFormReal.Text = "С главного экрана";
            this.buttonFromMainFormReal.Click += new System.EventHandler(this.buttonFromMainFormReal_Click);
            // 
            // buttonBFromClipboard
            // 
            this.buttonBFromClipboard.Name = "buttonBFromClipboard";
            this.buttonBFromClipboard.Size = new System.Drawing.Size(714, 26);
            this.buttonBFromClipboard.Text = "Из буфера обмена";
            this.buttonBFromClipboard.Click += new System.EventHandler(this.buttonBFromClipboard_Click);
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Location = new System.Drawing.Point(226, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(217, 44);
            this.button2.TabIndex = 8;
            this.button2.Text = "Выведенное значение A";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button8
            // 
            this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button8.Location = new System.Drawing.Point(3, 53);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(217, 44);
            this.button8.TabIndex = 9;
            this.button8.Text = "Вставить функцию";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.buttonInputFeacher_Click);
            // 
            // checkBoxCorrectView
            // 
            this.checkBoxCorrectView.AutoSize = true;
            this.checkBoxCorrectView.Location = new System.Drawing.Point(3, 609);
            this.checkBoxCorrectView.Name = "checkBoxCorrectView";
            this.checkBoxCorrectView.Size = new System.Drawing.Size(864, 25);
            this.checkBoxCorrectView.TabIndex = 1;
            this.checkBoxCorrectView.Text = "Показывать варианты вывода, сброса, исправления и обработки; память; кнопочный ка" +
    "лькулятор";
            this.checkBoxCorrectView.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelCorrectView
            // 
            this.tableLayoutPanelCorrectView.ColumnCount = 4;
            this.tableLayoutPanelCorrectView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelCorrectView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelCorrectView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelCorrectView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelCorrectView.Controls.Add(this.buttonRunGrafics, 1, 0);
            this.tableLayoutPanelCorrectView.Controls.Add(this.menuStrip5, 0, 1);
            this.tableLayoutPanelCorrectView.Controls.Add(this.menuStrip6, 3, 1);
            this.tableLayoutPanelCorrectView.Controls.Add(this.button9, 0, 0);
            this.tableLayoutPanelCorrectView.Controls.Add(this.buttonClearAll, 2, 0);
            this.tableLayoutPanelCorrectView.Controls.Add(this.buttonMemory, 3, 0);
            this.tableLayoutPanelCorrectView.Location = new System.Drawing.Point(3, 640);
            this.tableLayoutPanelCorrectView.Name = "tableLayoutPanelCorrectView";
            this.tableLayoutPanelCorrectView.RowCount = 2;
            this.tableLayoutPanelCorrectView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelCorrectView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelCorrectView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelCorrectView.Size = new System.Drawing.Size(892, 92);
            this.tableLayoutPanelCorrectView.TabIndex = 1;
            // 
            // buttonRunGrafics
            // 
            this.buttonRunGrafics.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRunGrafics.Location = new System.Drawing.Point(226, 3);
            this.buttonRunGrafics.Name = "buttonRunGrafics";
            this.buttonRunGrafics.Size = new System.Drawing.Size(217, 40);
            this.buttonRunGrafics.TabIndex = 8;
            this.buttonRunGrafics.Text = "Графики";
            this.buttonRunGrafics.UseVisualStyleBackColor = true;
            this.buttonRunGrafics.Click += new System.EventHandler(this.buttonRunGrafics_Click);
            // 
            // menuStrip5
            // 
            this.tableLayoutPanelCorrectView.SetColumnSpan(this.menuStrip5, 3);
            this.menuStrip5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip5.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip5.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.исправитьToolStripMenuItem,
            this.другаяОбработкаToolStripMenuItem,
            this.toolStripInputFunc});
            this.menuStrip5.Location = new System.Drawing.Point(0, 46);
            this.menuStrip5.Name = "menuStrip5";
            this.menuStrip5.Size = new System.Drawing.Size(669, 46);
            this.menuStrip5.TabIndex = 26;
            this.menuStrip5.Text = "menuStrip5";
            // 
            // исправитьToolStripMenuItem
            // 
            this.исправитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonChangeFunc1,
            this.buttonChengeBaskets,
            this.buttonAddBaskets,
            this.buttonDropBaskets,
            this.buttonInputFeacher,
            this.buttonTestChangeBaskets,
            this.buttonOpenConsts1,
            this.buttonTestCalc,
            this.buttonInteractiveEdit});
            this.исправитьToolStripMenuItem.Name = "исправитьToolStripMenuItem";
            this.исправитьToolStripMenuItem.Size = new System.Drawing.Size(129, 42);
            this.исправитьToolStripMenuItem.Text = "Исправить B";
            // 
            // buttonChangeFunc1
            // 
            this.buttonChangeFunc1.Name = "buttonChangeFunc1";
            this.buttonChangeFunc1.Size = new System.Drawing.Size(470, 26);
            this.buttonChangeFunc1.Text = "Раскрыть переменные и константы";
            this.buttonChangeFunc1.Click += new System.EventHandler(this.buttonChangeFunc_Click);
            // 
            // buttonChengeBaskets
            // 
            this.buttonChengeBaskets.Name = "buttonChengeBaskets";
            this.buttonChengeBaskets.Size = new System.Drawing.Size(470, 26);
            this.buttonChengeBaskets.Text = "Выравнять скобки";
            this.buttonChengeBaskets.Click += new System.EventHandler(this.buttonTestChangeBaskets_Click);
            // 
            // buttonAddBaskets
            // 
            this.buttonAddBaskets.Name = "buttonAddBaskets";
            this.buttonAddBaskets.Size = new System.Drawing.Size(470, 26);
            this.buttonAddBaskets.Text = "Добавить скобки";
            this.buttonAddBaskets.Click += new System.EventHandler(this.buttonAddBaskets_Click);
            // 
            // buttonDropBaskets
            // 
            this.buttonDropBaskets.Name = "buttonDropBaskets";
            this.buttonDropBaskets.Size = new System.Drawing.Size(470, 26);
            this.buttonDropBaskets.Text = "Удалить внешние скобки";
            this.buttonDropBaskets.Click += new System.EventHandler(this.buttonDropBaskets_Click);
            // 
            // buttonInputFeacher
            // 
            this.buttonInputFeacher.Name = "buttonInputFeacher";
            this.buttonInputFeacher.Size = new System.Drawing.Size(470, 26);
            this.buttonInputFeacher.Text = "Вставить функцию";
            this.buttonInputFeacher.Click += new System.EventHandler(this.buttonInputFeacher_Click);
            // 
            // buttonTestChangeBaskets
            // 
            this.buttonTestChangeBaskets.Name = "buttonTestChangeBaskets";
            this.buttonTestChangeBaskets.Size = new System.Drawing.Size(470, 26);
            this.buttonTestChangeBaskets.Text = "Выравнять все скобки (тестовая)";
            this.buttonTestChangeBaskets.Visible = false;
            this.buttonTestChangeBaskets.Click += new System.EventHandler(this.buttonTestChangeBaskets_Click);
            // 
            // buttonOpenConsts1
            // 
            this.buttonOpenConsts1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonOpenConsts,
            this.buttonOpenVariables,
            this.buttonOpenVariablesAnsConsts});
            this.buttonOpenConsts1.Name = "buttonOpenConsts1";
            this.buttonOpenConsts1.Size = new System.Drawing.Size(470, 26);
            this.buttonOpenConsts1.Text = "Раскрыть конструкции в формуле";
            // 
            // buttonOpenConsts
            // 
            this.buttonOpenConsts.Name = "buttonOpenConsts";
            this.buttonOpenConsts.Size = new System.Drawing.Size(313, 26);
            this.buttonOpenConsts.Text = "Константы";
            this.buttonOpenConsts.Click += new System.EventHandler(this.buttonOpenConsts_Click);
            // 
            // buttonOpenVariables
            // 
            this.buttonOpenVariables.Name = "buttonOpenVariables";
            this.buttonOpenVariables.Size = new System.Drawing.Size(313, 26);
            this.buttonOpenVariables.Text = "Переменные";
            this.buttonOpenVariables.Click += new System.EventHandler(this.buttonOpenVariables_Click);
            // 
            // buttonOpenVariablesAnsConsts
            // 
            this.buttonOpenVariablesAnsConsts.Name = "buttonOpenVariablesAnsConsts";
            this.buttonOpenVariablesAnsConsts.Size = new System.Drawing.Size(313, 26);
            this.buttonOpenVariablesAnsConsts.Text = "Переменные и константы";
            this.buttonOpenVariablesAnsConsts.Click += new System.EventHandler(this.buttonOpenVariablesAnsConsts_Click);
            // 
            // buttonTestCalc
            // 
            this.buttonTestCalc.Name = "buttonTestCalc";
            this.buttonTestCalc.Size = new System.Drawing.Size(470, 26);
            this.buttonTestCalc.Text = "Рассчитать";
            this.buttonTestCalc.Click += new System.EventHandler(this.buttonTestCalc_Click);
            // 
            // buttonInteractiveEdit
            // 
            this.buttonInteractiveEdit.Name = "buttonInteractiveEdit";
            this.buttonInteractiveEdit.Size = new System.Drawing.Size(470, 26);
            this.buttonInteractiveEdit.Text = "Интерактивное редактирование выражения";
            this.buttonInteractiveEdit.Click += new System.EventHandler(this.buttonInteractiveEdit_Click);
            // 
            // другаяОбработкаToolStripMenuItem
            // 
            this.другаяОбработкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToBynaryCode,
            this.buttonToVectorCalculator,
            this.простойКалькуляторToolStripMenuItem,
            this.buttonListCalculator});
            this.другаяОбработкаToolStripMenuItem.Name = "другаяОбработкаToolStripMenuItem";
            this.другаяОбработкаToolStripMenuItem.Size = new System.Drawing.Size(176, 42);
            this.другаяОбработкаToolStripMenuItem.Text = "Другая обработка";
            // 
            // buttonToBynaryCode
            // 
            this.buttonToBynaryCode.Name = "buttonToBynaryCode";
            this.buttonToBynaryCode.Size = new System.Drawing.Size(314, 26);
            this.buttonToBynaryCode.Text = "Двоичное представление";
            this.buttonToBynaryCode.Click += new System.EventHandler(this.buttonToBynaryCode_Click);
            // 
            // buttonToVectorCalculator
            // 
            this.buttonToVectorCalculator.Name = "buttonToVectorCalculator";
            this.buttonToVectorCalculator.Size = new System.Drawing.Size(314, 26);
            this.buttonToVectorCalculator.Text = "Векторный калькулятор";
            this.buttonToVectorCalculator.Click += new System.EventHandler(this.buttonToVectorCalculator_Click);
            // 
            // простойКалькуляторToolStripMenuItem
            // 
            this.простойКалькуляторToolStripMenuItem.Name = "простойКалькуляторToolStripMenuItem";
            this.простойКалькуляторToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.простойКалькуляторToolStripMenuItem.Text = "\"Простой\" калькулятор";
            // 
            // buttonListCalculator
            // 
            this.buttonListCalculator.Name = "buttonListCalculator";
            this.buttonListCalculator.Size = new System.Drawing.Size(314, 26);
            this.buttonListCalculator.Text = "Калькулятор-список";
            this.buttonListCalculator.Click += new System.EventHandler(this.buttonListCalculator_Click);
            // 
            // toolStripInputFunc
            // 
            this.toolStripInputFunc.Name = "toolStripInputFunc";
            this.toolStripInputFunc.Size = new System.Drawing.Size(181, 42);
            this.toolStripInputFunc.Text = "Вставить функцию";
            this.toolStripInputFunc.Click += new System.EventHandler(this.buttonInputFeacher_Click);
            // 
            // menuStrip6
            // 
            this.menuStrip6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip6.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip6.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip6.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip6.Location = new System.Drawing.Point(669, 46);
            this.menuStrip6.Name = "menuStrip6";
            this.menuStrip6.Size = new System.Drawing.Size(223, 46);
            this.menuStrip6.TabIndex = 7;
            this.menuStrip6.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(135, 42);
            this.toolStripMenuItem1.Text = "Ввести извне";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(714, 26);
            this.toolStripMenuItem2.Text = "Измерить входной параметр секундомером";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.buttonTimer_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(714, 26);
            this.toolStripMenuItem3.Text = "Получить входной параметр из сохранённых измерений секундомером";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.buttonGetSavedSeconds_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(714, 26);
            this.toolStripMenuItem4.Text = "С предыдущего окна";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.buttonFromMainForm_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(714, 26);
            this.toolStripMenuItem5.Text = "С целочисленного калькулятора";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(714, 26);
            this.toolStripMenuItem6.Text = "С главного экрана";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.buttonFromMainFormReal_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(714, 26);
            this.toolStripMenuItem7.Text = "Из буфера обмена";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.buttonBFromClipboard_Click);
            // 
            // button9
            // 
            this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button9.Location = new System.Drawing.Point(3, 3);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(217, 40);
            this.button9.TabIndex = 4;
            this.button9.Text = "Кнопочный калькулятор";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.buttonKeyBord_Click);
            // 
            // buttonClearAll
            // 
            this.buttonClearAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearAll.Location = new System.Drawing.Point(449, 3);
            this.buttonClearAll.Name = "buttonClearAll";
            this.buttonClearAll.Size = new System.Drawing.Size(217, 40);
            this.buttonClearAll.TabIndex = 6;
            this.buttonClearAll.Text = "Сбросить всё";
            this.buttonClearAll.UseVisualStyleBackColor = true;
            this.buttonClearAll.Click += new System.EventHandler(this.buttonClearAll_Click);
            // 
            // buttonMemory
            // 
            this.buttonMemory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMemory.Location = new System.Drawing.Point(672, 3);
            this.buttonMemory.Name = "buttonMemory";
            this.buttonMemory.Size = new System.Drawing.Size(217, 40);
            this.buttonMemory.TabIndex = 17;
            this.buttonMemory.Text = "Память";
            this.buttonMemory.UseVisualStyleBackColor = true;
            this.buttonMemory.Click += new System.EventHandler(this.buttonMemory_Click);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 6;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel11.Controls.Add(this.buttonClearOutput, 4, 0);
            this.tableLayoutPanel11.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.groupBox2, 3, 0);
            this.tableLayoutPanel11.Controls.Add(this.buttonClearInput, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.memoryB, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.memoryA, 3, 1);
            this.tableLayoutPanel11.Controls.Add(this.buttonCopyBCalcB, 3, 2);
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel18, 0, 2);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 738);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 3;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(892, 173);
            this.tableLayoutPanel11.TabIndex = 11;
            // 
            // buttonClearOutput
            // 
            this.buttonClearOutput.Location = new System.Drawing.Point(832, 10);
            this.buttonClearOutput.Margin = new System.Windows.Forms.Padding(10);
            this.buttonClearOutput.Name = "buttonClearOutput";
            this.buttonClearOutput.Size = new System.Drawing.Size(30, 63);
            this.buttonClearOutput.TabIndex = 3;
            this.buttonClearOutput.Text = "C";
            this.buttonClearOutput.UseVisualStyleBackColor = true;
            this.buttonClearOutput.Click += new System.EventHandler(this.buttonClearOutput_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxInput);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(370, 77);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Введённое значение (число/формула) (B)";
            // 
            // textBoxInput
            // 
            this.textBoxInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxInput.Location = new System.Drawing.Point(3, 30);
            this.textBoxInput.Name = "textBoxInput";
            this.textBoxInput.Size = new System.Drawing.Size(364, 34);
            this.textBoxInput.TabIndex = 1;
            this.textBoxInput.TextChanged += new System.EventHandler(this.textBoxInput_TextChanged);
            this.textBoxInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxInput_KeyPress);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxOutput);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(449, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(370, 77);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Вывод (A)";
            // 
            // textBoxOutput
            // 
            this.textBoxOutput.BackColor = System.Drawing.Color.White;
            this.textBoxOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxOutput.Location = new System.Drawing.Point(3, 30);
            this.textBoxOutput.Name = "textBoxOutput";
            this.textBoxOutput.ReadOnly = true;
            this.textBoxOutput.Size = new System.Drawing.Size(364, 34);
            this.textBoxOutput.TabIndex = 0;
            this.textBoxOutput.TextChanged += new System.EventHandler(this.textBoxOutput_TextChanged);
            // 
            // buttonClearInput
            // 
            this.buttonClearInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearInput.Location = new System.Drawing.Point(386, 10);
            this.buttonClearInput.Margin = new System.Windows.Forms.Padding(10);
            this.buttonClearInput.Name = "buttonClearInput";
            this.buttonClearInput.Size = new System.Drawing.Size(30, 63);
            this.buttonClearInput.TabIndex = 2;
            this.buttonClearInput.Text = "C";
            this.buttonClearInput.UseVisualStyleBackColor = true;
            this.buttonClearInput.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // memoryB
            // 
            this.memoryB.BorderStule = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tableLayoutPanel11.SetColumnSpan(this.memoryB, 2);
            this.memoryB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memoryB.Few = null;
            this.memoryB.FewInvoke = false;
            this.memoryB.Historytext = "История";
            this.memoryB.Location = new System.Drawing.Point(0, 83);
            this.memoryB.Margin = new System.Windows.Forms.Padding(0);
            this.memoryB.MinesText = "M-";
            this.memoryB.Name = "memoryB";
            this.memoryB.PlusText = "M+";
            this.memoryB.RText = "MR";
            this.memoryB.Size = new System.Drawing.Size(426, 45);
            this.memoryB.TabIndex = 13;
            this.memoryB.WriteAndClearText = "MRC";
            this.memoryB.WriteText = "->M";
            this.memoryB.Write += new System.Action(this.memoryB_Write);
            this.memoryB.Plus += new System.Action(this.memoryB_Plus);
            this.memoryB.Mines += new System.Action(this.memoryB_Mines);
            this.memoryB.MR += new System.Action(this.memoryA_MR);
            this.memoryB.History += new System.Action(this.memoryB_History);
            this.memoryB.WriteClear += new System.Action(this.memoryB_WriteClear);
            // 
            // memoryA
            // 
            this.memoryA.BorderStule = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tableLayoutPanel11.SetColumnSpan(this.memoryA, 2);
            this.memoryA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memoryA.Few = null;
            this.memoryA.FewInvoke = false;
            this.memoryA.Historytext = "История";
            this.memoryA.Location = new System.Drawing.Point(446, 83);
            this.memoryA.Margin = new System.Windows.Forms.Padding(0);
            this.memoryA.MinesText = "M-";
            this.memoryA.Name = "memoryA";
            this.memoryA.PlusText = "M+";
            this.memoryA.RText = "MR";
            this.memoryA.Size = new System.Drawing.Size(426, 45);
            this.memoryA.TabIndex = 15;
            this.memoryA.WriteAndClearText = "MRC";
            this.memoryA.WriteText = "->M";
            this.memoryA.Write += new System.Action(this.memoryA_Write);
            this.memoryA.Plus += new System.Action(this.memoryA_Plus);
            this.memoryA.Mines += new System.Action(this.memoryA_Mines);
            this.memoryA.MR += new System.Action(this.memoryA_MR_1);
            this.memoryA.History += new System.Action(this.memoryB_History);
            this.memoryA.WriteClear += new System.Action(this.memoryA_WriteClear);
            // 
            // buttonCopyBCalcB
            // 
            this.buttonCopyBCalcB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCopyBCalcB.Location = new System.Drawing.Point(449, 131);
            this.buttonCopyBCalcB.Name = "buttonCopyBCalcB";
            this.buttonCopyBCalcB.Size = new System.Drawing.Size(370, 39);
            this.buttonCopyBCalcB.TabIndex = 16;
            this.buttonCopyBCalcB.Text = "Копировать B в виде B=Calc(B)";
            this.buttonCopyBCalcB.UseVisualStyleBackColor = true;
            this.buttonCopyBCalcB.Click += new System.EventHandler(this.buttonCopyAB_Click);
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel11.SetColumnSpan(this.tableLayoutPanel18, 3);
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.72727F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.27273F));
            this.tableLayoutPanel18.Controls.Add(this.buttonPastCalcBFromBCalcB, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.buttonPastBFromBCalcB, 0, 0);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 131);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(440, 39);
            this.tableLayoutPanel18.TabIndex = 17;
            // 
            // buttonPastCalcBFromBCalcB
            // 
            this.buttonPastCalcBFromBCalcB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPastCalcBFromBCalcB.Location = new System.Drawing.Point(212, 3);
            this.buttonPastCalcBFromBCalcB.Name = "buttonPastCalcBFromBCalcB";
            this.buttonPastCalcBFromBCalcB.Size = new System.Drawing.Size(225, 33);
            this.buttonPastCalcBFromBCalcB.TabIndex = 1;
            this.buttonPastCalcBFromBCalcB.Text = "Вставить Calc(B) (B=Calc(B))";
            this.buttonPastCalcBFromBCalcB.UseVisualStyleBackColor = true;
            this.buttonPastCalcBFromBCalcB.Click += new System.EventHandler(this.buttonPastCalcBFromBCalcB_Click);
            // 
            // buttonPastBFromBCalcB
            // 
            this.buttonPastBFromBCalcB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPastBFromBCalcB.Location = new System.Drawing.Point(3, 3);
            this.buttonPastBFromBCalcB.Name = "buttonPastBFromBCalcB";
            this.buttonPastBFromBCalcB.Size = new System.Drawing.Size(203, 33);
            this.buttonPastBFromBCalcB.TabIndex = 0;
            this.buttonPastBFromBCalcB.Text = "Вставить B (B=Calc(B))";
            this.buttonPastBFromBCalcB.UseVisualStyleBackColor = true;
            this.buttonPastBFromBCalcB.Click += new System.EventHandler(this.buttonPastBFromBCalcB_Click);
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel22, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel23, 0, 0);
            this.tableLayoutPanel21.Location = new System.Drawing.Point(3, 917);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(892, 42);
            this.tableLayoutPanel21.TabIndex = 0;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 3;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel22.Controls.Add(this.buttonCalcA, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.checkBoxAutoCalcA, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.buttonCalcATest, 2, 0);
            this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(449, 3);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(440, 36);
            this.tableLayoutPanel22.TabIndex = 1;
            this.tableLayoutPanel22.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel22_Paint);
            // 
            // buttonCalcA
            // 
            this.buttonCalcA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalcA.Location = new System.Drawing.Point(3, 3);
            this.buttonCalcA.Name = "buttonCalcA";
            this.buttonCalcA.Size = new System.Drawing.Size(329, 30);
            this.buttonCalcA.TabIndex = 1;
            this.buttonCalcA.Text = "Вычислить A";
            this.buttonCalcA.UseVisualStyleBackColor = true;
            this.buttonCalcA.Click += new System.EventHandler(this.buttonOutput_Click);
            // 
            // checkBoxAutoCalcA
            // 
            this.checkBoxAutoCalcA.AutoSize = true;
            this.checkBoxAutoCalcA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoCalcA.Location = new System.Drawing.Point(338, 3);
            this.checkBoxAutoCalcA.Name = "checkBoxAutoCalcA";
            this.checkBoxAutoCalcA.Size = new System.Drawing.Size(94, 30);
            this.checkBoxAutoCalcA.TabIndex = 2;
            this.checkBoxAutoCalcA.Text = "Авто";
            this.checkBoxAutoCalcA.UseVisualStyleBackColor = true;
            this.checkBoxAutoCalcA.CheckedChanged += new System.EventHandler(this.checkBoxAutoCalcA_CheckedChanged);
            // 
            // buttonCalcATest
            // 
            this.buttonCalcATest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalcATest.Location = new System.Drawing.Point(438, 3);
            this.buttonCalcATest.Name = "buttonCalcATest";
            this.buttonCalcATest.Size = new System.Drawing.Size(1, 30);
            this.buttonCalcATest.TabIndex = 3;
            this.buttonCalcATest.Text = "Вычислить A (тестовая)";
            this.buttonCalcATest.UseVisualStyleBackColor = true;
            this.buttonCalcATest.Visible = false;
            this.buttonCalcATest.Click += new System.EventHandler(this.buttonCalcATest_Click);
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 3;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel23.Controls.Add(this.buttonCalcB, 0, 0);
            this.tableLayoutPanel23.Controls.Add(this.button13, 1, 0);
            this.tableLayoutPanel23.Controls.Add(this.button15, 2, 0);
            this.tableLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(440, 36);
            this.tableLayoutPanel23.TabIndex = 2;
            // 
            // buttonCalcB
            // 
            this.buttonCalcB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalcB.Location = new System.Drawing.Point(3, 3);
            this.buttonCalcB.Name = "buttonCalcB";
            this.buttonCalcB.Size = new System.Drawing.Size(189, 30);
            this.buttonCalcB.TabIndex = 0;
            this.buttonCalcB.Text = "Вычислить B";
            this.buttonCalcB.UseVisualStyleBackColor = true;
            this.buttonCalcB.Click += new System.EventHandler(this.buttonCalculateB_Click);
            // 
            // button13
            // 
            this.button13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button13.Location = new System.Drawing.Point(198, 3);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(189, 30);
            this.button13.TabIndex = 1;
            this.button13.Text = "Вставить функцию";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.buttonInputFeacher_Click);
            // 
            // button15
            // 
            this.button15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button15.Location = new System.Drawing.Point(393, 3);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(44, 30);
            this.button15.TabIndex = 2;
            this.button15.Text = "=A";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button2_Click);
            // 
            // checkBoxPanelCalcView
            // 
            this.checkBoxPanelCalcView.AutoSize = true;
            this.checkBoxPanelCalcView.Location = new System.Drawing.Point(3, 965);
            this.checkBoxPanelCalcView.Name = "checkBoxPanelCalcView";
            this.checkBoxPanelCalcView.Size = new System.Drawing.Size(273, 25);
            this.checkBoxPanelCalcView.TabIndex = 0;
            this.checkBoxPanelCalcView.Text = "Показывать панель рассчёта";
            this.checkBoxPanelCalcView.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelCalcView
            // 
            this.tableLayoutPanelCalcView.ColumnCount = 2;
            this.tableLayoutPanelCalcView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelCalcView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelCalcView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelCalcView.Controls.Add(this.checkBoxAutoOutput, 1, 0);
            this.tableLayoutPanelCalcView.Controls.Add(this.buttonOutput, 0, 1);
            this.tableLayoutPanelCalcView.Controls.Add(this.checkBoxEnter, 0, 0);
            this.tableLayoutPanelCalcView.Controls.Add(this.button3, 1, 1);
            this.tableLayoutPanelCalcView.Location = new System.Drawing.Point(3, 996);
            this.tableLayoutPanelCalcView.Name = "tableLayoutPanelCalcView";
            this.tableLayoutPanelCalcView.RowCount = 2;
            this.tableLayoutPanelCalcView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelCalcView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelCalcView.Size = new System.Drawing.Size(892, 100);
            this.tableLayoutPanelCalcView.TabIndex = 0;
            // 
            // checkBoxAutoOutput
            // 
            this.checkBoxAutoOutput.AutoSize = true;
            this.checkBoxAutoOutput.Checked = true;
            this.checkBoxAutoOutput.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAutoOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoOutput.Location = new System.Drawing.Point(449, 3);
            this.checkBoxAutoOutput.Name = "checkBoxAutoOutput";
            this.checkBoxAutoOutput.Size = new System.Drawing.Size(440, 44);
            this.checkBoxAutoOutput.TabIndex = 1;
            this.checkBoxAutoOutput.Text = "Вычислять A автоматически";
            this.checkBoxAutoOutput.UseVisualStyleBackColor = true;
            // 
            // buttonOutput
            // 
            this.buttonOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonOutput.Location = new System.Drawing.Point(3, 53);
            this.buttonOutput.Name = "buttonOutput";
            this.buttonOutput.Size = new System.Drawing.Size(440, 44);
            this.buttonOutput.TabIndex = 0;
            this.buttonOutput.Text = "Вывести значение";
            this.buttonOutput.UseVisualStyleBackColor = true;
            this.buttonOutput.Click += new System.EventHandler(this.buttonOutput_Click);
            // 
            // checkBoxEnter
            // 
            this.checkBoxEnter.AutoSize = true;
            this.checkBoxEnter.Checked = true;
            this.checkBoxEnter.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxEnter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxEnter.Location = new System.Drawing.Point(3, 3);
            this.checkBoxEnter.Name = "checkBoxEnter";
            this.checkBoxEnter.Size = new System.Drawing.Size(440, 44);
            this.checkBoxEnter.TabIndex = 0;
            this.checkBoxEnter.Text = "Вычислять A по клавише Enter";
            this.checkBoxEnter.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Location = new System.Drawing.Point(449, 53);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(440, 44);
            this.button3.TabIndex = 0;
            this.button3.Text = "Вычислить A";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.buttonOutput_Click);
            // 
            // checkBoxPanelRoundView
            // 
            this.checkBoxPanelRoundView.AutoSize = true;
            this.checkBoxPanelRoundView.Location = new System.Drawing.Point(3, 1102);
            this.checkBoxPanelRoundView.Name = "checkBoxPanelRoundView";
            this.checkBoxPanelRoundView.Size = new System.Drawing.Size(300, 25);
            this.checkBoxPanelRoundView.TabIndex = 0;
            this.checkBoxPanelRoundView.Text = "Показывать панель округлений";
            this.checkBoxPanelRoundView.UseVisualStyleBackColor = true;
            // 
            // tableLayoutViewFx
            // 
            this.tableLayoutViewFx.ColumnCount = 2;
            this.tableLayoutViewFx.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutViewFx.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutViewFx.Controls.Add(this.buttonRound, 0, 1);
            this.tableLayoutViewFx.Controls.Add(this.numericRound, 0, 0);
            this.tableLayoutViewFx.Controls.Add(this.checkBoxAutoRound, 1, 0);
            this.tableLayoutViewFx.Location = new System.Drawing.Point(3, 1133);
            this.tableLayoutViewFx.Name = "tableLayoutViewFx";
            this.tableLayoutViewFx.RowCount = 2;
            this.tableLayoutViewFx.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutViewFx.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutViewFx.Size = new System.Drawing.Size(892, 100);
            this.tableLayoutViewFx.TabIndex = 0;
            // 
            // buttonRound
            // 
            this.tableLayoutViewFx.SetColumnSpan(this.buttonRound, 2);
            this.buttonRound.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRound.Location = new System.Drawing.Point(3, 53);
            this.buttonRound.Name = "buttonRound";
            this.buttonRound.Size = new System.Drawing.Size(886, 44);
            this.buttonRound.TabIndex = 1;
            this.buttonRound.Text = "Округлить результат";
            this.buttonRound.UseVisualStyleBackColor = true;
            this.buttonRound.Click += new System.EventHandler(this.buttonRound_Click);
            // 
            // numericRound
            // 
            this.numericRound.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericRound.Location = new System.Drawing.Point(3, 3);
            this.numericRound.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numericRound.Name = "numericRound";
            this.numericRound.Size = new System.Drawing.Size(440, 34);
            this.numericRound.TabIndex = 0;
            this.numericRound.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // checkBoxAutoRound
            // 
            this.checkBoxAutoRound.AutoSize = true;
            this.checkBoxAutoRound.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoRound.Location = new System.Drawing.Point(449, 3);
            this.checkBoxAutoRound.Name = "checkBoxAutoRound";
            this.checkBoxAutoRound.Size = new System.Drawing.Size(440, 44);
            this.checkBoxAutoRound.TabIndex = 2;
            this.checkBoxAutoRound.Text = "Автоматически";
            this.checkBoxAutoRound.UseVisualStyleBackColor = true;
            // 
            // checkBoxPanelWriteView
            // 
            this.checkBoxPanelWriteView.AutoSize = true;
            this.checkBoxPanelWriteView.Location = new System.Drawing.Point(3, 1239);
            this.checkBoxPanelWriteView.Name = "checkBoxPanelWriteView";
            this.checkBoxPanelWriteView.Size = new System.Drawing.Size(380, 25);
            this.checkBoxPanelWriteView.TabIndex = 1;
            this.checkBoxPanelWriteView.Text = "Показывать панель вычисления и записи";
            this.checkBoxPanelWriteView.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelWriteView
            // 
            this.tableLayoutPanelWriteView.ColumnCount = 2;
            this.tableLayoutPanelWriteView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelWriteView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelWriteView.Controls.Add(this.groupBox3, 0, 0);
            this.tableLayoutPanelWriteView.Controls.Add(this.menuStrip2, 0, 1);
            this.tableLayoutPanelWriteView.Controls.Add(this.groupBox4, 1, 0);
            this.tableLayoutPanelWriteView.Location = new System.Drawing.Point(3, 1270);
            this.tableLayoutPanelWriteView.Name = "tableLayoutPanelWriteView";
            this.tableLayoutPanelWriteView.RowCount = 2;
            this.tableLayoutPanelWriteView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelWriteView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanelWriteView.Size = new System.Drawing.Size(892, 229);
            this.tableLayoutPanelWriteView.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel4);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(440, 173);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "A";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.checkBoxAutoWrite, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.buttonSet, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.button5, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.menuStrip3, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.button6, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 4;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.99813F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(434, 140);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // checkBoxAutoWrite
            // 
            this.checkBoxAutoWrite.AutoSize = true;
            this.checkBoxAutoWrite.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoWrite.Location = new System.Drawing.Point(220, 73);
            this.checkBoxAutoWrite.Name = "checkBoxAutoWrite";
            this.checkBoxAutoWrite.Size = new System.Drawing.Size(211, 29);
            this.checkBoxAutoWrite.TabIndex = 3;
            this.checkBoxAutoWrite.Text = "Автозапись";
            this.checkBoxAutoWrite.UseVisualStyleBackColor = true;
            // 
            // buttonSet
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.buttonSet, 2);
            this.buttonSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSet.Location = new System.Drawing.Point(3, 108);
            this.buttonSet.Name = "buttonSet";
            this.buttonSet.Size = new System.Drawing.Size(428, 29);
            this.buttonSet.TabIndex = 2;
            this.buttonSet.Text = "Выполнить оба действия";
            this.buttonSet.UseVisualStyleBackColor = true;
            this.buttonSet.Click += new System.EventHandler(this.buttonSet_Click);
            // 
            // button5
            // 
            this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button5.Location = new System.Drawing.Point(3, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(211, 29);
            this.button5.TabIndex = 0;
            this.button5.Text = "Вычислить";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.buttonOutput_Click);
            // 
            // menuStrip3
            // 
            this.menuStrip3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip3.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.записатьAToolStripMenuItem});
            this.menuStrip3.Location = new System.Drawing.Point(217, 0);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(217, 35);
            this.menuStrip3.TabIndex = 6;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // записатьAToolStripMenuItem
            // 
            this.записатьAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonWrite,
            this.buttonWriteMain,
            this.buttonWriteAToClipboard});
            this.записатьAToolStripMenuItem.Name = "записатьAToolStripMenuItem";
            this.записатьAToolStripMenuItem.Size = new System.Drawing.Size(99, 31);
            this.записатьAToolStripMenuItem.Text = "Записать";
            // 
            // buttonWrite
            // 
            this.buttonWrite.Name = "buttonWrite";
            this.buttonWrite.Size = new System.Drawing.Size(278, 26);
            this.buttonWrite.Text = "На предыдущее окно";
            this.buttonWrite.Click += new System.EventHandler(this.buttonWrite_Click);
            // 
            // buttonWriteMain
            // 
            this.buttonWriteMain.Name = "buttonWriteMain";
            this.buttonWriteMain.Size = new System.Drawing.Size(278, 26);
            this.buttonWriteMain.Text = "На главный экран";
            this.buttonWriteMain.Click += new System.EventHandler(this.buttonWriteMain_Click);
            // 
            // buttonWriteAToClipboard
            // 
            this.buttonWriteAToClipboard.Name = "buttonWriteAToClipboard";
            this.buttonWriteAToClipboard.Size = new System.Drawing.Size(278, 26);
            this.buttonWriteAToClipboard.Text = "В буфер обмена";
            this.buttonWriteAToClipboard.Click += new System.EventHandler(this.buttonWriteAToClipboard_Click);
            // 
            // button6
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.button6, 2);
            this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button6.Location = new System.Drawing.Point(3, 38);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(428, 29);
            this.button6.TabIndex = 7;
            this.button6.Text = "Записать на предыдущее окно";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.buttonWrite_Click);
            // 
            // menuStrip2
            // 
            this.tableLayoutPanelWriteView.SetColumnSpan(this.menuStrip2, 2);
            this.menuStrip2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip2.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вывестиToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 179);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(892, 50);
            this.menuStrip2.TabIndex = 5;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // вывестиToolStripMenuItem
            // 
            this.вывестиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aToolStripMenuItem,
            this.равенствоВыраженийToolStripMenuItem});
            this.вывестиToolStripMenuItem.Name = "вывестиToolStripMenuItem";
            this.вывестиToolStripMenuItem.Size = new System.Drawing.Size(99, 46);
            this.вывестиToolStripMenuItem.Text = "Записать";
            // 
            // aToolStripMenuItem
            // 
            this.aToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aToolStripMenuItem1,
            this.bToolStripMenuItem});
            this.aToolStripMenuItem.Name = "aToolStripMenuItem";
            this.aToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.aToolStripMenuItem.Text = "Значение/выражение";
            // 
            // aToolStripMenuItem1
            // 
            this.aToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.наПредыдущийЭкранToolStripMenuItem,
            this.наГлавныйЭкранToolStripMenuItem,
            this.вБуферОбменаToolStripMenuItem});
            this.aToolStripMenuItem1.Name = "aToolStripMenuItem1";
            this.aToolStripMenuItem1.Size = new System.Drawing.Size(106, 26);
            this.aToolStripMenuItem1.Text = "A";
            // 
            // наПредыдущийЭкранToolStripMenuItem
            // 
            this.наПредыдущийЭкранToolStripMenuItem.Name = "наПредыдущийЭкранToolStripMenuItem";
            this.наПредыдущийЭкранToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.наПредыдущийЭкранToolStripMenuItem.Text = "На предыдущий экран";
            this.наПредыдущийЭкранToolStripMenuItem.Click += new System.EventHandler(this.buttonWrite_Click);
            // 
            // наГлавныйЭкранToolStripMenuItem
            // 
            this.наГлавныйЭкранToolStripMenuItem.Name = "наГлавныйЭкранToolStripMenuItem";
            this.наГлавныйЭкранToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.наГлавныйЭкранToolStripMenuItem.Text = "На главный экран";
            this.наГлавныйЭкранToolStripMenuItem.Click += new System.EventHandler(this.buttonWriteMain_Click);
            // 
            // вБуферОбменаToolStripMenuItem
            // 
            this.вБуферОбменаToolStripMenuItem.Name = "вБуферОбменаToolStripMenuItem";
            this.вБуферОбменаToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.вБуферОбменаToolStripMenuItem.Text = "В буфер обмена";
            this.вБуферОбменаToolStripMenuItem.Click += new System.EventHandler(this.buttonWriteAToClipboard_Click);
            // 
            // bToolStripMenuItem
            // 
            this.bToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.наПредыдущийЭкранToolStripMenuItem1,
            this.наГлавныйЭкранToolStripMenuItem1,
            this.вБуферОбменаToolStripMenuItem1});
            this.bToolStripMenuItem.Name = "bToolStripMenuItem";
            this.bToolStripMenuItem.Size = new System.Drawing.Size(106, 26);
            this.bToolStripMenuItem.Text = "B";
            // 
            // наПредыдущийЭкранToolStripMenuItem1
            // 
            this.наПредыдущийЭкранToolStripMenuItem1.Name = "наПредыдущийЭкранToolStripMenuItem1";
            this.наПредыдущийЭкранToolStripMenuItem1.Size = new System.Drawing.Size(287, 26);
            this.наПредыдущийЭкранToolStripMenuItem1.Text = "На предыдущий экран";
            this.наПредыдущийЭкранToolStripMenuItem1.Click += new System.EventHandler(this.buttonWriteB_Click);
            // 
            // наГлавныйЭкранToolStripMenuItem1
            // 
            this.наГлавныйЭкранToolStripMenuItem1.Name = "наГлавныйЭкранToolStripMenuItem1";
            this.наГлавныйЭкранToolStripMenuItem1.Size = new System.Drawing.Size(287, 26);
            this.наГлавныйЭкранToolStripMenuItem1.Text = "На главный экран";
            this.наГлавныйЭкранToolStripMenuItem1.Click += new System.EventHandler(this.buttonWriteBMain_Click);
            // 
            // вБуферОбменаToolStripMenuItem1
            // 
            this.вБуферОбменаToolStripMenuItem1.Name = "вБуферОбменаToolStripMenuItem1";
            this.вБуферОбменаToolStripMenuItem1.Size = new System.Drawing.Size(287, 26);
            this.вБуферОбменаToolStripMenuItem1.Text = "В буфер обмена";
            this.вБуферОбменаToolStripMenuItem1.Click += new System.EventHandler(this.buttonWriteBToClipboard_Click);
            // 
            // равенствоВыраженийToolStripMenuItem
            // 
            this.равенствоВыраженийToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAequalsB1,
            this.buttonBequalsA1});
            this.равенствоВыраженийToolStripMenuItem.Name = "равенствоВыраженийToolStripMenuItem";
            this.равенствоВыраженийToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.равенствоВыраженийToolStripMenuItem.Text = "Равенство выражений";
            // 
            // buttonAequalsB1
            // 
            this.buttonAequalsB1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAequalsB,
            this.buttonAequalsBMain,
            this.buttonAequalsBToClipboard});
            this.buttonAequalsB1.Name = "buttonAequalsB1";
            this.buttonAequalsB1.Size = new System.Drawing.Size(130, 26);
            this.buttonAequalsB1.Text = "A=B";
            // 
            // buttonAequalsB
            // 
            this.buttonAequalsB.Name = "buttonAequalsB";
            this.buttonAequalsB.Size = new System.Drawing.Size(287, 26);
            this.buttonAequalsB.Text = "На предыдущий экран";
            this.buttonAequalsB.Click += new System.EventHandler(this.buttonAequalsB_Click);
            // 
            // buttonAequalsBMain
            // 
            this.buttonAequalsBMain.Name = "buttonAequalsBMain";
            this.buttonAequalsBMain.Size = new System.Drawing.Size(287, 26);
            this.buttonAequalsBMain.Text = "На главный экран";
            this.buttonAequalsBMain.Click += new System.EventHandler(this.buttonAequalsBMain_Click);
            // 
            // buttonAequalsBToClipboard
            // 
            this.buttonAequalsBToClipboard.Name = "buttonAequalsBToClipboard";
            this.buttonAequalsBToClipboard.Size = new System.Drawing.Size(287, 26);
            this.buttonAequalsBToClipboard.Text = "В буфер обмена";
            this.buttonAequalsBToClipboard.Click += new System.EventHandler(this.buttonAequalsBToClipboard_Click);
            // 
            // buttonBequalsA1
            // 
            this.buttonBequalsA1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonBequalsA,
            this.buttonBequalsAMain,
            this.buttonBequalsAToClipboard});
            this.buttonBequalsA1.Name = "buttonBequalsA1";
            this.buttonBequalsA1.Size = new System.Drawing.Size(130, 26);
            this.buttonBequalsA1.Text = "B=A";
            // 
            // buttonBequalsA
            // 
            this.buttonBequalsA.Name = "buttonBequalsA";
            this.buttonBequalsA.Size = new System.Drawing.Size(287, 26);
            this.buttonBequalsA.Text = "На предыдущий экран";
            this.buttonBequalsA.Click += new System.EventHandler(this.buttonBequalsA_Click);
            // 
            // buttonBequalsAMain
            // 
            this.buttonBequalsAMain.Name = "buttonBequalsAMain";
            this.buttonBequalsAMain.Size = new System.Drawing.Size(287, 26);
            this.buttonBequalsAMain.Text = "На главный экран";
            this.buttonBequalsAMain.Click += new System.EventHandler(this.buttonBequalsAMain_Click);
            // 
            // buttonBequalsAToClipboard
            // 
            this.buttonBequalsAToClipboard.Name = "buttonBequalsAToClipboard";
            this.buttonBequalsAToClipboard.Size = new System.Drawing.Size(287, 26);
            this.buttonBequalsAToClipboard.Text = "В буфер обмена";
            this.buttonBequalsAToClipboard.Click += new System.EventHandler(this.buttonBequalsAToClipboard_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tableLayoutPanel12);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(449, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(440, 173);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "B";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.buttonCalculateB, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.menuStrip4, 1, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(434, 140);
            this.tableLayoutPanel12.TabIndex = 0;
            // 
            // buttonCalculateB
            // 
            this.buttonCalculateB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalculateB.Location = new System.Drawing.Point(3, 3);
            this.buttonCalculateB.Name = "buttonCalculateB";
            this.buttonCalculateB.Size = new System.Drawing.Size(211, 64);
            this.buttonCalculateB.TabIndex = 8;
            this.buttonCalculateB.Text = "Вычислить B";
            this.buttonCalculateB.UseVisualStyleBackColor = true;
            this.buttonCalculateB.Click += new System.EventHandler(this.buttonCalculateB_Click);
            // 
            // menuStrip4
            // 
            this.menuStrip4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip4.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.записатьBToolStripMenuItem});
            this.menuStrip4.Location = new System.Drawing.Point(217, 0);
            this.menuStrip4.Name = "menuStrip4";
            this.menuStrip4.Size = new System.Drawing.Size(217, 70);
            this.menuStrip4.TabIndex = 20;
            this.menuStrip4.Text = "menuStrip4";
            // 
            // записатьBToolStripMenuItem
            // 
            this.записатьBToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonWriteB,
            this.buttonWriteBMain,
            this.buttonWriteBToClipboard});
            this.записатьBToolStripMenuItem.Name = "записатьBToolStripMenuItem";
            this.записатьBToolStripMenuItem.Size = new System.Drawing.Size(114, 66);
            this.записатьBToolStripMenuItem.Text = "Записать B";
            // 
            // buttonWriteB
            // 
            this.buttonWriteB.Name = "buttonWriteB";
            this.buttonWriteB.Size = new System.Drawing.Size(278, 26);
            this.buttonWriteB.Text = "На предыдущее окно";
            this.buttonWriteB.Click += new System.EventHandler(this.buttonWriteB_Click);
            // 
            // buttonWriteBMain
            // 
            this.buttonWriteBMain.Name = "buttonWriteBMain";
            this.buttonWriteBMain.Size = new System.Drawing.Size(278, 26);
            this.buttonWriteBMain.Text = "На главный экран";
            this.buttonWriteBMain.Click += new System.EventHandler(this.buttonWriteBMain_Click);
            // 
            // buttonWriteBToClipboard
            // 
            this.buttonWriteBToClipboard.Name = "buttonWriteBToClipboard";
            this.buttonWriteBToClipboard.Size = new System.Drawing.Size(278, 26);
            this.buttonWriteBToClipboard.Text = "В буфер обмена";
            this.buttonWriteBToClipboard.Click += new System.EventHandler(this.buttonWriteBToClipboard_Click);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 3;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.53363F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.57848F));
            this.tableLayoutPanel13.Controls.Add(this.TextBuffer, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.memoryBuffer, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel7, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel10, 2, 0);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 1505);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(892, 140);
            this.tableLayoutPanel13.TabIndex = 1;
            // 
            // TextBuffer
            // 
            this.TextBuffer.AllowNegative = true;
            this.TextBuffer.ClearingByReadonly = true;
            this.TextBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBuffer.EnterAllow = true;
            this.TextBuffer.Location = new System.Drawing.Point(4, 4);
            this.TextBuffer.Margin = new System.Windows.Forms.Padding(4);
            this.TextBuffer.MultiLine = false;
            this.TextBuffer.Name = "TextBuffer";
            this.TextBuffer.NoReadOnly = false;
            this.TextBuffer.ReadOnly = true;
            this.TextBuffer.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBuffer.SelectionStart = 0;
            this.TextBuffer.Size = new System.Drawing.Size(415, 82);
            this.TextBuffer.TabIndex = 11;
            this.TextBuffer.TextWithLineBreaks = "";
            this.TextBuffer.Title = "Буфер";
            this.TextBuffer.UseSystemPasswordChar = false;
            this.TextBuffer.Value = "";
            this.TextBuffer.ValueBackColor = System.Drawing.Color.White;
            this.TextBuffer.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.TextBuffer.ValueText = "";
            this.TextBuffer.ValueType = TableAIS.TextTitleType.Text;
            this.TextBuffer.ValueWithLineBreaks = "";
            this.TextBuffer.VisibleOK = false;
            // 
            // memoryBuffer
            // 
            this.memoryBuffer.BorderStule = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tableLayoutPanel13.SetColumnSpan(this.memoryBuffer, 3);
            this.memoryBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memoryBuffer.Few = null;
            this.memoryBuffer.FewInvoke = false;
            this.memoryBuffer.Historytext = "История";
            this.memoryBuffer.Location = new System.Drawing.Point(0, 90);
            this.memoryBuffer.Margin = new System.Windows.Forms.Padding(0);
            this.memoryBuffer.MinesText = "M-";
            this.memoryBuffer.Name = "memoryBuffer";
            this.memoryBuffer.PlusText = "M+";
            this.memoryBuffer.RText = "MR";
            this.memoryBuffer.Size = new System.Drawing.Size(892, 50);
            this.memoryBuffer.TabIndex = 16;
            this.memoryBuffer.WriteAndClearText = "MRC";
            this.memoryBuffer.WriteText = "->M";
            this.memoryBuffer.Write += new System.Action(this.memoryBuffer_Write);
            this.memoryBuffer.Plus += new System.Action(this.memoryBuffer_Plus);
            this.memoryBuffer.Mines += new System.Action(this.memoryBuffer_Mines);
            this.memoryBuffer.MR += new System.Action(this.memoryBuffer_MR);
            this.memoryBuffer.History += new System.Action(this.memoryB_History);
            this.memoryBuffer.WriteClear += new System.Action(this.memoryBuffer_WriteClear);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.buttonABuffer, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.buttonBufferB, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonBBuffer, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonBufferA, 0, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(426, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(216, 84);
            this.tableLayoutPanel7.TabIndex = 14;
            // 
            // buttonABuffer
            // 
            this.buttonABuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonABuffer.Location = new System.Drawing.Point(111, 45);
            this.buttonABuffer.Name = "buttonABuffer";
            this.buttonABuffer.Size = new System.Drawing.Size(102, 36);
            this.buttonABuffer.TabIndex = 3;
            this.buttonABuffer.Text = ">A";
            this.buttonABuffer.UseVisualStyleBackColor = true;
            this.buttonABuffer.Click += new System.EventHandler(this.buttonABuffer_Click);
            // 
            // buttonBufferB
            // 
            this.buttonBufferB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBufferB.Location = new System.Drawing.Point(3, 3);
            this.buttonBufferB.Name = "buttonBufferB";
            this.buttonBufferB.Size = new System.Drawing.Size(102, 36);
            this.buttonBufferB.TabIndex = 0;
            this.buttonBufferB.Text = "B>";
            this.buttonBufferB.UseVisualStyleBackColor = true;
            this.buttonBufferB.Click += new System.EventHandler(this.buttonBufferB_Click);
            // 
            // buttonBBuffer
            // 
            this.buttonBBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBBuffer.Location = new System.Drawing.Point(111, 3);
            this.buttonBBuffer.Name = "buttonBBuffer";
            this.buttonBBuffer.Size = new System.Drawing.Size(102, 36);
            this.buttonBBuffer.TabIndex = 2;
            this.buttonBBuffer.Text = ">B";
            this.buttonBBuffer.UseVisualStyleBackColor = true;
            this.buttonBBuffer.Click += new System.EventHandler(this.buttonBBuffer_Click);
            // 
            // buttonBufferA
            // 
            this.buttonBufferA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBufferA.Location = new System.Drawing.Point(3, 45);
            this.buttonBufferA.Name = "buttonBufferA";
            this.buttonBufferA.Size = new System.Drawing.Size(102, 36);
            this.buttonBufferA.TabIndex = 1;
            this.buttonBufferA.Text = "A>";
            this.buttonBufferA.UseVisualStyleBackColor = true;
            this.buttonBufferA.Click += new System.EventHandler(this.buttonBufferA_Click);
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Controls.Add(this.buttonRunHelpToBufer, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.buttonRunBuferToHelp, 0, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(648, 3);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(241, 84);
            this.tableLayoutPanel10.TabIndex = 25;
            // 
            // buttonRunHelpToBufer
            // 
            this.buttonRunHelpToBufer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRunHelpToBufer.Location = new System.Drawing.Point(3, 45);
            this.buttonRunHelpToBufer.Name = "buttonRunHelpToBufer";
            this.buttonRunHelpToBufer.Size = new System.Drawing.Size(235, 36);
            this.buttonRunHelpToBufer.TabIndex = 1;
            this.buttonRunHelpToBufer.Text = ">Help";
            this.buttonRunHelpToBufer.UseVisualStyleBackColor = true;
            this.buttonRunHelpToBufer.Click += new System.EventHandler(this.buttonRunHelpToBufer_Click);
            // 
            // buttonRunBuferToHelp
            // 
            this.buttonRunBuferToHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRunBuferToHelp.Location = new System.Drawing.Point(3, 3);
            this.buttonRunBuferToHelp.Name = "buttonRunBuferToHelp";
            this.buttonRunBuferToHelp.Size = new System.Drawing.Size(235, 36);
            this.buttonRunBuferToHelp.TabIndex = 0;
            this.buttonRunBuferToHelp.Text = "Help>";
            this.buttonRunBuferToHelp.UseVisualStyleBackColor = true;
            this.buttonRunBuferToHelp.Click += new System.EventHandler(this.buttonRunBuferToHelp_Click);
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.53363F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.55157F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.80269F));
            this.tableLayoutPanel14.Controls.Add(this.textBoxHelp, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel8, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel9, 2, 0);
            this.tableLayoutPanel14.Controls.Add(this.memoryHelp, 0, 1);
            this.tableLayoutPanel14.Controls.Add(this.buttonCalcHelp, 2, 1);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 1651);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 2;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(892, 134);
            this.tableLayoutPanel14.TabIndex = 1;
            // 
            // textBoxHelp
            // 
            this.textBoxHelp.AllowNegative = true;
            this.textBoxHelp.ClearingByReadonly = false;
            this.textBoxHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxHelp.EnterAllow = true;
            this.textBoxHelp.Location = new System.Drawing.Point(4, 4);
            this.textBoxHelp.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxHelp.MultiLine = false;
            this.textBoxHelp.Name = "textBoxHelp";
            this.textBoxHelp.NoReadOnly = true;
            this.textBoxHelp.ReadOnly = false;
            this.textBoxHelp.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxHelp.SelectionStart = 0;
            this.textBoxHelp.Size = new System.Drawing.Size(416, 76);
            this.textBoxHelp.TabIndex = 22;
            this.textBoxHelp.TextWithLineBreaks = "";
            this.textBoxHelp.Title = "Вспомогательное поле (Help)";
            this.textBoxHelp.UseSystemPasswordChar = false;
            this.textBoxHelp.Value = "";
            this.textBoxHelp.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxHelp.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxHelp.ValueText = "";
            this.textBoxHelp.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxHelp.ValueWithLineBreaks = "";
            this.textBoxHelp.VisibleOK = false;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.buttonRunHelpToB, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.buttonRunBToHelp, 0, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(427, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(213, 78);
            this.tableLayoutPanel8.TabIndex = 23;
            // 
            // buttonRunHelpToB
            // 
            this.buttonRunHelpToB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRunHelpToB.Location = new System.Drawing.Point(3, 42);
            this.buttonRunHelpToB.Name = "buttonRunHelpToB";
            this.buttonRunHelpToB.Size = new System.Drawing.Size(207, 33);
            this.buttonRunHelpToB.TabIndex = 1;
            this.buttonRunHelpToB.Text = ">B(формула)";
            this.buttonRunHelpToB.UseVisualStyleBackColor = true;
            this.buttonRunHelpToB.Click += new System.EventHandler(this.buttonRunHelpToB_Click);
            // 
            // buttonRunBToHelp
            // 
            this.buttonRunBToHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRunBToHelp.Location = new System.Drawing.Point(3, 3);
            this.buttonRunBToHelp.Name = "buttonRunBToHelp";
            this.buttonRunBToHelp.Size = new System.Drawing.Size(207, 33);
            this.buttonRunBToHelp.TabIndex = 0;
            this.buttonRunBToHelp.Text = "B(формула)>";
            this.buttonRunBToHelp.UseVisualStyleBackColor = true;
            this.buttonRunBToHelp.Click += new System.EventHandler(this.buttonRunBToHelp_Click);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.buttonRunAToHelp, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.buttonRunHelpToA, 1, 1);
            this.tableLayoutPanel9.Controls.Add(this.buttonRunHelpToB1, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.buttonRunB1ToHelp, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(646, 3);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(243, 78);
            this.tableLayoutPanel9.TabIndex = 24;
            // 
            // buttonRunAToHelp
            // 
            this.buttonRunAToHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRunAToHelp.Location = new System.Drawing.Point(3, 42);
            this.buttonRunAToHelp.Name = "buttonRunAToHelp";
            this.buttonRunAToHelp.Size = new System.Drawing.Size(115, 33);
            this.buttonRunAToHelp.TabIndex = 3;
            this.buttonRunAToHelp.Text = "A>";
            this.buttonRunAToHelp.UseVisualStyleBackColor = true;
            this.buttonRunAToHelp.Click += new System.EventHandler(this.buttonRunAToHelp_Click);
            // 
            // buttonRunHelpToA
            // 
            this.buttonRunHelpToA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRunHelpToA.Location = new System.Drawing.Point(124, 42);
            this.buttonRunHelpToA.Name = "buttonRunHelpToA";
            this.buttonRunHelpToA.Size = new System.Drawing.Size(116, 33);
            this.buttonRunHelpToA.TabIndex = 2;
            this.buttonRunHelpToA.Text = ">A";
            this.buttonRunHelpToA.UseVisualStyleBackColor = true;
            this.buttonRunHelpToA.Click += new System.EventHandler(this.buttonRunHelpToA_Click);
            // 
            // buttonRunHelpToB1
            // 
            this.buttonRunHelpToB1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRunHelpToB1.Location = new System.Drawing.Point(124, 3);
            this.buttonRunHelpToB1.Name = "buttonRunHelpToB1";
            this.buttonRunHelpToB1.Size = new System.Drawing.Size(116, 33);
            this.buttonRunHelpToB1.TabIndex = 1;
            this.buttonRunHelpToB1.Text = ">B";
            this.buttonRunHelpToB1.UseVisualStyleBackColor = true;
            this.buttonRunHelpToB1.Click += new System.EventHandler(this.buttonRunHelpToB1_Click);
            // 
            // buttonRunB1ToHelp
            // 
            this.buttonRunB1ToHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRunB1ToHelp.Location = new System.Drawing.Point(3, 3);
            this.buttonRunB1ToHelp.Name = "buttonRunB1ToHelp";
            this.buttonRunB1ToHelp.Size = new System.Drawing.Size(115, 33);
            this.buttonRunB1ToHelp.TabIndex = 0;
            this.buttonRunB1ToHelp.Text = "B>";
            this.buttonRunB1ToHelp.UseVisualStyleBackColor = true;
            this.buttonRunB1ToHelp.Click += new System.EventHandler(this.buttonRunB1ToHelp_Click);
            // 
            // memoryHelp
            // 
            this.memoryHelp.BorderStule = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tableLayoutPanel14.SetColumnSpan(this.memoryHelp, 2);
            this.memoryHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memoryHelp.Few = null;
            this.memoryHelp.FewInvoke = false;
            this.memoryHelp.Historytext = "История";
            this.memoryHelp.Location = new System.Drawing.Point(0, 84);
            this.memoryHelp.Margin = new System.Windows.Forms.Padding(0);
            this.memoryHelp.MinesText = "M-";
            this.memoryHelp.Name = "memoryHelp";
            this.memoryHelp.PlusText = "M+";
            this.memoryHelp.RText = "MR";
            this.memoryHelp.Size = new System.Drawing.Size(643, 50);
            this.memoryHelp.TabIndex = 25;
            this.memoryHelp.WriteAndClearText = "MRC";
            this.memoryHelp.WriteText = "->M";
            this.memoryHelp.Write += new System.Action(this.memoryHelp_Write);
            this.memoryHelp.Plus += new System.Action(this.memoryHelp_Plus);
            this.memoryHelp.Mines += new System.Action(this.memoryHelp_Mines);
            this.memoryHelp.MR += new System.Action(this.memoryHelp_MR);
            this.memoryHelp.History += new System.Action(this.memoryB_History);
            this.memoryHelp.WriteClear += new System.Action(this.memoryHelp_WriteClear);
            // 
            // buttonCalcHelp
            // 
            this.buttonCalcHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalcHelp.Location = new System.Drawing.Point(646, 87);
            this.buttonCalcHelp.Name = "buttonCalcHelp";
            this.buttonCalcHelp.Size = new System.Drawing.Size(243, 44);
            this.buttonCalcHelp.TabIndex = 26;
            this.buttonCalcHelp.Text = "Вычислить Help";
            this.buttonCalcHelp.UseVisualStyleBackColor = true;
            this.buttonCalcHelp.Click += new System.EventHandler(this.buttonCalcHelp_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 1788);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(792, 105);
            this.label2.TabIndex = 0;
            this.label2.Text = resources.GetString("label2.Text");
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelInfoCount
            // 
            this.labelInfoCount.AutoSize = true;
            this.labelInfoCount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelInfoCount.Location = new System.Drawing.Point(159, 0);
            this.labelInfoCount.Name = "labelInfoCount";
            this.labelInfoCount.Size = new System.Drawing.Size(256, 40);
            this.labelInfoCount.TabIndex = 2;
            this.labelInfoCount.Text = "label1";
            this.labelInfoCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 2;
            this.tableLayoutPanel2.SetColumnSpan(this.tableLayoutPanel24, 2);
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel24.Controls.Add(this.button10, 0, 0);
            this.tableLayoutPanel24.Controls.Add(this.button14, 1, 0);
            this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(421, 3);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(509, 34);
            this.tableLayoutPanel24.TabIndex = 9;
            // 
            // button10
            // 
            this.button10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button10.Location = new System.Drawing.Point(3, 3);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(248, 28);
            this.button10.TabIndex = 3;
            this.button10.Text = "Список функций";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.buttonInputFeacher_Click);
            // 
            // button14
            // 
            this.button14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button14.Location = new System.Drawing.Point(257, 3);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(249, 28);
            this.button14.TabIndex = 8;
            this.button14.Text = "График функции";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.buttonRunGrafics_Click);
            // 
            // button16
            // 
            this.button16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button16.Location = new System.Drawing.Point(418, 40);
            this.button16.Margin = new System.Windows.Forms.Padding(0);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(236, 51);
            this.button16.TabIndex = 10;
            this.button16.Text = "Интерактивное редактирование выражения";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.buttonInteractiveEdit_Click);
            // 
            // openFileCalculator
            // 
            this.openFileCalculator.FileName = "openFileDialog1";
            // 
            // timerViewFx
            // 
            this.timerViewFx.Enabled = true;
            this.timerViewFx.Tick += new System.EventHandler(this.timerViewFx_Tick);
            // 
            // CalculatorString
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(933, 553);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(700, 440);
            this.Name = "CalculatorString";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Калькулятор";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel25.ResumeLayout(false);
            this.flowResizeMain.ResumeLayout(false);
            this.flowResizeMain.PerformLayout();
            this.groupBoxImportFx.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.groupBoxRunC.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel16.PerformLayout();
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.menuStrip8.ResumeLayout(false);
            this.menuStrip8.PerformLayout();
            this.tableLayoutPanelFile.ResumeLayout(false);
            this.tableLayoutPanelFile.PerformLayout();
            this.menuStrip7.ResumeLayout(false);
            this.menuStrip7.PerformLayout();
            this.tableLayoutPanelInputBView.ResumeLayout(false);
            this.tableLayoutPanelInputBView.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tableLayoutPanelCorrectView.ResumeLayout(false);
            this.tableLayoutPanelCorrectView.PerformLayout();
            this.menuStrip5.ResumeLayout(false);
            this.menuStrip5.PerformLayout();
            this.menuStrip6.ResumeLayout(false);
            this.menuStrip6.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanelCalcView.ResumeLayout(false);
            this.tableLayoutPanelCalcView.PerformLayout();
            this.tableLayoutViewFx.ResumeLayout(false);
            this.tableLayoutViewFx.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericRound)).EndInit();
            this.tableLayoutPanelWriteView.ResumeLayout(false);
            this.tableLayoutPanelWriteView.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.menuStrip4.ResumeLayout(false);
            this.menuStrip4.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel24.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBoxOutput;
        private System.Windows.Forms.TextBox textBoxInput;
        private System.Windows.Forms.Button buttonClearInput;
        private System.Windows.Forms.Button buttonClearOutput;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonClearAll;
        private System.Windows.Forms.Button buttonOutput;
        private System.Windows.Forms.Button buttonSet;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.NumericUpDown numericRound;
        private System.Windows.Forms.Button buttonRound;
        private System.Windows.Forms.CheckBox checkBoxAutoRound;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBoxAutoWrite;
        private System.Windows.Forms.Button buttonKeyBord;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem buttonMenuCalculator;
        private System.Windows.Forms.ToolStripMenuItem buttonTimer;
        private System.Windows.Forms.ToolStripMenuItem buttonGetSavedSeconds;
        private System.Windows.Forms.Button buttonCalculateB;
        private System.Windows.Forms.ToolStripMenuItem buttonFromMainForm;
        private TextBoxWithTitle TextBuffer;
        private System.Windows.Forms.Button buttonBufferB;
        private System.Windows.Forms.Button buttonBufferA;
        private System.Windows.Forms.Button buttonBBuffer;
        private System.Windows.Forms.Button buttonABuffer;
        private Controls.MemoryCalculateControl memoryB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private Controls.MemoryCalculateControl memoryA;
        private Controls.MemoryCalculateControl memoryBuffer;
        private System.Windows.Forms.Button buttonMemory;
        private System.Windows.Forms.CheckBox checkBoxEnter;
        private System.Windows.Forms.CheckBox checkBoxAutoOutput;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem вывестиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem равенствоВыраженийToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAequalsB1;
        private System.Windows.Forms.ToolStripMenuItem buttonBequalsA1;
        private System.Windows.Forms.ToolStripMenuItem buttonIntCalculator;
        private System.Windows.Forms.ToolStripMenuItem buttonFromMainFormReal;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem записатьAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonWrite;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteMain;
        private System.Windows.Forms.MenuStrip menuStrip4;
        private System.Windows.Forms.ToolStripMenuItem записатьBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteB;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteBMain;
        private System.Windows.Forms.ToolStripMenuItem buttonAequalsB;
        private System.Windows.Forms.ToolStripMenuItem buttonAequalsBMain;
        private System.Windows.Forms.ToolStripMenuItem buttonBequalsA;
        private System.Windows.Forms.ToolStripMenuItem buttonBequalsAMain;
        private System.Windows.Forms.ToolStripMenuItem наПредыдущийЭкранToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem наГлавныйЭкранToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem наПредыдущийЭкранToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem наГлавныйЭкранToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteBToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteAToClipboard;
        private System.Windows.Forms.ToolStripMenuItem вБуферОбменаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вБуферОбменаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonAequalsBToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonBequalsAToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonBFromClipboard;
        private FlowResize flowResizeMain;
        private TextBoxWithTitle textBoxHelp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Button buttonRunBToHelp;
        private System.Windows.Forms.Button buttonRunHelpToB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Button buttonRunB1ToHelp;
        private System.Windows.Forms.Button buttonRunHelpToB1;
        private System.Windows.Forms.Button buttonRunAToHelp;
        private System.Windows.Forms.Button buttonRunHelpToA;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Button buttonRunHelpToBufer;
        private System.Windows.Forms.Button buttonRunBuferToHelp;
        private System.Windows.Forms.Button buttonRunGrafics;
        private System.Windows.Forms.MenuStrip menuStrip5;
        private System.Windows.Forms.ToolStripMenuItem исправитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonChangeFunc1;
        private System.Windows.Forms.ToolStripMenuItem buttonChengeBaskets;
        private System.Windows.Forms.ToolStripMenuItem buttonAddBaskets;
        private System.Windows.Forms.ToolStripMenuItem buttonDropBaskets;
        private System.Windows.Forms.ToolStripMenuItem другаяОбработкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryCode;
        private System.Windows.Forms.ToolStripMenuItem buttonToVectorCalculator;
        private System.Windows.Forms.ToolStripMenuItem простойКалькуляторToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonInputFeacher;
        private System.Windows.Forms.ToolStripMenuItem toolStripInputFunc;
        private System.Windows.Forms.ToolStripMenuItem buttonListCalculator;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Timer timerView;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelCalcView;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.CheckBox checkBoxPanelCalcView;
        private System.Windows.Forms.TableLayoutPanel tableLayoutViewFx;
        private System.Windows.Forms.CheckBox checkBoxPanelRoundView;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWriteView;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.CheckBox checkBoxPanelWriteView;
        private System.Windows.Forms.CheckBox checkBoxFlagsView;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private Controls.MemoryCalculateControl memoryHelp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelInputBView;
        private System.Windows.Forms.CheckBox checkBoxInputBView;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.CheckBox checkBoxCorrectView;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelCorrectView;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.MenuStrip menuStrip6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.Label labelInfoCount;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.CheckBox checkBoxShowFile;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelFile;
        private System.Windows.Forms.SaveFileDialog saveFileCalculator;
        private System.Windows.Forms.OpenFileDialog openFileCalculator;
        private System.Windows.Forms.Button buttonSaveFile;
        private System.Windows.Forms.Button buttonLoadFile;
        private System.Windows.Forms.MenuStrip menuStrip7;
        private System.Windows.Forms.ToolStripMenuItem обменСГлавнымЭкраномToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripJsonDropVariants;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonLastWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonMainWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonClipBoard;
        private System.Windows.Forms.CheckBox checkBoxViewFx;
        private System.Windows.Forms.GroupBox groupBoxImportFx;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private TextBoxWithTitle textBoxViewFx;
        private System.Windows.Forms.Timer timerViewFx;
        private System.Windows.Forms.Button button11;
        private TextBoxWithTitle textBoxFunctionConst;
        private TextBoxWithTitle textBoxFc;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Button buttonAddFunctionToC;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.RadioButton radioButtonC;
        private System.Windows.Forms.RadioButton radioButtonFc;
        private System.Windows.Forms.GroupBox groupBoxRunC;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.RadioButton radioButtonExportC;
        private System.Windows.Forms.RadioButton radioButtonImportC;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.CheckBox checkBoxAutoFc;
        private System.Windows.Forms.Button buttonCalcFc;
        private System.Windows.Forms.Button buttonCalcHelp;
        private System.Windows.Forms.CheckBox checkBoxEnterFc;
        private System.Windows.Forms.Button buttonCalcC;
        private System.Windows.Forms.MenuStrip menuStrip8;
        private System.Windows.Forms.ToolStripMenuItem исправитьCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddBasketsC;
        private System.Windows.Forms.ToolStripMenuItem buttonDropBasketsC;
        private System.Windows.Forms.ToolStripMenuItem buttonChangeBasketsC;
        private System.Windows.Forms.ToolStripMenuItem buttonDropVariableC;
        private System.Windows.Forms.ToolStripMenuItem вводВыводToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonCB;
        private System.Windows.Forms.ToolStripMenuItem buttonCA;
        private System.Windows.Forms.ToolStripMenuItem buttonBufferC;
        private System.Windows.Forms.Button buttonComputeFc;
        private System.Windows.Forms.ToolStripMenuItem buttonHelpC;
        private System.Windows.Forms.ToolStripMenuItem cИлиFCВыборОбменСToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonComputeC;
        private System.Windows.Forms.ToolStripMenuItem buttonClipBoardC;
        private System.Windows.Forms.ToolStripMenuItem buttonLastWindowC;
        private System.Windows.Forms.ToolStripMenuItem buttonMainWindowC;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button buttonScrollDown;
        private System.Windows.Forms.Button buttonScrollUp;
        private System.Windows.Forms.Button buttonScrollUp1;
        private System.Windows.Forms.Button buttonScrollDown1;
        private System.Windows.Forms.Button buttonScrollMin;
        private System.Windows.Forms.Button buttonScrollMax;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Button buttonCalcB;
        private System.Windows.Forms.Button buttonCalcA;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.CheckBox checkBoxAutoCalcA;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.ToolStripMenuItem buttonTestChangeBaskets;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenConsts1;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenConsts;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenVariables;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenVariablesAnsConsts;
        private System.Windows.Forms.ToolStripMenuItem buttonTestCalc;
        private System.Windows.Forms.Button buttonCalcATest;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.ToolStripMenuItem buttonInteractiveEdit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.CheckBox checkBoxFxOutput;
        private System.Windows.Forms.Button buttonCopyBCalcB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Button buttonPastBFromBCalcB;
        private System.Windows.Forms.Button buttonPastCalcBFromBCalcB;
    }
}