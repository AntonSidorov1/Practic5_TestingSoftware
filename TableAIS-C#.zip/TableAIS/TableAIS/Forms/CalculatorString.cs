﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using TableAIS.Controls;

namespace TableAIS
{
    

   

    public partial class CalculatorString : Form
    {
        int JsonDropVariantIndex
        {
            get
            {
                return toolStripJsonDropVariants.SelectedIndex;
            }
            set
            {
                toolStripJsonDropVariants.SelectedIndex = value;
            }
        }

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;


        public double NumberInputText
        {
            get
            {
                return InputCalculateTest(textBoxInput.Text);
                //return InputCalculate(textBoxInput.Text);

            }
            set
            {
                textBoxInput.Text = value.ToString();
            }
        }

        public double InputCalculateTest(string input)
        {
            return MyCalculate.CalculateConvertToPostphics(input, A, GetHelpNumber(), Buffer);
        }

        public double InputCalculate(string input)
        {
            return InputCalculate(input, A, Buffer, GetHelpNumber());
        }

        public static double InputCalculate(string input, double A, double buffer, string numberHelp)
        {
            input = input.ToLower();
            input = input.Trim();
            input = input.Replace('.', ',');
            input = input.Trim();
            //input = input.Replace("π", "pi");
            //input = input.Replace("pi", Math.PI.ToString());
            
            //input = input.Replace("e", Math.E.ToString());
            if (double.TryParse(input, out double number))
            {
                return number;
            }

            //string formule = input.ToUpper().Replace("A", $"({A})");
                        string formule = input.Replace("PI", Math.PI.ToString()).
                        //Replace("E", Math.E.ToString()).
                        Replace(',', '.').ToString();
            formule = formule.ToLower();
            double result = 0;
            // result = Convert.ToDouble(new DataTable().Compute(formule, null));
            result = MyCalculate.CalculateWithMemory(formule, $"{A}", $"{buffer}", numberHelp);

            return result;
        }

        public void CalculateB(string b)
        {
            TextNumberInput = InputCalculate(b);
        }

        public void CalculateB()
        {
            CalculateB(textBoxInput.Text);
        }

        public double TextNumberInput
        {
            get
            {
                try
                {
                    return NumberInputText;
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                NumberInputText = value;
            }
        }

        public double B
        {
            get => TextNumberInput;
            set => TextNumberInput = value;
        }

        public double Buffer
        {
            get
            {
                try
                {
                    return double.Parse(TextBuffer.Value);
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                TextBuffer.Value = value.ToString();
            }
        }

        public void SetInput(double value, bool input = true)
        {
            if (input)
                TextNumberInput = value;
        }

        public void SetInput(string value, bool input = true)
        {
            if(input)
            {
                try
                {
                    InputCalculate(value);
                    textBoxInput.Text = value;
                }
                catch
                {
                    
                }
            }
        }


        public CalculatorString()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();
            //HistoryList = new List<string>();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;
            change = true;
        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public CalculatorString(Save save):this()
        {
            Save = save;
        }

        public CalculatorString(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            int funcCount = 0;
            try
            {
                funcCount = ValueHelper.GetFuncsList().Count;
            }
            catch
            {

            }

            int deltaCount = funcCount % 100;
            string countText = "";
            if (deltaCount >= 10 && deltaCount <= 20)
            {
                countText = $"{funcCount} функций";
            }
            else
            {
                deltaCount = funcCount % 10;
                if(deltaCount == 1)
                {
                    countText = $"{funcCount} функция";
                }
                else if(deltaCount >= 2 && deltaCount <= 4)
                {
                    countText = $"{funcCount} функции";
                }
                else
                {
                    countText = $"{funcCount} функций";
                }
            }

            labelInfoCount.Text = countText + " для расчётов";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();
            HistoryIndexB = 0;
            JsonDropVariantIndex = 0;
            autoOutput = true;

            //flowResizeMain.ScrollControlIntoView(textBoxInput);
        }

        VScrollProperties VerticalScrollPanel => flowResizeMain.VerticalScroll;

        public string OperandsJson
        {
            get => Operands.GetJsonText();
            set => Operands = new PositionCalculate(value);
        }

        public PositionCalculate Operands
        {
            get => new PositionCalculate
            {
                B = textBoxInput.Text,
                A = textBoxOutput.Text,
                Buffer = TextBuffer.Value,
                Help = textBoxHelp.Value
            };
            set
            {
                autoOutput = false;
                try
                {
                    PositionCalculate operands = value;
                    try
                    {
                        textBoxInput.Text = operands.B;
                    }
                    catch { }
                    try
                    {
                        textBoxOutput.Text = operands.A;
                    }
                    catch { }
                    try
                    {
                        TextBuffer.Value = operands.Buffer;
                    }
                    catch { }
                    try
                    {
                        textBoxHelp.Value = operands.Help;
                    }
                    catch { }
                }
                catch { }
                autoOutput = true;
            }
        }



        static CalculatorMemoryList history;

        public static CalculatorMemoryList History
        {
            get => history;
            set => history = value;
        }

        public CalculatorMemoryList HistoryList
        {
            get => History; set => History = value;
        }

        public int HistoryCount
        {
            get => HistoryList.Count;
        }

        public int HistoryLast => HistoryCount - 1;

        int historyIndexB, historyIndexA, historyIndexBuffer, historyHelp;

        public int ChangeIndex(int index)
        {
            if (index < 0)
                return 0;
            if(index >  HistoryLast && HistoryCount > 0)
            {
                return HistoryLast;
            }
            if (index > HistoryLast)
                return 0;
            return index;
        }

        public int ChangeIndexHelp()
        {
            historyHelp = ChangeIndex(historyHelp);
            return historyHelp;
        }

        public int ChangeIndexB()
        {
            historyIndexB = ChangeIndex(historyIndexB);
            return historyIndexB;
        }

        public int HistoryIndexB
        {
            get => ChangeIndexB();
            set => historyIndexB = value;
        }

        public int HistoryIndexHelp
        {
            get => ChangeIndexHelp();
            set => historyHelp = value;
        }

        public int ChangeIndexBuffer()
        {
            historyIndexBuffer = ChangeIndex(historyIndexBuffer);
            return historyIndexBuffer;
        }

        public int HistoryIndexBuffer
        {
            get => ChangeIndexBuffer(); set => historyIndexBuffer = value;
        }
        
        public int ChangeIndexA()
        {
            historyIndexA = ChangeIndex(historyIndexA);
            return historyIndexA;
        }

        public int HistoryIndexA
        {
            get => ChangeIndexA(); set => historyIndexA = value;
        }

        public string HistoryHelp => HistoryList[HistoryIndexHelp].Formule;
        public string HistoryB => HistoryList[HistoryIndexB].Formule;
        public double HistoryA => InputCalculate(HistoryList[HistoryIndexA].Formule);
        public double HistoryBuffer => InputCalculate(HistoryList[HistoryIndexBuffer].Formule);

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxInput.Clear();
        }

        private void buttonClearOutput_Click(object sender, EventArgs e)
        {
            textBoxOutput.Clear();
        }

        private void buttonClearAll_Click(object sender, EventArgs e)
        {
            buttonClear_Click(sender, e);
            buttonClearOutput_Click(sender, e);
            TextBuffer.Clear();
            textBoxHelp.Clear();
        }

        public double A
        {
            get
            {
                try
                {
                    return Convert.ToDouble(textBoxOutput.Text);
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                textBoxOutput.Text = value.ToString();
            }
        }

        private void buttonOutput_Click(object sender, EventArgs e)
        {
            buttonCalcATest_Click(sender, e);
            return;

            try
            {
                textBoxOutput.Text = NumberInputText.ToString();
                if(checkBoxAutoRound.Checked)
                {
                    buttonRound_Click(sender, e);
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Необходимо число или формула",
                    "Вывод значения",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonWrite_Click(object sender, EventArgs e)
        {

            MetrOutput1?.Invoke(textBoxOutput.Text, Save);
        }

        private void buttonSet_Click(object sender, EventArgs e)
        {
            change = false;
            buttonOutput_Click(sender, e);
            buttonWrite_Click(sender, e);
            change = true;
        }

        public double Output
        {
            get
            {
                try
                {
                    return double.Parse(textBoxOutput.Text);
                }
                catch
                {
                    return 0;
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

            textBoxInput.Text = Output.ToString();
        }

        public int RoundResult => (int)numericRound.Value;

        private void buttonRound_Click(object sender, EventArgs e)
        {
            try
            {
                double result = Math.Round(A, RoundResult);
                textBoxOutput.Text = result.ToString();

            }
            catch (Exception ex)
            {

            }
        }

        private void buttonTimer_Click(object sender, EventArgs e)
        {
            SecondMetrForm form = new SecondMetrForm(Save.None);
            form.MetrOutput1 += Form_MetrOutput1;
            form.GetMilliseconds += Form_GetMilliseconds;
            form.Show();
        }

        private double Form_GetMilliseconds()
        {
            return Output;
        }

        private void Form_MetrOutput1(string time, Save save)
        {
            try
            {
                textBoxInput.Text = double.Parse(time.Replace('.', ',')).ToString();
            }
            catch
            {

            }
        }

        private void textBoxOutput_TextChanged(object sender, EventArgs e)
        {
            if(AutoWrite)
            {
                buttonWrite_Click(sender, e);
            }
        }

        bool change;

        bool AutoWrite => change && checkBoxAutoWrite.Checked;

        private void buttonKeyBord_Click(object sender, EventArgs e)
        {
            CalculatorKeyBord keyBord = new CalculatorKeyBord();
            keyBord.TextB = textBoxInput;
            keyBord.TextA = textBoxOutput;
            keyBord.TextBuffer = TextBuffer;
            keyBord.SecondInput += KeyBord_SecondInput;
            keyBord.SecondsSaved += KeyBord_SecondsSaved;
            keyBord.RunBA += KeyBord_RunAB;
            keyBord.RunAB += KeyBord_RunBA;
            keyBord.WriteA += KeyBord_WriteA;
            keyBord.OutputWriteA += KeyBord_OutputWriteA;
            keyBord.InputMainForm += buttonFromMainForm_Click;
            keyBord.WriteB += KeyBord_WriteB;
            keyBord.FewMemoryA = memoryA;
            keyBord.FewMemoryB = memoryB;
            keyBord.FewMemoryBuffer = memoryBuffer;
            keyBord.AutoOutput = checkBoxAutoOutput;
            keyBord.AutoWrite = checkBoxAutoWrite;
            keyBord.AequalsB += buttonAequalsB_Click;
            keyBord.BequalsA += buttonBequalsA_Click;
            keyBord.InputMainFormReal += buttonFromMainFormReal_Click;
            keyBord.AequalsBMain += buttonAequalsBMain_Click;
            keyBord.BequalsAMain += buttonBequalsAMain_Click;
            keyBord.GetHelpText += GetHelpNumber;

            keyBord.Show();
        }

        private void KeyBord_WriteB()
        {
            SaveB();
        }

        private void KeyBord_OutputWriteA()
        {
            buttonSet_Click(buttonSet, new EventArgs());
        }

        private void KeyBord_WriteA()
        {
            buttonWrite_Click(buttonWrite, new EventArgs());
        }

        private void KeyBord_RunBA()
        {
            buttonOutput_Click(buttonOutput, new EventArgs());
        }

        private void KeyBord_RunAB()
        {
            button2_Click(button2, new EventArgs());
        }

        private void KeyBord_SecondsSaved()
        {
            buttonGetSavedSeconds_Click(buttonTimer, new EventArgs());
        }

        private void KeyBord_SecondInput()
        {
            buttonTimer_Click(buttonTimer, new EventArgs());
        }

        private void buttonGetSavedSeconds_Click(object sender, EventArgs e)
        {
            FormSecondsSaved form = new FormSecondsSaved(Save.None);
            form.MetrOutput1 += Form_MetrOutput1;
            form.Show();
        }

        private void buttonCalculateB_Click(object sender, EventArgs e)
        {
            try
            {
                CalculateB();
            }
            catch (Exception ex)
            {

            }
        }

        private void buttonFromMainForm_Click(object sender, EventArgs e)
        {
            try
            {
                SetInput(SetNumberFromMain?.Invoke());
            }
            catch
            {

            }
        }

        public event Func<string> SetNumberFromMain;

        private void buttonBufferB_Click(object sender, EventArgs e)
        {
            try
            {
                Buffer = B;
            }
            catch (Exception ex) { }
        }

        private void buttonBufferA_Click(object sender, EventArgs e)
        {
            try
            {
                Buffer = A;
            }
            catch (Exception ex) { }
        }

        private void buttonBBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                B = Buffer;
            }
            catch
            {

            }
        }

        private void buttonABuffer_Click(object sender, EventArgs e)
        {
            try
            {
                A = Buffer;
            }
            catch
            {

            }
        }

        string GetFormuleB()
        {
            try
            {
                return FormuleB;
            }
            catch (Exception ex)
            {
                return "0";
            }
        }

        public string FormuleB
        {
            get
            {
                string formule = textBoxInput.Text;
               // InputCalculate(formule);
                formule = MyCalculate.ChangeBaskets(formule);
                return formule;
            }
            set
            {
                string formule = value;
               // InputCalculate(formule);
                textBoxInput.Text = formule;
            }
        }

        

        private void memoryA_MR()
        {
            try
            {
                string b = HistoryB;
                if(FormuleB.Trim() == "")
                {
                    FormuleB = HistoryB;
                }
                else
                {
                    FormuleB = "("+FormuleB.Trim()+") × (" + HistoryB.Trim()+")";
                }
            }
            catch
            {
                try
                {
                    FormuleB = HistoryB;
                }
                catch
                {

                }
            }
        }

        

        private void memoryB_Write()
        {
            try
            {
                HistoryList.Add(FormuleB);
            }
            catch
            {

            }
        }

        private void memoryB_Plus()
        {
            try
            {
                int index = HistoryIndexB;
                HistoryIndexB = index < HistoryLast ? ++index : 0;
            }
            catch
            {

            }
        }

        private void memoryB_Mines()
        {
            try
            {
                int index = HistoryIndexB;
                HistoryIndexB = index > 0 ? --index : HistoryLast;
            }
            catch
            {

            }
        }

        private void memoryA_Mines()
        {
            try
            {
                int index = HistoryIndexA;
                HistoryIndexA = index > 0 ? --index : HistoryLast;
            }
            catch
            {

            }
        }

        private void memoryA_MR_1()
        {
            try
            {
                if (A != 0)
                    A *= HistoryA;
                else
                    A = HistoryA;
            }
            catch
            {

            }
        }

        private void memoryBuffer_Write()
        {
            try
            {
                HistoryList.Add(Buffer.ToString());
            }
            catch
            {

            }
        }

        private void memoryBuffer_Plus()
        {
            try
            {
                int index = HistoryIndexBuffer;
                HistoryIndexBuffer = index < HistoryLast ? ++index : 0;
            }
            catch
            {

            }
        }

        private void memoryBuffer_Mines()
        {
            try
            {
                int index = HistoryIndexBuffer;
                HistoryIndexBuffer = index > 0 ? --index : HistoryLast;
            }
            catch
            {

            }
        }

        private void memoryBuffer_MR()
        {
            try
            {
                if (Buffer != 0)
                    Buffer *= HistoryBuffer;
                else
                    Buffer = HistoryBuffer;
            }
            catch
            {

            }
        }

        private void memoryB_History()
        {
            try
            {
                CalculatorMemory memory = new CalculatorMemory();
                memory.TextNumberA = textBoxOutput;
                memory.TextNumberB = textBoxInput;
                memory.TextBuffer = TextBuffer;
                memory.MetrOutput1 += MetrOutput1;
                memory.GetHelpText += GetHelpNumber;
                memory.Show();
            }
            catch
            {

            }
        }

        private void buttonMemory_Click(object sender, EventArgs e)
        {
            memoryB_History();
        }

        bool autoOutput;

        private void textBoxInput_TextChanged(object sender, EventArgs e)
        {
            if(checkBoxAutoOutput.Checked && autoOutput)
            {
                try
                {
                    A = B;
                }
                catch
                {

                }
            }
        }

        private void textBoxInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                char code = e.KeyChar;
                if(code == 13 && checkBoxEnter.Checked)
                {
                    A = B;
                }
            }
            catch
            {

            }
        }

        private void buttonWriteB_Click(object sender, EventArgs e)
        {
            SaveB();
        }

        public void SaveB()
        { 
            try
            {
                MetrOutput1?.Invoke(textBoxInput.Text, Save);
            }
            catch
            {

            }
        }

        private void memoryB_WriteClear()
        {
            try
            {
                try
                {

                    FormuleB = HistoryB;
                }
                catch
                {

                }
            }
            catch { }
        }

        private void memoryA_WriteClear()
        {
            try
            {

                A = HistoryA;
            }
            catch
            {

            }
        }

        private void memoryBuffer_WriteClear()
        {
            try
            {
                Buffer = HistoryBuffer;
            }
            catch
            {

            }
        }

        private void buttonAequalsB_Click(object sender, EventArgs e)
        {
            try
            {
                MetrOutput1?.Invoke(textBoxOutput.Text+"="+textBoxInput.Text, Save);
            }
            catch
            {

            }
        }

        private void buttonBequalsA_Click(object sender, EventArgs e)
        {
            try
            {
                MetrOutput1?.Invoke(textBoxInput.Text + "=" + textBoxOutput.Text, Save);
            }
            catch
            {

            }
        }

        private void buttonFromMainFormReal_Click(object sender, EventArgs e)
        {
            try
            {
                SetInput(ValueHelper.GetText());
            }
            catch { }
        }

        private void buttonWriteMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(textBoxOutput.Text);
            }
            catch { }
        }

        private void buttonWriteBMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(textBoxInput.Text);
            }
            catch { }
        }

        private void buttonAequalsBMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(textBoxOutput.Text + "=" + textBoxInput.Text);
            }
            catch
            {

            }
        }

        private void buttonBequalsAMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(textBoxInput.Text + "=" + textBoxOutput.Text);
            }
            catch
            {

            }
        }

        private void buttonWriteBToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBoxInput.Text);
            }
            catch { }
        }

        private void buttonWriteAToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBoxOutput.Text);
            }
            catch { }
        }

        private void buttonAequalsBToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBoxOutput.Text + "=" + textBoxInput.Text);
            }
            catch { }
        }

        private void buttonBequalsAToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBoxInput.Text + "=" + textBoxOutput.Text);
            }
            catch { }
        }

        private void buttonBFromClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    SetInput(Clipboard.GetText());
                }
                catch { }
            }
            catch { }
        }

        private void buttonChangeFunc_Click(object sender, EventArgs e)
        {
            buttonOpenVariablesAnsConsts_Click(sender, e);
            return;
        }

        public string GetHelpNumber()
        {
            string help = textBoxHelp.Value;
            if (help.Length < 1)
                return "0";
            return MyCalculate.ChangeBaskets(help);
        }

        public double GetHelpNumberReal()
        {
            try
            {
                string help = GetHelpNumber();
                double number = MyCalculate.GetResultHelp(help, A, Buffer, textBoxInput.Text);
                return number;
            }
            catch { 
                return 0.0;
            }
        }

        private void buttonRunBToHelp_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxHelp.Value = MyCalculate.ChangeBaskets(FormuleB);
            }
            catch { }
        }

        private void buttonRunHelpToB_Click(object sender, EventArgs e)
        {
            try
            {
                FormuleB = GetHelpNumber();
            }
            catch { }
        }

        private void buttonRunB1ToHelp_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxHelp.Value = InputCalculate(FormuleB).ToString();
            }
            catch { }
        }

        private void buttonRunHelpToB1_Click(object sender, EventArgs e)
        {
            try
            {
                FormuleB = GetHelpNumberReal().ToString();
            }
            catch { }
        }

        private void buttonRunAToHelp_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxHelp.Value = A.ToString();
            }
            catch { }
        }

        private void buttonRunHelpToA_Click(object sender, EventArgs e)
        {
            try
            {
                A = GetHelpNumberReal();
            }
            catch { }
        }

        private void buttonRunBuferToHelp_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxHelp.Value = Buffer.ToString();
            }
            catch { }
        }

        private void buttonRunHelpToBufer_Click(object sender, EventArgs e)
        {
            try
            {
                Buffer = GetHelpNumberReal();
            }
            catch { }
        }

        private void buttonRunGrafics_Click(object sender, EventArgs e)
        {
            FuncGraphicsForm form = new FuncGraphicsForm();
            form.GetB += Form_GetB;
            form.GetA += Form_GetA;
            form.GetBuffer += Form_GetBuffer;
            form.GetHelp += Form_GetHelp;
            form.MetrOutput1 += Form_MetrOutput1;
            form.SetNumberFromMain += SetNumberFromMain;
            form.Show();
        }

        private string Form_GetHelp()
        {
            return MyCalculate.ChangeBaskets(textBoxHelp.Value);
        }

        private string Form_GetBuffer()
        {
            return TextBuffer.Value;
        }

        private string Form_GetA()
        {
            return textBoxOutput.Text;
        }

        private string Form_GetB()
        {
            return MyCalculate.ChangeBaskets(textBoxInput.Text);
        }

        private void buttonChangeBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                FormuleB = FormuleB;
            }
            catch { }
        }

        private void buttonAddBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                FormuleB = MyCalculate.AddBasketsInteractive(FormuleB);
                return;
                FormuleB = "(" + FormuleB + ")";
            }
            catch { }
        }

        private void buttonDropBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                FormuleB = MyCalculate.DropBasketsInteractive(FormuleB);
                //FormuleB = MyCalculate.DropBaskets(FormuleB);
            }
            catch { }
        }

        private void buttonToBynaryCode_Click(object sender, EventArgs e)
        {
            BynaryWindow bynary = new BynaryWindow();
            bynary.MetrOutput1 += MetrOutput1;
            bynary.SetNumberFromMain += SetNumberFromMain;
            bynary.GetB += Bynary_GetB;
            bynary.GetA += Bynary_GetA;
            bynary.GetBuffer += Bynary_GetBuffer;
            bynary.GetHelp += Bynary_GetHelp;
            bynary.SetA += Bynary_SetA;
            bynary.SetB += Bynary_SetB;
            bynary.SetBuffer += Bynary_SetBuffer;
            bynary.SetHelp += Bynary_SetHelp;

            bynary.Show();
        }

        private void Bynary_SetHelp(double obj)
        {
            try
            {
                textBoxHelp.Value = obj.ToString();
            }
            catch { }
        }

        private void Bynary_SetBuffer(double obj)
        {
            try
            {
                Buffer = obj;
            }
            catch { }
        }

        private void Bynary_SetB(double obj)
        {
            try
            {
                A = obj;
            }
            catch { }
        }

        private void Bynary_SetA(double obj)
        {
            try
            {
                B = obj;
            }
            catch { }
        }

        private double Bynary_GetHelp()
        {
            return GetHelpNumberReal();
        }

        private double Bynary_GetBuffer()
        {

            return Buffer;
        }

        private double Bynary_GetA()
        {
            return A;
        }

        private double Bynary_GetB()
        {
            return B;
        }

        private void buttonToVectorCalculator_Click(object sender, EventArgs e)
        {
            VectorCalculator vectorCalculator = new VectorCalculator();
            VectorCalculator bynary = vectorCalculator;

            bynary.MetrOutput1 += MetrOutput1;
            bynary.SetNumberFromMain += SetNumberFromMain;

            bynary.GetB += Bynary_GetB;
            bynary.GetA += Bynary_GetA;
            bynary.GetBuffer += Bynary_GetBuffer;
            bynary.GetHelp += Bynary_GetHelp;
            bynary.SetA += Bynary_SetA;
            bynary.SetB += Bynary_SetB;
            bynary.SetBuffer += Bynary_SetBuffer;
            bynary.SetHelp += Bynary_SetHelp;
            bynary.GetFormuleB += Bynary_GetFormuleB;
            bynary.SetFormuleB += Bynary_SetFormuleB;
            bynary.GetFormuleHelp += Bynary_GetFormuleHelp;
            bynary.SetFormuleHelp += Bynary_SetFormuleHelp;

            vectorCalculator.Show();
        }

        private void Bynary_SetFormuleHelp(string obj)
        {
            textBoxHelp.Value = obj;
        }

        private string Bynary_GetFormuleHelp()
        {
            return textBoxHelp.Value;
        }

        private void Bynary_SetFormuleB(string obj)
        {
            FormuleB = obj;
        }

        private string Bynary_GetFormuleB()
        {
            return FormuleB;
        }

        private void buttonInputFeacher_Click(object sender, EventArgs e)
        {
            FeachersList form = new FeachersList();
            form.InputFunc += Form_InputFunc;
            form.MetrOutput1 += MetrOutput1;

            form.Show();
        }

        private void Form_InputFunc(string obj)
        {
            try
            {
                textBoxInput.Text += obj;
            }
            catch { }
        }

        private void buttonListCalculator_Click(object sender, EventArgs e)
        {
            ListCalculatorForm vectorCalculator = new ListCalculatorForm();
            ListCalculatorForm bynary = vectorCalculator;

            bynary.MetrOutput1 += MetrOutput1;
            bynary.SetNumberFromMain += SetNumberFromMain;

            bynary.GetB += Bynary_GetB;
            bynary.GetA += Bynary_GetA;
            bynary.GetBuffer += Bynary_GetBuffer;
            bynary.GetHelp += Bynary_GetHelp;
            bynary.SetA += Bynary_SetA;
            bynary.SetB += Bynary_SetB;
            bynary.SetBuffer += Bynary_SetBuffer;
            bynary.SetHelp += Bynary_SetHelp;
            bynary.GetFormuleB += Bynary_GetFormuleB;
            bynary.SetFormuleB += Bynary_SetFormuleB;
            bynary.GetFormuleHelp += Bynary_GetFormuleHelp;
            bynary.SetFormuleHelp += Bynary_SetFormuleHelp;

            bynary.SetByJson += Bynary_SetByJson;
            bynary.GetByJson += Bynary_GetByJson;

            vectorCalculator.Show();
        }

        private void Bynary_GetByJson(string obj)
        {
            OperandsJson = obj;
        }

        private string Bynary_SetByJson()
        {
            return OperandsJson;
        }

        private void timerView_Tick(object sender, EventArgs e)
        {
            checkBoxPanelCalcView.Visible = checkBoxFlagsView.Checked;
            tableLayoutPanelCalcView.Visible = checkBoxPanelCalcView.Checked;

            checkBoxPanelRoundView.Visible = checkBoxFlagsView.Checked;
            tableLayoutViewFx.Visible = checkBoxPanelRoundView.Checked;

            checkBoxPanelWriteView.Visible = checkBoxFlagsView.Checked;
            tableLayoutPanelWriteView.Visible = checkBoxPanelWriteView.Checked;

            checkBoxInputBView.Visible = checkBoxFlagsView.Checked;
            tableLayoutPanelInputBView.Visible = checkBoxInputBView.Checked;

            checkBoxCorrectView.Visible = checkBoxFlagsView.Checked;
            tableLayoutPanelCorrectView.Visible = checkBoxCorrectView.Checked;


            checkBoxShowFile.Visible = checkBoxFlagsView.Checked;
            tableLayoutPanelFile.Visible = checkBoxShowFile.Checked;

            checkBoxViewFx.Visible = checkBoxFlagsView.Checked;
            groupBoxImportFx.Visible = checkBoxViewFx.Checked;

            checkBoxAutoCalcA.Checked = checkBoxAutoOutput.Checked;
        }

        private void memoryHelp_Mines()
        {
            try
            {
                int index = HistoryIndexHelp;
                HistoryIndexHelp = index > 0 ? --index : HistoryLast;
            }
            catch
            {

            }
        }

        private void memoryHelp_Plus()
        {
            try
            {
                int index = HistoryIndexHelp;
                HistoryIndexHelp = index < HistoryLast ? ++index : 0;
            }
            catch
            {

            }
        }

        private void memoryHelp_Write()
        {
            try
            {
                HistoryList.Add(GetHelpNumber().ToString());
            }
            catch
            {

            }
        }

        private void memoryHelp_WriteClear()
        {
            try
            {
                textBoxHelp.Value = HistoryHelp;
            }
            catch
            {

            }
        }

        private void buttonLoadFile_Click(object sender, EventArgs e)
        {
            try
            {
                PositionCalculate positionCalculate = new PositionCalculate();
                openFileCalculator.Filter = positionCalculate.FileFilter;
                DialogResult result = openFileCalculator.ShowDialog();
                openFileCalculator.Multiselect = false;
                if (result != DialogResult.OK)
                {
                    return;
                }
                positionCalculate.SetByFile(openFileCalculator.FileName);
                Operands = positionCalculate;

                MessageBox.Show("Позиция в калькуляторе успешно загружена из файла \n" + openFileCalculator.FileName, "Загрузка позиции из файла", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось загрузить позицию в калькуляторе из файла", "Загрузка позиции из файла", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void buttonSaveFile_Click(object sender, EventArgs e)
        {
            try
            {
                PositionCalculate positionCalculate = Operands;
                saveFileCalculator.Filter = positionCalculate.FileFilter;
                DialogResult result = saveFileCalculator.ShowDialog();
                if (result != DialogResult.OK)
                {
                    return;
                }
                positionCalculate.ToFile(saveFileCalculator.FileName);

                MessageBox.Show("Позиция в калькуляторе успешно сохранена в файл \n" + saveFileCalculator.FileName, "Сохранение позиции в файл", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось сохранить позицию в калькуляторе в файл", "Сохранение позиции в файл", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void buttonJsonLastWindow_Click(object sender, EventArgs e)
        {
            try
            {

                if (JsonDropVariantIndex == 0)
                {
                    PositionCalculate positionCalculate = new PositionCalculate();
                    positionCalculate.SetJson(SetNumberFromMain?.Invoke());

                    Operands = positionCalculate;
                }
                else if(JsonDropVariantIndex == 1)
                {
                    PositionCalculate positionCalculate = Operands;
                    MetrOutput1?.Invoke(positionCalculate.GetJsonText(), Save.None);
                }
            }
            catch { }
        }

        private void buttonJsonMainWindow_Click(object sender, EventArgs e)
        {
            try
            {

                if (JsonDropVariantIndex == 0)
                {
                    PositionCalculate positionCalculate = new PositionCalculate();
                    positionCalculate.SetJson(ValueHelper.GetText());

                    Operands = positionCalculate;
                }
                else if (JsonDropVariantIndex == 1)
                {
                    PositionCalculate positionCalculate = Operands;
                    ValueHelper.SetText(positionCalculate.GetJsonText());
                }
            }
            catch { }
        }

        private void buttonJsonClipBoard_Click(object sender, EventArgs e)
        {
            try
            {

                if (JsonDropVariantIndex == 0)
                {
                    PositionCalculate positionCalculate = new PositionCalculate();
                    positionCalculate.SetJson(Clipboard.GetText());

                    Operands = positionCalculate;
                }
                else if (JsonDropVariantIndex == 1)
                {
                    PositionCalculate positionCalculate = Operands;
                    Clipboard.SetText(positionCalculate.GetJsonText());
                }
            }
            catch { }
        }

        static string fx2;

        private void timerViewFx_Tick(object sender, EventArgs e)
        {
            if (!checkBoxFxOutput.Checked)
                return;
            try
            {
                textBoxViewFx.Value = FuncGraphicsForm.Fx1;
            }
            catch { }

            try
            {
                FuncGraphicsForm.FxForFuncs(textBoxOutput.Text, textBoxInput.Text, TextBuffer.Value, textBoxHelp.Value);
            }
            catch
            {

            }
        }

        private void textBoxViewFx_ValueChanged(Control control, EventArgs e, string value)
        {
            try
            {
                FuncGraphicsForm.Fx1 = value;
            }
            catch { }
        }

        private void buttonAddFunctionToC_Click(object sender, EventArgs e)
        {
            FeachersList form = new FeachersList();
            form.InputFunc += Form_InputFunc1;
            form.MetrOutput1 += MetrOutput1;

            form.Show();
        }

        private void Form_InputFunc1(string obj)
        {
            try
            {
                textBoxFunctionConst.Value += obj;
            }
            catch { }
        }

        private void groupBoxRunC_VisibleChanged(object sender, EventArgs e)
        {
            radioButtonExportC.Checked = true;
        }

        private void radioButtonFc_CheckedChanged(object sender, EventArgs e)
        {
            groupBoxRunC.Visible = !(sender as RadioButton).Checked;
        }

        private void buttonCalcFc_Click(object sender, EventArgs e)
        {
            try
            {
                string help = GetHelpNumber();
                //double number = MyCalculate.CalculateWithB("fx(" + textBoxFunctionConst.Value, help, A.ToString(), Buffer.ToString(), B.ToString());
                textBoxFc.Value = MyCalculate.ViewX(textBoxViewFx.Value, textBoxFunctionConst.Value);
            }
            catch
            {
                
            }
        }

        string ValueByFx
        {
            get
            {
                
                if (radioButtonC.Checked)
                    return textBoxFunctionConst.Value;
                else
                    return textBoxFc.Value;
            }
            set
            {
                if (radioButtonC.Checked)
                    textBoxFunctionConst.Value = value;
                else
                    textBoxFc.Value = value;
            }
        }

        double NumberByFx
        {
            get
            {

                return MyCalculate.CalculateWithB(ValueByFx, GetHelpNumberReal().ToString(), A.ToString(), Buffer.ToString(), B.ToString());

            }
            set
            {
                ValueByFx = value.ToString();
            }
        }


        private void buttonCalcHelp_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxHelp.Value = GetHelpNumberReal().ToString();
            }
            catch { }
        }

        private void textBoxFunctionConst_ValueChanged(Control control, EventArgs e, string value)
        {
            try
            {
                if (checkBoxAutoFc.Checked)
                    buttonCalcFc_Click(control, e);
            }
            catch { }
        }

        private void textBoxFunctionConst_EnterKeyDown(Control control, EventArgs e, string value)
        {
            try
            {
                if (checkBoxEnterFc.Checked)
                    buttonCalcFc_Click(control, e);
            }
            catch { }
        }

        private void buttonCalcC_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    string help = GetHelpNumber();
                    double number = MyCalculate.CalculateWithB(textBoxFunctionConst.Value, help, A.ToString(), Buffer.ToString(), B.ToString());
                    textBoxFunctionConst.Value = number.ToString();
                }
                catch
                {

                }
            }
            catch { }
        }

        private void buttonAddBasketsC_Click(object sender, EventArgs e)
        {
            try
            {
                ValueByFx = MyCalculate.AddBaskets(ValueByFx).Trim();
            }
            catch { }
        }

        private void buttonDropBasketsC_Click(object sender, EventArgs e)
        {
            try
            {
                ValueByFx = MyCalculate.DropBaskets(ValueByFx).Trim();
            }
            catch { }
        }

        private void buttonChangeBasketsC_Click(object sender, EventArgs e)
        {
            try
            {
                ValueByFx = MyCalculate.ChangeBaskets(ValueByFx).Trim();
            }
            catch { }
        }

        private void buttonDropVariableC_Click(object sender, EventArgs e)
        {
            try
            {
               
                try
                {
                   ValueByFx= MyCalculate.FuncViewChange(ValueByFx, A.ToString(), Buffer.ToString(), GetHelpNumber(), GetFormuleB());
                }
                catch
                { 
                    
                }
            }
            catch { }
        }

        private void buttonCB_Click(object sender, EventArgs e)
        {
            try
            {
                if(radioButtonExportC.Checked)
                {
                    textBoxInput.Text = MyCalculate.ReplaceB(ValueByFx, GetFormuleB());
                }
                else
                {
                    ValueByFx = textBoxInput.Text;
                }
            }
            catch { }
        }

        private void buttonCA_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonExportC.Checked)
                {
                    A = NumberByFx;
                }
                else
                {
                    NumberByFx = A;
                }
            }
            catch { }
        }

        private void buttonBufferC_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonExportC.Checked)
                {
                   Buffer = NumberByFx;
                }
                else
                {
                    NumberByFx = Buffer;
                }
            }
            catch { }
        }

        private void buttonComputeFc_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    string help = GetHelpNumber();
                    double number = MyCalculate.CalculateWithB(textBoxFc.Value, help, A.ToString(), Buffer.ToString(), B.ToString());
                    textBoxFc.Value = number.ToString();
                }
                catch
                {

                }
            }
            catch { }
        }

        private void buttonHelpC_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonExportC.Checked)
                {
                    textBoxHelp.Value = MyCalculate.ReplaceHelp(ValueByFx, GetFormuleB(), GetHelpNumber());
                }
                else
                {
                    ValueByFx = textBoxHelp.Text;
                }
            }
            catch { }
        }

        private void buttonComputeC_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    string help = GetHelpNumber();
                    double number = MyCalculate.CalculateWithB(ValueByFx, help, A.ToString(), Buffer.ToString(), B.ToString());
                    ValueByFx = number.ToString();
                }
                catch
                {

                }
            }
            catch { }
        }

        private void buttonClipBoardC_Click(object sender, EventArgs e)
        {
            try
            {
                if(radioButtonExportC.Checked)
                    Clipboard.SetText(ValueByFx);
                else
                    ValueByFx = Clipboard.GetText();
            }
            catch { }
        }

        private void buttonLastWindowC_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonExportC.Checked)
                    MetrOutput1(ValueByFx, Save);
                else
                    ValueByFx = SetNumberFromMain?.Invoke();
            }
            catch { }
        }

        private void buttonMainWindowC_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonExportC.Checked)
                    ValueHelper.SetText(ValueByFx);
                else
                    ValueByFx = ValueHelper.GetText();
            }
            catch { }
        }

        private void buttonScrollDown_Click(object sender, EventArgs e)
        {
            try
            {
                VerticalScrollPanel.Value += 20;
            }
            catch 
            {
                VerticalScrollPanel.Value = VerticalScrollPanel.Maximum;
            }
        }

        private void buttonScrollUp_Click(object sender, EventArgs e)
        {
            try
            {
                VerticalScrollPanel.Value -= 20;
            }
            catch
            {
                VerticalScrollPanel.Value = VerticalScrollPanel.Minimum;
            }
        }

        private void buttonScrollDown1_Click(object sender, EventArgs e)
        {
            try
            {
                VerticalScrollPanel.Value += 40;
            }
            catch
            {
                VerticalScrollPanel.Value = VerticalScrollPanel.Maximum;
            }
        }

        private void buttonScrollUp1_Click(object sender, EventArgs e)
        {
            try
            {
                VerticalScrollPanel.Value -= 40;
            }
            catch
            {
                VerticalScrollPanel.Value = VerticalScrollPanel.Minimum;
            }
        }

        private void buttonScrollMax_Click(object sender, EventArgs e)
        {
            try
            {
                VerticalScrollPanel.Value = VerticalScrollPanel.Maximum;
            }
            catch { }
        }

        private void buttonScrollMin_Click(object sender, EventArgs e)
        {
            try
            {
                VerticalScrollPanel.Value = VerticalScrollPanel.Minimum;
            }
            catch { }
        }

        private void checkBoxAutoCalcA_CheckedChanged(object sender, EventArgs e)
        {
            checkBoxAutoOutput.Checked = checkBoxAutoCalcA.Checked;
        }

        private void buttonTestChangeBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxInput.Text = MyCalculate.ReplaceToFullFuncsCodeInteractive(textBoxInput.Text);
            }
            catch { }
        }

        private void buttonOpenConsts_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxInput.Text = MyCalculate.ReplaceByOpenConst(textBoxInput.Text);
            }
            catch { }
        }

        private void buttonOpenVariables_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxInput.Text = MyCalculate.ReplaceByOpenVariables(textBoxInput.Text, textBoxOutput.Text, TextBuffer.Value, textBoxHelp.Value);
            }
            catch { }
        }

        private void buttonOpenVariablesAnsConsts_Click(object sender, EventArgs e)
        {

            try
            {
                textBoxInput.Text = MyCalculate.ReplaceByOpenConst(textBoxInput.Text, textBoxOutput.Text, TextBuffer.Value, textBoxHelp.Value);
            }
            catch { }
        }

        private void flowResizeMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonTestCalc_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxInput.Text = MyCalculate.CalculateConvertToPostphics(textBoxInput.Text, textBoxOutput.Text, TextBuffer.Value, textBoxHelp.Value).ToString();
            }
            catch { }
        }

        private void buttonCalcATest_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxOutput.Text = MyCalculate.CalculateConvertToPostphics(textBoxInput.Text, textBoxOutput.Text, TextBuffer.Value, textBoxHelp.Value).ToString();
           
                if (checkBoxAutoRound.Checked)
                {
                    buttonRound_Click(sender, e);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Необходимо число или формула",
                    "Вывод значения",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tableLayoutPanel22_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void buttonInteractiveEdit_Click(object sender, EventArgs e)
        {
            FormulePartsForm formuleParts = new FormulePartsForm();
            formuleParts.ReloadFormuleParts += FormuleParts_ReloadFormuleParts;
            formuleParts.GetFormule += FormuleParts_GetFormule;
            formuleParts.UpdateFewFormule += FormuleParts_UpdateFewFormule;

            formuleParts.GetA += FormuleParts_GetA;
            formuleParts.GetFewA += FormuleParts_GetA;

            formuleParts.GetB += FormuleParts_GetB;
            formuleParts.GetFewB += FormuleParts_GetB;

            formuleParts.GetBuffer += FormuleParts_GetBuffer;
            formuleParts.GetFewBuffer += FormuleParts_GetBuffer;

            formuleParts.GetHelp += FormuleParts_GetHelp;
            formuleParts.GetFewHelp += FormuleParts_GetHelp;

            formuleParts.Show();
        }

        private string FormuleParts_GetHelp()
        {
            return textBoxHelp.Value;
        }

        private string FormuleParts_GetBuffer()
        {
            return TextBuffer.Value;
        }

        private string FormuleParts_GetB()
        {
            return textBoxInput.Text;
        }

        private string FormuleParts_GetA()
        {
           return textBoxOutput.Text;
        }

        private void FormuleParts_UpdateFewFormule(string obj)
        {
            try
            {
                textBoxInput.Text = obj;
            }
            catch { }
        }

        private string FormuleParts_GetFormule()
        {
            try
            {
                return textBoxInput.Text;
            }
            catch
            {
                return "";
            }
        }

        private FormulePartList FormuleParts_ReloadFormuleParts()
        {
            try
            {
                return MyCalculate.ReplaceToFullFuncsCodeInteractive(textBoxInput.Text);
            }
            catch {
                return new FormulePartList();
            }

        }

        private void buttonCopyAB_Click(object sender, EventArgs e)
        {
            string b = textBoxInput.Text;
            try
            {
                string calcB = InputCalculate(b).ToString();
                TableAIS.Buffer.CalculatetionCopy = new CalculatePositionCopy(b, calcB);
            }
            catch
            {

            }
        }

        private void buttonPastBFromBCalcB_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxInput.Text = TableAIS.Buffer.GetCalculatetionCopy().B;
            }
            catch { }
        }

        private void buttonPastCalcBFromBCalcB_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxInput.Text = TableAIS.Buffer.GetCalculatetionCopy().A;
            }
            catch { }
        }

        private void memoryHelp_MR()
        {
            try
            {
                string b = HistoryHelp;
                string help = GetHelpNumber();
                if (help.Trim() == "")
                {
                    textBoxHelp.Text = HistoryHelp;
                }
                else
                {
                    textBoxHelp.Text = "(" + help.Trim() + ") × (" + HistoryHelp.Trim() + ")";
                }
            }
            catch
            {
                try
                {
                    textBoxHelp.Text = HistoryHelp;
                }
                catch
                {

                }
            }
        }

        private void memoryA_Write()
        {
            try
            {
                HistoryList.Add(A.ToString());
            }
            catch
            {

            }
        }

        private void memoryA_Plus()
        {
            try
            {
                int index = HistoryIndexA;
                HistoryIndexA = index < HistoryLast ? ++index : 0;
            }
            catch
            {

            }
        }
    }
}
