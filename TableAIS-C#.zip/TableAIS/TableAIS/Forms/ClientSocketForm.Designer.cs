﻿namespace TableAIS
{
    partial class ClientSocketForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClientSocketForm));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.numbericUser4Oktet = new TableAIS.NumbericUser();
            this.numbericUser3Oktet = new TableAIS.NumbericUser();
            this.numbericUser2Oktet = new TableAIS.NumbericUser();
            this.numbericUser1Oktet = new TableAIS.NumbericUser();
            this.textBoxIpAddress = new System.Windows.Forms.TextBox();
            this.buttonClearIpAddress = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.numbericUserPort = new TableAIS.NumbericUser();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonCearAll = new System.Windows.Forms.Button();
            this.buttonOK = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonSetAddressByMain = new TableAIS.ButtonClickView();
            this.buttonWriteMain = new TableAIS.ButtonClickView();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(530, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(223, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(782, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(778, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(413, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 504);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(782, 23);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 2, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(782, 415);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // groupBox1
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.groupBox1, 4);
            this.groupBox1.Controls.Add(this.tableLayoutPanel3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(776, 201);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "IP-адрес";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.Controls.Add(this.numbericUser4Oktet, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.numbericUser3Oktet, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.numbericUser2Oktet, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.numbericUser1Oktet, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.textBoxIpAddress, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.buttonClearIpAddress, 2, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(770, 168);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // numbericUser4Oktet
            // 
            this.numbericUser4Oktet.Default = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUser4Oktet.DefaultValue = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUser4Oktet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericUser4Oktet.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUser4Oktet.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUser4Oktet.Location = new System.Drawing.Point(581, 5);
            this.numbericUser4Oktet.Macimum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numbericUser4Oktet.Margin = new System.Windows.Forms.Padding(5);
            this.numbericUser4Oktet.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numbericUser4Oktet.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser4Oktet.Name = "numbericUser4Oktet";
            this.numbericUser4Oktet.NoReadOnly = true;
            this.numbericUser4Oktet.ReadOnly = false;
            this.numbericUser4Oktet.Size = new System.Drawing.Size(184, 108);
            this.numbericUser4Oktet.TabIndex = 3;
            this.numbericUser4Oktet.Title = "4 октет";
            this.numbericUser4Oktet.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser4Oktet.VisibleOK = false;
            this.numbericUser4Oktet.ValueChanged += new TableAIS.ValueChangedControl(this.numbericUser1Oktet_ValueChanged);
            // 
            // numbericUser3Oktet
            // 
            this.numbericUser3Oktet.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser3Oktet.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser3Oktet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericUser3Oktet.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUser3Oktet.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUser3Oktet.Location = new System.Drawing.Point(389, 5);
            this.numbericUser3Oktet.Macimum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numbericUser3Oktet.Margin = new System.Windows.Forms.Padding(5);
            this.numbericUser3Oktet.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numbericUser3Oktet.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser3Oktet.Name = "numbericUser3Oktet";
            this.numbericUser3Oktet.NoReadOnly = true;
            this.numbericUser3Oktet.ReadOnly = false;
            this.numbericUser3Oktet.Size = new System.Drawing.Size(182, 108);
            this.numbericUser3Oktet.TabIndex = 2;
            this.numbericUser3Oktet.Title = "3 октет";
            this.numbericUser3Oktet.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser3Oktet.VisibleOK = false;
            this.numbericUser3Oktet.ValueChanged += new TableAIS.ValueChangedControl(this.numbericUser1Oktet_ValueChanged);
            // 
            // numbericUser2Oktet
            // 
            this.numbericUser2Oktet.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser2Oktet.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser2Oktet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericUser2Oktet.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUser2Oktet.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUser2Oktet.Location = new System.Drawing.Point(197, 5);
            this.numbericUser2Oktet.Macimum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numbericUser2Oktet.Margin = new System.Windows.Forms.Padding(5);
            this.numbericUser2Oktet.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numbericUser2Oktet.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser2Oktet.Name = "numbericUser2Oktet";
            this.numbericUser2Oktet.NoReadOnly = true;
            this.numbericUser2Oktet.ReadOnly = false;
            this.numbericUser2Oktet.Size = new System.Drawing.Size(182, 108);
            this.numbericUser2Oktet.TabIndex = 1;
            this.numbericUser2Oktet.Title = "2 октет";
            this.numbericUser2Oktet.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser2Oktet.VisibleOK = false;
            this.numbericUser2Oktet.ValueChanged += new TableAIS.ValueChangedControl(this.numbericUser1Oktet_ValueChanged);
            this.numbericUser2Oktet.Load += new System.EventHandler(this.numbericUser2Oktet_Load);
            // 
            // numbericUser1Oktet
            // 
            this.numbericUser1Oktet.Default = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.numbericUser1Oktet.DefaultValue = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.numbericUser1Oktet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericUser1Oktet.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUser1Oktet.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUser1Oktet.Location = new System.Drawing.Point(4, 4);
            this.numbericUser1Oktet.Macimum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numbericUser1Oktet.Margin = new System.Windows.Forms.Padding(4);
            this.numbericUser1Oktet.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numbericUser1Oktet.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser1Oktet.Name = "numbericUser1Oktet";
            this.numbericUser1Oktet.NoReadOnly = true;
            this.numbericUser1Oktet.ReadOnly = false;
            this.numbericUser1Oktet.Size = new System.Drawing.Size(184, 110);
            this.numbericUser1Oktet.TabIndex = 0;
            this.numbericUser1Oktet.Title = "1 октет";
            this.numbericUser1Oktet.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUser1Oktet.VisibleOK = false;
            this.numbericUser1Oktet.ValueChanged += new TableAIS.ValueChangedControl(this.numbericUser1Oktet_ValueChanged);
            // 
            // textBoxIpAddress
            // 
            this.textBoxIpAddress.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel3.SetColumnSpan(this.textBoxIpAddress, 2);
            this.textBoxIpAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxIpAddress.Location = new System.Drawing.Point(3, 121);
            this.textBoxIpAddress.Name = "textBoxIpAddress";
            this.textBoxIpAddress.ReadOnly = true;
            this.textBoxIpAddress.Size = new System.Drawing.Size(378, 34);
            this.textBoxIpAddress.TabIndex = 4;
            this.textBoxIpAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonClearIpAddress
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.buttonClearIpAddress, 2);
            this.buttonClearIpAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearIpAddress.Location = new System.Drawing.Point(387, 121);
            this.buttonClearIpAddress.Name = "buttonClearIpAddress";
            this.buttonClearIpAddress.Size = new System.Drawing.Size(380, 44);
            this.buttonClearIpAddress.TabIndex = 5;
            this.buttonClearIpAddress.Text = "Сбросить полностью IP-адрес";
            this.buttonClearIpAddress.UseVisualStyleBackColor = true;
            this.buttonClearIpAddress.Click += new System.EventHandler(this.buttonClearIpAddress_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel2.SetColumnSpan(this.tableLayoutPanel4, 2);
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Controls.Add(this.numbericUserPort, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBoxAddress, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 210);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(384, 202);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // numbericUserPort
            // 
            this.numbericUserPort.Default = new decimal(new int[] {
            9000,
            0,
            0,
            0});
            this.numbericUserPort.DefaultValue = new decimal(new int[] {
            9000,
            0,
            0,
            0});
            this.numbericUserPort.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericUserPort.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUserPort.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUserPort.Location = new System.Drawing.Point(4, 4);
            this.numbericUserPort.Macimum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numbericUserPort.Margin = new System.Windows.Forms.Padding(4);
            this.numbericUserPort.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numbericUserPort.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUserPort.Name = "numbericUserPort";
            this.numbericUserPort.NoReadOnly = true;
            this.numbericUserPort.ReadOnly = false;
            this.numbericUserPort.Size = new System.Drawing.Size(376, 144);
            this.numbericUserPort.TabIndex = 0;
            this.numbericUserPort.Title = "Порт";
            this.numbericUserPort.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUserPort.VisibleOK = false;
            this.numbericUserPort.ValueChanged += new TableAIS.ValueChangedControl(this.numbericUser1Oktet_ValueChanged);
            this.numbericUserPort.Load += new System.EventHandler(this.numbericUserPort_Load);
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.BackColor = System.Drawing.Color.White;
            this.textBoxAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxAddress.Location = new System.Drawing.Point(3, 155);
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.ReadOnly = true;
            this.textBoxAddress.Size = new System.Drawing.Size(378, 34);
            this.textBoxAddress.TabIndex = 1;
            this.textBoxAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel2.SetColumnSpan(this.tableLayoutPanel5, 2);
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.buttonCearAll, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonOK, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.buttonCancel, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.buttonSetAddressByMain, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.buttonWriteMain, 0, 4);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(393, 210);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 5;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0008F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0008F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0008F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.9988F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.9988F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(386, 202);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // buttonCearAll
            // 
            this.buttonCearAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCearAll.Location = new System.Drawing.Point(3, 3);
            this.buttonCearAll.Name = "buttonCearAll";
            this.buttonCearAll.Size = new System.Drawing.Size(380, 34);
            this.buttonCearAll.TabIndex = 0;
            this.buttonCearAll.Text = "Сбросить всё";
            this.buttonCearAll.UseVisualStyleBackColor = true;
            this.buttonCearAll.Click += new System.EventHandler(this.buttonCearAll_Click);
            // 
            // buttonOK
            // 
            this.buttonOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonOK.Location = new System.Drawing.Point(3, 43);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(380, 34);
            this.buttonOK.TabIndex = 1;
            this.buttonOK.Text = "ОК";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCancel.Location = new System.Drawing.Point(3, 83);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(380, 34);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Отмена";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonSetAddressByMain
            // 
            this.buttonSetAddressByMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSetAddressByMain.Location = new System.Drawing.Point(3, 123);
            this.buttonSetAddressByMain.Name = "buttonSetAddressByMain";
            this.buttonSetAddressByMain.Size = new System.Drawing.Size(380, 34);
            this.buttonSetAddressByMain.TabIndex = 3;
            this.buttonSetAddressByMain.Text = "Задать адрес с главного экрана";
            this.buttonSetAddressByMain.UseVisualStyleBackColor = true;
            this.buttonSetAddressByMain.Click += new System.EventHandler(this.buttonSetAddressByMain_Click);
            // 
            // buttonWriteMain
            // 
            this.buttonWriteMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonWriteMain.Location = new System.Drawing.Point(3, 163);
            this.buttonWriteMain.Name = "buttonWriteMain";
            this.buttonWriteMain.Size = new System.Drawing.Size(380, 36);
            this.buttonWriteMain.TabIndex = 4;
            this.buttonWriteMain.Text = "Записать на главный экран";
            this.buttonWriteMain.UseVisualStyleBackColor = true;
            this.buttonWriteMain.Click += new System.EventHandler(this.buttonWriteMain_Click);
            // 
            // ClientSocketForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(782, 553);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "ClientSocketForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Адрес сервера";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private NumbericUser numbericUser1Oktet;
        private NumbericUser numbericUser4Oktet;
        private NumbericUser numbericUser3Oktet;
        private NumbericUser numbericUser2Oktet;
        private System.Windows.Forms.TextBox textBoxIpAddress;
        private System.Windows.Forms.Button buttonClearIpAddress;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private NumbericUser numbericUserPort;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Button buttonCearAll;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Button buttonCancel;
        private ButtonClickView buttonSetAddressByMain;
        private ButtonClickView buttonWriteMain;
    }
}