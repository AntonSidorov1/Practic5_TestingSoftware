﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{


    public delegate void SavedText(string text);

    public partial class ClientSocketForm : Form
    {

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public event SavedText SavedText;


        public ClientSocketForm()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public ClientSocketForm(Save save):this()
        {
            Save = save;
        }

        public ClientSocketForm(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        public decimal Port
        {
            get => numbericUserPort.DefaultValue;
            set => numbericUserPort.DefaultValue = value;
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

            buttonCearAll_Click(sender, e);
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void numbericUser1Oktet_ValueChanged(object sender, EventArgs e, decimal value)
        {
            textBoxIpAddress.Text = numbericUser1Oktet.Value + "." + numbericUser2Oktet.Value + "." + numbericUser3Oktet.Value + "." + numbericUser4Oktet.Value;
            textBoxAddress.Text = textBoxIpAddress.Text + ":" + numbericUserPort.Value;
        }

        private void numbericUser2Oktet_Load(object sender, EventArgs e)
        {

        }

        private void buttonClearIpAddress_Click(object sender, EventArgs e)
        {
            numbericUser1Oktet.Clear();
            numbericUser2Oktet.Clear();
            numbericUser3Oktet.Clear();
            numbericUser4Oktet.Clear();
        }

        private void numbericUserPort_Load(object sender, EventArgs e)
        {

        }

        private void buttonCearAll_Click(object sender, EventArgs e)
        {
            buttonClearIpAddress_Click(sender, e);
            numbericUserPort.Clear();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            SavedText?.Invoke(textBoxAddress.Text);
            buttonCancel_Click(sender, e);
        }

        public event SavedText SaveText;

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            button1_Click(sender, e);
        }

        private void buttonSetAddressByMain_Click(object sender, EventArgs e)
        {
            try
            {
                SetAddress(ValueHelper.GetText());

            }
            catch { }
        }

        public void SetAddress(string address)
        {
            try
            {
                string[] parts = address.Split(':');
                int port = int.Parse(parts[1]);
                string[] oktets = parts[0].Split('.');
                int oktet1 = int.Parse(oktets[0]); ;
                int oktet2 = int.Parse(oktets[1]); ;
                int oktet3 = int.Parse(oktets[2]); ;
                int oktet4 = int.Parse(oktets[3]);

                numbericUserPort.Value = port;
                numbericUser1Oktet.Value = oktet1;
                numbericUser2Oktet.Value = oktet2;
                numbericUser3Oktet.Value = oktet3;
                numbericUser4Oktet.Value = oktet4;
            }
            catch { }      
        }

        private void buttonWriteMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(textBoxAddress.Text);
            }
            catch { }
        }
    }
}
