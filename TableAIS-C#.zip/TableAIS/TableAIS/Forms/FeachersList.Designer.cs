﻿namespace TableAIS
{
    partial class FeachersList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FeachersList));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.listBoxFuncNames = new System.Windows.Forms.ListBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip4 = new System.Windows.Forms.MenuStrip();
            this.записатьBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteSpecification = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteSpecificationMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteSpecificationToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxFuncName = new System.Windows.Forms.TextBox();
            this.buttonInputFunc = new System.Windows.Forms.Button();
            this.textBoxSpecification = new TableAIS.TextBoxWithTitle();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxFuncsCount = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxNameFind = new TableAIS.TextBoxWithTitle();
            this.buttonFind = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.flowResize1 = new TableAIS.FlowResize();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.listBoxFuncs = new System.Windows.Forms.ListBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxSort = new System.Windows.Forms.ComboBox();
            this.buttonSortClear = new System.Windows.Forms.Button();
            this.timerFuncName = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.menuStrip4.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.flowResize1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(530, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(223, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(782, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(778, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(413, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 504);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(782, 23);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.09463F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.90537F));
            this.tableLayoutPanel2.Controls.Add(this.listBoxFuncNames, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.6988F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65.30121F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(782, 415);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // listBoxFuncNames
            // 
            this.listBoxFuncNames.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxFuncNames.FormattingEnabled = true;
            this.listBoxFuncNames.ItemHeight = 21;
            this.listBoxFuncNames.Location = new System.Drawing.Point(340, 3);
            this.listBoxFuncNames.Name = "listBoxFuncNames";
            this.listBoxFuncNames.Size = new System.Drawing.Size(439, 138);
            this.listBoxFuncNames.TabIndex = 1;
            this.listBoxFuncNames.Click += new System.EventHandler(this.listBoxFuncNames_SelectedIndexChanged);
            this.listBoxFuncNames.SelectedIndexChanged += new System.EventHandler(this.listBoxFuncNames_SelectedIndexChanged);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.menuStrip4, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.textBoxFuncName, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonInputFunc, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.textBoxSpecification, 0, 2);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(340, 147);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(439, 265);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // menuStrip4
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.menuStrip4, 2);
            this.menuStrip4.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.записатьBToolStripMenuItem});
            this.menuStrip4.Location = new System.Drawing.Point(0, 40);
            this.menuStrip4.Name = "menuStrip4";
            this.menuStrip4.Size = new System.Drawing.Size(439, 27);
            this.menuStrip4.TabIndex = 21;
            this.menuStrip4.Text = "menuStrip4";
            // 
            // записатьBToolStripMenuItem
            // 
            this.записатьBToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonWriteSpecification,
            this.buttonWriteSpecificationMain,
            this.buttonWriteSpecificationToClipboard});
            this.записатьBToolStripMenuItem.Name = "записатьBToolStripMenuItem";
            this.записатьBToolStripMenuItem.Size = new System.Drawing.Size(252, 23);
            this.записатьBToolStripMenuItem.Text = "Сохранить спецификацию";
            // 
            // buttonWriteSpecification
            // 
            this.buttonWriteSpecification.Name = "buttonWriteSpecification";
            this.buttonWriteSpecification.Size = new System.Drawing.Size(278, 26);
            this.buttonWriteSpecification.Text = "На предыдущее окно";
            this.buttonWriteSpecification.Click += new System.EventHandler(this.buttonWriteSpecification_Click);
            // 
            // buttonWriteSpecificationMain
            // 
            this.buttonWriteSpecificationMain.Name = "buttonWriteSpecificationMain";
            this.buttonWriteSpecificationMain.Size = new System.Drawing.Size(278, 26);
            this.buttonWriteSpecificationMain.Text = "На главный экран";
            this.buttonWriteSpecificationMain.Click += new System.EventHandler(this.buttonWriteSpecificationMain_Click);
            // 
            // buttonWriteSpecificationToClipboard
            // 
            this.buttonWriteSpecificationToClipboard.Name = "buttonWriteSpecificationToClipboard";
            this.buttonWriteSpecificationToClipboard.Size = new System.Drawing.Size(278, 26);
            this.buttonWriteSpecificationToClipboard.Text = "В буфер обмена";
            this.buttonWriteSpecificationToClipboard.Click += new System.EventHandler(this.buttonWriteSpecificationToClipboard_Click);
            // 
            // textBoxFuncName
            // 
            this.textBoxFuncName.BackColor = System.Drawing.Color.White;
            this.textBoxFuncName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFuncName.Location = new System.Drawing.Point(3, 3);
            this.textBoxFuncName.Name = "textBoxFuncName";
            this.textBoxFuncName.ReadOnly = true;
            this.textBoxFuncName.Size = new System.Drawing.Size(213, 34);
            this.textBoxFuncName.TabIndex = 0;
            // 
            // buttonInputFunc
            // 
            this.buttonInputFunc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonInputFunc.Location = new System.Drawing.Point(222, 3);
            this.buttonInputFunc.Name = "buttonInputFunc";
            this.buttonInputFunc.Size = new System.Drawing.Size(214, 34);
            this.buttonInputFunc.TabIndex = 1;
            this.buttonInputFunc.Text = "Вставить";
            this.buttonInputFunc.UseVisualStyleBackColor = true;
            this.buttonInputFunc.Click += new System.EventHandler(this.buttonInputFunc_Click);
            // 
            // textBoxSpecification
            // 
            this.textBoxSpecification.AllowNegative = true;
            this.textBoxSpecification.ClearingByReadonly = false;
            this.tableLayoutPanel3.SetColumnSpan(this.textBoxSpecification, 2);
            this.textBoxSpecification.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxSpecification.EnterAllow = true;
            this.textBoxSpecification.Location = new System.Drawing.Point(4, 71);
            this.textBoxSpecification.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSpecification.MultiLine = true;
            this.textBoxSpecification.Name = "textBoxSpecification";
            this.textBoxSpecification.NoReadOnly = false;
            this.textBoxSpecification.ReadOnly = true;
            this.tableLayoutPanel3.SetRowSpan(this.textBoxSpecification, 2);
            this.textBoxSpecification.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxSpecification.SelectionStart = 0;
            this.textBoxSpecification.Size = new System.Drawing.Size(431, 190);
            this.textBoxSpecification.TabIndex = 2;
            this.textBoxSpecification.TextWithLineBreaks = "";
            this.textBoxSpecification.Title = "Спецификация";
            this.textBoxSpecification.UseSystemPasswordChar = false;
            this.textBoxSpecification.Value = "";
            this.textBoxSpecification.ValueBackColor = System.Drawing.Color.White;
            this.textBoxSpecification.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxSpecification.ValueText = "";
            this.textBoxSpecification.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxSpecification.ValueWithLineBreaks = "";
            this.textBoxSpecification.VisibleOK = false;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.47432F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.52568F));
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.textBoxFuncsCount, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.splitContainer1, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel6, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 4;
            this.tableLayoutPanel2.SetRowSpan(this.tableLayoutPanel4, 2);
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(331, 409);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 51);
            this.label1.TabIndex = 1;
            this.label1.Text = "Количество функций:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxFuncsCount
            // 
            this.textBoxFuncsCount.BackColor = System.Drawing.Color.White;
            this.textBoxFuncsCount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFuncsCount.Location = new System.Drawing.Point(180, 133);
            this.textBoxFuncsCount.Name = "textBoxFuncsCount";
            this.textBoxFuncsCount.ReadOnly = true;
            this.textBoxFuncsCount.Size = new System.Drawing.Size(148, 34);
            this.textBoxFuncsCount.TabIndex = 2;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel4.SetColumnSpan(this.tableLayoutPanel5, 2);
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 74F));
            this.tableLayoutPanel5.Controls.Add(this.textBoxNameFind, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonFind, 1, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 43);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(325, 84);
            this.tableLayoutPanel5.TabIndex = 3;
            // 
            // textBoxNameFind
            // 
            this.textBoxNameFind.AllowNegative = true;
            this.textBoxNameFind.ClearingByReadonly = false;
            this.textBoxNameFind.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxNameFind.EnterAllow = true;
            this.textBoxNameFind.Location = new System.Drawing.Point(4, 4);
            this.textBoxNameFind.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNameFind.MultiLine = false;
            this.textBoxNameFind.Name = "textBoxNameFind";
            this.textBoxNameFind.NoReadOnly = true;
            this.textBoxNameFind.ReadOnly = false;
            this.textBoxNameFind.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxNameFind.SelectionStart = 0;
            this.textBoxNameFind.Size = new System.Drawing.Size(243, 76);
            this.textBoxNameFind.TabIndex = 3;
            this.textBoxNameFind.TextWithLineBreaks = "";
            this.textBoxNameFind.Title = "Название/Код для поиска";
            this.textBoxNameFind.UseSystemPasswordChar = false;
            this.textBoxNameFind.Value = "";
            this.textBoxNameFind.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxNameFind.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxNameFind.ValueText = "";
            this.textBoxNameFind.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxNameFind.ValueWithLineBreaks = "";
            this.textBoxNameFind.VisibleOK = false;
            this.textBoxNameFind.ValueChanged += new TableAIS.TextValueChanged(this.textBoxNameFind_ValueChanged);
            // 
            // buttonFind
            // 
            this.buttonFind.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonFind.Location = new System.Drawing.Point(254, 3);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new System.Drawing.Size(68, 78);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Поиск";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new System.EventHandler(this.buttonFind_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.DarkGray;
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tableLayoutPanel4.SetColumnSpan(this.splitContainer1, 2);
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 184);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.White;
            this.splitContainer1.Panel1.Controls.Add(this.flowResize1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.White;
            this.splitContainer1.Panel2.Controls.Add(this.listBoxFuncs);
            this.splitContainer1.Size = new System.Drawing.Size(325, 222);
            this.splitContainer1.SplitterDistance = 25;
            this.splitContainer1.SplitterWidth = 10;
            this.splitContainer1.TabIndex = 4;
            // 
            // flowResize1
            // 
            this.flowResize1.AutoScroll = true;
            this.flowResize1.Controls.Add(this.textBox1);
            this.flowResize1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize1.Location = new System.Drawing.Point(0, 0);
            this.flowResize1.Name = "flowResize1";
            this.flowResize1.Size = new System.Drawing.Size(21, 218);
            this.flowResize1.TabIndex = 0;
            this.flowResize1.WithDelta = 25;
            this.flowResize1.WrapContents = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(0, 230);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // listBoxFuncs
            // 
            this.listBoxFuncs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxFuncs.FormattingEnabled = true;
            this.listBoxFuncs.ItemHeight = 21;
            this.listBoxFuncs.Location = new System.Drawing.Point(0, 0);
            this.listBoxFuncs.Name = "listBoxFuncs";
            this.listBoxFuncs.Size = new System.Drawing.Size(286, 218);
            this.listBoxFuncs.TabIndex = 0;
            this.listBoxFuncs.Click += new System.EventHandler(this.listBoxFuncs_SelectedIndexChanged);
            this.listBoxFuncs.SelectedIndexChanged += new System.EventHandler(this.listBoxFuncs_SelectedIndexChanged);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 3;
            this.tableLayoutPanel4.SetColumnSpan(this.tableLayoutPanel6, 2);
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 141F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel6.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.comboBoxSort, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonSortClear, 2, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(325, 34);
            this.tableLayoutPanel6.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 34);
            this.label2.TabIndex = 0;
            this.label2.Text = "Сортировать";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxSort
            // 
            this.comboBoxSort.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxSort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSort.FormattingEnabled = true;
            this.comboBoxSort.Items.AddRange(new object[] {
            "Не сортировать",
            "По возрастанию",
            "По убыванию",
            "Бинарные операторы по приоритетам",
            "Унарные операторы по приоритетам"});
            this.comboBoxSort.Location = new System.Drawing.Point(144, 3);
            this.comboBoxSort.Name = "comboBoxSort";
            this.comboBoxSort.Size = new System.Drawing.Size(138, 29);
            this.comboBoxSort.TabIndex = 1;
            this.comboBoxSort.SelectedIndexChanged += new System.EventHandler(this.buttonFind_Click);
            // 
            // buttonSortClear
            // 
            this.buttonSortClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSortClear.Location = new System.Drawing.Point(288, 3);
            this.buttonSortClear.Name = "buttonSortClear";
            this.buttonSortClear.Size = new System.Drawing.Size(34, 28);
            this.buttonSortClear.TabIndex = 2;
            this.buttonSortClear.Text = "C";
            this.buttonSortClear.UseVisualStyleBackColor = true;
            this.buttonSortClear.Click += new System.EventHandler(this.buttonSortClear_Click);
            // 
            // timerFuncName
            // 
            this.timerFuncName.Enabled = true;
            this.timerFuncName.Tick += new System.EventHandler(this.timerFuncName_Tick);
            // 
            // FeachersList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(782, 553);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "FeachersList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Список функций";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.menuStrip4.ResumeLayout(false);
            this.menuStrip4.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.flowResize1.ResumeLayout(false);
            this.flowResize1.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ListBox listBoxFuncs;
        private System.Windows.Forms.ListBox listBoxFuncNames;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TextBox textBoxFuncName;
        private System.Windows.Forms.Timer timerFuncName;
        private System.Windows.Forms.Button buttonInputFunc;
        private TextBoxWithTitle textBoxSpecification;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxFuncsCount;
        private System.Windows.Forms.MenuStrip menuStrip4;
        private System.Windows.Forms.ToolStripMenuItem записатьBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteSpecification;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteSpecificationMain;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteSpecificationToClipboard;
        private TextBoxWithTitle textBoxNameFind;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Button buttonFind;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private FlowResize flowResize1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxSort;
        private System.Windows.Forms.Button buttonSortClear;
    }
}