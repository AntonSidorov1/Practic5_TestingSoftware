﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class FeachersList : Form
    {


        public event Func<string> SetFromMain;
        public event Action<string> InputFunc;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public event Func<string> SetNumberFromMain;

        public string SetNumberFromMainInvoke()
        {
            return SetNumberFromMain?.Invoke()??"";
        }

        int ToNumber(string text)
        {
            try
            {
                return int.Parse(text);
            }
            catch 
            {
                return 0;
            }
        }

        public List<FuncNames> GetFuncsFind()
        {
            //return GetFuncs.FindByName(textBoxNameFind.Value);
            return GetFuncs.FindByName(textBoxNameFind.Value, (SortIndex)comboBoxSort.SelectedIndex);
            /*
            string name = textBoxNameFind.Value;
            if (name.Length < 1)
                return GetFuncs;
            else
            {
                if (name[0] == '$')
                {
                    name = name.Remove(0, 1);

                    return GetFuncs.FindAll(p => p.GetAllNames().Any(n => n.ToLower() == name.ToLower())
                    || p.GetPsevdoNameText() == name
                    || p.GetPsevdoName().ToString() == name);
                }
                return GetFuncs.FindAll(p => p.GetAllNames().Any(n => n.ToLower().Contains(name.ToLower())) || p.GetPsevdoNameText().Contains(name));
            }
            */
        }


        public FeachersList()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public FeachersList(Save save):this()
        {
            Save = save;
        }

        public FeachersList(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

            comboBoxSort.SelectedIndex = 0;

            try
            {
                listBoxFuncs.Items.Clear();
                listBoxFuncs.Items.AddRange(GetFuncs.ToArray());
                listBoxFuncs.SelectedIndex = 0;
            }
            catch { }

            textBoxFuncsCount.Text = GetFuncs.Count.ToString();
        }

        public FuncList GetFuncs => ValueHelper.GetFuncsList();

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void listBoxFuncs_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int index = listBoxFuncs.SelectedIndex;
                if(index < 0)
                {
                    listBoxFuncs.SelectedIndex = 0;
                    return;
                }
                FuncNames func = (FuncNames)listBoxFuncs.Items[index];
                listBoxFuncNames.Items.Clear();
                listBoxFuncNames.Items.AddRange(func.GetAllNames().ToArray());
                listBoxFuncNames.SelectedIndex = 0;
                textBoxSpecification.ValueText = func.GetSpecification();
            }
            catch { }

        }

        private void listBoxFuncNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int index = listBoxFuncNames.SelectedIndex;
                if(index < 0)
                {
                    listBoxFuncNames.SelectedIndex = 0;
                    return;
                }
            }
            catch { }
        }

        private void timerFuncName_Tick(object sender, EventArgs e)
        {
            try
            {
                int index1 = listBoxFuncs.SelectedIndex;
                int index2 = listBoxFuncNames.SelectedIndex;
                string name = "";
                try
                {
                    name = ((FuncNames) listBoxFuncs.Items[index1]).GetNameTitle();
                }
                catch
                {
                    name = listBoxFuncs.Items[index1].ToString();
                }
                string fewName = listBoxFuncNames.Items[index2].ToString();
                textBoxFuncName.Text = name + " | " + fewName;
            }
            catch {
                textBoxFuncName.Text = "";
            }

            try
            {
                textBoxFuncsCount.Text = listBoxFuncs.Items.Count + " / " + GetFuncs.Count.ToString();
            }
            catch { }
        }

        private void buttonInputFunc_Click(object sender, EventArgs e)
        {
            int index1 = listBoxFuncs.SelectedIndex;
            int index2 = listBoxFuncNames.SelectedIndex;

            try
            {
                string fewName = listBoxFuncNames.Items[index2].ToString();
                InputFunc?.Invoke(fewName);

            }
            catch { }

            try
            {
                int funcId = (listBoxFuncs.SelectedItem as FuncNames).GetPsevdoName();
                string fewName = listBoxFuncNames.Items[index2].ToString();
                try
                {
                    GetFunction?.Invoke(funcId, index2, fewName);
                }
                catch { }
                try
                {
                    GetFunctionForm?.Invoke(this, funcId, index2, fewName);
                }
                catch { }
            }
            catch { }
        }

        public delegate void RunFunc(int funcId, int nameId, string name);
        public delegate void RunFuncForm(Form form, int funcId, int nameId, string name);
        public event RunFunc GetFunction;
        public event RunFuncForm GetFunctionForm;

        public void SaveV(string text)
        {
            try
            {
                MetrOutput1?.Invoke(text, Save);
            }
            catch
            {

            }
        }

        public void WriteMain(string text)
        {
            try
            {
                ValueHelper.SetText(text);
            }
            catch { }
        }


        void WriteToClipboard(string text)
        {
            try
            {
                Clipboard.SetText(text);
            }
            catch { }
        }

        private void buttonWriteSpecification_Click(object sender, EventArgs e)
        {
            SaveV(textBoxSpecification.ValueText);
        }

        private void buttonWriteSpecificationMain_Click(object sender, EventArgs e)
        {
            WriteMain(textBoxSpecification.ValueText);
        }

        private void buttonWriteSpecificationToClipboard_Click(object sender, EventArgs e)
        {
            WriteToClipboard(textBoxSpecification.ValueText);
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            try
            {
                listBoxFuncs.Items.Clear();
                listBoxFuncNames.Items.Clear();
                textBoxSpecification.Clear();
                listBoxFuncs.Items.AddRange(GetFuncsFind().ToArray());
                listBoxFuncs.SelectedIndex = 0;
            }
            catch { }
        }

        private void textBoxNameFind_ValueChanged(Control control, EventArgs e, string value)
        {
            buttonFind_Click(control, e);
        }

        private void buttonSortClear_Click(object sender, EventArgs e)
        {
            try
            {
                comboBoxSort.SelectedIndex = 0;
            }
            catch { }
        }
    }
}
