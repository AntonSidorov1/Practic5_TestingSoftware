﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class FormSecondsSaved : Form
    {

        SecondDelta secondDelta;

        public SecondDelta SecondDelta
        {
            get => secondDelta; set => secondDelta = value;
        }

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        List<SecondDelta> secondDeltas;

        public List<SecondDelta> SecondDeltas
        {
            get => secondDeltas;
            set => secondDeltas = value;
        }

        public FormSecondsSaved()
        {
            outputChanged = true;
            SecondMetrForm.SecondSaved = false;
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;
            secondDeltas = SecondMetrForm.SecondDeltas;
            SecondDelta = new SecondDelta();

        }

        public FormSecondsSaved(SecondDelta secondDelta) : this()
        {
            SecondDelta = secondDelta;
        }

        public FormSecondsSaved(List<SecondDelta> secondDeltas, SecondDelta secondDelta):this(secondDelta)
        {
            SecondDeltas = secondDeltas;
        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public FormSecondsSaved(Save save):this()
        {
            Save = save;
        }

        public FormSecondsSaved(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        public bool SecondSeaved
        {
            get => SecondMetrForm.SecondSaved;
            set => SecondMetrForm.SecondSaved = value;
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            try
            {
                if(SecondSeaved)
                {
                    SecondSeaved = false;
                    UpdateList();
                }
            }
            catch(Exception ex)
            {

            }
        }

        public void UpdateList()
        {

            try
            {
                int index = SecondIndex;
                listBoxSecondsList.Items.Clear();
                listBoxSecondsList.Items.AddRange(SecondDeltas.ToArray());
                SecondIndex = index;
            }
            catch (Exception ex)
            {

            }

            ValueOutput();
        }

        bool outputChanged;
        public void ValueOutput()
        {
            try
            {
                if(comboBoxOutputList.SelectedIndex < 0)
                {
                    outputChanged = false;
                    comboBoxOutputList.SelectedIndex = 0;
                    outputChanged = true;
                    return;
                }
            }
            catch
            {

            }

            try
            {
                SecondDelta second = NowSecondDelta;
                textBoxSecondMetr.Text = second.VisulDatasNewLine();
                textBoxOutput.Text = second.ToString();
                comboBoxOutputList.SelectedIndex = NowSecondDelta.OutputIndex;
                numbericUserRound.Value = NowSecondDelta.GetRound();
                checkBoxChangePoint.Checked = NowSecondDelta.ChangePoint;

                try
                {
                    toolTipComboBox.SetToolTip(comboBoxOutputList, second.OutputName());
                }
                catch
                {

                }
            }
            catch (Exception ex)
            {
                textBoxSecondMetr.Text = "";
                textBoxOutput.Text = "";
            }

        }

        public int SecondIndex
        {
            get => listBoxSecondsList.SelectedIndex;
            set
            {
                
                int index = value;
                if(index < 0 && listBoxSecondsList.Items.Count > 0)
                {
                    SecondIndex = 0;
                    return;
                }    
                try
                {
                    index = Math.Min(index, listBoxSecondsList.Items.Count - 1);
                    listBoxSecondsList.SelectedIndex = index;
                }
                catch(Exception ex)
                {

                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

            comboBoxOutputList.Items.AddRange(SecondDelta.Outputs);
            UpdateList();
        }

        public new void Close()
        {
            timerTime.Stop();
            timerList.Stop();
            base.Close();
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        SecondDelta NowSecondDelta => SecondDeltas[SecondIndex];

        private void listBoxSecondsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ValueOutput();
            }
            catch(Exception ex)
            {

            }
        }

        private void buttonUpdateList_Click(object sender, EventArgs e)
        {
            UpdateList();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDeltas.RemoveAt(SecondIndex);
            }
            catch(Exception ex)
            {

            }
            UpdateList();
        }

        private void comboBoxOutputList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!outputChanged)
                return;
            try
            {
                try
                {
                    toolTipComboBox.SetToolTip(comboBoxOutputList, comboBoxOutputList.Text);
                }
                catch
                {

                }
                
                NowSecondDelta.OutputIndex = comboBoxOutputList.SelectedIndex;
                ValueOutput();
            }
            catch(Exception ex)
            {

            }
        }

        private void numbericUserRound_ValueChanged(object sender, EventArgs e, decimal value)
        {
            try
            {
                NowSecondDelta.SetRound(value);
                ValueOutput();
            }
            catch(Exception ex)
            {
                
            }
        }

        private void buttonSet_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.StartNowMines(NowSecondDelta);
            }
            catch(Exception ex)
            {

            }
        }

        private void checkBoxChangePoint_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                NowSecondDelta.ChangePoint = (sender as CheckBox).Checked;
                ValueOutput();
            }
            catch (Exception ex)
            {

            }
        }

        FormSecondsSaved secondsSaved;
        private void buttonWrite_Click(object sender, EventArgs e)
        {
            MetrOutput?.Invoke(SecondDelta);
            string text = textBoxOutput.Text;
            text = checkBoxChangePoint.Checked ? text.Replace(",", ".") : text;
            MetrOutput1?.Invoke(text, Save);
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            SecondDeltas.Clear();
            UpdateList();
        }

        private void buttonWriteFullText_Click(object sender, EventArgs e)
        {
            MetrOutput1?.Invoke(textBoxSecondMetr.Text, Save);
        }

        private void buttonWriteMain_Click(object sender, EventArgs e)
        {
            try
            {
                //MetrOutput?.Invoke(SecondDelta);
                string text = textBoxOutput.Text;
                text = SecondDelta.ChangePoint ? text.Replace(",", ".") : text;
                ValueHelper.SetText(text);
            }
            catch { }
        }

        private void buttonWriteFullTextMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(textBoxSecondMetr.Text);
            }
            catch { }
        }

        private void buttonWriteClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBoxOutput.Text);
            }
            catch { }
        }

        private void buttonWriteFullTextClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBoxSecondMetr.Text);
            }
            catch { }
        }
    }
}
