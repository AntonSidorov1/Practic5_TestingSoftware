﻿namespace TableAIS
{
    partial class FormulePartsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormulePartsForm));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.listBoxPartList = new System.Windows.Forms.ListBox();
            this.buttonReload = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonPartsClear = new System.Windows.Forms.Button();
            this.buttonUpdateFormule = new System.Windows.Forms.Button();
            this.buttonChangeBaskets = new System.Windows.Forms.Button();
            this.textBoxFewFormule = new TableAIS.TextBoxWithTitle();
            this.tabControlPart = new System.Windows.Forms.TabControl();
            this.tabPageNum = new System.Windows.Forms.TabPage();
            this.flowResize1 = new TableAIS.FlowResize();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonCalcSecondMetr = new System.Windows.Forms.Button();
            this.textBoxNumber = new TableAIS.TextBoxWithTitle();
            this.buttonBackSpace = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonNumber = new TableAIS.ButtonClickView();
            this.buttonClickView1 = new TableAIS.ButtonClickView();
            this.buttonClickView2 = new TableAIS.ButtonClickView();
            this.buttonClickView3 = new TableAIS.ButtonClickView();
            this.buttonClickView4 = new TableAIS.ButtonClickView();
            this.buttonClickView5 = new TableAIS.ButtonClickView();
            this.buttonClickView6 = new TableAIS.ButtonClickView();
            this.buttonClickView7 = new TableAIS.ButtonClickView();
            this.buttonClickView8 = new TableAIS.ButtonClickView();
            this.buttonClickView9 = new TableAIS.ButtonClickView();
            this.buttonClickView10 = new TableAIS.ButtonClickView();
            this.buttonMines = new System.Windows.Forms.Button();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonSetNumber = new System.Windows.Forms.Button();
            this.buttonReloadNumber = new System.Windows.Forms.Button();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxNumberEnter = new System.Windows.Forms.CheckBox();
            this.checkBoxNumAutoSave = new System.Windows.Forms.CheckBox();
            this.tabPageFunc = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxFuncName = new System.Windows.Forms.TextBox();
            this.comboBoxFuncNames = new System.Windows.Forms.ComboBox();
            this.buttonUpdateFuncNamesList = new System.Windows.Forms.Button();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonReloadNameID = new System.Windows.Forms.Button();
            this.buttonReloadFunc = new System.Windows.Forms.Button();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonFuncList = new System.Windows.Forms.Button();
            this.buttonFuncSet = new System.Windows.Forms.Button();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonOpenConst = new System.Windows.Forms.Button();
            this.buttonReplaceToE = new System.Windows.Forms.Button();
            this.tabPageBasket = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxBasketType = new System.Windows.Forms.ComboBox();
            this.checkBoxBasketAbs = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonUploadBasketType = new System.Windows.Forms.Button();
            this.buttonUploadBasketAbs = new System.Windows.Forms.Button();
            this.buttonUploadBasket = new System.Windows.Forms.Button();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonBasketSet = new System.Windows.Forms.Button();
            this.tabPageExp = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonReplaceExpFunc = new System.Windows.Forms.Button();
            this.buttonOpenConstExp = new System.Windows.Forms.Button();
            this.tabPageStaticVariable = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxStaticVariables = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonUploadStaticVariable = new System.Windows.Forms.Button();
            this.buttonSetStaticVariable = new System.Windows.Forms.Button();
            this.textBoxVariableValue = new TableAIS.TextBoxWithTitle();
            this.buttonOpenVariable = new System.Windows.Forms.Button();
            this.tabPageMemoryVariable = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxMemoryVariables = new TableAIS.Controls.ComboBoxToolTip();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonMemoryVariablesUpdate = new System.Windows.Forms.Button();
            this.buttonMemory = new System.Windows.Forms.Button();
            this.textBoxMemoryVariable = new TableAIS.TextBoxWithTitle();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonUploadMemoryVariable = new System.Windows.Forms.Button();
            this.buttonSetmemoryVariable = new System.Windows.Forms.Button();
            this.buttonOpenMemoryVariable = new System.Windows.Forms.Button();
            this.tabPageUgleOperator = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxUgleOperator = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonUgleOperatorUpload = new System.Windows.Forms.Button();
            this.buttonUgleOperatorSet = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddNumber = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFunction1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFunction = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddOperator = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddExp = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddOpenBasket = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddCloseBasket = new System.Windows.Forms.ToolStripMenuItem();
            this.скобкуСМодулемToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddAbsOpenBasket = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddAbsCloseBasket = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddArraySplit = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddStaticVariable = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddMemoryVariable = new System.Windows.Forms.ToolStripMenuItem();
            this.переменнуюСРезультатамиПостроенияГрафиковToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFxX = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFxY = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddX = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddVarMemoryList = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddUgleOperator = new System.Windows.Forms.ToolStripMenuItem();
            this.текущаяПозицияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonMoveUp = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonMoveDown = new System.Windows.Forms.ToolStripMenuItem();
            this.списокToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задатьЗановоToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выравнятьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.очиститьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьВыражениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddBaskets = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropBaskets = new System.Windows.Forms.ToolStripMenuItem();
            this.раскрытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenVariables = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenConsts = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenConstsAndVariables = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalculate = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonListUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonUpdateFormuleByNoCorrect = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripAutoSaveList = new System.Windows.Forms.ToolStripComboBox();
            this.timerFuncNames = new System.Windows.Forms.Timer(this.components);
            this.timerMemoryVariables = new System.Windows.Forms.Timer(this.components);
            this.buttonPastCalcBFromBCalcB = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tabControlPart.SuspendLayout();
            this.tabPageNum.SuspendLayout();
            this.flowResize1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tabPageFunc.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tabPageBasket.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.tabPageExp.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tabPageStaticVariable.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tabPageMemoryVariable.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.tabPageUgleOperator.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(577, 24);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(24);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(257, 40);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 496);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(862, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(862, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 88F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(858, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(2, 4);
            this.pictureBoxLogotip.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(82, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(88, 0);
            this.labelName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(463, 88);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 474);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(862, 22);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.60666F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.97781F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel2.Controls.Add(this.listBoxPartList, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.buttonReload, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.textBoxFewFormule, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.tabControlPart, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.menuStrip1, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 67.43516F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.56484F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(862, 385);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // listBoxPartList
            // 
            this.listBoxPartList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxPartList.FormattingEnabled = true;
            this.listBoxPartList.ItemHeight = 21;
            this.listBoxPartList.Location = new System.Drawing.Point(2, 42);
            this.listBoxPartList.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.listBoxPartList.Name = "listBoxPartList";
            this.listBoxPartList.Size = new System.Drawing.Size(242, 226);
            this.listBoxPartList.TabIndex = 0;
            this.listBoxPartList.SelectedIndexChanged += new System.EventHandler(this.listBoxPartList_SelectedIndexChanged);
            // 
            // buttonReload
            // 
            this.buttonReload.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonReload.Location = new System.Drawing.Point(2, 4);
            this.buttonReload.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonReload.Name = "buttonReload";
            this.buttonReload.Size = new System.Drawing.Size(242, 30);
            this.buttonReload.TabIndex = 1;
            this.buttonReload.Text = "Заново создать";
            this.buttonReload.UseVisualStyleBackColor = true;
            this.buttonReload.Click += new System.EventHandler(this.buttonReload_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.buttonPartsClear, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.buttonUpdateFormule, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.buttonChangeBaskets, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(2, 276);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(242, 105);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // buttonPartsClear
            // 
            this.buttonPartsClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPartsClear.Location = new System.Drawing.Point(2, 39);
            this.buttonPartsClear.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonPartsClear.Name = "buttonPartsClear";
            this.buttonPartsClear.Size = new System.Drawing.Size(238, 27);
            this.buttonPartsClear.TabIndex = 0;
            this.buttonPartsClear.Text = "Очистить";
            this.buttonPartsClear.UseVisualStyleBackColor = true;
            this.buttonPartsClear.Click += new System.EventHandler(this.buttonPartsClear_Click);
            // 
            // buttonUpdateFormule
            // 
            this.buttonUpdateFormule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUpdateFormule.Location = new System.Drawing.Point(2, 74);
            this.buttonUpdateFormule.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonUpdateFormule.Name = "buttonUpdateFormule";
            this.buttonUpdateFormule.Size = new System.Drawing.Size(238, 27);
            this.buttonUpdateFormule.TabIndex = 1;
            this.buttonUpdateFormule.Text = "Изменить выражение";
            this.buttonUpdateFormule.UseVisualStyleBackColor = true;
            this.buttonUpdateFormule.Click += new System.EventHandler(this.buttonUpdateFormule_Click);
            // 
            // buttonChangeBaskets
            // 
            this.buttonChangeBaskets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonChangeBaskets.Location = new System.Drawing.Point(2, 4);
            this.buttonChangeBaskets.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonChangeBaskets.Name = "buttonChangeBaskets";
            this.buttonChangeBaskets.Size = new System.Drawing.Size(238, 27);
            this.buttonChangeBaskets.TabIndex = 2;
            this.buttonChangeBaskets.Text = "Выравнять";
            this.buttonChangeBaskets.UseVisualStyleBackColor = true;
            this.buttonChangeBaskets.Click += new System.EventHandler(this.buttonChangeBaskets_Click);
            // 
            // textBoxFewFormule
            // 
            this.textBoxFewFormule.AllowNegative = true;
            this.textBoxFewFormule.ClearingByReadonly = false;
            this.tableLayoutPanel2.SetColumnSpan(this.textBoxFewFormule, 2);
            this.textBoxFewFormule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFewFormule.EnterAllow = true;
            this.textBoxFewFormule.Location = new System.Drawing.Point(250, 276);
            this.textBoxFewFormule.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFewFormule.MultiLine = false;
            this.textBoxFewFormule.Name = "textBoxFewFormule";
            this.textBoxFewFormule.NoReadOnly = false;
            this.textBoxFewFormule.ReadOnly = true;
            this.textBoxFewFormule.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxFewFormule.SelectionStart = 0;
            this.textBoxFewFormule.Size = new System.Drawing.Size(608, 105);
            this.textBoxFewFormule.TabIndex = 3;
            this.textBoxFewFormule.TextWithLineBreaks = "";
            this.textBoxFewFormule.Title = "Исходное выражение";
            this.textBoxFewFormule.UseSystemPasswordChar = false;
            this.textBoxFewFormule.Value = "";
            this.textBoxFewFormule.ValueBackColor = System.Drawing.Color.White;
            this.textBoxFewFormule.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxFewFormule.ValueText = "";
            this.textBoxFewFormule.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxFewFormule.ValueWithLineBreaks = "";
            this.textBoxFewFormule.VisibleOK = true;
            // 
            // tabControlPart
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.tabControlPart, 2);
            this.tabControlPart.Controls.Add(this.tabPageNum);
            this.tabControlPart.Controls.Add(this.tabPageFunc);
            this.tabControlPart.Controls.Add(this.tabPageBasket);
            this.tabControlPart.Controls.Add(this.tabPageExp);
            this.tabControlPart.Controls.Add(this.tabPageStaticVariable);
            this.tabControlPart.Controls.Add(this.tabPageMemoryVariable);
            this.tabControlPart.Controls.Add(this.tabPageUgleOperator);
            this.tabControlPart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPart.Location = new System.Drawing.Point(248, 42);
            this.tabControlPart.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tabControlPart.Name = "tabControlPart";
            this.tabControlPart.SelectedIndex = 0;
            this.tabControlPart.Size = new System.Drawing.Size(612, 226);
            this.tabControlPart.TabIndex = 4;
            // 
            // tabPageNum
            // 
            this.tabPageNum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPageNum.Controls.Add(this.flowResize1);
            this.tabPageNum.Location = new System.Drawing.Point(4, 30);
            this.tabPageNum.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tabPageNum.Name = "tabPageNum";
            this.tabPageNum.Padding = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tabPageNum.Size = new System.Drawing.Size(604, 192);
            this.tabPageNum.TabIndex = 0;
            this.tabPageNum.Text = "Число";
            this.tabPageNum.UseVisualStyleBackColor = true;
            // 
            // flowResize1
            // 
            this.flowResize1.AutoScroll = true;
            this.flowResize1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize1.Controls.Add(this.tableLayoutPanel4);
            this.flowResize1.Controls.Add(this.tableLayoutPanel23);
            this.flowResize1.Controls.Add(this.buttonPastCalcBFromBCalcB);
            this.flowResize1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize1.Location = new System.Drawing.Point(2, 4);
            this.flowResize1.Name = "flowResize1";
            this.flowResize1.Size = new System.Drawing.Size(596, 180);
            this.flowResize1.TabIndex = 0;
            this.flowResize1.WithDelta = 35;
            this.flowResize1.WrapContents = false;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.Controls.Add(this.buttonCalcSecondMetr, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.textBoxNumber, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.buttonBackSpace, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(2, 4);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(561, 180);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // buttonCalcSecondMetr
            // 
            this.buttonCalcSecondMetr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalcSecondMetr.Location = new System.Drawing.Point(434, 93);
            this.buttonCalcSecondMetr.Name = "buttonCalcSecondMetr";
            this.buttonCalcSecondMetr.Size = new System.Drawing.Size(124, 84);
            this.buttonCalcSecondMetr.TabIndex = 7;
            this.buttonCalcSecondMetr.Text = "Секундомер";
            this.buttonCalcSecondMetr.UseVisualStyleBackColor = true;
            this.buttonCalcSecondMetr.Click += new System.EventHandler(this.buttonCalcSecondMetr_Click);
            // 
            // textBoxNumber
            // 
            this.textBoxNumber.AllowNegative = true;
            this.textBoxNumber.ClearingByReadonly = false;
            this.textBoxNumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxNumber.EnterAllow = true;
            this.textBoxNumber.Location = new System.Drawing.Point(4, 4);
            this.textBoxNumber.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNumber.MultiLine = false;
            this.textBoxNumber.Name = "textBoxNumber";
            this.textBoxNumber.NoReadOnly = true;
            this.textBoxNumber.ReadOnly = false;
            this.textBoxNumber.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxNumber.SelectionStart = 0;
            this.textBoxNumber.Size = new System.Drawing.Size(423, 82);
            this.textBoxNumber.TabIndex = 0;
            this.textBoxNumber.TextWithLineBreaks = "";
            this.textBoxNumber.Title = "Число";
            this.textBoxNumber.UseSystemPasswordChar = false;
            this.textBoxNumber.Value = "";
            this.textBoxNumber.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxNumber.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxNumber.ValueText = "";
            this.textBoxNumber.ValueType = TableAIS.TextTitleType.Double;
            this.textBoxNumber.ValueWithLineBreaks = "";
            this.textBoxNumber.VisibleOK = false;
            this.textBoxNumber.EnterKeyDown += new TableAIS.TextValueChanged(this.textBoxNumber_EnterKeyDown);
            this.textBoxNumber.ValueChanged += new TableAIS.TextValueChanged(this.textBoxNumber_ValueChanged);
            // 
            // buttonBackSpace
            // 
            this.buttonBackSpace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBackSpace.Location = new System.Drawing.Point(433, 4);
            this.buttonBackSpace.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonBackSpace.Name = "buttonBackSpace";
            this.buttonBackSpace.Size = new System.Drawing.Size(126, 82);
            this.buttonBackSpace.TabIndex = 1;
            this.buttonBackSpace.Text = "⇐";
            this.buttonBackSpace.UseVisualStyleBackColor = true;
            this.buttonBackSpace.Click += new System.EventHandler(this.buttonBackSpace_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 156F));
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel6, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel7, 1, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(2, 94);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 82F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(427, 82);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 6;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 87F));
            this.tableLayoutPanel6.Controls.Add(this.buttonNumber, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickView1, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickView2, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickView3, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickView4, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickView5, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickView6, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickView7, 2, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickView8, 3, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickView9, 4, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonClickView10, 5, 1);
            this.tableLayoutPanel6.Controls.Add(this.buttonMines, 5, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(2, 4);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(267, 74);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // buttonNumber
            // 
            this.buttonNumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonNumber.Location = new System.Drawing.Point(2, 4);
            this.buttonNumber.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonNumber.Name = "buttonNumber";
            this.buttonNumber.Size = new System.Drawing.Size(32, 29);
            this.buttonNumber.TabIndex = 0;
            this.buttonNumber.Text = "0";
            this.buttonNumber.UseVisualStyleBackColor = true;
            this.buttonNumber.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonClickView1
            // 
            this.buttonClickView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView1.Location = new System.Drawing.Point(38, 4);
            this.buttonClickView1.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonClickView1.Name = "buttonClickView1";
            this.buttonClickView1.Size = new System.Drawing.Size(32, 29);
            this.buttonClickView1.TabIndex = 0;
            this.buttonClickView1.Text = "1";
            this.buttonClickView1.UseVisualStyleBackColor = true;
            this.buttonClickView1.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonClickView2
            // 
            this.buttonClickView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView2.Location = new System.Drawing.Point(74, 4);
            this.buttonClickView2.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonClickView2.Name = "buttonClickView2";
            this.buttonClickView2.Size = new System.Drawing.Size(32, 29);
            this.buttonClickView2.TabIndex = 0;
            this.buttonClickView2.Text = "2";
            this.buttonClickView2.UseVisualStyleBackColor = true;
            this.buttonClickView2.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonClickView3
            // 
            this.buttonClickView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView3.Location = new System.Drawing.Point(110, 4);
            this.buttonClickView3.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonClickView3.Name = "buttonClickView3";
            this.buttonClickView3.Size = new System.Drawing.Size(32, 29);
            this.buttonClickView3.TabIndex = 0;
            this.buttonClickView3.Text = "3";
            this.buttonClickView3.UseVisualStyleBackColor = true;
            this.buttonClickView3.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonClickView4
            // 
            this.buttonClickView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView4.Location = new System.Drawing.Point(146, 4);
            this.buttonClickView4.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonClickView4.Name = "buttonClickView4";
            this.buttonClickView4.Size = new System.Drawing.Size(32, 29);
            this.buttonClickView4.TabIndex = 0;
            this.buttonClickView4.Text = "4";
            this.buttonClickView4.UseVisualStyleBackColor = true;
            this.buttonClickView4.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonClickView5
            // 
            this.buttonClickView5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView5.Location = new System.Drawing.Point(2, 41);
            this.buttonClickView5.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonClickView5.Name = "buttonClickView5";
            this.buttonClickView5.Size = new System.Drawing.Size(32, 29);
            this.buttonClickView5.TabIndex = 0;
            this.buttonClickView5.Text = "5";
            this.buttonClickView5.UseVisualStyleBackColor = true;
            this.buttonClickView5.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonClickView6
            // 
            this.buttonClickView6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView6.Location = new System.Drawing.Point(38, 41);
            this.buttonClickView6.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonClickView6.Name = "buttonClickView6";
            this.buttonClickView6.Size = new System.Drawing.Size(32, 29);
            this.buttonClickView6.TabIndex = 0;
            this.buttonClickView6.Text = "6";
            this.buttonClickView6.UseVisualStyleBackColor = true;
            this.buttonClickView6.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonClickView7
            // 
            this.buttonClickView7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView7.Location = new System.Drawing.Point(74, 41);
            this.buttonClickView7.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonClickView7.Name = "buttonClickView7";
            this.buttonClickView7.Size = new System.Drawing.Size(32, 29);
            this.buttonClickView7.TabIndex = 0;
            this.buttonClickView7.Text = "7";
            this.buttonClickView7.UseVisualStyleBackColor = true;
            this.buttonClickView7.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonClickView8
            // 
            this.buttonClickView8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView8.Location = new System.Drawing.Point(110, 41);
            this.buttonClickView8.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonClickView8.Name = "buttonClickView8";
            this.buttonClickView8.Size = new System.Drawing.Size(32, 29);
            this.buttonClickView8.TabIndex = 0;
            this.buttonClickView8.Text = "8";
            this.buttonClickView8.UseVisualStyleBackColor = true;
            this.buttonClickView8.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonClickView9
            // 
            this.buttonClickView9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView9.Location = new System.Drawing.Point(146, 41);
            this.buttonClickView9.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonClickView9.Name = "buttonClickView9";
            this.buttonClickView9.Size = new System.Drawing.Size(32, 29);
            this.buttonClickView9.TabIndex = 0;
            this.buttonClickView9.Text = "9";
            this.buttonClickView9.UseVisualStyleBackColor = true;
            this.buttonClickView9.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonClickView10
            // 
            this.buttonClickView10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClickView10.Location = new System.Drawing.Point(182, 41);
            this.buttonClickView10.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonClickView10.Name = "buttonClickView10";
            this.buttonClickView10.Size = new System.Drawing.Size(83, 29);
            this.buttonClickView10.TabIndex = 0;
            this.buttonClickView10.Text = ",";
            this.buttonClickView10.UseVisualStyleBackColor = true;
            this.buttonClickView10.ClickView += new TableAIS.ClickView(this.buttonNumber_ClickView);
            // 
            // buttonMines
            // 
            this.buttonMines.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMines.Location = new System.Drawing.Point(182, 4);
            this.buttonMines.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonMines.Name = "buttonMines";
            this.buttonMines.Size = new System.Drawing.Size(83, 29);
            this.buttonMines.TabIndex = 1;
            this.buttonMines.Text = "+/-";
            this.buttonMines.UseVisualStyleBackColor = true;
            this.buttonMines.Click += new System.EventHandler(this.buttonMines_Click);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Controls.Add(this.buttonSetNumber, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonReloadNumber, 0, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(273, 4);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(152, 74);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // buttonSetNumber
            // 
            this.buttonSetNumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSetNumber.Location = new System.Drawing.Point(2, 4);
            this.buttonSetNumber.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonSetNumber.Name = "buttonSetNumber";
            this.buttonSetNumber.Size = new System.Drawing.Size(148, 29);
            this.buttonSetNumber.TabIndex = 0;
            this.buttonSetNumber.Text = "Задать";
            this.buttonSetNumber.UseVisualStyleBackColor = true;
            this.buttonSetNumber.Click += new System.EventHandler(this.buttonSetNumber_Click);
            // 
            // buttonReloadNumber
            // 
            this.buttonReloadNumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonReloadNumber.Location = new System.Drawing.Point(2, 41);
            this.buttonReloadNumber.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonReloadNumber.Name = "buttonReloadNumber";
            this.buttonReloadNumber.Size = new System.Drawing.Size(148, 29);
            this.buttonReloadNumber.TabIndex = 1;
            this.buttonReloadNumber.Text = "Восстановить";
            this.buttonReloadNumber.UseVisualStyleBackColor = true;
            this.buttonReloadNumber.Click += new System.EventHandler(this.buttonReloadNumber_Click);
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 2;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Controls.Add(this.checkBoxNumberEnter, 0, 0);
            this.tableLayoutPanel23.Controls.Add(this.checkBoxNumAutoSave, 0, 0);
            this.tableLayoutPanel23.Location = new System.Drawing.Point(3, 191);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(561, 50);
            this.tableLayoutPanel23.TabIndex = 1;
            // 
            // checkBoxNumberEnter
            // 
            this.checkBoxNumberEnter.AutoSize = true;
            this.checkBoxNumberEnter.Checked = true;
            this.checkBoxNumberEnter.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxNumberEnter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxNumberEnter.Location = new System.Drawing.Point(283, 3);
            this.checkBoxNumberEnter.Name = "checkBoxNumberEnter";
            this.checkBoxNumberEnter.Size = new System.Drawing.Size(275, 44);
            this.checkBoxNumberEnter.TabIndex = 6;
            this.checkBoxNumberEnter.Text = "Задавать по Enter";
            this.checkBoxNumberEnter.UseVisualStyleBackColor = true;
            // 
            // checkBoxNumAutoSave
            // 
            this.checkBoxNumAutoSave.AutoSize = true;
            this.checkBoxNumAutoSave.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxNumAutoSave.Location = new System.Drawing.Point(3, 3);
            this.checkBoxNumAutoSave.Name = "checkBoxNumAutoSave";
            this.checkBoxNumAutoSave.Size = new System.Drawing.Size(274, 44);
            this.checkBoxNumAutoSave.TabIndex = 5;
            this.checkBoxNumAutoSave.Text = "Задавать автоматически";
            this.checkBoxNumAutoSave.UseVisualStyleBackColor = true;
            // 
            // tabPageFunc
            // 
            this.tabPageFunc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPageFunc.Controls.Add(this.tableLayoutPanel8);
            this.tabPageFunc.Location = new System.Drawing.Point(4, 30);
            this.tabPageFunc.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tabPageFunc.Name = "tabPageFunc";
            this.tabPageFunc.Padding = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tabPageFunc.Size = new System.Drawing.Size(604, 192);
            this.tabPageFunc.TabIndex = 1;
            this.tabPageFunc.Text = "Функция";
            this.tabPageFunc.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel10, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel11, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel12, 1, 1);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(2, 4);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(596, 180);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.textBoxFuncName, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.comboBoxFuncNames, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.buttonUpdateFuncNamesList, 1, 1);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(2, 4);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(294, 82);
            this.tableLayoutPanel9.TabIndex = 0;
            // 
            // textBoxFuncName
            // 
            this.textBoxFuncName.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel9.SetColumnSpan(this.textBoxFuncName, 2);
            this.textBoxFuncName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFuncName.Location = new System.Drawing.Point(2, 4);
            this.textBoxFuncName.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.textBoxFuncName.Name = "textBoxFuncName";
            this.textBoxFuncName.ReadOnly = true;
            this.textBoxFuncName.Size = new System.Drawing.Size(290, 33);
            this.textBoxFuncName.TabIndex = 0;
            // 
            // comboBoxFuncNames
            // 
            this.comboBoxFuncNames.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxFuncNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFuncNames.FormattingEnabled = true;
            this.comboBoxFuncNames.Location = new System.Drawing.Point(2, 45);
            this.comboBoxFuncNames.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.comboBoxFuncNames.Name = "comboBoxFuncNames";
            this.comboBoxFuncNames.Size = new System.Drawing.Size(143, 29);
            this.comboBoxFuncNames.TabIndex = 1;
            this.comboBoxFuncNames.SelectedIndexChanged += new System.EventHandler(this.comboBoxFuncNames_SelectedIndexChanged);
            // 
            // buttonUpdateFuncNamesList
            // 
            this.buttonUpdateFuncNamesList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUpdateFuncNamesList.Location = new System.Drawing.Point(149, 45);
            this.buttonUpdateFuncNamesList.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonUpdateFuncNamesList.Name = "buttonUpdateFuncNamesList";
            this.buttonUpdateFuncNamesList.Size = new System.Drawing.Size(143, 33);
            this.buttonUpdateFuncNamesList.TabIndex = 2;
            this.buttonUpdateFuncNamesList.Text = "Обновить";
            this.buttonUpdateFuncNamesList.UseVisualStyleBackColor = true;
            this.buttonUpdateFuncNamesList.Click += new System.EventHandler(this.buttonUpdateFuncNamesList_Click);
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.Controls.Add(this.buttonReloadNameID, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.buttonReloadFunc, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(2, 94);
            this.tableLayoutPanel10.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(294, 82);
            this.tableLayoutPanel10.TabIndex = 1;
            // 
            // buttonReloadNameID
            // 
            this.buttonReloadNameID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonReloadNameID.Location = new System.Drawing.Point(2, 4);
            this.buttonReloadNameID.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonReloadNameID.Name = "buttonReloadNameID";
            this.buttonReloadNameID.Size = new System.Drawing.Size(290, 33);
            this.buttonReloadNameID.TabIndex = 0;
            this.buttonReloadNameID.Text = "Восстановить название";
            this.buttonReloadNameID.UseVisualStyleBackColor = true;
            this.buttonReloadNameID.Click += new System.EventHandler(this.buttonReloadNameID_Click);
            // 
            // buttonReloadFunc
            // 
            this.buttonReloadFunc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonReloadFunc.Location = new System.Drawing.Point(2, 45);
            this.buttonReloadFunc.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonReloadFunc.Name = "buttonReloadFunc";
            this.buttonReloadFunc.Size = new System.Drawing.Size(290, 33);
            this.buttonReloadFunc.TabIndex = 1;
            this.buttonReloadFunc.Text = "Восстановить функцию";
            this.buttonReloadFunc.UseVisualStyleBackColor = true;
            this.buttonReloadFunc.Click += new System.EventHandler(this.buttonReloadFunc_Click);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.buttonFuncList, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.buttonFuncSet, 0, 1);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(300, 4);
            this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(294, 82);
            this.tableLayoutPanel11.TabIndex = 2;
            // 
            // buttonFuncList
            // 
            this.buttonFuncList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonFuncList.Location = new System.Drawing.Point(2, 4);
            this.buttonFuncList.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonFuncList.Name = "buttonFuncList";
            this.buttonFuncList.Size = new System.Drawing.Size(290, 33);
            this.buttonFuncList.TabIndex = 0;
            this.buttonFuncList.Text = "Функция из списка";
            this.buttonFuncList.UseVisualStyleBackColor = true;
            this.buttonFuncList.Click += new System.EventHandler(this.buttonFuncList_Click);
            // 
            // buttonFuncSet
            // 
            this.buttonFuncSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonFuncSet.Location = new System.Drawing.Point(2, 45);
            this.buttonFuncSet.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.buttonFuncSet.Name = "buttonFuncSet";
            this.buttonFuncSet.Size = new System.Drawing.Size(290, 33);
            this.buttonFuncSet.TabIndex = 1;
            this.buttonFuncSet.Text = "Задать";
            this.buttonFuncSet.UseVisualStyleBackColor = true;
            this.buttonFuncSet.Click += new System.EventHandler(this.buttonFuncSet_Click);
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel12.Controls.Add(this.buttonOpenConst, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.buttonReplaceToE, 0, 1);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(301, 93);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(292, 84);
            this.tableLayoutPanel12.TabIndex = 3;
            // 
            // buttonOpenConst
            // 
            this.buttonOpenConst.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonOpenConst.Location = new System.Drawing.Point(3, 3);
            this.buttonOpenConst.Name = "buttonOpenConst";
            this.buttonOpenConst.Size = new System.Drawing.Size(286, 36);
            this.buttonOpenConst.TabIndex = 0;
            this.buttonOpenConst.Text = "Раскрыть константу";
            this.buttonOpenConst.UseVisualStyleBackColor = true;
            this.buttonOpenConst.Click += new System.EventHandler(this.buttonOpenConst_Click);
            // 
            // buttonReplaceToE
            // 
            this.buttonReplaceToE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonReplaceToE.Location = new System.Drawing.Point(3, 45);
            this.buttonReplaceToE.Name = "buttonReplaceToE";
            this.buttonReplaceToE.Size = new System.Drawing.Size(286, 36);
            this.buttonReplaceToE.TabIndex = 1;
            this.buttonReplaceToE.Text = "Заменить на E";
            this.buttonReplaceToE.UseVisualStyleBackColor = true;
            this.buttonReplaceToE.Click += new System.EventHandler(this.buttonReplaceToE_Click);
            // 
            // tabPageBasket
            // 
            this.tabPageBasket.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPageBasket.Controls.Add(this.tableLayoutPanel13);
            this.tabPageBasket.Location = new System.Drawing.Point(4, 30);
            this.tabPageBasket.Name = "tabPageBasket";
            this.tabPageBasket.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBasket.Size = new System.Drawing.Size(604, 192);
            this.tabPageBasket.TabIndex = 2;
            this.tabPageBasket.Text = "Скобка";
            this.tabPageBasket.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Controls.Add(this.comboBoxBasketType, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.checkBoxBasketAbs, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel14, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel15, 1, 1);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(594, 182);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // comboBoxBasketType
            // 
            this.comboBoxBasketType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxBasketType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBasketType.FormattingEnabled = true;
            this.comboBoxBasketType.Items.AddRange(new object[] {
            "Открывающая \"(\"",
            "Закрывающая \")\""});
            this.comboBoxBasketType.Location = new System.Drawing.Point(3, 3);
            this.comboBoxBasketType.Name = "comboBoxBasketType";
            this.comboBoxBasketType.Size = new System.Drawing.Size(291, 29);
            this.comboBoxBasketType.TabIndex = 0;
            // 
            // checkBoxBasketAbs
            // 
            this.checkBoxBasketAbs.AutoSize = true;
            this.checkBoxBasketAbs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxBasketAbs.Location = new System.Drawing.Point(300, 3);
            this.checkBoxBasketAbs.Name = "checkBoxBasketAbs";
            this.checkBoxBasketAbs.Size = new System.Drawing.Size(291, 44);
            this.checkBoxBasketAbs.TabIndex = 1;
            this.checkBoxBasketAbs.Text = "Модуль";
            this.checkBoxBasketAbs.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 1;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel14.Controls.Add(this.buttonUploadBasketType, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.buttonUploadBasketAbs, 0, 1);
            this.tableLayoutPanel14.Controls.Add(this.buttonUploadBasket, 0, 2);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 53);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 3;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(291, 126);
            this.tableLayoutPanel14.TabIndex = 2;
            // 
            // buttonUploadBasketType
            // 
            this.buttonUploadBasketType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUploadBasketType.Location = new System.Drawing.Point(3, 3);
            this.buttonUploadBasketType.Name = "buttonUploadBasketType";
            this.buttonUploadBasketType.Size = new System.Drawing.Size(285, 36);
            this.buttonUploadBasketType.TabIndex = 0;
            this.buttonUploadBasketType.Text = "Восстановить тип";
            this.buttonUploadBasketType.UseVisualStyleBackColor = true;
            this.buttonUploadBasketType.Click += new System.EventHandler(this.buttonUploadBasketType_Click);
            // 
            // buttonUploadBasketAbs
            // 
            this.buttonUploadBasketAbs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUploadBasketAbs.Location = new System.Drawing.Point(3, 45);
            this.buttonUploadBasketAbs.Name = "buttonUploadBasketAbs";
            this.buttonUploadBasketAbs.Size = new System.Drawing.Size(285, 36);
            this.buttonUploadBasketAbs.TabIndex = 1;
            this.buttonUploadBasketAbs.Text = "Восстановить \"модуль\"";
            this.buttonUploadBasketAbs.UseVisualStyleBackColor = true;
            this.buttonUploadBasketAbs.Click += new System.EventHandler(this.buttonUploadBasketAbs_Click);
            // 
            // buttonUploadBasket
            // 
            this.buttonUploadBasket.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUploadBasket.Location = new System.Drawing.Point(3, 87);
            this.buttonUploadBasket.Name = "buttonUploadBasket";
            this.buttonUploadBasket.Size = new System.Drawing.Size(285, 36);
            this.buttonUploadBasket.TabIndex = 2;
            this.buttonUploadBasket.Text = "Восстановить полностью";
            this.buttonUploadBasket.UseVisualStyleBackColor = true;
            this.buttonUploadBasket.Click += new System.EventHandler(this.buttonUploadBasket_Click);
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 1;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Controls.Add(this.buttonBasketSet, 0, 0);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(300, 53);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(291, 126);
            this.tableLayoutPanel15.TabIndex = 3;
            // 
            // buttonBasketSet
            // 
            this.buttonBasketSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBasketSet.Location = new System.Drawing.Point(3, 3);
            this.buttonBasketSet.Name = "buttonBasketSet";
            this.buttonBasketSet.Size = new System.Drawing.Size(285, 57);
            this.buttonBasketSet.TabIndex = 0;
            this.buttonBasketSet.Text = "Задать";
            this.buttonBasketSet.UseVisualStyleBackColor = true;
            this.buttonBasketSet.Click += new System.EventHandler(this.buttonBasketSet_Click);
            // 
            // tabPageExp
            // 
            this.tabPageExp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPageExp.Controls.Add(this.tableLayoutPanel16);
            this.tabPageExp.Location = new System.Drawing.Point(4, 30);
            this.tabPageExp.Name = "tabPageExp";
            this.tabPageExp.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageExp.Size = new System.Drawing.Size(604, 192);
            this.tabPageExp.TabIndex = 3;
            this.tabPageExp.Text = "E";
            this.tabPageExp.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Controls.Add(this.buttonReplaceExpFunc, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.buttonOpenConstExp, 0, 1);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(594, 182);
            this.tableLayoutPanel16.TabIndex = 0;
            // 
            // buttonReplaceExpFunc
            // 
            this.buttonReplaceExpFunc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonReplaceExpFunc.Location = new System.Drawing.Point(3, 3);
            this.buttonReplaceExpFunc.Name = "buttonReplaceExpFunc";
            this.buttonReplaceExpFunc.Size = new System.Drawing.Size(291, 85);
            this.buttonReplaceExpFunc.TabIndex = 0;
            this.buttonReplaceExpFunc.Text = "Преобразовать в функцию";
            this.buttonReplaceExpFunc.UseVisualStyleBackColor = true;
            this.buttonReplaceExpFunc.Click += new System.EventHandler(this.buttonReplaceExpFunc_Click);
            // 
            // buttonOpenConstExp
            // 
            this.buttonOpenConstExp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonOpenConstExp.Location = new System.Drawing.Point(3, 94);
            this.buttonOpenConstExp.Name = "buttonOpenConstExp";
            this.buttonOpenConstExp.Size = new System.Drawing.Size(291, 85);
            this.buttonOpenConstExp.TabIndex = 1;
            this.buttonOpenConstExp.Text = "Раскрыть константу";
            this.buttonOpenConstExp.UseVisualStyleBackColor = true;
            this.buttonOpenConstExp.Click += new System.EventHandler(this.buttonOpenConstExp_Click);
            // 
            // tabPageStaticVariable
            // 
            this.tabPageStaticVariable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPageStaticVariable.Controls.Add(this.tableLayoutPanel17);
            this.tabPageStaticVariable.Location = new System.Drawing.Point(4, 30);
            this.tabPageStaticVariable.Name = "tabPageStaticVariable";
            this.tabPageStaticVariable.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStaticVariable.Size = new System.Drawing.Size(604, 192);
            this.tabPageStaticVariable.TabIndex = 4;
            this.tabPageStaticVariable.Text = "Статическая переменная";
            this.tabPageStaticVariable.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 2;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.Controls.Add(this.comboBoxStaticVariables, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.buttonUploadStaticVariable, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.buttonSetStaticVariable, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.textBoxVariableValue, 0, 2);
            this.tableLayoutPanel17.Controls.Add(this.buttonOpenVariable, 1, 1);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 3;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.88372F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65.11628F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(594, 182);
            this.tableLayoutPanel17.TabIndex = 0;
            // 
            // comboBoxStaticVariables
            // 
            this.comboBoxStaticVariables.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxStaticVariables.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStaticVariables.DropDownWidth = 200;
            this.comboBoxStaticVariables.FormattingEnabled = true;
            this.comboBoxStaticVariables.Location = new System.Drawing.Point(3, 3);
            this.comboBoxStaticVariables.Name = "comboBoxStaticVariables";
            this.comboBoxStaticVariables.Size = new System.Drawing.Size(291, 29);
            this.comboBoxStaticVariables.TabIndex = 0;
            // 
            // buttonUploadStaticVariable
            // 
            this.buttonUploadStaticVariable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUploadStaticVariable.Location = new System.Drawing.Point(3, 36);
            this.buttonUploadStaticVariable.Name = "buttonUploadStaticVariable";
            this.buttonUploadStaticVariable.Size = new System.Drawing.Size(291, 45);
            this.buttonUploadStaticVariable.TabIndex = 1;
            this.buttonUploadStaticVariable.Text = "Восстановить";
            this.buttonUploadStaticVariable.UseVisualStyleBackColor = true;
            this.buttonUploadStaticVariable.Click += new System.EventHandler(this.buttonUploadStaticVariable_Click);
            // 
            // buttonSetStaticVariable
            // 
            this.buttonSetStaticVariable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSetStaticVariable.Location = new System.Drawing.Point(300, 3);
            this.buttonSetStaticVariable.Name = "buttonSetStaticVariable";
            this.buttonSetStaticVariable.Size = new System.Drawing.Size(291, 27);
            this.buttonSetStaticVariable.TabIndex = 2;
            this.buttonSetStaticVariable.Text = "Задать";
            this.buttonSetStaticVariable.UseVisualStyleBackColor = true;
            this.buttonSetStaticVariable.Click += new System.EventHandler(this.buttonSetStaticVariable_Click);
            // 
            // textBoxVariableValue
            // 
            this.textBoxVariableValue.AllowNegative = true;
            this.textBoxVariableValue.ClearingByReadonly = false;
            this.textBoxVariableValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxVariableValue.EnterAllow = true;
            this.textBoxVariableValue.Location = new System.Drawing.Point(4, 88);
            this.textBoxVariableValue.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxVariableValue.MultiLine = false;
            this.textBoxVariableValue.Name = "textBoxVariableValue";
            this.textBoxVariableValue.NoReadOnly = false;
            this.textBoxVariableValue.ReadOnly = true;
            this.textBoxVariableValue.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxVariableValue.SelectionStart = 0;
            this.textBoxVariableValue.Size = new System.Drawing.Size(289, 90);
            this.textBoxVariableValue.TabIndex = 3;
            this.textBoxVariableValue.TextWithLineBreaks = "";
            this.textBoxVariableValue.Title = "Значение переменной";
            this.textBoxVariableValue.UseSystemPasswordChar = false;
            this.textBoxVariableValue.Value = "";
            this.textBoxVariableValue.ValueBackColor = System.Drawing.Color.White;
            this.textBoxVariableValue.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxVariableValue.ValueText = "";
            this.textBoxVariableValue.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxVariableValue.ValueWithLineBreaks = "";
            this.textBoxVariableValue.VisibleOK = false;
            this.textBoxVariableValue.Load += new System.EventHandler(this.textBoxWithTitle1_Load);
            // 
            // buttonOpenVariable
            // 
            this.buttonOpenVariable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonOpenVariable.Location = new System.Drawing.Point(300, 36);
            this.buttonOpenVariable.Name = "buttonOpenVariable";
            this.buttonOpenVariable.Size = new System.Drawing.Size(291, 45);
            this.buttonOpenVariable.TabIndex = 4;
            this.buttonOpenVariable.Text = "Раскрыть";
            this.buttonOpenVariable.UseVisualStyleBackColor = true;
            this.buttonOpenVariable.Click += new System.EventHandler(this.buttonOpenVariable_Click);
            // 
            // tabPageMemoryVariable
            // 
            this.tabPageMemoryVariable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPageMemoryVariable.Controls.Add(this.tableLayoutPanel18);
            this.tabPageMemoryVariable.Location = new System.Drawing.Point(4, 30);
            this.tabPageMemoryVariable.Name = "tabPageMemoryVariable";
            this.tabPageMemoryVariable.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageMemoryVariable.Size = new System.Drawing.Size(604, 192);
            this.tabPageMemoryVariable.TabIndex = 5;
            this.tabPageMemoryVariable.Text = "Переменная памяти";
            this.tabPageMemoryVariable.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Controls.Add(this.comboBoxMemoryVariables, 0, 0);
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel19, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.textBoxMemoryVariable, 0, 1);
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel20, 1, 1);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 2;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(594, 182);
            this.tableLayoutPanel18.TabIndex = 0;
            // 
            // comboBoxMemoryVariables
            // 
            this.comboBoxMemoryVariables.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxMemoryVariables.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMemoryVariables.DropDownWidth = 200;
            this.comboBoxMemoryVariables.FormattingEnabled = true;
            this.comboBoxMemoryVariables.Location = new System.Drawing.Point(3, 3);
            this.comboBoxMemoryVariables.Name = "comboBoxMemoryVariables";
            this.comboBoxMemoryVariables.Size = new System.Drawing.Size(291, 29);
            this.comboBoxMemoryVariables.TabIndex = 0;
            this.comboBoxMemoryVariables.SelectedIndexChanged += new System.EventHandler(this.comboBoxMemoryVariables_SelectedIndexChanged);
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel19.Controls.Add(this.buttonMemoryVariablesUpdate, 0, 0);
            this.tableLayoutPanel19.Controls.Add(this.buttonMemory, 0, 1);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(300, 3);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(291, 85);
            this.tableLayoutPanel19.TabIndex = 1;
            // 
            // buttonMemoryVariablesUpdate
            // 
            this.buttonMemoryVariablesUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMemoryVariablesUpdate.Location = new System.Drawing.Point(3, 3);
            this.buttonMemoryVariablesUpdate.Name = "buttonMemoryVariablesUpdate";
            this.buttonMemoryVariablesUpdate.Size = new System.Drawing.Size(285, 36);
            this.buttonMemoryVariablesUpdate.TabIndex = 0;
            this.buttonMemoryVariablesUpdate.Text = "Обновить";
            this.buttonMemoryVariablesUpdate.UseVisualStyleBackColor = true;
            this.buttonMemoryVariablesUpdate.Click += new System.EventHandler(this.buttonMemoryVariablesUpdate_Click);
            // 
            // buttonMemory
            // 
            this.buttonMemory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonMemory.Location = new System.Drawing.Point(3, 45);
            this.buttonMemory.Name = "buttonMemory";
            this.buttonMemory.Size = new System.Drawing.Size(285, 37);
            this.buttonMemory.TabIndex = 1;
            this.buttonMemory.Text = "Память (История)";
            this.buttonMemory.UseVisualStyleBackColor = true;
            this.buttonMemory.Click += new System.EventHandler(this.buttonMemory_Click);
            // 
            // textBoxMemoryVariable
            // 
            this.textBoxMemoryVariable.AllowNegative = true;
            this.textBoxMemoryVariable.ClearingByReadonly = false;
            this.textBoxMemoryVariable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxMemoryVariable.EnterAllow = true;
            this.textBoxMemoryVariable.Location = new System.Drawing.Point(4, 95);
            this.textBoxMemoryVariable.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMemoryVariable.MultiLine = false;
            this.textBoxMemoryVariable.Name = "textBoxMemoryVariable";
            this.textBoxMemoryVariable.NoReadOnly = false;
            this.textBoxMemoryVariable.ReadOnly = true;
            this.textBoxMemoryVariable.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxMemoryVariable.SelectionStart = 0;
            this.textBoxMemoryVariable.Size = new System.Drawing.Size(289, 83);
            this.textBoxMemoryVariable.TabIndex = 2;
            this.textBoxMemoryVariable.TextWithLineBreaks = "";
            this.textBoxMemoryVariable.Title = "Значение переменной";
            this.textBoxMemoryVariable.UseSystemPasswordChar = false;
            this.textBoxMemoryVariable.Value = "";
            this.textBoxMemoryVariable.ValueBackColor = System.Drawing.Color.White;
            this.textBoxMemoryVariable.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxMemoryVariable.ValueText = "";
            this.textBoxMemoryVariable.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxMemoryVariable.ValueWithLineBreaks = "";
            this.textBoxMemoryVariable.VisibleOK = false;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 2;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.Controls.Add(this.buttonUploadMemoryVariable, 0, 0);
            this.tableLayoutPanel20.Controls.Add(this.buttonSetmemoryVariable, 0, 1);
            this.tableLayoutPanel20.Controls.Add(this.buttonOpenMemoryVariable, 1, 1);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(300, 94);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 2;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(291, 85);
            this.tableLayoutPanel20.TabIndex = 3;
            // 
            // buttonUploadMemoryVariable
            // 
            this.tableLayoutPanel20.SetColumnSpan(this.buttonUploadMemoryVariable, 2);
            this.buttonUploadMemoryVariable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUploadMemoryVariable.Location = new System.Drawing.Point(3, 3);
            this.buttonUploadMemoryVariable.Name = "buttonUploadMemoryVariable";
            this.buttonUploadMemoryVariable.Size = new System.Drawing.Size(285, 36);
            this.buttonUploadMemoryVariable.TabIndex = 0;
            this.buttonUploadMemoryVariable.Text = "Восстановить";
            this.buttonUploadMemoryVariable.UseVisualStyleBackColor = true;
            this.buttonUploadMemoryVariable.Click += new System.EventHandler(this.buttonUploadMemoryVariable_Click);
            // 
            // buttonSetmemoryVariable
            // 
            this.buttonSetmemoryVariable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSetmemoryVariable.Location = new System.Drawing.Point(3, 45);
            this.buttonSetmemoryVariable.Name = "buttonSetmemoryVariable";
            this.buttonSetmemoryVariable.Size = new System.Drawing.Size(139, 37);
            this.buttonSetmemoryVariable.TabIndex = 1;
            this.buttonSetmemoryVariable.Text = "Задать";
            this.buttonSetmemoryVariable.UseVisualStyleBackColor = true;
            this.buttonSetmemoryVariable.Click += new System.EventHandler(this.buttonSetmemoryVariable_Click);
            // 
            // buttonOpenMemoryVariable
            // 
            this.buttonOpenMemoryVariable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonOpenMemoryVariable.Location = new System.Drawing.Point(148, 45);
            this.buttonOpenMemoryVariable.Name = "buttonOpenMemoryVariable";
            this.buttonOpenMemoryVariable.Size = new System.Drawing.Size(140, 37);
            this.buttonOpenMemoryVariable.TabIndex = 2;
            this.buttonOpenMemoryVariable.Text = "Раскрыть";
            this.buttonOpenMemoryVariable.UseVisualStyleBackColor = true;
            this.buttonOpenMemoryVariable.Click += new System.EventHandler(this.buttonOpenMemoryVariable_Click);
            // 
            // tabPageUgleOperator
            // 
            this.tabPageUgleOperator.Controls.Add(this.tableLayoutPanel21);
            this.tabPageUgleOperator.Location = new System.Drawing.Point(4, 30);
            this.tabPageUgleOperator.Name = "tabPageUgleOperator";
            this.tabPageUgleOperator.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageUgleOperator.Size = new System.Drawing.Size(604, 192);
            this.tabPageUgleOperator.TabIndex = 6;
            this.tabPageUgleOperator.Text = "Угловой оператор";
            this.tabPageUgleOperator.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Controls.Add(this.comboBoxUgleOperator, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.buttonUgleOperatorUpload, 0, 1);
            this.tableLayoutPanel21.Controls.Add(this.buttonUgleOperatorSet, 1, 0);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 2;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(598, 186);
            this.tableLayoutPanel21.TabIndex = 0;
            // 
            // comboBoxUgleOperator
            // 
            this.comboBoxUgleOperator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxUgleOperator.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUgleOperator.DropDownWidth = 200;
            this.comboBoxUgleOperator.FormattingEnabled = true;
            this.comboBoxUgleOperator.Items.AddRange(new object[] {
            "Градусы (°)",
            "Минуты (\')",
            "Секундв (\'\')"});
            this.comboBoxUgleOperator.Location = new System.Drawing.Point(3, 3);
            this.comboBoxUgleOperator.Name = "comboBoxUgleOperator";
            this.comboBoxUgleOperator.Size = new System.Drawing.Size(293, 29);
            this.comboBoxUgleOperator.TabIndex = 0;
            // 
            // buttonUgleOperatorUpload
            // 
            this.buttonUgleOperatorUpload.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUgleOperatorUpload.Location = new System.Drawing.Point(3, 96);
            this.buttonUgleOperatorUpload.Name = "buttonUgleOperatorUpload";
            this.buttonUgleOperatorUpload.Size = new System.Drawing.Size(293, 87);
            this.buttonUgleOperatorUpload.TabIndex = 1;
            this.buttonUgleOperatorUpload.Text = "Восстановить";
            this.buttonUgleOperatorUpload.UseVisualStyleBackColor = true;
            this.buttonUgleOperatorUpload.Click += new System.EventHandler(this.buttonUgleOperatorUpload_Click);
            // 
            // buttonUgleOperatorSet
            // 
            this.buttonUgleOperatorSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUgleOperatorSet.Location = new System.Drawing.Point(302, 3);
            this.buttonUgleOperatorSet.Name = "buttonUgleOperatorSet";
            this.buttonUgleOperatorSet.Size = new System.Drawing.Size(293, 87);
            this.buttonUgleOperatorSet.TabIndex = 2;
            this.buttonUgleOperatorSet.Text = "Задать";
            this.buttonUgleOperatorSet.UseVisualStyleBackColor = true;
            this.buttonUgleOperatorSet.Click += new System.EventHandler(this.buttonUgleOperatorSet_Click);
            // 
            // menuStrip1
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.menuStrip1, 2);
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem,
            this.текущаяПозицияToolStripMenuItem,
            this.списокToolStripMenuItem,
            this.toolStripAutoSaveList});
            this.menuStrip1.Location = new System.Drawing.Point(246, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 4, 0, 4);
            this.menuStrip1.Size = new System.Drawing.Size(616, 38);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddNumber,
            this.buttonAddFunction1,
            this.buttonAddExp,
            this.buttonAddOpenBasket,
            this.buttonAddCloseBasket,
            this.скобкуСМодулемToolStripMenuItem,
            this.buttonAddArraySplit,
            this.buttonAddStaticVariable,
            this.buttonAddMemoryVariable,
            this.переменнуюСРезультатамиПостроенияГрафиковToolStripMenuItem,
            this.buttonAddX,
            this.buttonAddVarMemoryList,
            this.buttonAddUgleOperator});
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(92, 30);
            this.добавитьToolStripMenuItem.Text = "Добавить";
            // 
            // buttonAddNumber
            // 
            this.buttonAddNumber.Name = "buttonAddNumber";
            this.buttonAddNumber.Size = new System.Drawing.Size(520, 26);
            this.buttonAddNumber.Text = "Число";
            this.buttonAddNumber.Click += new System.EventHandler(this.buttonAddNumber_Click);
            // 
            // buttonAddFunction1
            // 
            this.buttonAddFunction1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddFunction,
            this.buttonAddOperator});
            this.buttonAddFunction1.Name = "buttonAddFunction1";
            this.buttonAddFunction1.Size = new System.Drawing.Size(520, 26);
            this.buttonAddFunction1.Text = "Функцию/оператор";
            // 
            // buttonAddFunction
            // 
            this.buttonAddFunction.Name = "buttonAddFunction";
            this.buttonAddFunction.Size = new System.Drawing.Size(165, 26);
            this.buttonAddFunction.Text = "Функцию";
            this.buttonAddFunction.Click += new System.EventHandler(this.buttonAddFunction_Click);
            // 
            // buttonAddOperator
            // 
            this.buttonAddOperator.Name = "buttonAddOperator";
            this.buttonAddOperator.Size = new System.Drawing.Size(165, 26);
            this.buttonAddOperator.Text = "Оператор";
            this.buttonAddOperator.Click += new System.EventHandler(this.buttonAddOperator_Click);
            // 
            // buttonAddExp
            // 
            this.buttonAddExp.Name = "buttonAddExp";
            this.buttonAddExp.Size = new System.Drawing.Size(520, 26);
            this.buttonAddExp.Text = "E";
            this.buttonAddExp.Click += new System.EventHandler(this.buttonAddExp_Click);
            // 
            // buttonAddOpenBasket
            // 
            this.buttonAddOpenBasket.Name = "buttonAddOpenBasket";
            this.buttonAddOpenBasket.Size = new System.Drawing.Size(520, 26);
            this.buttonAddOpenBasket.Text = "Открывающую скобку";
            this.buttonAddOpenBasket.Click += new System.EventHandler(this.buttonAddOpenBasket_Click);
            // 
            // buttonAddCloseBasket
            // 
            this.buttonAddCloseBasket.Name = "buttonAddCloseBasket";
            this.buttonAddCloseBasket.Size = new System.Drawing.Size(520, 26);
            this.buttonAddCloseBasket.Text = "Закрывающую скобку";
            this.buttonAddCloseBasket.Click += new System.EventHandler(this.buttonAddCloseBasket_Click);
            // 
            // скобкуСМодулемToolStripMenuItem
            // 
            this.скобкуСМодулемToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddAbsOpenBasket,
            this.buttonAddAbsCloseBasket});
            this.скобкуСМодулемToolStripMenuItem.Name = "скобкуСМодулемToolStripMenuItem";
            this.скобкуСМодулемToolStripMenuItem.Size = new System.Drawing.Size(520, 26);
            this.скобкуСМодулемToolStripMenuItem.Text = "Скобку с модулем";
            // 
            // buttonAddAbsOpenBasket
            // 
            this.buttonAddAbsOpenBasket.Name = "buttonAddAbsOpenBasket";
            this.buttonAddAbsOpenBasket.Size = new System.Drawing.Size(199, 26);
            this.buttonAddAbsOpenBasket.Text = "Открывающую";
            this.buttonAddAbsOpenBasket.Click += new System.EventHandler(this.buttonAddAbsOpenBasket_Click);
            // 
            // buttonAddAbsCloseBasket
            // 
            this.buttonAddAbsCloseBasket.Name = "buttonAddAbsCloseBasket";
            this.buttonAddAbsCloseBasket.Size = new System.Drawing.Size(199, 26);
            this.buttonAddAbsCloseBasket.Text = "Закрывающую";
            this.buttonAddAbsCloseBasket.Click += new System.EventHandler(this.buttonAddAbsCloseBasket_Click);
            // 
            // buttonAddArraySplit
            // 
            this.buttonAddArraySplit.Name = "buttonAddArraySplit";
            this.buttonAddArraySplit.Size = new System.Drawing.Size(520, 26);
            this.buttonAddArraySplit.Text = "Разделитель элементов в массиве \";\"";
            this.buttonAddArraySplit.Click += new System.EventHandler(this.buttonAddArraySplit_Click);
            // 
            // buttonAddStaticVariable
            // 
            this.buttonAddStaticVariable.Name = "buttonAddStaticVariable";
            this.buttonAddStaticVariable.Size = new System.Drawing.Size(520, 26);
            this.buttonAddStaticVariable.Text = "Статическую переменную";
            this.buttonAddStaticVariable.Click += new System.EventHandler(this.buttonAddStaticVariable_Click);
            // 
            // buttonAddMemoryVariable
            // 
            this.buttonAddMemoryVariable.Name = "buttonAddMemoryVariable";
            this.buttonAddMemoryVariable.Size = new System.Drawing.Size(520, 26);
            this.buttonAddMemoryVariable.Text = "Переменную памяти";
            this.buttonAddMemoryVariable.Click += new System.EventHandler(this.buttonAddMemoryVariable_Click);
            // 
            // переменнуюСРезультатамиПостроенияГрафиковToolStripMenuItem
            // 
            this.переменнуюСРезультатамиПостроенияГрафиковToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddFxX,
            this.buttonAddFxY});
            this.переменнуюСРезультатамиПостроенияГрафиковToolStripMenuItem.Name = "переменнуюСРезультатамиПостроенияГрафиковToolStripMenuItem";
            this.переменнуюСРезультатамиПостроенияГрафиковToolStripMenuItem.Size = new System.Drawing.Size(520, 26);
            this.переменнуюСРезультатамиПостроенияГрафиковToolStripMenuItem.Text = "Переменную с результатами построения графиков";
            // 
            // buttonAddFxX
            // 
            this.buttonAddFxX.Name = "buttonAddFxX";
            this.buttonAddFxX.Size = new System.Drawing.Size(99, 26);
            this.buttonAddFxX.Text = "X";
            this.buttonAddFxX.Click += new System.EventHandler(this.buttonAddFxX_Click);
            // 
            // buttonAddFxY
            // 
            this.buttonAddFxY.Name = "buttonAddFxY";
            this.buttonAddFxY.Size = new System.Drawing.Size(99, 26);
            this.buttonAddFxY.Text = "Y";
            this.buttonAddFxY.Click += new System.EventHandler(this.buttonAddFxY_Click);
            // 
            // buttonAddX
            // 
            this.buttonAddX.Name = "buttonAddX";
            this.buttonAddX.Size = new System.Drawing.Size(520, 26);
            this.buttonAddX.Text = "Независимую переменную \"x\" для построения графиков";
            this.buttonAddX.Click += new System.EventHandler(this.buttonAddX_Click);
            // 
            // buttonAddVarMemoryList
            // 
            this.buttonAddVarMemoryList.Name = "buttonAddVarMemoryList";
            this.buttonAddVarMemoryList.Size = new System.Drawing.Size(520, 26);
            this.buttonAddVarMemoryList.Text = "Переменную памяти-списка";
            this.buttonAddVarMemoryList.Click += new System.EventHandler(this.buttonAddVarMemoryList_Click);
            // 
            // buttonAddUgleOperator
            // 
            this.buttonAddUgleOperator.Name = "buttonAddUgleOperator";
            this.buttonAddUgleOperator.Size = new System.Drawing.Size(520, 26);
            this.buttonAddUgleOperator.Text = "Угловой оператор";
            this.buttonAddUgleOperator.Click += new System.EventHandler(this.buttonAddUgleOperator_Click);
            // 
            // текущаяПозицияToolStripMenuItem
            // 
            this.текущаяПозицияToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonDelete,
            this.buttonMoveUp,
            this.buttonMoveDown});
            this.текущаяПозицияToolStripMenuItem.Name = "текущаяПозицияToolStripMenuItem";
            this.текущаяПозицияToolStripMenuItem.Size = new System.Drawing.Size(153, 30);
            this.текущаяПозицияToolStripMenuItem.Text = "Текущая позиция";
            // 
            // buttonDelete
            // 
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(238, 26);
            this.buttonDelete.Text = "Удалить";
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonMoveUp
            // 
            this.buttonMoveUp.Name = "buttonMoveUp";
            this.buttonMoveUp.Size = new System.Drawing.Size(238, 26);
            this.buttonMoveUp.Text = "Переместить вверх";
            this.buttonMoveUp.Click += new System.EventHandler(this.buttonMoveUp_Click);
            // 
            // buttonMoveDown
            // 
            this.buttonMoveDown.Name = "buttonMoveDown";
            this.buttonMoveDown.Size = new System.Drawing.Size(238, 26);
            this.buttonMoveDown.Text = "Переместить вниз";
            this.buttonMoveDown.Click += new System.EventHandler(this.buttonMoveDown_Click);
            // 
            // списокToolStripMenuItem
            // 
            this.списокToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.задатьЗановоToolStripMenuItem,
            this.выравнятьToolStripMenuItem,
            this.очиститьToolStripMenuItem,
            this.изменитьВыражениеToolStripMenuItem,
            this.buttonAddBaskets,
            this.buttonDropBaskets,
            this.раскрытьToolStripMenuItem,
            this.buttonCalculate,
            this.buttonListUpdate,
            this.buttonUpdateFormuleByNoCorrect});
            this.списокToolStripMenuItem.Name = "списокToolStripMenuItem";
            this.списокToolStripMenuItem.Size = new System.Drawing.Size(77, 30);
            this.списокToolStripMenuItem.Text = "Список";
            // 
            // задатьЗановоToolStripMenuItem
            // 
            this.задатьЗановоToolStripMenuItem.Name = "задатьЗановоToolStripMenuItem";
            this.задатьЗановоToolStripMenuItem.Size = new System.Drawing.Size(382, 26);
            this.задатьЗановоToolStripMenuItem.Text = "Задать заново";
            this.задатьЗановоToolStripMenuItem.Click += new System.EventHandler(this.buttonReload_Click);
            // 
            // выравнятьToolStripMenuItem
            // 
            this.выравнятьToolStripMenuItem.Name = "выравнятьToolStripMenuItem";
            this.выравнятьToolStripMenuItem.Size = new System.Drawing.Size(382, 26);
            this.выравнятьToolStripMenuItem.Text = "Выравнять";
            this.выравнятьToolStripMenuItem.Click += new System.EventHandler(this.buttonChangeBaskets_Click);
            // 
            // очиститьToolStripMenuItem
            // 
            this.очиститьToolStripMenuItem.Name = "очиститьToolStripMenuItem";
            this.очиститьToolStripMenuItem.Size = new System.Drawing.Size(382, 26);
            this.очиститьToolStripMenuItem.Text = "Очистить";
            this.очиститьToolStripMenuItem.Click += new System.EventHandler(this.buttonPartsClear_Click);
            // 
            // изменитьВыражениеToolStripMenuItem
            // 
            this.изменитьВыражениеToolStripMenuItem.Name = "изменитьВыражениеToolStripMenuItem";
            this.изменитьВыражениеToolStripMenuItem.Size = new System.Drawing.Size(382, 26);
            this.изменитьВыражениеToolStripMenuItem.Text = "Изменить выражение";
            this.изменитьВыражениеToolStripMenuItem.Click += new System.EventHandler(this.buttonUpdateFormule_Click);
            // 
            // buttonAddBaskets
            // 
            this.buttonAddBaskets.Name = "buttonAddBaskets";
            this.buttonAddBaskets.Size = new System.Drawing.Size(382, 26);
            this.buttonAddBaskets.Text = "Добавить скобки";
            this.buttonAddBaskets.Click += new System.EventHandler(this.buttonAddBaskets_Click);
            // 
            // buttonDropBaskets
            // 
            this.buttonDropBaskets.Name = "buttonDropBaskets";
            this.buttonDropBaskets.Size = new System.Drawing.Size(382, 26);
            this.buttonDropBaskets.Text = "Удалить внешние скобки";
            this.buttonDropBaskets.Click += new System.EventHandler(this.buttonDropBaskets_Click);
            // 
            // раскрытьToolStripMenuItem
            // 
            this.раскрытьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonOpenVariables,
            this.buttonOpenConsts,
            this.buttonOpenConstsAndVariables});
            this.раскрытьToolStripMenuItem.Name = "раскрытьToolStripMenuItem";
            this.раскрытьToolStripMenuItem.Size = new System.Drawing.Size(382, 26);
            this.раскрытьToolStripMenuItem.Text = "Раскрыть";
            // 
            // buttonOpenVariables
            // 
            this.buttonOpenVariables.Name = "buttonOpenVariables";
            this.buttonOpenVariables.Size = new System.Drawing.Size(282, 26);
            this.buttonOpenVariables.Text = "Переменные";
            this.buttonOpenVariables.Click += new System.EventHandler(this.buttonOpenVariables_Click);
            // 
            // buttonOpenConsts
            // 
            this.buttonOpenConsts.Name = "buttonOpenConsts";
            this.buttonOpenConsts.Size = new System.Drawing.Size(282, 26);
            this.buttonOpenConsts.Text = "Константы";
            this.buttonOpenConsts.Click += new System.EventHandler(this.buttonOpenConsts_Click);
            // 
            // buttonOpenConstsAndVariables
            // 
            this.buttonOpenConstsAndVariables.Name = "buttonOpenConstsAndVariables";
            this.buttonOpenConstsAndVariables.Size = new System.Drawing.Size(282, 26);
            this.buttonOpenConstsAndVariables.Text = "Константы и переменные";
            this.buttonOpenConstsAndVariables.Click += new System.EventHandler(this.buttonOpenConstsAndVariables_Click);
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(382, 26);
            this.buttonCalculate.Text = "Вычислить";
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // buttonListUpdate
            // 
            this.buttonListUpdate.Name = "buttonListUpdate";
            this.buttonListUpdate.Size = new System.Drawing.Size(382, 26);
            this.buttonListUpdate.Text = "Обновить";
            this.buttonListUpdate.Click += new System.EventHandler(this.buttonListUpdate_Click);
            // 
            // buttonUpdateFormuleByNoCorrect
            // 
            this.buttonUpdateFormuleByNoCorrect.Name = "buttonUpdateFormuleByNoCorrect";
            this.buttonUpdateFormuleByNoCorrect.Size = new System.Drawing.Size(382, 26);
            this.buttonUpdateFormuleByNoCorrect.Text = "Изменить выражение без исправлений";
            this.buttonUpdateFormuleByNoCorrect.Click += new System.EventHandler(this.buttonUpdateFormuleByNoCorrect_Click);
            // 
            // toolStripAutoSaveList
            // 
            this.toolStripAutoSaveList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripAutoSaveList.Items.AddRange(new object[] {
            "Не изменять выражение автоматически",
            "Изменять выражение автоматически"});
            this.toolStripAutoSaveList.Name = "toolStripAutoSaveList";
            this.toolStripAutoSaveList.Size = new System.Drawing.Size(121, 30);
            // 
            // timerFuncNames
            // 
            this.timerFuncNames.Enabled = true;
            this.timerFuncNames.Interval = 20000;
            this.timerFuncNames.Tick += new System.EventHandler(this.timerFuncNames_Tick);
            // 
            // timerMemoryVariables
            // 
            this.timerMemoryVariables.Enabled = true;
            this.timerMemoryVariables.Interval = 10000;
            this.timerMemoryVariables.Tick += new System.EventHandler(this.buttonMemoryVariablesUpdate_Click);
            // 
            // buttonPastCalcBFromBCalcB
            // 
            this.buttonPastCalcBFromBCalcB.Location = new System.Drawing.Point(3, 247);
            this.buttonPastCalcBFromBCalcB.Name = "buttonPastCalcBFromBCalcB";
            this.buttonPastCalcBFromBCalcB.Size = new System.Drawing.Size(75, 34);
            this.buttonPastCalcBFromBCalcB.TabIndex = 2;
            this.buttonPastCalcBFromBCalcB.Text = "Вставить Calc(B) из B=Calc(B)";
            this.buttonPastCalcBFromBCalcB.UseVisualStyleBackColor = true;
            this.buttonPastCalcBFromBCalcB.Click += new System.EventHandler(this.buttonPastCalcBFromBCalcB_Click);
            // 
            // FormulePartsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(862, 522);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10F);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 569);
            this.Name = "FormulePartsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Интерактивное редактирование выражения";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tabControlPart.ResumeLayout(false);
            this.tabPageNum.ResumeLayout(false);
            this.flowResize1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel23.PerformLayout();
            this.tabPageFunc.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tabPageBasket.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tabPageExp.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tabPageStaticVariable.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tabPageMemoryVariable.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tabPageUgleOperator.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ListBox listBoxPartList;
        private System.Windows.Forms.Button buttonReload;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button buttonPartsClear;
        private System.Windows.Forms.Button buttonUpdateFormule;
        private TextBoxWithTitle textBoxFewFormule;
        private System.Windows.Forms.Button buttonChangeBaskets;
        private System.Windows.Forms.TabControl tabControlPart;
        private System.Windows.Forms.TabPage tabPageNum;
        private System.Windows.Forms.TabPage tabPageFunc;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private TextBoxWithTitle textBoxNumber;
        private System.Windows.Forms.Button buttonBackSpace;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private ButtonClickView buttonNumber;
        private ButtonClickView buttonClickView1;
        private ButtonClickView buttonClickView2;
        private ButtonClickView buttonClickView3;
        private ButtonClickView buttonClickView4;
        private ButtonClickView buttonClickView5;
        private ButtonClickView buttonClickView6;
        private ButtonClickView buttonClickView7;
        private ButtonClickView buttonClickView8;
        private ButtonClickView buttonClickView9;
        private ButtonClickView buttonClickView10;
        private System.Windows.Forms.Button buttonMines;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Button buttonSetNumber;
        private System.Windows.Forms.Button buttonReloadNumber;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.TextBox textBoxFuncName;
        private System.Windows.Forms.ComboBox comboBoxFuncNames;
        private System.Windows.Forms.Button buttonUpdateFuncNamesList;
        private System.Windows.Forms.Timer timerFuncNames;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Button buttonReloadNameID;
        private System.Windows.Forms.Button buttonReloadFunc;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Button buttonFuncList;
        private System.Windows.Forms.Button buttonFuncSet;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddNumber;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFunction1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Button buttonOpenConst;
        private System.Windows.Forms.ToolStripMenuItem buttonAddExp;
        private System.Windows.Forms.TabPage tabPageBasket;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.ComboBox comboBoxBasketType;
        private System.Windows.Forms.CheckBox checkBoxBasketAbs;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Button buttonUploadBasketType;
        private System.Windows.Forms.Button buttonUploadBasketAbs;
        private System.Windows.Forms.Button buttonUploadBasket;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Button buttonBasketSet;
        private System.Windows.Forms.ToolStripMenuItem buttonAddOpenBasket;
        private System.Windows.Forms.ToolStripMenuItem buttonAddCloseBasket;
        private System.Windows.Forms.ToolStripMenuItem скобкуСМодулемToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddAbsOpenBasket;
        private System.Windows.Forms.ToolStripMenuItem buttonAddAbsCloseBasket;
        private System.Windows.Forms.Button buttonReplaceToE;
        private System.Windows.Forms.TabPage tabPageExp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Button buttonReplaceExpFunc;
        private System.Windows.Forms.Button buttonOpenConstExp;
        private System.Windows.Forms.ToolStripMenuItem текущаяПозицияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonDelete;
        private System.Windows.Forms.ToolStripMenuItem buttonMoveUp;
        private System.Windows.Forms.ToolStripMenuItem buttonMoveDown;
        private System.Windows.Forms.ToolStripMenuItem buttonAddArraySplit;
        private System.Windows.Forms.TabPage tabPageStaticVariable;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private Controls.ComboBoxToolTip comboBoxStaticVariables;
        private System.Windows.Forms.Button buttonUploadStaticVariable;
        private System.Windows.Forms.Button buttonSetStaticVariable;
        private TextBoxWithTitle textBoxVariableValue;
        private System.Windows.Forms.Button buttonOpenVariable;
        private System.Windows.Forms.ToolStripMenuItem buttonAddStaticVariable;
        private System.Windows.Forms.TabPage tabPageMemoryVariable;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private Controls.ComboBoxToolTip comboBoxMemoryVariables;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Button buttonMemoryVariablesUpdate;
        private System.Windows.Forms.Timer timerMemoryVariables;
        private System.Windows.Forms.Button buttonMemory;
        private TextBoxWithTitle textBoxMemoryVariable;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Button buttonUploadMemoryVariable;
        private System.Windows.Forms.Button buttonSetmemoryVariable;
        private System.Windows.Forms.Button buttonOpenMemoryVariable;
        private System.Windows.Forms.ToolStripMenuItem buttonAddMemoryVariable;
        private System.Windows.Forms.ToolStripMenuItem списокToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задатьЗановоToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выравнятьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem очиститьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменитьВыражениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddBaskets;
        private System.Windows.Forms.ToolStripMenuItem buttonDropBaskets;
        private System.Windows.Forms.ToolStripMenuItem раскрытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenVariables;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenConsts;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenConstsAndVariables;
        private System.Windows.Forms.ToolStripMenuItem buttonCalculate;
        private System.Windows.Forms.ToolStripMenuItem переменнуюСРезультатамиПостроенияГрафиковToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFxX;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFxY;
        private System.Windows.Forms.ToolStripMenuItem buttonAddX;
        private System.Windows.Forms.ToolStripMenuItem buttonAddVarMemoryList;
        private System.Windows.Forms.TabPage tabPageUgleOperator;
        private System.Windows.Forms.ToolStripMenuItem buttonAddUgleOperator;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private Controls.ComboBoxToolTip comboBoxUgleOperator;
        private System.Windows.Forms.Button buttonUgleOperatorUpload;
        private System.Windows.Forms.Button buttonUgleOperatorSet;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFunction;
        private System.Windows.Forms.ToolStripMenuItem buttonAddOperator;
        private System.Windows.Forms.ToolStripMenuItem buttonListUpdate;
        private System.Windows.Forms.ToolStripComboBox toolStripAutoSaveList;
        private System.Windows.Forms.ToolStripMenuItem buttonUpdateFormuleByNoCorrect;
        private FlowResize flowResize1;
        private System.Windows.Forms.Button buttonCalcSecondMetr;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.CheckBox checkBoxNumAutoSave;
        private System.Windows.Forms.CheckBox checkBoxNumberEnter;
        private System.Windows.Forms.Button buttonPastCalcBFromBCalcB;
    }
}