﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class FormulePartsForm : Form
    {


        public event Func<string> SetFromMain;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public event Func<string> SetNumberFromMain;

        public string SetNumberFromMainInvoke()
        {
            return SetNumberFromMain?.Invoke()??"";
        }

        VariablesList variables;

        public FormulePartsForm()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;
            variables = new VariablesList();
            variables.Add("A");
            variables.Add("B");
            variables.Add("Buffer");
            variables.Add("Bufer");
            variables.Add("Help");
            variables.Add("@A");
            variables.Add("@B");
            variables.Add("@Buffer");
            variables.Add("@Bufer");
            variables.Add("@Help");
            variables.Add("X");
            variables.Add("{~X}");
            variables.Add("{~Y}");
            variables.Add("{~M}");
            comboBoxStaticVariables.Items.AddRange(variables.ToArray());

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public FormulePartsForm(Save save):this()
        {
            Save = save;
        }

        public FormulePartsForm(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        FormuleFunction FuncPart;
        FormuleBaskets BasketPart;

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            try
            {
                textBoxFewFormule.Value = GetFormule?.Invoke();
            }
            catch { }

            try
            {
                tabControlPart.Visible = true;
                FormulePart part = listBoxPartList.SelectedItem as FormulePart;
                part = part.GetThis();

            }
            catch
            {
                tabControlPart.TabPages.Clear();
            }

            try
            {
                textBoxFuncName.Text = FuncPart.Function.ToString();
            }
            catch
            {

            }


            try
            {
                buttonOpenConst.Visible = FuncPart.IsConst();
            }
            catch
            {

            }
            GetVariableValue();
        }

        public event Func<string> GetFormule;


        public event Func<string> GetA, GetB, GetBuffer, GetHelp;
        public event Func<string> GetFewA, GetFewB, GetFewBuffer, GetFewHelp;

        bool IsVarFx(string text)
        {
            text = text.ToLower().Trim();
            string x = "{~X}".ToLower();
            string y = "{~Y}".ToLower();
            string m = "{~M}".ToLower();
            return text == x || text == y || text == m;
        }

        void GetVariableValue()
        {
            try
            {
                string text = "0";
                string name  = comboBoxStaticVariables.SelectedItem.ToString().ToLower();

                switch(name)
                {
                    case "a": text = GetA?.Invoke(); break;
                    case "b": text = GetB?.Invoke(); break;
                    case "help": text = GetHelp?.Invoke(); break;
                    case "bufer": case "buffer": text = GetBuffer?.Invoke(); break;
                    case "@a": text = GetFewA?.Invoke(); break;
                    case "@b": text = GetFewB?.Invoke(); break;
                    case "@help": text = GetFewHelp?.Invoke(); break;
                    case "@bufer": case "@buffer": text = GetFewBuffer?.Invoke(); break;
                    case "{~x}":text = MyCalculate.ArrayX;break;
                    case "{~y}": text = MyCalculate.ArrayY; break;
                    case "{~m}": text = CalculatorMemoryList.FormulersListText(); break;
                    default: text = "0";break;
                }
                


                int length = text.Length;
                if (length < 1)
                    throw new Exception();
                textBoxVariableValue.Value = text;
            }
            catch
            {
                textBoxVariableValue.Value = "0";
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();
            buttonReload_Click(sender, e);

            toolStripAutoSaveList.SelectedIndex = 0;
            Size size = toolStripAutoSaveList.Size;
            size.Width = 200;
            toolStripAutoSaveList.Size = size;
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void buttonReload_Click(object sender, EventArgs e)
        {
            try
            {
               ListView(ReloadFormuleParts?.Invoke());
            }
            catch { }
        }

        public event Func<FormulePartList> ReloadFormuleParts;

        private void buttonPartsClear_Click(object sender, EventArgs e)
        {
            try
            {

                listBoxPartList.Items.Clear();
            }
            catch { }
        }

        private void buttonUpdateFormule_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList partList = GetFormulePartsByList();
                UpdateFewFormule?.Invoke(partList);
                
            }
            catch {
                try
                {
                    UpdateFewFormule?.Invoke("");
                }
                catch {}
            }
            buttonReload_Click(sender, e);
        }

        public event Action<string> UpdateFewFormule;

        private void buttonChangeBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formuleParts = GetFormulePartsByList();
                ListView(formuleParts);
            }
            catch { }
        }

        public FormulePartList GetFormulePartsByListNoCorrect()
        {
            FormulePartList formuleParts = new FormulePartList();

            foreach (object obj in listBoxPartList.Items)
            {
                try
                {
                    formuleParts.Add(obj as FormulePart);
                }
                catch { }
            }
            return formuleParts;
        }

        public FormulePartList GetFormulePartsByList()
        {
           
            FormulePartList formuleParts = MyCalculate.ReplaceToFullFuncsCodeInteractive(GetFormulePartsByListNoCorrect(), 'x');
            return formuleParts;
        }

        private void listBoxPartList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                buttonMemoryVariablesUpdate_Click(sender, e);
            }
            catch { }
            try
            {
                checkBoxNumAutoSave.Checked = false;
            }
            catch
            {

            }
            try
            {
                checkBoxNumberEnter.Checked = true;
            }
            catch
            {

            }
            try
            {
                
                tabControlPart.Visible = true;
                FormulePart part = listBoxPartList.SelectedItem as FormulePart;
                part = part.GetThis().Copy();
                tabControlPart.TabPages.Clear();
                if (part.IsNumber)
                {
                    tabControlPart.TabPages.Add(tabPageNum);
                    textBoxNumber.Value = part.GetText();
                }
                else if (part.IsFunction)
                {
                    tabControlPart.TabPages.Add(tabPageFunc);
                    FuncPart = part.AsFunction;
                    buttonUpdateFuncNamesList_Click(sender,e);
                    comboBoxFuncNames.SelectedIndex = FuncPart.NameID;
                }
                else if(part.IsBaskets)
                {
                    tabControlPart.TabPages.Add(tabPageBasket);
                    BasketPart = part.AsBaskets;
                    BasketUpdate();
                }
                else if(part.IsExp)
                {
                    tabControlPart.TabPages.Add(tabPageExp);
                }
                else if (part.IsStaticVariableThis())
                {
                    tabControlPart.TabPages.Add(tabPageStaticVariable);
                    UploadStaticvariable();
                }
                else if(part.IsMemoryVariable)
                {
                    tabControlPart.TabPages.Add(tabPageMemoryVariable);
                    UploadMemoryVariable();
                }
                else if(part.IsUgleOperator())
                {
                    tabControlPart.TabPages.Add(tabPageUgleOperator);
                    UploadUgleOperator();
                }
            }
            catch
            {
                tabControlPart.TabPages.Clear();
            }
        }

        void UploadUgleOperator()
        {
            try
            {
                object item = listBoxPartList.SelectedItem;
                FormuleUgleOperator operate = item as FormuleUgleOperator;
                comboBoxUgleOperator.SelectedIndex = operate.Dole;
            }
            catch
            {
                try
                {
                    comboBoxUgleOperator.SelectedIndex = 0;
                }
                catch
                {

                }
            }
        }
        void UploadMemoryVariable()
        {
            try
            {
                buttonMemoryVariablesUpdate_Click(new Button(), new EventArgs());
            }
            catch
            {

            }

            try
            {
                FormulePart part = listBoxPartList.SelectedItem as FormulePart;
                FormuleVariableMemory variable = part.AsMemoryVariable;
                comboBoxMemoryVariables.SelectedIndex = CalculatorString.History.FindIndexByNumber(variable.Name);
            }
            catch { }
        }

        public void UploadStaticvariable()
        {
            try
            {
                string name = listBoxPartList.SelectedItem.ToString();
                comboBoxStaticVariables.SelectedIndex = variables.FindIndex(v => v.ToLower() == name.ToLower());
            }
            catch
            {
                comboBoxStaticVariables.SelectedIndex = 0;
            }
        }

        public void BasketTypeUpdate()
        {
            try
            {
                if (BasketPart.IsOpenBasket)
                {
                    comboBoxBasketType.SelectedIndex = 0;
                }
                else
                {
                    comboBoxBasketType.SelectedIndex = 1;
                }
            }
            catch
            {

            }
        }

        public void BasketAbsUpdate()
        {
            try
            {
                checkBoxBasketAbs.Checked = BasketPart.Abs;
            }
            catch { }
        }

        public void BasketUpdate()
        {
            BasketTypeUpdate();
            BasketAbsUpdate();
        }

        private void buttonBackSpace_Click(object sender, EventArgs e)
        {
            try
            {
                string text = textBoxNumber.Value;
                textBoxNumber.Value = text.Substring(0, text.Length - 1);
            }
            catch { }
        }

        private void buttonNumber_ClickView(object sender, EventArgs e, Control control, string text)
        {
            try
            {
                textBoxNumber.RunTextDouble(text);
            }
            catch { }
        }

        private void buttonMines_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxNumber.RunKey('-');
            }
            catch { }
        }

        private void buttonSetNumber_Click(object sender, EventArgs e)
        {
            int index = -1;
            int indexText = textBoxNumber.SelectionStart;
            bool autoSave = checkBoxNumAutoSave.Checked;
            bool enter = checkBoxNumberEnter.Checked;
            try
            {
                index = listBoxPartList.SelectedIndex;
            }
            catch
            {

            }
            try
            {

                double number = MyCalculate.ToDouble(textBoxNumber.Value);
                string text = number.ToString();
                if (number < 0)
                {
                    text = "(" + text + ")";
                    index += 2;
                }
                FormulePartList list = GetFormulePartsByListNoCorrect().SetFormule(listBoxPartList.SelectedIndex, text);
                ListView(list);
            }
            catch { }
            if (index > -1)
            {
                try
                {
                    listBoxPartList.SelectedIndex = index;
                }
                catch { }
            }
            checkBoxNumAutoSave.Checked = autoSave;
            checkBoxNumberEnter.Checked = enter;
            try
            {
                textBoxNumber.Value = ((FormulePart)listBoxPartList.SelectedItem).ToString();
                textBoxNumber.SelectionStart = indexText;
            }
            catch
            {

            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBoxPartList.SelectedIndex;
                listBoxPartList.Items.RemoveAt(index);
            }
            catch { }
        }

        private void buttonReloadNumber_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxNumber.Value = listBoxPartList.SelectedItem.ToString();
            }
            catch { }
        }

        private void buttonUpdateFuncNamesList_Click(object sender, EventArgs e)
        {
            try
            {
                int index = comboBoxFuncNames.SelectedIndex;
                int count = comboBoxFuncNames.Items.Count;
                comboBoxFuncNames.Items.Clear();
                comboBoxFuncNames.Items.AddRange(FuncPart.Function.GetAllNames().ToArray());
                if (count == comboBoxFuncNames.Items.Count)
                    comboBoxFuncNames.SelectedIndex = index;
                else
                    comboBoxFuncNames.SelectedIndex = 0;
            }
            catch {
                try
                {
                    comboBoxFuncNames.SelectedIndex = 0;
                }
                catch {}
            }
        }

        private void timerFuncNames_Tick(object sender, EventArgs e)
        {
            buttonUpdateFuncNamesList_Click(sender, e);
        }

        private void buttonReloadNameID_Click(object sender, EventArgs e)
        {
            try
            {
                buttonUpdateFuncNamesList_Click(sender, e);
                comboBoxFuncNames.SelectedIndex = FuncPart.NameID;

            }
            catch {
                try
                {
                    comboBoxFuncNames.SelectedIndex = 0;
                }
                catch { }
            }

        }

        private void buttonReloadFunc_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePart part = listBoxPartList.SelectedItem as FormulePart;
                FuncPart = part.GetThis().AsFunction;
                buttonReloadNameID_Click(sender, e);
            }
            catch { }
        }

        private void buttonFuncList_Click(object sender, EventArgs e)
        {
            FeachersList feachersList = new FeachersList();
            feachersList.GetFunction += FeachersList_GetFunction;
            feachersList.Show();
        }

        private void FeachersList_GetFunction(int funcId, int nameId, string name)
        {
            try
            {
                FuncPart = new FormuleFunction(funcId, nameId);
                buttonUpdateFuncNamesList_Click(buttonFuncList, new EventArgs());
                comboBoxFuncNames.SelectedIndex = FuncPart.NameID;
            }
            catch
            {
                try
                {
                    comboBoxFuncNames.SelectedIndex = 0;
                }
                catch { }
            }
        }

        private void buttonFuncSet_Click(object sender, EventArgs e)
        {
            try
            {
                FuncPart.GetThis().AsFunction.NameID = comboBoxFuncNames.SelectedIndex;
                FormulePartList formuleParts = GetFormulePartsByListNoCorrect().Set(listBoxPartList.SelectedIndex, FuncPart.GetThis());
                ListView(formuleParts);
            }
            catch { }
        }

        private void comboBoxFuncNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                
            }
            catch { }
        }

        private void buttonAddNumber_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList list = GetFormulePartsByListNoCorrect().AddNumberWithThis(0);
                ListView(list);
                SetLast();
            }
            catch { }
        }

       void ListView(FormulePartList list)
        {
            listBoxPartList.Items.Clear();
            listBoxPartList.Items.AddRange(list.ToArray());
            try
            {
                if(toolStripAutoSaveList.SelectedIndex == 1)
                {
                    UpdateFormuleByNoCorrect();
                }
            }
            catch { }
        }

        private void buttonAddFunction_Click(object sender, EventArgs e)
        {
            FeachersList addFunc = new FeachersList();
            addFunc.GetFunctionForm += AddFunc_GetFunctionForm;
            addFunc.Show();
        }

        private void AddFunc_GetFunctionForm(Form form, int funcId, int nameId, string name)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddFunctionWithThis(funcId, nameId);
                ListView(formule);
                form.Close();
                SetLast();
            }
            catch { }
        }

        private void buttonOpenConst_Click(object sender, EventArgs e)
        {
            try
            {
                string constN = "(" + FuncPart.Function.AsConst().Number + ")";
                ListView(GetFormulePartsByListNoCorrect().SetFormule(listBoxPartList.SelectedIndex, constN));
            }
            catch { }
        }

        private void buttonAddExp_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddExpWithThis();
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        private void buttonUploadBasketType_Click(object sender, EventArgs e)
        {
            BasketTypeUpdate();
        }

        private void buttonUploadBasketAbs_Click(object sender, EventArgs e)
        {
            BasketAbsUpdate();
        }

        private void buttonUploadBasket_Click(object sender, EventArgs e)
        {
            BasketUpdate();
        }

        private void buttonBasketSet_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect();
                bool abs = checkBoxBasketAbs.Checked;
                int index = listBoxPartList.SelectedIndex;
                if (comboBoxBasketType.SelectedIndex == 0)
                {
                    formule.SetPart(index, FormuleBaskets.CreateOpen(abs));
                }
                else
                {
                    formule.SetPart(index, FormuleBaskets.CreateClose(abs));
                }
                ListView(formule);
                //SetLast();
            }
            catch { }
        }

        private void buttonAddOpenBasket_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddOpenBasketWithThis(false);
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        private void buttonAddCloseBasket_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddCloseBasketWithThis(false);
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        private void buttonAddAbsOpenBasket_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddOpenBasketWithThis(true);
                ListView(formule); 
                SetLast();
            }
            catch { }
        }

        private void buttonAddAbsCloseBasket_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddCloseBasketWithThis(true);
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        void SetLast()
        {
            try
            {
                listBoxPartList.SelectedIndex = listBoxPartList.Items.Count - 1;
            }
            catch { }
        }

        private void buttonReplaceToE_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect();
                //bool abs = checkBoxBasketAbs.Checked;
                int index = listBoxPartList.SelectedIndex;

                formule.SetPart(index, new FormuleExp());
                
                ListView(formule);
                listBoxPartList.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonReplaceExpFunc_Click(object sender, EventArgs e)
        {
            FeachersList replaceExpFunc = new FeachersList();
            replaceExpFunc.GetFunctionForm += ReplaceExpFunc_GetFunctionForm;
            replaceExpFunc.Show();
        }

        private void ReplaceExpFunc_GetFunctionForm(Form form, int funcId, int nameId, string name)
        {
            try
            {
                int index = listBoxPartList.SelectedIndex;
                FormulePartList formule = GetFormulePartsByListNoCorrect().SetPart(index, new FormuleFunction(funcId, nameId));
                ListView(formule);
                form.Close();
                listBoxPartList.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonOpenConstExp_Click(object sender, EventArgs e)
        {
            try
            {
                string constN = "(" + Math.E + ")";
                ListView(GetFormulePartsByListNoCorrect().SetFormule(listBoxPartList.SelectedIndex, constN));
            }
            catch { }
        }

        private void buttonOpenVariable_Click(object sender, EventArgs e)
        {
            try
            {
                string varValue1 = textBoxVariableValue.Value;
                FormulePartList varValue = !IsVarFx(comboBoxStaticVariables.SelectedItem.ToString()) || varValue1.Length < 1 && varValue1.Trim() == "0" ?
                    MyCalculate.AddBasketsInteractive(varValue1, 'x') : MyCalculate.ReplaceToFullFuncsCodeInteractive(varValue1, 'x');
                ListView(GetFormulePartsByListNoCorrect().SetFormule(listBoxPartList.SelectedIndex, varValue));
            }
            catch { }
        }

        private void buttonAddStaticVariable_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddStaticVariableWithThis("A");
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        private void buttonMemoryVariablesUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int index = comboBoxMemoryVariables.SelectedIndex;
                comboBoxMemoryVariables.Items.Clear();
                comboBoxMemoryVariables.Items.AddRange(CalculatorString.History.VariablesArray);

                comboBoxMemoryVariables.SelectedIndex = index;
            }
            catch
            {
                try
                {
                    comboBoxMemoryVariables.SelectedIndex = 0;
                }
                catch { }

            }

            ViewFormuleMemory();
        }

        void ViewFormuleMemory()
        {

            try
            {
                string text = CalculatorString.History[comboBoxMemoryVariables.SelectedIndex].Formule.Trim();
                if (text.Length < 1)
                    throw new Exception();
                textBoxMemoryVariable.Value = text;

            }
            catch
            {
                textBoxMemoryVariable.Value = "0";
            }
        }


        private void memoryB_History()
        {
            try
            {
                CalculatorMemory memory = new CalculatorMemory();
                //memory.TextNumberA = textBoxOutput;
                //memory.TextNumberB = textBoxInput;
                //memory.TextBuffer = GetBuffer;
                memory.MetrOutput1 += MetrOutput1;
                memory.GetHelpText += GetHelp;
                memory.Show();
            }
            catch
            {

            }
        }

        private void buttonMemory_Click(object sender, EventArgs e)
        {
            memoryB_History();
        }

        private void buttonUploadMemoryVariable_Click(object sender, EventArgs e)
        {
            try
            {
                UploadMemoryVariable();
            }
            catch { }
        }

        private void buttonSetmemoryVariable_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBoxPartList.SelectedIndex;
                FormulePartList formule = GetFormulePartsByListNoCorrect().SetPart(index,
                   new FormuleVariableMemory( CalculatorString.History[comboBoxMemoryVariables.SelectedIndex].VariableValueText));
                ListView(formule);
                listBoxPartList.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonOpenMemoryVariable_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBoxPartList.SelectedIndex;
                FormulePartList formule = GetFormulePartsByListNoCorrect().SetFormule(index,
                   CalculatorString.History[comboBoxMemoryVariables.SelectedIndex].FormuleAddBaskets());
                ListView(formule);
                //listBoxPartList.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonAddMemoryVariable_Click(object sender, EventArgs e)
        {
            try
            {
                FormuleVariableMemory memory = new FormuleVariableMemory(CalculatorString.History[0].VariableValueText);
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddWithThis(memory);
                ListView(formule);
                SetLast();
            }
            catch 
            {
                MessageBox.Show("Память пуста... \n" +
                    "Добавьте, хотя бы одну позицию в память калькулятора, прежде чем добавлять переменную в формулу",
                    "Добавление переменной памяти",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBoxMemoryVariables_SelectedIndexChanged(object sender, EventArgs e)
        {
            ViewFormuleMemory();
        }

        private void buttonAddBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList list = MyCalculate.AddBasketsInteractive(GetFormulePartsByList(), 'x');
                ListView(list);
            }
            catch(Exception ex)
            {

            }
        }

        private void buttonDropBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList list = MyCalculate.DropBasketsInteractive(GetFormulePartsByList(), 'x');
                ListView(list);
            }
            catch (Exception ex)
            {

            }
        }

        private void buttonOpenVariables_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList list = MyCalculate.ReplaceByOpenVariables(GetFormulePartsByList(), GetA(), GetB(), GetHelp(), GetBuffer(),
                    GetFewA(), GetFewB(), GetFewHelp(), GetFewBuffer(), 'x');
                ListView(list);
            }
            catch (Exception ex)
            {

            }
        }

        private void buttonOpenConsts_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList list = MyCalculate.ReplaceByOpenConst(GetFormulePartsByList(), 'x');
                ListView(list);
            }
            catch (Exception ex)
            {

            }
        }

        private void buttonOpenConstsAndVariables_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList list = MyCalculate.ReplaceByOpenConst(GetFormulePartsByList(), GetA(), GetB(), GetHelp(), GetBuffer(),
                    GetFewA(), GetFewB(), GetFewHelp(), GetFewBuffer(), 'x');
                ListView(list);
            }
            catch (Exception ex)
            {

            }
        }

        private void buttonCalcSecondMetr_Click(object sender, EventArgs e)
        {
            SecondMetrForm form = new SecondMetrForm(Save.None);
            form.MetrOutput1 += Form_MetrOutput1;
            form.GetMilliseconds += Form_GetMilliseconds;
            form.Show();
        }

        private double Form_GetMilliseconds()
        {
            try
            {
                return MyCalculate.ToDouble(textBoxNumber.Value);
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        private void Form_MetrOutput1(string time, Save save)
        {
            try
            {
                textBoxNumber.Value = double.Parse(time.Replace('.', ',')).ToString();
            }
            catch
            {

            }
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList list = new FormulePartList(MyCalculate.CalculateConvertToPostphics(GetFormulePartsByList()
                    , GetA(), GetB(), GetHelp(), GetBuffer(),
                    GetFewA(), GetFewB(), GetFewHelp(), GetFewBuffer(), 'x'));
                ListView(list);
            }
            catch (Exception ex)
            {

            }
        }

        private void buttonAddFxX_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddStaticVariableWithThis("{~X}");
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        private void buttonAddFxY_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddStaticVariableWithThis("{~Y}");
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        private void buttonAddX_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddStaticVariableWithThis("X");
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        private void buttonAddVarMemoryList_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddStaticVariableWithThis("{~M}");
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        private void buttonAddUgleOperator_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddUgleOperatorWithThis(0);
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        private void buttonUgleOperatorUpload_Click(object sender, EventArgs e)
        {
            UploadUgleOperator();
        }

        private void buttonUgleOperatorSet_Click(object sender, EventArgs e)
        {
            try
            {
                object item = listBoxPartList.SelectedItem;
                FormuleUgleOperator operate = item as FormuleUgleOperator;
                operate.Dole = comboBoxUgleOperator.SelectedIndex;
                FormulePartList formuleParts = GetFormulePartsByListNoCorrect().Set(listBoxPartList.SelectedIndex, operate.GetThis());
                ListView(formuleParts);
            }
            catch { }

            buttonUgleOperatorUpload_Click(sender, e);
        }

        private void buttonAddOperator_Click(object sender, EventArgs e)
        {
            string[] operates = new string[] {"+", "-", "*", "/", "//", "%", "%%", "‰", "**", "^", "\\", "-/-",
            "sin", "cos", "tg", "ctg", "sec", "cosec", "arcsin", "arccos", 
                "arctg", "arcctg", "arcsec", "arccosec","°", "'", "''",
            "log", "ln", "lg", "grad", "rad", "∛", "√", "✓", "E"};
            int length = operates.Length;
            int width = 5;
            int height = length / width + 2;

            Form addOperator = new Form();
            addOperator.Font = Font;
            addOperator.BackColor = BackColor;
            addOperator.ForeColor = ForeColor;
            addOperator.StartPosition = FormStartPosition.CenterScreen;
            TableLayoutPanel panel = new TableLayoutPanel();
            addOperator.Controls.Add(panel);
            panel.ColumnCount = 3;
            panel.RowCount = 5;
            Button exit = new Button();
            exit.Text = "Назад";
            exit.Click += (sender1, e1) =>
            {
                addOperator.Close();
                try
                {
                    addOperator.Dispose();
                }
                catch { }

                try
                {
                    GC.Collect();
                }
                catch
                {

                }
            };
            panel.Controls.Add(exit, 0, 0);
            panel.Dock = DockStyle.Fill;

            Label title = new Label();
            title.Text = "Добавление оператора";
            panel.Controls.Add(title, 1, 0);
            panel.SetColumnSpan(title, panel.ColumnCount-1);

            FlowResize panelOperates = new FlowResize();
            panel.Controls.Add(panelOperates, 0, 1);
            panelOperates.Dock = DockStyle.Fill;
            panel.SetColumnSpan(panelOperates, panel.ColumnCount);
            panel.SetRowSpan(panelOperates, panel.RowCount-1);
            panel.Dock = DockStyle.Fill;

            TableLayoutPanel tableOperates = new TableLayoutPanel();
            panelOperates.Controls.Add(tableOperates);
            panelOperates.WrapContents = false;
            panelOperates.FlowDirection = FlowDirection.TopDown;
            panelOperates.BorderStyle = BorderStyle.Fixed3D;

            for (int i = 0; i < height - 1; i++) 
            {
                tableOperates.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
            }
            tableOperates.RowStyles.Add(new RowStyle(SizeType.Percent, 50));

            for (int i = 0; i < width; i++) 
            {
                tableOperates.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 1.0f/width));
            }

            tableOperates.ColumnCount = width;
            tableOperates.RowCount = height;

            for (int i = 0; i< length; i++)
            {
                Button button = new Button();
                button.Text = operates[i];
                button.Click+= (sender1, e1) =>
                    {
                        string text = (sender1 as Button).Text;


                        try
                        {
                            
                            FormulePartList formuleParts = GetFormulePartsByListNoCorrect().AddWithThis(MyCalculate.ReplaceToFullFuncsCodeInteractive(text)[0]);
                            ListView(formuleParts);
                        }
                        catch { }

                        buttonUgleOperatorUpload_Click(sender1, e1);
                        addOperator.Close();
                    };
                button.Dock = DockStyle.Fill;
                tableOperates.Controls.Add(button);
            }
            tableOperates.Height = height * 50;
            Size size = addOperator.MinimumSize;
            size.Width = 500;
            size.Height = 250;
            addOperator.MinimumSize = size;

            foreach (Control control in panel.Controls)
            {
                control.Dock = DockStyle.Fill;
            }

            addOperator.Show();
        }

        private void textBoxNumber_ValueChanged(Control control, EventArgs e, string value)
        {
            if(checkBoxNumAutoSave.Checked)
            {
                buttonSetNumber_Click(control, e);
            }
        }

        private void buttonListUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBoxPartList.SelectedIndex;
                ListView(GetFormulePartsByListNoCorrect());
                listBoxPartList.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonUpdateFormuleByNoCorrect_Click(object sender, EventArgs e)
        {
            UpdateFormuleByNoCorrect();
        }

        void UpdateFormuleByNoCorrect()
        { 
            try
            {

                try
                {
                    FormulePartList partList = GetFormulePartsByListNoCorrect();
                    UpdateFewFormule?.Invoke(partList);

                }
                catch
                {
                    try
                    {
                        UpdateFewFormule?.Invoke("");
                    }
                    catch { }
                }
            }
            catch { }
        }

        private void textBoxNumber_EnterKeyDown(Control control, EventArgs e, string value)
        {
            try
            {
                if(checkBoxNumberEnter.Checked)
                {
                    buttonSetNumber_Click(control, e);
                }
            }
            catch { }
        }

        private void buttonPastCalcBFromBCalcB_Click(object sender, EventArgs e)
        {
            try
            {
                CalculatePositionCopy copy = Buffer.GetCalculatetionCopy();
                DialogResult result = MessageBox.Show("Вставить результат вычисления" + copy, "Вставка результата выражения", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    textBoxNumber.Value = copy.A;
                }
            }
            catch { }
        }

        private void buttonMoveUp_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBoxPartList.SelectedIndex;
                FormulePartList formule = GetFormulePartsByListNoCorrect();
                formule.MoveUp(index);
                ListView(formule);
                listBoxPartList.SelectedIndex = index - 1;
            }
            catch { }
        }

        private void buttonMoveDown_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBoxPartList.SelectedIndex;
                FormulePartList formule = GetFormulePartsByListNoCorrect();
                formule.MoveDown(index);
                ListView(formule);
                listBoxPartList.SelectedIndex = index + 1;
            }
            catch { }
        }

        private void buttonAddArraySplit_Click(object sender, EventArgs e)
        {
            try
            {
                FormulePartList formule = GetFormulePartsByListNoCorrect().AddArraySplitWithThis();
                ListView(formule);
                SetLast();
            }
            catch { }
        }

        private void buttonUploadStaticVariable_Click(object sender, EventArgs e)
        {
            UploadStaticvariable();
        }

        private void buttonSetStaticVariable_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBoxPartList.SelectedIndex;
                FormulePartList formule = GetFormulePartsByListNoCorrect().SetPart(index,
                    new FormuleStaticVariables(variables.Get(comboBoxStaticVariables.SelectedIndex)));
                ListView(formule);
               listBoxPartList.SelectedIndex = index;
            }
            catch { }
        }

        private void textBoxWithTitle1_Load(object sender, EventArgs e)
        {

        }
    }
}
