﻿namespace TableAIS
{
    partial class FuncGraphicsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FuncGraphicsForm));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridViewFx = new System.Windows.Forms.DataGridView();
            this.ColumnX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxFx = new TableAIS.TextBoxWithTitle();
            this.chartFx = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.ввестиФормулуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetByStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetByMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetByClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.buttonCreateGraphic = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropVariable = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropVariable1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonChangeBaskets = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddBaskets = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropBaskets = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTestChangeBaskets = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenConsts1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenConsts = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenVariables = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenVariablesAnsConsts = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip4 = new System.Windows.Forms.MenuStrip();
            this.очиститьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClearTableFx = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClearGraphicFx = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClearFunc = new System.Windows.Forms.ToolStripMenuItem();
            this.построитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buildGraphic = new System.Windows.Forms.ToolStripMenuItem();
            this.buildTable = new System.Windows.Forms.ToolStripMenuItem();
            this.buildTableTest = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCreateGraphicTest = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFeatcherFx = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.вывестиФормулуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.включитьFxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteFxStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteFxMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteFxClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.неВключатьFxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxIntervalFrom = new TableAIS.TextBoxWithTitle();
            this.textBoxIntervalTo = new TableAIS.TextBoxWithTitle();
            this.textBoxIntervalStep = new TableAIS.TextBoxWithTitle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.flowResize1 = new TableAIS.FlowResize();
            this.labelFx = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxHelp = new TableAIS.TextBoxWithTitle();
            this.textBoxBuffer = new TableAIS.TextBoxWithTitle();
            this.textBoxA = new TableAIS.TextBoxWithTitle();
            this.textBoxB = new TableAIS.TextBoxWithTitle();
            this.timerFunc = new System.Windows.Forms.Timer(this.components);
            this.buttonInteractiveEditFx = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFx)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartFx)).BeginInit();
            this.tableLayoutPanel4.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.menuStrip3.SuspendLayout();
            this.menuStrip4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.flowResize1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(621, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(283, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(933, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(933, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(929, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(504, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 504);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(933, 23);
            this.panel2.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridViewFx);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(312, 235);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Зависимость переменных";
            // 
            // dataGridViewFx
            // 
            this.dataGridViewFx.AllowUserToAddRows = false;
            this.dataGridViewFx.AllowUserToDeleteRows = false;
            this.dataGridViewFx.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewFx.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewFx.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewFx.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFx.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnX,
            this.ColumnY});
            this.dataGridViewFx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewFx.Location = new System.Drawing.Point(3, 30);
            this.dataGridViewFx.Name = "dataGridViewFx";
            this.dataGridViewFx.ReadOnly = true;
            this.dataGridViewFx.RowHeadersVisible = false;
            this.dataGridViewFx.RowHeadersWidth = 51;
            this.dataGridViewFx.RowTemplate.Height = 24;
            this.dataGridViewFx.Size = new System.Drawing.Size(306, 202);
            this.dataGridViewFx.TabIndex = 0;
            // 
            // ColumnX
            // 
            this.ColumnX.HeaderText = "X=";
            this.ColumnX.MinimumWidth = 6;
            this.ColumnX.Name = "ColumnX";
            this.ColumnX.ReadOnly = true;
            this.ColumnX.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ColumnX.Width = 125;
            // 
            // ColumnY
            // 
            this.ColumnY.HeaderText = "Y=";
            this.ColumnY.MinimumWidth = 6;
            this.ColumnY.Name = "ColumnY";
            this.ColumnY.ReadOnly = true;
            this.ColumnY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ColumnY.Width = 125;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.69132F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.30869F));
            this.tableLayoutPanel2.Controls.Add(this.textBoxFx, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.chartFx, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.tabControl1, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 82F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 82F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.27888F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 69.72112F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(933, 415);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // textBoxFx
            // 
            this.textBoxFx.AllowNegative = true;
            this.textBoxFx.ClearingByReadonly = false;
            this.textBoxFx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFx.EnterAllow = true;
            this.textBoxFx.Location = new System.Drawing.Point(4, 4);
            this.textBoxFx.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFx.MultiLine = false;
            this.textBoxFx.Name = "textBoxFx";
            this.textBoxFx.NoReadOnly = true;
            this.textBoxFx.ReadOnly = false;
            this.textBoxFx.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxFx.SelectionStart = 0;
            this.textBoxFx.Size = new System.Drawing.Size(324, 74);
            this.textBoxFx.TabIndex = 0;
            this.textBoxFx.TextWithLineBreaks = "";
            this.textBoxFx.Title = "f(x)=";
            this.textBoxFx.UseSystemPasswordChar = false;
            this.textBoxFx.Value = "";
            this.textBoxFx.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxFx.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxFx.ValueText = "";
            this.textBoxFx.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxFx.ValueWithLineBreaks = "";
            this.textBoxFx.VisibleOK = false;
            // 
            // chartFx
            // 
            this.chartFx.BackSecondaryColor = System.Drawing.Color.LightGray;
            this.chartFx.BorderlineColor = System.Drawing.Color.LightGray;
            chartArea1.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea1.Name = "ChartArea1";
            this.chartFx.ChartAreas.Add(chartArea1);
            this.chartFx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartFx.Location = new System.Drawing.Point(335, 167);
            this.chartFx.Name = "chartFx";
            this.tableLayoutPanel2.SetRowSpan(this.chartFx, 2);
            series1.BorderWidth = 2;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Color = System.Drawing.Color.Black;
            series1.LegendText = "F(x)";
            series1.MarkerBorderColor = System.Drawing.Color.Black;
            series1.MarkerBorderWidth = 2;
            series1.MarkerColor = System.Drawing.Color.Black;
            series1.Name = "SeriesFx";
            this.chartFx.Series.Add(series1);
            this.chartFx.Size = new System.Drawing.Size(595, 245);
            this.chartFx.TabIndex = 1;
            this.chartFx.Text = "f(x)";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.57895F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 68.42105F));
            this.tableLayoutPanel4.Controls.Add(this.menuStrip2, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.menuStrip3, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.menuStrip4, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(335, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(595, 76);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ввестиФормулуToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 38);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(187, 26);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // ввестиФормулуToolStripMenuItem
            // 
            this.ввестиФормулуToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetByStart,
            this.buttonSetByMain,
            this.buttonSetByClipboard});
            this.ввестиФормулуToolStripMenuItem.Name = "ввестиФормулуToolStripMenuItem";
            this.ввестиФормулуToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.ввестиФормулуToolStripMenuItem.Text = "Ввести формулу";
            // 
            // buttonSetByStart
            // 
            this.buttonSetByStart.Name = "buttonSetByStart";
            this.buttonSetByStart.Size = new System.Drawing.Size(268, 26);
            this.buttonSetByStart.Text = "С предыдущего экрана";
            this.buttonSetByStart.Click += new System.EventHandler(this.buttonSetByStart_Click);
            // 
            // buttonSetByMain
            // 
            this.buttonSetByMain.Name = "buttonSetByMain";
            this.buttonSetByMain.Size = new System.Drawing.Size(268, 26);
            this.buttonSetByMain.Text = "С главного экрана";
            this.buttonSetByMain.Click += new System.EventHandler(this.buttonSetByMain_Click);
            // 
            // buttonSetByClipboard
            // 
            this.buttonSetByClipboard.Name = "buttonSetByClipboard";
            this.buttonSetByClipboard.Size = new System.Drawing.Size(268, 26);
            this.buttonSetByClipboard.Text = "Из буфера обмена";
            this.buttonSetByClipboard.Click += new System.EventHandler(this.buttonSetByClipboard_Click);
            // 
            // menuStrip3
            // 
            this.menuStrip3.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCreateGraphic,
            this.buttonDropVariable});
            this.menuStrip3.Location = new System.Drawing.Point(187, 0);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(408, 28);
            this.menuStrip3.TabIndex = 2;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // buttonCreateGraphic
            // 
            this.buttonCreateGraphic.Name = "buttonCreateGraphic";
            this.buttonCreateGraphic.Size = new System.Drawing.Size(161, 24);
            this.buttonCreateGraphic.Text = "Построить график";
            this.buttonCreateGraphic.Click += new System.EventHandler(this.buttonCreateGraphic_Click_1);
            // 
            // buttonDropVariable
            // 
            this.buttonDropVariable.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonDropVariable1,
            this.buttonChangeBaskets,
            this.buttonAddBaskets,
            this.buttonDropBaskets,
            this.buttonTestChangeBaskets,
            this.buttonOpenConsts1,
            this.buttonInteractiveEditFx});
            this.buttonDropVariable.Name = "buttonDropVariable";
            this.buttonDropVariable.Size = new System.Drawing.Size(173, 24);
            this.buttonDropVariable.Text = "Исправить формулу";
            // 
            // buttonDropVariable1
            // 
            this.buttonDropVariable1.Name = "buttonDropVariable1";
            this.buttonDropVariable1.Size = new System.Drawing.Size(354, 26);
            this.buttonDropVariable1.Text = "Раскрыть переменные и константы";
            this.buttonDropVariable1.Click += new System.EventHandler(this.buttonDropVariable_Click);
            // 
            // buttonChangeBaskets
            // 
            this.buttonChangeBaskets.Name = "buttonChangeBaskets";
            this.buttonChangeBaskets.Size = new System.Drawing.Size(354, 26);
            this.buttonChangeBaskets.Text = "Выравнять скобки";
            this.buttonChangeBaskets.Click += new System.EventHandler(this.buttonTestChangeBaskets_Click);
            // 
            // buttonAddBaskets
            // 
            this.buttonAddBaskets.Name = "buttonAddBaskets";
            this.buttonAddBaskets.Size = new System.Drawing.Size(354, 26);
            this.buttonAddBaskets.Text = "Добавить скобки";
            this.buttonAddBaskets.Click += new System.EventHandler(this.buttonAddBaskets_Click);
            // 
            // buttonDropBaskets
            // 
            this.buttonDropBaskets.Name = "buttonDropBaskets";
            this.buttonDropBaskets.Size = new System.Drawing.Size(354, 26);
            this.buttonDropBaskets.Text = "Удалить внешние скобки";
            this.buttonDropBaskets.Click += new System.EventHandler(this.buttonDropBaskets_Click);
            // 
            // buttonTestChangeBaskets
            // 
            this.buttonTestChangeBaskets.Name = "buttonTestChangeBaskets";
            this.buttonTestChangeBaskets.Size = new System.Drawing.Size(354, 26);
            this.buttonTestChangeBaskets.Text = "Выравнять все скобки (тестовая)";
            this.buttonTestChangeBaskets.Visible = false;
            this.buttonTestChangeBaskets.Click += new System.EventHandler(this.buttonTestChangeBaskets_Click);
            // 
            // buttonOpenConsts1
            // 
            this.buttonOpenConsts1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonOpenConsts,
            this.buttonOpenVariables,
            this.buttonOpenVariablesAnsConsts});
            this.buttonOpenConsts1.Name = "buttonOpenConsts1";
            this.buttonOpenConsts1.Size = new System.Drawing.Size(354, 26);
            this.buttonOpenConsts1.Text = "Раскрыть конструкции в формуле";
            // 
            // buttonOpenConsts
            // 
            this.buttonOpenConsts.Name = "buttonOpenConsts";
            this.buttonOpenConsts.Size = new System.Drawing.Size(283, 26);
            this.buttonOpenConsts.Text = "Константы";
            this.buttonOpenConsts.Click += new System.EventHandler(this.buttonOpenConsts_Click);
            // 
            // buttonOpenVariables
            // 
            this.buttonOpenVariables.Name = "buttonOpenVariables";
            this.buttonOpenVariables.Size = new System.Drawing.Size(283, 26);
            this.buttonOpenVariables.Text = "Переменные";
            this.buttonOpenVariables.Click += new System.EventHandler(this.buttonOpenVariables_Click);
            // 
            // buttonOpenVariablesAnsConsts
            // 
            this.buttonOpenVariablesAnsConsts.Name = "buttonOpenVariablesAnsConsts";
            this.buttonOpenVariablesAnsConsts.Size = new System.Drawing.Size(283, 26);
            this.buttonOpenVariablesAnsConsts.Text = "Переменные и константы";
            this.buttonOpenVariablesAnsConsts.Click += new System.EventHandler(this.buttonOpenVariablesAnsConsts_Click);
            // 
            // menuStrip4
            // 
            this.menuStrip4.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.очиститьToolStripMenuItem,
            this.построитьToolStripMenuItem,
            this.buttonAddFeatcherFx});
            this.menuStrip4.Location = new System.Drawing.Point(187, 38);
            this.menuStrip4.Name = "menuStrip4";
            this.menuStrip4.Size = new System.Drawing.Size(408, 26);
            this.menuStrip4.TabIndex = 3;
            this.menuStrip4.Text = "menuStrip4";
            // 
            // очиститьToolStripMenuItem
            // 
            this.очиститьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonClearTableFx,
            this.buttonClearGraphicFx,
            this.buttonClearFunc});
            this.очиститьToolStripMenuItem.Name = "очиститьToolStripMenuItem";
            this.очиститьToolStripMenuItem.Size = new System.Drawing.Size(90, 22);
            this.очиститьToolStripMenuItem.Text = "Очистить";
            // 
            // buttonClearTableFx
            // 
            this.buttonClearTableFx.Name = "buttonClearTableFx";
            this.buttonClearTableFx.Size = new System.Drawing.Size(363, 26);
            this.buttonClearTableFx.Text = "Таблицу (Зависимость переменных)";
            this.buttonClearTableFx.Click += new System.EventHandler(this.buttonClearTableFx_Click);
            // 
            // buttonClearGraphicFx
            // 
            this.buttonClearGraphicFx.Name = "buttonClearGraphicFx";
            this.buttonClearGraphicFx.Size = new System.Drawing.Size(363, 26);
            this.buttonClearGraphicFx.Text = "График функции";
            this.buttonClearGraphicFx.Click += new System.EventHandler(this.buttonClearGraphicFx_Click);
            // 
            // buttonClearFunc
            // 
            this.buttonClearFunc.Name = "buttonClearFunc";
            this.buttonClearFunc.Size = new System.Drawing.Size(363, 26);
            this.buttonClearFunc.Text = "Оба объекта";
            this.buttonClearFunc.Click += new System.EventHandler(this.buttonClearFunc_Click);
            // 
            // построитьToolStripMenuItem
            // 
            this.построитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buildGraphic,
            this.buildTable,
            this.buildTableTest,
            this.buttonCreateGraphicTest});
            this.построитьToolStripMenuItem.Name = "построитьToolStripMenuItem";
            this.построитьToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.построитьToolStripMenuItem.Text = "Построить";
            this.построитьToolStripMenuItem.Click += new System.EventHandler(this.построитьToolStripMenuItem_Click);
            // 
            // buildGraphic
            // 
            this.buildGraphic.Name = "buildGraphic";
            this.buildGraphic.Size = new System.Drawing.Size(363, 26);
            this.buildGraphic.Text = "График функции";
            this.buildGraphic.Click += new System.EventHandler(this.buildGraphic_Click);
            // 
            // buildTable
            // 
            this.buildTable.Name = "buildTable";
            this.buildTable.Size = new System.Drawing.Size(363, 26);
            this.buildTable.Text = "Таблицу (Зависимость переменных)";
            this.buildTable.Click += new System.EventHandler(this.buttonCreateGraphic_Click);
            // 
            // buildTableTest
            // 
            this.buildTableTest.Name = "buildTableTest";
            this.buildTableTest.Size = new System.Drawing.Size(363, 26);
            this.buildTableTest.Text = "Таблицу (тестовая)";
            this.buildTableTest.Click += new System.EventHandler(this.buildTableTest_Click);
            // 
            // buttonCreateGraphicTest
            // 
            this.buttonCreateGraphicTest.Name = "buttonCreateGraphicTest";
            this.buttonCreateGraphicTest.Size = new System.Drawing.Size(363, 26);
            this.buttonCreateGraphicTest.Text = "Оба объекта (тестовая)";
            this.buttonCreateGraphicTest.Click += new System.EventHandler(this.buttonCreateGraphicTest_Click);
            // 
            // buttonAddFeatcherFx
            // 
            this.buttonAddFeatcherFx.Name = "buttonAddFeatcherFx";
            this.buttonAddFeatcherFx.Size = new System.Drawing.Size(203, 22);
            this.buttonAddFeatcherFx.Text = "Вставить функцию в f(x)";
            this.buttonAddFeatcherFx.Click += new System.EventHandler(this.buttonAddFeatcherFx_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вывестиФормулуToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(187, 26);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // вывестиФормулуToolStripMenuItem
            // 
            this.вывестиФормулуToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.включитьFxToolStripMenuItem,
            this.неВключатьFxToolStripMenuItem});
            this.вывестиФормулуToolStripMenuItem.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.вывестиФормулуToolStripMenuItem.Name = "вывестиФормулуToolStripMenuItem";
            this.вывестиФормулуToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.вывестиФормулуToolStripMenuItem.Text = "Вывести формулу";
            // 
            // включитьFxToolStripMenuItem
            // 
            this.включитьFxToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonWriteFxStart,
            this.buttonWriteFxMain,
            this.buttonWriteFxClipboard});
            this.включитьFxToolStripMenuItem.Name = "включитьFxToolStripMenuItem";
            this.включитьFxToolStripMenuItem.Size = new System.Drawing.Size(228, 26);
            this.включитьFxToolStripMenuItem.Text = "Включить F(x)=";
            // 
            // buttonWriteFxStart
            // 
            this.buttonWriteFxStart.Name = "buttonWriteFxStart";
            this.buttonWriteFxStart.Size = new System.Drawing.Size(260, 26);
            this.buttonWriteFxStart.Text = "На предыдущий экран";
            this.buttonWriteFxStart.Click += new System.EventHandler(this.buttonWriteFxStart_Click);
            // 
            // buttonWriteFxMain
            // 
            this.buttonWriteFxMain.Name = "buttonWriteFxMain";
            this.buttonWriteFxMain.Size = new System.Drawing.Size(260, 26);
            this.buttonWriteFxMain.Text = "На главный экран";
            this.buttonWriteFxMain.Click += new System.EventHandler(this.buttonWriteFxMain_Click);
            // 
            // buttonWriteFxClipboard
            // 
            this.buttonWriteFxClipboard.Name = "buttonWriteFxClipboard";
            this.buttonWriteFxClipboard.Size = new System.Drawing.Size(260, 26);
            this.buttonWriteFxClipboard.Text = "В буфер обмена";
            this.buttonWriteFxClipboard.Click += new System.EventHandler(this.buttonWriteFxClipboard_Click);
            // 
            // неВключатьFxToolStripMenuItem
            // 
            this.неВключатьFxToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonWriteStart,
            this.buttonWriteMain,
            this.buttonWriteClipboard});
            this.неВключатьFxToolStripMenuItem.Name = "неВключатьFxToolStripMenuItem";
            this.неВключатьFxToolStripMenuItem.Size = new System.Drawing.Size(228, 26);
            this.неВключатьFxToolStripMenuItem.Text = "Не включать F(x)=";
            // 
            // buttonWriteStart
            // 
            this.buttonWriteStart.Name = "buttonWriteStart";
            this.buttonWriteStart.Size = new System.Drawing.Size(260, 26);
            this.buttonWriteStart.Text = "На предыдущий экран";
            this.buttonWriteStart.Click += new System.EventHandler(this.buttonWriteStart_Click);
            // 
            // buttonWriteMain
            // 
            this.buttonWriteMain.Name = "buttonWriteMain";
            this.buttonWriteMain.Size = new System.Drawing.Size(260, 26);
            this.buttonWriteMain.Text = "На главный экран";
            this.buttonWriteMain.Click += new System.EventHandler(this.buttonWriteMain_Click);
            // 
            // buttonWriteClipboard
            // 
            this.buttonWriteClipboard.Name = "buttonWriteClipboard";
            this.buttonWriteClipboard.Size = new System.Drawing.Size(260, 26);
            this.buttonWriteClipboard.Text = "В буфер обмена";
            this.buttonWriteClipboard.Click += new System.EventHandler(this.buttonWriteClipboard_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.Controls.Add(this.textBoxIntervalFrom, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.textBoxIntervalTo, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.textBoxIntervalStep, 2, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(335, 85);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 76F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(595, 76);
            this.tableLayoutPanel5.TabIndex = 5;
            // 
            // textBoxIntervalFrom
            // 
            this.textBoxIntervalFrom.AllowNegative = true;
            this.textBoxIntervalFrom.ClearingByReadonly = false;
            this.textBoxIntervalFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxIntervalFrom.EnterAllow = true;
            this.textBoxIntervalFrom.Location = new System.Drawing.Point(4, 4);
            this.textBoxIntervalFrom.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxIntervalFrom.MultiLine = false;
            this.textBoxIntervalFrom.Name = "textBoxIntervalFrom";
            this.textBoxIntervalFrom.NoReadOnly = true;
            this.textBoxIntervalFrom.ReadOnly = false;
            this.textBoxIntervalFrom.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxIntervalFrom.SelectionStart = 0;
            this.textBoxIntervalFrom.Size = new System.Drawing.Size(190, 68);
            this.textBoxIntervalFrom.TabIndex = 0;
            this.textBoxIntervalFrom.TextWithLineBreaks = "";
            this.textBoxIntervalFrom.Title = "От";
            this.textBoxIntervalFrom.UseSystemPasswordChar = false;
            this.textBoxIntervalFrom.Value = "";
            this.textBoxIntervalFrom.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxIntervalFrom.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxIntervalFrom.ValueText = "";
            this.textBoxIntervalFrom.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxIntervalFrom.ValueWithLineBreaks = "";
            this.textBoxIntervalFrom.VisibleOK = false;
            this.textBoxIntervalFrom.ValueKeyPress += new System.EventHandler<System.Windows.Forms.KeyPressEventArgs>(this.textBoxInterval_KeyPress);
            this.textBoxIntervalFrom.Load += new System.EventHandler(this.textBoxIntervalFrom_Load);
            this.textBoxIntervalFrom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxInterval_KeyPress);
            // 
            // textBoxIntervalTo
            // 
            this.textBoxIntervalTo.AllowNegative = true;
            this.textBoxIntervalTo.ClearingByReadonly = false;
            this.textBoxIntervalTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxIntervalTo.EnterAllow = true;
            this.textBoxIntervalTo.Location = new System.Drawing.Point(203, 5);
            this.textBoxIntervalTo.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxIntervalTo.MultiLine = false;
            this.textBoxIntervalTo.Name = "textBoxIntervalTo";
            this.textBoxIntervalTo.NoReadOnly = true;
            this.textBoxIntervalTo.ReadOnly = false;
            this.textBoxIntervalTo.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxIntervalTo.SelectionStart = 0;
            this.textBoxIntervalTo.Size = new System.Drawing.Size(188, 66);
            this.textBoxIntervalTo.TabIndex = 0;
            this.textBoxIntervalTo.TextWithLineBreaks = "";
            this.textBoxIntervalTo.Title = "До";
            this.textBoxIntervalTo.UseSystemPasswordChar = false;
            this.textBoxIntervalTo.Value = "";
            this.textBoxIntervalTo.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxIntervalTo.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxIntervalTo.ValueText = "";
            this.textBoxIntervalTo.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxIntervalTo.ValueWithLineBreaks = "";
            this.textBoxIntervalTo.VisibleOK = false;
            this.textBoxIntervalTo.ValueKeyPress += new System.EventHandler<System.Windows.Forms.KeyPressEventArgs>(this.textBoxInterval_KeyPress);
            this.textBoxIntervalTo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxInterval_KeyPress);
            // 
            // textBoxIntervalStep
            // 
            this.textBoxIntervalStep.AllowNegative = true;
            this.textBoxIntervalStep.ClearingByReadonly = false;
            this.textBoxIntervalStep.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxIntervalStep.EnterAllow = true;
            this.textBoxIntervalStep.Location = new System.Drawing.Point(402, 7);
            this.textBoxIntervalStep.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.textBoxIntervalStep.MultiLine = false;
            this.textBoxIntervalStep.Name = "textBoxIntervalStep";
            this.textBoxIntervalStep.NoReadOnly = true;
            this.textBoxIntervalStep.ReadOnly = false;
            this.textBoxIntervalStep.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxIntervalStep.SelectionStart = 0;
            this.textBoxIntervalStep.Size = new System.Drawing.Size(187, 62);
            this.textBoxIntervalStep.TabIndex = 0;
            this.textBoxIntervalStep.TextWithLineBreaks = "";
            this.textBoxIntervalStep.Title = "С шагом";
            this.textBoxIntervalStep.UseSystemPasswordChar = false;
            this.textBoxIntervalStep.Value = "";
            this.textBoxIntervalStep.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxIntervalStep.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxIntervalStep.ValueText = "";
            this.textBoxIntervalStep.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxIntervalStep.ValueWithLineBreaks = "";
            this.textBoxIntervalStep.VisibleOK = false;
            this.textBoxIntervalStep.ValueKeyPress += new System.EventHandler<System.Windows.Forms.KeyPressEventArgs>(this.textBoxInterval_KeyPress);
            this.textBoxIntervalStep.Load += new System.EventHandler(this.textBoxIntervalStep_Load);
            this.textBoxIntervalStep.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxInterval_KeyPress);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.HotTrack = true;
            this.tabControl1.Location = new System.Drawing.Point(3, 85);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tableLayoutPanel2.SetRowSpan(this.tabControl1, 3);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(326, 327);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.flowResize1);
            this.tabPage1.Location = new System.Drawing.Point(4, 82);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(318, 241);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Формула";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // flowResize1
            // 
            this.flowResize1.AutoScroll = true;
            this.flowResize1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize1.Controls.Add(this.labelFx);
            this.flowResize1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize1.Location = new System.Drawing.Point(3, 3);
            this.flowResize1.Name = "flowResize1";
            this.flowResize1.Size = new System.Drawing.Size(312, 235);
            this.flowResize1.TabIndex = 0;
            this.flowResize1.WithDelta = 35;
            this.flowResize1.WrapContents = false;
            // 
            // labelFx
            // 
            this.labelFx.AutoSize = true;
            this.labelFx.Location = new System.Drawing.Point(3, 0);
            this.labelFx.Name = "labelFx";
            this.labelFx.Size = new System.Drawing.Size(62, 21);
            this.labelFx.TabIndex = 0;
            this.labelFx.Text = "label1";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 82);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(318, 241);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Таблица (Зависимость переменных)";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tableLayoutPanel3);
            this.tabPage3.Location = new System.Drawing.Point(4, 82);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(318, 241);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Значения в калькуляторе";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.textBoxHelp, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.textBoxBuffer, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.textBoxA, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.textBoxB, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(312, 235);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // textBoxHelp
            // 
            this.textBoxHelp.AllowNegative = true;
            this.textBoxHelp.ClearingByReadonly = false;
            this.textBoxHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxHelp.EnterAllow = true;
            this.textBoxHelp.Location = new System.Drawing.Point(161, 122);
            this.textBoxHelp.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxHelp.MultiLine = false;
            this.textBoxHelp.Name = "textBoxHelp";
            this.textBoxHelp.NoReadOnly = false;
            this.textBoxHelp.ReadOnly = true;
            this.textBoxHelp.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxHelp.SelectionStart = 0;
            this.textBoxHelp.Size = new System.Drawing.Size(146, 108);
            this.textBoxHelp.TabIndex = 3;
            this.textBoxHelp.TextWithLineBreaks = "";
            this.textBoxHelp.Title = "help=";
            this.textBoxHelp.UseSystemPasswordChar = false;
            this.textBoxHelp.Value = "";
            this.textBoxHelp.ValueBackColor = System.Drawing.Color.White;
            this.textBoxHelp.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxHelp.ValueText = "";
            this.textBoxHelp.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxHelp.ValueWithLineBreaks = "";
            this.textBoxHelp.VisibleOK = false;
            // 
            // textBoxBuffer
            // 
            this.textBoxBuffer.AllowNegative = true;
            this.textBoxBuffer.ClearingByReadonly = false;
            this.textBoxBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxBuffer.EnterAllow = true;
            this.textBoxBuffer.Location = new System.Drawing.Point(5, 122);
            this.textBoxBuffer.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxBuffer.MultiLine = false;
            this.textBoxBuffer.Name = "textBoxBuffer";
            this.textBoxBuffer.NoReadOnly = false;
            this.textBoxBuffer.ReadOnly = true;
            this.textBoxBuffer.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxBuffer.SelectionStart = 0;
            this.textBoxBuffer.Size = new System.Drawing.Size(146, 108);
            this.textBoxBuffer.TabIndex = 2;
            this.textBoxBuffer.TextWithLineBreaks = "";
            this.textBoxBuffer.Title = "bufer=";
            this.textBoxBuffer.UseSystemPasswordChar = false;
            this.textBoxBuffer.Value = "";
            this.textBoxBuffer.ValueBackColor = System.Drawing.Color.White;
            this.textBoxBuffer.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxBuffer.ValueText = "";
            this.textBoxBuffer.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxBuffer.ValueWithLineBreaks = "";
            this.textBoxBuffer.VisibleOK = false;
            // 
            // textBoxA
            // 
            this.textBoxA.AllowNegative = true;
            this.textBoxA.ClearingByReadonly = false;
            this.textBoxA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxA.EnterAllow = true;
            this.textBoxA.Location = new System.Drawing.Point(161, 5);
            this.textBoxA.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxA.MultiLine = false;
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.NoReadOnly = false;
            this.textBoxA.ReadOnly = true;
            this.textBoxA.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxA.SelectionStart = 0;
            this.textBoxA.Size = new System.Drawing.Size(146, 107);
            this.textBoxA.TabIndex = 1;
            this.textBoxA.TextWithLineBreaks = "";
            this.textBoxA.Title = "A=";
            this.textBoxA.UseSystemPasswordChar = false;
            this.textBoxA.Value = "";
            this.textBoxA.ValueBackColor = System.Drawing.Color.White;
            this.textBoxA.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxA.ValueText = "";
            this.textBoxA.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxA.ValueWithLineBreaks = "";
            this.textBoxA.VisibleOK = false;
            // 
            // textBoxB
            // 
            this.textBoxB.AllowNegative = true;
            this.textBoxB.ClearingByReadonly = false;
            this.textBoxB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxB.EnterAllow = true;
            this.textBoxB.Location = new System.Drawing.Point(4, 4);
            this.textBoxB.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxB.MultiLine = false;
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.NoReadOnly = false;
            this.textBoxB.ReadOnly = true;
            this.textBoxB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxB.SelectionStart = 0;
            this.textBoxB.Size = new System.Drawing.Size(148, 109);
            this.textBoxB.TabIndex = 0;
            this.textBoxB.TextWithLineBreaks = "";
            this.textBoxB.Title = "B=";
            this.textBoxB.UseSystemPasswordChar = false;
            this.textBoxB.Value = "";
            this.textBoxB.ValueBackColor = System.Drawing.Color.White;
            this.textBoxB.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxB.ValueText = "";
            this.textBoxB.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxB.ValueWithLineBreaks = "";
            this.textBoxB.VisibleOK = false;
            // 
            // timerFunc
            // 
            this.timerFunc.Enabled = true;
            this.timerFunc.Tick += new System.EventHandler(this.timerFunc_Tick);
            // 
            // buttonInteractiveEditFx
            // 
            this.buttonInteractiveEditFx.Name = "buttonInteractiveEditFx";
            this.buttonInteractiveEditFx.Size = new System.Drawing.Size(354, 26);
            this.buttonInteractiveEditFx.Text = "Интерактивное редактирование";
            this.buttonInteractiveEditFx.Click += new System.EventHandler(this.buttonInteractiveEditFx_Click);
            // 
            // FuncGraphicsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(933, 553);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "FuncGraphicsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "График функции";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFx)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartFx)).EndInit();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.menuStrip4.ResumeLayout(false);
            this.menuStrip4.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.flowResize1.ResumeLayout(false);
            this.flowResize1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private TextBoxWithTitle textBoxFx;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartFx;
        private System.Windows.Forms.Timer timerFunc;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private TextBoxWithTitle textBoxB;
        private TextBoxWithTitle textBoxHelp;
        private TextBoxWithTitle textBoxBuffer;
        private TextBoxWithTitle textBoxA;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridViewFx;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnX;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnY;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem вывестиФормулуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem включитьFxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem неВключатьFxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteFxStart;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteFxMain;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteFxClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteStart;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteMain;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteClipboard;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem ввестиФормулуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSetByStart;
        private System.Windows.Forms.ToolStripMenuItem buttonSetByMain;
        private System.Windows.Forms.ToolStripMenuItem buttonSetByClipboard;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem buttonCreateGraphic;
        private System.Windows.Forms.ToolStripMenuItem buttonDropVariable;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private TextBoxWithTitle textBoxIntervalFrom;
        private TextBoxWithTitle textBoxIntervalTo;
        private TextBoxWithTitle textBoxIntervalStep;
        private System.Windows.Forms.MenuStrip menuStrip4;
        private System.Windows.Forms.ToolStripMenuItem очиститьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonClearTableFx;
        private System.Windows.Forms.ToolStripMenuItem buttonClearGraphicFx;
        private System.Windows.Forms.ToolStripMenuItem построитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buildGraphic;
        private System.Windows.Forms.ToolStripMenuItem buttonClearFunc;
        private System.Windows.Forms.ToolStripMenuItem buttonDropVariable1;
        private System.Windows.Forms.ToolStripMenuItem buttonChangeBaskets;
        private System.Windows.Forms.ToolStripMenuItem buttonAddBaskets;
        private System.Windows.Forms.ToolStripMenuItem buttonDropBaskets;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private FlowResize flowResize1;
        private System.Windows.Forms.Label labelFx;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ToolStripMenuItem buildTable;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFeatcherFx;
        private System.Windows.Forms.ToolStripMenuItem buttonTestChangeBaskets;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenConsts1;
        private System.Windows.Forms.ToolStripMenuItem buildTableTest;
        private System.Windows.Forms.ToolStripMenuItem buttonCreateGraphicTest;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenConsts;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenVariables;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenVariablesAnsConsts;
        private System.Windows.Forms.ToolStripMenuItem buttonInteractiveEditFx;
    }
}