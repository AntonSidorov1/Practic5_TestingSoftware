﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Windows.Storage.Streams;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;
using System.Windows.Forms.DataVisualization.Charting;
using Windows.Graphics.DirectX;

namespace TableAIS
{
    

   

    public partial class FuncGraphicsForm : Form
    {


        public event Func<string> SetFromMain;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public event Func<string> SetNumberFromMain;

        public string SetNumberFromMainInvoke()
        {
            return SetNumberFromMain?.Invoke()??"";
        }


        public FuncGraphicsForm()
        {
            runFx = false;
            InitializeComponent();
            if (fx == null || fx is null || fx == "")
                fx = "";
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public FuncGraphicsForm(Save save):this()
        {
            Save = save;
        }

        public FuncGraphicsForm(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

            try
            {
                textBoxFx.Value = Fx1;
            }
            catch { }
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        public event Func<string> GetB, GetA, GetBuffer, GetHelp;

        public string GetBInvoke()
        {
            string b = "";
            try
            {
                b = GetB?.Invoke()??"";
            }
            catch
            {
               
            }
            if(b.Length < 1)
            {
                b = "0";
            }
            return b;
        }

        private void timerFunc_Tick(object sender, EventArgs e)
        {
            if(runFx)
            {
                runFx = false;
                textBoxFx.Value = fx;

            }

            textBoxB.Value = GetBInvoke();
            textBoxA.Value = GetAInvoke();
            textBoxBuffer.Value = GetBufferInvoke();
            textBoxHelp.Value = GetHelpInvoke();

            labelFx.Text = "F(x) = " + textBoxFx.Value;
            try
            {
                fx = MyCalculate.FuncViewChange(textBoxFx.Value, textBoxA.Value,textBoxBuffer.Value, textBoxHelp.Value, textBoxB.Value);
            }
            catch
            {
                fx = "";
            }

            try
            {
                
            }
            catch
            {

            }
        }

        public static string Fx2;

        public static void FxForFuncs(string a, string b, string buffer, string help)
        {
            try
            {
                string fx = Fx1;
                if (fx.Length < 1)
                    throw new Exception();
                Fx2 = MyCalculate.ReplaceByOpenConst(fx, a, b, buffer, help, 'x');
            }
            catch
            {
                Fx2 = "0";
            }
        }

        public new void Close()
        {
            timerFunc.Stop();
            timerTime.Stop();
            base.Close();
        }

        static string fx;

        public static string Fx1
        {
            get
            {
                if (fx == null)
                    fx = "";
                string func = MyCalculate.ChangeBaskets(fx).Trim();
                return func.Length > 0 ? func : "0";
            }
            set
            {
                string function = value;
                if (fx != function)
                {
                    fx = MyCalculate.ChangeBaskets(function).Trim();
                    runFx = true;
                }
            }
        }

        static bool runFx;

        public string GetAInvoke()
        {
            string a = "";
            try
            {
                a = GetA?.Invoke() ?? "";
            }
            catch
            {
            }
            string b = a;
            if (b.Length < 1)
            {
                b = "0";
            }
            return b;
        }

        private void buttonWriteStart_Click(object sender, EventArgs e)
        {
            try
            {
                MetrOutput1?.Invoke(Fx, Save.None);
            }
            catch { }
        }

        private void buttonWriteMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(Fx);
            }
            catch { }
        }

        private void buttonWriteClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(Fx);
            }
            catch { }
        }

        public string Fx
        {
            get => MyCalculate.ChangeBaskets(textBoxFx.Value);
            set => textBoxFx.Value = MyCalculate.ChangeBaskets(value);
        }

        public string FxText
        {
            get => "f(x)=" + Fx;
        }

        private void buttonWriteFxStart_Click(object sender, EventArgs e)
        {
            try
            {
                MetrOutput1?.Invoke(FxText, Save.None);
            }
            catch { }
        }

        private void buttonWriteFxMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(FxText);
            }
            catch { }
        }

        private void buttonWriteFxClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(FxText);
            }
            catch { }
        }

        private void buttonSetByStart_Click(object sender, EventArgs e)
        {
            try
            {
                Fx = SetNumberFromMainInvoke();
            }
            catch { }
        }

        private void buttonSetByMain_Click(object sender, EventArgs e)
        {
            try
            {
                Fx = ValueHelper.GetText();
            }
            catch { }
        }

        private void buttonSetByClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Fx = Clipboard.GetText();
            }
            catch { }
        }

        private void buttonDropVariable_Click(object sender, EventArgs e)
        {

            buttonOpenVariablesAnsConsts_Click(sender, e);
            return;
            try
            {
                Fx = GetNormalFormule();
            }
            catch { }
        }

        private void textBoxInterval_KeyPress(object sender, KeyPressEventArgs e)
        {
            return;
            char c = e.KeyChar;

            string text = (sender as TextBoxWithTitle).Value;
            int index = (sender as TextBoxWithTitle).SelectionStart;
            if(c == '.')
            {
                e.KeyChar = ',';
            }
            c = e.KeyChar;
            if(c == ',')
            {
                if(text.Contains(","))
                {
                    e.Handled
                         = true;
                    return;
                }
                if(index == 0)
                {
                    e.Handled = true;
                    text = "0," + text;
                    return;
                }
                return;
            }
            if(c == '-')
            {
                if(index> 0 || text.Contains('-'))
                {
                    e.Handled = true;
                    return;
                }
                return;
            }
            if(c == 8)
            {
                return;
            }
            if(c == 27)
            {
                e.Handled = true;
                (sender as TextBoxWithTitle).Clear();
                return;
            }
            if(char.IsDigit(c))
            {
                return;
            }
            e.Handled = true;
            

        }

        private void textBoxIntervalFrom_Load(object sender, EventArgs e)
        {
            
        }


        public Series CreateSeriea()
        {
            Series series = new Series();
            chartFx.Series.Add(series);

            series.ChartType = SeriesChartType.Line;
            series.ChartArea = chartFx.ChartAreas[0].Name;
            //series.Legend = chartFx.Legends[0].Name;
            //series.LegendText = "f(x)";
            series.IsValueShownAsLabel = false;
            series.Color = Color.Black;
            series.MarkerColor = Color.Black;
            series.MarkerBorderColor = Color.Black;
            series.MarkerBorderWidth =3;
            series.BorderWidth = 3;

            return series;
        }

        double Calculate(string formule)
        {
            try
            {
                return double.Parse(formule.Replace('.', ','));
            }
            catch
            {
                try
                {
                    return double.Parse(formule.Replace(',', '.'));
                }
                catch
                {
                    return MyCalculate.CalculateWithB(formule, textBoxA.Value, textBoxBuffer.Value, textBoxHelp.Value, textBoxB.Value);
                }
            }
        }


        private void buttonCreateGraphic_Click(object sender, EventArgs e)
        {
            buildTableTest_Click(sender, e);
            return;
            /*
            try
            {
                ListX.Clear();
                ListY.Clear();

                chartFx.Series.Clear();
                bool seria = false;
                dataGridViewFx.Rows.Clear();
                double from = Calculate(textBoxIntervalFrom.Value);
                double to = Calculate(textBoxIntervalTo.Value);
                double step = Calculate(textBoxIntervalStep.Value);
                double min = Math.Min(from, to);
                double max = Math.Max(from, to);
                if (step == 0)
                    throw new Exception();
                else if (step > 0)
                {
                    from = min;
                    to = max;
                }
                else
                {
                    from = max;
                    to = min;
                }

                double x = from;
                string fx = MyCalculate.GetFuncions(GetNormalFormule());
                List<string> tokens = MyCalculate.GetRpnWithX(fx);
                //Series series;
                while (step > 0 ? x <= to : x >= to)
                {
                    int rowIndex = dataGridViewFx.Rows.Add();
                    DataGridViewRow row = dataGridViewFx.Rows[rowIndex];
                    row.Cells[0].Value = x;
                    ListX.Add(x);
                    try
                    {
                        //double y = MyCalculate.GetYByX(fx, x);
                        double y = MyCalculate.GetYByX1(tokens, x);
                        row.Cells[1].Value = y;
                        ListY.Add(y);

                    }
                    catch
                    {
                        row.Cells[1].Value = "-";
                    }
                    x += step;

                }
                //buildGraphic_Click(sender, e);
            }
            catch { }
            */
        }



        private void textBoxIntervalStep_Load(object sender, EventArgs e)
        {

        }

        private void buttonClearTableFx_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridViewFx.Rows.Clear();
            }
            catch { }
        }

        private void buttonClearGraphicFx_Click(object sender, EventArgs e)
        {
            try
            {
                chartFx.Series.Clear();
                //chartFx.ChartAreas.Clear();
            }
            catch { }
        }


        public static List<double> ListX, ListY;

        public static double[] ListToArray(List<double> list)
        {
            if (list.Count < 1)
                return new double[] { 0 };
            else
                return list.ToArray();
        }

        public static double[] ListToArray1(List<double> list)
        {
            if (list.Count < 1)
                return new double[0];
            else
                return list.ToArray();
        }

        public static double[] ArrayX => ListToArray(ListX);
        public static double[] ArrayY => ListToArray(ListY);

        public static string MasX
        {
            get
            {
                double[] arr = ArrayX;
                if (arr.Length < 1)
                    return "(0)";
                return ";(" + string.Join(";", arr) + ")";
            }
        }

        public static string MasY
        {
            get
            {
                double[] arr = ArrayY;
                if (arr.Length < 1)
                    return "(0)";
                return ";(" + string.Join(";", arr) + ")";
            }
        }

        public static bool BeforeZero(double[] value)
        {
            int length = value.Length;
            for(int i = 0; i < length; i++)
            {
                double x = value[i];
                if (x > 0)
                    return false;
            }
            return true;
        }

        public static bool AfterZero(double[] value)
        {
            int length = value.Length;
            for (int i = 0; i < length; i++)
            {
                double x = value[i];
                if (x < 0)
                    return false;
            }
            return true;
        }

        public static double Min(double[] value)
        {
            int length = value.Length;
            if (length < 1)
                return 0;
            double min = value[0];
            for(int i = 1; i < length;i++)
            {
                min = Math.Min(min, value[i]);
            }

            return ChgangeValue(min);
        }

        static double ChgangeValue(double result)
        {

            double resultAbs = Math.Abs(result);
            if (result > 0)
            {
                if (resultAbs > max1)
                {
                    result = max;
                }
                if (resultAbs < min)
                {
                    result = 0;
                }
            }
            if (result < 0)
            {
                if (resultAbs > max)
                {
                    result = -max;
                }
                if (resultAbs < min)
                {
                    result = 0;
                }
            }
            return result;
        }

        public static double Max(double[] value)
        {
            int length = value.Length;
            if (length < 1)
                return 0;
            double max = value[0];
            for (int i = 1; i < length; i++)
            {
                max = Math.Max(max, value[i]);
            }
            return ChgangeValue(max);
        }

        static double OsMin(double[] value)
        {
            double result = Min(value) - 10.0;
            return ChgangeValue(result);
        }

        static double OsMax(double[] value)
        {
            double result = Max(value)+10.0;
            return ChgangeValue(result);
        }

        static double OsMinX() => OsMin(ArrayX);
        static double OsMaxX() => OsMax(ArrayX);

        static double OsMinY() => OsMax(ArrayX);
        static double OsMaxY() => OsMax(ArrayX);


        public static double GetOS(double[] value)
        {
            double delta = 10.0;
            double result = 0;
            if(BeforeZero(value))
            {
                result = Math.Min(Max(value) + delta, 0);
            }
            else if(AfterZero(value))
            {
                result = Math.Max(Min(value) - delta, 0);
            }

            double resultAbs = Math.Abs(result);
            if(result > 0)
            {
                if(resultAbs > max)
                {
                    result = max;
                }
                if(resultAbs < min)
                {
                    result = 0;
                }
            }
            if (result < 0)
            {
                if (resultAbs > max)
                {
                    result = -max;
                }
                if (resultAbs < min)
                {
                    result = 0;
                }
            }


            return result;
        }

        public static double GetOsX()
        {
            return Math.Min(GetOS(ArrayY), 0);
        }

        public static double GetOsY()
        {
            return GetOS(ArrayX);
        }

        static double div => 2.0;
        static double max1 => max;
        static double min1 => min;
        static double max => decimal.ToDouble(Math.Abs(new decimal(0, 0, 100000000, false, 0))) * div;
        static double min => decimal.ToDouble(Math.Abs(new decimal(1, 0, 0, false, 28))) / div;

        private void buttonClearFunc_Click(object sender, EventArgs e)
        {
            buttonClearTableFx_Click(sender, e);
            buttonClearGraphicFx_Click(sender, e);
        }

        private void buttonChangeBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxFx.Value = MyCalculate.ChangeBaskets(textBoxFx.Value);
            }
            catch { }
        }

        private void buttonAddBaskets_Click(object sender, EventArgs e)
        {
            try
            {

                textBoxFx.Value = MyCalculate.AddBasketsInteractive(textBoxFx.Value, 'x');
                //textBoxFx.Value = "("+MyCalculate.ChangeBaskets(textBoxFx.Value)+")";
            }
            catch { }
        }

        private void buttonDropBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxFx.Value = MyCalculate.DropBasketsInteractive(textBoxFx.Value, 'x');
                //textBoxFx.Value = MyCalculate.DropBaskets(textBoxFx.Value);
            }
            catch { }
        }

        private void построитьToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void buttonCreateGraphic_Click_1(object sender, EventArgs e)
        {
            try
            {
                buttonCreateGraphic_Click(sender, e);
                buildGraphic_Click(sender, e);
            }
            catch { }
        }

        private void buttonAddFeatcherFx_Click(object sender, EventArgs e)
        {
            FeachersList form = new FeachersList();
            form.InputFunc += Form_InputFunc; ;
            form.MetrOutput1 += MetrOutput1;

            form.Show();
        }

        private void Form_InputFunc(string obj)
        {
            try
            {
                textBoxFx.Value += obj;
            }
            catch { }
        }

        private void buttonTestChangeBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxFx.Value = MyCalculate.ReplaceToFullFuncsCodeInteractive(textBoxFx.Value, 'X');
            }
            catch { }
        }

        private void buttonOpenConsts_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxFx.Value = MyCalculate.ReplaceByOpenConst(textBoxFx.Value, 'X');
            }
            catch { }
        }

        private void buildTableTest_Click(object sender, EventArgs e)
        {
            ListX.Clear();
            ListY.Clear();

           // chartFx.Series.Clear();
            bool seria = false;
            dataGridViewFx.Rows.Clear();
            double from = Calculate(textBoxIntervalFrom.Value);
            double to = Calculate(textBoxIntervalTo.Value);
            double step = Calculate(textBoxIntervalStep.Value);
            double min = Math.Min(from, to);
            double max = Math.Max(from, to);
            if (step == 0)
                throw new Exception();
            else if (step > 0)
            {
                from = min;
                to = max;
            }
            else
            {
                from = max;
                to = min;
            }

            double x = from;

            string formule = textBoxFx.Value;
            FormulePartList formules = MyCalculate.ConvertToPostphicsToFx(formule, textBoxA.Value, textBoxBuffer.Value, textBoxHelp.Value, textBoxB.Value);
            if (MyCalculate.ContainsNoAllowFx(formules))
                return;

            while (step > 0 ? x <= to : x >= to)
            {
                int rowID = dataGridViewFx.Rows.Add();
                DataGridViewRow row = dataGridViewFx.Rows[rowID];
                row.Cells[0].Value = x;
                ListX.Add(x);
                try
                {
                    double y = MyCalculate.CalcByFx(formules, x);
                    row.Cells[1].Value = y;
                    ListY.Add(y);
                }
                catch
                {
                    row.Cells[1].Value = "-";
                }
                x += step;
            }
        }

        private void buttonCreateGraphicTest_Click(object sender, EventArgs e)
        {
            try
            {
                buildTableTest_Click(sender, e);
                buildGraphic_Click(sender, e);
            }
            catch { }
        }

        private void buttonOpenVariables_Click(object sender, EventArgs e)
        {

            try
            {
                textBoxFx.Value = MyCalculate.ReplaceByOpenVariables(textBoxFx.Value, textBoxA.Value, textBoxB.Value, textBoxHelp.Value, textBoxBuffer.Value, 'X');
            }
            catch { }
        }

        private void buttonOpenVariablesAnsConsts_Click(object sender, EventArgs e)
        {

            try
            {
                textBoxFx.Value = MyCalculate.ReplaceByOpenConst(textBoxFx.Value, textBoxA.Value, textBoxB.Value, textBoxHelp.Value, textBoxBuffer.Value, 'X');
            }
            catch { }
        }

        private void buttonInteractiveEditFx_Click(object sender, EventArgs e)
        {
            FormulePartsForm formuleParts = new FormulePartsForm();
            formuleParts.ReloadFormuleParts += FormuleParts_ReloadFormuleParts;
            formuleParts.GetFormule += FormuleParts_GetFormule;
            formuleParts.UpdateFewFormule += FormuleParts_UpdateFewFormule;

            formuleParts.GetA += FormuleParts_GetA;
            formuleParts.GetFewA += FormuleParts_GetA;

            formuleParts.GetB += FormuleParts_GetB;
            formuleParts.GetFewB += FormuleParts_GetB;

            formuleParts.GetBuffer += FormuleParts_GetBuffer;
            formuleParts.GetFewBuffer += FormuleParts_GetBuffer;

            formuleParts.GetHelp += FormuleParts_GetHelp;
            formuleParts.GetFewHelp += FormuleParts_GetHelp;

            formuleParts.Show();
        }

        private FormulePartList FormuleParts_ReloadFormuleParts()
        {
            try
            {
                return MyCalculate.ReplaceToFullFuncsCodeInteractive(textBoxFx.Value, 'x');
            }
            catch
            {
                return new FormulePartList();
            }

        }


        private string FormuleParts_GetHelp()
        {
            return textBoxHelp.Value;
        }

        private string FormuleParts_GetBuffer()
        {
            return textBoxBuffer.Value;
        }

        private string FormuleParts_GetB()
        {
            return textBoxB.Value;
        }

        private string FormuleParts_GetA()
        {
            return textBoxA.Value;
        }

        private void FormuleParts_UpdateFewFormule(string obj)
        {
            try
            {
                textBoxFx.Value = obj;
            }
            catch { }
        }

        private string FormuleParts_GetFormule()
        {
            try
            {
                return textBoxFx.Value;
            }
            catch
            {
                return "";
            }
        }


        private void buildGraphic_Click(object sender, EventArgs e)
        {
            try
            {
                chartFx.Series.Clear();
                //double from = double.Parse(textBoxIntervalFrom.Value);
                //double to = double.Parse(textBoxIntervalTo.Value);
                ChartArea chartArea = chartFx.ChartAreas[0];
                Axis osX = chartArea.AxisX;
                osX.Interval = 0;
                osX.Title = "X";
                
                //osX.Minimum = OsMinX();
                //osX.Maximum = OsMaxX();

                //osX.TextOrientation = TextOrientation.Horizontal;
                osX.ArrowStyle = AxisArrowStyle.SharpTriangle;
                //var scrool = osX.ScrollBar;
                //scrool.LineColor = Color.Black;
                //osX.ScrollBar = scrool;
                osX.MajorGrid.Enabled = false;
                osX.LineWidth = 1;
                //osX.Crossing = GetOsX();
                osX.Crossing = 0;
                //osX.ScaleView.Scroll(ScrollType.LargeIncrement);

                Axis osY = chartArea.AxisY;
                osY.Interval = 0;
                osY.Title = "Y";
                //osY.Minimum = OsMinY();
                //osY.Maximum = OsMaxY();
                //osY.TextOrientation = TextOrientation.Horizontal;
                osY.ArrowStyle = AxisArrowStyle.SharpTriangle;
                //osY.ScrollBar = scrool;
                osY.MajorGrid.Enabled = false;
                osY.LineWidth = 1;
                //osY.Crossing = GetOsY();
                osY.Crossing = 0;
                //osY.ScaleView.Scroll(ScrollType.LargeIncrement);
                //chartFx.AlignDataPointsByAxisLabel();
               


                bool seria = false;

                DataGridViewRowCollection rows = dataGridViewFx.Rows;
                int count = rows.Count;
                Series series = null;
                double x, y, num;
                //double div = 2;
                //double max = decimal.ToDouble(Math.Abs(new decimal(0, 0, 100000000, false, 0)))* div;
                //double min = decimal.ToDouble(Math.Abs(new decimal(1, 0, 0, false, 28)))/ div;
                //double.Epsilon
                for (int i = 0; i < count; i++)
                {
                    DataGridViewRow row = rows[i];
                    try
                    {
                        x = double.Parse(row.Cells[0].Value.ToString());
                        y = double.Parse(row.Cells[1].Value.ToString());
                        num = Math.Abs(y);
                        if (num != 0)
                        {
                            if (num > max || num < min)
                            {
                                throw new Exception();
                            }
                        }
                            decimal num1 = (decimal)num;
                        
                        if(!seria)
                        {
                            series = CreateSeriea();
                            seria = true;
                        }
                        series.Points.Add(new DataPoint(x, y));

                    }
                    catch 
                    {
                        seria = false;
                    }
                }
            }
            catch { }
        }

        public string GetBufferInvoke()
        {
            string buffer = "";
            try
            {
                buffer = GetBuffer?.Invoke() ?? "";
            }
            catch
            {
                
            }
            string b = buffer;
            if (b.Length < 1)
            {
                b = "0";
            }
            return b;
        }

        public string GetHelpInvoke()
        {
            string help = "";
            try
            {
                help = GetHelp?.Invoke() ?? "";
            }
            catch
            {
            }
            string b = help;
            if (b.Length < 1)
            {
                b = "0";
            }
            return b;
        }

        public string GetNormalFormule()
        {
            string formule = textBoxFx.Value;
            try
            {
                return MyCalculate.FuncViewChange(formule, textBoxA.Value, textBoxBuffer.Value, textBoxHelp.Value, textBoxB.Value);
            }
            catch
            {
                return formule;
            }
        }
    }
}
