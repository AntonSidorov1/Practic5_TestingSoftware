﻿namespace TableAIS
{
    partial class HostSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HostSettings));
            this.button1 = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxUdpClient = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.numbericUdpSenderPort = new TableAIS.NumbericUser();
            this.buttonUdpSenderStart = new System.Windows.Forms.Button();
            this.groupBoxTcpClient = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.numbericPortClient = new TableAIS.NumbericUser();
            this.buttonClientStart = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxIpAddress = new System.Windows.Forms.TextBox();
            this.buttonClearBuffer = new System.Windows.Forms.Button();
            this.groupBoxTcpServer = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.numbericPortServer = new TableAIS.NumbericUser();
            this.buttonServerStart = new System.Windows.Forms.Button();
            this.groupBoxUdpServer = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.numbericUdpRecivePort = new TableAIS.NumbericUser();
            this.buttonUdpRecipientStart = new System.Windows.Forms.Button();
            this.timerAllowed = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBoxUdpClient.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBoxTcpClient.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBoxTcpServer.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBoxUdpServer.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(621, 25);
            this.button1.Margin = new System.Windows.Forms.Padding(25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(283, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 427);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(933, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(933, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(929, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(504, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 404);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(933, 23);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.Controls.Add(this.groupBoxUdpClient, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxTcpClient, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.buttonClearBuffer, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxTcpServer, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxUdpServer, 3, 2);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(933, 315);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // groupBoxUdpClient
            // 
            this.groupBoxUdpClient.Controls.Add(this.tableLayoutPanel5);
            this.groupBoxUdpClient.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxUdpClient.Location = new System.Drawing.Point(469, 123);
            this.groupBoxUdpClient.Name = "groupBoxUdpClient";
            this.groupBoxUdpClient.Size = new System.Drawing.Size(227, 189);
            this.groupBoxUdpClient.TabIndex = 4;
            this.groupBoxUdpClient.TabStop = false;
            this.groupBoxUdpClient.Text = "UDP-отправитель";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.numbericUdpSenderPort, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonUdpSenderStart, 0, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(221, 156);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // numbericUdpSenderPort
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.numbericUdpSenderPort, 2);
            this.numbericUdpSenderPort.Default = new decimal(new int[] {
            9010,
            0,
            0,
            0});
            this.numbericUdpSenderPort.DefaultValue = new decimal(new int[] {
            9010,
            0,
            0,
            0});
            this.numbericUdpSenderPort.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericUdpSenderPort.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUdpSenderPort.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUdpSenderPort.Location = new System.Drawing.Point(4, 4);
            this.numbericUdpSenderPort.Macimum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numbericUdpSenderPort.Margin = new System.Windows.Forms.Padding(4);
            this.numbericUdpSenderPort.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numbericUdpSenderPort.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUdpSenderPort.Name = "numbericUdpSenderPort";
            this.numbericUdpSenderPort.NoReadOnly = true;
            this.numbericUdpSenderPort.ReadOnly = false;
            this.numbericUdpSenderPort.Size = new System.Drawing.Size(213, 98);
            this.numbericUdpSenderPort.TabIndex = 0;
            this.numbericUdpSenderPort.Title = "Порт";
            this.numbericUdpSenderPort.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUdpSenderPort.VisibleOK = false;
            this.numbericUdpSenderPort.ValueChanged += new TableAIS.ValueChangedControl(this.numbericUdpSenderPort_ValueChanged);
            this.numbericUdpSenderPort.VisibleChanged += new System.EventHandler(this.numbericUdpSenderPort_VisibleChanged);
            // 
            // buttonUdpSenderStart
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.buttonUdpSenderStart, 2);
            this.buttonUdpSenderStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUdpSenderStart.Location = new System.Drawing.Point(3, 109);
            this.buttonUdpSenderStart.Name = "buttonUdpSenderStart";
            this.buttonUdpSenderStart.Size = new System.Drawing.Size(215, 44);
            this.buttonUdpSenderStart.TabIndex = 1;
            this.buttonUdpSenderStart.Text = "button2";
            this.buttonUdpSenderStart.UseVisualStyleBackColor = true;
            this.buttonUdpSenderStart.Click += new System.EventHandler(this.buttonUdpSenderStart_Click);
            // 
            // groupBoxTcpClient
            // 
            this.groupBoxTcpClient.Controls.Add(this.tableLayoutPanel4);
            this.groupBoxTcpClient.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxTcpClient.Location = new System.Drawing.Point(236, 123);
            this.groupBoxTcpClient.Name = "groupBoxTcpClient";
            this.groupBoxTcpClient.Size = new System.Drawing.Size(227, 189);
            this.groupBoxTcpClient.TabIndex = 3;
            this.groupBoxTcpClient.TabStop = false;
            this.groupBoxTcpClient.Text = "TCP-Клиент";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.numbericPortClient, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.buttonClientStart, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(221, 156);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // numbericPortClient
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.numbericPortClient, 2);
            this.numbericPortClient.Default = new decimal(new int[] {
            9000,
            0,
            0,
            0});
            this.numbericPortClient.DefaultValue = new decimal(new int[] {
            9000,
            0,
            0,
            0});
            this.numbericPortClient.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericPortClient.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericPortClient.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericPortClient.Location = new System.Drawing.Point(4, 4);
            this.numbericPortClient.Macimum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numbericPortClient.Margin = new System.Windows.Forms.Padding(4);
            this.numbericPortClient.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numbericPortClient.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericPortClient.Name = "numbericPortClient";
            this.numbericPortClient.NoReadOnly = true;
            this.numbericPortClient.ReadOnly = false;
            this.numbericPortClient.Size = new System.Drawing.Size(213, 98);
            this.numbericPortClient.TabIndex = 0;
            this.numbericPortClient.Title = "Порт";
            this.numbericPortClient.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericPortClient.VisibleOK = false;
            this.numbericPortClient.ValueChanged += new TableAIS.ValueChangedControl(this.numbericPortClient_ValueChanged);
            // 
            // buttonClientStart
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.buttonClientStart, 2);
            this.buttonClientStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClientStart.Location = new System.Drawing.Point(3, 109);
            this.buttonClientStart.Name = "buttonClientStart";
            this.buttonClientStart.Size = new System.Drawing.Size(215, 44);
            this.buttonClientStart.TabIndex = 1;
            this.buttonClientStart.Text = "button2";
            this.buttonClientStart.UseVisualStyleBackColor = true;
            this.buttonClientStart.Click += new System.EventHandler(this.buttonClientStart_Click);
            // 
            // groupBox1
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.groupBox1, 4);
            this.groupBox1.Controls.Add(this.textBoxIpAddress);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(927, 74);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ваш IP-адрес";
            // 
            // textBoxIpAddress
            // 
            this.textBoxIpAddress.BackColor = System.Drawing.Color.White;
            this.textBoxIpAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxIpAddress.Location = new System.Drawing.Point(3, 30);
            this.textBoxIpAddress.Name = "textBoxIpAddress";
            this.textBoxIpAddress.ReadOnly = true;
            this.textBoxIpAddress.Size = new System.Drawing.Size(921, 34);
            this.textBoxIpAddress.TabIndex = 0;
            // 
            // buttonClearBuffer
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.buttonClearBuffer, 4);
            this.buttonClearBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearBuffer.Location = new System.Drawing.Point(3, 3);
            this.buttonClearBuffer.Name = "buttonClearBuffer";
            this.buttonClearBuffer.Size = new System.Drawing.Size(927, 34);
            this.buttonClearBuffer.TabIndex = 1;
            this.buttonClearBuffer.Text = "Очистить буфер";
            this.buttonClearBuffer.UseVisualStyleBackColor = true;
            this.buttonClearBuffer.Click += new System.EventHandler(this.buttonClearBuffer_Click);
            // 
            // groupBoxTcpServer
            // 
            this.groupBoxTcpServer.Controls.Add(this.tableLayoutPanel3);
            this.groupBoxTcpServer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxTcpServer.Location = new System.Drawing.Point(3, 123);
            this.groupBoxTcpServer.Name = "groupBoxTcpServer";
            this.groupBoxTcpServer.Size = new System.Drawing.Size(227, 189);
            this.groupBoxTcpServer.TabIndex = 2;
            this.groupBoxTcpServer.TabStop = false;
            this.groupBoxTcpServer.Text = "TCP-Сервер";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.numbericPortServer, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonServerStart, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(221, 156);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // numbericPortServer
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.numbericPortServer, 2);
            this.numbericPortServer.Default = new decimal(new int[] {
            9000,
            0,
            0,
            0});
            this.numbericPortServer.DefaultValue = new decimal(new int[] {
            9000,
            0,
            0,
            0});
            this.numbericPortServer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericPortServer.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericPortServer.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericPortServer.Location = new System.Drawing.Point(4, 4);
            this.numbericPortServer.Macimum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numbericPortServer.Margin = new System.Windows.Forms.Padding(4);
            this.numbericPortServer.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numbericPortServer.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericPortServer.Name = "numbericPortServer";
            this.numbericPortServer.NoReadOnly = true;
            this.numbericPortServer.ReadOnly = false;
            this.numbericPortServer.Size = new System.Drawing.Size(213, 98);
            this.numbericPortServer.TabIndex = 0;
            this.numbericPortServer.Title = "Порт";
            this.numbericPortServer.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericPortServer.VisibleOK = false;
            this.numbericPortServer.ValueChanged += new TableAIS.ValueChangedControl(this.numbericPortServer_ValueChanged);
            // 
            // buttonServerStart
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.buttonServerStart, 2);
            this.buttonServerStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonServerStart.Location = new System.Drawing.Point(3, 109);
            this.buttonServerStart.Name = "buttonServerStart";
            this.buttonServerStart.Size = new System.Drawing.Size(215, 44);
            this.buttonServerStart.TabIndex = 1;
            this.buttonServerStart.Text = "button2";
            this.buttonServerStart.UseVisualStyleBackColor = true;
            this.buttonServerStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // groupBoxUdpServer
            // 
            this.groupBoxUdpServer.Controls.Add(this.tableLayoutPanel6);
            this.groupBoxUdpServer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxUdpServer.Location = new System.Drawing.Point(702, 123);
            this.groupBoxUdpServer.Name = "groupBoxUdpServer";
            this.groupBoxUdpServer.Size = new System.Drawing.Size(228, 189);
            this.groupBoxUdpServer.TabIndex = 4;
            this.groupBoxUdpServer.TabStop = false;
            this.groupBoxUdpServer.Text = "UDP-получатель";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.numbericUdpRecivePort, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonUdpRecipientStart, 0, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(222, 156);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // numbericUdpRecivePort
            // 
            this.tableLayoutPanel6.SetColumnSpan(this.numbericUdpRecivePort, 2);
            this.numbericUdpRecivePort.Default = new decimal(new int[] {
            9020,
            0,
            0,
            0});
            this.numbericUdpRecivePort.DefaultValue = new decimal(new int[] {
            9020,
            0,
            0,
            0});
            this.numbericUdpRecivePort.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericUdpRecivePort.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUdpRecivePort.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUdpRecivePort.Location = new System.Drawing.Point(4, 4);
            this.numbericUdpRecivePort.Macimum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numbericUdpRecivePort.Margin = new System.Windows.Forms.Padding(4);
            this.numbericUdpRecivePort.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numbericUdpRecivePort.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUdpRecivePort.Name = "numbericUdpRecivePort";
            this.numbericUdpRecivePort.NoReadOnly = true;
            this.numbericUdpRecivePort.ReadOnly = false;
            this.numbericUdpRecivePort.Size = new System.Drawing.Size(214, 98);
            this.numbericUdpRecivePort.TabIndex = 0;
            this.numbericUdpRecivePort.Title = "Порт";
            this.numbericUdpRecivePort.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUdpRecivePort.VisibleOK = false;
            this.numbericUdpRecivePort.ValueChanged += new TableAIS.ValueChangedControl(this.numbericUdpRecivePort_ValueChanged);
            this.numbericUdpRecivePort.VisibleChanged += new System.EventHandler(this.numbericUdpRecivePort_VisibleChanged);
            // 
            // buttonUdpRecipientStart
            // 
            this.tableLayoutPanel6.SetColumnSpan(this.buttonUdpRecipientStart, 2);
            this.buttonUdpRecipientStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUdpRecipientStart.Location = new System.Drawing.Point(3, 109);
            this.buttonUdpRecipientStart.Name = "buttonUdpRecipientStart";
            this.buttonUdpRecipientStart.Size = new System.Drawing.Size(216, 44);
            this.buttonUdpRecipientStart.TabIndex = 1;
            this.buttonUdpRecipientStart.Text = "button2";
            this.buttonUdpRecipientStart.UseVisualStyleBackColor = true;
            this.buttonUdpRecipientStart.Click += new System.EventHandler(this.buttonUdpRecipientStart_Click);
            // 
            // timerAllowed
            // 
            this.timerAllowed.Enabled = true;
            this.timerAllowed.Tick += new System.EventHandler(this.timerAllowed_Tick);
            // 
            // HostSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(933, 453);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(600, 500);
            this.Name = "HostSettings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Настройки сетевого узла";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBoxUdpClient.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.groupBoxTcpClient.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxTcpServer.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.groupBoxUdpServer.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxIpAddress;
        private System.Windows.Forms.Button buttonClearBuffer;
        private System.Windows.Forms.GroupBox groupBoxTcpServer;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private NumbericUser numbericPortServer;
        private System.Windows.Forms.Button buttonServerStart;
        private System.Windows.Forms.GroupBox groupBoxTcpClient;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private NumbericUser numbericPortClient;
        private System.Windows.Forms.Button buttonClientStart;
        private System.Windows.Forms.GroupBox groupBoxUdpClient;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private NumbericUser numbericUdpSenderPort;
        private System.Windows.Forms.Button buttonUdpSenderStart;
        private System.Windows.Forms.GroupBox groupBoxUdpServer;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private NumbericUser numbericUdpRecivePort;
        private System.Windows.Forms.Button buttonUdpRecipientStart;
        private System.Windows.Forms.Timer timerAllowed;
    }
}