﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class HostSettings : Form
    {

        bool serverWorking
        {
            get => TcpHelper.ServerStarting;
            set => TcpHelper.ServerStarting = value;
        }

        public bool ClientStarting
        {
            get => clientStarting; set => clientStarting = value;
        }

        bool clientStarting
        {
            get => TcpHelper.ClientStarting;
            set => TcpHelper.ClientStarting = value;
        }

        public bool ServerWorking
        {
            get => serverWorking; set => serverWorking = value;
        }

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;


        public HostSettings()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public HostSettings(Save save):this()
        {
            Save = save;
        }

        public HostSettings(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        bool UdpServerWorking
        {
            get => UDPHelper.ServerStarting;
            set => UDPHelper.ServerStarting = value;
        }

        public void UdpClientOff()
        {
            UdpClientWorking = !UdpClientWorking;
        }

        bool UdpClientWorking
        {
            get => UDPHelper.ClientStarting;
            set => UDPHelper.ClientStarting = value;
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();

            try
            {
                textBoxIpAddress.Text = TcpHelper.GetIpAddressThis();
            }
            catch
            {
                textBoxIpAddress.Text = "127.0.0.1";
            }

            try
            {
                buttonServerStart.Text = serverWorking ? "Отстановить" : "Запустить";
                numbericPortServer.ReadOnly = ServerWorking;
                if (!ServerWorking)
                {
                    try
                    {
                        TcpHelper.ThisServer.Close();
                    }
                    catch
                    {

                    }

                    try
                    {
                        TcpHelper.ServerStop();
                    }
                    catch
                    {

                    }
                }
            }
            catch
            {

            }

            try
            {
                buttonClientStart.Text = clientStarting ? "Отстановить" : "Запустить";
                numbericPortClient.ReadOnly = clientStarting;
                if (!ClientStarting)
                {
                    try
                    {
                        TcpHelper.ThisClient.Close();
                    }
                    catch
                    {

                    }

                    try
                    {
                        TcpHelper.ClientStop();
                    }
                    catch
                    {

                    }
                }
            }
            catch
            {

            }

            try
            {
                buttonUdpRecipientStart.Text = UdpServerWorking ? "Отстановить" : "Запустить";
                numbericUdpRecivePort.ReadOnly = UdpServerWorking;
                if (!UdpServerWorking)
                {
                    try
                    {
                        UDPHelper.ThisServer.Close();
                    }
                    catch
                    {

                    }

                    try
                    {
                        UDPHelper.ServerStop();
                    }
                    catch
                    {

                    }
                }
            }
            catch
            {

            }

            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            try
            {

                buttonUdpSenderStart.Text = UdpClientWorking ? "Отстановить" : "Запустить";
                numbericUdpSenderPort.ReadOnly = UdpClientWorking;
            }
            catch { }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

            numbericPortServer.Value = TcpHelper.ServerPort;
            numbericPortClient.Value = TcpHelper.ClientPort;
            numbericUdpSenderPort.Value = UDPHelper.UdpPortClient;
            numbericUdpRecivePort.Value = UDPHelper.UdpPortServer;

            try
            {
                
            }
            catch
            {

            }
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void buttonClearBuffer_Click(object sender, EventArgs e)
        {
            Buffer.Text = "";
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            serverWorking = !serverWorking;
            if(serverWorking)
            {
                try
                {
                    TcpHelper.ServerStart();
                }
                catch
                {
                    ServerWorking = false;
                }
            }
        }

        private void numbericPortServer_ValueChanged(object sender, EventArgs e, decimal value)
        {
            TcpHelper.ServerPort = (int)value;
        }

        private void buttonClientStart_Click(object sender, EventArgs e)
        {
            ClientStarting = !ClientStarting;
            if(ClientStarting)
            {
                try
                {
                    TcpHelper.ClientStart();
                }
                catch
                {

                }
            }
        }

        private void numbericPortClient_ValueChanged(object sender, EventArgs e, decimal value)
        {
            TcpHelper.ClientPort = (int)value;
        }

        private void numbericUdpRecivePort_ValueChanged(object sender, EventArgs e, decimal value)
        {
            UDPHelper.UdpPortServer = (int)value;
        }

        private void numbericUdpSenderPort_VisibleChanged(object sender, EventArgs e)
        {
           
        }

        private void numbericUdpRecivePort_VisibleChanged(object sender, EventArgs e)
        {
            
        }

        private void numbericUdpSenderPort_ValueChanged(object sender, EventArgs e, decimal value)
        {
            UDPHelper.UdpPortClient = (int)(value);
        }

        private void buttonUdpRecipientStart_Click(object sender, EventArgs e)
        {
            UdpServerWorking = !UdpServerWorking;
            if (UdpServerWorking)
            {
                try
                {
                    UDPHelper.ServerStart();
                }
                catch
                {

                }
            }
        }

        private void timerAllowed_Tick(object sender, EventArgs e)
        {
            bool tcp = SecurityHelper.TcpPermissions.Allowed;
            groupBoxTcpServer.Enabled = tcp;
            groupBoxTcpClient.Enabled = tcp;
            bool udp = SecurityHelper.UdpPermissins.Allowed;
            groupBoxUdpClient.Enabled = udp;
            groupBoxUdpServer.Enabled = udp;

        }

        private void buttonUdpSenderStart_Click(object sender, EventArgs e)
        {
            UdpClientOff();
        }
    }
}
