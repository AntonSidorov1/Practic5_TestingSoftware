﻿namespace TableAIS
{
    partial class ListCalculatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListCalculatorForm));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.listBoxCalculatePositions = new System.Windows.Forms.ListBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.buttonUpdate2 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClear = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCreate = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddPositionByFile = new System.Windows.Forms.ToolStripMenuItem();
            this.изJsonпредставленияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddJsonLastWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddJsonByMainWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddJsonByClipBoard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddCopyChoosePosition = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddPosByCalculator = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddCopyChoosePositionWithAToB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddCopyChoosePositionWithCalcBToB = new System.Windows.Forms.ToolStripMenuItem();
            this.списокИФайлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcListExport = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcListExportFile = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcListExportLastWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcListExportMainWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcListExportClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.импортироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcImportCalc = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcImportCalcFile = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcImportCalcLastWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcImportCalcMainWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcImportCalcClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcListImportSet = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcListImportSetFile = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcListImportSetLastWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcListImportSetMainWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcListImportSetClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDeletePos = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBoxPos = new System.Windows.Forms.GroupBox();
            this.tabControlPos = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.flowResize1 = new TableAIS.FlowResize();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.button4 = new System.Windows.Forms.Button();
            this.textBoxB = new TableAIS.TextBoxWithTitle();
            this.buttonAddFeatcher = new System.Windows.Forms.Button();
            this.buttonCalcB = new System.Windows.Forms.Button();
            this.checkBoxFlagsView = new System.Windows.Forms.CheckBox();
            this.checkBoxCorreectB = new System.Windows.Forms.CheckBox();
            this.groupBoxCorrectB = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonAddBaskets = new System.Windows.Forms.Button();
            this.buttonChangeBaskets = new System.Windows.Forms.Button();
            this.buttonDropBaskets = new System.Windows.Forms.Button();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.раскрытьКомпонентыФормулыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenVariable = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOpenConst = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropVariable = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonInteractiveEditPos = new System.Windows.Forms.Button();
            this.checkBoxCalcView = new System.Windows.Forms.CheckBox();
            this.tableLayoutCalc = new System.Windows.Forms.TableLayoutPanel();
            this.buttonCalc = new System.Windows.Forms.Button();
            this.checkBoxAutoCalc = new System.Windows.Forms.CheckBox();
            this.checkBoxEnter = new System.Windows.Forms.CheckBox();
            this.buttonCopyAB = new System.Windows.Forms.Button();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxA = new TableAIS.TextBoxWithTitle();
            this.button3 = new System.Windows.Forms.Button();
            this.checkBoxAutoCalcA = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonCopyBCalcB = new System.Windows.Forms.Button();
            this.buttonPastCalcBFromBCalcB = new System.Windows.Forms.Button();
            this.buttonPastBFromBCalcB = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonCalculatorImport = new System.Windows.Forms.Button();
            this.buttonCalculatorExport = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.flowResize3 = new TableAIS.FlowResize();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxBInput = new TableAIS.TextBoxWithTitle();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxAOutput = new TableAIS.TextBoxWithLine();
            this.buttonBackSpace = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBoxAutoCalcInput = new System.Windows.Forms.CheckBox();
            this.checkBoxEnterInput = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.flowResize2 = new TableAIS.FlowResize();
            this.buttonPositionDelete = new System.Windows.Forms.Button();
            this.buttonPositionSave = new System.Windows.Forms.Button();
            this.buttonPositionLoad = new System.Windows.Forms.Button();
            this.menuStrip7 = new System.Windows.Forms.MenuStrip();
            this.обменСГлавнымЭкраномToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripJsonDropVariants = new System.Windows.Forms.ToolStripComboBox();
            this.buttonJsonLastWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonJsonMainWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonJsonClipBoard = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.flowResize4 = new TableAIS.FlowResize();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonClipboard = new System.Windows.Forms.RadioButton();
            this.radioButtonMain = new System.Windows.Forms.RadioButton();
            this.radioButtonLast = new System.Windows.Forms.RadioButton();
            this.radioButtonCalc = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonCalcHelp = new System.Windows.Forms.RadioButton();
            this.radioButtonCalcBuffer = new System.Windows.Forms.RadioButton();
            this.radioButtonCalcA = new System.Windows.Forms.RadioButton();
            this.radioButtonCalcB = new System.Windows.Forms.RadioButton();
            this.radioButtonValueB = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonLocalBA = new System.Windows.Forms.RadioButton();
            this.radioButtonLocalA = new System.Windows.Forms.RadioButton();
            this.radioButtonLocalB = new System.Windows.Forms.RadioButton();
            this.radioButtonLocalAB = new System.Windows.Forms.RadioButton();
            this.radioButtonLocalValueB = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonLoad = new System.Windows.Forms.Button();
            this.buttonSave = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxCalc = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxLocal = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxCount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.timerPos = new System.Windows.Forms.Timer(this.components);
            this.timerUpdate = new System.Windows.Forms.Timer(this.components);
            this.saveFileCalculator = new System.Windows.Forms.SaveFileDialog();
            this.openFileCalculator = new System.Windows.Forms.OpenFileDialog();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBoxPos.SuspendLayout();
            this.tabControlPos.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.flowResize1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBoxCorrectB.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.tableLayoutCalc.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.flowResize3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.flowResize2.SuspendLayout();
            this.menuStrip7.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.flowResize4.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(530, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(223, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(782, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(778, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(413, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 504);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(782, 23);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.23529F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.76471F));
            this.tableLayoutPanel2.Controls.Add(this.listBoxCalculatePositions, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.menuStrip1, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxPos, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.button1, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel7, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.671233F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 92.32877F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(782, 415);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // listBoxCalculatePositions
            // 
            this.listBoxCalculatePositions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxCalculatePositions.FormattingEnabled = true;
            this.listBoxCalculatePositions.HorizontalScrollbar = true;
            this.listBoxCalculatePositions.ItemHeight = 21;
            this.listBoxCalculatePositions.Location = new System.Drawing.Point(3, 49);
            this.listBoxCalculatePositions.Name = "listBoxCalculatePositions";
            this.tableLayoutPanel2.SetRowSpan(this.listBoxCalculatePositions, 2);
            this.listBoxCalculatePositions.ScrollAlwaysVisible = true;
            this.listBoxCalculatePositions.Size = new System.Drawing.Size(292, 363);
            this.listBoxCalculatePositions.TabIndex = 0;
            this.listBoxCalculatePositions.SelectedIndexChanged += new System.EventHandler(this.listBoxCalculatePositions_SelectedIndexChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonUpdate2,
            this.добавитьToolStripMenuItem,
            this.списокИФайлToolStripMenuItem,
            this.buttonDeletePos});
            this.menuStrip1.Location = new System.Drawing.Point(298, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(484, 29);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // buttonUpdate2
            // 
            this.buttonUpdate2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonUpdate,
            this.buttonClear});
            this.buttonUpdate2.Name = "buttonUpdate2";
            this.buttonUpdate2.Size = new System.Drawing.Size(87, 25);
            this.buttonUpdate2.Text = "Список";
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(176, 26);
            this.buttonUpdate.Text = "Обновить";
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(176, 26);
            this.buttonClear.Text = "Очистить";
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCreate,
            this.buttonAddPositionByFile,
            this.изJsonпредставленияToolStripMenuItem,
            this.buttonAddCopyChoosePosition,
            this.buttonAddPosByCalculator,
            this.buttonAddCopyChoosePositionWithAToB,
            this.buttonAddCopyChoosePositionWithCalcBToB});
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(104, 25);
            this.добавитьToolStripMenuItem.Text = "Добавить";
            // 
            // buttonCreate
            // 
            this.buttonCreate.Name = "buttonCreate";
            this.buttonCreate.Size = new System.Drawing.Size(415, 26);
            this.buttonCreate.Text = "Создать";
            this.buttonCreate.Click += new System.EventHandler(this.buttonCreate_Click);
            // 
            // buttonAddPositionByFile
            // 
            this.buttonAddPositionByFile.Name = "buttonAddPositionByFile";
            this.buttonAddPositionByFile.Size = new System.Drawing.Size(415, 26);
            this.buttonAddPositionByFile.Text = "Добавить из файла";
            this.buttonAddPositionByFile.Click += new System.EventHandler(this.buttonAddPositionByFile_Click);
            // 
            // изJsonпредставленияToolStripMenuItem
            // 
            this.изJsonпредставленияToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddJsonLastWindow,
            this.buttonAddJsonByMainWindow,
            this.buttonAddJsonByClipBoard});
            this.изJsonпредставленияToolStripMenuItem.Name = "изJsonпредставленияToolStripMenuItem";
            this.изJsonпредставленияToolStripMenuItem.Size = new System.Drawing.Size(415, 26);
            this.изJsonпредставленияToolStripMenuItem.Text = "Из Json-представления";
            // 
            // buttonAddJsonLastWindow
            // 
            this.buttonAddJsonLastWindow.Name = "buttonAddJsonLastWindow";
            this.buttonAddJsonLastWindow.Size = new System.Drawing.Size(293, 26);
            this.buttonAddJsonLastWindow.Text = "С предыдущего экрана";
            this.buttonAddJsonLastWindow.Click += new System.EventHandler(this.buttonAddJsonLastWindow_Click);
            // 
            // buttonAddJsonByMainWindow
            // 
            this.buttonAddJsonByMainWindow.Name = "buttonAddJsonByMainWindow";
            this.buttonAddJsonByMainWindow.Size = new System.Drawing.Size(293, 26);
            this.buttonAddJsonByMainWindow.Text = "С главного экрана";
            this.buttonAddJsonByMainWindow.Click += new System.EventHandler(this.buttonAddJsonByMainWindow_Click);
            // 
            // buttonAddJsonByClipBoard
            // 
            this.buttonAddJsonByClipBoard.Name = "buttonAddJsonByClipBoard";
            this.buttonAddJsonByClipBoard.Size = new System.Drawing.Size(293, 26);
            this.buttonAddJsonByClipBoard.Text = "Из буфера обмена";
            this.buttonAddJsonByClipBoard.Click += new System.EventHandler(this.buttonAddJsonByClipBoard_Click);
            // 
            // buttonAddCopyChoosePosition
            // 
            this.buttonAddCopyChoosePosition.Name = "buttonAddCopyChoosePosition";
            this.buttonAddCopyChoosePosition.Size = new System.Drawing.Size(415, 26);
            this.buttonAddCopyChoosePosition.Text = "Копию выбранной позиции";
            this.buttonAddCopyChoosePosition.Click += new System.EventHandler(this.buttonAddCopyChoosePosition_Click);
            // 
            // buttonAddPosByCalculator
            // 
            this.buttonAddPosByCalculator.Name = "buttonAddPosByCalculator";
            this.buttonAddPosByCalculator.Size = new System.Drawing.Size(415, 26);
            this.buttonAddPosByCalculator.Text = "С калькулятора";
            this.buttonAddPosByCalculator.Click += new System.EventHandler(this.buttonAddPosByCalculator_Click);
            // 
            // buttonAddCopyChoosePositionWithAToB
            // 
            this.buttonAddCopyChoosePositionWithAToB.Name = "buttonAddCopyChoosePositionWithAToB";
            this.buttonAddCopyChoosePositionWithAToB.Size = new System.Drawing.Size(415, 26);
            this.buttonAddCopyChoosePositionWithAToB.Text = "B является A в текущей позиции";
            this.buttonAddCopyChoosePositionWithAToB.Click += new System.EventHandler(this.buttonAddCopyChoosePositionWithAToB_Click);
            // 
            // buttonAddCopyChoosePositionWithCalcBToB
            // 
            this.buttonAddCopyChoosePositionWithCalcBToB.Name = "buttonAddCopyChoosePositionWithCalcBToB";
            this.buttonAddCopyChoosePositionWithCalcBToB.Size = new System.Drawing.Size(415, 26);
            this.buttonAddCopyChoosePositionWithCalcBToB.Text = "B является Calc(B) в текущей позиции";
            this.buttonAddCopyChoosePositionWithCalcBToB.Click += new System.EventHandler(this.buttonAddCopyChoosePositionWithCalcBToB_Click);
            // 
            // списокИФайлToolStripMenuItem
            // 
            this.списокИФайлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCalcListExport,
            this.импортироватьToolStripMenuItem});
            this.списокИФайлToolStripMenuItem.Name = "списокИФайлToolStripMenuItem";
            this.списокИФайлToolStripMenuItem.Size = new System.Drawing.Size(142, 25);
            this.списокИФайлToolStripMenuItem.Text = "Список и Json";
            // 
            // buttonCalcListExport
            // 
            this.buttonCalcListExport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCalcListExportFile,
            this.buttonCalcListExportLastWindow,
            this.buttonCalcListExportMainWindow,
            this.buttonCalcListExportClipboard});
            this.buttonCalcListExport.Name = "buttonCalcListExport";
            this.buttonCalcListExport.Size = new System.Drawing.Size(231, 26);
            this.buttonCalcListExport.Text = "Экспортировать";
            // 
            // buttonCalcListExportFile
            // 
            this.buttonCalcListExportFile.Name = "buttonCalcListExportFile";
            this.buttonCalcListExportFile.Size = new System.Drawing.Size(287, 26);
            this.buttonCalcListExportFile.Text = "В файл";
            this.buttonCalcListExportFile.Click += new System.EventHandler(this.buttonCalcListExport_Click);
            // 
            // buttonCalcListExportLastWindow
            // 
            this.buttonCalcListExportLastWindow.Name = "buttonCalcListExportLastWindow";
            this.buttonCalcListExportLastWindow.Size = new System.Drawing.Size(287, 26);
            this.buttonCalcListExportLastWindow.Text = "На предыдущий экран";
            this.buttonCalcListExportLastWindow.Click += new System.EventHandler(this.buttonCalcListExportLastWindow_Click);
            // 
            // buttonCalcListExportMainWindow
            // 
            this.buttonCalcListExportMainWindow.Name = "buttonCalcListExportMainWindow";
            this.buttonCalcListExportMainWindow.Size = new System.Drawing.Size(287, 26);
            this.buttonCalcListExportMainWindow.Text = "На главный экран";
            this.buttonCalcListExportMainWindow.Click += new System.EventHandler(this.buttonCalcListExportMainWindow_Click);
            // 
            // buttonCalcListExportClipboard
            // 
            this.buttonCalcListExportClipboard.Name = "buttonCalcListExportClipboard";
            this.buttonCalcListExportClipboard.Size = new System.Drawing.Size(287, 26);
            this.buttonCalcListExportClipboard.Text = "В буфер обмена";
            this.buttonCalcListExportClipboard.Click += new System.EventHandler(this.buttonCalcListExportClipboard_Click);
            // 
            // импортироватьToolStripMenuItem
            // 
            this.импортироватьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCalcImportCalc,
            this.buttonCalcListImportSet});
            this.импортироватьToolStripMenuItem.Name = "импортироватьToolStripMenuItem";
            this.импортироватьToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.импортироватьToolStripMenuItem.Text = "Импортировать";
            // 
            // buttonCalcImportCalc
            // 
            this.buttonCalcImportCalc.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCalcImportCalcFile,
            this.buttonCalcImportCalcLastWindow,
            this.buttonCalcImportCalcMainWindow,
            this.buttonCalcImportCalcClipboard});
            this.buttonCalcImportCalc.Name = "buttonCalcImportCalc";
            this.buttonCalcImportCalc.Size = new System.Drawing.Size(224, 26);
            this.buttonCalcImportCalc.Text = "В конец списка";
            // 
            // buttonCalcImportCalcFile
            // 
            this.buttonCalcImportCalcFile.Name = "buttonCalcImportCalcFile";
            this.buttonCalcImportCalcFile.Size = new System.Drawing.Size(293, 26);
            this.buttonCalcImportCalcFile.Text = "Из файла";
            this.buttonCalcImportCalcFile.Click += new System.EventHandler(this.buttonCalcImportCalc_Click);
            // 
            // buttonCalcImportCalcLastWindow
            // 
            this.buttonCalcImportCalcLastWindow.Name = "buttonCalcImportCalcLastWindow";
            this.buttonCalcImportCalcLastWindow.Size = new System.Drawing.Size(293, 26);
            this.buttonCalcImportCalcLastWindow.Text = "С предыдущего экрана";
            this.buttonCalcImportCalcLastWindow.Click += new System.EventHandler(this.buttonCalcImportCalcLastWindow_Click);
            // 
            // buttonCalcImportCalcMainWindow
            // 
            this.buttonCalcImportCalcMainWindow.Name = "buttonCalcImportCalcMainWindow";
            this.buttonCalcImportCalcMainWindow.Size = new System.Drawing.Size(293, 26);
            this.buttonCalcImportCalcMainWindow.Text = "С главного экрана";
            this.buttonCalcImportCalcMainWindow.Click += new System.EventHandler(this.buttonCalcImportCalcMainWindow_Click);
            // 
            // buttonCalcImportCalcClipboard
            // 
            this.buttonCalcImportCalcClipboard.Name = "buttonCalcImportCalcClipboard";
            this.buttonCalcImportCalcClipboard.Size = new System.Drawing.Size(293, 26);
            this.buttonCalcImportCalcClipboard.Text = "Из буфера обмена";
            this.buttonCalcImportCalcClipboard.Click += new System.EventHandler(this.buttonCalcImportCalcClipboard_Click);
            // 
            // buttonCalcListImportSet
            // 
            this.buttonCalcListImportSet.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCalcListImportSetFile,
            this.buttonCalcListImportSetLastWindow,
            this.buttonCalcListImportSetMainWindow,
            this.buttonCalcListImportSetClipboard});
            this.buttonCalcListImportSet.Name = "buttonCalcListImportSet";
            this.buttonCalcListImportSet.Size = new System.Drawing.Size(224, 26);
            this.buttonCalcListImportSet.Text = "Вместо списка";
            // 
            // buttonCalcListImportSetFile
            // 
            this.buttonCalcListImportSetFile.Name = "buttonCalcListImportSetFile";
            this.buttonCalcListImportSetFile.Size = new System.Drawing.Size(293, 26);
            this.buttonCalcListImportSetFile.Text = "Из файла";
            this.buttonCalcListImportSetFile.Click += new System.EventHandler(this.buttonCalcListImportSet_Click);
            // 
            // buttonCalcListImportSetLastWindow
            // 
            this.buttonCalcListImportSetLastWindow.Name = "buttonCalcListImportSetLastWindow";
            this.buttonCalcListImportSetLastWindow.Size = new System.Drawing.Size(293, 26);
            this.buttonCalcListImportSetLastWindow.Text = "С предыдущего экрана";
            this.buttonCalcListImportSetLastWindow.Click += new System.EventHandler(this.buttonCalcListImportSetLastWindow_Click);
            // 
            // buttonCalcListImportSetMainWindow
            // 
            this.buttonCalcListImportSetMainWindow.Name = "buttonCalcListImportSetMainWindow";
            this.buttonCalcListImportSetMainWindow.Size = new System.Drawing.Size(293, 26);
            this.buttonCalcListImportSetMainWindow.Text = "С главного экрана";
            this.buttonCalcListImportSetMainWindow.Click += new System.EventHandler(this.buttonCalcListImportSetMainWindow_Click);
            // 
            // buttonCalcListImportSetClipboard
            // 
            this.buttonCalcListImportSetClipboard.Name = "buttonCalcListImportSetClipboard";
            this.buttonCalcListImportSetClipboard.Size = new System.Drawing.Size(293, 26);
            this.buttonCalcListImportSetClipboard.Text = "Из буфера обмена";
            this.buttonCalcListImportSetClipboard.Click += new System.EventHandler(this.buttonCalcListImportSetClipboard_Click);
            // 
            // buttonDeletePos
            // 
            this.buttonDeletePos.Name = "buttonDeletePos";
            this.buttonDeletePos.Size = new System.Drawing.Size(93, 25);
            this.buttonDeletePos.Text = "Удалить";
            this.buttonDeletePos.Click += new System.EventHandler(this.buttonPositionDelete_Click);
            // 
            // groupBoxPos
            // 
            this.groupBoxPos.Controls.Add(this.tabControlPos);
            this.groupBoxPos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxPos.Location = new System.Drawing.Point(301, 77);
            this.groupBoxPos.Name = "groupBoxPos";
            this.groupBoxPos.Size = new System.Drawing.Size(478, 335);
            this.groupBoxPos.TabIndex = 2;
            this.groupBoxPos.TabStop = false;
            this.groupBoxPos.Text = "Позиция в калькуляторе";
            this.groupBoxPos.VisibleChanged += new System.EventHandler(this.groupBoxPos_VisibleChanged);
            // 
            // tabControlPos
            // 
            this.tabControlPos.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControlPos.Controls.Add(this.tabPage1);
            this.tabControlPos.Controls.Add(this.tabPage4);
            this.tabControlPos.Controls.Add(this.tabPage3);
            this.tabControlPos.Controls.Add(this.tabPage5);
            this.tabControlPos.Controls.Add(this.tabPage2);
            this.tabControlPos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPos.Location = new System.Drawing.Point(3, 30);
            this.tabControlPos.Name = "tabControlPos";
            this.tabControlPos.SelectedIndex = 0;
            this.tabControlPos.Size = new System.Drawing.Size(472, 302);
            this.tabControlPos.TabIndex = 0;
            this.tabControlPos.SelectedIndexChanged += new System.EventHandler(this.tabControlPos_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.flowResize1);
            this.tabPage1.Location = new System.Drawing.Point(4, 33);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(464, 265);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Расчёты";
            // 
            // flowResize1
            // 
            this.flowResize1.AutoScroll = true;
            this.flowResize1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize1.Controls.Add(this.tableLayoutPanel3);
            this.flowResize1.Controls.Add(this.checkBoxFlagsView);
            this.flowResize1.Controls.Add(this.checkBoxCorreectB);
            this.flowResize1.Controls.Add(this.groupBoxCorrectB);
            this.flowResize1.Controls.Add(this.checkBoxCalcView);
            this.flowResize1.Controls.Add(this.tableLayoutCalc);
            this.flowResize1.Controls.Add(this.tableLayoutPanel15);
            this.flowResize1.Controls.Add(this.tableLayoutPanel18);
            this.flowResize1.Controls.Add(this.groupBox5);
            this.flowResize1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize1.Location = new System.Drawing.Point(3, 3);
            this.flowResize1.Margin = new System.Windows.Forms.Padding(5);
            this.flowResize1.Name = "flowResize1";
            this.flowResize1.Size = new System.Drawing.Size(454, 255);
            this.flowResize1.TabIndex = 0;
            this.flowResize1.WithDelta = 35;
            this.flowResize1.WrapContents = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel3.Controls.Add(this.button4, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.textBoxB, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonAddFeatcher, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonCalcB, 1, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(419, 122);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // button4
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.button4, 2);
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.Location = new System.Drawing.Point(3, 91);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(413, 28);
            this.button4.TabIndex = 5;
            this.button4.Text = "Интерактивное редактирование";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.buttonInteractiveEditPos_Click);
            // 
            // textBoxB
            // 
            this.textBoxB.AllowNegative = true;
            this.textBoxB.ClearingByReadonly = false;
            this.textBoxB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxB.EnterAllow = true;
            this.textBoxB.Location = new System.Drawing.Point(4, 4);
            this.textBoxB.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxB.MultiLine = false;
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.NoReadOnly = true;
            this.textBoxB.ReadOnly = false;
            this.tableLayoutPanel3.SetRowSpan(this.textBoxB, 2);
            this.textBoxB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxB.SelectionStart = 0;
            this.textBoxB.Size = new System.Drawing.Size(321, 80);
            this.textBoxB.TabIndex = 0;
            this.textBoxB.TextWithLineBreaks = "";
            this.textBoxB.Title = "B=";
            this.textBoxB.UseSystemPasswordChar = false;
            this.textBoxB.Value = "";
            this.textBoxB.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxB.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxB.ValueText = "";
            this.textBoxB.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxB.ValueWithLineBreaks = "";
            this.textBoxB.VisibleOK = false;
            this.textBoxB.ValueChanged += new TableAIS.TextValueChanged(this.textBoxB_ValueChanged);
            this.textBoxB.ValueKeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxB_ValueKeyDown);
            // 
            // buttonAddFeatcher
            // 
            this.buttonAddFeatcher.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAddFeatcher.Location = new System.Drawing.Point(332, 3);
            this.buttonAddFeatcher.Name = "buttonAddFeatcher";
            this.buttonAddFeatcher.Size = new System.Drawing.Size(84, 38);
            this.buttonAddFeatcher.TabIndex = 1;
            this.buttonAddFeatcher.Text = "Вставить функцию";
            this.buttonAddFeatcher.UseVisualStyleBackColor = true;
            this.buttonAddFeatcher.Click += new System.EventHandler(this.buttonAddFeatcher_Click);
            // 
            // buttonCalcB
            // 
            this.buttonCalcB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalcB.Location = new System.Drawing.Point(332, 47);
            this.buttonCalcB.Name = "buttonCalcB";
            this.buttonCalcB.Size = new System.Drawing.Size(84, 38);
            this.buttonCalcB.TabIndex = 2;
            this.buttonCalcB.Text = "Вычислить";
            this.buttonCalcB.UseVisualStyleBackColor = true;
            this.buttonCalcB.Click += new System.EventHandler(this.buttonCalcB_Click);
            // 
            // checkBoxFlagsView
            // 
            this.checkBoxFlagsView.AutoSize = true;
            this.checkBoxFlagsView.Location = new System.Drawing.Point(3, 131);
            this.checkBoxFlagsView.Name = "checkBoxFlagsView";
            this.checkBoxFlagsView.Size = new System.Drawing.Size(350, 25);
            this.checkBoxFlagsView.TabIndex = 0;
            this.checkBoxFlagsView.Text = "Показывать флажки скрытия панелей";
            this.checkBoxFlagsView.UseVisualStyleBackColor = true;
            // 
            // checkBoxCorreectB
            // 
            this.checkBoxCorreectB.AutoSize = true;
            this.checkBoxCorreectB.Location = new System.Drawing.Point(3, 162);
            this.checkBoxCorreectB.Name = "checkBoxCorreectB";
            this.checkBoxCorreectB.Size = new System.Drawing.Size(347, 25);
            this.checkBoxCorreectB.TabIndex = 0;
            this.checkBoxCorreectB.Text = "Показывать варианты исправлений B";
            this.checkBoxCorreectB.UseVisualStyleBackColor = true;
            // 
            // groupBoxCorrectB
            // 
            this.groupBoxCorrectB.Controls.Add(this.tableLayoutPanel14);
            this.groupBoxCorrectB.Location = new System.Drawing.Point(3, 193);
            this.groupBoxCorrectB.Name = "groupBoxCorrectB";
            this.groupBoxCorrectB.Size = new System.Drawing.Size(419, 140);
            this.groupBoxCorrectB.TabIndex = 0;
            this.groupBoxCorrectB.TabStop = false;
            this.groupBoxCorrectB.Text = "Показывать панель исправлений B";
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.Controls.Add(this.buttonAddBaskets, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.buttonChangeBaskets, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.buttonDropBaskets, 0, 1);
            this.tableLayoutPanel14.Controls.Add(this.menuStrip2, 1, 1);
            this.tableLayoutPanel14.Controls.Add(this.buttonInteractiveEditPos, 0, 2);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 3;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(413, 107);
            this.tableLayoutPanel14.TabIndex = 0;
            // 
            // buttonAddBaskets
            // 
            this.buttonAddBaskets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonAddBaskets.Location = new System.Drawing.Point(3, 3);
            this.buttonAddBaskets.Name = "buttonAddBaskets";
            this.buttonAddBaskets.Size = new System.Drawing.Size(200, 29);
            this.buttonAddBaskets.TabIndex = 0;
            this.buttonAddBaskets.Text = "Добавить скобки";
            this.buttonAddBaskets.UseVisualStyleBackColor = true;
            this.buttonAddBaskets.Click += new System.EventHandler(this.buttonAddBaskets_Click);
            // 
            // buttonChangeBaskets
            // 
            this.buttonChangeBaskets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonChangeBaskets.Location = new System.Drawing.Point(209, 3);
            this.buttonChangeBaskets.Name = "buttonChangeBaskets";
            this.buttonChangeBaskets.Size = new System.Drawing.Size(201, 29);
            this.buttonChangeBaskets.TabIndex = 1;
            this.buttonChangeBaskets.Text = "Выравнять скобки";
            this.buttonChangeBaskets.UseVisualStyleBackColor = true;
            this.buttonChangeBaskets.Click += new System.EventHandler(this.buttonChangeBaskets_Click);
            // 
            // buttonDropBaskets
            // 
            this.buttonDropBaskets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDropBaskets.Location = new System.Drawing.Point(3, 38);
            this.buttonDropBaskets.Name = "buttonDropBaskets";
            this.buttonDropBaskets.Size = new System.Drawing.Size(200, 29);
            this.buttonDropBaskets.TabIndex = 2;
            this.buttonDropBaskets.Text = "Удалить внешние скобки";
            this.buttonDropBaskets.UseVisualStyleBackColor = true;
            this.buttonDropBaskets.Click += new System.EventHandler(this.buttonDropBaskets_Click);
            // 
            // menuStrip2
            // 
            this.menuStrip2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip2.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.раскрытьКомпонентыФормулыToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(206, 35);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(0);
            this.menuStrip2.Size = new System.Drawing.Size(207, 35);
            this.menuStrip2.TabIndex = 3;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // раскрытьКомпонентыФормулыToolStripMenuItem
            // 
            this.раскрытьКомпонентыФормулыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonOpenVariable,
            this.buttonOpenConst,
            this.buttonDropVariable});
            this.раскрытьКомпонентыФормулыToolStripMenuItem.Name = "раскрытьКомпонентыФормулыToolStripMenuItem";
            this.раскрытьКомпонентыФормулыToolStripMenuItem.Size = new System.Drawing.Size(215, 35);
            this.раскрытьКомпонентыФормулыToolStripMenuItem.Text = "Раскрыть конструкции";
            // 
            // buttonOpenVariable
            // 
            this.buttonOpenVariable.Name = "buttonOpenVariable";
            this.buttonOpenVariable.Size = new System.Drawing.Size(313, 26);
            this.buttonOpenVariable.Text = "Переменные";
            this.buttonOpenVariable.Click += new System.EventHandler(this.buttonOpenVariable_Click);
            // 
            // buttonOpenConst
            // 
            this.buttonOpenConst.Name = "buttonOpenConst";
            this.buttonOpenConst.Size = new System.Drawing.Size(313, 26);
            this.buttonOpenConst.Text = "Константы";
            this.buttonOpenConst.Click += new System.EventHandler(this.buttonOpenConst_Click);
            // 
            // buttonDropVariable
            // 
            this.buttonDropVariable.Name = "buttonDropVariable";
            this.buttonDropVariable.Size = new System.Drawing.Size(313, 26);
            this.buttonDropVariable.Text = "Переменные и константы";
            this.buttonDropVariable.Click += new System.EventHandler(this.buttonDropVariable_Click);
            // 
            // buttonInteractiveEditPos
            // 
            this.tableLayoutPanel14.SetColumnSpan(this.buttonInteractiveEditPos, 2);
            this.buttonInteractiveEditPos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonInteractiveEditPos.Location = new System.Drawing.Point(3, 73);
            this.buttonInteractiveEditPos.Name = "buttonInteractiveEditPos";
            this.buttonInteractiveEditPos.Size = new System.Drawing.Size(407, 31);
            this.buttonInteractiveEditPos.TabIndex = 4;
            this.buttonInteractiveEditPos.Text = "Интерактивное редактирование";
            this.buttonInteractiveEditPos.UseVisualStyleBackColor = true;
            this.buttonInteractiveEditPos.Click += new System.EventHandler(this.buttonInteractiveEditPos_Click);
            // 
            // checkBoxCalcView
            // 
            this.checkBoxCalcView.AutoSize = true;
            this.checkBoxCalcView.Location = new System.Drawing.Point(3, 339);
            this.checkBoxCalcView.Name = "checkBoxCalcView";
            this.checkBoxCalcView.Size = new System.Drawing.Size(264, 25);
            this.checkBoxCalcView.TabIndex = 3;
            this.checkBoxCalcView.Text = "Показывать панель расчёта";
            this.checkBoxCalcView.UseVisualStyleBackColor = true;
            // 
            // tableLayoutCalc
            // 
            this.tableLayoutCalc.ColumnCount = 2;
            this.tableLayoutCalc.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutCalc.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutCalc.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutCalc.Controls.Add(this.buttonCalc, 0, 0);
            this.tableLayoutCalc.Controls.Add(this.checkBoxAutoCalc, 1, 0);
            this.tableLayoutCalc.Controls.Add(this.checkBoxEnter, 1, 1);
            this.tableLayoutCalc.Controls.Add(this.buttonCopyAB, 0, 1);
            this.tableLayoutCalc.Location = new System.Drawing.Point(3, 370);
            this.tableLayoutCalc.Name = "tableLayoutCalc";
            this.tableLayoutCalc.RowCount = 2;
            this.tableLayoutCalc.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutCalc.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutCalc.Size = new System.Drawing.Size(419, 78);
            this.tableLayoutCalc.TabIndex = 2;
            // 
            // buttonCalc
            // 
            this.buttonCalc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalc.Location = new System.Drawing.Point(3, 3);
            this.buttonCalc.Name = "buttonCalc";
            this.buttonCalc.Size = new System.Drawing.Size(203, 33);
            this.buttonCalc.TabIndex = 0;
            this.buttonCalc.Text = "Посчитать";
            this.buttonCalc.UseVisualStyleBackColor = true;
            this.buttonCalc.Click += new System.EventHandler(this.buttonCalc_Click);
            // 
            // checkBoxAutoCalc
            // 
            this.checkBoxAutoCalc.AutoSize = true;
            this.checkBoxAutoCalc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoCalc.Location = new System.Drawing.Point(212, 3);
            this.checkBoxAutoCalc.Name = "checkBoxAutoCalc";
            this.checkBoxAutoCalc.Size = new System.Drawing.Size(204, 33);
            this.checkBoxAutoCalc.TabIndex = 1;
            this.checkBoxAutoCalc.Text = "Авторассчёт";
            this.checkBoxAutoCalc.UseVisualStyleBackColor = true;
            this.checkBoxAutoCalc.CheckedChanged += new System.EventHandler(this.checkBoxAutoCalc_CheckedChanged);
            // 
            // checkBoxEnter
            // 
            this.checkBoxEnter.AutoSize = true;
            this.checkBoxEnter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxEnter.Location = new System.Drawing.Point(212, 42);
            this.checkBoxEnter.Name = "checkBoxEnter";
            this.checkBoxEnter.Size = new System.Drawing.Size(204, 33);
            this.checkBoxEnter.TabIndex = 2;
            this.checkBoxEnter.Text = "Расчёт по Enter";
            this.checkBoxEnter.UseVisualStyleBackColor = true;
            this.checkBoxEnter.CheckedChanged += new System.EventHandler(this.checkBoxEnter_CheckedChanged);
            // 
            // buttonCopyAB
            // 
            this.buttonCopyAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCopyAB.Location = new System.Drawing.Point(3, 42);
            this.buttonCopyAB.Name = "buttonCopyAB";
            this.buttonCopyAB.Size = new System.Drawing.Size(203, 33);
            this.buttonCopyAB.TabIndex = 3;
            this.buttonCopyAB.Text = "Вывести A в B";
            this.buttonCopyAB.UseVisualStyleBackColor = true;
            this.buttonCopyAB.Click += new System.EventHandler(this.buttonCopyAB_Click);
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel15.Controls.Add(this.textBoxA, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.button3, 1, 1);
            this.tableLayoutPanel15.Controls.Add(this.checkBoxAutoCalcA, 1, 0);
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 454);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(419, 100);
            this.tableLayoutPanel15.TabIndex = 0;
            // 
            // textBoxA
            // 
            this.textBoxA.AllowNegative = true;
            this.textBoxA.ClearingByReadonly = true;
            this.textBoxA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxA.EnterAllow = true;
            this.textBoxA.Location = new System.Drawing.Point(5, 5);
            this.textBoxA.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxA.MultiLine = false;
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.NoReadOnly = false;
            this.textBoxA.ReadOnly = true;
            this.tableLayoutPanel15.SetRowSpan(this.textBoxA, 2);
            this.textBoxA.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxA.SelectionStart = 0;
            this.textBoxA.Size = new System.Drawing.Size(319, 90);
            this.textBoxA.TabIndex = 1;
            this.textBoxA.TextWithLineBreaks = "";
            this.textBoxA.Title = "A=";
            this.textBoxA.UseSystemPasswordChar = false;
            this.textBoxA.Value = "";
            this.textBoxA.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxA.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxA.ValueText = "";
            this.textBoxA.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxA.ValueWithLineBreaks = "";
            this.textBoxA.VisibleOK = false;
            this.textBoxA.ValueChanged += new TableAIS.TextValueChanged(this.textBoxA_ValueChanged);
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Location = new System.Drawing.Point(332, 53);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 44);
            this.button3.TabIndex = 2;
            this.button3.Text = "Вычислить";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.buttonCalc_Click);
            // 
            // checkBoxAutoCalcA
            // 
            this.checkBoxAutoCalcA.AutoSize = true;
            this.checkBoxAutoCalcA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoCalcA.Location = new System.Drawing.Point(332, 3);
            this.checkBoxAutoCalcA.Name = "checkBoxAutoCalcA";
            this.checkBoxAutoCalcA.Size = new System.Drawing.Size(84, 44);
            this.checkBoxAutoCalcA.TabIndex = 3;
            this.checkBoxAutoCalcA.Text = "Авто";
            this.checkBoxAutoCalcA.UseVisualStyleBackColor = true;
            this.checkBoxAutoCalcA.CheckedChanged += new System.EventHandler(this.checkBoxAutoCalcA_CheckedChanged);
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.72727F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.27273F));
            this.tableLayoutPanel18.Controls.Add(this.buttonCopyBCalcB, 0, 1);
            this.tableLayoutPanel18.Controls.Add(this.buttonPastCalcBFromBCalcB, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.buttonPastBFromBCalcB, 0, 0);
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 560);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 2;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(419, 69);
            this.tableLayoutPanel18.TabIndex = 18;
            // 
            // buttonCopyBCalcB
            // 
            this.tableLayoutPanel18.SetColumnSpan(this.buttonCopyBCalcB, 2);
            this.buttonCopyBCalcB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCopyBCalcB.Location = new System.Drawing.Point(3, 37);
            this.buttonCopyBCalcB.Name = "buttonCopyBCalcB";
            this.buttonCopyBCalcB.Size = new System.Drawing.Size(413, 29);
            this.buttonCopyBCalcB.TabIndex = 17;
            this.buttonCopyBCalcB.Text = "Копировать B в виде B=Calc(B)";
            this.buttonCopyBCalcB.UseVisualStyleBackColor = true;
            this.buttonCopyBCalcB.Click += new System.EventHandler(this.buttonCopyBCalcB_Click);
            // 
            // buttonPastCalcBFromBCalcB
            // 
            this.buttonPastCalcBFromBCalcB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPastCalcBFromBCalcB.Location = new System.Drawing.Point(202, 3);
            this.buttonPastCalcBFromBCalcB.Name = "buttonPastCalcBFromBCalcB";
            this.buttonPastCalcBFromBCalcB.Size = new System.Drawing.Size(214, 28);
            this.buttonPastCalcBFromBCalcB.TabIndex = 1;
            this.buttonPastCalcBFromBCalcB.Text = "Вставить Calc(B) (B=Calc(B))";
            this.buttonPastCalcBFromBCalcB.UseVisualStyleBackColor = true;
            this.buttonPastCalcBFromBCalcB.Click += new System.EventHandler(this.buttonPastCalcBFromBCalcB_Click);
            // 
            // buttonPastBFromBCalcB
            // 
            this.buttonPastBFromBCalcB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPastBFromBCalcB.Location = new System.Drawing.Point(3, 3);
            this.buttonPastBFromBCalcB.Name = "buttonPastBFromBCalcB";
            this.buttonPastBFromBCalcB.Size = new System.Drawing.Size(193, 28);
            this.buttonPastBFromBCalcB.TabIndex = 0;
            this.buttonPastBFromBCalcB.Text = "Вставить B (B=Calc(B))";
            this.buttonPastBFromBCalcB.UseVisualStyleBackColor = true;
            this.buttonPastBFromBCalcB.Click += new System.EventHandler(this.buttonPastBFromBCalcB_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tableLayoutPanel13);
            this.groupBox5.Location = new System.Drawing.Point(3, 635);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(419, 100);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Обмен с калькулятором";
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Controls.Add(this.buttonCalculatorImport, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.buttonCalculatorExport, 1, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(413, 67);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // buttonCalculatorImport
            // 
            this.buttonCalculatorImport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalculatorImport.Location = new System.Drawing.Point(3, 3);
            this.buttonCalculatorImport.Name = "buttonCalculatorImport";
            this.buttonCalculatorImport.Size = new System.Drawing.Size(200, 61);
            this.buttonCalculatorImport.TabIndex = 0;
            this.buttonCalculatorImport.Text = "Импорт";
            this.buttonCalculatorImport.UseVisualStyleBackColor = true;
            this.buttonCalculatorImport.Click += new System.EventHandler(this.buttonCalculatorImport_Click);
            // 
            // buttonCalculatorExport
            // 
            this.buttonCalculatorExport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalculatorExport.Location = new System.Drawing.Point(209, 3);
            this.buttonCalculatorExport.Name = "buttonCalculatorExport";
            this.buttonCalculatorExport.Size = new System.Drawing.Size(201, 61);
            this.buttonCalculatorExport.TabIndex = 1;
            this.buttonCalculatorExport.Text = "Экспорт";
            this.buttonCalculatorExport.UseVisualStyleBackColor = true;
            this.buttonCalculatorExport.Click += new System.EventHandler(this.buttonCalculatorExport_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.White;
            this.tabPage4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage4.Controls.Add(this.flowResize3);
            this.tabPage4.Location = new System.Drawing.Point(4, 33);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage4.Size = new System.Drawing.Size(464, 274);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Ввод B и расчёт A";
            // 
            // flowResize3
            // 
            this.flowResize3.AutoScroll = true;
            this.flowResize3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize3.Controls.Add(this.tableLayoutPanel4);
            this.flowResize3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize3.Location = new System.Drawing.Point(2, 2);
            this.flowResize3.Name = "flowResize3";
            this.flowResize3.Size = new System.Drawing.Size(456, 266);
            this.flowResize3.TabIndex = 0;
            this.flowResize3.WithDelta = 35;
            this.flowResize3.WrapContents = false;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel4.Controls.Add(this.textBoxBInput, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.textBoxAOutput, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.buttonBackSpace, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 2);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 4;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(421, 296);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // textBoxBInput
            // 
            this.textBoxBInput.AllowNegative = true;
            this.textBoxBInput.ClearingByReadonly = false;
            this.tableLayoutPanel4.SetColumnSpan(this.textBoxBInput, 2);
            this.textBoxBInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxBInput.EnterAllow = true;
            this.textBoxBInput.Location = new System.Drawing.Point(4, 4);
            this.textBoxBInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxBInput.MultiLine = false;
            this.textBoxBInput.Name = "textBoxBInput";
            this.textBoxBInput.NoReadOnly = true;
            this.textBoxBInput.ReadOnly = false;
            this.textBoxBInput.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxBInput.SelectionStart = 0;
            this.textBoxBInput.Size = new System.Drawing.Size(354, 78);
            this.textBoxBInput.TabIndex = 0;
            this.textBoxBInput.TextWithLineBreaks = "";
            this.textBoxBInput.Title = "B=";
            this.textBoxBInput.UseSystemPasswordChar = false;
            this.textBoxBInput.Value = "";
            this.textBoxBInput.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxBInput.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxBInput.ValueText = "";
            this.textBoxBInput.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxBInput.ValueWithLineBreaks = "";
            this.textBoxBInput.VisibleOK = false;
            this.textBoxBInput.ValueChanged += new TableAIS.TextValueChanged(this.textBoxBInput_ValueChanged);
            this.textBoxBInput.ValueKeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxB_ValueKeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 40);
            this.label1.TabIndex = 1;
            this.label1.Text = "A=";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxAOutput
            // 
            this.textBoxAOutput.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel4.SetColumnSpan(this.textBoxAOutput, 2);
            this.textBoxAOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxAOutput.Location = new System.Drawing.Point(56, 89);
            this.textBoxAOutput.Name = "textBoxAOutput";
            this.textBoxAOutput.ReadOnly = true;
            this.textBoxAOutput.Size = new System.Drawing.Size(362, 34);
            this.textBoxAOutput.TabIndex = 2;
            this.textBoxAOutput.TextWithLineBreaks = "";
            this.textBoxAOutput.Value = "";
            this.textBoxAOutput.ValueLinesChanged += new TableAIS.ValueLinesChanged(this.textBoxAOutput_ValueLinesChanged);
            // 
            // buttonBackSpace
            // 
            this.buttonBackSpace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBackSpace.Location = new System.Drawing.Point(365, 3);
            this.buttonBackSpace.Name = "buttonBackSpace";
            this.buttonBackSpace.Size = new System.Drawing.Size(53, 80);
            this.buttonBackSpace.TabIndex = 3;
            this.buttonBackSpace.Text = "<=";
            this.buttonBackSpace.UseVisualStyleBackColor = true;
            this.buttonBackSpace.Click += new System.EventHandler(this.buttonBackSpace_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel4.SetColumnSpan(this.tableLayoutPanel5, 3);
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.Controls.Add(this.button2, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.checkBoxAutoCalcInput, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.checkBoxEnterInput, 2, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 129);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(415, 47);
            this.tableLayoutPanel5.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Location = new System.Drawing.Point(3, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(132, 41);
            this.button2.TabIndex = 0;
            this.button2.Text = "Вычислить";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.buttonCalc_Click);
            // 
            // checkBoxAutoCalcInput
            // 
            this.checkBoxAutoCalcInput.AutoSize = true;
            this.checkBoxAutoCalcInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoCalcInput.Location = new System.Drawing.Point(141, 3);
            this.checkBoxAutoCalcInput.Name = "checkBoxAutoCalcInput";
            this.checkBoxAutoCalcInput.Size = new System.Drawing.Size(132, 41);
            this.checkBoxAutoCalcInput.TabIndex = 1;
            this.checkBoxAutoCalcInput.Text = "Автовычисление";
            this.checkBoxAutoCalcInput.UseVisualStyleBackColor = true;
            this.checkBoxAutoCalcInput.CheckedChanged += new System.EventHandler(this.checkBoxAutoCalcInput_CheckedChanged);
            // 
            // checkBoxEnterInput
            // 
            this.checkBoxEnterInput.AutoSize = true;
            this.checkBoxEnterInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxEnterInput.Location = new System.Drawing.Point(279, 3);
            this.checkBoxEnterInput.Name = "checkBoxEnterInput";
            this.checkBoxEnterInput.Size = new System.Drawing.Size(133, 41);
            this.checkBoxEnterInput.TabIndex = 2;
            this.checkBoxEnterInput.Text = "Вычисление по Enter";
            this.checkBoxEnterInput.UseVisualStyleBackColor = true;
            this.checkBoxEnterInput.CheckedChanged += new System.EventHandler(this.checkBoxEnterInput_CheckedChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage3.Controls.Add(this.flowResize2);
            this.tabPage3.Location = new System.Drawing.Point(4, 33);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(464, 274);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Настройки позиции";
            // 
            // flowResize2
            // 
            this.flowResize2.AutoScroll = true;
            this.flowResize2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize2.Controls.Add(this.buttonPositionDelete);
            this.flowResize2.Controls.Add(this.buttonPositionSave);
            this.flowResize2.Controls.Add(this.buttonPositionLoad);
            this.flowResize2.Controls.Add(this.menuStrip7);
            this.flowResize2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize2.Location = new System.Drawing.Point(3, 3);
            this.flowResize2.Margin = new System.Windows.Forms.Padding(5);
            this.flowResize2.Name = "flowResize2";
            this.flowResize2.Size = new System.Drawing.Size(454, 264);
            this.flowResize2.TabIndex = 0;
            this.flowResize2.WithDelta = 35;
            this.flowResize2.WrapContents = false;
            // 
            // buttonPositionDelete
            // 
            this.buttonPositionDelete.Location = new System.Drawing.Point(3, 3);
            this.buttonPositionDelete.Name = "buttonPositionDelete";
            this.buttonPositionDelete.Size = new System.Drawing.Size(419, 51);
            this.buttonPositionDelete.TabIndex = 0;
            this.buttonPositionDelete.Text = "Удалить позицию";
            this.buttonPositionDelete.UseVisualStyleBackColor = true;
            this.buttonPositionDelete.Click += new System.EventHandler(this.buttonPositionDelete_Click);
            // 
            // buttonPositionSave
            // 
            this.buttonPositionSave.Location = new System.Drawing.Point(3, 60);
            this.buttonPositionSave.Name = "buttonPositionSave";
            this.buttonPositionSave.Size = new System.Drawing.Size(419, 39);
            this.buttonPositionSave.TabIndex = 1;
            this.buttonPositionSave.Text = "Сохранить позицию в файл";
            this.buttonPositionSave.UseVisualStyleBackColor = true;
            this.buttonPositionSave.Click += new System.EventHandler(this.buttonPositionSave_Click);
            // 
            // buttonPositionLoad
            // 
            this.buttonPositionLoad.Location = new System.Drawing.Point(3, 105);
            this.buttonPositionLoad.Name = "buttonPositionLoad";
            this.buttonPositionLoad.Size = new System.Drawing.Size(419, 39);
            this.buttonPositionLoad.TabIndex = 2;
            this.buttonPositionLoad.Text = "Загрузить позицию из файла";
            this.buttonPositionLoad.UseVisualStyleBackColor = true;
            this.buttonPositionLoad.Click += new System.EventHandler(this.buttonPositionLoad_Click);
            // 
            // menuStrip7
            // 
            this.menuStrip7.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip7.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip7.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.обменСГлавнымЭкраномToolStripMenuItem});
            this.menuStrip7.Location = new System.Drawing.Point(0, 147);
            this.menuStrip7.Name = "menuStrip7";
            this.menuStrip7.Size = new System.Drawing.Size(425, 29);
            this.menuStrip7.TabIndex = 3;
            this.menuStrip7.Text = "menuStrip7";
            // 
            // обменСГлавнымЭкраномToolStripMenuItem
            // 
            this.обменСГлавнымЭкраномToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripJsonDropVariants,
            this.buttonJsonLastWindow,
            this.buttonJsonMainWindow,
            this.buttonJsonClipBoard});
            this.обменСГлавнымЭкраномToolStripMenuItem.Name = "обменСГлавнымЭкраномToolStripMenuItem";
            this.обменСГлавнымЭкраномToolStripMenuItem.Size = new System.Drawing.Size(133, 25);
            this.обменСГлавнымЭкраномToolStripMenuItem.Text = "Json-формат";
            // 
            // toolStripJsonDropVariants
            // 
            this.toolStripJsonDropVariants.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripJsonDropVariants.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.toolStripJsonDropVariants.Items.AddRange(new object[] {
            "Получить из",
            "Записать в"});
            this.toolStripJsonDropVariants.Name = "toolStripJsonDropVariants";
            this.toolStripJsonDropVariants.Size = new System.Drawing.Size(121, 29);
            // 
            // buttonJsonLastWindow
            // 
            this.buttonJsonLastWindow.Name = "buttonJsonLastWindow";
            this.buttonJsonLastWindow.Size = new System.Drawing.Size(262, 26);
            this.buttonJsonLastWindow.Text = "Предыдущий экран";
            this.buttonJsonLastWindow.Click += new System.EventHandler(this.buttonJsonLastWindow_Click);
            // 
            // buttonJsonMainWindow
            // 
            this.buttonJsonMainWindow.Name = "buttonJsonMainWindow";
            this.buttonJsonMainWindow.Size = new System.Drawing.Size(262, 26);
            this.buttonJsonMainWindow.Text = "Главный экран";
            this.buttonJsonMainWindow.Click += new System.EventHandler(this.buttonJsonMainWindow_Click);
            // 
            // buttonJsonClipBoard
            // 
            this.buttonJsonClipBoard.Name = "buttonJsonClipBoard";
            this.buttonJsonClipBoard.Size = new System.Drawing.Size(262, 26);
            this.buttonJsonClipBoard.Text = "Буфер обмена";
            this.buttonJsonClipBoard.Click += new System.EventHandler(this.buttonJsonClipBoard_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.White;
            this.tabPage5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage5.Controls.Add(this.flowResize4);
            this.tabPage5.Location = new System.Drawing.Point(4, 33);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage5.Size = new System.Drawing.Size(464, 274);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Обмен данными";
            // 
            // flowResize4
            // 
            this.flowResize4.AutoScroll = true;
            this.flowResize4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize4.Controls.Add(this.tableLayoutPanel6);
            this.flowResize4.Controls.Add(this.groupBox4);
            this.flowResize4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize4.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize4.Location = new System.Drawing.Point(5, 5);
            this.flowResize4.Name = "flowResize4";
            this.flowResize4.Size = new System.Drawing.Size(450, 260);
            this.flowResize4.TabIndex = 0;
            this.flowResize4.WithDelta = 35;
            this.flowResize4.WrapContents = false;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Controls.Add(this.groupBox3, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.groupBox2, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel11, 1, 1);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56.62337F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 43.37663F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(415, 385);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel10);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 220);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(201, 162);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Внешнее пространство";
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.radioButtonClipboard, 0, 4);
            this.tableLayoutPanel10.Controls.Add(this.radioButtonMain, 0, 3);
            this.tableLayoutPanel10.Controls.Add(this.radioButtonLast, 0, 2);
            this.tableLayoutPanel10.Controls.Add(this.radioButtonCalc, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 5;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(195, 129);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // radioButtonClipboard
            // 
            this.radioButtonClipboard.AutoSize = true;
            this.radioButtonClipboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonClipboard.Location = new System.Drawing.Point(3, 103);
            this.radioButtonClipboard.Name = "radioButtonClipboard";
            this.radioButtonClipboard.Size = new System.Drawing.Size(189, 23);
            this.radioButtonClipboard.TabIndex = 3;
            this.radioButtonClipboard.Text = "Буфер обмена";
            this.radioButtonClipboard.UseVisualStyleBackColor = true;
            // 
            // radioButtonMain
            // 
            this.radioButtonMain.AutoSize = true;
            this.radioButtonMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonMain.Location = new System.Drawing.Point(3, 78);
            this.radioButtonMain.Name = "radioButtonMain";
            this.radioButtonMain.Size = new System.Drawing.Size(189, 19);
            this.radioButtonMain.TabIndex = 2;
            this.radioButtonMain.Text = "Главный экран";
            this.radioButtonMain.UseVisualStyleBackColor = true;
            // 
            // radioButtonLast
            // 
            this.radioButtonLast.AutoSize = true;
            this.radioButtonLast.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonLast.Location = new System.Drawing.Point(3, 53);
            this.radioButtonLast.Name = "radioButtonLast";
            this.radioButtonLast.Size = new System.Drawing.Size(189, 19);
            this.radioButtonLast.TabIndex = 1;
            this.radioButtonLast.Text = "Предыдущий экран";
            this.radioButtonLast.UseVisualStyleBackColor = true;
            // 
            // radioButtonCalc
            // 
            this.radioButtonCalc.AutoSize = true;
            this.radioButtonCalc.Checked = true;
            this.radioButtonCalc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonCalc.Location = new System.Drawing.Point(3, 28);
            this.radioButtonCalc.Name = "radioButtonCalc";
            this.radioButtonCalc.Size = new System.Drawing.Size(189, 19);
            this.radioButtonCalc.TabIndex = 0;
            this.radioButtonCalc.TabStop = true;
            this.radioButtonCalc.Text = "Калькулятор";
            this.radioButtonCalc.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel9);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(210, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(202, 211);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Данные на калькуляторе";
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.radioButtonCalcHelp, 0, 5);
            this.tableLayoutPanel9.Controls.Add(this.radioButtonCalcBuffer, 0, 4);
            this.tableLayoutPanel9.Controls.Add(this.radioButtonCalcA, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.radioButtonCalcB, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.radioButtonValueB, 0, 3);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 6;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(196, 178);
            this.tableLayoutPanel9.TabIndex = 0;
            // 
            // radioButtonCalcHelp
            // 
            this.radioButtonCalcHelp.AutoSize = true;
            this.radioButtonCalcHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonCalcHelp.Location = new System.Drawing.Point(3, 148);
            this.radioButtonCalcHelp.Name = "radioButtonCalcHelp";
            this.radioButtonCalcHelp.Size = new System.Drawing.Size(190, 27);
            this.radioButtonCalcHelp.TabIndex = 3;
            this.radioButtonCalcHelp.Text = "Help";
            this.radioButtonCalcHelp.UseVisualStyleBackColor = true;
            // 
            // radioButtonCalcBuffer
            // 
            this.radioButtonCalcBuffer.AutoSize = true;
            this.radioButtonCalcBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonCalcBuffer.Location = new System.Drawing.Point(3, 119);
            this.radioButtonCalcBuffer.Name = "radioButtonCalcBuffer";
            this.radioButtonCalcBuffer.Size = new System.Drawing.Size(190, 23);
            this.radioButtonCalcBuffer.TabIndex = 2;
            this.radioButtonCalcBuffer.Text = "Buffer";
            this.radioButtonCalcBuffer.UseVisualStyleBackColor = true;
            // 
            // radioButtonCalcA
            // 
            this.radioButtonCalcA.AutoSize = true;
            this.radioButtonCalcA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonCalcA.Location = new System.Drawing.Point(3, 61);
            this.radioButtonCalcA.Name = "radioButtonCalcA";
            this.radioButtonCalcA.Size = new System.Drawing.Size(190, 23);
            this.radioButtonCalcA.TabIndex = 1;
            this.radioButtonCalcA.Text = "A";
            this.radioButtonCalcA.UseVisualStyleBackColor = true;
            // 
            // radioButtonCalcB
            // 
            this.radioButtonCalcB.AutoSize = true;
            this.radioButtonCalcB.Checked = true;
            this.radioButtonCalcB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonCalcB.Location = new System.Drawing.Point(3, 32);
            this.radioButtonCalcB.Name = "radioButtonCalcB";
            this.radioButtonCalcB.Size = new System.Drawing.Size(190, 23);
            this.radioButtonCalcB.TabIndex = 0;
            this.radioButtonCalcB.TabStop = true;
            this.radioButtonCalcB.Text = "B";
            this.radioButtonCalcB.UseVisualStyleBackColor = true;
            // 
            // radioButtonValueB
            // 
            this.radioButtonValueB.AutoSize = true;
            this.radioButtonValueB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonValueB.Location = new System.Drawing.Point(3, 90);
            this.radioButtonValueB.Name = "radioButtonValueB";
            this.radioButtonValueB.Size = new System.Drawing.Size(190, 23);
            this.radioButtonValueB.TabIndex = 4;
            this.radioButtonValueB.TabStop = true;
            this.radioButtonValueB.Text = "Значение B";
            this.radioButtonValueB.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel8);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(201, 211);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Локальные данные";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.radioButtonLocalBA, 0, 5);
            this.tableLayoutPanel8.Controls.Add(this.radioButtonLocalA, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.radioButtonLocalB, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.radioButtonLocalAB, 0, 4);
            this.tableLayoutPanel8.Controls.Add(this.radioButtonLocalValueB, 0, 3);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 6;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(195, 178);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // radioButtonLocalBA
            // 
            this.radioButtonLocalBA.AutoSize = true;
            this.radioButtonLocalBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonLocalBA.Location = new System.Drawing.Point(3, 148);
            this.radioButtonLocalBA.Name = "radioButtonLocalBA";
            this.radioButtonLocalBA.Size = new System.Drawing.Size(189, 27);
            this.radioButtonLocalBA.TabIndex = 3;
            this.radioButtonLocalBA.TabStop = true;
            this.radioButtonLocalBA.Text = "B=A";
            this.radioButtonLocalBA.UseVisualStyleBackColor = true;
            // 
            // radioButtonLocalA
            // 
            this.radioButtonLocalA.AutoSize = true;
            this.radioButtonLocalA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonLocalA.Location = new System.Drawing.Point(3, 61);
            this.radioButtonLocalA.Name = "radioButtonLocalA";
            this.radioButtonLocalA.Size = new System.Drawing.Size(189, 23);
            this.radioButtonLocalA.TabIndex = 1;
            this.radioButtonLocalA.Text = "A";
            this.radioButtonLocalA.UseVisualStyleBackColor = true;
            // 
            // radioButtonLocalB
            // 
            this.radioButtonLocalB.AutoSize = true;
            this.radioButtonLocalB.Checked = true;
            this.radioButtonLocalB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonLocalB.Location = new System.Drawing.Point(3, 32);
            this.radioButtonLocalB.Name = "radioButtonLocalB";
            this.radioButtonLocalB.Size = new System.Drawing.Size(189, 23);
            this.radioButtonLocalB.TabIndex = 0;
            this.radioButtonLocalB.TabStop = true;
            this.radioButtonLocalB.Text = "B";
            this.radioButtonLocalB.UseVisualStyleBackColor = true;
            // 
            // radioButtonLocalAB
            // 
            this.radioButtonLocalAB.AutoSize = true;
            this.radioButtonLocalAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonLocalAB.Location = new System.Drawing.Point(3, 119);
            this.radioButtonLocalAB.Name = "radioButtonLocalAB";
            this.radioButtonLocalAB.Size = new System.Drawing.Size(189, 23);
            this.radioButtonLocalAB.TabIndex = 2;
            this.radioButtonLocalAB.TabStop = true;
            this.radioButtonLocalAB.Text = "A=B";
            this.radioButtonLocalAB.UseVisualStyleBackColor = true;
            // 
            // radioButtonLocalValueB
            // 
            this.radioButtonLocalValueB.AutoSize = true;
            this.radioButtonLocalValueB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonLocalValueB.Location = new System.Drawing.Point(3, 90);
            this.radioButtonLocalValueB.Name = "radioButtonLocalValueB";
            this.radioButtonLocalValueB.Size = new System.Drawing.Size(189, 23);
            this.radioButtonLocalValueB.TabIndex = 4;
            this.radioButtonLocalValueB.TabStop = true;
            this.radioButtonLocalValueB.Text = "Значение B";
            this.radioButtonLocalValueB.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.buttonLoad, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.buttonSave, 0, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(210, 220);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(202, 162);
            this.tableLayoutPanel11.TabIndex = 3;
            // 
            // buttonLoad
            // 
            this.buttonLoad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLoad.Location = new System.Drawing.Point(3, 84);
            this.buttonLoad.Name = "buttonLoad";
            this.buttonLoad.Size = new System.Drawing.Size(196, 75);
            this.buttonLoad.TabIndex = 1;
            this.buttonLoad.Text = "Загрузить (Импортировать)";
            this.buttonLoad.UseVisualStyleBackColor = true;
            this.buttonLoad.Click += new System.EventHandler(this.buttonLoad_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSave.Location = new System.Drawing.Point(3, 3);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(196, 75);
            this.buttonSave.TabIndex = 0;
            this.buttonSave.Text = "Сохранить (Экспортировать)";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tableLayoutPanel12);
            this.groupBox4.Location = new System.Drawing.Point(3, 394);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(415, 140);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Заданные значения";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Controls.Add(this.textBoxCalc, 1, 1);
            this.tableLayoutPanel12.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.textBoxLocal, 1, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(409, 107);
            this.tableLayoutPanel12.TabIndex = 0;
            // 
            // textBoxCalc
            // 
            this.textBoxCalc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxCalc.Location = new System.Drawing.Point(143, 56);
            this.textBoxCalc.Name = "textBoxCalc";
            this.textBoxCalc.Size = new System.Drawing.Size(263, 34);
            this.textBoxCalc.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(3, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 54);
            this.label4.TabIndex = 1;
            this.label4.Text = "На калькуляторе";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 53);
            this.label3.TabIndex = 0;
            this.label3.Text = "Локальное";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxLocal
            // 
            this.textBoxLocal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxLocal.Location = new System.Drawing.Point(143, 3);
            this.textBoxLocal.Name = "textBoxLocal";
            this.textBoxLocal.Size = new System.Drawing.Size(263, 34);
            this.textBoxLocal.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 33);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(464, 274);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(301, 49);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(478, 22);
            this.button1.TabIndex = 3;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41096F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58904F));
            this.tableLayoutPanel7.Controls.Add(this.textBoxCount, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(292, 40);
            this.tableLayoutPanel7.TabIndex = 4;
            // 
            // textBoxCount
            // 
            this.textBoxCount.BackColor = System.Drawing.Color.White;
            this.textBoxCount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxCount.Location = new System.Drawing.Point(194, 3);
            this.textBoxCount.Name = "textBoxCount";
            this.textBoxCount.ReadOnly = true;
            this.textBoxCount.Size = new System.Drawing.Size(95, 34);
            this.textBoxCount.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 40);
            this.label2.TabIndex = 1;
            this.label2.Text = "Общее количество";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // timerPos
            // 
            this.timerPos.Enabled = true;
            this.timerPos.Tick += new System.EventHandler(this.timerPos_Tick);
            // 
            // timerUpdate
            // 
            this.timerUpdate.Enabled = true;
            this.timerUpdate.Interval = 15000;
            this.timerUpdate.Tick += new System.EventHandler(this.timerUpdate_Tick);
            // 
            // openFileCalculator
            // 
            this.openFileCalculator.FileName = "openFileDialog1";
            // 
            // ListCalculatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(782, 553);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "ListCalculatorForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Калькулятор-список";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBoxPos.ResumeLayout(false);
            this.tabControlPos.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.flowResize1.ResumeLayout(false);
            this.flowResize1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.groupBoxCorrectB.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.tableLayoutCalc.ResumeLayout(false);
            this.tableLayoutCalc.PerformLayout();
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.tableLayoutPanel18.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.flowResize3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.flowResize2.ResumeLayout(false);
            this.flowResize2.PerformLayout();
            this.menuStrip7.ResumeLayout(false);
            this.menuStrip7.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.flowResize4.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ListBox listBoxCalculatePositions;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem buttonUpdate2;
        private System.Windows.Forms.GroupBox groupBoxPos;
        public System.Windows.Forms.Timer timerPos;
        private System.Windows.Forms.Timer timerUpdate;
        private System.Windows.Forms.TabControl tabControlPos;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private FlowResize flowResize1;
        private TextBoxWithTitle textBoxB;
        private TextBoxWithTitle textBoxA;
        private System.Windows.Forms.TableLayoutPanel tableLayoutCalc;
        private System.Windows.Forms.Button buttonCalc;
        private System.Windows.Forms.CheckBox checkBoxAutoCalc;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonCreate;
        private System.Windows.Forms.CheckBox checkBoxEnter;
        private System.Windows.Forms.TabPage tabPage3;
        private FlowResize flowResize2;
        private System.Windows.Forms.Button buttonPositionDelete;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private TextBoxWithTitle textBoxBInput;
        private FlowResize flowResize3;
        private System.Windows.Forms.Label label1;
        private TextBoxWithLine textBoxAOutput;
        private System.Windows.Forms.Button buttonBackSpace;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBoxAutoCalcInput;
        private System.Windows.Forms.CheckBox checkBoxEnterInput;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TextBox textBoxCount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.RadioButton radioButtonLocalA;
        private System.Windows.Forms.RadioButton radioButtonLocalB;
        private FlowResize flowResize4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.RadioButton radioButtonCalcA;
        private System.Windows.Forms.RadioButton radioButtonCalcB;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.RadioButton radioButtonClipboard;
        private System.Windows.Forms.RadioButton radioButtonMain;
        private System.Windows.Forms.RadioButton radioButtonLast;
        private System.Windows.Forms.RadioButton radioButtonCalc;
        private System.Windows.Forms.RadioButton radioButtonCalcHelp;
        private System.Windows.Forms.RadioButton radioButtonCalcBuffer;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.RadioButton radioButtonLocalAB;
        private System.Windows.Forms.RadioButton radioButtonLocalBA;
        private System.Windows.Forms.Button buttonLoad;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxLocal;
        private System.Windows.Forms.TextBox textBoxCalc;
        private System.Windows.Forms.CheckBox checkBoxCalcView;
        private System.Windows.Forms.Button buttonPositionSave;
        private System.Windows.Forms.SaveFileDialog saveFileCalculator;
        private System.Windows.Forms.Button buttonPositionLoad;
        private System.Windows.Forms.OpenFileDialog openFileCalculator;
        private System.Windows.Forms.ToolStripMenuItem buttonAddPositionByFile;
        private System.Windows.Forms.ToolStripMenuItem списокИФайлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcListExport;
        private System.Windows.Forms.ToolStripMenuItem импортироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcImportCalc;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcListImportSet;
        private System.Windows.Forms.MenuStrip menuStrip7;
        private System.Windows.Forms.ToolStripMenuItem обменСГлавнымЭкраномToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripJsonDropVariants;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonLastWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonMainWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonClipBoard;
        private System.Windows.Forms.ToolStripMenuItem изJsonпредставленияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddJsonLastWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonAddJsonByMainWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonAddJsonByClipBoard;
        private System.Windows.Forms.ToolStripMenuItem buttonAddCopyChoosePosition;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button buttonAddFeatcher;
        private System.Windows.Forms.ToolStripMenuItem buttonAddPosByCalculator;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Button buttonCalculatorImport;
        private System.Windows.Forms.Button buttonCalculatorExport;
        private System.Windows.Forms.GroupBox groupBoxCorrectB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Button buttonAddBaskets;
        private System.Windows.Forms.Button buttonChangeBaskets;
        private System.Windows.Forms.Button buttonDropBaskets;
        private System.Windows.Forms.CheckBox checkBoxCorreectB;
        private System.Windows.Forms.ToolStripMenuItem buttonUpdate;
        private System.Windows.Forms.ToolStripMenuItem buttonClear;
        private System.Windows.Forms.ToolStripMenuItem buttonDeletePos;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcListExportFile;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcImportCalcFile;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcListImportSetFile;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcListExportLastWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcListExportMainWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcListExportClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcImportCalcLastWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcImportCalcMainWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcImportCalcClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcListImportSetLastWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcListImportSetMainWindow;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcListImportSetClipboard;
        private System.Windows.Forms.Button buttonCalcB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.CheckBox checkBoxFlagsView;
        private System.Windows.Forms.CheckBox checkBoxAutoCalcA;
        private System.Windows.Forms.Button buttonCopyAB;
        private System.Windows.Forms.RadioButton radioButtonLocalValueB;
        private System.Windows.Forms.RadioButton radioButtonValueB;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem раскрытьКомпонентыФормулыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenVariable;
        private System.Windows.Forms.ToolStripMenuItem buttonOpenConst;
        private System.Windows.Forms.ToolStripMenuItem buttonDropVariable;
        private System.Windows.Forms.Button buttonInteractiveEditPos;
        private System.Windows.Forms.ToolStripMenuItem buttonAddCopyChoosePositionWithAToB;
        private System.Windows.Forms.ToolStripMenuItem buttonAddCopyChoosePositionWithCalcBToB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Button buttonPastCalcBFromBCalcB;
        private System.Windows.Forms.Button buttonPastBFromBCalcB;
        private System.Windows.Forms.Button buttonCopyBCalcB;
        private System.Windows.Forms.Button button4;
    }
}