﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using static System.Net.Mime.MediaTypeNames;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class ListCalculatorForm : Form
    {

        int JsonDropVariantIndex
        {
            get
            {
                return toolStripJsonDropVariants.SelectedIndex;
            }
            set
            {
                toolStripJsonDropVariants.SelectedIndex = value;
            }
        }


        public event Func<double> GetA, GetB, GetBuffer, GetHelp;
        public event Action<double> SetA, SetB, SetBuffer, SetHelp;
        public event Func<string> GetFormuleB, GetFormuleHelp;
        public event Action<string> SetFormuleB, SetFormuleHelp;

        public event Action<string> GetByJson;
        public event Func<string> SetByJson;


        public event Func<string> SetFromMain;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public event Func<string> SetNumberFromMain;

        PositionCalculate positionCalculate;



        public string SetNumberFromMainInvoke()
        {
            return SetNumberFromMain?.Invoke()??"";
        }


        public ListCalculatorForm()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;


        }

        public ListCalculator ListCalculator => ValueHelper.ListCalculator; 

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            autoChange = false;
            try
            {
                ListCalculator.GetFewVariables = () =>
                {
                    try
                    {
                        return new FewVariables(FormuleB, A, Buffer, FormuleHelp);
                    }
                    catch
                    {
                        return null;
                    }
                };
            }
            catch { }

            try
            {
                int index = listBoxCalculatePositions.SelectedIndex;

                listBoxCalculatePositions.Items.Clear();

                listBoxCalculatePositions.Items.AddRange(ListCalculator.ToArray());
                index = Math.Max(Math.Min(index, listBoxCalculatePositions.Items.Count - 1), 0);
                try
                {
                    listBoxCalculatePositions.SelectedIndex = index;
                }
                catch { }
            }
            catch
            {

            }
            autoChange = true;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public ListCalculatorForm(Save save):this()
        {
            Save = save;
        }

        public ListCalculatorForm(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();



            autoChange = true;
            buttonUpdate_Click(sender, e);
        }

        string Extended
        {
            get
            {
                if(radioButtonCalc.Checked)
                {
                    return ExtendedCalc;
                }
                if(radioButtonLast.Checked)
                {
                    return FromLast();
                }
                if(radioButtonMain.Checked)
                {
                    return FromMain();
                }
                return FromClipboard();

            }
            set
            {
                string text = value;
                if(radioButtonCalc.Checked)
                {
                    ExtendedCalc = text;
                }
                else if(radioButtonLast.Checked)
                {
                    SaveV(text);
                }
                else if(radioButtonMain.Checked)
                {
                    WriteMain(text);
                }
                else
                {
                    WriteToClipboard(text);
                }

            }
        }


        public void SaveV(string text)
        {
            try
            {
                MetrOutput1?.Invoke(text, Save);
            }
            catch
            {

            }
        }

        public void WriteMain(string text)
        {
            try
            {
                ValueHelper.SetText(text);
            }
            catch { }
        }

        void WriteToClipboard(string text)
        {
            try
            {
                Clipboard.SetText(text);
            }
            catch { }
        }


        string FromLast()
        {
            try
            {
                return SetNumberFromMain?.Invoke();
            }
            catch
            {
                return "";
            }
        }

        string FromMain()
        {
            return ValueHelper.GetText();
        }

        string FromClipboard()
        {
            try
            {
                return Clipboard.GetText();
            }
            catch
            {
                return "";
            }
        }


        string ExtendedCalc
        {
            get
            {
                try
                {
                    if (radioButtonCalcA.Checked)
                        return A;
                    if (radioButtonCalcB.Checked)
                        return FormuleB;
                    if (radioButtonCalcBuffer.Checked)
                        return Buffer;
                    if (radioButtonValueB.Checked)
                        return B;
                    return FormuleHelp;
                }
                catch
                {
                    return "";
                }
            }
            set
            {
                try
                {
                    string text = value;
                    if (radioButtonCalcA.Checked)
                    {
                        A = text;
                    }
                    else if (radioButtonCalcB.Checked)
                    {
                        FormuleB = text;
                    }
                    else if (radioButtonCalcBuffer.Checked)
                    {
                        Buffer = text;
                    }
                    else if (radioButtonCalcHelp.Checked)
                    {
                        FormuleHelp = text;
                    }
                }
                catch { }
            }
        }

        public string PositionPart
        {
            get
            {
                if(radioButtonLocalA.Checked)
                {
                    return textBoxA.Value;
                }
                else if(radioButtonLocalB.Checked)
                {
                    return textBoxB.Value;
                }
                else if(radioButtonLocalValueB.Checked)
                {
                    return positionCalculate.CalculateWithFew(textBoxB.Value);
                }
                else if(radioButtonLocalAB.Checked)
                {
                    return textBoxA.Value + " = "+textBoxB.Value;
                }
                else
                {
                    return textBoxB.Value + " = " + textBoxA.Value;
                }
            }
            set
            {
                if (radioButtonLocalValueB.Checked)
                {
                    textBoxB.Value = positionCalculate.CalculateWithFew(value);
                }
                if ( radioButtonLocalA.Checked)
                {
                    textBoxA.Value = positionCalculate.CalculateWithFew(value);
                }
                else if(radioButtonLocalB.Checked)
                {
                    textBoxB.Value = value;
                }
            }
        }

        private void timerPos_Tick(object sender, EventArgs e)
        {
            try
            {
                groupBoxPos.Visible = listBoxCalculatePositions.SelectedIndex >= 0;
            }
            catch { }

            try
            {
                positionCalculate.AutoReact = false;
            }
            catch { }

            try
            {
                //if (positionCalculate.AutoReact)
                {
                    textBoxA.Value = positionCalculate.A.ToString();
                }
            }
            catch { }

            try
            {
                checkBoxAutoCalc.Checked = positionCalculate.AutoCalculate;
            }
            catch { }

            try
            {
                checkBoxEnter.Checked = positionCalculate.EnterCalculate;
            }
            catch { }

            try
            {
                positionCalculate.AutoReact = true;
            }
            catch { }

            try
            {
                textBoxCount.Text = ListCalculator.Count.ToString();
            }
            catch
            {

            }

            try
            {
                textBoxLocal.Text = PositionPart;
            }
            catch
            { }

            try
            {
                textBoxCalc.Text = ExtendedCalc;
            }
            catch { }

            tableLayoutCalc.Visible = checkBoxCalcView.Checked;
            groupBoxCorrectB.Visible = checkBoxCorreectB.Checked;

            checkBoxCalcView.Visible = checkBoxFlagsView.Checked;
            checkBoxCorreectB.Visible = checkBoxFlagsView.Checked;
            checkBoxAutoCalcA.Checked = checkBoxAutoCalc.Checked;
        }

        private void timerUpdate_Tick(object sender, EventArgs e)
        {
            buttonUpdate_Click(sender, e);
            try
            {
                
            }
            catch
            {

            }
        }


        bool autoChange;

        private void listBoxCalculatePositions_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            try
            {
                positionCalculate = (PositionCalculate)listBoxCalculatePositions.SelectedItem;
                positionCalculate.AutoReact = false;
                try
                {
                    textBoxB.Value = positionCalculate.B;
                }
                catch { }

                try
                {
                    textBoxA.Value = positionCalculate.A.ToString();
                }
                catch { }


                try
                {
                    checkBoxAutoCalc.Checked = positionCalculate.AutoCalc;
                }
                catch { }


                positionCalculate.AutoReact = true;


            }
            catch { }
            if(autoChange)
            {
                tabControlPos.SelectedIndex = 0;
            }
        }

        PositionCalculate GetPosition() => listBoxCalculatePositions.SelectedItem as PositionCalculate;

        private void textBoxB_ValueChanged(Control control, EventArgs e, string value)
        {
            try
            {
                positionCalculate.SetB(value);
            }
            catch { }

            try
            {
                textBoxBInput.Value = value;
            }
            catch
            {

            }
        }

        private void textBoxA_ValueChanged(Control control, EventArgs e, string value)
        {
            try
            {
                if (positionCalculate.AutoReact)
                    positionCalculate.A = value;
            }
            catch { }

            try
            {
                textBoxAOutput.Value = value;
            }
            catch { }
        }

        private void buttonCalc_Click(object sender, EventArgs e)
        {
            try
            {
                positionCalculate.CalculateB();
            }
            catch { }
        }

        private void checkBoxAutoCalc_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if(positionCalculate.AutoReact)
                {
                    positionCalculate.AutoCalculate = checkBoxAutoCalc.Checked;
                }
            }
            catch { }

            try
            {
                checkBoxAutoCalcInput.Checked = checkBoxAutoCalc.Checked;
            }
            catch { }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            try
            {
                ListCalculator.Clear();
                
            }
            catch { }

            buttonUpdate_Click(sender, e);
        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.Add();
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;
            }
            catch { }
        }

        private void checkBoxEnter_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                positionCalculate.EnterCalculate = checkBoxEnter.Checked;
            }
            catch { }

            try
            {
                checkBoxEnterInput.Checked = checkBoxEnter.Checked;
            }
            catch { }
        }

        private void textBoxB_ValueKeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                try
                {
                    if (positionCalculate.EnterCalculate)
                        positionCalculate.CalculateB();
                }
                catch { }
            }
        }

        private void buttonPositionDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ListCalculator.RemoveAt(listBoxCalculatePositions.SelectedIndex);
            }
            catch { }

            try
            {
                buttonUpdate_Click(sender, e);
            }
            catch { }

            tabControlPos.SelectedIndex = 0;
        }

        private void groupBoxPos_VisibleChanged(object sender, EventArgs e)
        {
            try
            {
                tabControlPos.SelectedIndex = 0;
            }
            catch { }
        }

        private void textBoxBInput_ValueChanged(Control control, EventArgs e, string value)
        {
            try
            {
                textBoxB.Value = value;
            }
            catch { }
        }

        private void textBoxAOutput_ValueLinesChanged(object sender, EventArgs e, Control control, string text, string textWithLineBreaks)
        {
            try
            {
                textBoxA.Value = textWithLineBreaks;
            }
            catch { }
        }

        private void buttonBackSpace_Click(object sender, EventArgs e)
        {
            try
            {
                string b = textBoxBInput.Value;
                int length = b.Length - 1;
                textBoxBInput.Value = b.Substring(0, length);
            }
            catch { }
        }

        private void checkBoxAutoCalcInput_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                checkBoxAutoCalc.Checked = checkBoxAutoCalcInput.Checked;
            }
            catch { }
        }

        private void checkBoxEnterInput_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                checkBoxEnter.Checked = checkBoxEnterInput.Checked;
            }
            catch { }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                Extended = PositionPart;
            }
            catch { }
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            try
            {
                PositionPart = Extended;
            }
            catch { }
        }

        private void buttonPositionSave_Click(object sender, EventArgs e)
        {
            try
            {
                saveFileCalculator.Filter = positionCalculate.FileFilter;
                DialogResult result = saveFileCalculator.ShowDialog();
                if(result != DialogResult.OK)
                {
                    return;
                }
                positionCalculate.ToFile(saveFileCalculator.FileName);

                MessageBox.Show("Позиция в калькуляторе успешно сохранена в файл \n" + saveFileCalculator.FileName, "Сохранение позиции в файл", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось сохранить позицию в калькуляторе в файл", "Сохранение позиции в файл", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void buttonPositionLoad_Click(object sender, EventArgs e)
        {
            try
            {
                openFileCalculator.Filter = positionCalculate.FileFilter;
                DialogResult result = openFileCalculator.ShowDialog();
                openFileCalculator.Multiselect = false;
                if (result != DialogResult.OK)
                {
                    return;
                }
                positionCalculate.SetByFile(openFileCalculator.FileName);

                MessageBox.Show("Позиция в калькуляторе успешно загружена из файла \n" + openFileCalculator.FileName, "Загрузка позиции из файла", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось загрузить позицию в калькуляторе из файла", "Загрузка позиции из файла", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void buttonAddPositionByFile_Click(object sender, EventArgs e)
        {
            try
            {
                openFileCalculator.Filter = PositionCalculate.GetFilter();
                openFileCalculator.Multiselect = true;
                DialogResult result = openFileCalculator.ShowDialog();
                if (result != DialogResult.OK)
                {
                    return;
                }

                string[] fileNames = openFileCalculator.FileNames;

                for (int i = 0; i < fileNames.Length; i++)
                {
                    int index = ListCalculator.AddByFile(fileNames[i]);
                    buttonUpdate_Click(sender, e);
                    listBoxCalculatePositions.SelectedIndex = index;
                }

                MessageBox.Show("Позиции в калькуляторе успешно загружены из файлов \n \"" + string.Join("\" \"", fileNames)+"\"", "Загрузка позиции из файла", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось загрузить позицию в калькуляторе из файла", "Загрузка позиции из файла", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void buttonCalcListExport_Click(object sender, EventArgs e)
        {
            try
            {
                saveFileCalculator.Filter = ListCalculator.FileFilter;
                DialogResult result = saveFileCalculator.ShowDialog();
                if (result != DialogResult.OK)
                {
                    return;
                }
                ListCalculator.ToFile(saveFileCalculator.FileName);

                MessageBox.Show("Список позиций в калькуляторе успешно сохранён в файл \n" + saveFileCalculator.FileName, "Сохранение списка позиций в файл", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось сохранить список позиций в калькуляторе в файл", "Сохранение списка позиций в файл", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void buttonCalcImportCalc_Click(object sender, EventArgs e)
        {
            try
            {
                openFileCalculator.Filter = ListCalculator.GetFilter();
                openFileCalculator.Multiselect = true;
                DialogResult result = openFileCalculator.ShowDialog();
                if (result != DialogResult.OK)
                {
                    return;
                }

                string[] fileNames = openFileCalculator.FileNames;


                int index = ListCalculator.AddArrayByFile(fileNames);
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;


                MessageBox.Show("Позиции в калькуляторе успешно загружены из файлов \n \"" + string.Join("\" \"", fileNames) + "\"", "Загрузка позиции из файла", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось загрузить позицию в калькуляторе из файла", "Загрузка позиции из файла", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void buttonCalcListImportSet_Click(object sender, EventArgs e)
        {
            try
            {
                openFileCalculator.Filter = ListCalculator.GetFilter();
                openFileCalculator.Multiselect = true;
                DialogResult result = openFileCalculator.ShowDialog();
                if (result != DialogResult.OK)
                {
                    return;
                }

                string[] fileNames = openFileCalculator.FileNames;


                int index = ListCalculator.SetByFile(fileNames);
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;


                MessageBox.Show("Позиции в калькуляторе успешно загружены из файлов \n \"" + string.Join("\" \"", fileNames) + "\"", "Загрузка позиции из файла", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось загрузить позицию в калькуляторе из файла", "Загрузка позиции из файла", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void tabControlPos_SelectedIndexChanged(object sender, EventArgs e)
        {

            JsonDropVariantIndex = 0;
        }

        private void buttonJsonLastWindow_Click(object sender, EventArgs e)
        {
            try
            {

                if (JsonDropVariantIndex == 0)
                {
                    //PositionCalculate positionCalculate = new PositionCalculate();
                    positionCalculate.SetJson(SetNumberFromMain?.Invoke());

                }
                else if (JsonDropVariantIndex == 1)
                {
                    
                    MetrOutput1?.Invoke(positionCalculate.GetJsonText(), Save.None);
                }
            }
            catch { }
        }

        private void buttonJsonMainWindow_Click(object sender, EventArgs e)
        {

            try
            {

                if (JsonDropVariantIndex == 0)
                {
                    //PositionCalculate positionCalculate = new PositionCalculate();
                    positionCalculate.SetJson(ValueHelper.GetText());

                }
                else if (JsonDropVariantIndex == 1)
                {
                   
                    ValueHelper.SetText(positionCalculate.GetJsonText());
                }
            }
            catch { }
        }

        private void buttonJsonClipBoard_Click(object sender, EventArgs e)
        {
            try
            {

                if (JsonDropVariantIndex == 0)
                {
                    //PositionCalculate positionCalculate = new PositionCalculate();
                    positionCalculate.SetJson(Clipboard.GetText());

                }
                else if (JsonDropVariantIndex == 1)
                {
                   
                    Clipboard.SetText(positionCalculate.GetJsonText());
                }
            }
            catch { }
        }

        private void buttonAddJsonLastWindow_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.AddByJson(SetNumberFromMain?.Invoke());
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonAddJsonByMainWindow_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.AddByJson(ValueHelper.GetText());
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonAddJsonByClipBoard_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.AddByJson(Clipboard.GetText());
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonAddCopyChoosePosition_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.AddCopyByIndex(listBoxCalculatePositions.SelectedIndex);
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;
            }
            catch { }

        }

        private void buttonAddFeatcher_Click(object sender, EventArgs e)
        {
            FeachersList form = new FeachersList();
            form.InputFunc += Form_InputFunc;
            form.MetrOutput1 += MetrOutput1;

            form.Show();
        }

        private void Form_InputFunc(string obj)
        {
            try
            {
                textBoxB.Value += obj;
            }
            catch { }
        }

        private void buttonAddPosByCalculator_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.AddByJson(SetByJson?.Invoke());
                UpdatePositions();
                listBoxCalculatePositions.SelectedIndex = index;

            }
            catch { }
        }

        public void UpdatePositions()
        {
            try
            {

                buttonUpdate_Click(buttonUpdate2, new EventArgs());
            }
            catch { }
        }

        private void buttonCalculatorImport_Click(object sender, EventArgs e)
        {
            try
            {
                positionCalculate.SetJson(SetByJson?.Invoke());
                UpdatePositions();
            }
            catch { }
        }

        private void buttonCalculatorExport_Click(object sender, EventArgs e)
        {
            try
            {
                GetByJson?.Invoke(positionCalculate.GetJsonText());
                UpdatePositions();
            }
            catch { }
        }

        private void buttonAddBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                positionCalculate = positionCalculate.AddBaskets();
                UpdatePositions();
            }
            catch { }
        }

        public void ShowMessageCorrectB(PositionCalculate positionCalculate, Control control)
        {
            ShowMessage($"Значение B исправлено на {positionCalculate.B}", control);
        }

        public void ShowMessage(string message, Control control)
        {
            try
            {
                System.Windows.Forms.Help.ShowPopup(control, message, new Point(Left + control.Left + 100, Top + control.Top + 100));
            }
            catch { }
            
        }

        private void buttonChangeBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                positionCalculate = positionCalculate.ChangeBaskets();
                UpdatePositions();
            }
            catch { }
        }

        private void buttonDropBaskets_Click(object sender, EventArgs e)
        {
            try
            {
                positionCalculate = positionCalculate.DropBaskets();
                UpdatePositions();
            }
            catch { }
        }

        private void buttonDropVariable_Click(object sender, EventArgs e)
        {
            try
            {
                positionCalculate = positionCalculate.DropVariables();
                UpdatePositions();
            }
            catch { }
        }

        private void buttonCalcListExportLastWindow_Click(object sender, EventArgs e)
        {
            try
            {
                MetrOutput1?.Invoke(ListCalculator.ToJsonArrayText(), Save);
            }
            catch { }
        }

        private void buttonCalcListExportMainWindow_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(ListCalculator.ToJsonArrayText());
            }
            catch { }

        }

        private void buttonCalcListExportClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(ListCalculator.ToJsonArrayText());
            }
            catch { }

        }

        private void buttonCalcImportCalcLastWindow_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.AddArrayByJson(SetNumberFromMain?.Invoke());
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;
            }
            catch { }

        }

        private void buttonCalcImportCalcMainWindow_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.AddArrayByJson(ValueHelper.GetText());
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonCalcImportCalcClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.AddArrayByJson(Clipboard.GetText());
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonCalcListImportSetLastWindow_Click(object sender, EventArgs e)
        {
            try
            {

                int index = ListCalculator.SetByJson(SetNumberFromMain?.Invoke());
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;

            }
            catch { }
        }

        private void buttonCalcListImportSetMainWindow_Click(object sender, EventArgs e)
        {
            try
            {

                int index = ListCalculator.SetByJson(ValueHelper.GetText());
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;

            }
            catch { }
        }

        private void buttonCalcListImportSetClipboard_Click(object sender, EventArgs e)
        {
            try
            {

                int index = ListCalculator.SetByJson(Clipboard.GetText());
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;

            }
            catch { }
        }

        private void buttonCalcB_Click(object sender, EventArgs e)
        {
            try
            {
                positionCalculate.CalculateToB();
                textBoxB.Value = positionCalculate.B;
            }
            catch { }   
        }

        private void checkBoxAutoCalcA_CheckedChanged(object sender, EventArgs e)
        {
            checkBoxAutoCalc.Checked = (sender as CheckBox).Checked;
        }

        private void buttonCopyAB_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxB.Value = positionCalculate.CopyAB().B;
            }
            catch { }
        }

        private void buttonOpenConst_Click(object sender, EventArgs e)
        {
            try
            {
                positionCalculate = positionCalculate.OpenConsts();
                UpdatePositions();
            }
            catch { }
        }

        private void buttonOpenVariable_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    positionCalculate = positionCalculate.OpenVariables();
                    UpdatePositions();
                }
                catch { }
            }
            catch { }
        }

        private void buttonInteractiveEditPos_Click(object sender, EventArgs e)
        {
            FormulePartsForm formuleParts = new FormulePartsForm();
            formuleParts.ReloadFormuleParts += FormuleParts_ReloadFormuleParts;
            formuleParts.GetFormule += FormuleParts_GetFormule;
            formuleParts.UpdateFewFormule += FormuleParts_UpdateFewFormule;

            formuleParts.GetA += FormuleParts_GetA;
            formuleParts.GetFewA += FormuleParts_GetFewA; ;

            formuleParts.GetB += FormuleParts_GetB;
            formuleParts.GetFewB += FormuleParts_GetFewB; ;

            formuleParts.GetBuffer += FormuleParts_GetBuffer;
            formuleParts.GetFewBuffer += FormuleParts_GetFewBuffer; ;

            formuleParts.GetHelp += FormuleParts_GetHelp;
            formuleParts.GetFewHelp += FormuleParts_GetFewHelp; ;

            formuleParts.Show();
        }

        private string FormuleParts_GetFewHelp()
        {
            return GetPosition().GetFewVariables?.Invoke().Help;
        }

        private string FormuleParts_GetFewBuffer()
        {
            return GetPosition().GetFewVariables?.Invoke().Buffer;
        }

        private string FormuleParts_GetFewB()
        {
            return GetPosition().GetFewVariables?.Invoke().B;
        }

        private string FormuleParts_GetFewA()
        {
            return GetPosition().GetFewVariables?.Invoke().A;
        }
        

        private string FormuleParts_GetHelp()
        {
            return "0";
        }

        private string FormuleParts_GetBuffer()
        {
            return "0";
        }

        private string FormuleParts_GetB()
        {
            return textBoxB.Value;
        }

        private string FormuleParts_GetA()
        {
            return textBoxA.Value;
        }

        private void FormuleParts_UpdateFewFormule(string obj)
        {
            try
            {
                textBoxB.Value = obj;
            }
            catch { }
        }

        private string FormuleParts_GetFormule()
        {
            try
            {
                return textBoxB.Value;
            }
            catch
            {
                return "";
            }
        }

        private FormulePartList FormuleParts_ReloadFormuleParts()
        {
            try
            {
                return MyCalculate.ReplaceToFullFuncsCodeInteractive(textBoxB.Value);
            }
            catch
            {
                return new FormulePartList();
            }

        }

        private void buttonAddCopyChoosePositionWithAToB_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.AddCopyByIndexWithAToB(listBoxCalculatePositions.SelectedIndex);
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonAddCopyChoosePositionWithCalcBToB_Click(object sender, EventArgs e)
        {
            try
            {
                int index = ListCalculator.AddCopyByIndexWithCalcBToB(listBoxCalculatePositions.SelectedIndex);
                buttonUpdate_Click(sender, e);
                listBoxCalculatePositions.SelectedIndex = index;
            }
            catch { }
        }

        private void buttonCopyBCalcB_Click(object sender, EventArgs e)
        {
            try
            {
                string b = positionCalculate.B;
                string calcB = positionCalculate.CalculateInteractiveB().ToString();
                TableAIS.Buffer.CalculatetionCopy = new CalculatePositionCopy(b, calcB);
            }
            catch
            {

            }
        }

        private void buttonPastBFromBCalcB_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxB.Value = TableAIS.Buffer.GetCalculatetionCopy().B;
            }
            catch { }
        }

        private void buttonPastCalcBFromBCalcB_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxB.Value = TableAIS.Buffer.GetCalculatetionCopy().A;
            }
            catch { }
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }


        string FormuleB
        {
            get
            {
                try
                {
                    return GetFormuleB?.Invoke();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {
                try
                {
                    SetFormuleB?.Invoke(value);
                }
                catch { }
            }
        }

        string FormuleHelp
        {
            get
            {
                try
                {
                    return GetFormuleHelp?.Invoke();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {
                try
                {
                    SetFormuleHelp?.Invoke(value);
                }
                catch { }
            }
        }

        string B
        {
            get
            {
                try
                {
                    return (GetB?.Invoke() ?? 0).ToString();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {
                string formule = value;
                double number = 0;

                try
                {
                    try
                    {
                        number = MyCalculate.ToDouble(formule);
                    }
                    catch
                    {
                        number = positionCalculate.CalculateByThis(formule);
                    }
                    SetB?.Invoke(number);
                }
                catch
                {

                }
                return;
                try
                {
                    SetB?.Invoke(double.Parse(value));
                }
                catch { }
            }
        }

        string A
        {
            get
            {
                try
                {
                    return (GetA?.Invoke() ?? 0).ToString();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {
                string formule = value;
                double number = 0;

                try
                {
                    try
                    {
                        number = MyCalculate.ToDouble(formule);
                    }
                    catch
                    {
                        number = positionCalculate.CalculateByThis(formule);
                    }
                    SetA?.Invoke(number);
                }
                catch
                {

                }
                return;

                try
                {
                    SetA?.Invoke(MyCalculate.ToDouble(formule));
                }
                catch 
                {
                    try
                    {
                        SetA?.Invoke(positionCalculate.CalculateByThis(formule));
                    }
                    catch
                    {

                    }
                }
            }
        }

        string Buffer
        {
            get
            {
                try
                {
                    return (GetBuffer?.Invoke() ?? 0).ToString();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {

                string formule = value;
                double number = 0;

                try
                {
                    try
                    {
                        number = MyCalculate.ToDouble(formule);
                    }
                    catch
                    {
                        number = positionCalculate.CalculateByThis(formule);
                    }
                    SetBuffer?.Invoke(number);
                }
                catch
                {

                }
                return;

                try
                {
                    SetBuffer?.Invoke(double.Parse(value));
                }
                catch { }
            }
        }

        string Help
        {
            get
            {
                try
                {
                    return (GetHelp?.Invoke() ?? 0).ToString();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {


                string formule = value;
                double number = 0;

                try
                {
                    try
                    {
                        number = MyCalculate.ToDouble(formule);
                    }
                    catch
                    {
                        number = positionCalculate.CalculateByThis(formule);
                    }
                    SetHelp?.Invoke(number);
                }
                catch
                {

                }
                return;

                try
                {
                    SetHelp?.Invoke(double.Parse(value));
                }
                catch { }
            }
        }


        double Calculate(string formule)
        {
            try
            {
                try
                {
                    return double.Parse(formule.Replace('.', ','));
                }
                catch
                {
                    try
                    {
                        return double.Parse(formule.Replace(',', '.'));
                    }
                    catch
                    {
                        return MyCalculate.CalculateWithB(formule, A, Buffer, Help, B);
                    }
                }
            }
            catch
            {
                return 0.0;
            }
        }

    }
}
