﻿namespace TableAIS
{
    partial class ProcessListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProcessListForm));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.listBoxProcess = new System.Windows.Forms.ListBox();
            this.timerProcess = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.labelName = new System.Windows.Forms.Label();
            this.labelProcess = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonSend = new System.Windows.Forms.Button();
            this.textBoxProcessAddress = new TableAIS.TextBoxWithTitle();
            this.textBoxSendMessage = new TableAIS.TextBoxWithTitle();
            this.textBoxReciveMessage = new TableAIS.TextBoxWithTitle();
            this.timerReciveMessage = new System.Windows.Forms.Timer(this.components);
            this.buttonStartProcess = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(530, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(223, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(782, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel18, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(778, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 504);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(782, 23);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.textBoxReciveMessage, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.19277F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.80723F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(782, 415);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // listBoxProcess
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.listBoxProcess, 2);
            this.listBoxProcess.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxProcess.FormattingEnabled = true;
            this.listBoxProcess.ItemHeight = 21;
            this.listBoxProcess.Location = new System.Drawing.Point(3, 53);
            this.listBoxProcess.Name = "listBoxProcess";
            this.listBoxProcess.Size = new System.Drawing.Size(379, 221);
            this.listBoxProcess.TabIndex = 0;
            this.listBoxProcess.SelectedIndexChanged += new System.EventHandler(this.listBoxProcess_SelectedIndexChanged);
            // 
            // timerProcess
            // 
            this.timerProcess.Enabled = true;
            this.timerProcess.Interval = 15000;
            this.timerProcess.Tick += new System.EventHandler(this.timerProcess_Tick);
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 1;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Controls.Add(this.labelName, 0, 0);
            this.tableLayoutPanel18.Controls.Add(this.labelProcess, 0, 1);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(89, 3);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 2;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(413, 80);
            this.tableLayoutPanel18.TabIndex = 2;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(3, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(407, 59);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Обмен через разделяемую память";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelProcess
            // 
            this.labelProcess.AutoSize = true;
            this.labelProcess.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelProcess.Location = new System.Drawing.Point(3, 59);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new System.Drawing.Size(407, 21);
            this.labelProcess.TabIndex = 2;
            this.labelProcess.Text = "TableAIS";
            this.labelProcess.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.listBoxProcess, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonStartProcess, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(385, 277);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(3, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(186, 44);
            this.button1.TabIndex = 1;
            this.button1.Text = "Обновить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.timerProcess_Tick);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.textBoxProcessAddress, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.buttonSend, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.textBoxSendMessage, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(394, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 3;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 92F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(385, 277);
            this.tableLayoutPanel4.TabIndex = 2;
            // 
            // buttonSend
            // 
            this.buttonSend.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSend.Location = new System.Drawing.Point(3, 247);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(379, 27);
            this.buttonSend.TabIndex = 1;
            this.buttonSend.Text = "Отправить";
            this.buttonSend.UseVisualStyleBackColor = true;
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // textBoxProcessAddress
            // 
            this.textBoxProcessAddress.AllowNegative = true;
            this.textBoxProcessAddress.ClearingByReadonly = false;
            this.textBoxProcessAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxProcessAddress.EnterAllow = true;
            this.textBoxProcessAddress.Location = new System.Drawing.Point(4, 4);
            this.textBoxProcessAddress.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxProcessAddress.MultiLine = false;
            this.textBoxProcessAddress.Name = "textBoxProcessAddress";
            this.textBoxProcessAddress.NoReadOnly = true;
            this.textBoxProcessAddress.ReadOnly = false;
            this.textBoxProcessAddress.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxProcessAddress.SelectionStart = 0;
            this.textBoxProcessAddress.Size = new System.Drawing.Size(377, 84);
            this.textBoxProcessAddress.TabIndex = 0;
            this.textBoxProcessAddress.TextWithLineBreaks = "";
            this.textBoxProcessAddress.Title = "Приложение";
            this.textBoxProcessAddress.UseSystemPasswordChar = false;
            this.textBoxProcessAddress.Value = "";
            this.textBoxProcessAddress.ValueBackColor = System.Drawing.Color.White;
            this.textBoxProcessAddress.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxProcessAddress.ValueText = "";
            this.textBoxProcessAddress.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxProcessAddress.ValueWithLineBreaks = "";
            this.textBoxProcessAddress.VisibleOK = false;
            // 
            // textBoxSendMessage
            // 
            this.textBoxSendMessage.AllowNegative = true;
            this.textBoxSendMessage.ClearingByReadonly = false;
            this.textBoxSendMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxSendMessage.EnterAllow = true;
            this.textBoxSendMessage.Location = new System.Drawing.Point(4, 96);
            this.textBoxSendMessage.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSendMessage.MultiLine = true;
            this.textBoxSendMessage.Name = "textBoxSendMessage";
            this.textBoxSendMessage.NoReadOnly = true;
            this.textBoxSendMessage.ReadOnly = false;
            this.textBoxSendMessage.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxSendMessage.SelectionStart = 0;
            this.textBoxSendMessage.Size = new System.Drawing.Size(377, 144);
            this.textBoxSendMessage.TabIndex = 2;
            this.textBoxSendMessage.TextWithLineBreaks = "";
            this.textBoxSendMessage.Title = "Сообщение";
            this.textBoxSendMessage.UseSystemPasswordChar = false;
            this.textBoxSendMessage.Value = "";
            this.textBoxSendMessage.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxSendMessage.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxSendMessage.ValueText = "";
            this.textBoxSendMessage.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxSendMessage.ValueWithLineBreaks = "";
            this.textBoxSendMessage.VisibleOK = false;
            // 
            // textBoxReciveMessage
            // 
            this.textBoxReciveMessage.AllowNegative = true;
            this.textBoxReciveMessage.ClearingByReadonly = true;
            this.textBoxReciveMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxReciveMessage.EnterAllow = true;
            this.textBoxReciveMessage.Location = new System.Drawing.Point(4, 287);
            this.textBoxReciveMessage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxReciveMessage.MultiLine = true;
            this.textBoxReciveMessage.Name = "textBoxReciveMessage";
            this.textBoxReciveMessage.NoReadOnly = false;
            this.textBoxReciveMessage.ReadOnly = true;
            this.textBoxReciveMessage.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxReciveMessage.SelectionStart = 0;
            this.textBoxReciveMessage.Size = new System.Drawing.Size(383, 124);
            this.textBoxReciveMessage.TabIndex = 3;
            this.textBoxReciveMessage.TextWithLineBreaks = "";
            this.textBoxReciveMessage.Title = "Полученное сообщение";
            this.textBoxReciveMessage.UseSystemPasswordChar = false;
            this.textBoxReciveMessage.Value = "";
            this.textBoxReciveMessage.ValueBackColor = System.Drawing.Color.White;
            this.textBoxReciveMessage.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxReciveMessage.ValueText = "";
            this.textBoxReciveMessage.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxReciveMessage.ValueWithLineBreaks = "";
            this.textBoxReciveMessage.VisibleOK = false;
            // 
            // timerReciveMessage
            // 
            this.timerReciveMessage.Enabled = true;
            this.timerReciveMessage.Tick += new System.EventHandler(this.timerReciveMessage_Tick);
            // 
            // buttonStartProcess
            // 
            this.buttonStartProcess.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonStartProcess.Location = new System.Drawing.Point(195, 3);
            this.buttonStartProcess.Name = "buttonStartProcess";
            this.buttonStartProcess.Size = new System.Drawing.Size(187, 44);
            this.buttonStartProcess.TabIndex = 2;
            this.buttonStartProcess.Text = "Запустить ещё";
            this.buttonStartProcess.UseVisualStyleBackColor = true;
            this.buttonStartProcess.Click += new System.EventHandler(this.buttonStartProcess_Click);
            // 
            // ProcessListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(782, 553);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "ProcessListForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Обмен через разделяемую память";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel18.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ListBox listBoxProcess;
        private System.Windows.Forms.Timer timerProcess;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelProcess;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private TextBoxWithTitle textBoxProcessAddress;
        private System.Windows.Forms.Button buttonSend;
        private TextBoxWithTitle textBoxSendMessage;
        private TextBoxWithTitle textBoxReciveMessage;
        private System.Windows.Forms.Timer timerReciveMessage;
        private System.Windows.Forms.Button buttonStartProcess;
    }
}