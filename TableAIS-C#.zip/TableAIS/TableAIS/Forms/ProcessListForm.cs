﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Windows.Foundation;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class ProcessListForm : Form
    {


        public event Func<string> SetFromMain;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public event Func<string> SetNumberFromMain;

        public string SetNumberFromMainInvoke()
        {
            return SetNumberFromMain?.Invoke()??"";
        }


        public ProcessListForm()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public ProcessListForm(Save save):this()
        {
            Save = save;
        }

        public ProcessListForm(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            try
            {
                labelProcess.Text = ProcessInfo.NowProcessInfo.ToString();
            }
            catch { }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

            message = "";

            try
            {
                listBoxProcess.Items.AddRange(ProcessInfo.ProcessList.ToArray());
            }
            catch { }
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void timerProcess_Tick(object sender, EventArgs e)
        {
            try
            {
                listBoxProcess.Items.Clear();
                listBoxProcess.Items.AddRange(ProcessInfo.ProcessList.ToArray());
            }
            catch { }
        }

        private void listBoxProcess_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                textBoxProcessAddress.Value = (sender as ListBox).SelectedItem.ToString();
            }
            catch { }
        }

        MemoryMappedFile sharedMemory;

        private void buttonSend_Click(object sender, EventArgs e)
        {
            string title = "Отправка сообщения";
            try
            {
                string message = textBoxSendMessage.Value;
                int size = message.Length;
                string name = textBoxProcessAddress.Value;
                if(name.Length < 1)
                {
                    MessageBox.Show("Выберите процесс из списка", title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                sharedMemory = MemoryMappedFile.CreateOrOpen(name, size * 2 + 4);
                using (MemoryMappedViewAccessor writer = sharedMemory.CreateViewAccessor(0, size * 2 + 4))
                {
                    char[] symwols = message.ToCharArray();
                    //запись в разделяемую память
                    //запись размера с нулевого байта в разделяемой памяти
                    writer.Write(0, size);
                    //запись сообщения с четвертого байта в разделяемой памяти
                    writer.WriteArray<char>(4, symwols, 0, message.Length);
                    writer.Dispose();
                }
                MessageBox.Show("Сообщение успешно отправлено", title, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch 
            { 
                MessageBox.Show("Не удалось отправить сообщение", title, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            try
            {
                sharedMemory.Dispose();
            }
            catch { }

            try
            {
                File.Delete(textBoxProcessAddress.Value);
            }
            catch { }


            try
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            catch { }
        }

        private void timerReciveMessage_Tick(object sender, EventArgs e)
        {
            try
            {
                string name = labelProcess.Text;

                MemoryMappedFile sharedMemory = MemoryMappedFile.OpenExisting(name);
                int size = 0;

                
                using (MemoryMappedViewAccessor reader = sharedMemory.CreateViewAccessor(0, 4, MemoryMappedFileAccess.Read))
                {
                    size = reader.ReadInt32(0);
                }
                char[] message = new char[size];

                using (MemoryMappedViewAccessor reader = sharedMemory.CreateViewAccessor(4, size * 2, MemoryMappedFileAccess.Read))
                {
                    //Массив символов сообщения
                    reader.ReadArray<char>(0, message, 0, size);
                }

                textBoxReciveMessage.Value = new string(message);

                sharedMemory.Dispose();

            }
            catch { }

            try
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            catch { }
        }

        string message;

        private void buttonStartProcess_Click(object sender, EventArgs e)
        {
            try
            {
                Process process = Process.Start(Application.ExecutablePath);
                timerProcess_Tick(sender, e);
            }
            catch { }
        }
    }
}
