﻿namespace TableAIS
{
    partial class ReplaceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReplaceForm));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxFrom = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxTo = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBoxText = new System.Windows.Forms.TextBox();
            this.flowResize1 = new TableAIS.FlowResize();
            this.buttonReplace = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonAllText = new System.Windows.Forms.RadioButton();
            this.radioButtonSelectedText = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonFrom = new System.Windows.Forms.RadioButton();
            this.radioButtonTo = new System.Windows.Forms.RadioButton();
            this.radioButtonValue = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonRunStart = new System.Windows.Forms.RadioButton();
            this.radioButtonRunEnd = new System.Windows.Forms.RadioButton();
            this.radioButtonRunText = new System.Windows.Forms.RadioButton();
            this.flowResize2 = new TableAIS.FlowResize();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.задатьСимволToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetSpace = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetEnter = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetTab = new System.Windows.Forms.ToolStripMenuItem();
            this.символToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetSqrt = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetSqrt1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetPI = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClear = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ввестиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetByStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetByClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetByValue = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetBySelectedValue = new System.Windows.Forms.ToolStripMenuItem();
            this.весьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.начальныйТекстToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetBySelectedFrom = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetByFrom = new System.Windows.Forms.ToolStripMenuItem();
            this.начальныйТексToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetBySelectedTo = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetByTo = new System.Windows.Forms.ToolStripMenuItem();
            this.записатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.flowResize1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.flowResize2.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(530, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(223, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(782, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(778, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(413, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 504);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(782, 23);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox3, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.flowResize1, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.flowResize2, 1, 2);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(782, 415);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxFrom);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(385, 132);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Начальный текст";
            // 
            // textBoxFrom
            // 
            this.textBoxFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFrom.Location = new System.Drawing.Point(3, 30);
            this.textBoxFrom.Multiline = true;
            this.textBoxFrom.Name = "textBoxFrom";
            this.textBoxFrom.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxFrom.Size = new System.Drawing.Size(379, 99);
            this.textBoxFrom.TabIndex = 0;
            this.textBoxFrom.TextChanged += new System.EventHandler(this.textBoxFrom_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxTo);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(394, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(385, 132);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Сменить на (Конечный текст)";
            // 
            // textBoxTo
            // 
            this.textBoxTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxTo.Location = new System.Drawing.Point(3, 30);
            this.textBoxTo.Multiline = true;
            this.textBoxTo.Name = "textBoxTo";
            this.textBoxTo.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxTo.Size = new System.Drawing.Size(379, 99);
            this.textBoxTo.TabIndex = 1;
            this.textBoxTo.TextChanged += new System.EventHandler(this.textBoxTo_TextChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBoxText);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 141);
            this.groupBox3.Name = "groupBox3";
            this.tableLayoutPanel2.SetRowSpan(this.groupBox3, 2);
            this.groupBox3.Size = new System.Drawing.Size(385, 271);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Исходный текст";
            // 
            // textBoxText
            // 
            this.textBoxText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxText.Location = new System.Drawing.Point(3, 30);
            this.textBoxText.Multiline = true;
            this.textBoxText.Name = "textBoxText";
            this.textBoxText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxText.Size = new System.Drawing.Size(379, 238);
            this.textBoxText.TabIndex = 0;
            this.textBoxText.TextChanged += new System.EventHandler(this.textBoxText_TextChanged);
            // 
            // flowResize1
            // 
            this.flowResize1.AutoScroll = true;
            this.flowResize1.Controls.Add(this.buttonReplace);
            this.flowResize1.Controls.Add(this.groupBox4);
            this.flowResize1.Controls.Add(this.groupBox5);
            this.flowResize1.Controls.Add(this.groupBox6);
            this.flowResize1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize1.Location = new System.Drawing.Point(394, 141);
            this.flowResize1.Name = "flowResize1";
            this.flowResize1.Size = new System.Drawing.Size(385, 132);
            this.flowResize1.TabIndex = 3;
            this.flowResize1.WithDelta = 35;
            this.flowResize1.WrapContents = false;
            // 
            // buttonReplace
            // 
            this.buttonReplace.Location = new System.Drawing.Point(3, 3);
            this.buttonReplace.Name = "buttonReplace";
            this.buttonReplace.Size = new System.Drawing.Size(350, 33);
            this.buttonReplace.TabIndex = 0;
            this.buttonReplace.Text = "Заменить";
            this.buttonReplace.UseVisualStyleBackColor = true;
            this.buttonReplace.Click += new System.EventHandler(this.buttonReplace_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tableLayoutPanel3);
            this.groupBox4.Location = new System.Drawing.Point(3, 42);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(350, 100);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Фрагментная обработка и вывод";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.radioButtonAllText, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.radioButtonSelectedText, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(344, 67);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // radioButtonAllText
            // 
            this.radioButtonAllText.AutoSize = true;
            this.radioButtonAllText.Checked = true;
            this.radioButtonAllText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonAllText.Location = new System.Drawing.Point(3, 3);
            this.radioButtonAllText.Name = "radioButtonAllText";
            this.radioButtonAllText.Size = new System.Drawing.Size(166, 27);
            this.radioButtonAllText.TabIndex = 0;
            this.radioButtonAllText.TabStop = true;
            this.radioButtonAllText.Text = "Весь текст";
            this.radioButtonAllText.UseVisualStyleBackColor = true;
            // 
            // radioButtonSelectedText
            // 
            this.radioButtonSelectedText.AutoSize = true;
            this.radioButtonSelectedText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonSelectedText.Location = new System.Drawing.Point(175, 3);
            this.radioButtonSelectedText.Name = "radioButtonSelectedText";
            this.radioButtonSelectedText.Size = new System.Drawing.Size(166, 27);
            this.radioButtonSelectedText.TabIndex = 1;
            this.radioButtonSelectedText.Text = "Выделенный текст";
            this.radioButtonSelectedText.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tableLayoutPanel4);
            this.groupBox5.Location = new System.Drawing.Point(3, 148);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(350, 100);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Место обработки";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.radioButtonFrom, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.radioButtonTo, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.radioButtonValue, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(344, 67);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // radioButtonFrom
            // 
            this.radioButtonFrom.AutoSize = true;
            this.radioButtonFrom.Checked = true;
            this.radioButtonFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonFrom.Location = new System.Drawing.Point(3, 3);
            this.radioButtonFrom.Name = "radioButtonFrom";
            this.radioButtonFrom.Size = new System.Drawing.Size(166, 27);
            this.radioButtonFrom.TabIndex = 0;
            this.radioButtonFrom.TabStop = true;
            this.radioButtonFrom.Text = "Начальный текст";
            this.radioButtonFrom.UseVisualStyleBackColor = true;
            // 
            // radioButtonTo
            // 
            this.radioButtonTo.AutoSize = true;
            this.radioButtonTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonTo.Location = new System.Drawing.Point(175, 3);
            this.radioButtonTo.Name = "radioButtonTo";
            this.radioButtonTo.Size = new System.Drawing.Size(166, 27);
            this.radioButtonTo.TabIndex = 1;
            this.radioButtonTo.TabStop = true;
            this.radioButtonTo.Text = "Конечный текст";
            this.radioButtonTo.UseVisualStyleBackColor = true;
            // 
            // radioButtonValue
            // 
            this.radioButtonValue.AutoSize = true;
            this.radioButtonValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonValue.Location = new System.Drawing.Point(3, 36);
            this.radioButtonValue.Name = "radioButtonValue";
            this.radioButtonValue.Size = new System.Drawing.Size(166, 28);
            this.radioButtonValue.TabIndex = 2;
            this.radioButtonValue.TabStop = true;
            this.radioButtonValue.Text = "Исходный текст";
            this.radioButtonValue.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.tableLayoutPanel5);
            this.groupBox6.Location = new System.Drawing.Point(3, 254);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(350, 100);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Способ подстановки текста";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.radioButtonRunStart, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.radioButtonRunEnd, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.radioButtonRunText, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(344, 67);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // radioButtonRunStart
            // 
            this.radioButtonRunStart.AutoSize = true;
            this.radioButtonRunStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonRunStart.Location = new System.Drawing.Point(3, 36);
            this.radioButtonRunStart.Name = "radioButtonRunStart";
            this.radioButtonRunStart.Size = new System.Drawing.Size(166, 28);
            this.radioButtonRunStart.TabIndex = 2;
            this.radioButtonRunStart.Text = "В начале текста";
            this.radioButtonRunStart.UseVisualStyleBackColor = true;
            // 
            // radioButtonRunEnd
            // 
            this.radioButtonRunEnd.AutoSize = true;
            this.radioButtonRunEnd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonRunEnd.Location = new System.Drawing.Point(175, 3);
            this.radioButtonRunEnd.Name = "radioButtonRunEnd";
            this.radioButtonRunEnd.Size = new System.Drawing.Size(166, 27);
            this.radioButtonRunEnd.TabIndex = 1;
            this.radioButtonRunEnd.Text = "В конце текста";
            this.radioButtonRunEnd.UseVisualStyleBackColor = true;
            // 
            // radioButtonRunText
            // 
            this.radioButtonRunText.AutoSize = true;
            this.radioButtonRunText.Checked = true;
            this.radioButtonRunText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonRunText.Location = new System.Drawing.Point(3, 3);
            this.radioButtonRunText.Name = "radioButtonRunText";
            this.radioButtonRunText.Size = new System.Drawing.Size(166, 27);
            this.radioButtonRunText.TabIndex = 0;
            this.radioButtonRunText.TabStop = true;
            this.radioButtonRunText.Text = "Вместо текста";
            this.radioButtonRunText.UseVisualStyleBackColor = true;
            // 
            // flowResize2
            // 
            this.flowResize2.AutoScroll = true;
            this.flowResize2.Controls.Add(this.menuStrip2);
            this.flowResize2.Controls.Add(this.menuStrip1);
            this.flowResize2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize2.Location = new System.Drawing.Point(394, 279);
            this.flowResize2.Name = "flowResize2";
            this.flowResize2.Size = new System.Drawing.Size(385, 133);
            this.flowResize2.TabIndex = 4;
            this.flowResize2.WithDelta = 35;
            this.flowResize2.WrapContents = false;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.задатьСимволToolStripMenuItem,
            this.buttonClear});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(276, 30);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // задатьСимволToolStripMenuItem
            // 
            this.задатьСимволToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetSpace,
            this.buttonSetEnter,
            this.buttonSetTab,
            this.символToolStripMenuItem});
            this.задатьСимволToolStripMenuItem.Name = "задатьСимволToolStripMenuItem";
            this.задатьСимволToolStripMenuItem.Size = new System.Drawing.Size(164, 26);
            this.задатьСимволToolStripMenuItem.Text = "Вставить символ";
            // 
            // buttonSetSpace
            // 
            this.buttonSetSpace.Name = "buttonSetSpace";
            this.buttonSetSpace.Size = new System.Drawing.Size(323, 26);
            this.buttonSetSpace.Text = "Пробел";
            this.buttonSetSpace.Click += new System.EventHandler(this.buttonSetSpace_Click);
            // 
            // buttonSetEnter
            // 
            this.buttonSetEnter.Name = "buttonSetEnter";
            this.buttonSetEnter.Size = new System.Drawing.Size(323, 26);
            this.buttonSetEnter.Text = "Перенос на другую строку";
            this.buttonSetEnter.Click += new System.EventHandler(this.buttonSetEnter_Click);
            // 
            // buttonSetTab
            // 
            this.buttonSetTab.Name = "buttonSetTab";
            this.buttonSetTab.Size = new System.Drawing.Size(323, 26);
            this.buttonSetTab.Text = "Табуляция";
            this.buttonSetTab.Click += new System.EventHandler(this.buttonSetTab_Click);
            // 
            // символToolStripMenuItem
            // 
            this.символToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetSqrt,
            this.buttonSetSqrt1,
            this.buttonSetPI});
            this.символToolStripMenuItem.Name = "символToolStripMenuItem";
            this.символToolStripMenuItem.Size = new System.Drawing.Size(323, 26);
            this.символToolStripMenuItem.Text = "Символ";
            // 
            // buttonSetSqrt
            // 
            this.buttonSetSqrt.Name = "buttonSetSqrt";
            this.buttonSetSqrt.Size = new System.Drawing.Size(108, 26);
            this.buttonSetSqrt.Text = "√";
            this.buttonSetSqrt.Click += new System.EventHandler(this.buttonSetSqrt_Click);
            // 
            // buttonSetSqrt1
            // 
            this.buttonSetSqrt1.Name = "buttonSetSqrt1";
            this.buttonSetSqrt1.Size = new System.Drawing.Size(108, 26);
            this.buttonSetSqrt1.Text = "✓";
            this.buttonSetSqrt1.Click += new System.EventHandler(this.buttonSetSqrt1_Click);
            // 
            // buttonSetPI
            // 
            this.buttonSetPI.Name = "buttonSetPI";
            this.buttonSetPI.Size = new System.Drawing.Size(108, 26);
            this.buttonSetPI.Text = "π";
            this.buttonSetPI.Click += new System.EventHandler(this.buttonSetPI_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(102, 26);
            this.buttonClear.Text = "Очистить";
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ввестиToolStripMenuItem,
            this.записатьToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 30);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(276, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ввестиToolStripMenuItem
            // 
            this.ввестиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetByStart,
            this.buttonSetMain,
            this.buttonSetByClipboard,
            this.buttonSetByValue,
            this.начальныйТекстToolStripMenuItem,
            this.начальныйТексToolStripMenuItem});
            this.ввестиToolStripMenuItem.Name = "ввестиToolStripMenuItem";
            this.ввестиToolStripMenuItem.Size = new System.Drawing.Size(81, 26);
            this.ввестиToolStripMenuItem.Text = "Ввести";
            // 
            // buttonSetByStart
            // 
            this.buttonSetByStart.Name = "buttonSetByStart";
            this.buttonSetByStart.Size = new System.Drawing.Size(293, 26);
            this.buttonSetByStart.Text = "С предыдущего экрана";
            this.buttonSetByStart.Click += new System.EventHandler(this.buttonSetByStart_Click);
            // 
            // buttonSetMain
            // 
            this.buttonSetMain.Name = "buttonSetMain";
            this.buttonSetMain.Size = new System.Drawing.Size(293, 26);
            this.buttonSetMain.Text = "С главного экрана";
            this.buttonSetMain.Click += new System.EventHandler(this.buttonSetMain_Click);
            // 
            // buttonSetByClipboard
            // 
            this.buttonSetByClipboard.Name = "buttonSetByClipboard";
            this.buttonSetByClipboard.Size = new System.Drawing.Size(293, 26);
            this.buttonSetByClipboard.Text = "Из буфера обмена";
            this.buttonSetByClipboard.Click += new System.EventHandler(this.buttonSetByClipboard_Click);
            // 
            // buttonSetByValue
            // 
            this.buttonSetByValue.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetBySelectedValue,
            this.весьToolStripMenuItem});
            this.buttonSetByValue.Name = "buttonSetByValue";
            this.buttonSetByValue.Size = new System.Drawing.Size(293, 26);
            this.buttonSetByValue.Text = "Исходный текст";
            // 
            // buttonSetBySelectedValue
            // 
            this.buttonSetBySelectedValue.Name = "buttonSetBySelectedValue";
            this.buttonSetBySelectedValue.Size = new System.Drawing.Size(202, 26);
            this.buttonSetBySelectedValue.Text = "Выделенный";
            this.buttonSetBySelectedValue.Click += new System.EventHandler(this.buttonSetBySelectedValue_Click);
            // 
            // весьToolStripMenuItem
            // 
            this.весьToolStripMenuItem.Name = "весьToolStripMenuItem";
            this.весьToolStripMenuItem.Size = new System.Drawing.Size(202, 26);
            this.весьToolStripMenuItem.Text = "Весь";
            this.весьToolStripMenuItem.Click += new System.EventHandler(this.buttonSetByValue_Click);
            // 
            // начальныйТекстToolStripMenuItem
            // 
            this.начальныйТекстToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetBySelectedFrom,
            this.buttonSetByFrom});
            this.начальныйТекстToolStripMenuItem.Name = "начальныйТекстToolStripMenuItem";
            this.начальныйТекстToolStripMenuItem.Size = new System.Drawing.Size(293, 26);
            this.начальныйТекстToolStripMenuItem.Text = "Начальный текст";
            // 
            // buttonSetBySelectedFrom
            // 
            this.buttonSetBySelectedFrom.Name = "buttonSetBySelectedFrom";
            this.buttonSetBySelectedFrom.Size = new System.Drawing.Size(202, 26);
            this.buttonSetBySelectedFrom.Text = "Выделенный";
            this.buttonSetBySelectedFrom.Click += new System.EventHandler(this.buttonSetBySelectedFrom_Click);
            // 
            // buttonSetByFrom
            // 
            this.buttonSetByFrom.Name = "buttonSetByFrom";
            this.buttonSetByFrom.Size = new System.Drawing.Size(202, 26);
            this.buttonSetByFrom.Text = "Весь";
            this.buttonSetByFrom.Click += new System.EventHandler(this.buttonSetByFrom_Click);
            // 
            // начальныйТексToolStripMenuItem
            // 
            this.начальныйТексToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetBySelectedTo,
            this.buttonSetByTo});
            this.начальныйТексToolStripMenuItem.Name = "начальныйТексToolStripMenuItem";
            this.начальныйТексToolStripMenuItem.Size = new System.Drawing.Size(293, 26);
            this.начальныйТексToolStripMenuItem.Text = "\"Сменить на\"";
            // 
            // buttonSetBySelectedTo
            // 
            this.buttonSetBySelectedTo.Name = "buttonSetBySelectedTo";
            this.buttonSetBySelectedTo.Size = new System.Drawing.Size(202, 26);
            this.buttonSetBySelectedTo.Text = "Выделенный";
            this.buttonSetBySelectedTo.Click += new System.EventHandler(this.buttonSetBySelectedTo_Click);
            // 
            // buttonSetByTo
            // 
            this.buttonSetByTo.Name = "buttonSetByTo";
            this.buttonSetByTo.Size = new System.Drawing.Size(202, 26);
            this.buttonSetByTo.Text = "Весь";
            this.buttonSetByTo.Click += new System.EventHandler(this.buttonSetByTo_Click);
            // 
            // записатьToolStripMenuItem
            // 
            this.записатьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToStart,
            this.buttonToMain,
            this.buttonToClipboard});
            this.записатьToolStripMenuItem.Name = "записатьToolStripMenuItem";
            this.записатьToolStripMenuItem.Size = new System.Drawing.Size(99, 26);
            this.записатьToolStripMenuItem.Text = "Записать";
            // 
            // buttonToStart
            // 
            this.buttonToStart.Name = "buttonToStart";
            this.buttonToStart.Size = new System.Drawing.Size(287, 26);
            this.buttonToStart.Text = "На предыдущий экран";
            this.buttonToStart.Click += new System.EventHandler(this.buttonToStart_Click);
            // 
            // buttonToMain
            // 
            this.buttonToMain.Name = "buttonToMain";
            this.buttonToMain.Size = new System.Drawing.Size(287, 26);
            this.buttonToMain.Text = "На главный экран";
            this.buttonToMain.Click += new System.EventHandler(this.buttonToMain_Click);
            // 
            // buttonToClipboard
            // 
            this.buttonToClipboard.Name = "buttonToClipboard";
            this.buttonToClipboard.Size = new System.Drawing.Size(287, 26);
            this.buttonToClipboard.Text = "В буфер обмена";
            this.buttonToClipboard.Click += new System.EventHandler(this.buttonToClipboard_Click);
            // 
            // ReplaceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(782, 553);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "ReplaceForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Замена символов";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.flowResize1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.flowResize2.ResumeLayout(false);
            this.flowResize2.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBoxText;
        private System.Windows.Forms.TextBox textBoxFrom;
        private System.Windows.Forms.TextBox textBoxTo;
        private FlowResize flowResize1;
        private System.Windows.Forms.Button buttonReplace;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.RadioButton radioButtonAllText;
        private System.Windows.Forms.RadioButton radioButtonSelectedText;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.RadioButton radioButtonFrom;
        private System.Windows.Forms.RadioButton radioButtonTo;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton radioButtonValue;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.RadioButton radioButtonRunStart;
        private System.Windows.Forms.RadioButton radioButtonRunEnd;
        private System.Windows.Forms.RadioButton radioButtonRunText;
        private FlowResize flowResize2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ввестиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSetByStart;
        private System.Windows.Forms.ToolStripMenuItem buttonSetMain;
        private System.Windows.Forms.ToolStripMenuItem buttonSetByClipboard;
        private System.Windows.Forms.ToolStripMenuItem записатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToMain;
        private System.Windows.Forms.ToolStripMenuItem buttonToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonSetByValue;
        private System.Windows.Forms.ToolStripMenuItem buttonSetBySelectedValue;
        private System.Windows.Forms.ToolStripMenuItem весьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem начальныйТексToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSetBySelectedTo;
        private System.Windows.Forms.ToolStripMenuItem buttonSetByTo;
        private System.Windows.Forms.ToolStripMenuItem начальныйТекстToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSetBySelectedFrom;
        private System.Windows.Forms.ToolStripMenuItem buttonSetByFrom;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem задатьСимволToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSetSpace;
        private System.Windows.Forms.ToolStripMenuItem buttonSetEnter;
        private System.Windows.Forms.ToolStripMenuItem buttonSetTab;
        private System.Windows.Forms.ToolStripMenuItem символToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSetSqrt;
        private System.Windows.Forms.ToolStripMenuItem buttonSetSqrt1;
        private System.Windows.Forms.ToolStripMenuItem buttonSetPI;
        private System.Windows.Forms.ToolStripMenuItem buttonClear;
    }
}