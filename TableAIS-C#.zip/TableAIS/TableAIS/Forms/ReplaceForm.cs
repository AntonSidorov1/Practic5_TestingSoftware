﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class ReplaceForm : Form
    {


        public event Func<string> SetFromMain;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public event Func<string> SetNumberFromMain;

        public string SetNumberFromMainInvoke()
        {
            return SetNumberFromMain?.Invoke()??"";
        }


        public ReplaceForm()
        {
            change = true;
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;
            
            Icon = Properties.Resources.AisTable1;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public ReplaceForm(Save save):this()
        {
            Save = save;
        }

        public ReplaceForm(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            try
            {
                string value = SetNumberFromMainInvoke();
                string valueStart = Value;
                if(valueStart != value && !valueStart.Equals(value))
                {
                    change = false;
                    Value = value;
                }
            }
            catch { }
            change = true;
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();
            
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
        bool change;
        private void textBoxText_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if(change)
                MetrOutput1?.Invoke(Value, Save.None);
            }
            catch { }
        }

        public string Value
        {
            get => textBoxText.Text.Replace(Environment.NewLine, "\n");
            set => textBoxText.Text = value.Replace(Environment.NewLine, "\n").Replace("\n", Environment.NewLine);
        }

        public string SelectedValue
        {
            get => textBoxText.SelectedText.Replace(Environment.NewLine, "\n");
            set => textBoxText.SelectedText = value.Replace(Environment.NewLine, "\n").Replace("\n", Environment.NewLine);
        }

        private void textBoxFrom_TextChanged(object sender, EventArgs e)
        {

        }

        public string From
        {
            get => textBoxFrom.Text.Replace(Environment.NewLine, "\n");
            set => textBoxFrom.Text = value.Replace(Environment.NewLine, "\n").Replace("\n", Environment.NewLine);
        }

        public string SelectFrom
        {
            get => textBoxFrom.SelectedText.Replace(Environment.NewLine, "\n");
            set => textBoxFrom.SelectedText = value.Replace(Environment.NewLine, "\n").Replace("\n", Environment.NewLine);
        }

        private void textBoxTo_TextChanged(object sender, EventArgs e)
        {

        }

        public string To
        {
            get => textBoxTo.Text.Replace(Environment.NewLine, "\n");
            set => textBoxTo.Text = value.Replace(Environment.NewLine, "\n").Replace("\n", Environment.NewLine);
        }

        public string SelectTo
        {
            get => textBoxTo.SelectedText.Replace(Environment.NewLine, "\n");
            set => textBoxTo.SelectedText = value.Replace(Environment.NewLine, "\n").Replace("\n", Environment.NewLine);

        }

        public string ChooseTo
        {
            get
            {
                if(radioButtonAllText.Checked)
                {
                    return To;
                }
                if(radioButtonSelectedText.Checked)
                {
                    return SelectTo;
                }
                return "";
            }
            set
            {
                string text = value;
                if(radioButtonAllText.Checked)
                {
                    To = text;
                }
                if (radioButtonSelectedText.Checked)
                {
                    SelectTo = text;
                }
            }
        }

        public string ChooseFrom
        {
            get
            {
                if (radioButtonAllText.Checked)
                {
                    return From;
                }
                if (radioButtonSelectedText.Checked)
                {
                    return SelectFrom;
                }
                return "";
            }
            set
            {
                string text = value;
                if (radioButtonAllText.Checked)
                {
                    From = text;
                }
                if (radioButtonSelectedText.Checked)
                {
                    SelectFrom = text;
                }
            }
        }

        public string ChooseValue
        {
            get
            {
                if (radioButtonAllText.Checked)
                {
                    return Value;
                }
                if (radioButtonSelectedText.Checked)
                {
                    return SelectedValue;
                }
                return "";
            }
            set
            {
                string text = value;
                if (radioButtonAllText.Checked)
                {
                    Value = text;
                }
                if (radioButtonSelectedText.Checked)
                {
                    SelectedValue = text;
                }
            }
        }

        public string ChooseReplace
        {
            get
            {
                if(radioButtonFrom.Checked)
                {
                    return ChooseFrom;
                }
                if(radioButtonTo.Checked)
                {
                    return ChooseTo;
                }
                if(radioButtonValue.Checked)
                {
                    return ChooseValue;
                }
                return "";
            }
            set
            {
                string text = value;
                if(radioButtonFrom.Checked)
                {
                    ChooseFrom = text;
                }
                else if(radioButtonTo.Checked)
                {
                    ChooseTo = text;
                }
                else if(radioButtonValue.Checked)
                {
                    ChooseValue = text;
                }
            }
        }

        public void Replace()
        {
            try
            {
                Value = Value.Replace(From, To);
            }
            catch { }
        }

        private void buttonReplace_Click(object sender, EventArgs e)
        {
            try
            {
                Replace();
            }
            catch { }
        }

        public void RunText(string text)
        {
            if(radioButtonRunText.Checked)
            {
                ChooseReplace = text;
            }
            else if(radioButtonRunEnd.Checked)
            {
                ChooseReplace = ChooseReplace + text;
            }
            else if(radioButtonRunStart.Checked)
            {
                ChooseReplace = text + ChooseReplace;
            }

        }

        private void buttonSetByStart_Click(object sender, EventArgs e)
        {
            try
            {
                RunText(SetNumberFromMainInvoke());
            }
            catch { }
        }

        private void buttonSetMain_Click(object sender, EventArgs e)
        {
            try
            {
                RunText(ValueHelper.GetText());
            }
            catch { }
        }

        private void buttonSetByClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                RunText(Clipboard.GetText());
            }
            catch { }
        }

        private void buttonToStart_Click(object sender, EventArgs e)
        {
            try
            {
                MetrOutput1(ChooseReplace, Save.None);
            }
            catch { }
        }

        private void buttonToMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(ChooseReplace);
            }
            catch { }
        }

        private void buttonToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(ChooseReplace);
            }
            catch { }
        }

        private void buttonSetByValue_Click(object sender, EventArgs e)
        {
            try
            {
                RunText(Value);
            }
            catch { }
        }

        private void buttonSetBySelectedValue_Click(object sender, EventArgs e)
        {
            try
            {
                RunText(SelectedValue);
            }
            catch { }
        }

        private void buttonSetBySelectedTo_Click(object sender, EventArgs e)
        {
            try
            {
                RunText(SelectTo);
            }
            catch { }
        }

        private void buttonSetByTo_Click(object sender, EventArgs e)
        {
            try
            {
                RunText(To);
            }
            catch { }
        }

        private void buttonSetBySelectedFrom_Click(object sender, EventArgs e)
        {
            try
            {
                RunText(SelectFrom);
            }
            catch { }
        }

        private void buttonSetByFrom_Click(object sender, EventArgs e)
        {
            try
            {
                RunText(From);
            }
            catch { }
        }

        private void buttonSetSpace_Click(object sender, EventArgs e)
        {
            try
            {
                RunText(" ");
            }
            catch { }
        }

        private void buttonSetEnter_Click(object sender, EventArgs e)
        {
            try
            {
                RunText("\n");
            }
            catch { }
        }

        private void buttonSetTab_Click(object sender, EventArgs e)
        {
            try
            {
                RunText("\t");
            }
            catch { }
        }

        private void buttonSetSqrt_Click(object sender, EventArgs e)
        {
            try
            {
                RunText("√");
            }
            catch { }
        }

        private void buttonSetSqrt1_Click(object sender, EventArgs e)
        {
            try
            {
                RunText("✓");
            }
            catch { }
        }

        private void buttonSetPI_Click(object sender, EventArgs e)
        {
            try
            {
                RunText("π");
            }
            catch { }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseReplace = "";
            }
            catch { }
        }
    }
}
