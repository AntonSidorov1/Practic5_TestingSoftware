﻿namespace TableAIS
{
    partial class SecondMetrForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SecondMetrForm));
            this.button1 = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.textBoxSecondMetr = new System.Windows.Forms.TextBox();
            this.buttonClear = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonStartTime = new System.Windows.Forms.Button();
            this.buttonStartSet = new System.Windows.Forms.Button();
            this.buttonStartNow = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.numericStartSeconds = new System.Windows.Forms.NumericUpDown();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.numericStartMinutes = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.numericStartHours = new System.Windows.Forms.NumericUpDown();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.buttonEndTime = new System.Windows.Forms.Button();
            this.buttonEndSet = new System.Windows.Forms.Button();
            this.buttonEndNow = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.numericEndSeconds = new System.Windows.Forms.NumericUpDown();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.numericEndMinutes = new System.Windows.Forms.NumericUpDown();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.numericEndHours = new System.Windows.Forms.NumericUpDown();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.buttonResultInput = new System.Windows.Forms.Button();
            this.buttonSetResult = new System.Windows.Forms.Button();
            this.buttonMines = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.numericAddMilliSecond = new System.Windows.Forms.NumericUpDown();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.numericAddSecond = new System.Windows.Forms.NumericUpDown();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.numericMinuteAdd = new System.Windows.Forms.NumericUpDown();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.numericAddHour = new System.Windows.Forms.NumericUpDown();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxFromStart = new System.Windows.Forms.CheckBox();
            this.checkBoxFromNow = new System.Windows.Forms.CheckBox();
            this.checkBoxPointChange = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonStart = new System.Windows.Forms.Button();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.ввестиИзВнеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.задатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetMilliseconds = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetSeconds = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetMinutes = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetHours = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetFullTime = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetPlusHours = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHourTimeSet = new System.Windows.Forms.ToolStripMenuItem();
            this.увеличитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddMilliseconds = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSecondsAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonMinutesAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHoursAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFullTime = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddPlusHours = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddHourMinutes = new System.Windows.Forms.ToolStripMenuItem();
            this.уменьшитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSubMilliseconds = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSecondsSub = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonMinutesSub = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHoursSub = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSubFullTime = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSubPlusHours = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSubHourMinutes = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSave = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSavedList = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxOutput = new System.Windows.Forms.ComboBox();
            this.textBoxOutput = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.numericRound = new System.Windows.Forms.NumericUpDown();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWrite = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.checkBoxIsTimer = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonTimeStart = new System.Windows.Forms.Button();
            this.textBoxTimeStart = new System.Windows.Forms.TextBox();
            this.menuStrip4 = new System.Windows.Forms.MenuStrip();
            this.записатьВесьТекстToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteTextMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWriteTextClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.numbericUserStart = new TableAIS.NumbericUser();
            this.numbericUserTo = new TableAIS.NumbericUser();
            this.timerStart = new System.Windows.Forms.Timer(this.components);
            this.toolTipComboBox = new System.Windows.Forms.ToolTip(this.components);
            this.buttonTimerTime = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericStartSeconds)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericStartMinutes)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericStartHours)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericEndSeconds)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericEndMinutes)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericEndHours)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericAddMilliSecond)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericAddSecond)).BeginInit();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericMinuteAdd)).BeginInit();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericAddHour)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericRound)).BeginInit();
            this.menuStrip3.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.menuStrip4.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(569, 25);
            this.button1.Margin = new System.Windows.Forms.Padding(25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(249, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 627);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(847, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // textBoxSecondMetr
            // 
            this.textBoxSecondMetr.BackColor = System.Drawing.Color.White;
            this.textBoxSecondMetr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxSecondMetr.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxSecondMetr.Location = new System.Drawing.Point(0, 40);
            this.textBoxSecondMetr.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxSecondMetr.MinimumSize = new System.Drawing.Size(330, 190);
            this.textBoxSecondMetr.Multiline = true;
            this.textBoxSecondMetr.Name = "textBoxSecondMetr";
            this.textBoxSecondMetr.ReadOnly = true;
            this.textBoxSecondMetr.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxSecondMetr.Size = new System.Drawing.Size(514, 351);
            this.textBoxSecondMetr.TabIndex = 2;
            // 
            // buttonClear
            // 
            this.buttonClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClear.Location = new System.Drawing.Point(168, 3);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(159, 44);
            this.buttonClear.TabIndex = 4;
            this.buttonClear.Text = "Сбросить";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonStartTime);
            this.groupBox1.Controls.Add(this.buttonStartSet);
            this.groupBox1.Controls.Add(this.buttonStartNow);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(289, 163);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Начальное время";
            // 
            // buttonStartTime
            // 
            this.buttonStartTime.Location = new System.Drawing.Point(13, 125);
            this.buttonStartTime.Name = "buttonStartTime";
            this.buttonStartTime.Size = new System.Drawing.Size(270, 32);
            this.buttonStartTime.TabIndex = 3;
            this.buttonStartTime.Text = "Выполнить оба действия";
            this.buttonStartTime.UseVisualStyleBackColor = true;
            this.buttonStartTime.Click += new System.EventHandler(this.buttonStartTime_Click);
            // 
            // buttonStartSet
            // 
            this.buttonStartSet.Location = new System.Drawing.Point(152, 88);
            this.buttonStartSet.Name = "buttonStartSet";
            this.buttonStartSet.Size = new System.Drawing.Size(131, 36);
            this.buttonStartSet.TabIndex = 2;
            this.buttonStartSet.Text = "Задать";
            this.buttonStartSet.UseVisualStyleBackColor = true;
            this.buttonStartSet.Click += new System.EventHandler(this.buttonStartSet_Click);
            // 
            // buttonStartNow
            // 
            this.buttonStartNow.Location = new System.Drawing.Point(13, 88);
            this.buttonStartNow.Name = "buttonStartNow";
            this.buttonStartNow.Size = new System.Drawing.Size(133, 36);
            this.buttonStartNow.TabIndex = 1;
            this.buttonStartNow.Text = "Текущее";
            this.buttonStartNow.UseVisualStyleBackColor = true;
            this.buttonStartNow.Click += new System.EventHandler(this.buttonStartNow_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.numericStartSeconds);
            this.groupBox4.Location = new System.Drawing.Point(180, 17);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(100, 70);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Секунды";
            // 
            // numericStartSeconds
            // 
            this.numericStartSeconds.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericStartSeconds.Location = new System.Drawing.Point(3, 30);
            this.numericStartSeconds.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numericStartSeconds.Name = "numericStartSeconds";
            this.numericStartSeconds.Size = new System.Drawing.Size(94, 34);
            this.numericStartSeconds.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.numericStartMinutes);
            this.groupBox3.Location = new System.Drawing.Point(81, 17);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(91, 70);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Минуты";
            // 
            // numericStartMinutes
            // 
            this.numericStartMinutes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericStartMinutes.Location = new System.Drawing.Point(3, 30);
            this.numericStartMinutes.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numericStartMinutes.Name = "numericStartMinutes";
            this.numericStartMinutes.Size = new System.Drawing.Size(85, 34);
            this.numericStartMinutes.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.numericStartHours);
            this.groupBox2.Location = new System.Drawing.Point(6, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(69, 70);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Часы";
            // 
            // numericStartHours
            // 
            this.numericStartHours.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericStartHours.Location = new System.Drawing.Point(3, 30);
            this.numericStartHours.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.numericStartHours.Name = "numericStartHours";
            this.numericStartHours.Size = new System.Drawing.Size(63, 34);
            this.numericStartHours.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.buttonEndTime);
            this.groupBox5.Controls.Add(this.buttonEndSet);
            this.groupBox5.Controls.Add(this.buttonEndNow);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.groupBox7);
            this.groupBox5.Controls.Add(this.groupBox8);
            this.groupBox5.Location = new System.Drawing.Point(3, 172);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(289, 159);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Конечное время";
            // 
            // buttonEndTime
            // 
            this.buttonEndTime.Location = new System.Drawing.Point(13, 124);
            this.buttonEndTime.Name = "buttonEndTime";
            this.buttonEndTime.Size = new System.Drawing.Size(270, 32);
            this.buttonEndTime.TabIndex = 3;
            this.buttonEndTime.Text = "Выполнить оба действия";
            this.buttonEndTime.UseVisualStyleBackColor = true;
            this.buttonEndTime.Click += new System.EventHandler(this.buttonEndTime_Click);
            // 
            // buttonEndSet
            // 
            this.buttonEndSet.Location = new System.Drawing.Point(149, 87);
            this.buttonEndSet.Name = "buttonEndSet";
            this.buttonEndSet.Size = new System.Drawing.Size(131, 36);
            this.buttonEndSet.TabIndex = 2;
            this.buttonEndSet.Text = "Задать";
            this.buttonEndSet.UseVisualStyleBackColor = true;
            this.buttonEndSet.Click += new System.EventHandler(this.buttonEndSet_Click);
            // 
            // buttonEndNow
            // 
            this.buttonEndNow.Location = new System.Drawing.Point(13, 88);
            this.buttonEndNow.Name = "buttonEndNow";
            this.buttonEndNow.Size = new System.Drawing.Size(133, 36);
            this.buttonEndNow.TabIndex = 1;
            this.buttonEndNow.Text = "Текущее";
            this.buttonEndNow.UseVisualStyleBackColor = true;
            this.buttonEndNow.Click += new System.EventHandler(this.buttonEndNow_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.numericEndSeconds);
            this.groupBox6.Location = new System.Drawing.Point(180, 17);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(100, 70);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Секунды";
            // 
            // numericEndSeconds
            // 
            this.numericEndSeconds.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericEndSeconds.Location = new System.Drawing.Point(3, 30);
            this.numericEndSeconds.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numericEndSeconds.Name = "numericEndSeconds";
            this.numericEndSeconds.Size = new System.Drawing.Size(94, 34);
            this.numericEndSeconds.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.numericEndMinutes);
            this.groupBox7.Location = new System.Drawing.Point(81, 17);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(91, 70);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Минуты";
            // 
            // numericEndMinutes
            // 
            this.numericEndMinutes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericEndMinutes.Location = new System.Drawing.Point(3, 30);
            this.numericEndMinutes.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numericEndMinutes.Name = "numericEndMinutes";
            this.numericEndMinutes.Size = new System.Drawing.Size(85, 34);
            this.numericEndMinutes.TabIndex = 0;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.numericEndHours);
            this.groupBox8.Location = new System.Drawing.Point(6, 17);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(69, 70);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Часы";
            // 
            // numericEndHours
            // 
            this.numericEndHours.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericEndHours.Location = new System.Drawing.Point(3, 30);
            this.numericEndHours.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.numericEndHours.Name = "numericEndHours";
            this.numericEndHours.Size = new System.Drawing.Size(63, 34);
            this.numericEndHours.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tableLayoutPanel9.SetColumnSpan(this.flowLayoutPanel1, 2);
            this.flowLayoutPanel1.Controls.Add(this.groupBox1);
            this.flowLayoutPanel1.Controls.Add(this.groupBox5);
            this.flowLayoutPanel1.Controls.Add(this.groupBox9);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 153);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(321, 229);
            this.flowLayoutPanel1.TabIndex = 7;
            this.flowLayoutPanel1.WrapContents = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.buttonResultInput);
            this.groupBox9.Controls.Add(this.buttonSetResult);
            this.groupBox9.Controls.Add(this.buttonMines);
            this.groupBox9.Controls.Add(this.buttonAdd);
            this.groupBox9.Controls.Add(this.groupBox13);
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Controls.Add(this.groupBox11);
            this.groupBox9.Controls.Add(this.groupBox12);
            this.groupBox9.Location = new System.Drawing.Point(3, 337);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(289, 224);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Увеличить/Уменьшить результат";
            // 
            // buttonResultInput
            // 
            this.buttonResultInput.Location = new System.Drawing.Point(5, 169);
            this.buttonResultInput.Name = "buttonResultInput";
            this.buttonResultInput.Size = new System.Drawing.Size(141, 30);
            this.buttonResultInput.TabIndex = 4;
            this.buttonResultInput.Text = "Ввести";
            this.buttonResultInput.UseVisualStyleBackColor = true;
            this.buttonResultInput.Click += new System.EventHandler(this.buttonResultInput_Click);
            // 
            // buttonSetResult
            // 
            this.buttonSetResult.Location = new System.Drawing.Point(152, 178);
            this.buttonSetResult.Name = "buttonSetResult";
            this.buttonSetResult.Size = new System.Drawing.Size(128, 34);
            this.buttonSetResult.TabIndex = 3;
            this.buttonSetResult.Text = "Задать";
            this.buttonSetResult.UseVisualStyleBackColor = true;
            this.buttonSetResult.Click += new System.EventHandler(this.buttonSetResult_Click);
            // 
            // buttonMines
            // 
            this.buttonMines.Location = new System.Drawing.Point(152, 131);
            this.buttonMines.Name = "buttonMines";
            this.buttonMines.Size = new System.Drawing.Size(128, 41);
            this.buttonMines.TabIndex = 2;
            this.buttonMines.Text = "Уменьшить";
            this.buttonMines.UseVisualStyleBackColor = true;
            this.buttonMines.Click += new System.EventHandler(this.buttonMines_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(152, 87);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(128, 41);
            this.buttonAdd.TabIndex = 1;
            this.buttonAdd.Text = "Увеличить";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.numericAddMilliSecond);
            this.groupBox13.Location = new System.Drawing.Point(5, 93);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(141, 70);
            this.groupBox13.TabIndex = 0;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Милисекунды";
            // 
            // numericAddMilliSecond
            // 
            this.numericAddMilliSecond.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericAddMilliSecond.Location = new System.Drawing.Point(3, 30);
            this.numericAddMilliSecond.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericAddMilliSecond.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.numericAddMilliSecond.Name = "numericAddMilliSecond";
            this.numericAddMilliSecond.Size = new System.Drawing.Size(135, 34);
            this.numericAddMilliSecond.TabIndex = 0;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.numericAddSecond);
            this.groupBox10.Location = new System.Drawing.Point(180, 17);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(100, 70);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Секунды";
            // 
            // numericAddSecond
            // 
            this.numericAddSecond.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericAddSecond.Location = new System.Drawing.Point(3, 30);
            this.numericAddSecond.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.numericAddSecond.Minimum = new decimal(new int[] {
            60,
            0,
            0,
            -2147483648});
            this.numericAddSecond.Name = "numericAddSecond";
            this.numericAddSecond.Size = new System.Drawing.Size(94, 34);
            this.numericAddSecond.TabIndex = 0;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.numericMinuteAdd);
            this.groupBox11.Location = new System.Drawing.Point(81, 17);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(91, 70);
            this.groupBox11.TabIndex = 0;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Минуты";
            // 
            // numericMinuteAdd
            // 
            this.numericMinuteAdd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericMinuteAdd.Location = new System.Drawing.Point(3, 30);
            this.numericMinuteAdd.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.numericMinuteAdd.Minimum = new decimal(new int[] {
            60,
            0,
            0,
            -2147483648});
            this.numericMinuteAdd.Name = "numericMinuteAdd";
            this.numericMinuteAdd.Size = new System.Drawing.Size(85, 34);
            this.numericMinuteAdd.TabIndex = 0;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.numericAddHour);
            this.groupBox12.Location = new System.Drawing.Point(6, 17);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(69, 70);
            this.groupBox12.TabIndex = 0;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Часы";
            // 
            // numericAddHour
            // 
            this.numericAddHour.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericAddHour.Location = new System.Drawing.Point(3, 30);
            this.numericAddHour.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.numericAddHour.Minimum = new decimal(new int[] {
            24,
            0,
            0,
            -2147483648});
            this.numericAddHour.Name = "numericAddHour";
            this.numericAddHour.Size = new System.Drawing.Size(63, 34);
            this.numericAddHour.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(847, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(843, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(452, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Секундомер";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 604);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(847, 23);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 333F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.textBoxSecondMetr, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel8, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel9, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 124F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(847, 515);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75.29881F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.70119F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel6, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel7, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonTimerTime, 1, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(6, 397);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(6);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(502, 112);
            this.tableLayoutPanel3.TabIndex = 11;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 3;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.42553F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.00473F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel6.Controls.Add(this.checkBoxFromStart, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.checkBoxFromNow, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.checkBoxPointChange, 2, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 59);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(372, 50);
            this.tableLayoutPanel6.TabIndex = 5;
            // 
            // checkBoxFromStart
            // 
            this.checkBoxFromStart.AutoSize = true;
            this.checkBoxFromStart.Checked = true;
            this.checkBoxFromStart.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxFromStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxFromStart.Location = new System.Drawing.Point(153, 3);
            this.checkBoxFromStart.Name = "checkBoxFromStart";
            this.checkBoxFromStart.Size = new System.Drawing.Size(90, 44);
            this.checkBoxFromStart.TabIndex = 6;
            this.checkBoxFromStart.Text = "С начала";
            this.checkBoxFromStart.UseVisualStyleBackColor = true;
            // 
            // checkBoxFromNow
            // 
            this.checkBoxFromNow.AutoSize = true;
            this.checkBoxFromNow.Checked = true;
            this.checkBoxFromNow.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxFromNow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxFromNow.Location = new System.Drawing.Point(3, 3);
            this.checkBoxFromNow.Name = "checkBoxFromNow";
            this.checkBoxFromNow.Size = new System.Drawing.Size(144, 44);
            this.checkBoxFromNow.TabIndex = 5;
            this.checkBoxFromNow.Text = "От текущего времени";
            this.checkBoxFromNow.UseVisualStyleBackColor = true;
            // 
            // checkBoxPointChange
            // 
            this.checkBoxPointChange.AutoSize = true;
            this.checkBoxPointChange.Checked = true;
            this.checkBoxPointChange.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxPointChange.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxPointChange.Location = new System.Drawing.Point(249, 3);
            this.checkBoxPointChange.Name = "checkBoxPointChange";
            this.checkBoxPointChange.Size = new System.Drawing.Size(120, 44);
            this.checkBoxPointChange.TabIndex = 7;
            this.checkBoxPointChange.Text = "Замена разделителя";
            this.checkBoxPointChange.UseVisualStyleBackColor = true;
            this.checkBoxPointChange.CheckedChanged += new System.EventHandler(this.checkBoxPointChange_CheckedChanged);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 3;
            this.tableLayoutPanel3.SetColumnSpan(this.tableLayoutPanel7, 2);
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel7.Controls.Add(this.buttonClear, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonStart, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel11, 2, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(496, 50);
            this.tableLayoutPanel7.TabIndex = 6;
            // 
            // buttonStart
            // 
            this.buttonStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonStart.Location = new System.Drawing.Point(3, 3);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(159, 44);
            this.buttonStart.TabIndex = 3;
            this.buttonStart.Text = "button2";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel11.Controls.Add(this.menuStrip2, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(330, 0);
            this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(166, 50);
            this.tableLayoutPanel11.TabIndex = 5;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ввестиИзВнеToolStripMenuItem1});
            this.menuStrip2.Location = new System.Drawing.Point(0, 25);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(166, 25);
            this.menuStrip2.TabIndex = 6;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // ввестиИзВнеToolStripMenuItem1
            // 
            this.ввестиИзВнеToolStripMenuItem1.BackColor = System.Drawing.Color.LightGray;
            this.ввестиИзВнеToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.задатьToolStripMenuItem,
            this.увеличитьToolStripMenuItem,
            this.уменьшитьToolStripMenuItem});
            this.ввестиИзВнеToolStripMenuItem1.Name = "ввестиИзВнеToolStripMenuItem1";
            this.ввестиИзВнеToolStripMenuItem1.Size = new System.Drawing.Size(152, 21);
            this.ввестиИзВнеToolStripMenuItem1.Text = "Ввести из вне";
            // 
            // задатьToolStripMenuItem
            // 
            this.задатьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetMilliseconds,
            this.buttonSetSeconds,
            this.buttonSetMinutes,
            this.buttonSetHours,
            this.buttonSetFullTime,
            this.buttonSetPlusHours,
            this.buttonHourTimeSet});
            this.задатьToolStripMenuItem.Name = "задатьToolStripMenuItem";
            this.задатьToolStripMenuItem.Size = new System.Drawing.Size(210, 26);
            this.задатьToolStripMenuItem.Text = "Задать";
            // 
            // buttonSetMilliseconds
            // 
            this.buttonSetMilliseconds.Name = "buttonSetMilliseconds";
            this.buttonSetMilliseconds.Size = new System.Drawing.Size(440, 26);
            this.buttonSetMilliseconds.Text = "Миллисекунды";
            this.buttonSetMilliseconds.Click += new System.EventHandler(this.buttonSetMilliseconds_Click);
            // 
            // buttonSetSeconds
            // 
            this.buttonSetSeconds.Name = "buttonSetSeconds";
            this.buttonSetSeconds.Size = new System.Drawing.Size(440, 26);
            this.buttonSetSeconds.Text = "Секунды";
            this.buttonSetSeconds.Click += new System.EventHandler(this.buttonSetSeconds_Click);
            // 
            // buttonSetMinutes
            // 
            this.buttonSetMinutes.Name = "buttonSetMinutes";
            this.buttonSetMinutes.Size = new System.Drawing.Size(440, 26);
            this.buttonSetMinutes.Text = "Минуты";
            this.buttonSetMinutes.Click += new System.EventHandler(this.buttonSetMinutes_Click);
            // 
            // buttonSetHours
            // 
            this.buttonSetHours.Name = "buttonSetHours";
            this.buttonSetHours.Size = new System.Drawing.Size(440, 26);
            this.buttonSetHours.Text = "Часы";
            this.buttonSetHours.Click += new System.EventHandler(this.buttonSetHours_Click);
            // 
            // buttonSetFullTime
            // 
            this.buttonSetFullTime.Name = "buttonSetFullTime";
            this.buttonSetFullTime.Size = new System.Drawing.Size(440, 26);
            this.buttonSetFullTime.Text = "Полное или часы и минуты без секунд";
            this.buttonSetFullTime.Click += new System.EventHandler(this.buttonSetFullTime_Click);
            // 
            // buttonSetPlusHours
            // 
            this.buttonSetPlusHours.Name = "buttonSetPlusHours";
            this.buttonSetPlusHours.Size = new System.Drawing.Size(440, 26);
            this.buttonSetPlusHours.Text = "Плюс часы";
            this.buttonSetPlusHours.Click += new System.EventHandler(this.buttonSetPlusHours_Click);
            // 
            // buttonHourTimeSet
            // 
            this.buttonHourTimeSet.Name = "buttonHourTimeSet";
            this.buttonHourTimeSet.Size = new System.Drawing.Size(440, 26);
            this.buttonHourTimeSet.Text = "Часы и минуты с секундами";
            this.buttonHourTimeSet.Click += new System.EventHandler(this.buttonHourTimeSet_Click);
            // 
            // увеличитьToolStripMenuItem
            // 
            this.увеличитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddMilliseconds,
            this.buttonSecondsAdd,
            this.buttonMinutesAdd,
            this.buttonHoursAdd,
            this.buttonAddFullTime,
            this.buttonAddPlusHours,
            this.buttonAddHourMinutes});
            this.увеличитьToolStripMenuItem.Name = "увеличитьToolStripMenuItem";
            this.увеличитьToolStripMenuItem.Size = new System.Drawing.Size(210, 26);
            this.увеличитьToolStripMenuItem.Text = "Увеличить на";
            // 
            // buttonAddMilliseconds
            // 
            this.buttonAddMilliseconds.Name = "buttonAddMilliseconds";
            this.buttonAddMilliseconds.Size = new System.Drawing.Size(440, 26);
            this.buttonAddMilliseconds.Text = "Миллисекунды";
            this.buttonAddMilliseconds.Click += new System.EventHandler(this.buttonAddMilliseconds_Click);
            // 
            // buttonSecondsAdd
            // 
            this.buttonSecondsAdd.Name = "buttonSecondsAdd";
            this.buttonSecondsAdd.Size = new System.Drawing.Size(440, 26);
            this.buttonSecondsAdd.Text = "Секунды";
            this.buttonSecondsAdd.Click += new System.EventHandler(this.buttonSecondsAdd_Click);
            // 
            // buttonMinutesAdd
            // 
            this.buttonMinutesAdd.Name = "buttonMinutesAdd";
            this.buttonMinutesAdd.Size = new System.Drawing.Size(440, 26);
            this.buttonMinutesAdd.Text = "Минуты";
            this.buttonMinutesAdd.Click += new System.EventHandler(this.buttonMinutesAdd_Click);
            // 
            // buttonHoursAdd
            // 
            this.buttonHoursAdd.Name = "buttonHoursAdd";
            this.buttonHoursAdd.Size = new System.Drawing.Size(440, 26);
            this.buttonHoursAdd.Text = "Часы";
            this.buttonHoursAdd.Click += new System.EventHandler(this.buttonHoursAdd_Click);
            // 
            // buttonAddFullTime
            // 
            this.buttonAddFullTime.Name = "buttonAddFullTime";
            this.buttonAddFullTime.Size = new System.Drawing.Size(440, 26);
            this.buttonAddFullTime.Text = "Полное или часы и минуты без секунд";
            this.buttonAddFullTime.Click += new System.EventHandler(this.buttonAddFullTime_Click);
            // 
            // buttonAddPlusHours
            // 
            this.buttonAddPlusHours.Name = "buttonAddPlusHours";
            this.buttonAddPlusHours.Size = new System.Drawing.Size(440, 26);
            this.buttonAddPlusHours.Text = "Плюс часы";
            this.buttonAddPlusHours.Click += new System.EventHandler(this.buttonAddPlusHours_Click);
            // 
            // buttonAddHourMinutes
            // 
            this.buttonAddHourMinutes.Name = "buttonAddHourMinutes";
            this.buttonAddHourMinutes.Size = new System.Drawing.Size(440, 26);
            this.buttonAddHourMinutes.Text = "Часы и минуты с секундами";
            this.buttonAddHourMinutes.Click += new System.EventHandler(this.buttonAddHourMinutes_Click);
            // 
            // уменьшитьToolStripMenuItem
            // 
            this.уменьшитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSubMilliseconds,
            this.buttonSecondsSub,
            this.buttonMinutesSub,
            this.buttonHoursSub,
            this.buttonSubFullTime,
            this.buttonSubPlusHours,
            this.buttonSubHourMinutes});
            this.уменьшитьToolStripMenuItem.Name = "уменьшитьToolStripMenuItem";
            this.уменьшитьToolStripMenuItem.Size = new System.Drawing.Size(210, 26);
            this.уменьшитьToolStripMenuItem.Text = "Уменьшить на";
            // 
            // buttonSubMilliseconds
            // 
            this.buttonSubMilliseconds.Name = "buttonSubMilliseconds";
            this.buttonSubMilliseconds.Size = new System.Drawing.Size(440, 26);
            this.buttonSubMilliseconds.Text = "Миллисекунды";
            this.buttonSubMilliseconds.Click += new System.EventHandler(this.buttonSubMilliseconds_Click);
            // 
            // buttonSecondsSub
            // 
            this.buttonSecondsSub.Name = "buttonSecondsSub";
            this.buttonSecondsSub.Size = new System.Drawing.Size(440, 26);
            this.buttonSecondsSub.Text = "Секунды";
            this.buttonSecondsSub.Click += new System.EventHandler(this.buttonSecondsSub_Click);
            // 
            // buttonMinutesSub
            // 
            this.buttonMinutesSub.Name = "buttonMinutesSub";
            this.buttonMinutesSub.Size = new System.Drawing.Size(440, 26);
            this.buttonMinutesSub.Text = "Минуты";
            this.buttonMinutesSub.Click += new System.EventHandler(this.buttonMinutesSub_Click);
            // 
            // buttonHoursSub
            // 
            this.buttonHoursSub.Name = "buttonHoursSub";
            this.buttonHoursSub.Size = new System.Drawing.Size(440, 26);
            this.buttonHoursSub.Text = "Часы";
            this.buttonHoursSub.Click += new System.EventHandler(this.buttonHoursSub_Click);
            // 
            // buttonSubFullTime
            // 
            this.buttonSubFullTime.Name = "buttonSubFullTime";
            this.buttonSubFullTime.Size = new System.Drawing.Size(440, 26);
            this.buttonSubFullTime.Text = "Полное или часы и минуты без секунд";
            this.buttonSubFullTime.Click += new System.EventHandler(this.buttonSubFullTime_Click);
            // 
            // buttonSubPlusHours
            // 
            this.buttonSubPlusHours.Name = "buttonSubPlusHours";
            this.buttonSubPlusHours.Size = new System.Drawing.Size(440, 26);
            this.buttonSubPlusHours.Text = "Плюс часы";
            this.buttonSubPlusHours.Click += new System.EventHandler(this.buttonSubPlusHours_Click);
            // 
            // buttonSubHourMinutes
            // 
            this.buttonSubHourMinutes.Name = "buttonSubHourMinutes";
            this.buttonSubHourMinutes.Size = new System.Drawing.Size(440, 26);
            this.buttonSubHourMinutes.Text = "Часы и минуты с секундами";
            this.buttonSubHourMinutes.Click += new System.EventHandler(this.buttonSubHourMinutes_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(166, 25);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.LightGray;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSave,
            this.buttonSavedList});
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(132, 21);
            this.toolStripMenuItem1.Text = "Запомненные";
            // 
            // buttonSave
            // 
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(370, 26);
            this.buttonSave.Text = "Запомнить измерение";
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonSavedList
            // 
            this.buttonSavedList.Font = new System.Drawing.Font("Lucida Console", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSavedList.Name = "buttonSavedList";
            this.buttonSavedList.Size = new System.Drawing.Size(370, 26);
            this.buttonSavedList.Text = "Список запомненных измерений";
            this.buttonSavedList.Click += new System.EventHandler(this.buttonSavedList_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.7156F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.2844F));
            this.tableLayoutPanel4.Controls.Add(this.comboBoxOutput, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBoxOutput, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.menuStrip3, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.checkBoxIsTimer, 1, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(517, 394);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.85939F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.14061F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(327, 118);
            this.tableLayoutPanel4.TabIndex = 12;
            // 
            // comboBoxOutput
            // 
            this.comboBoxOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxOutput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxOutput.DropDownWidth = 300;
            this.comboBoxOutput.FormattingEnabled = true;
            this.comboBoxOutput.Location = new System.Drawing.Point(3, 3);
            this.comboBoxOutput.Name = "comboBoxOutput";
            this.comboBoxOutput.Size = new System.Drawing.Size(186, 29);
            this.comboBoxOutput.TabIndex = 7;
            this.comboBoxOutput.SelectedIndexChanged += new System.EventHandler(this.comboBoxOutput_SelectedIndexChanged);
            // 
            // textBoxOutput
            // 
            this.textBoxOutput.BackColor = System.Drawing.Color.White;
            this.textBoxOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxOutput.Location = new System.Drawing.Point(3, 100);
            this.textBoxOutput.Name = "textBoxOutput";
            this.textBoxOutput.ReadOnly = true;
            this.textBoxOutput.Size = new System.Drawing.Size(186, 34);
            this.textBoxOutput.TabIndex = 8;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.numericRound, 1, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 48);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(186, 46);
            this.tableLayoutPanel5.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 46);
            this.label2.TabIndex = 0;
            this.label2.Text = "Округлить до";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericRound
            // 
            this.numericRound.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericRound.Location = new System.Drawing.Point(96, 3);
            this.numericRound.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numericRound.Name = "numericRound";
            this.numericRound.Size = new System.Drawing.Size(87, 34);
            this.numericRound.TabIndex = 1;
            this.numericRound.ValueChanged += new System.EventHandler(this.numericRound_ValueChanged);
            // 
            // menuStrip3
            // 
            this.menuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2});
            this.menuStrip3.Location = new System.Drawing.Point(192, 45);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(135, 30);
            this.menuStrip3.TabIndex = 10;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonWrite,
            this.buttonWriteMain,
            this.buttonWriteClipboard});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(86, 26);
            this.toolStripMenuItem2.Text = "Записать";
            // 
            // buttonWrite
            // 
            this.buttonWrite.Name = "buttonWrite";
            this.buttonWrite.Size = new System.Drawing.Size(241, 26);
            this.buttonWrite.Text = "На предыдущее окно";
            this.buttonWrite.Click += new System.EventHandler(this.buttonWrite_Click);
            // 
            // buttonWriteMain
            // 
            this.buttonWriteMain.Name = "buttonWriteMain";
            this.buttonWriteMain.Size = new System.Drawing.Size(241, 26);
            this.buttonWriteMain.Text = "На главный экран";
            this.buttonWriteMain.Click += new System.EventHandler(this.buttonWriteMain_Click);
            // 
            // buttonWriteClipboard
            // 
            this.buttonWriteClipboard.Name = "buttonWriteClipboard";
            this.buttonWriteClipboard.Size = new System.Drawing.Size(241, 26);
            this.buttonWriteClipboard.Text = "В буфер обмена";
            this.buttonWriteClipboard.Click += new System.EventHandler(this.buttonWriteClipboard_Click);
            // 
            // checkBoxIsTimer
            // 
            this.checkBoxIsTimer.AutoSize = true;
            this.checkBoxIsTimer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxIsTimer.Location = new System.Drawing.Point(195, 3);
            this.checkBoxIsTimer.Name = "checkBoxIsTimer";
            this.checkBoxIsTimer.Size = new System.Drawing.Size(129, 39);
            this.checkBoxIsTimer.TabIndex = 11;
            this.checkBoxIsTimer.Text = "Таймер";
            this.checkBoxIsTimer.UseVisualStyleBackColor = true;
            this.checkBoxIsTimer.CheckedChanged += new System.EventHandler(this.checkBoxIsTimer_CheckedChanged);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 3;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.24379F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.57336F));
            this.tableLayoutPanel8.Controls.Add(this.buttonTimeStart, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.textBoxTimeStart, 2, 0);
            this.tableLayoutPanel8.Controls.Add(this.menuStrip4, 0, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(508, 34);
            this.tableLayoutPanel8.TabIndex = 13;
            // 
            // buttonTimeStart
            // 
            this.buttonTimeStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTimeStart.Location = new System.Drawing.Point(172, 3);
            this.buttonTimeStart.Name = "buttonTimeStart";
            this.buttonTimeStart.Size = new System.Drawing.Size(218, 28);
            this.buttonTimeStart.TabIndex = 0;
            this.buttonTimeStart.Text = "Отложенный запуск";
            this.buttonTimeStart.UseVisualStyleBackColor = true;
            this.buttonTimeStart.Click += new System.EventHandler(this.buttonTimeStart_Click);
            // 
            // textBoxTimeStart
            // 
            this.textBoxTimeStart.BackColor = System.Drawing.Color.White;
            this.textBoxTimeStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxTimeStart.Location = new System.Drawing.Point(396, 3);
            this.textBoxTimeStart.Name = "textBoxTimeStart";
            this.textBoxTimeStart.ReadOnly = true;
            this.textBoxTimeStart.Size = new System.Drawing.Size(109, 34);
            this.textBoxTimeStart.TabIndex = 1;
            this.textBoxTimeStart.Text = "5";
            this.textBoxTimeStart.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // menuStrip4
            // 
            this.menuStrip4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.записатьВесьТекстToolStripMenuItem});
            this.menuStrip4.Location = new System.Drawing.Point(0, 0);
            this.menuStrip4.Name = "menuStrip4";
            this.menuStrip4.Size = new System.Drawing.Size(169, 30);
            this.menuStrip4.TabIndex = 2;
            this.menuStrip4.Text = "menuStrip4";
            // 
            // записатьВесьТекстToolStripMenuItem
            // 
            this.записатьВесьТекстToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonWriteText,
            this.buttonWriteTextMain,
            this.buttonWriteTextClipboard});
            this.записатьВесьТекстToolStripMenuItem.Name = "записатьВесьТекстToolStripMenuItem";
            this.записатьВесьТекстToolStripMenuItem.Size = new System.Drawing.Size(159, 26);
            this.записатьВесьТекстToolStripMenuItem.Text = "Записать весь текст";
            // 
            // buttonWriteText
            // 
            this.buttonWriteText.Name = "buttonWriteText";
            this.buttonWriteText.Size = new System.Drawing.Size(241, 26);
            this.buttonWriteText.Text = "На предыдущее окно";
            this.buttonWriteText.Click += new System.EventHandler(this.buttonWriteText_Click);
            // 
            // buttonWriteTextMain
            // 
            this.buttonWriteTextMain.Name = "buttonWriteTextMain";
            this.buttonWriteTextMain.Size = new System.Drawing.Size(241, 26);
            this.buttonWriteTextMain.Text = "На главный экран";
            this.buttonWriteTextMain.Click += new System.EventHandler(this.buttonWriteTextMain_Click);
            // 
            // buttonWriteTextClipboard
            // 
            this.buttonWriteTextClipboard.Name = "buttonWriteTextClipboard";
            this.buttonWriteTextClipboard.Size = new System.Drawing.Size(241, 26);
            this.buttonWriteTextClipboard.Text = "В буфер обмена";
            this.buttonWriteTextClipboard.Click += new System.EventHandler(this.buttonWriteTextClipboard_Click);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.flowLayoutPanel1, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.groupBox14, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(517, 3);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel2.SetRowSpan(this.tableLayoutPanel9, 2);
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(327, 385);
            this.tableLayoutPanel9.TabIndex = 14;
            // 
            // groupBox14
            // 
            this.tableLayoutPanel9.SetColumnSpan(this.groupBox14, 2);
            this.groupBox14.Controls.Add(this.tableLayoutPanel10);
            this.groupBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox14.Location = new System.Drawing.Point(3, 3);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(321, 144);
            this.groupBox14.TabIndex = 8;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Отложенный запуск";
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Controls.Add(this.numbericUserStart, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.numbericUserTo, 1, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 111F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(315, 111);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // numbericUserStart
            // 
            this.numbericUserStart.Default = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numbericUserStart.DefaultValue = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numbericUserStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericUserStart.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUserStart.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUserStart.Location = new System.Drawing.Point(4, 4);
            this.numbericUserStart.Macimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numbericUserStart.Margin = new System.Windows.Forms.Padding(4);
            this.numbericUserStart.Maximum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numbericUserStart.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUserStart.Name = "numbericUserStart";
            this.numbericUserStart.NoReadOnly = true;
            this.numbericUserStart.ReadOnly = false;
            this.numbericUserStart.Size = new System.Drawing.Size(149, 103);
            this.numbericUserStart.TabIndex = 0;
            this.numbericUserStart.Title = "С";
            this.numbericUserStart.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numbericUserStart.VisibleOK = true;
            this.numbericUserStart.ValueChanged += new TableAIS.ValueChangedControl(this.numbericUserStart_ValueChanged);
            // 
            // numbericUserTo
            // 
            this.numbericUserTo.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUserTo.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUserTo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericUserTo.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUserTo.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericUserTo.Location = new System.Drawing.Point(161, 4);
            this.numbericUserTo.Macimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numbericUserTo.Margin = new System.Windows.Forms.Padding(4);
            this.numbericUserTo.Maximum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numbericUserTo.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUserTo.Name = "numbericUserTo";
            this.numbericUserTo.NoReadOnly = true;
            this.numbericUserTo.ReadOnly = false;
            this.numbericUserTo.Size = new System.Drawing.Size(150, 103);
            this.numbericUserTo.TabIndex = 1;
            this.numbericUserTo.Title = "До";
            this.numbericUserTo.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericUserTo.VisibleOK = true;
            // 
            // timerStart
            // 
            this.timerStart.Interval = 1000;
            this.timerStart.Tick += new System.EventHandler(this.timerStart_Tick);
            // 
            // buttonTimerTime
            // 
            this.buttonTimerTime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTimerTime.Location = new System.Drawing.Point(381, 59);
            this.buttonTimerTime.Name = "buttonTimerTime";
            this.buttonTimerTime.Size = new System.Drawing.Size(118, 50);
            this.buttonTimerTime.TabIndex = 7;
            this.buttonTimerTime.Text = "Время на таймере";
            this.buttonTimerTime.UseVisualStyleBackColor = true;
            this.buttonTimerTime.Click += new System.EventHandler(this.buttonTimerTime_Click);
            // 
            // SecondMetrForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(847, 653);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "SecondMetrForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Секундомер и таймер";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SecondMetrForm_FormClosed);
            this.Load += new System.EventHandler(this.SecondMetrForm_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericStartSeconds)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericStartMinutes)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericStartHours)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericEndSeconds)).EndInit();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericEndMinutes)).EndInit();
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericEndHours)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericAddMilliSecond)).EndInit();
            this.groupBox10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericAddSecond)).EndInit();
            this.groupBox11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericMinuteAdd)).EndInit();
            this.groupBox12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericAddHour)).EndInit();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericRound)).EndInit();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.menuStrip4.ResumeLayout(false);
            this.menuStrip4.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.TextBox textBoxSecondMetr;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown numericStartHours;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown numericStartMinutes;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown numericStartSeconds;
        private System.Windows.Forms.Button buttonStartNow;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button buttonEndNow;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.NumericUpDown numericEndSeconds;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.NumericUpDown numericEndMinutes;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.NumericUpDown numericEndHours;
        private System.Windows.Forms.Button buttonStartSet;
        private System.Windows.Forms.Button buttonEndSet;
        private System.Windows.Forms.Button buttonStartTime;
        private System.Windows.Forms.Button buttonEndTime;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.NumericUpDown numericAddSecond;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.NumericUpDown numericMinuteAdd;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.NumericUpDown numericAddHour;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonMines;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.ComboBox comboBoxOutput;
        private System.Windows.Forms.TextBox textBoxOutput;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericRound;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.NumericUpDown numericAddMilliSecond;
        private System.Windows.Forms.CheckBox checkBoxFromNow;
        private System.Windows.Forms.CheckBox checkBoxFromStart;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.CheckBox checkBoxPointChange;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Button buttonTimeStart;
        private System.Windows.Forms.TextBox textBoxTimeStart;
        private System.Windows.Forms.Timer timerStart;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private NumbericUser numbericUserStart;
        private NumbericUser numbericUserTo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonSave;
        private System.Windows.Forms.ToolStripMenuItem buttonSavedList;
        private System.Windows.Forms.ToolTip toolTipComboBox;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem ввестиИзВнеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem задатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSetMilliseconds;
        private System.Windows.Forms.ToolStripMenuItem увеличитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddMilliseconds;
        private System.Windows.Forms.ToolStripMenuItem уменьшитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSubMilliseconds;
        private System.Windows.Forms.Button buttonSetResult;
        private System.Windows.Forms.Button buttonResultInput;
        private System.Windows.Forms.ToolStripMenuItem buttonSetSeconds;
        private System.Windows.Forms.ToolStripMenuItem buttonSetMinutes;
        private System.Windows.Forms.ToolStripMenuItem buttonSetHours;
        private System.Windows.Forms.ToolStripMenuItem buttonSecondsAdd;
        private System.Windows.Forms.ToolStripMenuItem buttonMinutesAdd;
        private System.Windows.Forms.ToolStripMenuItem buttonHoursAdd;
        private System.Windows.Forms.ToolStripMenuItem buttonSecondsSub;
        private System.Windows.Forms.ToolStripMenuItem buttonMinutesSub;
        private System.Windows.Forms.ToolStripMenuItem buttonHoursSub;
        private System.Windows.Forms.ToolStripMenuItem buttonSetFullTime;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFullTime;
        private System.Windows.Forms.ToolStripMenuItem buttonSubFullTime;
        private System.Windows.Forms.ToolStripMenuItem buttonSetPlusHours;
        private System.Windows.Forms.ToolStripMenuItem buttonAddPlusHours;
        private System.Windows.Forms.ToolStripMenuItem buttonSubPlusHours;
        private System.Windows.Forms.ToolStripMenuItem buttonHourTimeSet;
        private System.Windows.Forms.ToolStripMenuItem buttonAddHourMinutes;
        private System.Windows.Forms.ToolStripMenuItem buttonSubHourMinutes;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem buttonWrite;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteMain;
        private System.Windows.Forms.MenuStrip menuStrip4;
        private System.Windows.Forms.ToolStripMenuItem записатьВесьТекстToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteText;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteTextMain;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteTextClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonWriteClipboard;
        private System.Windows.Forms.CheckBox checkBoxIsTimer;
        private System.Windows.Forms.Button buttonTimerTime;
    }
}