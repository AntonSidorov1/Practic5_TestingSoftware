﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
//using static System.Net.Mime.MediaTypeNames;

namespace TableAIS
{
    

    public delegate void TimerOutput(SecondDelta delta);
    public delegate void TimerOutput1(string time, Save save);

    public partial class SecondMetrForm : Form
    {

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;


        static List<SecondDelta> secondDeltas;

        public static List<SecondDelta> SecondDeltas
        {
            get => secondDeltas;
            set => secondDeltas = value;
        }

        public SecondMetrForm()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();
            SecondDelta.ChangePoint = true;
            save = Save.None;

            Icon = Properties.Resources.AisTable1;
            

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public SecondMetrForm(Save save):this()
        {
            Save = save;
        }

        public SecondMetrForm(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void SecondMetrForm_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

            comboBoxOutput.Items.AddRange(SecondDelta.Outputs);
            OutputIndex = 0;
        }

        public int OutputIndex
        {
            get
            {
                if(comboBoxOutput.SelectedIndex < 0)
                {
                    comboBoxOutput.SelectedIndex = 0;
                }
                return comboBoxOutput.SelectedIndex;
            }
            set => comboBoxOutput.SelectedIndex = value;
        }

        string messageTimeEnd = "Время вышло";


        private void timerTime_Tick(object sender, EventArgs e)
        {
            buttonStart.Text = started ? "Остановить" : "Запустить";
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();

            if (started)
            {
                if (SecondDelta.IsTimerEnd())
                {
                    started = false;
                    MessageBox.Show(messageTimeEnd, "Время на таймере вышло", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SecondDelta.Clear();
                }
                else
                    SecondDelta.DateEndNow();
            }

            //OutputIndex = SecondDelta.OutputIndex;
            textBoxSecondMetr.Text= SecondDelta.VisulDatasNewLine();
            textBoxOutput.Text = SecondDelta.Output();
            checkBoxPointChange.Checked = SecondDelta.ChangePoint;

            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            try
            {
                buttonTimeStart.Text = startTick ? "Стоп" : "Отложенный запуск";
            }
            catch
            {

            }

            try
            {
                checkBoxIsTimer.Checked = SecondDelta.IsTimer;
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            TimeSpan span = SecondDelta.TimeSpan;
            started = !started;

            if(checkBoxFromStart.Checked && started)
            {
                buttonClear_Click(sender, e);
                return;
            }

            if (checkBoxFromNow.Checked && started)
            {
                SecondDelta.StartMines();
            }
        }

        public void SetInput(string span, bool input)
        {
            try
            {
                TimeSpan span1 = TimeSpan.Parse(span);
                if (input)
                    SecondDelta.StartNowMines(span1);
            }
            catch
            {

            }
        }

        bool started = false;

        private void buttonClear_Click(object sender, EventArgs e)
        {
            
            SecondDelta.Clear();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePickerStart_ValueChanged(object sender, EventArgs e)
        {
            SecondDelta.TimeStart = (sender as DateTimePicker).Value;
        }

        private void buttonStartNow_Click(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            numericStartSeconds.Value = dateTime.Second;
            numericStartMinutes.Value = dateTime.Minute;
            numericStartHours.Value = dateTime.Hour;
        }

        private void buttonEndNow_Click(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            numericEndSeconds.Value = dateTime.Second;
            numericEndMinutes.Value = dateTime.Minute;
            numericEndHours.Value = dateTime.Hour;
        }

        private void buttonStartSet_Click(object sender, EventArgs e)
        {
            int second = (int)numericStartSeconds.Value;
            int minute = (int)numericStartMinutes.Value;
            int hour = (int)numericStartHours.Value;
            DateTime now = DateTime.Now;
            now = new DateTime(now.Year, now.Month, now.Day, hour, minute, second);
            if (now > DateTime.Now)
                now = now.AddDays(-1);
            SecondDelta.TimeStart = now;
        }

        private void buttonEndSet_Click(object sender, EventArgs e)
        {
            int second = (int)numericEndSeconds.Value;
            int minute = (int)numericEndMinutes.Value;
            int hour = (int)numericEndHours.Value;

            DateTime now = DateTime.Now;
            now = new DateTime(now.Year, now.Month, now.Day, hour, minute, second);
            //if (now > DateTime.Now)
            //    now = now.AddDays(-1);
            SecondDelta.TimeEndWithNow(now);
        }

        private void buttonStartTime_Click(object sender, EventArgs e)
        {
            buttonStartNow_Click(sender, e);
            buttonStartSet_Click(sender, e);
        }

        private void buttonEndTime_Click(object sender, EventArgs e)
        {
            buttonEndNow_Click(sender, e);
            buttonEndSet_Click(sender, e);
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            SecondDelta.AddWithNow(numericAddHour.Value, numericMinuteAdd.Value, numericAddSecond.Value, numericAddMilliSecond.Value);
        }

        private void buttonMines_Click(object sender, EventArgs e)
        {
            SecondDelta.MinesWithNow(numericAddHour.Value, numericMinuteAdd.Value, numericAddSecond.Value, numericAddMilliSecond.Value);
        }

        private void SecondMetrForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            timerTime.Stop();
        }

        private void comboBoxOutput_SelectedIndexChanged(object sender, EventArgs e)
        {
            SecondDelta.OutputIndex = OutputIndex;
            numericRound.Value = SecondDelta.GetRound(OutputIndex);
            try
            {
                toolTipComboBox.SetToolTip(comboBoxOutput, SecondDelta.OutputName());
            }
            catch
            {

            }
        }

        private void numericRound_ValueChanged(object sender, EventArgs e)
        {
            SecondDelta.SetRound(OutputIndex, numericRound.Value);
        }

        private void buttonWrite_Click(object sender, EventArgs e)
        {
            MetrOutput?.Invoke(SecondDelta);
            string text = textBoxOutput.Text;
            text = SecondDelta.ChangePoint ? text.Replace(",", ".") : text;
            MetrOutput1?.Invoke(text, Save);
        }

        private void checkBoxPointChange_CheckedChanged(object sender, EventArgs e)
        {
            SecondDelta.ChangePoint = (sender as CheckBox).Checked;
        }

        private void buttonWriteText_Click(object sender, EventArgs e)
        {

            MetrOutput1?.Invoke(textBoxSecondMetr.Text, Save);
        }

        private void buttonTimeStart_Click(object sender, EventArgs e)
        {
            if (!startTick)
            {
                ValueTimerStart = (int)numbericUserStart.Value;
                timerStart_Tick(timerStart, e);
            }
            else
            {
                timerStart.Stop();
                startFew = false;
                numbericUserStart.RunValueChange();
            }
        }

        bool startTick => timerStart.Enabled || startFew;

        public int ValueTimerStart
        {
            get
            {
                try
                {
                    return int.Parse(textBoxTimeStart.Text);
                }
                catch
                {
                    return 5;
                }
            }
            set => textBoxTimeStart.Text = value.ToString();
        }

        bool startFew = false;
        private void timerStart_Tick(object sender, EventArgs e)
        {
            startFew = true;
            (sender as System.Windows.Forms.Timer).Stop();
            int start = ValueTimerStart;
            int end = (int)numbericUserTo.Value;
            if(start > end && startTick)
            {
                ValueTimerStart = start - 1;
                (sender as System.Windows.Forms.Timer).Start();
            }
            else
            {
                ValueTimerStart = (int)numbericUserStart.Value;
                buttonStart_Click(buttonStart, e);
            }
            startFew = false;
        }

        private void numbericUserStart_ValueChanged(object sender, EventArgs e, decimal value)
        {
            if(!startTick)
            {
                ValueTimerStart = (int)value;
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            SecondDelta.OutputIndex = comboBoxOutput.SelectedIndex;
            SecondDelta.Save(SecondDeltas);

            try
            {
                SecondSaved = true;
            }
            catch(Exception ex)
            {

            }
        }

        public static bool SecondSaved;

        FormSecondsSaved formSeconds;

        private void buttonSavedList_Click(object sender, EventArgs e)
        {
            formSeconds = new FormSecondsSaved(SecondDelta);
            formSeconds.MetrOutput1 += FormSeconds_MetrOutput1;
            formSeconds.Show();
        }

        private void FormSeconds_MetrOutput1(string time, Save save)
        {
           MetrOutput1?.Invoke(time, save);
        }

        private void buttonSetMilliseconds_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SetMilliseconds(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        public event Func<double> GetMilliseconds;

        private void buttonAddMilliseconds_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.AddMilliseconds(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonSubMilliseconds_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SubMilliseconds(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonSetResult_Click(object sender, EventArgs e)
        {
            try
            {

                SecondDelta.SetTime(ChangeHour, ChangeMinute, ChangeSecond, ChangeMilliSecond);
            }
            catch (Exception ex) { }
        }

        public int ChangeSecond
        {
            get => (int)numericAddSecond.Value;
            set => numericAddSecond.Value = value;
        }

        public int ChangeMilliSecond
        {
            get => (int)numericAddMilliSecond.Value;
            set => numericAddMilliSecond.Value = value;
        }
        public int ChangeMinute
        {
            get => (int)numericMinuteAdd.Value;
            set => numericMinuteAdd.Value = value;
        }
        public int ChangeHour
        {
            get => (int)numericAddHour.Value;
            set => numericAddHour.Value = value;
        }

        private void buttonResultInput_Click(object sender, EventArgs e)
        {
            try
            {
                ChangeMilliSecond = SecondDelta.MilisecondsDelta;
                ChangeSecond = SecondDelta.SecondsDelta;
                ChangeMinute = SecondDelta.MinutesDelta;
                ChangeHour = SecondDelta.HoursDelta;
            }
            catch
            {

            }
        }

        private void buttonSetSeconds_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SetSeconds(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonSetMinutes_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SetMinutes(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonSetHours_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SetHours(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonSecondsAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.AddSeconds(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonMinutesAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.AddMinutes(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonHoursAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.AddHours(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonSecondsSub_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SubSeconds(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonMinutesSub_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SubMinutes(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonHoursSub_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SubHours(GetMilliseconds?.Invoke() ?? 0);
            }
            catch
            (Exception ex)
            { }
        }

        private void buttonSetFullTime_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SetFull(GetTime?.Invoke());
            }
            catch
            {

            }
        }

        public event Func<string> GetTime;

        private void buttonAddFullTime_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.AddFull(GetTime?.Invoke());
            }
            catch
            {

            }
        }

        private void buttonSubFullTime_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SubFull(GetTime?.Invoke());
            }
            catch
            {

            }
        }

        private void buttonSetPlusHours_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SetPlusHours(GetTime?.Invoke());
            }
            catch
            {

            }
        }

        private void buttonAddPlusHours_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.AddPlusHours(GetTime?.Invoke());
            }
            catch
            {

            }
        }

        private void buttonSubPlusHours_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SubPlusHours(GetTime?.Invoke());
            }
            catch
            {

            }
        }

        private void buttonHourTimeSet_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SetHourMinutes(GetTime?.Invoke());
            }
            catch
            {

            }
        }

        private void buttonAddHourMinutes_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.AddHourMinutes(GetTime?.Invoke());
            }
            catch
            {

            }
        }

        private void buttonSubHourMinutes_Click(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.SubHourMinutes(GetTime?.Invoke());
            }
            catch
            {

            }
        }

        private void buttonWriteMain_Click(object sender, EventArgs e)
        {
            try
            {
                //MetrOutput?.Invoke(SecondDelta);
                string text = textBoxOutput.Text;
                text = SecondDelta.ChangePoint ? text.Replace(",", ".") : text;
                ValueHelper.SetText(text);
            }
            catch { }
        }

        private void buttonWriteTextMain_Click(object sender, EventArgs e)
        {
            try
            {
                ValueHelper.SetText(textBoxSecondMetr.Text);
            }
            catch { }
        }

        private void buttonWriteTextClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBoxSecondMetr.Text);
            }
            catch { }
        }

        private void buttonWriteClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBoxOutput.Text);
            }
            catch { }
        }

        private void checkBoxIsTimer_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                SecondDelta.IsTimer = checkBoxIsTimer.Checked;
            }
            catch { }
        }

        private void buttonTimerTime_Click(object sender, EventArgs e)
        {
            TimerTimeForm form = new TimerTimeForm(SecondDelta);
            form.Show();
        }
    }
}
