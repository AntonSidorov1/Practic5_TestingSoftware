﻿namespace TableAIS
{
    partial class SecurityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SecurityForm));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonSetPermissions = new System.Windows.Forms.Button();
            this.flowResize1 = new TableAIS.FlowResize();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxUDP = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxUDP = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonDefaultUDP = new System.Windows.Forms.Button();
            this.groupBoxTCP = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxTCP = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonDefaultTCP = new System.Windows.Forms.Button();
            this.groupBoxEnternet = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxEnternet = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonEnternetDefault = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxTcpRecive = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxTcpRecive = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonTcpReciveDefault = new System.Windows.Forms.Button();
            this.groupBoxTcpSend = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxTcpSend = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonTcpSendDefault = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxUdpRecive = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxUdpRecive = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonUdpReciveDefault = new System.Windows.Forms.Button();
            this.groupBoxUdpSend = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxUdpSend = new TableAIS.Controls.ComboBoxToolTip();
            this.buttonUdpSendDefault = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.panel2.SuspendLayout();
            this.flowResize1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBoxUDP.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBoxTCP.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBoxEnternet.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.groupBoxTcpRecive.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.groupBoxTcpSend.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.groupBoxUdpRecive.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.groupBoxUdpSend.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(541, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(231, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(801, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(801, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(797, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(424, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.buttonSetPermissions);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 484);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(801, 43);
            this.panel2.TabIndex = 9;
            // 
            // buttonSetPermissions
            // 
            this.buttonSetPermissions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSetPermissions.Location = new System.Drawing.Point(0, 0);
            this.buttonSetPermissions.Name = "buttonSetPermissions";
            this.buttonSetPermissions.Size = new System.Drawing.Size(797, 39);
            this.buttonSetPermissions.TabIndex = 0;
            this.buttonSetPermissions.Text = "Применить";
            this.buttonSetPermissions.UseVisualStyleBackColor = true;
            this.buttonSetPermissions.Click += new System.EventHandler(this.buttonSetPermissions_Click);
            // 
            // flowResize1
            // 
            this.flowResize1.AutoScroll = true;
            this.flowResize1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize1.Controls.Add(this.groupBox1);
            this.flowResize1.Controls.Add(this.groupBox2);
            this.flowResize1.Controls.Add(this.groupBox3);
            this.flowResize1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize1.Location = new System.Drawing.Point(0, 89);
            this.flowResize1.Name = "flowResize1";
            this.flowResize1.Size = new System.Drawing.Size(801, 395);
            this.flowResize1.TabIndex = 10;
            this.flowResize1.WithDelta = 35;
            this.flowResize1.WrapContents = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel2);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(766, 180);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Сетевой обмен";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.groupBoxUDP, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxTCP, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxEnternet, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 159F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(760, 147);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // groupBoxUDP
            // 
            this.groupBoxUDP.Controls.Add(this.tableLayoutPanel5);
            this.groupBoxUDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxUDP.Location = new System.Drawing.Point(509, 3);
            this.groupBoxUDP.Name = "groupBoxUDP";
            this.groupBoxUDP.Size = new System.Drawing.Size(248, 141);
            this.groupBoxUDP.TabIndex = 2;
            this.groupBoxUDP.TabStop = false;
            this.groupBoxUDP.Text = "groupBox2";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.comboBoxUDP, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonDefaultUDP, 0, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(242, 108);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // comboBoxUDP
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.comboBoxUDP, 2);
            this.comboBoxUDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxUDP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUDP.DropDownWidth = 200;
            this.comboBoxUDP.FormattingEnabled = true;
            this.comboBoxUDP.Location = new System.Drawing.Point(3, 3);
            this.comboBoxUDP.Name = "comboBoxUDP";
            this.comboBoxUDP.Size = new System.Drawing.Size(236, 29);
            this.comboBoxUDP.TabIndex = 0;
            // 
            // buttonDefaultUDP
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.buttonDefaultUDP, 2);
            this.buttonDefaultUDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDefaultUDP.Location = new System.Drawing.Point(3, 57);
            this.buttonDefaultUDP.Name = "buttonDefaultUDP";
            this.buttonDefaultUDP.Size = new System.Drawing.Size(236, 48);
            this.buttonDefaultUDP.TabIndex = 1;
            this.buttonDefaultUDP.Text = "Поумолчанию";
            this.buttonDefaultUDP.UseVisualStyleBackColor = true;
            this.buttonDefaultUDP.Click += new System.EventHandler(this.buttonDefaultUDP_Click);
            // 
            // groupBoxTCP
            // 
            this.groupBoxTCP.Controls.Add(this.tableLayoutPanel4);
            this.groupBoxTCP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxTCP.Location = new System.Drawing.Point(256, 3);
            this.groupBoxTCP.Name = "groupBoxTCP";
            this.groupBoxTCP.Size = new System.Drawing.Size(247, 141);
            this.groupBoxTCP.TabIndex = 1;
            this.groupBoxTCP.TabStop = false;
            this.groupBoxTCP.Text = "groupBox2";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.comboBoxTCP, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.buttonDefaultTCP, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(241, 108);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // comboBoxTCP
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.comboBoxTCP, 2);
            this.comboBoxTCP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxTCP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTCP.DropDownWidth = 200;
            this.comboBoxTCP.FormattingEnabled = true;
            this.comboBoxTCP.Location = new System.Drawing.Point(3, 3);
            this.comboBoxTCP.Name = "comboBoxTCP";
            this.comboBoxTCP.Size = new System.Drawing.Size(235, 29);
            this.comboBoxTCP.TabIndex = 0;
            // 
            // buttonDefaultTCP
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.buttonDefaultTCP, 2);
            this.buttonDefaultTCP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDefaultTCP.Location = new System.Drawing.Point(3, 57);
            this.buttonDefaultTCP.Name = "buttonDefaultTCP";
            this.buttonDefaultTCP.Size = new System.Drawing.Size(235, 48);
            this.buttonDefaultTCP.TabIndex = 1;
            this.buttonDefaultTCP.Text = "Поумолчанию";
            this.buttonDefaultTCP.UseVisualStyleBackColor = true;
            this.buttonDefaultTCP.Click += new System.EventHandler(this.buttonDefaultTCP_Click);
            // 
            // groupBoxEnternet
            // 
            this.groupBoxEnternet.Controls.Add(this.tableLayoutPanel3);
            this.groupBoxEnternet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxEnternet.Location = new System.Drawing.Point(3, 3);
            this.groupBoxEnternet.Name = "groupBoxEnternet";
            this.groupBoxEnternet.Size = new System.Drawing.Size(247, 141);
            this.groupBoxEnternet.TabIndex = 0;
            this.groupBoxEnternet.TabStop = false;
            this.groupBoxEnternet.Text = "groupBox2";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.comboBoxEnternet, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonEnternetDefault, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(241, 108);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // comboBoxEnternet
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.comboBoxEnternet, 2);
            this.comboBoxEnternet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEnternet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEnternet.DropDownWidth = 200;
            this.comboBoxEnternet.FormattingEnabled = true;
            this.comboBoxEnternet.Location = new System.Drawing.Point(3, 3);
            this.comboBoxEnternet.Name = "comboBoxEnternet";
            this.comboBoxEnternet.Size = new System.Drawing.Size(235, 29);
            this.comboBoxEnternet.TabIndex = 0;
            this.comboBoxEnternet.MySeclectedIndexChanged += new TableAIS.Controls.MySeclectedIndexChanged(this.comboBoxEnternet_MySeclectedIndexChanged);
            // 
            // buttonEnternetDefault
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.buttonEnternetDefault, 2);
            this.buttonEnternetDefault.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonEnternetDefault.Location = new System.Drawing.Point(3, 57);
            this.buttonEnternetDefault.Name = "buttonEnternetDefault";
            this.buttonEnternetDefault.Size = new System.Drawing.Size(235, 48);
            this.buttonEnternetDefault.TabIndex = 1;
            this.buttonEnternetDefault.Text = "Поумолчанию";
            this.buttonEnternetDefault.UseVisualStyleBackColor = true;
            this.buttonEnternetDefault.Click += new System.EventHandler(this.buttonEnternetDefault_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel6);
            this.groupBox2.Location = new System.Drawing.Point(3, 189);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(766, 157);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Передача по протоколу TCP";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.groupBoxTcpRecive, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.groupBoxTcpSend, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 136F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(760, 124);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // groupBoxTcpRecive
            // 
            this.groupBoxTcpRecive.Controls.Add(this.tableLayoutPanel8);
            this.groupBoxTcpRecive.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxTcpRecive.Location = new System.Drawing.Point(383, 3);
            this.groupBoxTcpRecive.Name = "groupBoxTcpRecive";
            this.groupBoxTcpRecive.Size = new System.Drawing.Size(374, 118);
            this.groupBoxTcpRecive.TabIndex = 2;
            this.groupBoxTcpRecive.TabStop = false;
            this.groupBoxTcpRecive.Text = "groupBox2";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.comboBoxTcpRecive, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.buttonTcpReciveDefault, 0, 1);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(368, 85);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // comboBoxTcpRecive
            // 
            this.tableLayoutPanel8.SetColumnSpan(this.comboBoxTcpRecive, 2);
            this.comboBoxTcpRecive.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxTcpRecive.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTcpRecive.DropDownWidth = 200;
            this.comboBoxTcpRecive.FormattingEnabled = true;
            this.comboBoxTcpRecive.Location = new System.Drawing.Point(3, 3);
            this.comboBoxTcpRecive.Name = "comboBoxTcpRecive";
            this.comboBoxTcpRecive.Size = new System.Drawing.Size(362, 29);
            this.comboBoxTcpRecive.TabIndex = 0;
            // 
            // buttonTcpReciveDefault
            // 
            this.tableLayoutPanel8.SetColumnSpan(this.buttonTcpReciveDefault, 2);
            this.buttonTcpReciveDefault.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTcpReciveDefault.Location = new System.Drawing.Point(3, 45);
            this.buttonTcpReciveDefault.Name = "buttonTcpReciveDefault";
            this.buttonTcpReciveDefault.Size = new System.Drawing.Size(362, 37);
            this.buttonTcpReciveDefault.TabIndex = 1;
            this.buttonTcpReciveDefault.Text = "Поумолчанию";
            this.buttonTcpReciveDefault.UseVisualStyleBackColor = true;
            this.buttonTcpReciveDefault.Click += new System.EventHandler(this.buttonTcpReciveDefault_Click);
            // 
            // groupBoxTcpSend
            // 
            this.groupBoxTcpSend.Controls.Add(this.tableLayoutPanel7);
            this.groupBoxTcpSend.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxTcpSend.Location = new System.Drawing.Point(3, 3);
            this.groupBoxTcpSend.Name = "groupBoxTcpSend";
            this.groupBoxTcpSend.Size = new System.Drawing.Size(374, 118);
            this.groupBoxTcpSend.TabIndex = 1;
            this.groupBoxTcpSend.TabStop = false;
            this.groupBoxTcpSend.Text = "groupBox2";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.comboBoxTcpSend, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonTcpSendDefault, 0, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(368, 85);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // comboBoxTcpSend
            // 
            this.tableLayoutPanel7.SetColumnSpan(this.comboBoxTcpSend, 2);
            this.comboBoxTcpSend.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxTcpSend.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTcpSend.DropDownWidth = 200;
            this.comboBoxTcpSend.FormattingEnabled = true;
            this.comboBoxTcpSend.Location = new System.Drawing.Point(3, 3);
            this.comboBoxTcpSend.Name = "comboBoxTcpSend";
            this.comboBoxTcpSend.Size = new System.Drawing.Size(362, 29);
            this.comboBoxTcpSend.TabIndex = 0;
            // 
            // buttonTcpSendDefault
            // 
            this.tableLayoutPanel7.SetColumnSpan(this.buttonTcpSendDefault, 2);
            this.buttonTcpSendDefault.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTcpSendDefault.Location = new System.Drawing.Point(3, 45);
            this.buttonTcpSendDefault.Name = "buttonTcpSendDefault";
            this.buttonTcpSendDefault.Size = new System.Drawing.Size(362, 37);
            this.buttonTcpSendDefault.TabIndex = 1;
            this.buttonTcpSendDefault.Text = "Поумолчанию";
            this.buttonTcpSendDefault.UseVisualStyleBackColor = true;
            this.buttonTcpSendDefault.Click += new System.EventHandler(this.buttonTcpSendDefault_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel9);
            this.groupBox3.Location = new System.Drawing.Point(3, 352);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(766, 157);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Передача по протоколу UDP";
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.groupBoxUdpRecive, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.groupBoxUdpSend, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 136F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(760, 124);
            this.tableLayoutPanel9.TabIndex = 0;
            // 
            // groupBoxUdpRecive
            // 
            this.groupBoxUdpRecive.Controls.Add(this.tableLayoutPanel10);
            this.groupBoxUdpRecive.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxUdpRecive.Location = new System.Drawing.Point(383, 3);
            this.groupBoxUdpRecive.Name = "groupBoxUdpRecive";
            this.groupBoxUdpRecive.Size = new System.Drawing.Size(374, 118);
            this.groupBoxUdpRecive.TabIndex = 2;
            this.groupBoxUdpRecive.TabStop = false;
            this.groupBoxUdpRecive.Text = "groupBox2";
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Controls.Add(this.comboBoxUdpRecive, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.buttonUdpReciveDefault, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(368, 85);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // comboBoxUdpRecive
            // 
            this.tableLayoutPanel10.SetColumnSpan(this.comboBoxUdpRecive, 2);
            this.comboBoxUdpRecive.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxUdpRecive.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUdpRecive.DropDownWidth = 200;
            this.comboBoxUdpRecive.FormattingEnabled = true;
            this.comboBoxUdpRecive.Location = new System.Drawing.Point(3, 3);
            this.comboBoxUdpRecive.Name = "comboBoxUdpRecive";
            this.comboBoxUdpRecive.Size = new System.Drawing.Size(362, 29);
            this.comboBoxUdpRecive.TabIndex = 0;
            // 
            // buttonUdpReciveDefault
            // 
            this.tableLayoutPanel10.SetColumnSpan(this.buttonUdpReciveDefault, 2);
            this.buttonUdpReciveDefault.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUdpReciveDefault.Location = new System.Drawing.Point(3, 45);
            this.buttonUdpReciveDefault.Name = "buttonUdpReciveDefault";
            this.buttonUdpReciveDefault.Size = new System.Drawing.Size(362, 37);
            this.buttonUdpReciveDefault.TabIndex = 1;
            this.buttonUdpReciveDefault.Text = "Поумолчанию";
            this.buttonUdpReciveDefault.UseVisualStyleBackColor = true;
            this.buttonUdpReciveDefault.Click += new System.EventHandler(this.buttonUdpReciveDefault_Click);
            // 
            // groupBoxUdpSend
            // 
            this.groupBoxUdpSend.Controls.Add(this.tableLayoutPanel11);
            this.groupBoxUdpSend.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxUdpSend.Location = new System.Drawing.Point(3, 3);
            this.groupBoxUdpSend.Name = "groupBoxUdpSend";
            this.groupBoxUdpSend.Size = new System.Drawing.Size(374, 118);
            this.groupBoxUdpSend.TabIndex = 1;
            this.groupBoxUdpSend.TabStop = false;
            this.groupBoxUdpSend.Text = "groupBox2";
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 2;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.comboBoxUdpSend, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.buttonUdpSendDefault, 0, 1);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(368, 85);
            this.tableLayoutPanel11.TabIndex = 0;
            // 
            // comboBoxUdpSend
            // 
            this.tableLayoutPanel11.SetColumnSpan(this.comboBoxUdpSend, 2);
            this.comboBoxUdpSend.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxUdpSend.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUdpSend.DropDownWidth = 200;
            this.comboBoxUdpSend.FormattingEnabled = true;
            this.comboBoxUdpSend.Location = new System.Drawing.Point(3, 3);
            this.comboBoxUdpSend.Name = "comboBoxUdpSend";
            this.comboBoxUdpSend.Size = new System.Drawing.Size(362, 29);
            this.comboBoxUdpSend.TabIndex = 0;
            // 
            // buttonUdpSendDefault
            // 
            this.tableLayoutPanel11.SetColumnSpan(this.buttonUdpSendDefault, 2);
            this.buttonUdpSendDefault.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonUdpSendDefault.Location = new System.Drawing.Point(3, 45);
            this.buttonUdpSendDefault.Name = "buttonUdpSendDefault";
            this.buttonUdpSendDefault.Size = new System.Drawing.Size(362, 37);
            this.buttonUdpSendDefault.TabIndex = 1;
            this.buttonUdpSendDefault.Text = "Поумолчанию";
            this.buttonUdpSendDefault.UseVisualStyleBackColor = true;
            this.buttonUdpSendDefault.Click += new System.EventHandler(this.buttonUdpSendDefault_Click);
            // 
            // SecurityForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(801, 553);
            this.Controls.Add(this.flowResize1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "SecurityForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Безопасность";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.panel2.ResumeLayout(false);
            this.flowResize1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBoxUDP.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.groupBoxTCP.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.groupBoxEnternet.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.groupBoxTcpRecive.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.groupBoxTcpSend.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.groupBoxUdpRecive.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.groupBoxUdpSend.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private FlowResize flowResize1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBoxEnternet;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private Controls.ComboBoxToolTip comboBoxEnternet;
        private System.Windows.Forms.Button buttonEnternetDefault;
        private System.Windows.Forms.GroupBox groupBoxUDP;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private Controls.ComboBoxToolTip comboBoxUDP;
        private System.Windows.Forms.Button buttonDefaultUDP;
        private System.Windows.Forms.GroupBox groupBoxTCP;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private Controls.ComboBoxToolTip comboBoxTCP;
        private System.Windows.Forms.Button buttonDefaultTCP;
        private System.Windows.Forms.Button buttonSetPermissions;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.GroupBox groupBoxTcpRecive;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private Controls.ComboBoxToolTip comboBoxTcpRecive;
        private System.Windows.Forms.Button buttonTcpReciveDefault;
        private System.Windows.Forms.GroupBox groupBoxTcpSend;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private Controls.ComboBoxToolTip comboBoxTcpSend;
        private System.Windows.Forms.Button buttonTcpSendDefault;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.GroupBox groupBoxUdpRecive;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private Controls.ComboBoxToolTip comboBoxUdpRecive;
        private System.Windows.Forms.Button buttonUdpReciveDefault;
        private System.Windows.Forms.GroupBox groupBoxUdpSend;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private Controls.ComboBoxToolTip comboBoxUdpSend;
        private System.Windows.Forms.Button buttonUdpSendDefault;
    }
}