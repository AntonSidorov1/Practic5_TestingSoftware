﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class SecurityForm : Form
    {


        public event Func<string> SetFromMain;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;


        public SecurityForm()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public SecurityForm(Save save):this()
        {
            Save = save;
        }

        public SecurityForm(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        ParamsPermissions enternet, tcp, udp, tcpSend, tcpRecive, udpSend, udpRecive;
        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

             enternet = SecurityHelper.EnternetPermissions;
            groupBoxEnternet.Text = enternet.Name;
            comboBoxEnternet.Items.AddRange(enternet.ToArray());
            comboBoxEnternet.SelectedIndex = enternet.SelectionIndex;

            tcp = SecurityHelper.TcpPermissions;
            groupBoxTCP.Text = tcp.Name;
            comboBoxTCP.Items.AddRange(tcp.ToArray());
            comboBoxTCP.SelectedIndex = tcp.SelectionIndex;

            udp = SecurityHelper.UdpPermissins;
            groupBoxUDP.Text = udp.Name;
            comboBoxUDP.Items.AddRange(udp.ToArray());
            comboBoxUDP.SelectedIndex = udp.SelectionIndex;

            tcpSend = SecurityHelper.TcpSender;
            groupBoxTcpSend.Text = tcpSend.Name;
            comboBoxTcpSend.Items.AddRange(tcpSend.ToArray());
            comboBoxTcpSend.SelectedIndex = tcpSend.SelectionIndex;

            tcpRecive = SecurityHelper.TcpRecipient;
            groupBoxTcpRecive.Text = tcpRecive.Name;
            comboBoxTcpRecive.Items.AddRange(tcpRecive.ToArray());
            comboBoxTcpRecive.SelectedIndex = tcpRecive.SelectionIndex;

            udpSend = SecurityHelper.UdpSender;
            groupBoxUdpSend.Text = udpSend.Name;
            comboBoxUdpSend.Items.AddRange(udpSend.ToArray());
            comboBoxUdpSend.SelectedIndex = udpSend.SelectionIndex;

            udpRecive = SecurityHelper.UdpRecipient;
            groupBoxUdpRecive.Text = udpRecive.Name;
            comboBoxUdpRecive.Items.AddRange(udpRecive.ToArray());
            comboBoxUdpRecive.SelectedIndex = udpRecive.SelectionIndex;





        }

        private void buttonTcpSendDefault_Click(object sender, EventArgs e)
        {
            comboBoxTcpSend.SelectedIndex = 0;
        }

        private void buttonTcpReciveDefault_Click(object sender, EventArgs e)
        {
            comboBoxTcpRecive.SelectedIndex = 0;
        }

        private void buttonUdpSendDefault_Click(object sender, EventArgs e)
        {
            comboBoxUdpSend.SelectedIndex = 0;
        }

        private void buttonUdpReciveDefault_Click(object sender, EventArgs e)
        {
            comboBoxTcpRecive.SelectedIndex=0;
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void buttonDefaultTCP_Click(object sender, EventArgs e)
        {
            comboBoxTCP.SelectedIndex = 0;
        }

        private void buttonDefaultUDP_Click(object sender, EventArgs e)
        {
            comboBoxUDP.SelectedIndex = 0;
        }

        private void buttonSetPermissions_Click(object sender, EventArgs e)
        {
            try
            {
                enternet.SelectionIndex = comboBoxEnternet.SelectedIndex;
                tcp.SelectionIndex = comboBoxTCP.SelectedIndex;
                udp.SelectionIndex = comboBoxUDP.SelectedIndex;
                tcpSend.SelectionIndex = comboBoxTcpSend.SelectedIndex;
                tcpRecive.SelectionIndex = comboBoxTcpRecive.SelectedIndex;
                udpSend.SelectionIndex = comboBoxUdpSend.SelectedIndex;
                udpRecive.SelectionIndex = comboBoxUdpRecive.SelectedIndex;
                SecurityHelper.SavePermissions();
                MessageBox.Show("Настройки безопасности успешно изменены", "Изменение настроек безопасности", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось изменить одну или несколько настроек безопасности", "Изменение настроек безопасности (Ошибка!!!)", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBoxEnternet_MySeclectedIndexChanged(object sender, EventArgs e, Control control, int selectedIndex)
        {
            
        }

        private void buttonEnternetDefault_Click(object sender, EventArgs e)
        {
            comboBoxEnternet.SelectedIndex = 0;
        }
    }
}
