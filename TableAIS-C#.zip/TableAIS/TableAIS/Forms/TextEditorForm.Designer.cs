﻿namespace TableAIS
{
    partial class TextEditorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TextEditorForm));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxValue = new TableAIS.TextBoxWithLine();
            this.checkBoxAutoSave = new System.Windows.Forms.CheckBox();
            this.menuStripEdit = new System.Windows.Forms.MenuStrip();
            this.ввестиИзВнеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromMainFrom = new System.Windows.Forms.ToolStripMenuItem();
            this.вместоВыделенногоТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SetFromMainBySelected = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetTextBySelected = new System.Windows.Forms.ToolStripMenuItem();
            this.относительноВыделенногоТекстаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetSellectedText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetWithoutSell = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetBeforeSell = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetAfterSell = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromClipBoardBySelected = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromTimeBufferBySelected = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromLongBufferBySelected = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddProgramInfoBySelected = new System.Windows.Forms.ToolStripMenuItem();
            this.изТекстовогоФайлаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.секундомеромТаймеромToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.калькуляторомToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изПамятиКалькулятораToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изСпискаЗапомненныхИзмеренийСекундомеромToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectedTextClear = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetFeathersList = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetValueByTextOutput = new System.Windows.Forms.ToolStripMenuItem();
            this.относительноВыделенногоТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetSelectedText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromWithoutBySelected = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetBeforeSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.butonSetReservNames = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetJsonStruct = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromSecondEnd1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddThisText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddClipboardEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromMain = new System.Windows.Forms.ToolStripMenuItem();
            this.относительноВыделенногоТекстаToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddSelectedTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddWithoutSelectedEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddBeforeEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddAfterEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromTimeBufferEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromLongBufferEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddProgramInfoEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromTextFileEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromSecondEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddCalculatorEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcMemoryEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddSecondSavedEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFeathersListEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddOutputEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.butonSetReservNamesEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetJsonStructEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.вставитьВНачалеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddThisStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddClipboardStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromMainStart = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddSelectedTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddWithoutSelectedStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddBeforeStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddAfterStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromTimeBufferStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromLongBufferStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddProgramInfoStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromTextFileStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFromSecondStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddCalculatorStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcMemoryStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddSecondSavedStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddFeathersListStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddOutputStart = new System.Windows.Forms.ToolStripMenuItem();
            this.butonSetReservNamesStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetJsonStructStart = new System.Windows.Forms.ToolStripMenuItem();
            this.вывестисохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWrite = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSaveAllText = new System.Windows.Forms.ToolStripMenuItem();
            this.выделенияТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.выделитьВсёДоВыделенногоФрагментаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectedStartToSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectedStartOutSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.выделитьВсёПослеВыделенногоФрагментаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectedEndToSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectedEndOutSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.переместитьВыделениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonRunSelectLeft1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonRunSelectLeft = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddSelectSymwolLeft = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropSelectSymwolLeft = new System.Windows.Forms.ToolStripMenuItem();
            this.на1СимволВправоToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonRunSelectRight = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddSelectSymwolRight = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDropSelectSymwolRight = new System.Windows.Forms.ToolStripMenuItem();
            this.переместитьНаКоличествоВыделенныхСимволовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.publicRunSellectedCountLeft = new System.Windows.Forms.ToolStripMenuItem();
            this.publicRunSellectedCountRight = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьКоличествоВыделенныхСимволовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.publicAddSellectedCountLeft = new System.Windows.Forms.ToolStripMenuItem();
            this.publicAddSellectedCountRight = new System.Windows.Forms.ToolStripMenuItem();
            this.вБуферОбменаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToTextFile = new System.Windows.Forms.ToolStripMenuItem();
            this.ToTimeBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToSettingsBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDialogForm = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonGetNotification = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonShowToast = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetBallonText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpper = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLower = new System.Windows.Forms.ToolStripMenuItem();
            this.буферОбменаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemBynaryCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynary = new System.Windows.Forms.ToolStripMenuItem();
            this.вместоТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.весьТекстToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynarySelected = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonToBynaryOutSell = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryBefore = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryAfter = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryCodeChoose = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.весьТекстToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryEndSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonToBynaryOutSellEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryBeforeEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryAfterEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddBynaryCodeChooseEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryStart = new System.Windows.Forms.ToolStripMenuItem();
            this.весьТекстToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryStartSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonToBynaryOutSellStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryBeforeStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBynaryAfterStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddBynaryCodeChooseStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynary = new System.Windows.Forms.ToolStripMenuItem();
            this.вместоТекстаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.весьТекстToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynarySelected = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonFromBynaryOutSell = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynaryBefore = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynaryAfter = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynaryCodeCoose = new System.Windows.Forms.ToolStripMenuItem();
            this.вКонцеТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynaryEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynaryEndSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonFromBynaryOutSellEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonFromBynaryBeforeSellEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonFromBynaryAfterSellEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynaryCodeCooseEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonFromBynaryOutSellStart1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynaryStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynaryStartSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonFromBynaryOutSellStart = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonFromBynaryBeforeSellStart = new System.Windows.Forms.ToolStripMenuItem();
            this.bottonFromBynaryAfterSellStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBynaryCodeCooseStart = new System.Windows.Forms.ToolStripMenuItem();
            this.четверичныйКодToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.конвертироватьВЧетверичныйКодToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вместоТекстаToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTextToQuaternaryCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAllTextToQuaternaryCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectTextToQuaternaryCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOutSelectTextToQuaternaryCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOutSelectTextBeforeQuaternaryCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOutSelectTextAfterQuaternaryCode = new System.Windows.Forms.ToolStripMenuItem();
            this.конвертироватьИзЧетверичногоКодаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вместоТекстаToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonQuaternaryCodeToText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonQuaternaryCodeToAllText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonQuaternaryCodeToSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonQuaternaryCodeToOutSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonQuaternaryCodeToBeforeSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonQuaternaryCodeToAfterSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.восьмеричныйКодToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.конвертироватьВВосьмеричныйКодToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вместоТекстаToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTextToOctalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAllTextToOctalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectTextToOctalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOutSelectTextToOctalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBeforeSelectTextToOctalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAfterSelectTextToOctalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.конвертироватьИзВосьмеричногоКодаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вместоТекстаToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOctalCodeToText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOctalCodeToAllText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOctalCodeToSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOctalCodeToOutSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOctalCodeToBeforeSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOctalCodeToAfterSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.шестнадцатиричныйКодToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.конвертироватьВШестнадцатеричныйКодToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вместоТекстаToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTextToHexadecimalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAllTextToHexadecimalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectTextToHexadecimalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOutSelectTextToHexadecimalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBeforeSelectTextToHexadecimalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAfterSelectTextToHexadecimalCode = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTextToHexadecimalCodeEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAllTextToHexadecimalCodeEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectTextToHexadecimalCodeEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOutSelectTextToHexadecimalCodeEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBeforeSelectTextToHexadecimalCodeEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAfterSelectTextToHexadecimalCodeEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTextToHexadecimalCodeStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAllTextToHexadecimalCodeStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectTextToHexadecimalCodeStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOutSelectTextToHexadecimalCodeStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBeforeSelectTextToHexadecimalCodeStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAfterSelectTextToHexadecimalCodeStart = new System.Windows.Forms.ToolStripMenuItem();
            this.конвертироватьИзШестнадцатеричногоКодаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вместоТекстаToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToAllText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToOutSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToBeforeSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToAfterSelectText = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToAllTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToSelectTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToOutSelectTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToBeforeSelectTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToAfterSelectTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToAllTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToSelectTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToOutSelectTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToBeforeSelectTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHexadecimalCodeToAfterSelectTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.перекадировкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToBufferInTextCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromBufferInTextCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClearBufferTextCode = new System.Windows.Forms.ToolStripMenuItem();
            this.исправленияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.переводВВерхнийРегистрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerAllText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerSellectedText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerOutSellectedText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerEndSellectedText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerStartSellectedText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerChooseText = new System.Windows.Forms.ToolStripMenuItem();
            this.вставитьВКонцеТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerAllTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerSellectedTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerOutSellectedTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerStartSellectedTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerEndSellectedTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerChooseTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.вставитьВНачалеТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerAllTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerSellectedTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerOutSellectedTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerStartSellectedTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerEndSellectedTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLowerChooseTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.переводВНижнийРегистрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вставитьВместоТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperAllText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperSellectedText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperOutSellectedText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperEndSellectedText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperStartSellectedText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperChooseText = new System.Windows.Forms.ToolStripMenuItem();
            this.вставитьВКонцеТекстаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperAllTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperSellectedTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperOutSellectedTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperEndSellectedTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperStartSellectedTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperChooseTextEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.вставитьВНачалеТекстаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperAllTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperSellectedTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperOutSellectedTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperEndSellectedTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperStartSellectedTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToUpperChooseTextStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonReplace = new System.Windows.Forms.ToolStripMenuItem();
            this.буферОбменаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAllTextToClipboard1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAllTextToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSelectedTextToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonOutSelectedTextToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAfterSelectToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonBeforeSelectToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonChooseToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.загрузитьИзБуфераОбменаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.дляВсегоТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadAllTextFromClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadAllTextFromClipboardStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadAllTextFromClipboardEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.дляВыделенногоТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadSelectTextFromClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadSelectTextFromClipboardStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadSelectTextFromClipboardEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.дляВывестиСохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadChooseTextFromClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadChooseTextFromClipboardStart = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadChooseTextFromClipboardEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClear = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButtonAllText = new System.Windows.Forms.RadioButton();
            this.checkBoxAutoInput = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxTextCode = new System.Windows.Forms.ComboBox();
            this.notifyIconThis = new System.Windows.Forms.NotifyIcon(this.components);
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.menuStripEdit.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(530, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(223, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(782, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(778, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(413, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 504);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(782, 23);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.textBoxValue, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBoxAutoSave, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.menuStripEdit, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.buttonClear, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBoxAutoInput, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.groupBox2, 0, 2);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(782, 415);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // textBoxValue
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.textBoxValue, 2);
            this.textBoxValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxValue.Location = new System.Drawing.Point(15, 225);
            this.textBoxValue.Margin = new System.Windows.Forms.Padding(15);
            this.textBoxValue.Multiline = true;
            this.textBoxValue.Name = "textBoxValue";
            this.textBoxValue.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxValue.Size = new System.Drawing.Size(752, 175);
            this.textBoxValue.TabIndex = 0;
            this.textBoxValue.TextWithLineBreaks = "";
            this.textBoxValue.Value = "";
            this.textBoxValue.ValueLinesChanged += new TableAIS.ValueLinesChanged(this.textBoxValue_ValueLinesChanged);
            this.textBoxValue.TextChanged += new System.EventHandler(this.textBoxValue_TextChanged);
            // 
            // checkBoxAutoSave
            // 
            this.checkBoxAutoSave.AutoSize = true;
            this.checkBoxAutoSave.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoSave.Location = new System.Drawing.Point(394, 53);
            this.checkBoxAutoSave.Name = "checkBoxAutoSave";
            this.checkBoxAutoSave.Size = new System.Drawing.Size(385, 34);
            this.checkBoxAutoSave.TabIndex = 1;
            this.checkBoxAutoSave.Text = "Автосохранение на главный экран";
            this.checkBoxAutoSave.UseVisualStyleBackColor = true;
            // 
            // menuStripEdit
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.menuStripEdit, 2);
            this.menuStripEdit.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStripEdit.GripMargin = new System.Windows.Forms.Padding(5);
            this.menuStripEdit.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStripEdit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ввестиИзВнеToolStripMenuItem,
            this.вывестисохранитьToolStripMenuItem,
            this.буферОбменаToolStripMenuItem,
            this.исправленияToolStripMenuItem,
            this.буферОбменаToolStripMenuItem1});
            this.menuStripEdit.Location = new System.Drawing.Point(0, 0);
            this.menuStripEdit.Name = "menuStripEdit";
            this.menuStripEdit.Size = new System.Drawing.Size(782, 39);
            this.menuStripEdit.TabIndex = 2;
            this.menuStripEdit.Text = "menuStrip1";
            // 
            // ввестиИзВнеToolStripMenuItem
            // 
            this.ввестиИзВнеToolStripMenuItem.BackColor = System.Drawing.Color.LightGray;
            this.ввестиИзВнеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonFromMainFrom,
            this.вместоВыделенногоТекстаToolStripMenuItem,
            this.buttonAddFromSecondEnd1,
            this.вставитьВНачалеToolStripMenuItem});
            this.ввестиИзВнеToolStripMenuItem.Margin = new System.Windows.Forms.Padding(5);
            this.ввестиИзВнеToolStripMenuItem.Name = "ввестиИзВнеToolStripMenuItem";
            this.ввестиИзВнеToolStripMenuItem.Size = new System.Drawing.Size(81, 25);
            this.ввестиИзВнеToolStripMenuItem.Text = "Ввести";
            // 
            // buttonFromMainFrom
            // 
            this.buttonFromMainFrom.Name = "buttonFromMainFrom";
            this.buttonFromMainFrom.Size = new System.Drawing.Size(251, 26);
            this.buttonFromMainFrom.Text = "С главного экрана";
            this.buttonFromMainFrom.Click += new System.EventHandler(this.buttonFromMainFrom_Click);
            // 
            // вместоВыделенногоТекстаToolStripMenuItem
            // 
            this.вместоВыделенногоТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SetFromMainBySelected,
            this.buttonSetTextBySelected,
            this.относительноВыделенногоТекстаToolStripMenuItem1,
            this.buttonFromClipBoardBySelected,
            this.buttonFromTimeBufferBySelected,
            this.buttonFromLongBufferBySelected,
            this.buttonAddProgramInfoBySelected,
            this.изТекстовогоФайлаToolStripMenuItem,
            this.секундомеромТаймеромToolStripMenuItem,
            this.калькуляторомToolStripMenuItem,
            this.изПамятиКалькулятораToolStripMenuItem,
            this.изСпискаЗапомненныхИзмеренийСекундомеромToolStripMenuItem,
            this.buttonSelectedTextClear,
            this.buttonSetFeathersList,
            this.buttonSetValueByTextOutput,
            this.относительноВыделенногоТекстаToolStripMenuItem,
            this.butonSetReservNames,
            this.buttonSetJsonStruct});
            this.вместоВыделенногоТекстаToolStripMenuItem.Name = "вместоВыделенногоТекстаToolStripMenuItem";
            this.вместоВыделенногоТекстаToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.вместоВыделенногоТекстаToolStripMenuItem.Text = "Вместо текста";
            // 
            // SetFromMainBySelected
            // 
            this.SetFromMainBySelected.Name = "SetFromMainBySelected";
            this.SetFromMainBySelected.Size = new System.Drawing.Size(530, 26);
            this.SetFromMainBySelected.Text = "С главного экрана";
            this.SetFromMainBySelected.Click += new System.EventHandler(this.SetFromMainBySelected_Click);
            // 
            // buttonSetTextBySelected
            // 
            this.buttonSetTextBySelected.Name = "buttonSetTextBySelected";
            this.buttonSetTextBySelected.Size = new System.Drawing.Size(530, 26);
            this.buttonSetTextBySelected.Text = "Весь введённый текст";
            this.buttonSetTextBySelected.Click += new System.EventHandler(this.buttonSetTextBySelected_Click);
            // 
            // относительноВыделенногоТекстаToolStripMenuItem1
            // 
            this.относительноВыделенногоТекстаToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetSellectedText,
            this.buttonSetWithoutSell,
            this.buttonSetBeforeSell,
            this.buttonSetAfterSell});
            this.относительноВыделенногоТекстаToolStripMenuItem1.Name = "относительноВыделенногоТекстаToolStripMenuItem1";
            this.относительноВыделенногоТекстаToolStripMenuItem1.Size = new System.Drawing.Size(530, 26);
            this.относительноВыделенногоТекстаToolStripMenuItem1.Text = "Относительно выделенного текста";
            // 
            // buttonSetSellectedText
            // 
            this.buttonSetSellectedText.Name = "buttonSetSellectedText";
            this.buttonSetSellectedText.Size = new System.Drawing.Size(324, 26);
            this.buttonSetSellectedText.Text = "Выделенный текст";
            this.buttonSetSellectedText.Click += new System.EventHandler(this.buttonSetSellectedText_Click);
            // 
            // buttonSetWithoutSell
            // 
            this.buttonSetWithoutSell.Name = "buttonSetWithoutSell";
            this.buttonSetWithoutSell.Size = new System.Drawing.Size(324, 26);
            this.buttonSetWithoutSell.Text = "Без выделенного текста";
            this.buttonSetWithoutSell.Click += new System.EventHandler(this.buttonSetWithoutSell_Click);
            // 
            // buttonSetBeforeSell
            // 
            this.buttonSetBeforeSell.Name = "buttonSetBeforeSell";
            this.buttonSetBeforeSell.Size = new System.Drawing.Size(324, 26);
            this.buttonSetBeforeSell.Text = "До выделенного текста";
            this.buttonSetBeforeSell.Click += new System.EventHandler(this.buttonSetBeforeSell_Click);
            // 
            // buttonSetAfterSell
            // 
            this.buttonSetAfterSell.Name = "buttonSetAfterSell";
            this.buttonSetAfterSell.Size = new System.Drawing.Size(324, 26);
            this.buttonSetAfterSell.Text = "После выделенного текста";
            this.buttonSetAfterSell.Click += new System.EventHandler(this.buttonSetAfterSell_Click);
            // 
            // buttonFromClipBoardBySelected
            // 
            this.buttonFromClipBoardBySelected.Name = "buttonFromClipBoardBySelected";
            this.buttonFromClipBoardBySelected.Size = new System.Drawing.Size(530, 26);
            this.buttonFromClipBoardBySelected.Text = "Из буфера обмена";
            this.buttonFromClipBoardBySelected.Click += new System.EventHandler(this.buttonFromClipBoardBySelected_Click);
            // 
            // buttonFromTimeBufferBySelected
            // 
            this.buttonFromTimeBufferBySelected.Name = "buttonFromTimeBufferBySelected";
            this.buttonFromTimeBufferBySelected.Size = new System.Drawing.Size(530, 26);
            this.buttonFromTimeBufferBySelected.Text = "Из временного буфера";
            this.buttonFromTimeBufferBySelected.Click += new System.EventHandler(this.buttonFromTimeBufferBySelected_Click);
            // 
            // buttonFromLongBufferBySelected
            // 
            this.buttonFromLongBufferBySelected.Name = "buttonFromLongBufferBySelected";
            this.buttonFromLongBufferBySelected.Size = new System.Drawing.Size(530, 26);
            this.buttonFromLongBufferBySelected.Text = "Из постоянного буфера";
            this.buttonFromLongBufferBySelected.Click += new System.EventHandler(this.buttonFromLongBufferBySelected_Click);
            // 
            // buttonAddProgramInfoBySelected
            // 
            this.buttonAddProgramInfoBySelected.Name = "buttonAddProgramInfoBySelected";
            this.buttonAddProgramInfoBySelected.Size = new System.Drawing.Size(530, 26);
            this.buttonAddProgramInfoBySelected.Text = "Информацию о приложении";
            this.buttonAddProgramInfoBySelected.Click += new System.EventHandler(this.buttonAddProgramInfoBySelected_Click);
            // 
            // изТекстовогоФайлаToolStripMenuItem
            // 
            this.изТекстовогоФайлаToolStripMenuItem.Name = "изТекстовогоФайлаToolStripMenuItem";
            this.изТекстовогоФайлаToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.изТекстовогоФайлаToolStripMenuItem.Text = "Из текстового файла";
            this.изТекстовогоФайлаToolStripMenuItem.Click += new System.EventHandler(this.buttonFromTextFile_Click);
            // 
            // секундомеромТаймеромToolStripMenuItem
            // 
            this.секундомеромТаймеромToolStripMenuItem.Name = "секундомеромТаймеромToolStripMenuItem";
            this.секундомеромТаймеромToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.секундомеромТаймеромToolStripMenuItem.Text = "Секундомером/Таймером";
            this.секундомеромТаймеромToolStripMenuItem.Click += new System.EventHandler(this.buttonFromSecondMetr_Click);
            // 
            // калькуляторомToolStripMenuItem
            // 
            this.калькуляторомToolStripMenuItem.Name = "калькуляторомToolStripMenuItem";
            this.калькуляторомToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.калькуляторомToolStripMenuItem.Text = "Калькулятором";
            this.калькуляторомToolStripMenuItem.Click += new System.EventHandler(this.buttonFromCalculator_Click);
            // 
            // изПамятиКалькулятораToolStripMenuItem
            // 
            this.изПамятиКалькулятораToolStripMenuItem.Name = "изПамятиКалькулятораToolStripMenuItem";
            this.изПамятиКалькулятораToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.изПамятиКалькулятораToolStripMenuItem.Text = "Из памяти калькулятора";
            this.изПамятиКалькулятораToolStripMenuItem.Click += new System.EventHandler(this.buttonFromCalculatorMemory_Click);
            // 
            // изСпискаЗапомненныхИзмеренийСекундомеромToolStripMenuItem
            // 
            this.изСпискаЗапомненныхИзмеренийСекундомеромToolStripMenuItem.Name = "изСпискаЗапомненныхИзмеренийСекундомеромToolStripMenuItem";
            this.изСпискаЗапомненныхИзмеренийСекундомеромToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.изСпискаЗапомненныхИзмеренийСекундомеромToolStripMenuItem.Text = "Из списка запомненных измерений секундомером";
            this.изСпискаЗапомненныхИзмеренийСекундомеромToolStripMenuItem.Click += new System.EventHandler(this.buttonFromSecondsList_Click);
            // 
            // buttonSelectedTextClear
            // 
            this.buttonSelectedTextClear.Name = "buttonSelectedTextClear";
            this.buttonSelectedTextClear.Size = new System.Drawing.Size(530, 26);
            this.buttonSelectedTextClear.Text = "Очистить";
            this.buttonSelectedTextClear.Click += new System.EventHandler(this.buttonSelectedTextClear_Click);
            // 
            // buttonSetFeathersList
            // 
            this.buttonSetFeathersList.Name = "buttonSetFeathersList";
            this.buttonSetFeathersList.Size = new System.Drawing.Size(530, 26);
            this.buttonSetFeathersList.Text = "Список функций приложения";
            this.buttonSetFeathersList.Click += new System.EventHandler(this.buttonSetFeathersList_Click);
            // 
            // buttonSetValueByTextOutput
            // 
            this.buttonSetValueByTextOutput.Name = "buttonSetValueByTextOutput";
            this.buttonSetValueByTextOutput.Size = new System.Drawing.Size(530, 26);
            this.buttonSetValueByTextOutput.Text = "Текст \"Вывести/Сохранить\"";
            this.buttonSetValueByTextOutput.Click += new System.EventHandler(this.buttonSetValueByTextOutput_Click);
            // 
            // относительноВыделенногоТекстаToolStripMenuItem
            // 
            this.относительноВыделенногоТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetSelectedText,
            this.buttonFromWithoutBySelected,
            this.buttonSetBeforeSelected});
            this.относительноВыделенногоТекстаToolStripMenuItem.Name = "относительноВыделенногоТекстаToolStripMenuItem";
            this.относительноВыделенногоТекстаToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.относительноВыделенногоТекстаToolStripMenuItem.Text = "Относительно выделенного текста";
            // 
            // buttonSetSelectedText
            // 
            this.buttonSetSelectedText.Name = "buttonSetSelectedText";
            this.buttonSetSelectedText.Size = new System.Drawing.Size(299, 26);
            this.buttonSetSelectedText.Text = "Выделенный текст";
            this.buttonSetSelectedText.Click += new System.EventHandler(this.buttonSetSelectedText_Click);
            // 
            // buttonFromWithoutBySelected
            // 
            this.buttonFromWithoutBySelected.Name = "buttonFromWithoutBySelected";
            this.buttonFromWithoutBySelected.Size = new System.Drawing.Size(299, 26);
            this.buttonFromWithoutBySelected.Text = "Без выделенного текста";
            this.buttonFromWithoutBySelected.Click += new System.EventHandler(this.buttonFromWithoutBySelected_Click);
            // 
            // buttonSetBeforeSelected
            // 
            this.buttonSetBeforeSelected.Name = "buttonSetBeforeSelected";
            this.buttonSetBeforeSelected.Size = new System.Drawing.Size(299, 26);
            this.buttonSetBeforeSelected.Text = "До выделенного текста";
            this.buttonSetBeforeSelected.Click += new System.EventHandler(this.buttonSetBeforeSelected_Click);
            // 
            // butonSetReservNames
            // 
            this.butonSetReservNames.Name = "butonSetReservNames";
            this.butonSetReservNames.Size = new System.Drawing.Size(530, 26);
            this.butonSetReservNames.Text = "Зарезервированные имена значений";
            this.butonSetReservNames.Click += new System.EventHandler(this.butonSetReservNames_Click);
            // 
            // buttonSetJsonStruct
            // 
            this.buttonSetJsonStruct.Name = "buttonSetJsonStruct";
            this.buttonSetJsonStruct.Size = new System.Drawing.Size(530, 26);
            this.buttonSetJsonStruct.Text = "Json-cтруктура передаваемого текста";
            this.buttonSetJsonStruct.Click += new System.EventHandler(this.buttonSetJsonStruct_Click);
            // 
            // buttonAddFromSecondEnd1
            // 
            this.buttonAddFromSecondEnd1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddThisText,
            this.buttonAddClipboardEnd,
            this.buttonAddFromMain,
            this.относительноВыделенногоТекстаToolStripMenuItem2,
            this.buttonAddFromTimeBufferEnd,
            this.buttonAddFromLongBufferEnd,
            this.buttonAddProgramInfoEnd,
            this.buttonAddFromTextFileEnd,
            this.buttonAddFromSecondEnd,
            this.buttonAddCalculatorEnd,
            this.buttonCalcMemoryEnd,
            this.buttonAddSecondSavedEnd,
            this.buttonAddFeathersListEnd,
            this.buttonAddOutputEnd,
            this.butonSetReservNamesEnd,
            this.buttonSetJsonStructEnd});
            this.buttonAddFromSecondEnd1.Name = "buttonAddFromSecondEnd1";
            this.buttonAddFromSecondEnd1.Size = new System.Drawing.Size(251, 26);
            this.buttonAddFromSecondEnd1.Text = "Вставить в конце";
            // 
            // buttonAddThisText
            // 
            this.buttonAddThisText.Name = "buttonAddThisText";
            this.buttonAddThisText.Size = new System.Drawing.Size(530, 26);
            this.buttonAddThisText.Text = "Введённый текст";
            this.buttonAddThisText.Click += new System.EventHandler(this.buttonAddThisText_Click);
            // 
            // buttonAddClipboardEnd
            // 
            this.buttonAddClipboardEnd.Name = "buttonAddClipboardEnd";
            this.buttonAddClipboardEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonAddClipboardEnd.Text = "Из буфера обмена";
            this.buttonAddClipboardEnd.Click += new System.EventHandler(this.buttonAddClipboardEnd_Click);
            // 
            // buttonAddFromMain
            // 
            this.buttonAddFromMain.Name = "buttonAddFromMain";
            this.buttonAddFromMain.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFromMain.Text = "С главного экрана";
            this.buttonAddFromMain.Click += new System.EventHandler(this.buttonAddFromMain_Click);
            // 
            // относительноВыделенногоТекстаToolStripMenuItem2
            // 
            this.относительноВыделенногоТекстаToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddSelectedTextEnd,
            this.buttonAddWithoutSelectedEnd,
            this.buttonAddBeforeEnd,
            this.buttonAddAfterEnd});
            this.относительноВыделенногоТекстаToolStripMenuItem2.Name = "относительноВыделенногоТекстаToolStripMenuItem2";
            this.относительноВыделенногоТекстаToolStripMenuItem2.Size = new System.Drawing.Size(530, 26);
            this.относительноВыделенногоТекстаToolStripMenuItem2.Text = "Относительно выделенного текста";
            // 
            // buttonAddSelectedTextEnd
            // 
            this.buttonAddSelectedTextEnd.Name = "buttonAddSelectedTextEnd";
            this.buttonAddSelectedTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonAddSelectedTextEnd.Text = "Выделенный текст";
            this.buttonAddSelectedTextEnd.Click += new System.EventHandler(this.buttonAddSelectedTextEnd_Click);
            // 
            // buttonAddWithoutSelectedEnd
            // 
            this.buttonAddWithoutSelectedEnd.Name = "buttonAddWithoutSelectedEnd";
            this.buttonAddWithoutSelectedEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonAddWithoutSelectedEnd.Text = "Без выделенного текста";
            this.buttonAddWithoutSelectedEnd.Click += new System.EventHandler(this.buttonAddWithoutSelectedEnd_Click);
            // 
            // buttonAddBeforeEnd
            // 
            this.buttonAddBeforeEnd.Name = "buttonAddBeforeEnd";
            this.buttonAddBeforeEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonAddBeforeEnd.Text = "До выделенного текста";
            this.buttonAddBeforeEnd.Click += new System.EventHandler(this.buttonAddBeforeEnd_Click);
            // 
            // buttonAddAfterEnd
            // 
            this.buttonAddAfterEnd.Name = "buttonAddAfterEnd";
            this.buttonAddAfterEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonAddAfterEnd.Text = "После выделенного текста";
            this.buttonAddAfterEnd.Click += new System.EventHandler(this.buttonAddAfterEnd_Click);
            // 
            // buttonAddFromTimeBufferEnd
            // 
            this.buttonAddFromTimeBufferEnd.Name = "buttonAddFromTimeBufferEnd";
            this.buttonAddFromTimeBufferEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFromTimeBufferEnd.Text = "Из временного буфера";
            this.buttonAddFromTimeBufferEnd.Click += new System.EventHandler(this.buttonAddFromTimeBufferEnd_Click);
            // 
            // buttonAddFromLongBufferEnd
            // 
            this.buttonAddFromLongBufferEnd.Name = "buttonAddFromLongBufferEnd";
            this.buttonAddFromLongBufferEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFromLongBufferEnd.Text = "Из постоянного буфера";
            this.buttonAddFromLongBufferEnd.Click += new System.EventHandler(this.buttonAddFromLongBufferEnd_Click);
            // 
            // buttonAddProgramInfoEnd
            // 
            this.buttonAddProgramInfoEnd.Name = "buttonAddProgramInfoEnd";
            this.buttonAddProgramInfoEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonAddProgramInfoEnd.Text = "Информацию о приложении";
            this.buttonAddProgramInfoEnd.Click += new System.EventHandler(this.buttonAddProgramInfoEnd_Click);
            // 
            // buttonAddFromTextFileEnd
            // 
            this.buttonAddFromTextFileEnd.Name = "buttonAddFromTextFileEnd";
            this.buttonAddFromTextFileEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFromTextFileEnd.Text = "Из текстового файла";
            this.buttonAddFromTextFileEnd.Click += new System.EventHandler(this.buttonAddFromTextFileEnd_Click);
            // 
            // buttonAddFromSecondEnd
            // 
            this.buttonAddFromSecondEnd.Name = "buttonAddFromSecondEnd";
            this.buttonAddFromSecondEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFromSecondEnd.Text = "Секундомером/Таймером";
            this.buttonAddFromSecondEnd.Click += new System.EventHandler(this.buttonAddFromSecondEnd_Click);
            // 
            // buttonAddCalculatorEnd
            // 
            this.buttonAddCalculatorEnd.Name = "buttonAddCalculatorEnd";
            this.buttonAddCalculatorEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonAddCalculatorEnd.Text = "Калькулятором";
            this.buttonAddCalculatorEnd.Click += new System.EventHandler(this.buttonAddCalculatorEnd_Click);
            // 
            // buttonCalcMemoryEnd
            // 
            this.buttonCalcMemoryEnd.Name = "buttonCalcMemoryEnd";
            this.buttonCalcMemoryEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonCalcMemoryEnd.Text = "Из памяти калькулятора";
            this.buttonCalcMemoryEnd.Click += new System.EventHandler(this.buttonCalcMemoryEnd_Click);
            // 
            // buttonAddSecondSavedEnd
            // 
            this.buttonAddSecondSavedEnd.Name = "buttonAddSecondSavedEnd";
            this.buttonAddSecondSavedEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonAddSecondSavedEnd.Text = "Из списка запомненных измерений секундомером";
            this.buttonAddSecondSavedEnd.Click += new System.EventHandler(this.buttonAddSecondSavedEnd_Click);
            // 
            // buttonAddFeathersListEnd
            // 
            this.buttonAddFeathersListEnd.Name = "buttonAddFeathersListEnd";
            this.buttonAddFeathersListEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFeathersListEnd.Text = "Список функций приложения";
            this.buttonAddFeathersListEnd.Click += new System.EventHandler(this.buttonAddFeathersListEnd_Click);
            // 
            // buttonAddOutputEnd
            // 
            this.buttonAddOutputEnd.Name = "buttonAddOutputEnd";
            this.buttonAddOutputEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonAddOutputEnd.Text = "Текст \"Вывести/Сохранить\"";
            this.buttonAddOutputEnd.Click += new System.EventHandler(this.buttonAddOutputEnd_Click);
            // 
            // butonSetReservNamesEnd
            // 
            this.butonSetReservNamesEnd.Name = "butonSetReservNamesEnd";
            this.butonSetReservNamesEnd.Size = new System.Drawing.Size(530, 26);
            this.butonSetReservNamesEnd.Text = "Зарезервированные имена значений";
            this.butonSetReservNamesEnd.Click += new System.EventHandler(this.butonSetReservNamesEnd_Click);
            // 
            // buttonSetJsonStructEnd
            // 
            this.buttonSetJsonStructEnd.Name = "buttonSetJsonStructEnd";
            this.buttonSetJsonStructEnd.Size = new System.Drawing.Size(530, 26);
            this.buttonSetJsonStructEnd.Text = "Json-cтруктура передаваемого текста";
            this.buttonSetJsonStructEnd.Click += new System.EventHandler(this.buttonSetJsonStructEnd_Click);
            // 
            // вставитьВНачалеToolStripMenuItem
            // 
            this.вставитьВНачалеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddThisStart,
            this.buttonAddClipboardStart,
            this.buttonAddFromMainStart,
            this.toolStripMenuItem1,
            this.buttonAddFromTimeBufferStart,
            this.buttonAddFromLongBufferStart,
            this.buttonAddProgramInfoStart,
            this.buttonAddFromTextFileStart,
            this.buttonAddFromSecondStart,
            this.buttonAddCalculatorStart,
            this.buttonCalcMemoryStart,
            this.buttonAddSecondSavedStart,
            this.buttonAddFeathersListStart,
            this.buttonAddOutputStart,
            this.butonSetReservNamesStart,
            this.buttonSetJsonStructStart});
            this.вставитьВНачалеToolStripMenuItem.Name = "вставитьВНачалеToolStripMenuItem";
            this.вставитьВНачалеToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.вставитьВНачалеToolStripMenuItem.Text = "Вставить в начале";
            // 
            // buttonAddThisStart
            // 
            this.buttonAddThisStart.Name = "buttonAddThisStart";
            this.buttonAddThisStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddThisStart.Text = "Введённый текст";
            this.buttonAddThisStart.Click += new System.EventHandler(this.buttonAddThisStart_Click);
            // 
            // buttonAddClipboardStart
            // 
            this.buttonAddClipboardStart.Name = "buttonAddClipboardStart";
            this.buttonAddClipboardStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddClipboardStart.Text = "Из буфера обмена";
            this.buttonAddClipboardStart.Click += new System.EventHandler(this.buttonAddClipboardStart_Click);
            // 
            // buttonAddFromMainStart
            // 
            this.buttonAddFromMainStart.Name = "buttonAddFromMainStart";
            this.buttonAddFromMainStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFromMainStart.Text = "С главного экрана";
            this.buttonAddFromMainStart.Click += new System.EventHandler(this.buttonAddFromMainStart_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddSelectedTextStart,
            this.buttonAddWithoutSelectedStart,
            this.buttonAddBeforeStart,
            this.buttonAddAfterStart});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(530, 26);
            this.toolStripMenuItem1.Text = "Относительно выделенного текста";
            // 
            // buttonAddSelectedTextStart
            // 
            this.buttonAddSelectedTextStart.Name = "buttonAddSelectedTextStart";
            this.buttonAddSelectedTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonAddSelectedTextStart.Text = "Выделенный текст";
            this.buttonAddSelectedTextStart.Click += new System.EventHandler(this.buttonAddSelectedTextStart_Click);
            // 
            // buttonAddWithoutSelectedStart
            // 
            this.buttonAddWithoutSelectedStart.Name = "buttonAddWithoutSelectedStart";
            this.buttonAddWithoutSelectedStart.Size = new System.Drawing.Size(324, 26);
            this.buttonAddWithoutSelectedStart.Text = "Без выделенного текста";
            this.buttonAddWithoutSelectedStart.Click += new System.EventHandler(this.buttonAddWithoutSelectedStart_Click);
            // 
            // buttonAddBeforeStart
            // 
            this.buttonAddBeforeStart.Name = "buttonAddBeforeStart";
            this.buttonAddBeforeStart.Size = new System.Drawing.Size(324, 26);
            this.buttonAddBeforeStart.Text = "До выделенного текста";
            this.buttonAddBeforeStart.Click += new System.EventHandler(this.buttonAddBeforeStart_Click);
            // 
            // buttonAddAfterStart
            // 
            this.buttonAddAfterStart.Name = "buttonAddAfterStart";
            this.buttonAddAfterStart.Size = new System.Drawing.Size(324, 26);
            this.buttonAddAfterStart.Text = "После выделенного текста";
            this.buttonAddAfterStart.Click += new System.EventHandler(this.buttonAddAfterStart_Click);
            // 
            // buttonAddFromTimeBufferStart
            // 
            this.buttonAddFromTimeBufferStart.Name = "buttonAddFromTimeBufferStart";
            this.buttonAddFromTimeBufferStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFromTimeBufferStart.Text = "Из временного буфера";
            this.buttonAddFromTimeBufferStart.Click += new System.EventHandler(this.buttonAddFromTimeBufferStart_Click);
            // 
            // buttonAddFromLongBufferStart
            // 
            this.buttonAddFromLongBufferStart.Name = "buttonAddFromLongBufferStart";
            this.buttonAddFromLongBufferStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFromLongBufferStart.Text = "Из постоянного буфера";
            this.buttonAddFromLongBufferStart.Click += new System.EventHandler(this.buttonAddFromLongBufferStart_Click);
            // 
            // buttonAddProgramInfoStart
            // 
            this.buttonAddProgramInfoStart.Name = "buttonAddProgramInfoStart";
            this.buttonAddProgramInfoStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddProgramInfoStart.Text = "Информацию о приложении";
            this.buttonAddProgramInfoStart.Click += new System.EventHandler(this.buttonAddProgramInfoStart_Click);
            // 
            // buttonAddFromTextFileStart
            // 
            this.buttonAddFromTextFileStart.Name = "buttonAddFromTextFileStart";
            this.buttonAddFromTextFileStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFromTextFileStart.Text = "Из текстового файла";
            this.buttonAddFromTextFileStart.Click += new System.EventHandler(this.buttonAddFromTextFileStart_Click);
            // 
            // buttonAddFromSecondStart
            // 
            this.buttonAddFromSecondStart.Name = "buttonAddFromSecondStart";
            this.buttonAddFromSecondStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFromSecondStart.Text = "Секундомером/Таймером";
            this.buttonAddFromSecondStart.Click += new System.EventHandler(this.buttonAddFromSecondStart_Click);
            // 
            // buttonAddCalculatorStart
            // 
            this.buttonAddCalculatorStart.Name = "buttonAddCalculatorStart";
            this.buttonAddCalculatorStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddCalculatorStart.Text = "Калькулятором";
            this.buttonAddCalculatorStart.Click += new System.EventHandler(this.buttonAddCalculatorStart_Click);
            // 
            // buttonCalcMemoryStart
            // 
            this.buttonCalcMemoryStart.Name = "buttonCalcMemoryStart";
            this.buttonCalcMemoryStart.Size = new System.Drawing.Size(530, 26);
            this.buttonCalcMemoryStart.Text = "Из памяти калькулятора";
            this.buttonCalcMemoryStart.Click += new System.EventHandler(this.buttonCalcMemoryStart_Click);
            // 
            // buttonAddSecondSavedStart
            // 
            this.buttonAddSecondSavedStart.Name = "buttonAddSecondSavedStart";
            this.buttonAddSecondSavedStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddSecondSavedStart.Text = "Из списка запомненных измерений секундомером";
            this.buttonAddSecondSavedStart.Click += new System.EventHandler(this.buttonAddSecondSavedStart_Click);
            // 
            // buttonAddFeathersListStart
            // 
            this.buttonAddFeathersListStart.Name = "buttonAddFeathersListStart";
            this.buttonAddFeathersListStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddFeathersListStart.Text = "Список функций приложения";
            this.buttonAddFeathersListStart.Click += new System.EventHandler(this.buttonAddFeathersListStart_Click);
            // 
            // buttonAddOutputStart
            // 
            this.buttonAddOutputStart.Name = "buttonAddOutputStart";
            this.buttonAddOutputStart.Size = new System.Drawing.Size(530, 26);
            this.buttonAddOutputStart.Text = "Текст \"Вывести/Сохранить\"";
            this.buttonAddOutputStart.Click += new System.EventHandler(this.buttonAddOutputEnd_Click);
            // 
            // butonSetReservNamesStart
            // 
            this.butonSetReservNamesStart.Name = "butonSetReservNamesStart";
            this.butonSetReservNamesStart.Size = new System.Drawing.Size(530, 26);
            this.butonSetReservNamesStart.Text = "Зарезервированные имена значений";
            this.butonSetReservNamesStart.Click += new System.EventHandler(this.butonSetReservNamesStart_Click);
            // 
            // buttonSetJsonStructStart
            // 
            this.buttonSetJsonStructStart.Name = "buttonSetJsonStructStart";
            this.buttonSetJsonStructStart.Size = new System.Drawing.Size(530, 26);
            this.buttonSetJsonStructStart.Text = "Json-cтруктура передаваемого текста";
            this.buttonSetJsonStructStart.Click += new System.EventHandler(this.buttonSetJsonStructStart_Click);
            // 
            // вывестисохранитьToolStripMenuItem
            // 
            this.вывестисохранитьToolStripMenuItem.BackColor = System.Drawing.Color.LightGray;
            this.вывестисохранитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonWrite,
            this.buttonSaveAllText,
            this.выделенияТекстаToolStripMenuItem,
            this.вБуферОбменаToolStripMenuItem,
            this.buttonToTextFile,
            this.ToTimeBuffer,
            this.buttonToSettingsBuffer,
            this.buttonDialogForm,
            this.buttonGetNotification,
            this.buttonShowToast,
            this.buttonSetBallonText,
            this.buttonToUpper,
            this.buttonToLower});
            this.вывестисохранитьToolStripMenuItem.Margin = new System.Windows.Forms.Padding(5);
            this.вывестисохранитьToolStripMenuItem.Name = "вывестисохранитьToolStripMenuItem";
            this.вывестисохранитьToolStripMenuItem.Size = new System.Drawing.Size(191, 25);
            this.вывестисохранитьToolStripMenuItem.Text = "Вывести/сохранить";
            // 
            // buttonWrite
            // 
            this.buttonWrite.Name = "buttonWrite";
            this.buttonWrite.Size = new System.Drawing.Size(414, 26);
            this.buttonWrite.Text = "Записать на главный экран";
            this.buttonWrite.Click += new System.EventHandler(this.buttonWrite_Click);
            // 
            // buttonSaveAllText
            // 
            this.buttonSaveAllText.Name = "buttonSaveAllText";
            this.buttonSaveAllText.Size = new System.Drawing.Size(414, 26);
            this.buttonSaveAllText.Text = "Записать на главный экран весь текст";
            this.buttonSaveAllText.Click += new System.EventHandler(this.buttonSaveAllText_Click);
            // 
            // выделенияТекстаToolStripMenuItem
            // 
            this.выделенияТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSelectText,
            this.buttonDropSelected,
            this.выделитьВсёДоВыделенногоФрагментаToolStripMenuItem,
            this.выделитьВсёПослеВыделенногоФрагментаToolStripMenuItem,
            this.переместитьВыделениеToolStripMenuItem,
            this.переместитьНаКоличествоВыделенныхСимволовToolStripMenuItem,
            this.добавитьКоличествоВыделенныхСимволовToolStripMenuItem});
            this.выделенияТекстаToolStripMenuItem.Name = "выделенияТекстаToolStripMenuItem";
            this.выделенияТекстаToolStripMenuItem.Size = new System.Drawing.Size(414, 26);
            this.выделенияТекстаToolStripMenuItem.Text = "Выделения текста";
            // 
            // buttonSelectText
            // 
            this.buttonSelectText.Name = "buttonSelectText";
            this.buttonSelectText.Size = new System.Drawing.Size(530, 26);
            this.buttonSelectText.Text = "Выделить весь текст";
            this.buttonSelectText.Click += new System.EventHandler(this.buttonSelectText_Click);
            // 
            // buttonDropSelected
            // 
            this.buttonDropSelected.Name = "buttonDropSelected";
            this.buttonDropSelected.Size = new System.Drawing.Size(530, 26);
            this.buttonDropSelected.Text = "Снять все выделения";
            this.buttonDropSelected.Click += new System.EventHandler(this.buttonDropSelected_Click);
            // 
            // выделитьВсёДоВыделенногоФрагментаToolStripMenuItem
            // 
            this.выделитьВсёДоВыделенногоФрагментаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSelectedStartToSelected,
            this.buttonSelectedStartOutSelected});
            this.выделитьВсёДоВыделенногоФрагментаToolStripMenuItem.Name = "выделитьВсёДоВыделенногоФрагментаToolStripMenuItem";
            this.выделитьВсёДоВыделенногоФрагментаToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.выделитьВсёДоВыделенногоФрагментаToolStripMenuItem.Text = "Выделить всё до выделенного фрагмента";
            // 
            // buttonSelectedStartToSelected
            // 
            this.buttonSelectedStartToSelected.Name = "buttonSelectedStartToSelected";
            this.buttonSelectedStartToSelected.Size = new System.Drawing.Size(399, 26);
            this.buttonSelectedStartToSelected.Text = "Включить выделенный фрагмент";
            this.buttonSelectedStartToSelected.Click += new System.EventHandler(this.buttonSelectedStartToSelected_Click);
            // 
            // buttonSelectedStartOutSelected
            // 
            this.buttonSelectedStartOutSelected.Name = "buttonSelectedStartOutSelected";
            this.buttonSelectedStartOutSelected.Size = new System.Drawing.Size(399, 26);
            this.buttonSelectedStartOutSelected.Text = "Не включать выделенный фрагмент";
            this.buttonSelectedStartOutSelected.Click += new System.EventHandler(this.buttonSelectedStartOutSelected_Click);
            // 
            // выделитьВсёПослеВыделенногоФрагментаToolStripMenuItem
            // 
            this.выделитьВсёПослеВыделенногоФрагментаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSelectedEndToSelected,
            this.buttonSelectedEndOutSelected});
            this.выделитьВсёПослеВыделенногоФрагментаToolStripMenuItem.Name = "выделитьВсёПослеВыделенногоФрагментаToolStripMenuItem";
            this.выделитьВсёПослеВыделенногоФрагментаToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.выделитьВсёПослеВыделенногоФрагментаToolStripMenuItem.Text = "Выделить всё после выделенного фрагмента";
            // 
            // buttonSelectedEndToSelected
            // 
            this.buttonSelectedEndToSelected.Name = "buttonSelectedEndToSelected";
            this.buttonSelectedEndToSelected.Size = new System.Drawing.Size(399, 26);
            this.buttonSelectedEndToSelected.Text = "Включить выделенный фрагмент";
            this.buttonSelectedEndToSelected.Click += new System.EventHandler(this.buttonSelectedEndToSelected_Click);
            // 
            // buttonSelectedEndOutSelected
            // 
            this.buttonSelectedEndOutSelected.Name = "buttonSelectedEndOutSelected";
            this.buttonSelectedEndOutSelected.Size = new System.Drawing.Size(399, 26);
            this.buttonSelectedEndOutSelected.Text = "Не включать выделенный фрагмент";
            this.buttonSelectedEndOutSelected.Click += new System.EventHandler(this.buttonSelectedEndOutSelected_Click);
            // 
            // переместитьВыделениеToolStripMenuItem
            // 
            this.переместитьВыделениеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonRunSelectLeft1,
            this.на1СимволВправоToolStripMenuItem});
            this.переместитьВыделениеToolStripMenuItem.Name = "переместитьВыделениеToolStripMenuItem";
            this.переместитьВыделениеToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.переместитьВыделениеToolStripMenuItem.Text = "Переместить выделение на 1 символ";
            // 
            // buttonRunSelectLeft1
            // 
            this.buttonRunSelectLeft1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonRunSelectLeft,
            this.buttonAddSelectSymwolLeft,
            this.buttonDropSelectSymwolLeft});
            this.buttonRunSelectLeft1.Name = "buttonRunSelectLeft1";
            this.buttonRunSelectLeft1.Size = new System.Drawing.Size(155, 26);
            this.buttonRunSelectLeft1.Text = "Влево";
            // 
            // buttonRunSelectLeft
            // 
            this.buttonRunSelectLeft.Name = "buttonRunSelectLeft";
            this.buttonRunSelectLeft.Size = new System.Drawing.Size(446, 26);
            this.buttonRunSelectLeft.Text = "Всё выделение";
            this.buttonRunSelectLeft.Click += new System.EventHandler(this.buttonRunSelectLeft_Click);
            // 
            // buttonAddSelectSymwolLeft
            // 
            this.buttonAddSelectSymwolLeft.Name = "buttonAddSelectSymwolLeft";
            this.buttonAddSelectSymwolLeft.Size = new System.Drawing.Size(446, 26);
            this.buttonAddSelectSymwolLeft.Text = "Добавить 1 выделенный символ в начале";
            this.buttonAddSelectSymwolLeft.Click += new System.EventHandler(this.buttonAddSelectSymwolLeft_Click);
            // 
            // buttonDropSelectSymwolLeft
            // 
            this.buttonDropSelectSymwolLeft.Name = "buttonDropSelectSymwolLeft";
            this.buttonDropSelectSymwolLeft.Size = new System.Drawing.Size(446, 26);
            this.buttonDropSelectSymwolLeft.Text = "Убрать 1 выделенный символ в конце";
            this.buttonDropSelectSymwolLeft.Click += new System.EventHandler(this.buttonDropSelectSymwolLeft_Click);
            // 
            // на1СимволВправоToolStripMenuItem
            // 
            this.на1СимволВправоToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonRunSelectRight,
            this.buttonAddSelectSymwolRight,
            this.buttonDropSelectSymwolRight});
            this.на1СимволВправоToolStripMenuItem.Name = "на1СимволВправоToolStripMenuItem";
            this.на1СимволВправоToolStripMenuItem.Size = new System.Drawing.Size(155, 26);
            this.на1СимволВправоToolStripMenuItem.Text = "Вправо";
            // 
            // buttonRunSelectRight
            // 
            this.buttonRunSelectRight.Name = "buttonRunSelectRight";
            this.buttonRunSelectRight.Size = new System.Drawing.Size(440, 26);
            this.buttonRunSelectRight.Text = "Всё выделение";
            this.buttonRunSelectRight.Click += new System.EventHandler(this.buttonRunSelectRight_Click);
            // 
            // buttonAddSelectSymwolRight
            // 
            this.buttonAddSelectSymwolRight.Name = "buttonAddSelectSymwolRight";
            this.buttonAddSelectSymwolRight.Size = new System.Drawing.Size(440, 26);
            this.buttonAddSelectSymwolRight.Text = "Добавить 1 выделенный символ в конце";
            this.buttonAddSelectSymwolRight.Click += new System.EventHandler(this.buttonAddSelectSymwolRight_Click);
            // 
            // buttonDropSelectSymwolRight
            // 
            this.buttonDropSelectSymwolRight.Name = "buttonDropSelectSymwolRight";
            this.buttonDropSelectSymwolRight.Size = new System.Drawing.Size(440, 26);
            this.buttonDropSelectSymwolRight.Text = "Убрать 1 выделенный символ в начале";
            this.buttonDropSelectSymwolRight.Click += new System.EventHandler(this.buttonDropSelectSymwolRight_Click);
            // 
            // переместитьНаКоличествоВыделенныхСимволовToolStripMenuItem
            // 
            this.переместитьНаКоличествоВыделенныхСимволовToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.publicRunSellectedCountLeft,
            this.publicRunSellectedCountRight});
            this.переместитьНаКоличествоВыделенныхСимволовToolStripMenuItem.Name = "переместитьНаКоличествоВыделенныхСимволовToolStripMenuItem";
            this.переместитьНаКоличествоВыделенныхСимволовToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.переместитьНаКоличествоВыделенныхСимволовToolStripMenuItem.Text = "Переместить на количество выделенных символов";
            // 
            // publicRunSellectedCountLeft
            // 
            this.publicRunSellectedCountLeft.Name = "publicRunSellectedCountLeft";
            this.publicRunSellectedCountLeft.Size = new System.Drawing.Size(155, 26);
            this.publicRunSellectedCountLeft.Text = "Влево";
            this.publicRunSellectedCountLeft.Click += new System.EventHandler(this.publicRunSellectedCountLeft_Click);
            // 
            // publicRunSellectedCountRight
            // 
            this.publicRunSellectedCountRight.Name = "publicRunSellectedCountRight";
            this.publicRunSellectedCountRight.Size = new System.Drawing.Size(155, 26);
            this.publicRunSellectedCountRight.Text = "Вправо";
            this.publicRunSellectedCountRight.Click += new System.EventHandler(this.publicRunSellectedCountRight_Click);
            // 
            // добавитьКоличествоВыделенныхСимволовToolStripMenuItem
            // 
            this.добавитьКоличествоВыделенныхСимволовToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.publicAddSellectedCountLeft,
            this.publicAddSellectedCountRight});
            this.добавитьКоличествоВыделенныхСимволовToolStripMenuItem.Name = "добавитьКоличествоВыделенныхСимволовToolStripMenuItem";
            this.добавитьКоличествоВыделенныхСимволовToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.добавитьКоличествоВыделенныхСимволовToolStripMenuItem.Text = "Добавить количество выделенных символов";
            // 
            // publicAddSellectedCountLeft
            // 
            this.publicAddSellectedCountLeft.Name = "publicAddSellectedCountLeft";
            this.publicAddSellectedCountLeft.Size = new System.Drawing.Size(155, 26);
            this.publicAddSellectedCountLeft.Text = "Слева";
            this.publicAddSellectedCountLeft.Click += new System.EventHandler(this.publicAddSellectedCountLeft_Click);
            // 
            // publicAddSellectedCountRight
            // 
            this.publicAddSellectedCountRight.Name = "publicAddSellectedCountRight";
            this.publicAddSellectedCountRight.Size = new System.Drawing.Size(155, 26);
            this.publicAddSellectedCountRight.Text = "Справа";
            this.publicAddSellectedCountRight.Click += new System.EventHandler(this.publicAddSellectedCountRight_Click);
            // 
            // вБуферОбменаToolStripMenuItem
            // 
            this.вБуферОбменаToolStripMenuItem.Name = "вБуферОбменаToolStripMenuItem";
            this.вБуферОбменаToolStripMenuItem.Size = new System.Drawing.Size(414, 26);
            this.вБуферОбменаToolStripMenuItem.Text = "В буфер обмена";
            this.вБуферОбменаToolStripMenuItem.Click += new System.EventHandler(this.buttonToClipBoard_Click);
            // 
            // buttonToTextFile
            // 
            this.buttonToTextFile.Name = "buttonToTextFile";
            this.buttonToTextFile.Size = new System.Drawing.Size(414, 26);
            this.buttonToTextFile.Text = "В текстовый файл";
            this.buttonToTextFile.Click += new System.EventHandler(this.buttonToTextFile_Click);
            // 
            // ToTimeBuffer
            // 
            this.ToTimeBuffer.Name = "ToTimeBuffer";
            this.ToTimeBuffer.Size = new System.Drawing.Size(414, 26);
            this.ToTimeBuffer.Text = "Во временный буфер";
            this.ToTimeBuffer.Click += new System.EventHandler(this.ToTimeBuffer_Click);
            // 
            // buttonToSettingsBuffer
            // 
            this.buttonToSettingsBuffer.Name = "buttonToSettingsBuffer";
            this.buttonToSettingsBuffer.Size = new System.Drawing.Size(414, 26);
            this.buttonToSettingsBuffer.Text = "В постоянный буфер";
            this.buttonToSettingsBuffer.Click += new System.EventHandler(this.buttonToSettingsBuffer_Click);
            // 
            // buttonDialogForm
            // 
            this.buttonDialogForm.Name = "buttonDialogForm";
            this.buttonDialogForm.Size = new System.Drawing.Size(414, 26);
            this.buttonDialogForm.Text = "Диалоговым окном";
            this.buttonDialogForm.Click += new System.EventHandler(this.buttonDialogForm_Click);
            // 
            // buttonGetNotification
            // 
            this.buttonGetNotification.Name = "buttonGetNotification";
            this.buttonGetNotification.Size = new System.Drawing.Size(414, 26);
            this.buttonGetNotification.Text = "Уведомлением";
            this.buttonGetNotification.Click += new System.EventHandler(this.buttonGetNotification_Click);
            // 
            // buttonShowToast
            // 
            this.buttonShowToast.Name = "buttonShowToast";
            this.buttonShowToast.Size = new System.Drawing.Size(414, 26);
            this.buttonShowToast.Text = "Всплывающим сообщением";
            this.buttonShowToast.Click += new System.EventHandler(this.buttonShowToast_Click);
            // 
            // buttonSetBallonText
            // 
            this.buttonSetBallonText.Name = "buttonSetBallonText";
            this.buttonSetBallonText.Size = new System.Drawing.Size(414, 26);
            this.buttonSetBallonText.Text = "Всплывающей подсказкой";
            this.buttonSetBallonText.Click += new System.EventHandler(this.buttonSetBallonText_Click);
            // 
            // buttonToUpper
            // 
            this.buttonToUpper.Name = "buttonToUpper";
            this.buttonToUpper.Size = new System.Drawing.Size(414, 26);
            this.buttonToUpper.Text = "Перевести в верхний регистр";
            this.buttonToUpper.Click += new System.EventHandler(this.buttonToUpper_Click);
            // 
            // buttonToLower
            // 
            this.buttonToLower.Name = "buttonToLower";
            this.buttonToLower.Size = new System.Drawing.Size(414, 26);
            this.buttonToLower.Text = "Перевести в нижний регистр";
            this.buttonToLower.Click += new System.EventHandler(this.buttonToLower_Click);
            // 
            // буферОбменаToolStripMenuItem
            // 
            this.буферОбменаToolStripMenuItem.BackColor = System.Drawing.Color.LightGray;
            this.буферОбменаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itemBynaryCode,
            this.четверичныйКодToolStripMenuItem,
            this.восьмеричныйКодToolStripMenuItem,
            this.шестнадцатиричныйКодToolStripMenuItem,
            this.перекадировкаToolStripMenuItem});
            this.буферОбменаToolStripMenuItem.Margin = new System.Windows.Forms.Padding(5);
            this.буферОбменаToolStripMenuItem.Name = "буферОбменаToolStripMenuItem";
            this.буферОбменаToolStripMenuItem.Size = new System.Drawing.Size(139, 25);
            this.буферОбменаToolStripMenuItem.Text = "Кодирование";
            // 
            // itemBynaryCode
            // 
            this.itemBynaryCode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToBynary,
            this.buttonFromBynary});
            this.itemBynaryCode.Name = "itemBynaryCode";
            this.itemBynaryCode.Size = new System.Drawing.Size(308, 26);
            this.itemBynaryCode.Text = "Двоичный код";
            // 
            // buttonToBynary
            // 
            this.buttonToBynary.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вместоТекстаToolStripMenuItem,
            this.buttonToBynaryEnd,
            this.buttonToBynaryStart});
            this.buttonToBynary.Name = "buttonToBynary";
            this.buttonToBynary.Size = new System.Drawing.Size(398, 26);
            this.buttonToBynary.Text = "Конвертировать в двоичный код";
            // 
            // вместоТекстаToolStripMenuItem
            // 
            this.вместоТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.весьТекстToolStripMenuItem,
            this.buttonToBynarySelected,
            this.bottonToBynaryOutSell,
            this.buttonToBynaryBefore,
            this.buttonToBynaryAfter,
            this.buttonToBynaryCodeChoose});
            this.вместоТекстаToolStripMenuItem.Name = "вместоТекстаToolStripMenuItem";
            this.вместоТекстаToolStripMenuItem.Size = new System.Drawing.Size(225, 26);
            this.вместоТекстаToolStripMenuItem.Text = "Вместо текста";
            this.вместоТекстаToolStripMenuItem.Click += new System.EventHandler(this.вместоТекстаToolStripMenuItem_Click);
            // 
            // весьТекстToolStripMenuItem
            // 
            this.весьТекстToolStripMenuItem.Name = "весьТекстToolStripMenuItem";
            this.весьТекстToolStripMenuItem.Size = new System.Drawing.Size(324, 26);
            this.весьТекстToolStripMenuItem.Text = "Весь текст";
            this.весьТекстToolStripMenuItem.Click += new System.EventHandler(this.buttonToBynary_Click);
            // 
            // buttonToBynarySelected
            // 
            this.buttonToBynarySelected.Name = "buttonToBynarySelected";
            this.buttonToBynarySelected.Size = new System.Drawing.Size(324, 26);
            this.buttonToBynarySelected.Text = "Выделенный текст";
            this.buttonToBynarySelected.Click += new System.EventHandler(this.buttonToBynarySelected_Click);
            // 
            // bottonToBynaryOutSell
            // 
            this.bottonToBynaryOutSell.Name = "bottonToBynaryOutSell";
            this.bottonToBynaryOutSell.Size = new System.Drawing.Size(324, 26);
            this.bottonToBynaryOutSell.Text = "Без выделенного текста";
            this.bottonToBynaryOutSell.Click += new System.EventHandler(this.bottonToBynaryOutSell_Click);
            // 
            // buttonToBynaryBefore
            // 
            this.buttonToBynaryBefore.Name = "buttonToBynaryBefore";
            this.buttonToBynaryBefore.Size = new System.Drawing.Size(324, 26);
            this.buttonToBynaryBefore.Text = "До выделенного текста";
            this.buttonToBynaryBefore.Click += new System.EventHandler(this.buttonToBynaryBefore_Click);
            // 
            // buttonToBynaryAfter
            // 
            this.buttonToBynaryAfter.Name = "buttonToBynaryAfter";
            this.buttonToBynaryAfter.Size = new System.Drawing.Size(324, 26);
            this.buttonToBynaryAfter.Text = "После выделенного текста";
            this.buttonToBynaryAfter.Click += new System.EventHandler(this.buttonToBynaryAfter_Click);
            // 
            // buttonToBynaryCodeChoose
            // 
            this.buttonToBynaryCodeChoose.Name = "buttonToBynaryCodeChoose";
            this.buttonToBynaryCodeChoose.Size = new System.Drawing.Size(324, 26);
            this.buttonToBynaryCodeChoose.Text = "\"Вывести/Сохранить\"";
            this.buttonToBynaryCodeChoose.Click += new System.EventHandler(this.buttonToBynaryCodeChoose_Click);
            // 
            // buttonToBynaryEnd
            // 
            this.buttonToBynaryEnd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.весьТекстToolStripMenuItem1,
            this.buttonToBynaryEndSelected,
            this.bottonToBynaryOutSellEnd,
            this.buttonToBynaryBeforeEnd,
            this.buttonToBynaryAfterEnd,
            this.buttonAddBynaryCodeChooseEnd});
            this.buttonToBynaryEnd.Name = "buttonToBynaryEnd";
            this.buttonToBynaryEnd.Size = new System.Drawing.Size(225, 26);
            this.buttonToBynaryEnd.Text = "В конце текста";
            // 
            // весьТекстToolStripMenuItem1
            // 
            this.весьТекстToolStripMenuItem1.Name = "весьТекстToolStripMenuItem1";
            this.весьТекстToolStripMenuItem1.Size = new System.Drawing.Size(324, 26);
            this.весьТекстToolStripMenuItem1.Text = "Весь текст";
            this.весьТекстToolStripMenuItem1.Click += new System.EventHandler(this.buttonToBynaryEnd_Click);
            // 
            // buttonToBynaryEndSelected
            // 
            this.buttonToBynaryEndSelected.Name = "buttonToBynaryEndSelected";
            this.buttonToBynaryEndSelected.Size = new System.Drawing.Size(324, 26);
            this.buttonToBynaryEndSelected.Text = "Выделенный текст";
            this.buttonToBynaryEndSelected.Click += new System.EventHandler(this.buttonToBynaryEndSelected_Click);
            // 
            // bottonToBynaryOutSellEnd
            // 
            this.bottonToBynaryOutSellEnd.Name = "bottonToBynaryOutSellEnd";
            this.bottonToBynaryOutSellEnd.Size = new System.Drawing.Size(324, 26);
            this.bottonToBynaryOutSellEnd.Text = "Без выделенного текста";
            this.bottonToBynaryOutSellEnd.Click += new System.EventHandler(this.bottonToBynaryOutSellEnd_Click);
            // 
            // buttonToBynaryBeforeEnd
            // 
            this.buttonToBynaryBeforeEnd.Name = "buttonToBynaryBeforeEnd";
            this.buttonToBynaryBeforeEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonToBynaryBeforeEnd.Text = "До выделенного текста";
            this.buttonToBynaryBeforeEnd.Click += new System.EventHandler(this.buttonToBynaryBeforeEnd_Click);
            // 
            // buttonToBynaryAfterEnd
            // 
            this.buttonToBynaryAfterEnd.Name = "buttonToBynaryAfterEnd";
            this.buttonToBynaryAfterEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonToBynaryAfterEnd.Text = "После выделенного текста";
            this.buttonToBynaryAfterEnd.Click += new System.EventHandler(this.buttonToBynaryAfterEnd_Click);
            // 
            // buttonAddBynaryCodeChooseEnd
            // 
            this.buttonAddBynaryCodeChooseEnd.Name = "buttonAddBynaryCodeChooseEnd";
            this.buttonAddBynaryCodeChooseEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonAddBynaryCodeChooseEnd.Text = "\"Вывести/Сохранить\"";
            this.buttonAddBynaryCodeChooseEnd.Click += new System.EventHandler(this.buttonAddBynaryCodeChoose_Click);
            // 
            // buttonToBynaryStart
            // 
            this.buttonToBynaryStart.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.весьТекстToolStripMenuItem2,
            this.buttonToBynaryStartSelected,
            this.bottonToBynaryOutSellStart,
            this.buttonToBynaryBeforeStart,
            this.buttonToBynaryAfterStart,
            this.buttonAddBynaryCodeChooseStart});
            this.buttonToBynaryStart.Name = "buttonToBynaryStart";
            this.buttonToBynaryStart.Size = new System.Drawing.Size(225, 26);
            this.buttonToBynaryStart.Text = "В начале текста";
            // 
            // весьТекстToolStripMenuItem2
            // 
            this.весьТекстToolStripMenuItem2.Name = "весьТекстToolStripMenuItem2";
            this.весьТекстToolStripMenuItem2.Size = new System.Drawing.Size(324, 26);
            this.весьТекстToolStripMenuItem2.Text = "Весь текст";
            this.весьТекстToolStripMenuItem2.Click += new System.EventHandler(this.buttonToBynaryStart_Click);
            // 
            // buttonToBynaryStartSelected
            // 
            this.buttonToBynaryStartSelected.Name = "buttonToBynaryStartSelected";
            this.buttonToBynaryStartSelected.Size = new System.Drawing.Size(324, 26);
            this.buttonToBynaryStartSelected.Text = "Выделенный текст";
            this.buttonToBynaryStartSelected.Click += new System.EventHandler(this.buttonToBynaryStartSelected_Click);
            // 
            // bottonToBynaryOutSellStart
            // 
            this.bottonToBynaryOutSellStart.Name = "bottonToBynaryOutSellStart";
            this.bottonToBynaryOutSellStart.Size = new System.Drawing.Size(324, 26);
            this.bottonToBynaryOutSellStart.Text = "Без выделенного текста";
            this.bottonToBynaryOutSellStart.Click += new System.EventHandler(this.bottonToBynaryOutSellStart_Click);
            // 
            // buttonToBynaryBeforeStart
            // 
            this.buttonToBynaryBeforeStart.Name = "buttonToBynaryBeforeStart";
            this.buttonToBynaryBeforeStart.Size = new System.Drawing.Size(324, 26);
            this.buttonToBynaryBeforeStart.Text = "До выделенного текста";
            this.buttonToBynaryBeforeStart.Click += new System.EventHandler(this.buttonToBynaryBeforeStart_Click);
            // 
            // buttonToBynaryAfterStart
            // 
            this.buttonToBynaryAfterStart.Name = "buttonToBynaryAfterStart";
            this.buttonToBynaryAfterStart.Size = new System.Drawing.Size(324, 26);
            this.buttonToBynaryAfterStart.Text = "После выделенного текста";
            this.buttonToBynaryAfterStart.Click += new System.EventHandler(this.buttonToBynaryAfterStart_Click);
            // 
            // buttonAddBynaryCodeChooseStart
            // 
            this.buttonAddBynaryCodeChooseStart.Name = "buttonAddBynaryCodeChooseStart";
            this.buttonAddBynaryCodeChooseStart.Size = new System.Drawing.Size(324, 26);
            this.buttonAddBynaryCodeChooseStart.Text = "\"Вывести/Сохранить\"";
            this.buttonAddBynaryCodeChooseStart.Click += new System.EventHandler(this.buttonAddBynaryCodeChooseStart_Click);
            // 
            // buttonFromBynary
            // 
            this.buttonFromBynary.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вместоТекстаToolStripMenuItem1,
            this.вКонцеТекстаToolStripMenuItem,
            this.bottonFromBynaryOutSellStart1});
            this.buttonFromBynary.Name = "buttonFromBynary";
            this.buttonFromBynary.Size = new System.Drawing.Size(398, 26);
            this.buttonFromBynary.Text = "Конвертировать из двоичного кода";
            // 
            // вместоТекстаToolStripMenuItem1
            // 
            this.вместоТекстаToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.весьТекстToolStripMenuItem3,
            this.buttonFromBynarySelected,
            this.bottonFromBynaryOutSell,
            this.buttonFromBynaryBefore,
            this.buttonFromBynaryAfter,
            this.buttonFromBynaryCodeCoose});
            this.вместоТекстаToolStripMenuItem1.Name = "вместоТекстаToolStripMenuItem1";
            this.вместоТекстаToolStripMenuItem1.Size = new System.Drawing.Size(225, 26);
            this.вместоТекстаToolStripMenuItem1.Text = "Вместо текста";
            // 
            // весьТекстToolStripMenuItem3
            // 
            this.весьТекстToolStripMenuItem3.Name = "весьТекстToolStripMenuItem3";
            this.весьТекстToolStripMenuItem3.Size = new System.Drawing.Size(324, 26);
            this.весьТекстToolStripMenuItem3.Text = "Весь текст";
            this.весьТекстToolStripMenuItem3.Click += new System.EventHandler(this.buttonFromBynary_Click);
            // 
            // buttonFromBynarySelected
            // 
            this.buttonFromBynarySelected.Name = "buttonFromBynarySelected";
            this.buttonFromBynarySelected.Size = new System.Drawing.Size(324, 26);
            this.buttonFromBynarySelected.Text = "Выделенный текст";
            this.buttonFromBynarySelected.Click += new System.EventHandler(this.buttonFromBynarySelected_Click);
            // 
            // bottonFromBynaryOutSell
            // 
            this.bottonFromBynaryOutSell.Name = "bottonFromBynaryOutSell";
            this.bottonFromBynaryOutSell.Size = new System.Drawing.Size(324, 26);
            this.bottonFromBynaryOutSell.Text = "Без выделенного текста";
            this.bottonFromBynaryOutSell.Click += new System.EventHandler(this.bottonFromBynaryOutSell_Click);
            // 
            // buttonFromBynaryBefore
            // 
            this.buttonFromBynaryBefore.Name = "buttonFromBynaryBefore";
            this.buttonFromBynaryBefore.Size = new System.Drawing.Size(324, 26);
            this.buttonFromBynaryBefore.Text = "До выделенного текста";
            this.buttonFromBynaryBefore.Click += new System.EventHandler(this.buttonFromBynaryBefore_Click);
            // 
            // buttonFromBynaryAfter
            // 
            this.buttonFromBynaryAfter.Name = "buttonFromBynaryAfter";
            this.buttonFromBynaryAfter.Size = new System.Drawing.Size(324, 26);
            this.buttonFromBynaryAfter.Text = "После выделенного текста";
            this.buttonFromBynaryAfter.Click += new System.EventHandler(this.buttonFromBynaryAfter_Click);
            // 
            // buttonFromBynaryCodeCoose
            // 
            this.buttonFromBynaryCodeCoose.Name = "buttonFromBynaryCodeCoose";
            this.buttonFromBynaryCodeCoose.Size = new System.Drawing.Size(324, 26);
            this.buttonFromBynaryCodeCoose.Text = "\"Вывести/Сохранить\"";
            this.buttonFromBynaryCodeCoose.Click += new System.EventHandler(this.buttonFromBynaryCodeCoose_Click);
            // 
            // вКонцеТекстаToolStripMenuItem
            // 
            this.вКонцеТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonFromBynaryEnd,
            this.buttonFromBynaryEndSelected,
            this.bottonFromBynaryOutSellEnd,
            this.bottonFromBynaryBeforeSellEnd,
            this.bottonFromBynaryAfterSellEnd,
            this.buttonFromBynaryCodeCooseEnd});
            this.вКонцеТекстаToolStripMenuItem.Name = "вКонцеТекстаToolStripMenuItem";
            this.вКонцеТекстаToolStripMenuItem.Size = new System.Drawing.Size(225, 26);
            this.вКонцеТекстаToolStripMenuItem.Text = "В конце текста";
            // 
            // buttonFromBynaryEnd
            // 
            this.buttonFromBynaryEnd.Name = "buttonFromBynaryEnd";
            this.buttonFromBynaryEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonFromBynaryEnd.Text = "Весь текст";
            this.buttonFromBynaryEnd.Click += new System.EventHandler(this.buttonFromBynaryEnd_Click);
            // 
            // buttonFromBynaryEndSelected
            // 
            this.buttonFromBynaryEndSelected.Name = "buttonFromBynaryEndSelected";
            this.buttonFromBynaryEndSelected.Size = new System.Drawing.Size(324, 26);
            this.buttonFromBynaryEndSelected.Text = "Выделенный текст";
            this.buttonFromBynaryEndSelected.Click += new System.EventHandler(this.buttonFromBynaryEndSelected_Click);
            // 
            // bottonFromBynaryOutSellEnd
            // 
            this.bottonFromBynaryOutSellEnd.Name = "bottonFromBynaryOutSellEnd";
            this.bottonFromBynaryOutSellEnd.Size = new System.Drawing.Size(324, 26);
            this.bottonFromBynaryOutSellEnd.Text = "Без выделенного текста";
            this.bottonFromBynaryOutSellEnd.Click += new System.EventHandler(this.bottonFromBynaryOutSellEnd_Click);
            // 
            // bottonFromBynaryBeforeSellEnd
            // 
            this.bottonFromBynaryBeforeSellEnd.Name = "bottonFromBynaryBeforeSellEnd";
            this.bottonFromBynaryBeforeSellEnd.Size = new System.Drawing.Size(324, 26);
            this.bottonFromBynaryBeforeSellEnd.Text = "До выделенного текста";
            this.bottonFromBynaryBeforeSellEnd.Click += new System.EventHandler(this.bottonFromBynaryBeforeSellEnd_Click);
            // 
            // bottonFromBynaryAfterSellEnd
            // 
            this.bottonFromBynaryAfterSellEnd.Name = "bottonFromBynaryAfterSellEnd";
            this.bottonFromBynaryAfterSellEnd.Size = new System.Drawing.Size(324, 26);
            this.bottonFromBynaryAfterSellEnd.Text = "После выделенного текста";
            this.bottonFromBynaryAfterSellEnd.Click += new System.EventHandler(this.bottonFromBynaryAfterSellEnd_Click);
            // 
            // buttonFromBynaryCodeCooseEnd
            // 
            this.buttonFromBynaryCodeCooseEnd.Name = "buttonFromBynaryCodeCooseEnd";
            this.buttonFromBynaryCodeCooseEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonFromBynaryCodeCooseEnd.Text = "\"Вывести/Сохранить\"";
            this.buttonFromBynaryCodeCooseEnd.Click += new System.EventHandler(this.buttonFromBynaryCodeCooseEnd_Click);
            // 
            // bottonFromBynaryOutSellStart1
            // 
            this.bottonFromBynaryOutSellStart1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonFromBynaryStart,
            this.buttonFromBynaryStartSelected,
            this.bottonFromBynaryOutSellStart,
            this.bottonFromBynaryBeforeSellStart,
            this.bottonFromBynaryAfterSellStart,
            this.buttonFromBynaryCodeCooseStart});
            this.bottonFromBynaryOutSellStart1.Name = "bottonFromBynaryOutSellStart1";
            this.bottonFromBynaryOutSellStart1.Size = new System.Drawing.Size(225, 26);
            this.bottonFromBynaryOutSellStart1.Text = "В начале текста";
            // 
            // buttonFromBynaryStart
            // 
            this.buttonFromBynaryStart.Name = "buttonFromBynaryStart";
            this.buttonFromBynaryStart.Size = new System.Drawing.Size(338, 26);
            this.buttonFromBynaryStart.Text = "Весь текст";
            this.buttonFromBynaryStart.Click += new System.EventHandler(this.buttonFromBynaryStart_Click);
            // 
            // buttonFromBynaryStartSelected
            // 
            this.buttonFromBynaryStartSelected.Name = "buttonFromBynaryStartSelected";
            this.buttonFromBynaryStartSelected.Size = new System.Drawing.Size(338, 26);
            this.buttonFromBynaryStartSelected.Text = "Выделенный текст";
            this.buttonFromBynaryStartSelected.Click += new System.EventHandler(this.buttonFromBynaryStartSelected_Click);
            // 
            // bottonFromBynaryOutSellStart
            // 
            this.bottonFromBynaryOutSellStart.Name = "bottonFromBynaryOutSellStart";
            this.bottonFromBynaryOutSellStart.Size = new System.Drawing.Size(338, 26);
            this.bottonFromBynaryOutSellStart.Text = "Без выделенного фрагмента";
            this.bottonFromBynaryOutSellStart.Click += new System.EventHandler(this.bottonFromBynaryOutSellStart_Click);
            // 
            // bottonFromBynaryBeforeSellStart
            // 
            this.bottonFromBynaryBeforeSellStart.Name = "bottonFromBynaryBeforeSellStart";
            this.bottonFromBynaryBeforeSellStart.Size = new System.Drawing.Size(338, 26);
            this.bottonFromBynaryBeforeSellStart.Text = "До выделенного текста";
            this.bottonFromBynaryBeforeSellStart.Click += new System.EventHandler(this.bottonFromBynaryBeforeSellStart_Click);
            // 
            // bottonFromBynaryAfterSellStart
            // 
            this.bottonFromBynaryAfterSellStart.Name = "bottonFromBynaryAfterSellStart";
            this.bottonFromBynaryAfterSellStart.Size = new System.Drawing.Size(338, 26);
            this.bottonFromBynaryAfterSellStart.Text = "После выделенного текста";
            this.bottonFromBynaryAfterSellStart.Click += new System.EventHandler(this.bottonFromBynaryAfterSellStart_Click);
            // 
            // buttonFromBynaryCodeCooseStart
            // 
            this.buttonFromBynaryCodeCooseStart.Name = "buttonFromBynaryCodeCooseStart";
            this.buttonFromBynaryCodeCooseStart.Size = new System.Drawing.Size(338, 26);
            this.buttonFromBynaryCodeCooseStart.Text = "\"Вывести/Сохранить\"";
            this.buttonFromBynaryCodeCooseStart.Click += new System.EventHandler(this.buttonFromBynaryCodeCooseStart_Click);
            // 
            // четверичныйКодToolStripMenuItem
            // 
            this.четверичныйКодToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.конвертироватьВЧетверичныйКодToolStripMenuItem,
            this.конвертироватьИзЧетверичногоКодаToolStripMenuItem});
            this.четверичныйКодToolStripMenuItem.Name = "четверичныйКодToolStripMenuItem";
            this.четверичныйКодToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.четверичныйКодToolStripMenuItem.Text = "Четверичный код";
            // 
            // конвертироватьВЧетверичныйКодToolStripMenuItem
            // 
            this.конвертироватьВЧетверичныйКодToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вместоТекстаToolStripMenuItem2});
            this.конвертироватьВЧетверичныйКодToolStripMenuItem.Name = "конвертироватьВЧетверичныйКодToolStripMenuItem";
            this.конвертироватьВЧетверичныйКодToolStripMenuItem.Size = new System.Drawing.Size(424, 26);
            this.конвертироватьВЧетверичныйКодToolStripMenuItem.Text = "Конвертировать в четверичный код";
            // 
            // вместоТекстаToolStripMenuItem2
            // 
            this.вместоТекстаToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonTextToQuaternaryCode,
            this.buttonAllTextToQuaternaryCode,
            this.buttonSelectTextToQuaternaryCode,
            this.buttonOutSelectTextToQuaternaryCode,
            this.buttonOutSelectTextBeforeQuaternaryCode,
            this.buttonOutSelectTextAfterQuaternaryCode});
            this.вместоТекстаToolStripMenuItem2.Name = "вместоТекстаToolStripMenuItem2";
            this.вместоТекстаToolStripMenuItem2.Size = new System.Drawing.Size(212, 26);
            this.вместоТекстаToolStripMenuItem2.Text = "Вместо текста";
            // 
            // buttonTextToQuaternaryCode
            // 
            this.buttonTextToQuaternaryCode.Name = "buttonTextToQuaternaryCode";
            this.buttonTextToQuaternaryCode.Size = new System.Drawing.Size(324, 26);
            this.buttonTextToQuaternaryCode.Text = "\"Вывести/Сохранить\"";
            this.buttonTextToQuaternaryCode.Click += new System.EventHandler(this.buttonTextToQuaternaryCode_Click);
            // 
            // buttonAllTextToQuaternaryCode
            // 
            this.buttonAllTextToQuaternaryCode.Name = "buttonAllTextToQuaternaryCode";
            this.buttonAllTextToQuaternaryCode.Size = new System.Drawing.Size(324, 26);
            this.buttonAllTextToQuaternaryCode.Text = "Весь текст";
            this.buttonAllTextToQuaternaryCode.Click += new System.EventHandler(this.buttonAllTextToQuaternaryCode_Click);
            // 
            // buttonSelectTextToQuaternaryCode
            // 
            this.buttonSelectTextToQuaternaryCode.Name = "buttonSelectTextToQuaternaryCode";
            this.buttonSelectTextToQuaternaryCode.Size = new System.Drawing.Size(324, 26);
            this.buttonSelectTextToQuaternaryCode.Text = "Выделенный текст";
            this.buttonSelectTextToQuaternaryCode.Click += new System.EventHandler(this.buttonSelectTextToQuaternaryCode_Click);
            // 
            // buttonOutSelectTextToQuaternaryCode
            // 
            this.buttonOutSelectTextToQuaternaryCode.Name = "buttonOutSelectTextToQuaternaryCode";
            this.buttonOutSelectTextToQuaternaryCode.Size = new System.Drawing.Size(324, 26);
            this.buttonOutSelectTextToQuaternaryCode.Text = "Без выделенного текста";
            this.buttonOutSelectTextToQuaternaryCode.Click += new System.EventHandler(this.buttonOutSelectTextToQuaternaryCode_Click);
            // 
            // buttonOutSelectTextBeforeQuaternaryCode
            // 
            this.buttonOutSelectTextBeforeQuaternaryCode.Name = "buttonOutSelectTextBeforeQuaternaryCode";
            this.buttonOutSelectTextBeforeQuaternaryCode.Size = new System.Drawing.Size(324, 26);
            this.buttonOutSelectTextBeforeQuaternaryCode.Text = "До выделенного текста";
            this.buttonOutSelectTextBeforeQuaternaryCode.Click += new System.EventHandler(this.buttonOutSelectTextBeforeQuaternaryCode_Click);
            // 
            // buttonOutSelectTextAfterQuaternaryCode
            // 
            this.buttonOutSelectTextAfterQuaternaryCode.Name = "buttonOutSelectTextAfterQuaternaryCode";
            this.buttonOutSelectTextAfterQuaternaryCode.Size = new System.Drawing.Size(324, 26);
            this.buttonOutSelectTextAfterQuaternaryCode.Text = "После выделенного текста";
            this.buttonOutSelectTextAfterQuaternaryCode.Click += new System.EventHandler(this.buttonOutSelectTextAfterQuaternaryCode_Click);
            // 
            // конвертироватьИзЧетверичногоКодаToolStripMenuItem
            // 
            this.конвертироватьИзЧетверичногоКодаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вместоТекстаToolStripMenuItem3});
            this.конвертироватьИзЧетверичногоКодаToolStripMenuItem.Name = "конвертироватьИзЧетверичногоКодаToolStripMenuItem";
            this.конвертироватьИзЧетверичногоКодаToolStripMenuItem.Size = new System.Drawing.Size(424, 26);
            this.конвертироватьИзЧетверичногоКодаToolStripMenuItem.Text = "Конвертировать из четверичного кода";
            // 
            // вместоТекстаToolStripMenuItem3
            // 
            this.вместоТекстаToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonQuaternaryCodeToText,
            this.buttonQuaternaryCodeToAllText,
            this.buttonQuaternaryCodeToSelectText,
            this.buttonQuaternaryCodeToOutSelectText,
            this.buttonQuaternaryCodeToBeforeSelectText,
            this.buttonQuaternaryCodeToAfterSelectText});
            this.вместоТекстаToolStripMenuItem3.Name = "вместоТекстаToolStripMenuItem3";
            this.вместоТекстаToolStripMenuItem3.Size = new System.Drawing.Size(212, 26);
            this.вместоТекстаToolStripMenuItem3.Text = "Вместо текста";
            // 
            // buttonQuaternaryCodeToText
            // 
            this.buttonQuaternaryCodeToText.Name = "buttonQuaternaryCodeToText";
            this.buttonQuaternaryCodeToText.Size = new System.Drawing.Size(324, 26);
            this.buttonQuaternaryCodeToText.Text = "\"Вывести/Сохранить\"";
            this.buttonQuaternaryCodeToText.Click += new System.EventHandler(this.buttonQuaternaryCodeToText_Click);
            // 
            // buttonQuaternaryCodeToAllText
            // 
            this.buttonQuaternaryCodeToAllText.Name = "buttonQuaternaryCodeToAllText";
            this.buttonQuaternaryCodeToAllText.Size = new System.Drawing.Size(324, 26);
            this.buttonQuaternaryCodeToAllText.Text = "Весь текст";
            this.buttonQuaternaryCodeToAllText.Click += new System.EventHandler(this.buttonQuaternaryCodeToAllText_Click);
            // 
            // buttonQuaternaryCodeToSelectText
            // 
            this.buttonQuaternaryCodeToSelectText.Name = "buttonQuaternaryCodeToSelectText";
            this.buttonQuaternaryCodeToSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonQuaternaryCodeToSelectText.Text = "Выделенный текст";
            this.buttonQuaternaryCodeToSelectText.Click += new System.EventHandler(this.buttonQuaternaryCodeToSelectText_Click);
            // 
            // buttonQuaternaryCodeToOutSelectText
            // 
            this.buttonQuaternaryCodeToOutSelectText.Name = "buttonQuaternaryCodeToOutSelectText";
            this.buttonQuaternaryCodeToOutSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonQuaternaryCodeToOutSelectText.Text = "Без выделенного текста";
            this.buttonQuaternaryCodeToOutSelectText.Click += new System.EventHandler(this.buttonQuaternaryCodeToOutSelectText_Click);
            // 
            // buttonQuaternaryCodeToBeforeSelectText
            // 
            this.buttonQuaternaryCodeToBeforeSelectText.Name = "buttonQuaternaryCodeToBeforeSelectText";
            this.buttonQuaternaryCodeToBeforeSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonQuaternaryCodeToBeforeSelectText.Text = "До выделенного текста";
            this.buttonQuaternaryCodeToBeforeSelectText.Click += new System.EventHandler(this.buttonQuaternaryCodeToBeforeSelectText_Click);
            // 
            // buttonQuaternaryCodeToAfterSelectText
            // 
            this.buttonQuaternaryCodeToAfterSelectText.Name = "buttonQuaternaryCodeToAfterSelectText";
            this.buttonQuaternaryCodeToAfterSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonQuaternaryCodeToAfterSelectText.Text = "После выделенного текста";
            this.buttonQuaternaryCodeToAfterSelectText.Click += new System.EventHandler(this.buttonQuaternaryCodeToAfterSelectText_Click);
            // 
            // восьмеричныйКодToolStripMenuItem
            // 
            this.восьмеричныйКодToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.конвертироватьВВосьмеричныйКодToolStripMenuItem,
            this.конвертироватьИзВосьмеричногоКодаToolStripMenuItem});
            this.восьмеричныйКодToolStripMenuItem.Name = "восьмеричныйКодToolStripMenuItem";
            this.восьмеричныйКодToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.восьмеричныйКодToolStripMenuItem.Text = "Восьмеричный код";
            // 
            // конвертироватьВВосьмеричныйКодToolStripMenuItem
            // 
            this.конвертироватьВВосьмеричныйКодToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вместоТекстаToolStripMenuItem4});
            this.конвертироватьВВосьмеричныйКодToolStripMenuItem.Name = "конвертироватьВВосьмеричныйКодToolStripMenuItem";
            this.конвертироватьВВосьмеричныйКодToolStripMenuItem.Size = new System.Drawing.Size(438, 26);
            this.конвертироватьВВосьмеричныйКодToolStripMenuItem.Text = "Конвертировать в восьмеричный код";
            // 
            // вместоТекстаToolStripMenuItem4
            // 
            this.вместоТекстаToolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonTextToOctalCode,
            this.buttonAllTextToOctalCode,
            this.buttonSelectTextToOctalCode,
            this.buttonOutSelectTextToOctalCode,
            this.buttonBeforeSelectTextToOctalCode,
            this.buttonAfterSelectTextToOctalCode});
            this.вместоТекстаToolStripMenuItem4.Name = "вместоТекстаToolStripMenuItem4";
            this.вместоТекстаToolStripMenuItem4.Size = new System.Drawing.Size(212, 26);
            this.вместоТекстаToolStripMenuItem4.Text = "Вместо текста";
            // 
            // buttonTextToOctalCode
            // 
            this.buttonTextToOctalCode.Name = "buttonTextToOctalCode";
            this.buttonTextToOctalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonTextToOctalCode.Text = "\"Вывести/Сохранить\"";
            this.buttonTextToOctalCode.Click += new System.EventHandler(this.buttonTextToOctalCode_Click);
            // 
            // buttonAllTextToOctalCode
            // 
            this.buttonAllTextToOctalCode.Name = "buttonAllTextToOctalCode";
            this.buttonAllTextToOctalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonAllTextToOctalCode.Text = "Весь текст";
            this.buttonAllTextToOctalCode.Click += new System.EventHandler(this.buttonAllTextToOctalCode_Click);
            // 
            // buttonSelectTextToOctalCode
            // 
            this.buttonSelectTextToOctalCode.Name = "buttonSelectTextToOctalCode";
            this.buttonSelectTextToOctalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonSelectTextToOctalCode.Text = "Выделенный текст";
            this.buttonSelectTextToOctalCode.Click += new System.EventHandler(this.buttonSelectTextToOctalCode_Click);
            // 
            // buttonOutSelectTextToOctalCode
            // 
            this.buttonOutSelectTextToOctalCode.Name = "buttonOutSelectTextToOctalCode";
            this.buttonOutSelectTextToOctalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonOutSelectTextToOctalCode.Text = "Без выделенного текста";
            this.buttonOutSelectTextToOctalCode.Click += new System.EventHandler(this.buttonOutSelectTextToOctalCode_Click);
            // 
            // buttonBeforeSelectTextToOctalCode
            // 
            this.buttonBeforeSelectTextToOctalCode.Name = "buttonBeforeSelectTextToOctalCode";
            this.buttonBeforeSelectTextToOctalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonBeforeSelectTextToOctalCode.Text = "До выделенного текста";
            this.buttonBeforeSelectTextToOctalCode.Click += new System.EventHandler(this.buttonBeforeSelectTextToOctalCode_Click);
            // 
            // buttonAfterSelectTextToOctalCode
            // 
            this.buttonAfterSelectTextToOctalCode.Name = "buttonAfterSelectTextToOctalCode";
            this.buttonAfterSelectTextToOctalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonAfterSelectTextToOctalCode.Text = "После выделенного текста";
            this.buttonAfterSelectTextToOctalCode.Click += new System.EventHandler(this.buttonAfterSelectTextToOctalCode_Click);
            // 
            // конвертироватьИзВосьмеричногоКодаToolStripMenuItem
            // 
            this.конвертироватьИзВосьмеричногоКодаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вместоТекстаToolStripMenuItem5});
            this.конвертироватьИзВосьмеричногоКодаToolStripMenuItem.Name = "конвертироватьИзВосьмеричногоКодаToolStripMenuItem";
            this.конвертироватьИзВосьмеричногоКодаToolStripMenuItem.Size = new System.Drawing.Size(438, 26);
            this.конвертироватьИзВосьмеричногоКодаToolStripMenuItem.Text = "Конвертировать из восьмеричного кода";
            // 
            // вместоТекстаToolStripMenuItem5
            // 
            this.вместоТекстаToolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonOctalCodeToText,
            this.buttonOctalCodeToAllText,
            this.buttonOctalCodeToSelectText,
            this.buttonOctalCodeToOutSelectText,
            this.buttonOctalCodeToBeforeSelectText,
            this.buttonOctalCodeToAfterSelectText});
            this.вместоТекстаToolStripMenuItem5.Name = "вместоТекстаToolStripMenuItem5";
            this.вместоТекстаToolStripMenuItem5.Size = new System.Drawing.Size(212, 26);
            this.вместоТекстаToolStripMenuItem5.Text = "Вместо текста";
            // 
            // buttonOctalCodeToText
            // 
            this.buttonOctalCodeToText.Name = "buttonOctalCodeToText";
            this.buttonOctalCodeToText.Size = new System.Drawing.Size(324, 26);
            this.buttonOctalCodeToText.Text = "\"Вывести/Сохранить\"";
            this.buttonOctalCodeToText.Click += new System.EventHandler(this.buttonOctalCodeToText_Click);
            // 
            // buttonOctalCodeToAllText
            // 
            this.buttonOctalCodeToAllText.Name = "buttonOctalCodeToAllText";
            this.buttonOctalCodeToAllText.Size = new System.Drawing.Size(324, 26);
            this.buttonOctalCodeToAllText.Text = "Весь текст";
            this.buttonOctalCodeToAllText.Click += new System.EventHandler(this.buttonOctalCodeToAllText_Click);
            // 
            // buttonOctalCodeToSelectText
            // 
            this.buttonOctalCodeToSelectText.Name = "buttonOctalCodeToSelectText";
            this.buttonOctalCodeToSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonOctalCodeToSelectText.Text = "Выделенный текст";
            this.buttonOctalCodeToSelectText.Click += new System.EventHandler(this.buttonOctalCodeToSelectText_Click);
            // 
            // buttonOctalCodeToOutSelectText
            // 
            this.buttonOctalCodeToOutSelectText.Name = "buttonOctalCodeToOutSelectText";
            this.buttonOctalCodeToOutSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonOctalCodeToOutSelectText.Text = "Без выделенного текста";
            this.buttonOctalCodeToOutSelectText.Click += new System.EventHandler(this.buttonOctalCodeToOutSelectText_Click);
            // 
            // buttonOctalCodeToBeforeSelectText
            // 
            this.buttonOctalCodeToBeforeSelectText.Name = "buttonOctalCodeToBeforeSelectText";
            this.buttonOctalCodeToBeforeSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonOctalCodeToBeforeSelectText.Text = "До выделенного текста";
            this.buttonOctalCodeToBeforeSelectText.Click += new System.EventHandler(this.buttonOctalCodeToBeforeSelectText_Click);
            // 
            // buttonOctalCodeToAfterSelectText
            // 
            this.buttonOctalCodeToAfterSelectText.Name = "buttonOctalCodeToAfterSelectText";
            this.buttonOctalCodeToAfterSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonOctalCodeToAfterSelectText.Text = "После выделенного текста";
            this.buttonOctalCodeToAfterSelectText.Click += new System.EventHandler(this.buttonOctalCodeToAfterSelectText_Click);
            // 
            // шестнадцатиричныйКодToolStripMenuItem
            // 
            this.шестнадцатиричныйКодToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.конвертироватьВШестнадцатеричныйКодToolStripMenuItem,
            this.конвертироватьИзШестнадцатеричногоКодаToolStripMenuItem});
            this.шестнадцатиричныйКодToolStripMenuItem.Name = "шестнадцатиричныйКодToolStripMenuItem";
            this.шестнадцатиричныйКодToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.шестнадцатиричныйКодToolStripMenuItem.Text = "Шестнадцатиричный код";
            // 
            // конвертироватьВШестнадцатеричныйКодToolStripMenuItem
            // 
            this.конвертироватьВШестнадцатеричныйКодToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вместоТекстаToolStripMenuItem6,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.конвертироватьВШестнадцатеричныйКодToolStripMenuItem.Name = "конвертироватьВШестнадцатеричныйКодToolStripMenuItem";
            this.конвертироватьВШестнадцатеричныйКодToolStripMenuItem.Size = new System.Drawing.Size(488, 26);
            this.конвертироватьВШестнадцатеричныйКодToolStripMenuItem.Text = "Конвертировать в шестнадцатеричный код";
            // 
            // вместоТекстаToolStripMenuItem6
            // 
            this.вместоТекстаToolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonTextToHexadecimalCode,
            this.buttonAllTextToHexadecimalCode,
            this.buttonSelectTextToHexadecimalCode,
            this.buttonOutSelectTextToHexadecimalCode,
            this.buttonBeforeSelectTextToHexadecimalCode,
            this.buttonAfterSelectTextToHexadecimalCode});
            this.вместоТекстаToolStripMenuItem6.Name = "вместоТекстаToolStripMenuItem6";
            this.вместоТекстаToolStripMenuItem6.Size = new System.Drawing.Size(226, 26);
            this.вместоТекстаToolStripMenuItem6.Text = "Вместо текста";
            // 
            // buttonTextToHexadecimalCode
            // 
            this.buttonTextToHexadecimalCode.Name = "buttonTextToHexadecimalCode";
            this.buttonTextToHexadecimalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonTextToHexadecimalCode.Text = "\"Вывести/Сохранить\"";
            this.buttonTextToHexadecimalCode.Click += new System.EventHandler(this.buttonTextToHexadecimalCode_Click);
            // 
            // buttonAllTextToHexadecimalCode
            // 
            this.buttonAllTextToHexadecimalCode.Name = "buttonAllTextToHexadecimalCode";
            this.buttonAllTextToHexadecimalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonAllTextToHexadecimalCode.Text = "Весь текст";
            this.buttonAllTextToHexadecimalCode.Click += new System.EventHandler(this.buttonAllTextToHexadecimalCode_Click);
            // 
            // buttonSelectTextToHexadecimalCode
            // 
            this.buttonSelectTextToHexadecimalCode.Name = "buttonSelectTextToHexadecimalCode";
            this.buttonSelectTextToHexadecimalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonSelectTextToHexadecimalCode.Text = "Выделенный текст";
            this.buttonSelectTextToHexadecimalCode.Click += new System.EventHandler(this.buttonSelectTextToHexadecimalCode_Click);
            // 
            // buttonOutSelectTextToHexadecimalCode
            // 
            this.buttonOutSelectTextToHexadecimalCode.Name = "buttonOutSelectTextToHexadecimalCode";
            this.buttonOutSelectTextToHexadecimalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonOutSelectTextToHexadecimalCode.Text = "Без выделенного текста";
            this.buttonOutSelectTextToHexadecimalCode.Click += new System.EventHandler(this.buttonOutSelectTextToHexadecimalCode_Click);
            // 
            // buttonBeforeSelectTextToHexadecimalCode
            // 
            this.buttonBeforeSelectTextToHexadecimalCode.Name = "buttonBeforeSelectTextToHexadecimalCode";
            this.buttonBeforeSelectTextToHexadecimalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonBeforeSelectTextToHexadecimalCode.Text = "До выделенного текста";
            this.buttonBeforeSelectTextToHexadecimalCode.Click += new System.EventHandler(this.buttonBeforeSelectTextToHexadecimalCode_Click);
            // 
            // buttonAfterSelectTextToHexadecimalCode
            // 
            this.buttonAfterSelectTextToHexadecimalCode.Name = "buttonAfterSelectTextToHexadecimalCode";
            this.buttonAfterSelectTextToHexadecimalCode.Size = new System.Drawing.Size(324, 26);
            this.buttonAfterSelectTextToHexadecimalCode.Text = "После выделенного текста";
            this.buttonAfterSelectTextToHexadecimalCode.Click += new System.EventHandler(this.buttonAfterSelectTextToHexadecimalCode_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonTextToHexadecimalCodeEnd,
            this.buttonAllTextToHexadecimalCodeEnd,
            this.buttonSelectTextToHexadecimalCodeEnd,
            this.buttonOutSelectTextToHexadecimalCodeEnd,
            this.buttonBeforeSelectTextToHexadecimalCodeEnd,
            this.buttonAfterSelectTextToHexadecimalCodeEnd});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(226, 26);
            this.toolStripMenuItem2.Text = "В конце текста";
            // 
            // buttonTextToHexadecimalCodeEnd
            // 
            this.buttonTextToHexadecimalCodeEnd.Name = "buttonTextToHexadecimalCodeEnd";
            this.buttonTextToHexadecimalCodeEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonTextToHexadecimalCodeEnd.Text = "\"Вывести/Сохранить\"";
            this.buttonTextToHexadecimalCodeEnd.Click += new System.EventHandler(this.buttonTextToHexadecimalCodeEnd_Click);
            // 
            // buttonAllTextToHexadecimalCodeEnd
            // 
            this.buttonAllTextToHexadecimalCodeEnd.Name = "buttonAllTextToHexadecimalCodeEnd";
            this.buttonAllTextToHexadecimalCodeEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonAllTextToHexadecimalCodeEnd.Text = "Весь текст";
            this.buttonAllTextToHexadecimalCodeEnd.Click += new System.EventHandler(this.buttonAllTextToHexadecimalCodeEnd_Click);
            // 
            // buttonSelectTextToHexadecimalCodeEnd
            // 
            this.buttonSelectTextToHexadecimalCodeEnd.Name = "buttonSelectTextToHexadecimalCodeEnd";
            this.buttonSelectTextToHexadecimalCodeEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonSelectTextToHexadecimalCodeEnd.Text = "Выделенный текст";
            this.buttonSelectTextToHexadecimalCodeEnd.Click += new System.EventHandler(this.buttonSelectTextToHexadecimalCodeEnd_Click);
            // 
            // buttonOutSelectTextToHexadecimalCodeEnd
            // 
            this.buttonOutSelectTextToHexadecimalCodeEnd.Name = "buttonOutSelectTextToHexadecimalCodeEnd";
            this.buttonOutSelectTextToHexadecimalCodeEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonOutSelectTextToHexadecimalCodeEnd.Text = "Без выделенного текста";
            this.buttonOutSelectTextToHexadecimalCodeEnd.Click += new System.EventHandler(this.buttonOutSelectTextToHexadecimalCodeEnd_Click);
            // 
            // buttonBeforeSelectTextToHexadecimalCodeEnd
            // 
            this.buttonBeforeSelectTextToHexadecimalCodeEnd.Name = "buttonBeforeSelectTextToHexadecimalCodeEnd";
            this.buttonBeforeSelectTextToHexadecimalCodeEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonBeforeSelectTextToHexadecimalCodeEnd.Text = "До выделенного текста";
            this.buttonBeforeSelectTextToHexadecimalCodeEnd.Click += new System.EventHandler(this.buttonBeforeSelectTextToHexadecimalCodeEnd_Click);
            // 
            // buttonAfterSelectTextToHexadecimalCodeEnd
            // 
            this.buttonAfterSelectTextToHexadecimalCodeEnd.Name = "buttonAfterSelectTextToHexadecimalCodeEnd";
            this.buttonAfterSelectTextToHexadecimalCodeEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonAfterSelectTextToHexadecimalCodeEnd.Text = "После выделенного текста";
            this.buttonAfterSelectTextToHexadecimalCodeEnd.Click += new System.EventHandler(this.buttonAfterSelectTextToHexadecimalCodeEnd_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonTextToHexadecimalCodeStart,
            this.buttonAllTextToHexadecimalCodeStart,
            this.buttonSelectTextToHexadecimalCodeStart,
            this.buttonOutSelectTextToHexadecimalCodeStart,
            this.buttonBeforeSelectTextToHexadecimalCodeStart,
            this.buttonAfterSelectTextToHexadecimalCodeStart});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(226, 26);
            this.toolStripMenuItem3.Text = "В начало текста";
            // 
            // buttonTextToHexadecimalCodeStart
            // 
            this.buttonTextToHexadecimalCodeStart.Name = "buttonTextToHexadecimalCodeStart";
            this.buttonTextToHexadecimalCodeStart.Size = new System.Drawing.Size(324, 26);
            this.buttonTextToHexadecimalCodeStart.Text = "\"Вывести/Сохранить\"";
            this.buttonTextToHexadecimalCodeStart.Click += new System.EventHandler(this.buttonTextToHexadecimalCodeStart_Click);
            // 
            // buttonAllTextToHexadecimalCodeStart
            // 
            this.buttonAllTextToHexadecimalCodeStart.Name = "buttonAllTextToHexadecimalCodeStart";
            this.buttonAllTextToHexadecimalCodeStart.Size = new System.Drawing.Size(324, 26);
            this.buttonAllTextToHexadecimalCodeStart.Text = "Весь текст";
            this.buttonAllTextToHexadecimalCodeStart.Click += new System.EventHandler(this.buttonAllTextToHexadecimalCodeStart_Click);
            // 
            // buttonSelectTextToHexadecimalCodeStart
            // 
            this.buttonSelectTextToHexadecimalCodeStart.Name = "buttonSelectTextToHexadecimalCodeStart";
            this.buttonSelectTextToHexadecimalCodeStart.Size = new System.Drawing.Size(324, 26);
            this.buttonSelectTextToHexadecimalCodeStart.Text = "Выделенный текст";
            this.buttonSelectTextToHexadecimalCodeStart.Click += new System.EventHandler(this.buttonSelectTextToHexadecimalCodeStart_Click);
            // 
            // buttonOutSelectTextToHexadecimalCodeStart
            // 
            this.buttonOutSelectTextToHexadecimalCodeStart.Name = "buttonOutSelectTextToHexadecimalCodeStart";
            this.buttonOutSelectTextToHexadecimalCodeStart.Size = new System.Drawing.Size(324, 26);
            this.buttonOutSelectTextToHexadecimalCodeStart.Text = "Без выделенного текста";
            this.buttonOutSelectTextToHexadecimalCodeStart.Click += new System.EventHandler(this.buttonOutSelectTextToHexadecimalCodeStart_Click);
            // 
            // buttonBeforeSelectTextToHexadecimalCodeStart
            // 
            this.buttonBeforeSelectTextToHexadecimalCodeStart.Name = "buttonBeforeSelectTextToHexadecimalCodeStart";
            this.buttonBeforeSelectTextToHexadecimalCodeStart.Size = new System.Drawing.Size(324, 26);
            this.buttonBeforeSelectTextToHexadecimalCodeStart.Text = "До выделенного текста";
            this.buttonBeforeSelectTextToHexadecimalCodeStart.Click += new System.EventHandler(this.buttonBeforeSelectTextToHexadecimalCodeStart_Click);
            // 
            // buttonAfterSelectTextToHexadecimalCodeStart
            // 
            this.buttonAfterSelectTextToHexadecimalCodeStart.Name = "buttonAfterSelectTextToHexadecimalCodeStart";
            this.buttonAfterSelectTextToHexadecimalCodeStart.Size = new System.Drawing.Size(324, 26);
            this.buttonAfterSelectTextToHexadecimalCodeStart.Text = "После выделенного текста";
            this.buttonAfterSelectTextToHexadecimalCodeStart.Click += new System.EventHandler(this.buttonAfterSelectTextToHexadecimalCodeStart_Click);
            // 
            // конвертироватьИзШестнадцатеричногоКодаToolStripMenuItem
            // 
            this.конвертироватьИзШестнадцатеричногоКодаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вместоТекстаToolStripMenuItem7,
            this.toolStripMenuItem4,
            this.toolStripMenuItem6});
            this.конвертироватьИзШестнадцатеричногоКодаToolStripMenuItem.Name = "конвертироватьИзШестнадцатеричногоКодаToolStripMenuItem";
            this.конвертироватьИзШестнадцатеричногоКодаToolStripMenuItem.Size = new System.Drawing.Size(488, 26);
            this.конвертироватьИзШестнадцатеричногоКодаToolStripMenuItem.Text = "Конвертировать из шестнадцатеричного кода";
            // 
            // вместоТекстаToolStripMenuItem7
            // 
            this.вместоТекстаToolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonHexadecimalCodeToText,
            this.buttonHexadecimalCodeToAllText,
            this.buttonHexadecimalCodeToSelectText,
            this.buttonHexadecimalCodeToOutSelectText,
            this.buttonHexadecimalCodeToBeforeSelectText,
            this.buttonHexadecimalCodeToAfterSelectText});
            this.вместоТекстаToolStripMenuItem7.Name = "вместоТекстаToolStripMenuItem7";
            this.вместоТекстаToolStripMenuItem7.Size = new System.Drawing.Size(225, 26);
            this.вместоТекстаToolStripMenuItem7.Text = "Вместо текста";
            // 
            // buttonHexadecimalCodeToText
            // 
            this.buttonHexadecimalCodeToText.Name = "buttonHexadecimalCodeToText";
            this.buttonHexadecimalCodeToText.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToText.Text = "\"Вывести/Сохранить\"";
            this.buttonHexadecimalCodeToText.Click += new System.EventHandler(this.buttonHexadecimalCodeToText_Click);
            // 
            // buttonHexadecimalCodeToAllText
            // 
            this.buttonHexadecimalCodeToAllText.Name = "buttonHexadecimalCodeToAllText";
            this.buttonHexadecimalCodeToAllText.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToAllText.Text = "Весь текст";
            this.buttonHexadecimalCodeToAllText.Click += new System.EventHandler(this.buttonHexadecimalCodeToAllText_Click);
            // 
            // buttonHexadecimalCodeToSelectText
            // 
            this.buttonHexadecimalCodeToSelectText.Name = "buttonHexadecimalCodeToSelectText";
            this.buttonHexadecimalCodeToSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToSelectText.Text = "Выделенный текст";
            this.buttonHexadecimalCodeToSelectText.Click += new System.EventHandler(this.buttonHexadecimalCodeToSelectText_Click);
            // 
            // buttonHexadecimalCodeToOutSelectText
            // 
            this.buttonHexadecimalCodeToOutSelectText.Name = "buttonHexadecimalCodeToOutSelectText";
            this.buttonHexadecimalCodeToOutSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToOutSelectText.Text = "Без выделенного текста";
            this.buttonHexadecimalCodeToOutSelectText.Click += new System.EventHandler(this.buttonHexadecimalCodeToOutSelectText_Click);
            // 
            // buttonHexadecimalCodeToBeforeSelectText
            // 
            this.buttonHexadecimalCodeToBeforeSelectText.Name = "buttonHexadecimalCodeToBeforeSelectText";
            this.buttonHexadecimalCodeToBeforeSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToBeforeSelectText.Text = "До выделенного текста";
            this.buttonHexadecimalCodeToBeforeSelectText.Click += new System.EventHandler(this.buttonHexadecimalCodeToBeforeSelectText_Click);
            // 
            // buttonHexadecimalCodeToAfterSelectText
            // 
            this.buttonHexadecimalCodeToAfterSelectText.Name = "buttonHexadecimalCodeToAfterSelectText";
            this.buttonHexadecimalCodeToAfterSelectText.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToAfterSelectText.Text = "После выделенного текста";
            this.buttonHexadecimalCodeToAfterSelectText.Click += new System.EventHandler(this.buttonHexadecimalCodeToAfterSelectText_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonHexadecimalCodeToTextEnd,
            this.buttonHexadecimalCodeToAllTextEnd,
            this.buttonHexadecimalCodeToSelectTextEnd,
            this.buttonHexadecimalCodeToOutSelectTextEnd,
            this.buttonHexadecimalCodeToBeforeSelectTextEnd,
            this.buttonHexadecimalCodeToAfterSelectTextEnd});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(225, 26);
            this.toolStripMenuItem4.Text = "В конце текста";
            // 
            // buttonHexadecimalCodeToTextEnd
            // 
            this.buttonHexadecimalCodeToTextEnd.Name = "buttonHexadecimalCodeToTextEnd";
            this.buttonHexadecimalCodeToTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToTextEnd.Text = "\"Вывести/Сохранить\"";
            this.buttonHexadecimalCodeToTextEnd.Click += new System.EventHandler(this.buttonHexadecimalCodeToTextEnd_Click);
            // 
            // buttonHexadecimalCodeToAllTextEnd
            // 
            this.buttonHexadecimalCodeToAllTextEnd.Name = "buttonHexadecimalCodeToAllTextEnd";
            this.buttonHexadecimalCodeToAllTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToAllTextEnd.Text = "Весь текст";
            this.buttonHexadecimalCodeToAllTextEnd.Click += new System.EventHandler(this.buttonHexadecimalCodeToAllTextEnd_Click);
            // 
            // buttonHexadecimalCodeToSelectTextEnd
            // 
            this.buttonHexadecimalCodeToSelectTextEnd.Name = "buttonHexadecimalCodeToSelectTextEnd";
            this.buttonHexadecimalCodeToSelectTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToSelectTextEnd.Text = "Выделенный текст";
            this.buttonHexadecimalCodeToSelectTextEnd.Click += new System.EventHandler(this.buttonHexadecimalCodeToSelectTextEnd_Click);
            // 
            // buttonHexadecimalCodeToOutSelectTextEnd
            // 
            this.buttonHexadecimalCodeToOutSelectTextEnd.Name = "buttonHexadecimalCodeToOutSelectTextEnd";
            this.buttonHexadecimalCodeToOutSelectTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToOutSelectTextEnd.Text = "Без выделенного текста";
            this.buttonHexadecimalCodeToOutSelectTextEnd.Click += new System.EventHandler(this.buttonHexadecimalCodeToOutSelectTextEnd_Click);
            // 
            // buttonHexadecimalCodeToBeforeSelectTextEnd
            // 
            this.buttonHexadecimalCodeToBeforeSelectTextEnd.Name = "buttonHexadecimalCodeToBeforeSelectTextEnd";
            this.buttonHexadecimalCodeToBeforeSelectTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToBeforeSelectTextEnd.Text = "До выделенного текста";
            this.buttonHexadecimalCodeToBeforeSelectTextEnd.Click += new System.EventHandler(this.buttonHexadecimalCodeToBeforeSelectTextEnd_Click);
            // 
            // buttonHexadecimalCodeToAfterSelectTextEnd
            // 
            this.buttonHexadecimalCodeToAfterSelectTextEnd.Name = "buttonHexadecimalCodeToAfterSelectTextEnd";
            this.buttonHexadecimalCodeToAfterSelectTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToAfterSelectTextEnd.Text = "После выделенного текста";
            this.buttonHexadecimalCodeToAfterSelectTextEnd.Click += new System.EventHandler(this.buttonHexadecimalCodeToAfterSelectTextEnd_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonHexadecimalCodeToTextStart,
            this.buttonHexadecimalCodeToAllTextStart,
            this.buttonHexadecimalCodeToSelectTextStart,
            this.buttonHexadecimalCodeToOutSelectTextStart,
            this.buttonHexadecimalCodeToBeforeSelectTextStart,
            this.buttonHexadecimalCodeToAfterSelectTextStart});
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(225, 26);
            this.toolStripMenuItem6.Text = "В начале текста";
            // 
            // buttonHexadecimalCodeToTextStart
            // 
            this.buttonHexadecimalCodeToTextStart.Name = "buttonHexadecimalCodeToTextStart";
            this.buttonHexadecimalCodeToTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToTextStart.Text = "\"Вывести/Сохранить\"";
            this.buttonHexadecimalCodeToTextStart.Click += new System.EventHandler(this.buttonHexadecimalCodeToTextStart_Click);
            // 
            // buttonHexadecimalCodeToAllTextStart
            // 
            this.buttonHexadecimalCodeToAllTextStart.Name = "buttonHexadecimalCodeToAllTextStart";
            this.buttonHexadecimalCodeToAllTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToAllTextStart.Text = "Весь текст";
            this.buttonHexadecimalCodeToAllTextStart.Click += new System.EventHandler(this.buttonHexadecimalCodeToAllTextStart_Click);
            // 
            // buttonHexadecimalCodeToSelectTextStart
            // 
            this.buttonHexadecimalCodeToSelectTextStart.Name = "buttonHexadecimalCodeToSelectTextStart";
            this.buttonHexadecimalCodeToSelectTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToSelectTextStart.Text = "Выделенный текст";
            this.buttonHexadecimalCodeToSelectTextStart.Click += new System.EventHandler(this.buttonHexadecimalCodeToSelectTextStart_Click);
            // 
            // buttonHexadecimalCodeToOutSelectTextStart
            // 
            this.buttonHexadecimalCodeToOutSelectTextStart.Name = "buttonHexadecimalCodeToOutSelectTextStart";
            this.buttonHexadecimalCodeToOutSelectTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToOutSelectTextStart.Text = "Без выделенного текста";
            this.buttonHexadecimalCodeToOutSelectTextStart.Click += new System.EventHandler(this.buttonHexadecimalCodeToOutSelectTextStart_Click);
            // 
            // buttonHexadecimalCodeToBeforeSelectTextStart
            // 
            this.buttonHexadecimalCodeToBeforeSelectTextStart.Name = "buttonHexadecimalCodeToBeforeSelectTextStart";
            this.buttonHexadecimalCodeToBeforeSelectTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToBeforeSelectTextStart.Text = "До выделенного текста";
            this.buttonHexadecimalCodeToBeforeSelectTextStart.Click += new System.EventHandler(this.buttonHexadecimalCodeToBeforeSelectTextStart_Click);
            // 
            // buttonHexadecimalCodeToAfterSelectTextStart
            // 
            this.buttonHexadecimalCodeToAfterSelectTextStart.Name = "buttonHexadecimalCodeToAfterSelectTextStart";
            this.buttonHexadecimalCodeToAfterSelectTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonHexadecimalCodeToAfterSelectTextStart.Text = "После выделенного текста";
            this.buttonHexadecimalCodeToAfterSelectTextStart.Click += new System.EventHandler(this.buttonHexadecimalCodeToAfterSelectTextStart_Click);
            // 
            // перекадировкаToolStripMenuItem
            // 
            this.перекадировкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToBufferInTextCode,
            this.buttonFromBufferInTextCode,
            this.buttonClearBufferTextCode});
            this.перекадировкаToolStripMenuItem.Name = "перекадировкаToolStripMenuItem";
            this.перекадировкаToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.перекадировкаToolStripMenuItem.Text = "Перекодировка";
            // 
            // buttonToBufferInTextCode
            // 
            this.buttonToBufferInTextCode.Name = "buttonToBufferInTextCode";
            this.buttonToBufferInTextCode.Size = new System.Drawing.Size(557, 26);
            this.buttonToBufferInTextCode.Text = "Скопировать текст в буфер в выбранной кодировке";
            this.buttonToBufferInTextCode.Click += new System.EventHandler(this.buttonToBufferInTextCode_Click);
            // 
            // buttonFromBufferInTextCode
            // 
            this.buttonFromBufferInTextCode.Name = "buttonFromBufferInTextCode";
            this.buttonFromBufferInTextCode.Size = new System.Drawing.Size(557, 26);
            this.buttonFromBufferInTextCode.Text = "Скопировать текст из буфера в выбранной кодировке";
            this.buttonFromBufferInTextCode.Click += new System.EventHandler(this.buttonFromBufferInTextCode_Click);
            // 
            // buttonClearBufferTextCode
            // 
            this.buttonClearBufferTextCode.Name = "buttonClearBufferTextCode";
            this.buttonClearBufferTextCode.Size = new System.Drawing.Size(557, 26);
            this.buttonClearBufferTextCode.Text = "Очистить буфер";
            this.buttonClearBufferTextCode.Click += new System.EventHandler(this.buttonClearBufferTextCode_Click);
            // 
            // исправленияToolStripMenuItem
            // 
            this.исправленияToolStripMenuItem.BackColor = System.Drawing.Color.LightGray;
            this.исправленияToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.переводВВерхнийРегистрToolStripMenuItem,
            this.переводВНижнийРегистрToolStripMenuItem,
            this.buttonReplace});
            this.исправленияToolStripMenuItem.Margin = new System.Windows.Forms.Padding(5);
            this.исправленияToolStripMenuItem.Name = "исправленияToolStripMenuItem";
            this.исправленияToolStripMenuItem.Size = new System.Drawing.Size(137, 25);
            this.исправленияToolStripMenuItem.Text = "Исправления";
            // 
            // переводВВерхнийРегистрToolStripMenuItem
            // 
            this.переводВВерхнийРегистрToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вToolStripMenuItem,
            this.вставитьВКонцеТекстаToolStripMenuItem,
            this.вставитьВНачалеТекстаToolStripMenuItem});
            this.переводВВерхнийРегистрToolStripMenuItem.Name = "переводВВерхнийРегистрToolStripMenuItem";
            this.переводВВерхнийРегистрToolStripMenuItem.Size = new System.Drawing.Size(334, 26);
            this.переводВВерхнийРегистрToolStripMenuItem.Text = "Перевод в нижний регистр";
            // 
            // вToolStripMenuItem
            // 
            this.вToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToLowerAllText,
            this.buttonToLowerSellectedText,
            this.buttonToLowerOutSellectedText,
            this.buttonToLowerEndSellectedText,
            this.buttonToLowerStartSellectedText,
            this.buttonToLowerChooseText});
            this.вToolStripMenuItem.Name = "вToolStripMenuItem";
            this.вToolStripMenuItem.Size = new System.Drawing.Size(302, 26);
            this.вToolStripMenuItem.Text = "Вставить вместо текста";
            // 
            // buttonToLowerAllText
            // 
            this.buttonToLowerAllText.Name = "buttonToLowerAllText";
            this.buttonToLowerAllText.Size = new System.Drawing.Size(363, 26);
            this.buttonToLowerAllText.Text = "Весь текст";
            this.buttonToLowerAllText.Click += new System.EventHandler(this.buttonToLowerAllText_Click);
            // 
            // buttonToLowerSellectedText
            // 
            this.buttonToLowerSellectedText.Name = "buttonToLowerSellectedText";
            this.buttonToLowerSellectedText.Size = new System.Drawing.Size(363, 26);
            this.buttonToLowerSellectedText.Text = "Выделенный текст";
            this.buttonToLowerSellectedText.Click += new System.EventHandler(this.buttonToLowerSellectedText_Click);
            // 
            // buttonToLowerOutSellectedText
            // 
            this.buttonToLowerOutSellectedText.Name = "buttonToLowerOutSellectedText";
            this.buttonToLowerOutSellectedText.Size = new System.Drawing.Size(363, 26);
            this.buttonToLowerOutSellectedText.Text = "Без выделенного текста";
            this.buttonToLowerOutSellectedText.Click += new System.EventHandler(this.buttonToLowerOutSellectedText_Click);
            // 
            // buttonToLowerEndSellectedText
            // 
            this.buttonToLowerEndSellectedText.Name = "buttonToLowerEndSellectedText";
            this.buttonToLowerEndSellectedText.Size = new System.Drawing.Size(363, 26);
            this.buttonToLowerEndSellectedText.Text = "После выделенного фрагмента";
            this.buttonToLowerEndSellectedText.Click += new System.EventHandler(this.buttonToLowerEndSellectedText_Click);
            // 
            // buttonToLowerStartSellectedText
            // 
            this.buttonToLowerStartSellectedText.Name = "buttonToLowerStartSellectedText";
            this.buttonToLowerStartSellectedText.Size = new System.Drawing.Size(363, 26);
            this.buttonToLowerStartSellectedText.Text = "До выделенного фрагмента";
            this.buttonToLowerStartSellectedText.Click += new System.EventHandler(this.buttonToLowerStartSellectedText_Click);
            // 
            // buttonToLowerChooseText
            // 
            this.buttonToLowerChooseText.Name = "buttonToLowerChooseText";
            this.buttonToLowerChooseText.Size = new System.Drawing.Size(363, 26);
            this.buttonToLowerChooseText.Text = "\"Вывести/Сохранить\"";
            this.buttonToLowerChooseText.Click += new System.EventHandler(this.buttonToLowerChooseText_Click);
            // 
            // вставитьВКонцеТекстаToolStripMenuItem
            // 
            this.вставитьВКонцеТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToLowerAllTextEnd,
            this.buttonToLowerSellectedTextEnd,
            this.buttonToLowerOutSellectedTextEnd,
            this.buttonToLowerStartSellectedTextStart,
            this.buttonToLowerEndSellectedTextStart,
            this.buttonToLowerChooseTextEnd});
            this.вставитьВКонцеТекстаToolStripMenuItem.Name = "вставитьВКонцеТекстаToolStripMenuItem";
            this.вставитьВКонцеТекстаToolStripMenuItem.Size = new System.Drawing.Size(302, 26);
            this.вставитьВКонцеТекстаToolStripMenuItem.Text = "Вставить в конце текста";
            // 
            // buttonToLowerAllTextEnd
            // 
            this.buttonToLowerAllTextEnd.Name = "buttonToLowerAllTextEnd";
            this.buttonToLowerAllTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerAllTextEnd.Text = "Весть текст";
            this.buttonToLowerAllTextEnd.Click += new System.EventHandler(this.buttonToLowerAllTextEnd_Click);
            // 
            // buttonToLowerSellectedTextEnd
            // 
            this.buttonToLowerSellectedTextEnd.Name = "buttonToLowerSellectedTextEnd";
            this.buttonToLowerSellectedTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerSellectedTextEnd.Text = "Выделенный текст";
            this.buttonToLowerSellectedTextEnd.Click += new System.EventHandler(this.buttonToLowerSellectedTextEnd_Click);
            // 
            // buttonToLowerOutSellectedTextEnd
            // 
            this.buttonToLowerOutSellectedTextEnd.Name = "buttonToLowerOutSellectedTextEnd";
            this.buttonToLowerOutSellectedTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerOutSellectedTextEnd.Text = "Без выделенного текста";
            this.buttonToLowerOutSellectedTextEnd.Click += new System.EventHandler(this.buttonToLowerOutSellectedTextEnd_Click);
            // 
            // buttonToLowerStartSellectedTextStart
            // 
            this.buttonToLowerStartSellectedTextStart.Name = "buttonToLowerStartSellectedTextStart";
            this.buttonToLowerStartSellectedTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerStartSellectedTextStart.Text = "До выделенного текста";
            this.buttonToLowerStartSellectedTextStart.Click += new System.EventHandler(this.buttonToLowerStartSellectedTextStart_Click);
            // 
            // buttonToLowerEndSellectedTextStart
            // 
            this.buttonToLowerEndSellectedTextStart.Name = "buttonToLowerEndSellectedTextStart";
            this.buttonToLowerEndSellectedTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerEndSellectedTextStart.Text = "После выделенного текста";
            this.buttonToLowerEndSellectedTextStart.Click += new System.EventHandler(this.buttonToLowerEndSellectedTextStart_Click);
            // 
            // buttonToLowerChooseTextEnd
            // 
            this.buttonToLowerChooseTextEnd.Name = "buttonToLowerChooseTextEnd";
            this.buttonToLowerChooseTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerChooseTextEnd.Text = "\"Вывести/Сохранить\"";
            this.buttonToLowerChooseTextEnd.Click += new System.EventHandler(this.buttonToLowerChooseTextEnd_Click);
            // 
            // вставитьВНачалеТекстаToolStripMenuItem
            // 
            this.вставитьВНачалеТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToLowerAllTextStart,
            this.buttonToLowerSellectedTextStart,
            this.buttonToLowerOutSellectedTextStart,
            this.buttonToLowerStartSellectedTextEnd,
            this.buttonToLowerEndSellectedTextEnd,
            this.buttonToLowerChooseTextStart});
            this.вставитьВНачалеТекстаToolStripMenuItem.Name = "вставитьВНачалеТекстаToolStripMenuItem";
            this.вставитьВНачалеТекстаToolStripMenuItem.Size = new System.Drawing.Size(302, 26);
            this.вставитьВНачалеТекстаToolStripMenuItem.Text = "Вставить в начале текста";
            // 
            // buttonToLowerAllTextStart
            // 
            this.buttonToLowerAllTextStart.Name = "buttonToLowerAllTextStart";
            this.buttonToLowerAllTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerAllTextStart.Text = "Весь текст";
            this.buttonToLowerAllTextStart.Click += new System.EventHandler(this.buttonToLowerAllTextStart_Click);
            // 
            // buttonToLowerSellectedTextStart
            // 
            this.buttonToLowerSellectedTextStart.Name = "buttonToLowerSellectedTextStart";
            this.buttonToLowerSellectedTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerSellectedTextStart.Text = "Выделенный текст";
            this.buttonToLowerSellectedTextStart.Click += new System.EventHandler(this.buttonToLowerSellectedTextStart_Click);
            // 
            // buttonToLowerOutSellectedTextStart
            // 
            this.buttonToLowerOutSellectedTextStart.Name = "buttonToLowerOutSellectedTextStart";
            this.buttonToLowerOutSellectedTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerOutSellectedTextStart.Text = "Без выделенного текста";
            this.buttonToLowerOutSellectedTextStart.Click += new System.EventHandler(this.buttonToLowerOutSellectedTextStart_Click);
            // 
            // buttonToLowerStartSellectedTextEnd
            // 
            this.buttonToLowerStartSellectedTextEnd.Name = "buttonToLowerStartSellectedTextEnd";
            this.buttonToLowerStartSellectedTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerStartSellectedTextEnd.Text = "До выделенного текста";
            this.buttonToLowerStartSellectedTextEnd.Click += new System.EventHandler(this.buttonToLowerStartSellectedTextEnd_Click);
            // 
            // buttonToLowerEndSellectedTextEnd
            // 
            this.buttonToLowerEndSellectedTextEnd.Name = "buttonToLowerEndSellectedTextEnd";
            this.buttonToLowerEndSellectedTextEnd.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerEndSellectedTextEnd.Text = "После выделенного текста";
            this.buttonToLowerEndSellectedTextEnd.Click += new System.EventHandler(this.buttonToLowerEndSellectedTextEnd_Click);
            // 
            // buttonToLowerChooseTextStart
            // 
            this.buttonToLowerChooseTextStart.Name = "buttonToLowerChooseTextStart";
            this.buttonToLowerChooseTextStart.Size = new System.Drawing.Size(324, 26);
            this.buttonToLowerChooseTextStart.Text = "\"Вывести/Сохранить\"";
            this.buttonToLowerChooseTextStart.Click += new System.EventHandler(this.buttonToLowerChooseTextStart_Click);
            // 
            // переводВНижнийРегистрToolStripMenuItem
            // 
            this.переводВНижнийРегистрToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вставитьВместоТекстаToolStripMenuItem,
            this.вставитьВКонцеТекстаToolStripMenuItem1,
            this.вставитьВНачалеТекстаToolStripMenuItem1});
            this.переводВНижнийРегистрToolStripMenuItem.Name = "переводВНижнийРегистрToolStripMenuItem";
            this.переводВНижнийРегистрToolStripMenuItem.Size = new System.Drawing.Size(334, 26);
            this.переводВНижнийРегистрToolStripMenuItem.Text = "Перевод в верхний регистр";
            // 
            // вставитьВместоТекстаToolStripMenuItem
            // 
            this.вставитьВместоТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToUpperAllText,
            this.buttonToUpperSellectedText,
            this.buttonToUpperOutSellectedText,
            this.buttonToUpperEndSellectedText,
            this.buttonToUpperStartSellectedText,
            this.buttonToUpperChooseText});
            this.вставитьВместоТекстаToolStripMenuItem.Name = "вставитьВместоТекстаToolStripMenuItem";
            this.вставитьВместоТекстаToolStripMenuItem.Size = new System.Drawing.Size(302, 26);
            this.вставитьВместоТекстаToolStripMenuItem.Text = "Вставить вместо текста";
            // 
            // buttonToUpperAllText
            // 
            this.buttonToUpperAllText.Name = "buttonToUpperAllText";
            this.buttonToUpperAllText.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperAllText.Text = "Весь текст";
            this.buttonToUpperAllText.Click += new System.EventHandler(this.buttonToUpperAllText_Click);
            // 
            // buttonToUpperSellectedText
            // 
            this.buttonToUpperSellectedText.Name = "buttonToUpperSellectedText";
            this.buttonToUpperSellectedText.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperSellectedText.Text = "Выделенный текст";
            this.buttonToUpperSellectedText.Click += new System.EventHandler(this.buttonToUpperSellectedText_Click);
            // 
            // buttonToUpperOutSellectedText
            // 
            this.buttonToUpperOutSellectedText.Name = "buttonToUpperOutSellectedText";
            this.buttonToUpperOutSellectedText.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperOutSellectedText.Text = "Без выделенного текста";
            this.buttonToUpperOutSellectedText.Click += new System.EventHandler(this.buttonToUpperOutSellectedText_Click);
            // 
            // buttonToUpperEndSellectedText
            // 
            this.buttonToUpperEndSellectedText.Name = "buttonToUpperEndSellectedText";
            this.buttonToUpperEndSellectedText.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperEndSellectedText.Text = "После выделенного фрагмента";
            this.buttonToUpperEndSellectedText.Click += new System.EventHandler(this.buttonToUpperEndSellectedText_Click);
            // 
            // buttonToUpperStartSellectedText
            // 
            this.buttonToUpperStartSellectedText.Name = "buttonToUpperStartSellectedText";
            this.buttonToUpperStartSellectedText.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperStartSellectedText.Text = "До выделенного текста";
            this.buttonToUpperStartSellectedText.Click += new System.EventHandler(this.buttonToUpperStartSellectedText_Click);
            // 
            // buttonToUpperChooseText
            // 
            this.buttonToUpperChooseText.Name = "buttonToUpperChooseText";
            this.buttonToUpperChooseText.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperChooseText.Text = "\"Вывести/Сохранить\"";
            this.buttonToUpperChooseText.Click += new System.EventHandler(this.buttonToUpperChooseText_Click);
            // 
            // вставитьВКонцеТекстаToolStripMenuItem1
            // 
            this.вставитьВКонцеТекстаToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToUpperAllTextEnd,
            this.buttonToUpperSellectedTextEnd,
            this.buttonToUpperOutSellectedTextEnd,
            this.buttonToUpperEndSellectedTextEnd,
            this.buttonToUpperStartSellectedTextEnd,
            this.buttonToUpperChooseTextEnd});
            this.вставитьВКонцеТекстаToolStripMenuItem1.Name = "вставитьВКонцеТекстаToolStripMenuItem1";
            this.вставитьВКонцеТекстаToolStripMenuItem1.Size = new System.Drawing.Size(302, 26);
            this.вставитьВКонцеТекстаToolStripMenuItem1.Text = "Вставить в конце текста";
            // 
            // buttonToUpperAllTextEnd
            // 
            this.buttonToUpperAllTextEnd.Name = "buttonToUpperAllTextEnd";
            this.buttonToUpperAllTextEnd.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperAllTextEnd.Text = "Весь текст";
            this.buttonToUpperAllTextEnd.Click += new System.EventHandler(this.buttonToUpperAllTextEnd_Click);
            // 
            // buttonToUpperSellectedTextEnd
            // 
            this.buttonToUpperSellectedTextEnd.Name = "buttonToUpperSellectedTextEnd";
            this.buttonToUpperSellectedTextEnd.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperSellectedTextEnd.Text = "Выделенный текст";
            this.buttonToUpperSellectedTextEnd.Click += new System.EventHandler(this.buttonToUpperSellectedTextEnd_Click);
            // 
            // buttonToUpperOutSellectedTextEnd
            // 
            this.buttonToUpperOutSellectedTextEnd.Name = "buttonToUpperOutSellectedTextEnd";
            this.buttonToUpperOutSellectedTextEnd.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperOutSellectedTextEnd.Text = "Без выделенного текста";
            this.buttonToUpperOutSellectedTextEnd.Click += new System.EventHandler(this.buttonToUpperOutSellectedTextEnd_Click);
            // 
            // buttonToUpperEndSellectedTextEnd
            // 
            this.buttonToUpperEndSellectedTextEnd.Name = "buttonToUpperEndSellectedTextEnd";
            this.buttonToUpperEndSellectedTextEnd.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperEndSellectedTextEnd.Text = "После выделенного фрагмента";
            this.buttonToUpperEndSellectedTextEnd.Click += new System.EventHandler(this.buttonToUpperEndSellectedTextEnd_Click);
            // 
            // buttonToUpperStartSellectedTextEnd
            // 
            this.buttonToUpperStartSellectedTextEnd.Name = "buttonToUpperStartSellectedTextEnd";
            this.buttonToUpperStartSellectedTextEnd.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperStartSellectedTextEnd.Text = "До выделенного фрагмента";
            this.buttonToUpperStartSellectedTextEnd.Click += new System.EventHandler(this.buttonToUpperStartSellectedTextEnd_Click);
            // 
            // buttonToUpperChooseTextEnd
            // 
            this.buttonToUpperChooseTextEnd.Name = "buttonToUpperChooseTextEnd";
            this.buttonToUpperChooseTextEnd.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperChooseTextEnd.Text = "\"Вывести/Сохранить\"";
            this.buttonToUpperChooseTextEnd.Click += new System.EventHandler(this.buttonToUpperChooseTextEnd_Click);
            // 
            // вставитьВНачалеТекстаToolStripMenuItem1
            // 
            this.вставитьВНачалеТекстаToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToUpperAllTextStart,
            this.buttonToUpperSellectedTextStart,
            this.buttonToUpperOutSellectedTextStart,
            this.buttonToUpperEndSellectedTextStart,
            this.buttonToUpperStartSellectedTextStart,
            this.buttonToUpperChooseTextStart});
            this.вставитьВНачалеТекстаToolStripMenuItem1.Name = "вставитьВНачалеТекстаToolStripMenuItem1";
            this.вставитьВНачалеТекстаToolStripMenuItem1.Size = new System.Drawing.Size(302, 26);
            this.вставитьВНачалеТекстаToolStripMenuItem1.Text = "Вставить в начале текста";
            // 
            // buttonToUpperAllTextStart
            // 
            this.buttonToUpperAllTextStart.Name = "buttonToUpperAllTextStart";
            this.buttonToUpperAllTextStart.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperAllTextStart.Text = "Весь текст";
            this.buttonToUpperAllTextStart.Click += new System.EventHandler(this.buttonToUpperAllTextStart_Click);
            // 
            // buttonToUpperSellectedTextStart
            // 
            this.buttonToUpperSellectedTextStart.Name = "buttonToUpperSellectedTextStart";
            this.buttonToUpperSellectedTextStart.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperSellectedTextStart.Text = "Выделенный текст";
            this.buttonToUpperSellectedTextStart.Click += new System.EventHandler(this.buttonToUpperSellectedTextStart_Click);
            // 
            // buttonToUpperOutSellectedTextStart
            // 
            this.buttonToUpperOutSellectedTextStart.Name = "buttonToUpperOutSellectedTextStart";
            this.buttonToUpperOutSellectedTextStart.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperOutSellectedTextStart.Text = "Без выделенного текста";
            this.buttonToUpperOutSellectedTextStart.Click += new System.EventHandler(this.buttonToUpperOutSellectedTextStart_Click);
            // 
            // buttonToUpperEndSellectedTextStart
            // 
            this.buttonToUpperEndSellectedTextStart.Name = "buttonToUpperEndSellectedTextStart";
            this.buttonToUpperEndSellectedTextStart.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperEndSellectedTextStart.Text = "После выделенного фрагмента";
            this.buttonToUpperEndSellectedTextStart.Click += new System.EventHandler(this.buttonToUpperEndSellectedTextStart_Click);
            // 
            // buttonToUpperStartSellectedTextStart
            // 
            this.buttonToUpperStartSellectedTextStart.Name = "buttonToUpperStartSellectedTextStart";
            this.buttonToUpperStartSellectedTextStart.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperStartSellectedTextStart.Text = "До выделенного текста";
            this.buttonToUpperStartSellectedTextStart.Click += new System.EventHandler(this.buttonToUpperStartSellectedTextStart_Click);
            // 
            // buttonToUpperChooseTextStart
            // 
            this.buttonToUpperChooseTextStart.Name = "buttonToUpperChooseTextStart";
            this.buttonToUpperChooseTextStart.Size = new System.Drawing.Size(363, 26);
            this.buttonToUpperChooseTextStart.Text = "\"Вывести/Сохранить\"";
            this.buttonToUpperChooseTextStart.Click += new System.EventHandler(this.buttonToUpperChooseTextStart_Click);
            // 
            // buttonReplace
            // 
            this.buttonReplace.Name = "buttonReplace";
            this.buttonReplace.Size = new System.Drawing.Size(334, 26);
            this.buttonReplace.Text = "Заменить символы";
            this.buttonReplace.Click += new System.EventHandler(this.buttonReplace_Click);
            // 
            // буферОбменаToolStripMenuItem1
            // 
            this.буферОбменаToolStripMenuItem1.BackColor = System.Drawing.Color.LightGray;
            this.буферОбменаToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAllTextToClipboard1,
            this.загрузитьИзБуфераОбменаToolStripMenuItem});
            this.буферОбменаToolStripMenuItem1.Margin = new System.Windows.Forms.Padding(5);
            this.буферОбменаToolStripMenuItem1.Name = "буферОбменаToolStripMenuItem1";
            this.буферОбменаToolStripMenuItem1.Size = new System.Drawing.Size(146, 25);
            this.буферОбменаToolStripMenuItem1.Text = "Буфер обмена";
            // 
            // buttonAllTextToClipboard1
            // 
            this.buttonAllTextToClipboard1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAllTextToClipboard,
            this.buttonSelectedTextToClipboard,
            this.buttonOutSelectedTextToClipboard,
            this.buttonAfterSelectToClipboard,
            this.buttonBeforeSelectToClipboard,
            this.buttonChooseToClipboard});
            this.buttonAllTextToClipboard1.Name = "buttonAllTextToClipboard1";
            this.buttonAllTextToClipboard1.Size = new System.Drawing.Size(336, 26);
            this.buttonAllTextToClipboard1.Text = "Вывести в буфер обмена";
            // 
            // buttonAllTextToClipboard
            // 
            this.buttonAllTextToClipboard.Name = "buttonAllTextToClipboard";
            this.buttonAllTextToClipboard.Size = new System.Drawing.Size(324, 26);
            this.buttonAllTextToClipboard.Text = "Весь текст";
            this.buttonAllTextToClipboard.Click += new System.EventHandler(this.buttonAllTextToClipboard_Click);
            // 
            // buttonSelectedTextToClipboard
            // 
            this.buttonSelectedTextToClipboard.Name = "buttonSelectedTextToClipboard";
            this.buttonSelectedTextToClipboard.Size = new System.Drawing.Size(324, 26);
            this.buttonSelectedTextToClipboard.Text = "Выделенный текст";
            this.buttonSelectedTextToClipboard.Click += new System.EventHandler(this.buttonSelectedTextToClipboard_Click);
            // 
            // buttonOutSelectedTextToClipboard
            // 
            this.buttonOutSelectedTextToClipboard.Name = "buttonOutSelectedTextToClipboard";
            this.buttonOutSelectedTextToClipboard.Size = new System.Drawing.Size(324, 26);
            this.buttonOutSelectedTextToClipboard.Text = "Без выделенного текста";
            this.buttonOutSelectedTextToClipboard.Click += new System.EventHandler(this.buttonOutSelectedTextToClipboard_Click);
            // 
            // buttonAfterSelectToClipboard
            // 
            this.buttonAfterSelectToClipboard.Name = "buttonAfterSelectToClipboard";
            this.buttonAfterSelectToClipboard.Size = new System.Drawing.Size(324, 26);
            this.buttonAfterSelectToClipboard.Text = "После выделенного текста";
            this.buttonAfterSelectToClipboard.Click += new System.EventHandler(this.buttonAfterSelectToClipboard_Click);
            // 
            // buttonBeforeSelectToClipboard
            // 
            this.buttonBeforeSelectToClipboard.Name = "buttonBeforeSelectToClipboard";
            this.buttonBeforeSelectToClipboard.Size = new System.Drawing.Size(324, 26);
            this.buttonBeforeSelectToClipboard.Text = "До выделенного текста";
            this.buttonBeforeSelectToClipboard.Click += new System.EventHandler(this.buttonBeforeSelectToClipboard_Click);
            // 
            // buttonChooseToClipboard
            // 
            this.buttonChooseToClipboard.Name = "buttonChooseToClipboard";
            this.buttonChooseToClipboard.Size = new System.Drawing.Size(324, 26);
            this.buttonChooseToClipboard.Text = "\"Вывести/Сохранить\"";
            this.buttonChooseToClipboard.Click += new System.EventHandler(this.buttonChooseToClipboard_Click);
            // 
            // загрузитьИзБуфераОбменаToolStripMenuItem
            // 
            this.загрузитьИзБуфераОбменаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.дляВсегоТекстаToolStripMenuItem,
            this.дляВыделенногоТекстаToolStripMenuItem,
            this.дляВывестиСохранитьToolStripMenuItem});
            this.загрузитьИзБуфераОбменаToolStripMenuItem.Name = "загрузитьИзБуфераОбменаToolStripMenuItem";
            this.загрузитьИзБуфераОбменаToolStripMenuItem.Size = new System.Drawing.Size(336, 26);
            this.загрузитьИзБуфераОбменаToolStripMenuItem.Text = "Загрузить из буфера обмена";
            // 
            // дляВсегоТекстаToolStripMenuItem
            // 
            this.дляВсегоТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonLoadAllTextFromClipboard,
            this.buttonLoadAllTextFromClipboardStart,
            this.buttonLoadAllTextFromClipboardEnd});
            this.дляВсегоТекстаToolStripMenuItem.Name = "дляВсегоТекстаToolStripMenuItem";
            this.дляВсегоТекстаToolStripMenuItem.Size = new System.Drawing.Size(313, 26);
            this.дляВсегоТекстаToolStripMenuItem.Text = "Для всего текста";
            // 
            // buttonLoadAllTextFromClipboard
            // 
            this.buttonLoadAllTextFromClipboard.Name = "buttonLoadAllTextFromClipboard";
            this.buttonLoadAllTextFromClipboard.Size = new System.Drawing.Size(167, 26);
            this.buttonLoadAllTextFromClipboard.Text = "Вместо";
            this.buttonLoadAllTextFromClipboard.Click += new System.EventHandler(this.buttonLoadAllTextFromClipboard_Click);
            // 
            // buttonLoadAllTextFromClipboardStart
            // 
            this.buttonLoadAllTextFromClipboardStart.Name = "buttonLoadAllTextFromClipboardStart";
            this.buttonLoadAllTextFromClipboardStart.Size = new System.Drawing.Size(167, 26);
            this.buttonLoadAllTextFromClipboardStart.Text = "В начале";
            this.buttonLoadAllTextFromClipboardStart.Click += new System.EventHandler(this.buttonLoadAllTextFromClipboardStart_Click);
            // 
            // buttonLoadAllTextFromClipboardEnd
            // 
            this.buttonLoadAllTextFromClipboardEnd.Name = "buttonLoadAllTextFromClipboardEnd";
            this.buttonLoadAllTextFromClipboardEnd.Size = new System.Drawing.Size(167, 26);
            this.buttonLoadAllTextFromClipboardEnd.Text = "В конце";
            this.buttonLoadAllTextFromClipboardEnd.Click += new System.EventHandler(this.buttonLoadAllTextFromClipboardEnd_Click);
            // 
            // дляВыделенногоТекстаToolStripMenuItem
            // 
            this.дляВыделенногоТекстаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonLoadSelectTextFromClipboard,
            this.buttonLoadSelectTextFromClipboardStart,
            this.buttonLoadSelectTextFromClipboardEnd});
            this.дляВыделенногоТекстаToolStripMenuItem.Name = "дляВыделенногоТекстаToolStripMenuItem";
            this.дляВыделенногоТекстаToolStripMenuItem.Size = new System.Drawing.Size(313, 26);
            this.дляВыделенногоТекстаToolStripMenuItem.Text = "Для выделенного текста";
            // 
            // buttonLoadSelectTextFromClipboard
            // 
            this.buttonLoadSelectTextFromClipboard.Name = "buttonLoadSelectTextFromClipboard";
            this.buttonLoadSelectTextFromClipboard.Size = new System.Drawing.Size(167, 26);
            this.buttonLoadSelectTextFromClipboard.Text = "Вместо";
            this.buttonLoadSelectTextFromClipboard.Click += new System.EventHandler(this.buttonLoadSelectTextFromClipboard_Click);
            // 
            // buttonLoadSelectTextFromClipboardStart
            // 
            this.buttonLoadSelectTextFromClipboardStart.Name = "buttonLoadSelectTextFromClipboardStart";
            this.buttonLoadSelectTextFromClipboardStart.Size = new System.Drawing.Size(167, 26);
            this.buttonLoadSelectTextFromClipboardStart.Text = "В начале";
            this.buttonLoadSelectTextFromClipboardStart.Click += new System.EventHandler(this.buttonLoadSelectTextFromClipboardStart_Click);
            // 
            // buttonLoadSelectTextFromClipboardEnd
            // 
            this.buttonLoadSelectTextFromClipboardEnd.Name = "buttonLoadSelectTextFromClipboardEnd";
            this.buttonLoadSelectTextFromClipboardEnd.Size = new System.Drawing.Size(167, 26);
            this.buttonLoadSelectTextFromClipboardEnd.Text = "В конце";
            this.buttonLoadSelectTextFromClipboardEnd.Click += new System.EventHandler(this.buttonLoadSelectTextFromClipboardEnd_Click);
            // 
            // дляВывестиСохранитьToolStripMenuItem
            // 
            this.дляВывестиСохранитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonLoadChooseTextFromClipboard,
            this.buttonLoadChooseTextFromClipboardStart,
            this.buttonLoadChooseTextFromClipboardEnd});
            this.дляВывестиСохранитьToolStripMenuItem.Name = "дляВывестиСохранитьToolStripMenuItem";
            this.дляВывестиСохранитьToolStripMenuItem.Size = new System.Drawing.Size(313, 26);
            this.дляВывестиСохранитьToolStripMenuItem.Text = "Для \"Вывести/Сохранить\"";
            // 
            // buttonLoadChooseTextFromClipboard
            // 
            this.buttonLoadChooseTextFromClipboard.Name = "buttonLoadChooseTextFromClipboard";
            this.buttonLoadChooseTextFromClipboard.Size = new System.Drawing.Size(167, 26);
            this.buttonLoadChooseTextFromClipboard.Text = "Вместо";
            this.buttonLoadChooseTextFromClipboard.Click += new System.EventHandler(this.buttonLoadChooseTextFromClipboard_Click);
            // 
            // buttonLoadChooseTextFromClipboardStart
            // 
            this.buttonLoadChooseTextFromClipboardStart.Name = "buttonLoadChooseTextFromClipboardStart";
            this.buttonLoadChooseTextFromClipboardStart.Size = new System.Drawing.Size(167, 26);
            this.buttonLoadChooseTextFromClipboardStart.Text = "В начале";
            this.buttonLoadChooseTextFromClipboardStart.Click += new System.EventHandler(this.buttonLoadChooseTextFromClipboardStart_Click);
            // 
            // buttonLoadChooseTextFromClipboardEnd
            // 
            this.buttonLoadChooseTextFromClipboardEnd.Name = "buttonLoadChooseTextFromClipboardEnd";
            this.buttonLoadChooseTextFromClipboardEnd.Size = new System.Drawing.Size(167, 26);
            this.buttonLoadChooseTextFromClipboardEnd.Text = "В конце";
            this.buttonLoadChooseTextFromClipboardEnd.Click += new System.EventHandler(this.buttonLoadChooseTextFromClipboardEnd_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClear.Location = new System.Drawing.Point(5, 55);
            this.buttonClear.Margin = new System.Windows.Forms.Padding(5);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(381, 30);
            this.buttonClear.TabIndex = 4;
            this.buttonClear.Text = "Очистить текст";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // groupBox1
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.groupBox1, 2);
            this.groupBox1.Controls.Add(this.tableLayoutPanel3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 150);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(782, 60);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Вывести/Сохранить; Добавить в конце; Добавить в начале; Вместо текста";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.radioButton1, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.radioButtonAllText, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(776, 27);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButton1.Location = new System.Drawing.Point(391, 3);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(382, 21);
            this.radioButton1.TabIndex = 1;
            this.radioButton1.Text = "Выделенный текст";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButtonAllText
            // 
            this.radioButtonAllText.AutoSize = true;
            this.radioButtonAllText.Checked = true;
            this.radioButtonAllText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonAllText.Location = new System.Drawing.Point(3, 3);
            this.radioButtonAllText.Name = "radioButtonAllText";
            this.radioButtonAllText.Size = new System.Drawing.Size(382, 21);
            this.radioButtonAllText.TabIndex = 0;
            this.radioButtonAllText.TabStop = true;
            this.radioButtonAllText.Text = "Весь текст";
            this.radioButtonAllText.UseVisualStyleBackColor = true;
            // 
            // checkBoxAutoInput
            // 
            this.checkBoxAutoInput.AutoSize = true;
            this.checkBoxAutoInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoInput.Location = new System.Drawing.Point(394, 93);
            this.checkBoxAutoInput.Name = "checkBoxAutoInput";
            this.checkBoxAutoInput.Size = new System.Drawing.Size(385, 54);
            this.checkBoxAutoInput.TabIndex = 6;
            this.checkBoxAutoInput.Text = "Автоввод с главного экрана";
            this.checkBoxAutoInput.UseVisualStyleBackColor = true;
            this.checkBoxAutoInput.CheckedChanged += new System.EventHandler(this.checkBoxAutoInput_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBoxTextCode);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 93);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(385, 54);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Кодировка для обмена с файлами";
            // 
            // comboBoxTextCode
            // 
            this.comboBoxTextCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxTextCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTextCode.FormattingEnabled = true;
            this.comboBoxTextCode.Items.AddRange(new object[] {
            "Авто",
            "Default",
            "Unicode",
            "ASCII",
            "UTF7",
            "UTF8",
            "UTF32",
            "BigEndianUnicode"});
            this.comboBoxTextCode.Location = new System.Drawing.Point(3, 30);
            this.comboBoxTextCode.Margin = new System.Windows.Forms.Padding(0);
            this.comboBoxTextCode.Name = "comboBoxTextCode";
            this.comboBoxTextCode.Size = new System.Drawing.Size(379, 29);
            this.comboBoxTextCode.TabIndex = 0;
            // 
            // notifyIconThis
            // 
            this.notifyIconThis.Text = "notifyIcon1";
            this.notifyIconThis.Visible = true;
            // 
            // TextEditorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(782, 553);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStripEdit;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "TextEditorForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Текстовый редактор";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.menuStripEdit.ResumeLayout(false);
            this.menuStripEdit.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private TextBoxWithLine textBoxValue;
        private System.Windows.Forms.CheckBox checkBoxAutoSave;
        private System.Windows.Forms.ToolStripMenuItem вывестисохранитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonWrite;
        private System.Windows.Forms.ToolStripMenuItem ввестиИзВнеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonFromMainFrom;
        private System.Windows.Forms.MenuStrip menuStripEdit;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynary;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynary;
        private System.Windows.Forms.ToolStripMenuItem буферОбменаToolStripMenuItem;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.ToolStripMenuItem вБуферОбменаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToTextFile;
        private System.Windows.Forms.ToolStripMenuItem ToTimeBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonToSettingsBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonDialogForm;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromSecondEnd1;
        private System.Windows.Forms.ToolStripMenuItem buttonAddThisText;
        private System.Windows.Forms.ToolStripMenuItem buttonAddClipboardEnd;
        private System.Windows.Forms.ToolStripMenuItem вставитьВНачалеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddThisStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAddClipboardStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromMain;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromMainStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromTimeBufferEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromTimeBufferStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromLongBufferEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromLongBufferStart;
        private System.Windows.Forms.ToolStripMenuItem вместоВыделенногоТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SetFromMainBySelected;
        private System.Windows.Forms.ToolStripMenuItem buttonSetTextBySelected;
        private System.Windows.Forms.ToolStripMenuItem buttonFromClipBoardBySelected;
        private System.Windows.Forms.ToolStripMenuItem buttonFromTimeBufferBySelected;
        private System.Windows.Forms.ToolStripMenuItem buttonFromLongBufferBySelected;
        private System.Windows.Forms.ToolStripMenuItem buttonAddProgramInfoBySelected;
        private System.Windows.Forms.ToolStripMenuItem buttonAddProgramInfoEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddProgramInfoStart;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.RadioButton radioButtonAllText;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.ToolStripMenuItem изТекстовогоФайлаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem секундомеромТаймеромToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem калькуляторомToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изПамятиКалькулятораToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изСпискаЗапомненныхИзмеренийСекундомеромToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectedTextClear;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromTextFileEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromTextFileStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromSecondEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFromSecondStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAddCalculatorEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddCalculatorStart;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcMemoryEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcMemoryStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAddSecondSavedEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddSecondSavedStart;
        private System.Windows.Forms.ToolStripMenuItem buttonSetFeathersList;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFeathersListEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddFeathersListStart;
        private System.Windows.Forms.ToolStripMenuItem buttonGetNotification;
        private System.Windows.Forms.ToolStripMenuItem buttonSetValueByTextOutput;
        private System.Windows.Forms.ToolStripMenuItem buttonAddOutputEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddOutputStart;
        private System.Windows.Forms.ToolStripMenuItem buttonShowToast;
        private System.Windows.Forms.NotifyIcon notifyIconThis;
        private System.Windows.Forms.ToolStripMenuItem buttonSetBallonText;
        private System.Windows.Forms.CheckBox checkBoxAutoInput;
        private System.Windows.Forms.ToolStripMenuItem buttonSaveAllText;
        private System.Windows.Forms.ToolStripMenuItem выделенияТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonDropSelected;
        private System.Windows.Forms.ToolStripMenuItem выделитьВсёДоВыделенногоФрагментаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectedStartToSelected;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectedStartOutSelected;
        private System.Windows.Forms.ToolStripMenuItem выделитьВсёПослеВыделенногоФрагментаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectedEndToSelected;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectedEndOutSelected;
        private System.Windows.Forms.ToolStripMenuItem вместоТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryStart;
        private System.Windows.Forms.ToolStripMenuItem весьТекстToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynarySelected;
        private System.Windows.Forms.ToolStripMenuItem весьТекстToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryEndSelected;
        private System.Windows.Forms.ToolStripMenuItem весьТекстToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryStartSelected;
        private System.Windows.Forms.ToolStripMenuItem вместоТекстаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem весьТекстToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynarySelected;
        private System.Windows.Forms.ToolStripMenuItem вКонцеТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottonFromBynaryOutSellStart1;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynaryEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynaryEndSelected;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynaryStart;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynaryStartSelected;
        private System.Windows.Forms.ToolStripMenuItem относительноВыделенногоТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSetSelectedText;
        private System.Windows.Forms.ToolStripMenuItem buttonFromWithoutBySelected;
        private System.Windows.Forms.ToolStripMenuItem buttonSetBeforeSelected;
        private System.Windows.Forms.ToolStripMenuItem bottonToBynaryOutSell;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryBefore;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryAfter;
        private System.Windows.Forms.ToolStripMenuItem относительноВыделенногоТекстаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonSetSellectedText;
        private System.Windows.Forms.ToolStripMenuItem buttonSetWithoutSell;
        private System.Windows.Forms.ToolStripMenuItem buttonSetBeforeSell;
        private System.Windows.Forms.ToolStripMenuItem buttonSetAfterSell;
        private System.Windows.Forms.ToolStripMenuItem bottonToBynaryOutSellEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryBeforeEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryAfterEnd;
        private System.Windows.Forms.ToolStripMenuItem bottonToBynaryOutSellStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryBeforeStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryAfterStart;
        private System.Windows.Forms.ToolStripMenuItem bottonFromBynaryOutSell;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynaryBefore;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynaryAfter;
        private System.Windows.Forms.ToolStripMenuItem bottonFromBynaryOutSellEnd;
        private System.Windows.Forms.ToolStripMenuItem bottonFromBynaryBeforeSellEnd;
        private System.Windows.Forms.ToolStripMenuItem bottonFromBynaryAfterSellEnd;
        private System.Windows.Forms.ToolStripMenuItem bottonFromBynaryOutSellStart;
        private System.Windows.Forms.ToolStripMenuItem bottonFromBynaryBeforeSellStart;
        private System.Windows.Forms.ToolStripMenuItem bottonFromBynaryAfterSellStart;
        private System.Windows.Forms.ToolStripMenuItem относительноВыделенногоТекстаToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem buttonAddSelectedTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddWithoutSelectedEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddBeforeEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddAfterEnd;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonAddSelectedTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAddWithoutSelectedStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAddBeforeStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAddAfterStart;
        private System.Windows.Forms.ToolStripMenuItem переместитьВыделениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonRunSelectLeft1;
        private System.Windows.Forms.ToolStripMenuItem на1СимволВправоToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonRunSelectLeft;
        private System.Windows.Forms.ToolStripMenuItem buttonAddSelectSymwolLeft;
        private System.Windows.Forms.ToolStripMenuItem buttonDropSelectSymwolLeft;
        private System.Windows.Forms.ToolStripMenuItem buttonRunSelectRight;
        private System.Windows.Forms.ToolStripMenuItem buttonAddSelectSymwolRight;
        private System.Windows.Forms.ToolStripMenuItem buttonDropSelectSymwolRight;
        private System.Windows.Forms.ToolStripMenuItem переместитьНаКоличествоВыделенныхСимволовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem publicRunSellectedCountLeft;
        private System.Windows.Forms.ToolStripMenuItem publicRunSellectedCountRight;
        private System.Windows.Forms.ToolStripMenuItem добавитьКоличествоВыделенныхСимволовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem publicAddSellectedCountLeft;
        private System.Windows.Forms.ToolStripMenuItem publicAddSellectedCountRight;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpper;
        private System.Windows.Forms.ToolStripMenuItem buttonToLower;
        private System.Windows.Forms.ToolStripMenuItem четверичныйКодToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem восьмеричныйКодToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem шестнадцатиричныйКодToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemBynaryCode;
        private System.Windows.Forms.ToolStripMenuItem исправленияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem переводВВерхнийРегистрToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem переводВНижнийРегистрToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вставитьВКонцеТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вставитьВНачалеТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToBynaryCodeChoose;
        private System.Windows.Forms.ToolStripMenuItem buttonAddBynaryCodeChooseEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddBynaryCodeChooseStart;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynaryCodeCooseStart;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynaryCodeCooseEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBynaryCodeCoose;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerAllText;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerSellectedText;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerOutSellectedText;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerEndSellectedText;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerStartSellectedText;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerChooseText;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerAllTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerSellectedTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerOutSellectedTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerStartSellectedTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerEndSellectedTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerChooseTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerAllTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerSellectedTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerOutSellectedTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerStartSellectedTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerEndSellectedTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToLowerChooseTextStart;
        private System.Windows.Forms.ToolStripMenuItem вставитьВместоТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperAllText;
        private System.Windows.Forms.ToolStripMenuItem вставитьВКонцеТекстаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem вставитьВНачалеТекстаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperSellectedText;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperOutSellectedText;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperEndSellectedText;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperStartSellectedText;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperChooseText;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperAllTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperSellectedTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperOutSellectedTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperEndSellectedTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperAllTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperStartSellectedTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperChooseTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperSellectedTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperOutSellectedTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperEndSellectedTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperStartSellectedTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonToUpperChooseTextStart;
        private System.Windows.Forms.ToolStripMenuItem butonSetReservNames;
        private System.Windows.Forms.ToolStripMenuItem butonSetReservNamesEnd;
        private System.Windows.Forms.ToolStripMenuItem butonSetReservNamesStart;
        private System.Windows.Forms.ToolStripMenuItem buttonSetJsonStruct;
        private System.Windows.Forms.ToolStripMenuItem buttonSetJsonStructEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonSetJsonStructStart;
        private System.Windows.Forms.ToolStripMenuItem конвертироватьВЧетверичныйКодToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вместоТекстаToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem buttonTextToQuaternaryCode;
        private System.Windows.Forms.ToolStripMenuItem конвертироватьИзЧетверичногоКодаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вместоТекстаToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem buttonQuaternaryCodeToText;
        private System.Windows.Forms.ToolStripMenuItem конвертироватьВВосьмеричныйКодToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вместоТекстаToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem buttonTextToOctalCode;
        private System.Windows.Forms.ToolStripMenuItem конвертироватьИзВосьмеричногоКодаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вместоТекстаToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem buttonOctalCodeToText;
        private System.Windows.Forms.ToolStripMenuItem конвертироватьВШестнадцатеричныйКодToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вместоТекстаToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem buttonTextToHexadecimalCode;
        private System.Windows.Forms.ToolStripMenuItem конвертироватьИзШестнадцатеричногоКодаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вместоТекстаToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToText;
        private System.Windows.Forms.ToolStripMenuItem буферОбменаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonAllTextToClipboard1;
        private System.Windows.Forms.ToolStripMenuItem buttonAllTextToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectedTextToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonOutSelectedTextToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonAfterSelectToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonBeforeSelectToClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonChooseToClipboard;
        private System.Windows.Forms.ToolStripMenuItem загрузитьИзБуфераОбменаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem дляВсегоТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadAllTextFromClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadAllTextFromClipboardStart;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadAllTextFromClipboardEnd;
        private System.Windows.Forms.ToolStripMenuItem дляВыделенногоТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadSelectTextFromClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadSelectTextFromClipboardStart;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadSelectTextFromClipboardEnd;
        private System.Windows.Forms.ToolStripMenuItem дляВывестиСохранитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadChooseTextFromClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadChooseTextFromClipboardStart;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadChooseTextFromClipboardEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAllTextToQuaternaryCode;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectTextToQuaternaryCode;
        private System.Windows.Forms.ToolStripMenuItem buttonOutSelectTextToQuaternaryCode;
        private System.Windows.Forms.ToolStripMenuItem buttonOutSelectTextBeforeQuaternaryCode;
        private System.Windows.Forms.ToolStripMenuItem buttonOutSelectTextAfterQuaternaryCode;
        private System.Windows.Forms.ToolStripMenuItem buttonQuaternaryCodeToAllText;
        private System.Windows.Forms.ToolStripMenuItem buttonQuaternaryCodeToSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonQuaternaryCodeToOutSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonQuaternaryCodeToBeforeSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonQuaternaryCodeToAfterSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonAllTextToOctalCode;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectTextToOctalCode;
        private System.Windows.Forms.ToolStripMenuItem buttonOutSelectTextToOctalCode;
        private System.Windows.Forms.ToolStripMenuItem buttonBeforeSelectTextToOctalCode;
        private System.Windows.Forms.ToolStripMenuItem buttonAfterSelectTextToOctalCode;
        private System.Windows.Forms.ToolStripMenuItem buttonOctalCodeToAllText;
        private System.Windows.Forms.ToolStripMenuItem buttonOctalCodeToSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonOctalCodeToOutSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonOctalCodeToBeforeSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonOctalCodeToAfterSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonAllTextToHexadecimalCode;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectTextToHexadecimalCode;
        private System.Windows.Forms.ToolStripMenuItem buttonOutSelectTextToHexadecimalCode;
        private System.Windows.Forms.ToolStripMenuItem buttonBeforeSelectTextToHexadecimalCode;
        private System.Windows.Forms.ToolStripMenuItem buttonAfterSelectTextToHexadecimalCode;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToAllText;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToOutSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToBeforeSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToAfterSelectText;
        private System.Windows.Forms.ToolStripMenuItem buttonReplace;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxTextCode;
        private System.Windows.Forms.ToolStripMenuItem перекадировкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToBufferInTextCode;
        private System.Windows.Forms.ToolStripMenuItem buttonFromBufferInTextCode;
        private System.Windows.Forms.ToolStripMenuItem buttonClearBufferTextCode;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem buttonTextToHexadecimalCodeEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAllTextToHexadecimalCodeEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectTextToHexadecimalCodeEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonOutSelectTextToHexadecimalCodeEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonBeforeSelectTextToHexadecimalCodeEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonAfterSelectTextToHexadecimalCodeEnd;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem buttonTextToHexadecimalCodeStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAllTextToHexadecimalCodeStart;
        private System.Windows.Forms.ToolStripMenuItem buttonSelectTextToHexadecimalCodeStart;
        private System.Windows.Forms.ToolStripMenuItem buttonOutSelectTextToHexadecimalCodeStart;
        private System.Windows.Forms.ToolStripMenuItem buttonBeforeSelectTextToHexadecimalCodeStart;
        private System.Windows.Forms.ToolStripMenuItem buttonAfterSelectTextToHexadecimalCodeStart;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToAllTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToSelectTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToOutSelectTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToBeforeSelectTextEnd;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToAfterSelectTextEnd;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToAllTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToSelectTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToOutSelectTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToBeforeSelectTextStart;
        private System.Windows.Forms.ToolStripMenuItem buttonHexadecimalCodeToAfterSelectTextStart;
    }
}