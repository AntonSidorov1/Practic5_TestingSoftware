﻿using Microsoft.Toolkit.Uwp.Notifications;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
//using static System.Net.Mime.MediaTypeNames;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class TextEditorForm : Form
    {

        public event Func<string> SetFromMain;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;


        public TextEditorForm()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;
            saving = true;

        }

        public TextEditorForm(string text) : this()
        {
            Value = text;
        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public TextEditorForm(Save save):this()
        {
            Save = save;
        }

        public TextEditorForm(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            if (!AutoInput)
                return;


            try
            {
                saving = false;
                string value = GetFormMain();
                string value1 = Value;
                if(value1 != value && !value1.Equals(value)) 
                {
                    Value = value;
                }
            }
            catch { }
            saving = true;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();
            notifyIconThis.Text = Text;
            notifyIconThis.Icon = Icon;
            notifyIconThis.Visible = true;
            notifyIconThis.BalloonTipIcon = ToolTipIcon.Info;
            notifyIconThis.BalloonTipTitle = Text;
            notifyIconThis.Click += buttonSetBallonText_Click;
            notifyIconThis.BalloonTipClicked += buttonSetBallonText_Click;
            comboBoxTextCode.SelectedIndex = 0;

            EncodingInfo[] encodings = Encoding.GetEncodings();
            for(int i = 0;  i < encodings.Length; i++)
            {
                comboBoxTextCode.Items.Add(encodings[i].GetEncoding().EncodingName);
            }
            try
            {
                buffer = null;
            }
            catch { }
        }

        public Encoding GetTextCode()
        {
            Encoding encoding = Encoding.Default;
            int index = comboBoxTextCode.SelectedIndex;
            switch (index)
            {
                case 1: encoding = Encoding.Default; break;
                case 2: encoding = Encoding.Unicode; break;
                case 3: encoding = Encoding.ASCII; break;
                case 4: encoding = Encoding.UTF7; break;
                case 5: encoding = Encoding.UTF8; break;
                case 6: encoding = Encoding.UTF32; break;
                case 7: encoding = Encoding.BigEndianUnicode; break;
                default:
                    {
                        if (index > 0)
                        {
                            index -= 8;
                            encoding = Encoding.GetEncodings()[index].GetEncoding();
                        }
                    }
                    break;
            }

            return encoding;
        }

        public bool AllText
        {
            get => radioButtonAllText.Checked;
            set => radioButtonAllText.Checked = value;
        }

        public string ChooseText
        {
            get => AllText ? Value : SelectedValue;
            set
            {
                string valueText = value;
                if(AllText)
                {
                    Value = valueText;
                }
                else
                {
                    SelectedValue = valueText;
                }
            }
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                notifyIconThis.Visible = false;
                notifyIconThis.Dispose();
            }
            catch { }
        }

        public string Value
        {
            get => textBoxValue.Value.Replace(Environment.NewLine, "\n");
            set => textBoxValue.Value = value.Replace(Environment.NewLine, "\n").Replace("\n", Environment.NewLine);
        }

        public bool AutoSave
        {
            get => checkBoxAutoSave.Checked;
            set => checkBoxAutoSave.Checked = value;
        }

        public bool AutoInput
        {
            get => checkBoxAutoInput.Checked;
            set => checkBoxAutoInput.Checked = value;
        }

        public bool AutoOutput => AutoSave || AutoInput;

        bool saving;

        public bool Saving => saving && AutoOutput;

        private void textBoxValue_ValueLinesChanged(object sender, EventArgs e, Control control, string text, string textWithLineBreaks)
        {
            try
            {
                if(Saving)
                {
                    MetrOutput1?.Invoke(textWithLineBreaks, Save);
                }
            }
            catch { }
        }

        private void buttonWrite_Click(object sender, EventArgs e)
        {
            try
            {
                MetrOutput1?.Invoke(ChooseText, Save);
            }
            catch { }
        }

        private void buttonFromMainFrom_Click(object sender, EventArgs e)
        {
            try
            {
                saving = false;
                Value = GetFormMain();
            }
            catch { }
            saving = true;
        }

        public string GetFormMain()
        {
            try
            {
                return SetFromMain?.Invoke() ?? "";
            }
            catch
            {
                return "";
            }
        }

        private void buttonToBynary_Click(object sender, EventArgs e)
        {
            try
            {
                string value = Value;
                ChooseText = BynaryCodeText(value);
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonFromBynary_Click(object sender, EventArgs e)
        {

            try
            {
                string value = Value;
                ChooseText = TextByBynaryCode(value).Replace("\n", Environment.NewLine);
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonToClipBoard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(ChooseText);
            }
            catch
            {

            }
        }

        private void buttonFromClipBoard_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = Clipboard.GetText();
            }
            catch
            {

            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            try
            {
                Value = "";
            }
            catch { }
        }

        public static string[] filters => new string[]
        {
            "Text Files (*.txt)|*.txt",
            "Text Files (*.stxt)|*.stxt",
            "Text Files (*.txt; *.stxt)|*.txt;*.stxt",
            "C# Files (*.cs)|*.cs",
            "Java Files (*.java)|*.java",
            "C++ Files (*.cpp)|*.cpp",
            "C++ Files (*.c)|*.c",
            "Java Script Files (*.js)|*.js",
            "Файлы с программным кодом (*.cs, *.java, *.cpp, *.c, *.js)|*.cs; *.java; *.cpp; *.c; *.js",
            "XML Files (*.xml)|*.xml",
            "HTML Files (*.html)|*.html",
            "Файлы с кодом разметки (*.xml, *.html)|*.xml; *.html",
            "Json Files (*.json)|*.json",
            "Файлы с кодом (*.cs, *.java, *.cpp, *.c, *.js, *.xml, *.html, *.json)|*.cs; *.java; *.cpp; *.c; *.js; *.xml; *.html; *.json",
            "All Files|*.*"
        };

        private void buttonToTextFile_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = string.Join("|", filters);
                save.Title = "Сохрание текста в файл";
                if (save.ShowDialog() == DialogResult.Cancel)
                    return;
                if (comboBoxTextCode.SelectedIndex == 0)
                    File.WriteAllText(save.FileName, ChooseText);
                else
                    File.WriteAllText(save.FileName, ChooseText, GetTextCode());
                MessageBox.Show("Текст успешно сохранён в файл", "Сохрание текста в файл", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {


                MessageBox.Show($"Не удалось сохранить текст в файл: \n {ex.Message}", $"Сохрание текста в файл", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonFromTextFile_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog save = new OpenFileDialog();
                save.Filter = string.Join("|", filters);
                save.Title = "Загрузка текста из файла";
               
                if (save.ShowDialog() == DialogResult.Cancel)
                    return;
                if(comboBoxTextCode.SelectedIndex == 0)
                ChooseText = File.ReadAllText(save.FileName);
                else
                {
                    ChooseText = File.ReadAllText(save.FileName, GetTextCode());

                }
                MessageBox.Show("Текст успешно загружен из файла", "Загрузка текста из файла", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {


                MessageBox.Show($"Не удалось загрузить текст из файла: \n {ex.Message}", $"Загрузка текста из файла", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonFromSecondMetr_Click(object sender, EventArgs e)
        {
            try
            {
                SecondMetrForm form = new SecondMetrForm(Save.None);

                form.MetrOutput1 += Form_MetrOutput1;
                form.GetMilliseconds += Form_GetMilliseconds;
                form.GetTime += Form_GetTime;
                form.Show();
            }
            catch { }
        }


        private string Form_GetTime()
        {
            try
            {
                return ChooseText;
            }
            catch
            {
                return "";
            }
        }

        private double Form_GetMilliseconds()
        {
            try
            {
                return double.Parse(ChooseText.Replace('.', ','));
            }
            catch
            {
                return 0;
            }
        }

        private void Form_MetrOutput1(string time, Save save)
        {
            //change = false;
            ChooseText = time.Replace("\n", Environment.NewLine);
            //SetValueChange(textBoxValue, new EventArgs());
        }

        private void buttonFromSecondsList_Click(object sender, EventArgs e)
        {

            FormSecondsSaved saved = new FormSecondsSaved();
            saved.MetrOutput1 += Saved_MetrOutput1;
            saved.Show();
        }

        private void Saved_MetrOutput1(string time, Save save)
        {
            ChooseText = time;
        }

        private void buttonFromCalculator_Click(object sender, EventArgs e)
        {
            CalculatorString form = new CalculatorString(Save.None);
            form.MetrOutput1 += Form_MetrOutput1;
            form.SetNumberFromMain += Form_SetNumberFromMain;
            form.Show();
        }

        private string Form_SetNumberFromMain()
        {
            return ChooseText;
        }

        private void buttonFromCalculatorMemory_Click(object sender, EventArgs e)
        {
            try
            {
                CalculatorMemory memory = new CalculatorMemory();
                memory.MetrOutput1 += Memory_MetrOutput1;
                memory.Show();
            }
            catch
            {

            }
        }


        private void Memory_MetrOutput1(string time, Save save)
        {
            ChooseText = time;
        }

        private void ToTimeBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                Buffer.Text = ChooseText;
            }
            catch
            {

            }
        }

        private void buttonFromTimeBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                Value = Buffer.Text;
            }
            catch
            {

            }
        }

        private void buttonToSettingsBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                PropertiesHelper.Buffer = ChooseText;
            }
            catch
            {

            }
        }

        private void buttonFromSettingsBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                Value = PropertiesHelper.Buffer;
            }
            catch
            {

            }
        }

        private void buttonProgramInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Value = MainForm.ProgramInfo();
            }
            catch
            {

            }
        }

        public static string ProgramInfo() => MainForm.ProgramInfo();

        private void buttonDialogForm_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show(ChooseText);
            }
            catch { }
        }

        private void buttonAddThisText_Click(object sender, EventArgs e)
        {
            try
            {
                string value = Value;
                ChooseText = ChooseText + value;
            }
            catch
            {

            }
        }

        private void buttonAddClipboardEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ChooseText;
                ChooseText = value + Clipboard.GetText();
            }
            catch
            {

            }
        }

        private void buttonAddClipboardStart_Click(object sender, EventArgs e)
        {

            try
            {
                string value = ChooseText;
                ChooseText = Clipboard.GetText() + value;
            }
            catch
            {

            }
        }

        private void buttonAddFromMain_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ChooseText;
                ChooseText = value+GetFormMain();
            }
            catch
            {

            }
        }

        private void buttonAddFromMainStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ChooseText;
                ChooseText = GetFormMain() + value;
            }
            catch
            {

            }
        }

        private void buttonAddFromTimeBufferEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ChooseText;
                ChooseText = value + Buffer.Text;
            }
            catch
            {

            }
        }

        private void buttonAddFromTimeBufferStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ChooseText;
                ChooseText = Buffer.Text + value;
            }
            catch
            {

            }
        }

        private void buttonAddFromLongBufferEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + PropertiesHelper.Buffer;
            }
            catch
            {

            }
        }

        private void buttonAddFromLongBufferStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText =  PropertiesHelper.Buffer + ChooseText;
            }
            catch
            {

            }
        }

        private void buttonSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxValue.SelectAll();
            }
            catch { }
        }

        private void buttonDropSelected_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxValue.SelectionLength = 0;
            }
            catch { }
        }

        private void buttonSetSelectedText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = SelectedValue;
            }
            catch { }
        }

        public string SelectedValue
        {
            get => textBoxValue.SelectedText.Replace(Environment.NewLine, "\n");
            set => textBoxValue.SelectedText = value.Replace(Environment.NewLine, "\n").Replace("\n", Environment.NewLine);
        }

        private void buttonDropSelectedText_Click(object sender, EventArgs e)
        {
            try
            {
                SelectedValue = "";
            }
            catch { }
        }

        private void buttonAddSelectedTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + SelectedValue;
            }
            catch
            {

            }
        }

        private void buttonAddWithoutSelectedEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += ValueWithoutSelected;
                return;

                string value = Value;
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                value = value.Remove(start, length);
                ChooseText = value + ChooseText;
            }
            catch
            {

            }
            saving = true;
        }

        private void buttonAddSelectedTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = SelectedValue + ChooseText;
            }
            catch
            {

            }
        }

        private void buttonAddWithoutSelectedStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ValueWithoutSelected + ChooseText;
                return;
                string value = Value;
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                value = value.Remove(start, length);
                ChooseText = ChooseText + value;
            }
            catch
            {

            }
        }

        private void SetFromMainBySelected_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = GetFormMain();
            }
            catch (Exception ex) { }
        }

        private void buttonSetTextBySelected_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = Value;
            }
            catch (Exception ex) { }
        }

        private void buttonFromClipBoardBySelected_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = Clipboard.GetText();
            }
            catch (Exception ex) { }
        }

        private void buttonFromTimeBufferBySelected_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = Buffer.Text;
            }
            catch (Exception ex) { }
        }

        private void buttonFromLongBufferBySelected_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = PropertiesHelper.Buffer;
            }
            catch (Exception ex) { }
        }

        private void buttonFromWithoutBySelected_Click(object sender, EventArgs e)
        {
            try
            {
                
                ChooseText = ValueWithoutSelected;
            }
            catch (Exception ex) { }
        }

        public string ValueWithoutSelected
        {
            get
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                string value = ValueText
                    .Remove(start, length);
                return value.Replace(Environment.NewLine, "\n");
            }
        }

        private void buttonAddProgramInfoBySelected_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ProgramInfo();
            }
            catch (Exception ex) { }
        }

        private void buttonAddProgramInfoEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + ProgramInfo();
            }
            catch (Exception ex) { }
        }

        private void buttonAddProgramInfoStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ProgramInfo() + ChooseText;
            }
            catch (Exception ex) { }
        }

        private void buttonAddThisStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = Value;
                ChooseText = value + ChooseText;
            }
            catch
            {

            }
        }

        private void buttonSetSelectedTextBySelected_Click(object sender, EventArgs e)
        {

        }

        private void buttonSelectedTextClear_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = "";
            }
            catch (Exception ex) { }
        }

        private void buttonAddFromTextFileEnd_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog save = new OpenFileDialog();
                save.Filter = string.Join("|", filters);
                save.Title = "Загрузка текста из файла";
                if (save.ShowDialog() == DialogResult.Cancel)
                    return;
                if (comboBoxTextCode.SelectedIndex == 0)
                    ChooseText = ChooseText + File.ReadAllText(save.FileName);
                else
                {
                    ChooseText = ChooseText + File.ReadAllText(save.FileName, GetTextCode());
                }
                MessageBox.Show("Текст успешно загружен из файла", "Загрузка текста из файла", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {


                MessageBox.Show($"Не удалось загрузить текст из файла: \n {ex.Message}", $"Загрузка текста из файла", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonAddFromTextFileStart_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog save = new OpenFileDialog();
                save.Filter = string.Join("|", filters);
                save.Title = "Загрузка текста из файла";
                if (save.ShowDialog() == DialogResult.Cancel)
                    return;
                if (comboBoxTextCode.SelectedIndex == 0)
                    ChooseText = File.ReadAllText(save.FileName) + ChooseText;
                else
                {
                    ChooseText = File.ReadAllText(save.FileName, GetTextCode()) + ChooseText;
                }
                MessageBox.Show("Текст успешно загружен из файла", "Загрузка текста из файла", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {


                MessageBox.Show($"Не удалось загрузить текст из файла: \n {ex.Message}", $"Загрузка текста из файла", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonAddFromSecondEnd_Click(object sender, EventArgs e)
        {
            try
            {
                SecondMetrForm form = new SecondMetrForm(Save.None);

                form.MetrOutput1 += Form_MetrOutput11; ;
                form.GetMilliseconds += Form_GetMilliseconds;
                form.GetTime += Form_GetTime;
                form.Show();
            }
            catch { }
        }

        private void Form_MetrOutput11(string time, Save save)
        {
            //change = false;
            ChooseText = ChooseText + time;
            //SetValueChange(textBoxValue, new EventArgs());
        }

        private void buttonAddFromSecondStart_Click(object sender, EventArgs e)
        {
            try
            {
                SecondMetrForm form = new SecondMetrForm(Save.None);

                form.MetrOutput1 += Form_MetrOutput12; ;
                form.GetMilliseconds += Form_GetMilliseconds;
                form.GetTime += Form_GetTime;
                form.Show();
            }
            catch { }
        }

        private void Form_MetrOutput12(string time, Save save)
        {
            //change = false;
            ChooseText = time + ChooseText;
            //SetValueChange(textBoxValue, new EventArgs());
        }

        private void buttonAddCalculatorEnd_Click(object sender, EventArgs e)
        {
            CalculatorString form = new CalculatorString(Save.None);
            form.MetrOutput1 += Form_MetrOutput11;
            form.SetNumberFromMain += Form_SetNumberFromMain;
            form.Show();
        }

        private void buttonAddCalculatorStart_Click(object sender, EventArgs e)
        {
            CalculatorString form = new CalculatorString(Save.None);
            form.MetrOutput1 += Form_MetrOutput12;
            form.SetNumberFromMain += Form_SetNumberFromMain;
            form.Show();
        }

        private void buttonCalcMemoryEnd_Click(object sender, EventArgs e)
        {
            try
            {
                CalculatorMemory memory = new CalculatorMemory();
                memory.MetrOutput1 += Form_MetrOutput11;
                memory.Show();
            }
            catch
            {

            }
        }

        private void buttonCalcMemoryStart_Click(object sender, EventArgs e)
        {
            try
            {
                CalculatorMemory memory = new CalculatorMemory();
                memory.MetrOutput1 += Form_MetrOutput12;
                memory.Show();
            }
            catch
            {

            }
        }

        private void buttonAddSecondSavedEnd_Click(object sender, EventArgs e)
        {

            FormSecondsSaved saved = new FormSecondsSaved();
            saved.MetrOutput1 += Form_MetrOutput11;
            saved.Show();
        }

        private void buttonAddSecondSavedStart_Click(object sender, EventArgs e)
        {

            FormSecondsSaved saved = new FormSecondsSaved();
            saved.MetrOutput1 += Form_MetrOutput12;
            saved.Show();
        }

        public string GetFeacheresList()
        {
            string text = Properties.Settings.Default.FeatcherInfoFiles;
            string[] files = text.Split('|');
            List<string> parts = new List<string>();
            int length = files.Length;

            try
            {
                string name = MainForm.AppName();
                parts.Add(name);
            }
            catch { }
            
            for(int i = 0; i < length;i++)
            {
                try
                {
                    string list = File.ReadAllText(Application.StartupPath + @"\" + files[i].Trim());
                    parts.Add(list);
                }
                catch { }
            }


            return string.Join("\n", parts);
        }

        private void buttonSetFeathersList_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = GetFeacheresList();
            }
            catch
            { }
        }

        private void buttonAddFeathersListEnd_Click(object sender, EventArgs e)
        {

            try
            {
                ChooseText = ChooseText + GetFeacheresList();
            }
            catch
            { }
        }

        private void buttonAddFeathersListStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = GetFeacheresList() + ChooseText;
            }
            catch
            { }
        }

        private void buttonGetNotification_Click(object sender, EventArgs e)
        {
            try
            {
                new ToastContentBuilder()
                .AddArgument("action", "viewConversation")
                .AddArgument("conversationId", 9813)
                .AddCustomTimeStamp(DateTime.Now)
                .AddText("Текстовый редактор TableAIS")
                .AddText(ChooseText)
                .Show();
            }
            catch { }
        }

        private void buttonSetValueByTextOutput_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText;
            }
            catch { }
        }

        private void buttonAddOutputEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ChooseText;
                ChooseText = value + value;
            }
            catch { }
        }

        private void buttonShowToast_Click(object sender, EventArgs e)
        {
            try
            {
                Help.ShowPopup(textBoxValue, ChooseText, new Point(Left + textBoxValue.Left+100, Top + textBoxValue.Top + 100));
            }
            catch { }
        }

        private void buttonSetBallonText_Click(object sender, EventArgs e)
        {
            try
            {
                notifyIconThis.BalloonTipText = ChooseText;
                notifyIconThis.ShowBalloonTip(5000);
            }
            catch { }
        }

        private void checkBoxAutoInput_CheckedChanged(object sender, EventArgs e)
        {
            checkBoxAutoSave.Enabled = !(sender as CheckBox).Checked;
        }

        private void textBoxValue_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonSaveAllText_Click(object sender, EventArgs e)
        {
            try
            {
                MetrOutput1?.Invoke(Value, Save);
            }
            catch { }
        }

        private void buttonSelectedStartToSelected_Click(object sender, EventArgs e)
        {
            try
            {
                int length = textBoxValue.SelectionStart + textBoxValue.SelectionLength;
                textBoxValue.SelectionStart = 0;
                textBoxValue.SelectionLength = length;
            }
            catch { }
        }

        private void buttonSelectedStartOutSelected_Click(object sender, EventArgs e)
        {
            try
            {
                int length = textBoxValue.SelectionStart;
                textBoxValue.SelectionStart = 0;
                textBoxValue.SelectionLength = length;
            }
            catch { }
        }

        private void buttonSelectedEndToSelected_Click(object sender, EventArgs e)
        {
            try
            {
                int length = ValueText.Length - textBoxValue.SelectionStart;
                textBoxValue.SelectionLength = length;
            }
            catch { }
        }

        public string ValueText
        {
            get => textBoxValue.Text;
            set => textBoxValue.Text = value;
        }

        private void buttonSelectedEndOutSelected_Click(object sender, EventArgs e)
        {
            try
            {
                int selectStart = textBoxValue.SelectionStart;
                int selectLenth = textBoxValue.SelectionLength;
                selectStart += selectLenth;
                int length = ValueText.Length - selectStart;
                textBoxValue.SelectionStart = selectStart;
                textBoxValue.SelectionLength = length;
            }
            catch { }
        }

        private void buttonToBynaryEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = Value;
                ChooseText = ChooseText+ BynaryText(value);
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonToBynaryStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = Value;
                ChooseText = BynaryText(value) + ChooseText;
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonToBynarySelected_Click(object sender, EventArgs e)
        {
            try
            {
                string value = SelectedValue;
                ChooseText = BynaryText(value);
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonToBynaryEndSelected_Click(object sender, EventArgs e)
        {
            try
            {
                string value = SelectedValue;
                ChooseText = ChooseText + BynaryText(value);
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonToBynaryStartSelected_Click(object sender, EventArgs e)
        {
            try
            {
                string value = SelectedValue;
                ChooseText =BynaryText(value) + ChooseText;
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonFromBynarySelected_Click(object sender, EventArgs e)
        {
            try
            {
                string value = SelectedValue;
                ChooseText = TextByBynaryCode(value).Replace("\n", Environment.NewLine);
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonFromBynaryEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = Value;
                ChooseText = ChooseText + TextByBynaryCode(value).Replace("\n", Environment.NewLine);
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonFromBynaryEndSelected_Click(object sender, EventArgs e)
        {
            try
            {
                string value = SelectedValue;
                ChooseText = ChooseText + TextByBynaryCode(value).Replace("\n", Environment.NewLine);
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonFromBynaryStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = Value;
                ChooseText =  TextByBynaryCode(value).Replace("\n", Environment.NewLine) + ChooseText;
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonFromBynaryStartSelected_Click(object sender, EventArgs e)
        {
            try
            {
                string value = SelectedValue;
                ChooseText = TextByBynaryCode(value).Replace("\n", Environment.NewLine) + ChooseText;
            }
            catch
            (Exception ex)
            {

            }
        }

        public string BeforeSelectedValue
        {
            get
            {
                int start = textBoxValue.SelectionStart;
                string text = textBoxValue.Text.Substring(0, start);
                return text.Replace(Environment.NewLine, "\n");
            }
        }


        public string AfterSelectedValue
        {
            get
            {
                int start = textBoxValue.SelectionStart + textBoxValue.SelectionLength;
                //int length = textBoxValue.Text.Length - start;
                string text = textBoxValue.Text.Substring(start);
                return text.Replace(Environment.NewLine, "\n");
            }
        }

        private void buttonSetBeforeSelected_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = BeforeSelectedValue;
            }
            catch { }
        }

        private void bottonToBynaryOutSell_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ValueWithoutSelected;
                ChooseText = BynaryText(value);
            }
            catch { }
        }

        private void buttonToBynaryBefore_Click(object sender, EventArgs e)
        {
            try
            {
                string value = BeforeSelectedValue;
                ChooseText = BynaryText(value);
            }
            catch { }
        }

        private void buttonToBynaryAfter_Click(object sender, EventArgs e)
        {
            try
            {
                string value = AfterSelectedValue;
                ChooseText = BynaryText(value);
            }
            catch { }
        }

        private void buttonSetSellectedText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = SelectedValue;
            }
            catch { }
        }

        private void buttonSetWithoutSell_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ValueWithoutSelected;
            }
            catch { }
        }

        private void buttonSetBeforeSell_Click(object sender, EventArgs e)
        {
            buttonSetBeforeSelected_Click(sender, e);
        }

        private void buttonSetAfterSell_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = AfterSelectedValue;
            }
            catch { }
        }

        private void bottonToBynaryOutSellEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ValueWithoutSelected;
                ChooseText += BynaryText(value);
            }
            catch { }
        }

        private void buttonToBynaryBeforeEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = BeforeSelectedValue;
                ChooseText += BynaryText(value);
            }
            catch { }
        }

        private void buttonToBynaryAfterEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = AfterSelectedValue;
                ChooseText += BynaryText(value);
            }
            catch { }
        }

        private void bottonToBynaryOutSellStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ValueWithoutSelected;
                ChooseText = BynaryText(value) + ChooseText;
            }
            catch { }
        }

        private void buttonToBynaryBeforeStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = BeforeSelectedValue;
                ChooseText = BynaryText(value) + ChooseText;
            }
            catch { }
        }

        private void buttonToBynaryAfterStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = AfterSelectedValue;
                ChooseText = BynaryText(value) + ChooseText;
            }
            catch { }
        }

        private void bottonFromBynaryOutSell_Click(object sender, EventArgs e)
        {

            try
            {
                string value = ValueWithoutSelected;
                ChooseText = TextByBynaryCode(value);
            }
            catch { }
        }

        private void buttonFromBynaryBefore_Click(object sender, EventArgs e)
        {
            try
            {
                string value = BeforeSelectedValue;
                ChooseText = TextByBynaryCode(value);
            }
            catch { }
        }

        private void buttonFromBynaryAfter_Click(object sender, EventArgs e)
        {
            try
            {
                string value = AfterSelectedValue;
                ChooseText = TextByBynaryCode(value);
            }
            catch { }
        }

        private void bottonFromBynaryOutSellEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ValueWithoutSelected;
                ChooseText = ChooseText + TextByBynaryCode(value);
            }
            catch { }
        }

        private void bottonFromBynaryBeforeSellEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = BeforeSelectedValue;
                ChooseText = ChooseText + TextByBynaryCode(value);
            }
            catch { }
        }

        private void bottonFromBynaryAfterSellEnd_Click(object sender, EventArgs e)
        {
            try
            {
                string value = AfterSelectedValue;
                ChooseText = ChooseText + TextByBynaryCode(value);
            }
            catch { }
        }

        private void bottonFromBynaryOutSellStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ValueWithoutSelected;
                ChooseText = TextByBynaryCode(value) + ChooseText;
            }
            catch { }
        }

        private void bottonFromBynaryBeforeSellStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = BeforeSelectedValue;
                ChooseText = TextByBynaryCode(value) + ChooseText;
            }
            catch { }
        }

        private void bottonFromBynaryAfterSellStart_Click(object sender, EventArgs e)
        {
            try
            {
                string value = AfterSelectedValue;
                ChooseText = TextByBynaryCode(value) + ChooseText;
            }
            catch { }
        }

        private void buttonAddBeforeEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += BeforeSelectedValue;
            }
            catch { }
        }

        private void buttonAddAfterEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += AfterSelectedValue;
            }
            catch { }
        }

        private void buttonAddBeforeStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = BeforeSelectedValue + ChooseText;
            }
            catch { }
        }

        private void buttonAddAfterStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = AfterSelectedValue + ChooseText;
            }
            catch { }
        }

        private void buttonRunSelectLeft_Click(object sender, EventArgs e)
        {
            try
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                if(start <= 0)
                {
                    textBoxValue.SelectionLength = length - 1;
                    return;
                }

                textBoxValue.SelectionStart = start - 1;
                textBoxValue.SelectionLength = length;

            }
            catch { }
        }

        private void buttonAddSelectSymwolLeft_Click(object sender, EventArgs e)
        {
            try
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                if (start <= 0)
                {
                    return;
                }

                textBoxValue.SelectionStart = start - 1;
                textBoxValue.SelectionLength = length + 1;

            }
            catch { }
        }

        private void buttonDropSelectSymwolLeft_Click(object sender, EventArgs e)
        {
            try
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                if (length <= 0)
                    return;

                textBoxValue.SelectionLength = length - 1;

            }
            catch { }
        }

        private void buttonRunSelectRight_Click(object sender, EventArgs e)
        {
            try
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                int length1 = textBoxValue.Text.Length;
                int count = length1;
                start++;
                length1 -= start;
                textBoxValue.SelectionStart = Math.Min(start, count);
                textBoxValue.SelectionLength = Math.Min(length, length1);

            }
            catch { }
        }

        private void buttonAddSelectSymwolRight_Click(object sender, EventArgs e)
        {

            try
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                int length1 = textBoxValue.Text.Length;
                int count = length1;
                length++;
                length1 -= start;
                textBoxValue.SelectionStart = Math.Min(start, count);
                textBoxValue.SelectionLength = Math.Min(length, length1);

            }
            catch { }
        }

        private void buttonDropSelectSymwolRight_Click(object sender, EventArgs e)
        {
            try
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                if (length <= 0)
                    return;
                int length1 = textBoxValue.Text.Length;
                int count = length1;
                start++;
                length--;
                length1 -= start;
                textBoxValue.SelectionStart = Math.Min(start, count);
                textBoxValue.SelectionLength = Math.Min(length, length1);

            }
            catch { }
        }

        private void publicRunSellectedCountLeft_Click(object sender, EventArgs e)
        {
            try
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                int length1 = textBoxValue.Text.Length;
                int count = length1;
                if (length <= 0)
                    return;
                start -= length;
                while(start < 0)
                {
                    start++;
                    length--;
                }
                length = Math.Max(0, length);
                length1 -= start;
                length = Math.Min(length, length1);
                textBoxValue.SelectionStart = start;
                textBoxValue.SelectionLength = length;

            }
            catch { }
        }

        private void publicRunSellectedCountRight_Click(object sender, EventArgs e)
        {
            try
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                int length1 = textBoxValue.Text.Length;
                int count = length1;
                if (length <= 0)
                    return;
                start += length;
                while (start > count)
                {
                    start--;
                    length++;
                }
                length = Math.Max(0, length);
                length1 -= start;
                length = Math.Min(length, length1);
                textBoxValue.SelectionStart = start;
                textBoxValue.SelectionLength = length;

            }
            catch { }
        }

        private void publicAddSellectedCountLeft_Click(object sender, EventArgs e)
        {
            try
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                int length2 = length;
                int length1 = textBoxValue.Text.Length;
                int count = length1;
                if (length <= 0)
                    return;
                start -= length;
                while (start < 0)
                {
                    start++;
                    length--;
                }
                length = Math.Max(0, length);
                length1 -= start;
                length += length2;
                length = Math.Min(length, length1);
                textBoxValue.SelectionStart = start;
                textBoxValue.SelectionLength = length;
            }
            catch { }

        }

        private void publicAddSellectedCountRight_Click(object sender, EventArgs e)
        {
            try
            {
                int start = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                int length2 = length;
                int length1 = textBoxValue.Text.Length;
                int count = length1;
                if (length <= 0)
                    return;
                //start -= length;
                while (start < 0)
                {
                    start++;
                    length--;
                }
                length = Math.Max(0, length);
                length1 -= start;
                length += length2;
                length = Math.Min(length, length1);
                textBoxValue.SelectionStart = start;
                textBoxValue.SelectionLength = length;
            }
            catch { }
        }

        private void buttonToUpper_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText.ToUpper();
            }
            catch { }
        }

        private void buttonToLower_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText.ToLower();
            }
            catch { }
        }

        private void вместоТекстаToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void buttonToBynaryCodeChoose_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = BynaryText(ChooseText);
            }
            catch { }
        }

        private void buttonAddBynaryCodeChoose_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText+ BynaryText(ChooseText);
            }
            catch { }
        }

        private void buttonAddBynaryCodeChooseStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = BynaryText(ChooseText) + ChooseText;
            }
            catch { }
        }

        private void buttonFromBynaryCodeCooseStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = TextByBynaryCode(ChooseText) + ChooseText;
            }
            catch { }
        }

        private void buttonFromBynaryCodeCooseEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + TextByBynaryCode(ChooseText);
            }
            catch { }
        }

        private void buttonFromBynaryCodeCoose_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = TextByBynaryCode(ChooseText);
            }
            catch { }
        }

        private void buttonToLowerAllText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = Value.ToLower();
            }
            catch { }
        }

        private void buttonToLowerSellectedText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = SelectedValue.ToLower();
            }
            catch { }
        }

        private void buttonToLowerOutSellectedText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ValueWithoutSelected.ToLower();
            }
            catch { }
        }

        private void buttonToLowerEndSellectedText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = AfterSelectedValue.ToLower();
            }
            catch { }
        }

        private void buttonToLowerStartSellectedText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = BeforeSelectedValue.ToLower();
            }
            catch { }
        }

        private void buttonToLowerChooseText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText.ToLower();
            }
            catch { }
        }

        private void buttonToLowerAllTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText+ Value.ToLower();
            }
            catch { }
        }

        private void buttonToLowerSellectedTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + SelectedValue.ToLower();
            }
            catch { }
        }

        private void buttonToLowerOutSellectedTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + ValueWithoutSelected.ToLower();
            }
            catch { }
        }

        private void buttonToLowerStartSellectedTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + BeforeSelectedValue.ToLower();
            }
            catch { }
        }

        private void buttonToLowerEndSellectedTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + AfterSelectedValue.ToLower();
            }
            catch { }
        }

        private void buttonToLowerChooseTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + ChooseText.ToLower();
            }
            catch { }
        }

        private void buttonToLowerAllTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = Value.ToLower() + ChooseText;
            }
            catch { }
        }

        private void buttonToLowerSellectedTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = SelectedValue.ToLower() + ChooseText;
            }
            catch { }
        }

        private void buttonToLowerOutSellectedTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ValueWithoutSelected.ToLower() + ChooseText;
            }
            catch { }
        }

        private void buttonToLowerStartSellectedTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = BeforeSelectedValue.ToLower() + ChooseText;
            }
            catch { }
        }

        private void buttonToLowerEndSellectedTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = AfterSelectedValue.ToLower() + ChooseText;
            }
            catch { }
        }

        private void buttonToLowerChooseTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText.ToLower() + ChooseText;
            }
            catch { }
        }

        private void buttonToUpperAllText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = Value.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperSellectedText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = SelectedValue.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperOutSellectedText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ValueWithoutSelected.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperEndSellectedText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = AfterSelectedValue.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperStartSellectedText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = BeforeSelectedValue.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperChooseText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperAllTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + Value.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperSellectedTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + SelectedValue.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperOutSellectedTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + ValueWithoutSelected.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperEndSellectedTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + AfterSelectedValue.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperStartSellectedTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + BeforeSelectedValue.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperChooseTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + ChooseText.ToUpper();
            }
            catch { }
        }

        private void buttonToUpperAllTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = Value.ToUpper() + ChooseText;
            }
            catch { }
        }

        private void buttonToUpperSellectedTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = SelectedValue.ToUpper() + ChooseText;
            }
            catch { }
        }

        private void buttonToUpperOutSellectedTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ValueWithoutSelected.ToUpper() + ChooseText;
            }
            catch { }
        }

        private void buttonToUpperEndSellectedTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = AfterSelectedValue.ToUpper() + ChooseText;
            }
            catch { }
        }

        private void buttonToUpperStartSellectedTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = BeforeSelectedValue.ToUpper() + ChooseText;
            }
            catch { }
        }

        private void buttonToUpperChooseTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText.ToUpper() + ChooseText;
            }
            catch { }
        }

        private void butonSetReservNames_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = MainForm.GetReservNames1();
            }
            catch { }
        }

        private void butonSetReservNamesEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText+ MainForm.GetReservNames1();
            }
            catch { }
        }

        private void butonSetReservNamesStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = MainForm.GetReservNames1() + ChooseText;
            }
            catch { }
        }

        private void buttonSetJsonStruct_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = MainForm.GetJsonInfo();
            }
            catch { }
        }

        private void buttonSetJsonStructEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText + MainForm.GetJsonInfo();
            }
            catch { }
        }

        private void buttonSetJsonStructStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = MainForm.GetJsonInfo() + ChooseText;
            }
            catch { }
        }

        private void buttonTextToQuaternaryCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToQuaternaryCode(ChooseText);
            }
            catch { }
        }

        private void buttonQuaternaryCodeToText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.QuaternaryCodeToText(ChooseText);
            }
            catch { }
        }

        private void buttonTextToOctalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToOctalCode(ChooseText);
            }
            catch { }
        }

        private void buttonOctalCodeToText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.OctalCodeToText(ChooseText);
            }
            catch { }
        }

        private void buttonTextToHexadecimalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(ChooseText);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(ChooseText);
            }
            catch { }
        }

        private void buttonAllTextToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(Value);
            }
            catch { }
        }

        private void buttonSelectedTextToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(SelectedValue);
            }
            catch { }
        }

        private void buttonOutSelectedTextToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(ValueWithoutSelected);
            }
            catch { }
        }

        private void buttonAfterSelectToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(AfterSelectedValue);
            }
            catch { }
        }

        private void buttonBeforeSelectToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(BeforeSelectedValue);
            }
            catch { }
        }

        private void buttonChooseToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(ChooseText);
            }
            catch { }
        }

        private void buttonLoadAllTextFromClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Value = Clipboard.GetText();
            }
            catch { }
        }

        private void buttonLoadAllTextFromClipboardStart_Click(object sender, EventArgs e)
        {
            try
            {
                Value = Value + Clipboard.GetText();
            }
            catch { }
        }


        private void buttonLoadAllTextFromClipboardEnd_Click(object sender, EventArgs e)
        {
            try
            {
                Value = Clipboard.GetText() + Value;
            }
            catch { }
        }

        private void buttonLoadSelectTextFromClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                SelectedValue = Clipboard.GetText();
            }
            catch { }
        }

        private void buttonLoadSelectTextFromClipboardStart_Click(object sender, EventArgs e)
        {
            try
            {
                SelectedValue = SelectedValue + Clipboard.GetText();
            }
            catch { }
        }

        private void buttonLoadSelectTextFromClipboardEnd_Click(object sender, EventArgs e)
        {
            try
            {
                SelectedValue = Clipboard.GetText() + SelectedValue;
            }
            catch { }
        }

        private void buttonLoadChooseTextFromClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = Clipboard.GetText();
            }
            catch { }
        }

        private void buttonLoadChooseTextFromClipboardStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = ChooseText+ Clipboard.GetText();
            }
            catch { }
        }

        private void buttonLoadChooseTextFromClipboardEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = Clipboard.GetText() + ChooseText;
            }
            catch { }
        }

        private void buttonAllTextToQuaternaryCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToQuaternaryCode(Value);
            }
            catch { }
        }

        private void buttonSelectTextToQuaternaryCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToQuaternaryCode(SelectedValue);
            }
            catch { }
        }

        private void buttonOutSelectTextToQuaternaryCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToQuaternaryCode(ValueWithoutSelected);
            }
            catch { }
        }

        private void buttonOutSelectTextBeforeQuaternaryCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToQuaternaryCode(BeforeSelectedValue);
            }
            catch { }
        }

        private void buttonOutSelectTextAfterQuaternaryCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToQuaternaryCode(AfterSelectedValue);
            }
            catch { }
        }

        private void buttonQuaternaryCodeToAllText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.QuaternaryCodeToText(Value);
            }
            catch { }
        }

        private void buttonQuaternaryCodeToSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.QuaternaryCodeToText(SelectedValue);
            }
            catch { }
        }

        private void buttonQuaternaryCodeToOutSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.QuaternaryCodeToText(ValueWithoutSelected);
            }
            catch { }
        }

        private void buttonQuaternaryCodeToBeforeSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.QuaternaryCodeToText(BeforeSelectedValue);
            }
            catch { }
        }

        private void buttonQuaternaryCodeToAfterSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.QuaternaryCodeToText(AfterSelectedValue);
            }
            catch { }
        }

        private void buttonAllTextToOctalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToOctalCode(Value);
            }
            catch { }
        }

        private void buttonSelectTextToOctalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToOctalCode(SelectedValue);
            }
            catch { }
        }

        private void buttonOutSelectTextToOctalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToOctalCode(ValueWithoutSelected);
            }
            catch { }
        }

        private void buttonBeforeSelectTextToOctalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToOctalCode(BeforeSelectedValue);
            }
            catch { }
        }

        private void buttonAfterSelectTextToOctalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToOctalCode(AfterSelectedValue);
            }
            catch { }
        }

        private void buttonOctalCodeToAllText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.OctalCodeToText(Value);
            }
            catch { }
        }

        private void buttonOctalCodeToSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.OctalCodeToText(SelectedValue);
            }
            catch { }
        }

        private void buttonOctalCodeToOutSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.OctalCodeToText(ValueWithoutSelected);
            }
            catch { }
        }

        private void buttonOctalCodeToBeforeSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.OctalCodeToText(BeforeSelectedValue);
            }
            catch { }
        }

        private void buttonOctalCodeToAfterSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.OctalCodeToText(AfterSelectedValue);
            }
            catch { }
        }

        private void buttonAllTextToHexadecimalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(Value);
            }
            catch { }
        }

        private void buttonSelectTextToHexadecimalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(SelectedValue);
            }
            catch { }
        }

        private void buttonOutSelectTextToHexadecimalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(ValueWithoutSelected);
            }
            catch { }
        }

        private void buttonBeforeSelectTextToHexadecimalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(BeforeSelectedValue);
            }
            catch { }
        }

        private void buttonAfterSelectTextToHexadecimalCode_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(AfterSelectedValue);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToAllText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(Value);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(SelectedValue);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToOutSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(ValueWithoutSelected);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToBeforeSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(BeforeSelectedValue);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToAfterSelectText_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(AfterSelectedValue);
            }
            catch { }
        }

        private void buttonReplace_Click(object sender, EventArgs e)
        {
            try
            {
                ReplaceForm form = new ReplaceForm();

                form.MetrOutput1 += Form_MetrOutput13;
                form.SetNumberFromMain += Form_SetNumberFromMain1;

                form.Show();
            }
            catch { }
        }

        private string Form_SetNumberFromMain1()
        {
            return ChooseText;
        }

        private void Form_MetrOutput13(string time, Save save)
        {
            try
            {
                ChooseText = time;
            }
            catch { }
        }


        byte[] buffer;
        private void buttonToBufferInTextCode_Click(object sender, EventArgs e)
        {
            try
            {
                int index = comboBoxTextCode.SelectedIndex;
                if(index == 0)
                {
                    buffer = Encoding.UTF8.GetBytes(ChooseText);
                }
                else
                {
                    buffer = GetTextCode().GetBytes(ChooseText);
                }
            }
            catch { }
        }

        string BynaryText(string text)
        {
            return BynaryCodeText(text);
        }

        string BynaryCodeText(string text)
        {
            int index = comboBoxTextCode.SelectedIndex;
            if(index == 0)
            {
                return BynaryCode.BynaryText(text);
            }
            return BynaryCode.BynaryText(text, GetTextCode());
        }

        string TextByBynaryCode(string bynaryCode)
        {
            int index = comboBoxTextCode.SelectedIndex;
            if (index == 0)
            {
                return BynaryCode.TextByBynaryCode(bynaryCode);
            }
            return BynaryCode.TextByBynaryCode(bynaryCode, GetTextCode());
        }

        private void buttonFromBufferInTextCode_Click(object sender, EventArgs e)
        {
            try
            {
                int index = comboBoxTextCode.SelectedIndex;
                if (index == 0)
                {
                    ChooseText = Encoding.UTF8.GetString(buffer);
                }
                else
                {
                    ChooseText = GetTextCode().GetString(buffer);
                }
            }
            catch { }
        }

        private void buttonClearBufferTextCode_Click(object sender, EventArgs e)
        {
            try
            {
                buffer = null;
            }
            catch { }
        }

        private void buttonTextToHexadecimalCodeEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.TextToHexadecimalCode(ChooseText);
            }
            catch { }
        }

        private void buttonAllTextToHexadecimalCodeEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.TextToHexadecimalCode(Value);
            }
            catch { }
        }

        private void buttonSelectTextToHexadecimalCodeEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.TextToHexadecimalCode(SelectedValue);
            }
            catch { }
        }

        private void buttonOutSelectTextToHexadecimalCodeEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.TextToHexadecimalCode(ValueWithoutSelected);
            }
            catch { }
        }

        private void buttonBeforeSelectTextToHexadecimalCodeEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.TextToHexadecimalCode(BeforeSelectedValue);
            }
            catch { }
        }

        private void buttonAfterSelectTextToHexadecimalCodeEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.TextToHexadecimalCode(AfterSelectedValue);
            }
            catch { }
        }

        private void buttonTextToHexadecimalCodeStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(ChooseText) + ChooseText;
            }
            catch { }
        }

        private void buttonAllTextToHexadecimalCodeStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(Value) + ChooseText;
            }
            catch { }
        }

        private void buttonSelectTextToHexadecimalCodeStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(SelectedValue) + ChooseText;
            }
            catch { }
        }

        private void buttonOutSelectTextToHexadecimalCodeStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(ValueWithoutSelected) + ChooseText;
            }
            catch { }
        }

        private void buttonBeforeSelectTextToHexadecimalCodeStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(BeforeSelectedValue) + ChooseText;
            }
            catch { }
        }

        private void buttonAfterSelectTextToHexadecimalCodeStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.TextToHexadecimalCode(AfterSelectedValue) + ChooseText;
            }
            catch { }
        }

        private void buttonHexadecimalCodeToTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.HexadecimalCodeToText(ChooseText);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToAllTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.HexadecimalCodeToText(Value);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToSelectTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.HexadecimalCodeToText(SelectedValue);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToOutSelectTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.HexadecimalCodeToText(ValueWithoutSelected);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToBeforeSelectTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.HexadecimalCodeToText(BeforeSelectedValue);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToAfterSelectTextEnd_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText += CodesConvert.HexadecimalCodeToText(AfterSelectedValue);
            }
            catch { }
        }

        private void buttonHexadecimalCodeToTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(ChooseText) + ChooseText;
            }
            catch { }
        }

        private void buttonHexadecimalCodeToAllTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(Value) + ChooseText;
            }
            catch { }
        }

        private void buttonHexadecimalCodeToSelectTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(SelectedValue) + ChooseText;
            }
            catch { }
        }

        private void buttonHexadecimalCodeToOutSelectTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(ValueWithoutSelected) + ChooseText;
            }
            catch { }
        }

        private void buttonHexadecimalCodeToBeforeSelectTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(BeforeSelectedValue) + ChooseText;
            }
            catch { }
        }

        private void buttonHexadecimalCodeToAfterSelectTextStart_Click(object sender, EventArgs e)
        {
            try
            {
                ChooseText = CodesConvert.HexadecimalCodeToText(AfterSelectedValue) + ChooseText;
            }
            catch { }
        }
    }
}
