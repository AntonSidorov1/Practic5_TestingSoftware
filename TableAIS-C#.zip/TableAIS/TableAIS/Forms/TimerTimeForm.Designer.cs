﻿namespace TableAIS
{
    partial class TimerTimeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TimerTimeForm));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.numbericHour = new TableAIS.NumbericUser();
            this.numbericMinute = new TableAIS.NumbericUser();
            this.numbericSecond = new TableAIS.NumbericUser();
            this.numbericMilliSecond = new TableAIS.NumbericUser();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.maskedTextBoxSecondMetr = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxTimer = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTimerValueBySecondMetr = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonUploadTimer = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.buttonTimerSet = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(439, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(164, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 327);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(632, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(632, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(628, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(322, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Шаблон";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 304);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(632, 23);
            this.panel2.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.Controls.Add(this.numbericMilliSecond, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.numbericSecond, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.numbericMinute, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.numbericHour, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 2, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(632, 215);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // numbericHour
            // 
            this.numbericHour.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericHour.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericHour.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericHour.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericHour.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericHour.Location = new System.Drawing.Point(4, 4);
            this.numbericHour.Macimum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.numbericHour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.numbericHour.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.numbericHour.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericHour.Name = "numbericHour";
            this.numbericHour.NoReadOnly = true;
            this.numbericHour.ReadOnly = false;
            this.numbericHour.Size = new System.Drawing.Size(150, 99);
            this.numbericHour.TabIndex = 0;
            this.numbericHour.Title = "Часы";
            this.numbericHour.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericHour.VisibleOK = false;
            // 
            // numbericMinute
            // 
            this.numbericMinute.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericMinute.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericMinute.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericMinute.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericMinute.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericMinute.Location = new System.Drawing.Point(163, 5);
            this.numbericMinute.Macimum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numbericMinute.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.numbericMinute.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numbericMinute.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericMinute.Name = "numbericMinute";
            this.numbericMinute.NoReadOnly = true;
            this.numbericMinute.ReadOnly = false;
            this.numbericMinute.Size = new System.Drawing.Size(148, 97);
            this.numbericMinute.TabIndex = 1;
            this.numbericMinute.Title = "Минуты";
            this.numbericMinute.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericMinute.VisibleOK = false;
            // 
            // numbericSecond
            // 
            this.numbericSecond.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericSecond.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericSecond.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericSecond.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericSecond.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericSecond.Location = new System.Drawing.Point(321, 5);
            this.numbericSecond.Macimum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numbericSecond.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.numbericSecond.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numbericSecond.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericSecond.Name = "numbericSecond";
            this.numbericSecond.NoReadOnly = true;
            this.numbericSecond.ReadOnly = false;
            this.numbericSecond.Size = new System.Drawing.Size(148, 97);
            this.numbericSecond.TabIndex = 2;
            this.numbericSecond.Title = "Секунды";
            this.numbericSecond.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericSecond.VisibleOK = false;
            // 
            // numbericMilliSecond
            // 
            this.numbericMilliSecond.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericMilliSecond.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericMilliSecond.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numbericMilliSecond.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericMilliSecond.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericMilliSecond.Location = new System.Drawing.Point(479, 5);
            this.numbericMilliSecond.Macimum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numbericMilliSecond.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.numbericMilliSecond.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numbericMilliSecond.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericMilliSecond.Name = "numbericMilliSecond";
            this.numbericMilliSecond.NoReadOnly = true;
            this.numbericMilliSecond.ReadOnly = false;
            this.numbericMilliSecond.Size = new System.Drawing.Size(148, 97);
            this.numbericMilliSecond.TabIndex = 3;
            this.numbericMilliSecond.Title = "Миллисекунды";
            this.numbericMilliSecond.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericMilliSecond.VisibleOK = false;
            // 
            // groupBox1
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.groupBox1, 2);
            this.groupBox1.Controls.Add(this.tableLayoutPanel3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 110);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(310, 102);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Значения";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.maskedTextBoxTimer, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.maskedTextBoxSecondMetr, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(304, 69);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Секундомер";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "Таймер";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // maskedTextBoxSecondMetr
            // 
            this.maskedTextBoxSecondMetr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.maskedTextBoxSecondMetr.Location = new System.Drawing.Point(155, 3);
            this.maskedTextBoxSecondMetr.Mask = "00:00:00.000";
            this.maskedTextBoxSecondMetr.Name = "maskedTextBoxSecondMetr";
            this.maskedTextBoxSecondMetr.Size = new System.Drawing.Size(146, 34);
            this.maskedTextBoxSecondMetr.TabIndex = 2;
            this.maskedTextBoxSecondMetr.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBoxTimer
            // 
            this.maskedTextBoxTimer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.maskedTextBoxTimer.Location = new System.Drawing.Point(155, 37);
            this.maskedTextBoxTimer.Mask = "00:00:00.000";
            this.maskedTextBoxTimer.Name = "maskedTextBoxTimer";
            this.maskedTextBoxTimer.Size = new System.Drawing.Size(146, 34);
            this.maskedTextBoxTimer.TabIndex = 3;
            this.maskedTextBoxTimer.ValidatingType = typeof(System.DateTime);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel2.SetColumnSpan(this.tableLayoutPanel4, 2);
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Controls.Add(this.menuStrip2, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(319, 110);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(310, 102);
            this.tableLayoutPanel4.TabIndex = 5;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.buttonUploadTimer});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(310, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonTimerValueBySecondMetr});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(162, 25);
            this.toolStripMenuItem1.Text = "Задать значения";
            // 
            // buttonTimerValueBySecondMetr
            // 
            this.buttonTimerValueBySecondMetr.Name = "buttonTimerValueBySecondMetr";
            this.buttonTimerValueBySecondMetr.Size = new System.Drawing.Size(224, 26);
            this.buttonTimerValueBySecondMetr.Text = "С секундомера";
            this.buttonTimerValueBySecondMetr.Click += new System.EventHandler(this.buttonTimerValueBySecondMetr_Click);
            // 
            // buttonUploadTimer
            // 
            this.buttonUploadTimer.Name = "buttonUploadTimer";
            this.buttonUploadTimer.Size = new System.Drawing.Size(139, 25);
            this.buttonUploadTimer.Text = "Восстановить";
            this.buttonUploadTimer.Click += new System.EventHandler(this.buttonUploadTimer_Click);
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonTimerSet});
            this.menuStrip2.Location = new System.Drawing.Point(0, 51);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(310, 29);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // buttonTimerSet
            // 
            this.buttonTimerSet.Name = "buttonTimerSet";
            this.buttonTimerSet.Size = new System.Drawing.Size(236, 25);
            this.buttonTimerSet.Text = "Задать время на таймере";
            this.buttonTimerSet.Click += new System.EventHandler(this.buttonTimerSet_Click);
            // 
            // TimerTimeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(632, 353);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(650, 400);
            this.Name = "TimerTimeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Шаблон";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private NumbericUser numbericHour;
        private NumbericUser numbericMilliSecond;
        private NumbericUser numbericSecond;
        private NumbericUser numbericMinute;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxSecondMetr;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxTimer;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonTimerValueBySecondMetr;
        private System.Windows.Forms.ToolStripMenuItem buttonUploadTimer;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem buttonTimerSet;
    }
}