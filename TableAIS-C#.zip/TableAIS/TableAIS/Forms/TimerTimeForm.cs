﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class TimerTimeForm : Form
    {


        public event Func<string> SetFromMain;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public event Func<string> SetNumberFromMain;

        public string SetNumberFromMainInvoke()
        {
            return SetNumberFromMain?.Invoke()??"";
        }

        SecondDelta timerWork;


        public TimerTimeForm(SecondDelta timerWork)
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;
            TimerWork = timerWork;


        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }
        public SecondDelta TimerWork { get => timerWork; set => timerWork = value; }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            try
            {
                TimeSpan secondMetr = TimerWork.TimeSpan;
                string hour = secondMetr.Hours.ToString("00");
                string minute = secondMetr.Minutes.ToString("00");
                string second = secondMetr.Seconds.ToString("00");
                string millisecond = secondMetr.Milliseconds.ToString("000");
                maskedTextBoxSecondMetr.Text = hour+minute + second + millisecond;
            }
            catch
            {

            }

            try
            {
                TimeSpan timer = TimerWork.TimerTime;
                string hour = timer.Hours.ToString("00");
                string minute = timer.Minutes.ToString("00");
                string second = timer.Seconds.ToString("00");
                string millisecond = timer.Milliseconds.ToString("000");
                maskedTextBoxTimer.Text = hour + minute + second + millisecond;
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();


            TimeSpan timer = TimerWork.TimerTime;

            numbericHour.Value = timer.Hours;
            numbericMinute.Value = timer.Minutes;
            numbericSecond.Value = timer.Seconds;
            numbericMilliSecond.Value = timer.Milliseconds;

        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void buttonTimerValueBySecondMetr_Click(object sender, EventArgs e)
        {

            TimeSpan timer = TimerWork.TimeSpan;

            numbericHour.Value = timer.Hours;
            numbericMinute.Value = timer.Minutes;
            numbericSecond.Value = timer.Seconds;
            numbericMilliSecond.Value = timer.Milliseconds;
        }

        private void buttonUploadTimer_Click(object sender, EventArgs e)
        {
            TimeSpan timer = TimerWork.TimerTime;

            numbericHour.Value = timer.Hours;
            numbericMinute.Value = timer.Minutes;
            numbericSecond.Value = timer.Seconds;
            numbericMilliSecond.Value = timer.Milliseconds;
        }

        private void buttonTimerSet_Click(object sender, EventArgs e)
        {
            int hour = (int)numbericHour.Value;
            int minute = (int)numbericMinute.Value;
            int second = (int)numbericSecond.Value;
            int millisecond = (int)numbericMilliSecond.Value;
            TimeSpan timer = new TimeSpan(0, hour, minute, second, millisecond);
            TimerWork.TimerTime = timer;
        }
    }
}
