﻿namespace TableAIS
{
    partial class VectorCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VectorCalculator));
            this.buttonBack = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.flowResize1 = new TableAIS.FlowResize();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxLenAB = new TableAIS.TextBoxWithTitle();
            this.buttonLenAB = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.textBoxViewAB1 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxViewAB = new TableAIS.TextBoxWithTitle();
            this.buttonViewAB = new System.Windows.Forms.Button();
            this.buttonCalsABZ = new System.Windows.Forms.Button();
            this.buttonCalsABY = new System.Windows.Forms.Button();
            this.buttonCalsABX = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxLenB = new TableAIS.TextBoxWithTitle();
            this.buttonLenB = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxViewB = new TableAIS.TextBoxWithTitle();
            this.buttonViewB = new System.Windows.Forms.Button();
            this.buttonCalsBZ = new System.Windows.Forms.Button();
            this.buttonCalsBY = new System.Windows.Forms.Button();
            this.buttonCalsBX = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxABZ = new TableAIS.TextBoxWithTitle();
            this.textBoxABY = new TableAIS.TextBoxWithTitle();
            this.textBoxABX = new TableAIS.TextBoxWithTitle();
            this.buttonClearAB = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxBZ = new TableAIS.TextBoxWithTitle();
            this.textBoxBY = new TableAIS.TextBoxWithTitle();
            this.textBoxBX = new TableAIS.TextBoxWithTitle();
            this.buttonClearB = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxAZ = new TableAIS.TextBoxWithTitle();
            this.textBoxAY = new TableAIS.TextBoxWithTitle();
            this.textBoxAX = new TableAIS.TextBoxWithTitle();
            this.buttonClearA = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxLenA = new TableAIS.TextBoxWithTitle();
            this.buttonLenA = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxViewA = new TableAIS.TextBoxWithTitle();
            this.buttonViewA = new System.Windows.Forms.Button();
            this.buttonCalsAZ = new System.Windows.Forms.Button();
            this.buttonCalsAY = new System.Windows.Forms.Button();
            this.buttonCalsAX = new System.Windows.Forms.Button();
            this.menuStrip4 = new System.Windows.Forms.MenuStrip();
            this.вычислитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddAB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSubAB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonVectorMullAB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCoordsMullVector = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDivCoordsAB = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxScalarAB = new TableAIS.TextBoxWithTitle();
            this.buttonScalarAB = new System.Windows.Forms.Button();
            this.menuStrip5 = new System.Windows.Forms.MenuStrip();
            this.длинаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyLenA = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyLenB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyLenAB = new System.Windows.Forms.ToolStripMenuItem();
            this.умножитьНаЧислоToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonMullNA = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonMullNB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonMullNAB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonRet = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.flowResize2 = new TableAIS.FlowResize();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCalcLen = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLenToMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLenToLast = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLenToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.вЫвестиВКалькуляторToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToCalcA = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToCalcB = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToCalcBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToCalcHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLenClear = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxVectorLen = new TableAIS.TextBoxWithTitle();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonVectorAB = new System.Windows.Forms.RadioButton();
            this.radioButtonVectorB = new System.Windows.Forms.RadioButton();
            this.radioButtonVectorA = new System.Windows.Forms.RadioButton();
            this.textBoxVectorCoords = new TableAIS.TextBoxWithTitle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.изменениеИВыводToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonViewCalc = new System.Windows.Forms.ToolStripMenuItem();
            this.вывестиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCoordsToMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCoordsToLast = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCoordsToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCoordsClear = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLast = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToClipBoard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToCalculator = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCoordinateClear = new System.Windows.Forms.ToolStripMenuItem();
            this.ввестиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromLast = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromCalculator = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxCoordinate = new TableAIS.TextBoxWithTitle();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonCalcHelp = new System.Windows.Forms.RadioButton();
            this.radioButtonCalcBuffer = new System.Windows.Forms.RadioButton();
            this.radioButtonCalcA = new System.Windows.Forms.RadioButton();
            this.radioButtonCalcB = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonZ = new System.Windows.Forms.RadioButton();
            this.radioButtonY = new System.Windows.Forms.RadioButton();
            this.radioButtonX = new System.Windows.Forms.RadioButton();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxHelp = new TableAIS.TextBoxWithTitle();
            this.textBoxBuffer = new TableAIS.TextBoxWithTitle();
            this.textBoxA = new TableAIS.TextBoxWithTitle();
            this.textBoxB = new TableAIS.TextBoxWithTitle();
            this.textBoxSumView = new TableAIS.TextBoxWithTitle();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.comboBoxOutputPlace = new System.Windows.Forms.ComboBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.comboBoxOutputView = new System.Windows.Forms.ComboBox();
            this.buttonSumOutput = new System.Windows.Forms.Button();
            this.timerVectorSumView = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.flowResize1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.textBoxViewAB1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.menuStrip4.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.menuStrip5.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.flowResize2.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.menuStrip3.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonBack
            // 
            this.buttonBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBack.Location = new System.Drawing.Point(590, 25);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(25);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(263, 36);
            this.buttonBack.TabIndex = 0;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 527);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(882, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(151, 20);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(151, 20);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Interval = 1;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(882, 89);
            this.panel1.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonBack, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(878, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(89, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(473, 86);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Венкторный калькулятор";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 504);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(882, 23);
            this.panel2.TabIndex = 9;
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl1.Location = new System.Drawing.Point(0, 89);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(882, 415);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.flowResize1);
            this.tabPage1.Location = new System.Drawing.Point(4, 30);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(874, 381);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Векторная сумма";
            // 
            // flowResize1
            // 
            this.flowResize1.AutoScroll = true;
            this.flowResize1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize1.Controls.Add(this.tableLayoutPanel2);
            this.flowResize1.Controls.Add(this.groupBox22);
            this.flowResize1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize1.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.flowResize1.Location = new System.Drawing.Point(3, 3);
            this.flowResize1.Name = "flowResize1";
            this.flowResize1.Size = new System.Drawing.Size(868, 375);
            this.flowResize1.TabIndex = 0;
            this.flowResize1.WithDelta = 35;
            this.flowResize1.WrapContents = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel2.Controls.Add(this.groupBox10, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.groupBox7, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.groupBox3, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox4, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.menuStrip4, 2, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 319F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(833, 590);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.tableLayoutPanel12);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox10.Location = new System.Drawing.Point(557, 274);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox10.Size = new System.Drawing.Size(273, 313);
            this.groupBox10.TabIndex = 5;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Параметры вектора f(A;B)";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.groupBox11, 0, 3);
            this.tableLayoutPanel12.Controls.Add(this.groupBox12, 0, 2);
            this.tableLayoutPanel12.Controls.Add(this.buttonCalsABZ, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.buttonCalsABY, 1, 0);
            this.tableLayoutPanel12.Controls.Add(this.buttonCalsABX, 0, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(0, 21);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 4;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.1992F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.8008F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(273, 292);
            this.tableLayoutPanel12.TabIndex = 5;
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel12.SetColumnSpan(this.groupBox11, 2);
            this.groupBox11.Controls.Add(this.tableLayoutPanel13);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox11.Location = new System.Drawing.Point(3, 178);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox11.Size = new System.Drawing.Size(267, 111);
            this.groupBox11.TabIndex = 5;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Длина вектора";
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.Controls.Add(this.textBoxLenAB, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.buttonLenAB, 0, 1);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(0, 21);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.68687F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.31313F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(267, 90);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // textBoxLenAB
            // 
            this.textBoxLenAB.AllowNegative = true;
            this.textBoxLenAB.ClearingByReadonly = true;
            this.textBoxLenAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxLenAB.EnterAllow = true;
            this.textBoxLenAB.Location = new System.Drawing.Point(3, 3);
            this.textBoxLenAB.MultiLine = false;
            this.textBoxLenAB.Name = "textBoxLenAB";
            this.textBoxLenAB.NoReadOnly = false;
            this.textBoxLenAB.ReadOnly = true;
            this.textBoxLenAB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxLenAB.SelectionStart = 0;
            this.textBoxLenAB.Size = new System.Drawing.Size(261, 55);
            this.textBoxLenAB.TabIndex = 3;
            this.textBoxLenAB.TextWithLineBreaks = "";
            this.textBoxLenAB.Title = "";
            this.textBoxLenAB.UseSystemPasswordChar = false;
            this.textBoxLenAB.Value = "";
            this.textBoxLenAB.ValueBackColor = System.Drawing.Color.White;
            this.textBoxLenAB.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxLenAB.ValueText = "";
            this.textBoxLenAB.ValueType = TableAIS.TextTitleType.Double;
            this.textBoxLenAB.ValueWithLineBreaks = "";
            this.textBoxLenAB.VisibleOK = false;
            // 
            // buttonLenAB
            // 
            this.buttonLenAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLenAB.Location = new System.Drawing.Point(3, 64);
            this.buttonLenAB.Name = "buttonLenAB";
            this.buttonLenAB.Size = new System.Drawing.Size(261, 23);
            this.buttonLenAB.TabIndex = 4;
            this.buttonLenAB.Text = "Вычислить";
            this.buttonLenAB.UseVisualStyleBackColor = true;
            this.buttonLenAB.Click += new System.EventHandler(this.buttonLenAB_Click);
            // 
            // groupBox12
            // 
            this.tableLayoutPanel12.SetColumnSpan(this.groupBox12, 2);
            this.groupBox12.Controls.Add(this.textBoxViewAB1);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox12.Location = new System.Drawing.Point(3, 62);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox12.Size = new System.Drawing.Size(267, 110);
            this.groupBox12.TabIndex = 4;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Отображение вектора {x,y,z}";
            // 
            // textBoxViewAB1
            // 
            this.textBoxViewAB1.BackColor = System.Drawing.Color.Transparent;
            this.textBoxViewAB1.ColumnCount = 1;
            this.textBoxViewAB1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.textBoxViewAB1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.textBoxViewAB1.Controls.Add(this.textBoxViewAB, 0, 0);
            this.textBoxViewAB1.Controls.Add(this.buttonViewAB, 0, 1);
            this.textBoxViewAB1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxViewAB1.Location = new System.Drawing.Point(0, 21);
            this.textBoxViewAB1.Name = "textBoxViewAB1";
            this.textBoxViewAB1.RowCount = 2;
            this.textBoxViewAB1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.68687F));
            this.textBoxViewAB1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.31313F));
            this.textBoxViewAB1.Size = new System.Drawing.Size(267, 89);
            this.textBoxViewAB1.TabIndex = 0;
            // 
            // textBoxViewAB
            // 
            this.textBoxViewAB.AllowNegative = true;
            this.textBoxViewAB.BackColor = System.Drawing.Color.Transparent;
            this.textBoxViewAB.ClearingByReadonly = true;
            this.textBoxViewAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxViewAB.EnterAllow = true;
            this.textBoxViewAB.Location = new System.Drawing.Point(3, 3);
            this.textBoxViewAB.MultiLine = false;
            this.textBoxViewAB.Name = "textBoxViewAB";
            this.textBoxViewAB.NoReadOnly = false;
            this.textBoxViewAB.ReadOnly = true;
            this.textBoxViewAB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxViewAB.SelectionStart = 0;
            this.textBoxViewAB.Size = new System.Drawing.Size(261, 55);
            this.textBoxViewAB.TabIndex = 3;
            this.textBoxViewAB.TextWithLineBreaks = "";
            this.textBoxViewAB.Title = "";
            this.textBoxViewAB.UseSystemPasswordChar = false;
            this.textBoxViewAB.Value = "";
            this.textBoxViewAB.ValueBackColor = System.Drawing.Color.White;
            this.textBoxViewAB.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxViewAB.ValueText = "";
            this.textBoxViewAB.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxViewAB.ValueWithLineBreaks = "";
            this.textBoxViewAB.VisibleOK = false;
            // 
            // buttonViewAB
            // 
            this.buttonViewAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonViewAB.Location = new System.Drawing.Point(3, 64);
            this.buttonViewAB.Name = "buttonViewAB";
            this.buttonViewAB.Size = new System.Drawing.Size(261, 22);
            this.buttonViewAB.TabIndex = 4;
            this.buttonViewAB.Text = "Вычислить";
            this.buttonViewAB.UseVisualStyleBackColor = true;
            this.buttonViewAB.Click += new System.EventHandler(this.buttonViewAB_Click);
            // 
            // buttonCalsABZ
            // 
            this.buttonCalsABZ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalsABZ.Location = new System.Drawing.Point(3, 33);
            this.buttonCalsABZ.Name = "buttonCalsABZ";
            this.buttonCalsABZ.Size = new System.Drawing.Size(130, 23);
            this.buttonCalsABZ.TabIndex = 2;
            this.buttonCalsABZ.Text = "Вычислить Z";
            this.buttonCalsABZ.UseVisualStyleBackColor = true;
            this.buttonCalsABZ.Click += new System.EventHandler(this.buttonCalsABZ_Click);
            // 
            // buttonCalsABY
            // 
            this.buttonCalsABY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalsABY.Location = new System.Drawing.Point(139, 3);
            this.buttonCalsABY.Name = "buttonCalsABY";
            this.buttonCalsABY.Size = new System.Drawing.Size(131, 24);
            this.buttonCalsABY.TabIndex = 1;
            this.buttonCalsABY.Text = "Вычислить Y";
            this.buttonCalsABY.UseVisualStyleBackColor = true;
            this.buttonCalsABY.Click += new System.EventHandler(this.buttonCalsABY_Click);
            // 
            // buttonCalsABX
            // 
            this.buttonCalsABX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalsABX.Location = new System.Drawing.Point(3, 3);
            this.buttonCalsABX.Name = "buttonCalsABX";
            this.buttonCalsABX.Size = new System.Drawing.Size(130, 24);
            this.buttonCalsABX.TabIndex = 0;
            this.buttonCalsABX.Text = "Вычислить X";
            this.buttonCalsABX.UseVisualStyleBackColor = true;
            this.buttonCalsABX.Click += new System.EventHandler(this.buttonCalsABX_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.tableLayoutPanel9);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(280, 243);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.SetRowSpan(this.groupBox7, 2);
            this.groupBox7.Size = new System.Drawing.Size(271, 344);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Параметры вектора B";
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.groupBox8, 0, 3);
            this.tableLayoutPanel9.Controls.Add(this.groupBox9, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.buttonCalsBZ, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.buttonCalsBY, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.buttonCalsBX, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(0, 21);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 4;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.62406F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.37594F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(271, 323);
            this.tableLayoutPanel9.TabIndex = 5;
            // 
            // groupBox8
            // 
            this.tableLayoutPanel9.SetColumnSpan(this.groupBox8, 2);
            this.groupBox8.Controls.Add(this.tableLayoutPanel10);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Location = new System.Drawing.Point(3, 203);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox8.Size = new System.Drawing.Size(265, 117);
            this.groupBox8.TabIndex = 5;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Длина вектора";
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.Controls.Add(this.textBoxLenB, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.buttonLenB, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(0, 21);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.68687F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.31313F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(265, 96);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // textBoxLenB
            // 
            this.textBoxLenB.AllowNegative = true;
            this.textBoxLenB.ClearingByReadonly = true;
            this.textBoxLenB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxLenB.EnterAllow = true;
            this.textBoxLenB.Location = new System.Drawing.Point(3, 3);
            this.textBoxLenB.MultiLine = false;
            this.textBoxLenB.Name = "textBoxLenB";
            this.textBoxLenB.NoReadOnly = false;
            this.textBoxLenB.ReadOnly = true;
            this.textBoxLenB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxLenB.SelectionStart = 0;
            this.textBoxLenB.Size = new System.Drawing.Size(259, 59);
            this.textBoxLenB.TabIndex = 3;
            this.textBoxLenB.TextWithLineBreaks = "";
            this.textBoxLenB.Title = "";
            this.textBoxLenB.UseSystemPasswordChar = false;
            this.textBoxLenB.Value = "";
            this.textBoxLenB.ValueBackColor = System.Drawing.Color.White;
            this.textBoxLenB.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxLenB.ValueText = "";
            this.textBoxLenB.ValueType = TableAIS.TextTitleType.Double;
            this.textBoxLenB.ValueWithLineBreaks = "";
            this.textBoxLenB.VisibleOK = false;
            // 
            // buttonLenB
            // 
            this.buttonLenB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLenB.Location = new System.Drawing.Point(3, 68);
            this.buttonLenB.Name = "buttonLenB";
            this.buttonLenB.Size = new System.Drawing.Size(259, 25);
            this.buttonLenB.TabIndex = 4;
            this.buttonLenB.Text = "Вычислить";
            this.buttonLenB.UseVisualStyleBackColor = true;
            this.buttonLenB.Click += new System.EventHandler(this.buttonLenB_Click);
            // 
            // groupBox9
            // 
            this.tableLayoutPanel9.SetColumnSpan(this.groupBox9, 2);
            this.groupBox9.Controls.Add(this.tableLayoutPanel11);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox9.Location = new System.Drawing.Point(3, 83);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox9.Size = new System.Drawing.Size(265, 114);
            this.groupBox9.TabIndex = 4;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Отображение вектора {x,y,z}";
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel11.Controls.Add(this.textBoxViewB, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.buttonViewB, 0, 1);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(0, 21);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.68687F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.31313F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(265, 93);
            this.tableLayoutPanel11.TabIndex = 0;
            // 
            // textBoxViewB
            // 
            this.textBoxViewB.AllowNegative = true;
            this.textBoxViewB.ClearingByReadonly = true;
            this.textBoxViewB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxViewB.EnterAllow = true;
            this.textBoxViewB.Location = new System.Drawing.Point(3, 3);
            this.textBoxViewB.MultiLine = false;
            this.textBoxViewB.Name = "textBoxViewB";
            this.textBoxViewB.NoReadOnly = false;
            this.textBoxViewB.ReadOnly = true;
            this.textBoxViewB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxViewB.SelectionStart = 0;
            this.textBoxViewB.Size = new System.Drawing.Size(259, 57);
            this.textBoxViewB.TabIndex = 3;
            this.textBoxViewB.TextWithLineBreaks = "";
            this.textBoxViewB.Title = "";
            this.textBoxViewB.UseSystemPasswordChar = false;
            this.textBoxViewB.Value = "";
            this.textBoxViewB.ValueBackColor = System.Drawing.Color.White;
            this.textBoxViewB.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxViewB.ValueText = "";
            this.textBoxViewB.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxViewB.ValueWithLineBreaks = "";
            this.textBoxViewB.VisibleOK = false;
            // 
            // buttonViewB
            // 
            this.buttonViewB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonViewB.Location = new System.Drawing.Point(3, 66);
            this.buttonViewB.Name = "buttonViewB";
            this.buttonViewB.Size = new System.Drawing.Size(259, 24);
            this.buttonViewB.TabIndex = 4;
            this.buttonViewB.Text = "Вычислить";
            this.buttonViewB.UseVisualStyleBackColor = true;
            this.buttonViewB.Click += new System.EventHandler(this.buttonViewB_Click);
            // 
            // buttonCalsBZ
            // 
            this.buttonCalsBZ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalsBZ.Location = new System.Drawing.Point(3, 41);
            this.buttonCalsBZ.Name = "buttonCalsBZ";
            this.buttonCalsBZ.Size = new System.Drawing.Size(129, 36);
            this.buttonCalsBZ.TabIndex = 2;
            this.buttonCalsBZ.Text = "Вычислить Z";
            this.buttonCalsBZ.UseVisualStyleBackColor = true;
            this.buttonCalsBZ.Click += new System.EventHandler(this.buttonCalsBZ_Click);
            // 
            // buttonCalsBY
            // 
            this.buttonCalsBY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalsBY.Location = new System.Drawing.Point(138, 3);
            this.buttonCalsBY.Name = "buttonCalsBY";
            this.buttonCalsBY.Size = new System.Drawing.Size(130, 32);
            this.buttonCalsBY.TabIndex = 1;
            this.buttonCalsBY.Text = "Вычислить Y";
            this.buttonCalsBY.UseVisualStyleBackColor = true;
            this.buttonCalsBY.Click += new System.EventHandler(this.buttonCalsBY_Click);
            // 
            // buttonCalsBX
            // 
            this.buttonCalsBX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalsBX.Location = new System.Drawing.Point(3, 3);
            this.buttonCalsBX.Name = "buttonCalsBX";
            this.buttonCalsBX.Size = new System.Drawing.Size(129, 32);
            this.buttonCalsBX.TabIndex = 0;
            this.buttonCalsBX.Text = "Вычислить X";
            this.buttonCalsBX.UseVisualStyleBackColor = true;
            this.buttonCalsBX.Click += new System.EventHandler(this.buttonCalsBX_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel5);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(557, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(273, 234);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Вектор f(A;B)";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.textBoxABZ, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.textBoxABY, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.textBoxABX, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonClearAB, 0, 3);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 24);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 4;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(267, 207);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // textBoxABZ
            // 
            this.textBoxABZ.AllowNegative = true;
            this.textBoxABZ.ClearingByReadonly = true;
            this.textBoxABZ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxABZ.EnterAllow = true;
            this.textBoxABZ.Location = new System.Drawing.Point(4, 122);
            this.textBoxABZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxABZ.MultiLine = false;
            this.textBoxABZ.Name = "textBoxABZ";
            this.textBoxABZ.NoReadOnly = false;
            this.textBoxABZ.ReadOnly = true;
            this.textBoxABZ.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxABZ.SelectionStart = 0;
            this.textBoxABZ.Size = new System.Drawing.Size(259, 51);
            this.textBoxABZ.TabIndex = 2;
            this.textBoxABZ.TextWithLineBreaks = "";
            this.textBoxABZ.Title = "Координата Z";
            this.textBoxABZ.UseSystemPasswordChar = false;
            this.textBoxABZ.Value = "";
            this.textBoxABZ.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxABZ.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxABZ.ValueText = "";
            this.textBoxABZ.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxABZ.ValueWithLineBreaks = "";
            this.textBoxABZ.VisibleOK = false;
            // 
            // textBoxABY
            // 
            this.textBoxABY.AllowNegative = true;
            this.textBoxABY.ClearingByReadonly = true;
            this.textBoxABY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxABY.EnterAllow = true;
            this.textBoxABY.Location = new System.Drawing.Point(4, 63);
            this.textBoxABY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxABY.MultiLine = false;
            this.textBoxABY.Name = "textBoxABY";
            this.textBoxABY.NoReadOnly = false;
            this.textBoxABY.ReadOnly = true;
            this.textBoxABY.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxABY.SelectionStart = 0;
            this.textBoxABY.Size = new System.Drawing.Size(259, 51);
            this.textBoxABY.TabIndex = 1;
            this.textBoxABY.TextWithLineBreaks = "";
            this.textBoxABY.Title = "Координата Y";
            this.textBoxABY.UseSystemPasswordChar = false;
            this.textBoxABY.Value = "";
            this.textBoxABY.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxABY.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxABY.ValueText = "";
            this.textBoxABY.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxABY.ValueWithLineBreaks = "";
            this.textBoxABY.VisibleOK = false;
            // 
            // textBoxABX
            // 
            this.textBoxABX.AllowNegative = true;
            this.textBoxABX.ClearingByReadonly = true;
            this.textBoxABX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxABX.EnterAllow = true;
            this.textBoxABX.Location = new System.Drawing.Point(4, 4);
            this.textBoxABX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxABX.MultiLine = false;
            this.textBoxABX.Name = "textBoxABX";
            this.textBoxABX.NoReadOnly = false;
            this.textBoxABX.ReadOnly = true;
            this.textBoxABX.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxABX.SelectionStart = 0;
            this.textBoxABX.Size = new System.Drawing.Size(259, 51);
            this.textBoxABX.TabIndex = 0;
            this.textBoxABX.TextWithLineBreaks = "";
            this.textBoxABX.Title = "Координата X";
            this.textBoxABX.UseSystemPasswordChar = false;
            this.textBoxABX.Value = "";
            this.textBoxABX.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxABX.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxABX.ValueText = "";
            this.textBoxABX.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxABX.ValueWithLineBreaks = "";
            this.textBoxABX.VisibleOK = false;
            // 
            // buttonClearAB
            // 
            this.buttonClearAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearAB.Location = new System.Drawing.Point(3, 180);
            this.buttonClearAB.Name = "buttonClearAB";
            this.buttonClearAB.Size = new System.Drawing.Size(261, 24);
            this.buttonClearAB.TabIndex = 3;
            this.buttonClearAB.Text = "Сбросить";
            this.buttonClearAB.UseVisualStyleBackColor = true;
            this.buttonClearAB.Click += new System.EventHandler(this.buttonClearAB_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel4);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(280, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(271, 234);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Вектор B";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.textBoxBZ, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.textBoxBY, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.textBoxBX, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.buttonClearB, 0, 3);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 24);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 4;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(265, 207);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // textBoxBZ
            // 
            this.textBoxBZ.AllowNegative = true;
            this.textBoxBZ.ClearingByReadonly = false;
            this.textBoxBZ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxBZ.EnterAllow = true;
            this.textBoxBZ.Location = new System.Drawing.Point(4, 122);
            this.textBoxBZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxBZ.MultiLine = false;
            this.textBoxBZ.Name = "textBoxBZ";
            this.textBoxBZ.NoReadOnly = true;
            this.textBoxBZ.ReadOnly = false;
            this.textBoxBZ.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxBZ.SelectionStart = 0;
            this.textBoxBZ.Size = new System.Drawing.Size(257, 51);
            this.textBoxBZ.TabIndex = 2;
            this.textBoxBZ.TextWithLineBreaks = "";
            this.textBoxBZ.Title = "Координата Z";
            this.textBoxBZ.UseSystemPasswordChar = false;
            this.textBoxBZ.Value = "";
            this.textBoxBZ.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxBZ.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxBZ.ValueText = "";
            this.textBoxBZ.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxBZ.ValueWithLineBreaks = "";
            this.textBoxBZ.VisibleOK = false;
            // 
            // textBoxBY
            // 
            this.textBoxBY.AllowNegative = true;
            this.textBoxBY.ClearingByReadonly = false;
            this.textBoxBY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxBY.EnterAllow = true;
            this.textBoxBY.Location = new System.Drawing.Point(4, 63);
            this.textBoxBY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxBY.MultiLine = false;
            this.textBoxBY.Name = "textBoxBY";
            this.textBoxBY.NoReadOnly = true;
            this.textBoxBY.ReadOnly = false;
            this.textBoxBY.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxBY.SelectionStart = 0;
            this.textBoxBY.Size = new System.Drawing.Size(257, 51);
            this.textBoxBY.TabIndex = 1;
            this.textBoxBY.TextWithLineBreaks = "";
            this.textBoxBY.Title = "Координата Y";
            this.textBoxBY.UseSystemPasswordChar = false;
            this.textBoxBY.Value = "";
            this.textBoxBY.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxBY.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxBY.ValueText = "";
            this.textBoxBY.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxBY.ValueWithLineBreaks = "";
            this.textBoxBY.VisibleOK = false;
            // 
            // textBoxBX
            // 
            this.textBoxBX.AllowNegative = true;
            this.textBoxBX.ClearingByReadonly = false;
            this.textBoxBX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxBX.EnterAllow = true;
            this.textBoxBX.Location = new System.Drawing.Point(4, 4);
            this.textBoxBX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxBX.MultiLine = false;
            this.textBoxBX.Name = "textBoxBX";
            this.textBoxBX.NoReadOnly = true;
            this.textBoxBX.ReadOnly = false;
            this.textBoxBX.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxBX.SelectionStart = 0;
            this.textBoxBX.Size = new System.Drawing.Size(257, 51);
            this.textBoxBX.TabIndex = 0;
            this.textBoxBX.TextWithLineBreaks = "";
            this.textBoxBX.Title = "Координата X";
            this.textBoxBX.UseSystemPasswordChar = false;
            this.textBoxBX.Value = "";
            this.textBoxBX.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxBX.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxBX.ValueText = "";
            this.textBoxBX.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxBX.ValueWithLineBreaks = "";
            this.textBoxBX.VisibleOK = false;
            // 
            // buttonClearB
            // 
            this.buttonClearB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearB.Location = new System.Drawing.Point(3, 180);
            this.buttonClearB.Name = "buttonClearB";
            this.buttonClearB.Size = new System.Drawing.Size(259, 24);
            this.buttonClearB.TabIndex = 3;
            this.buttonClearB.Text = "Сбросить";
            this.buttonClearB.UseVisualStyleBackColor = true;
            this.buttonClearB.Click += new System.EventHandler(this.buttonClearB_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(271, 234);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Вектор A";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.textBoxAZ, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.textBoxAY, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.textBoxAX, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonClearA, 0, 3);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 24);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(265, 207);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // textBoxAZ
            // 
            this.textBoxAZ.AllowNegative = true;
            this.textBoxAZ.ClearingByReadonly = false;
            this.textBoxAZ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxAZ.EnterAllow = true;
            this.textBoxAZ.Location = new System.Drawing.Point(4, 122);
            this.textBoxAZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAZ.MultiLine = false;
            this.textBoxAZ.Name = "textBoxAZ";
            this.textBoxAZ.NoReadOnly = true;
            this.textBoxAZ.ReadOnly = false;
            this.textBoxAZ.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxAZ.SelectionStart = 0;
            this.textBoxAZ.Size = new System.Drawing.Size(257, 51);
            this.textBoxAZ.TabIndex = 2;
            this.textBoxAZ.TextWithLineBreaks = "";
            this.textBoxAZ.Title = "Координата Z";
            this.textBoxAZ.UseSystemPasswordChar = false;
            this.textBoxAZ.Value = "";
            this.textBoxAZ.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxAZ.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxAZ.ValueText = "";
            this.textBoxAZ.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxAZ.ValueWithLineBreaks = "";
            this.textBoxAZ.VisibleOK = false;
            // 
            // textBoxAY
            // 
            this.textBoxAY.AllowNegative = true;
            this.textBoxAY.ClearingByReadonly = false;
            this.textBoxAY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxAY.EnterAllow = true;
            this.textBoxAY.Location = new System.Drawing.Point(4, 63);
            this.textBoxAY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAY.MultiLine = false;
            this.textBoxAY.Name = "textBoxAY";
            this.textBoxAY.NoReadOnly = true;
            this.textBoxAY.ReadOnly = false;
            this.textBoxAY.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxAY.SelectionStart = 0;
            this.textBoxAY.Size = new System.Drawing.Size(257, 51);
            this.textBoxAY.TabIndex = 1;
            this.textBoxAY.TextWithLineBreaks = "";
            this.textBoxAY.Title = "Координата Y";
            this.textBoxAY.UseSystemPasswordChar = false;
            this.textBoxAY.Value = "";
            this.textBoxAY.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxAY.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxAY.ValueText = "";
            this.textBoxAY.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxAY.ValueWithLineBreaks = "";
            this.textBoxAY.VisibleOK = false;
            // 
            // textBoxAX
            // 
            this.textBoxAX.AllowNegative = true;
            this.textBoxAX.ClearingByReadonly = false;
            this.textBoxAX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxAX.EnterAllow = true;
            this.textBoxAX.Location = new System.Drawing.Point(4, 4);
            this.textBoxAX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAX.MultiLine = false;
            this.textBoxAX.Name = "textBoxAX";
            this.textBoxAX.NoReadOnly = true;
            this.textBoxAX.ReadOnly = false;
            this.textBoxAX.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxAX.SelectionStart = 0;
            this.textBoxAX.Size = new System.Drawing.Size(257, 51);
            this.textBoxAX.TabIndex = 0;
            this.textBoxAX.TextWithLineBreaks = "";
            this.textBoxAX.Title = "Координата X";
            this.textBoxAX.UseSystemPasswordChar = false;
            this.textBoxAX.Value = "";
            this.textBoxAX.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxAX.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxAX.ValueText = "";
            this.textBoxAX.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxAX.ValueWithLineBreaks = "";
            this.textBoxAX.VisibleOK = false;
            // 
            // buttonClearA
            // 
            this.buttonClearA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearA.Location = new System.Drawing.Point(3, 180);
            this.buttonClearA.Name = "buttonClearA";
            this.buttonClearA.Size = new System.Drawing.Size(259, 24);
            this.buttonClearA.TabIndex = 3;
            this.buttonClearA.Text = "Сбросить";
            this.buttonClearA.UseVisualStyleBackColor = true;
            this.buttonClearA.Click += new System.EventHandler(this.buttonClearA_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tableLayoutPanel7);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(3, 243);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.SetRowSpan(this.groupBox4, 2);
            this.groupBox4.Size = new System.Drawing.Size(271, 344);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Параметры вектора A";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.groupBox6, 0, 3);
            this.tableLayoutPanel7.Controls.Add(this.groupBox5, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.buttonCalsAZ, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.buttonCalsAY, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonCalsAX, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 21);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 4;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.19011F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.80989F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(271, 323);
            this.tableLayoutPanel7.TabIndex = 5;
            // 
            // groupBox6
            // 
            this.tableLayoutPanel7.SetColumnSpan(this.groupBox6, 2);
            this.groupBox6.Controls.Add(this.tableLayoutPanel8);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(3, 202);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox6.Size = new System.Drawing.Size(265, 118);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Длина вектора";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.Controls.Add(this.textBoxLenA, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.buttonLenA, 0, 1);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 21);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.68687F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.31313F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(265, 97);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // textBoxLenA
            // 
            this.textBoxLenA.AllowNegative = true;
            this.textBoxLenA.ClearingByReadonly = true;
            this.textBoxLenA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxLenA.EnterAllow = true;
            this.textBoxLenA.Location = new System.Drawing.Point(3, 3);
            this.textBoxLenA.MultiLine = false;
            this.textBoxLenA.Name = "textBoxLenA";
            this.textBoxLenA.NoReadOnly = false;
            this.textBoxLenA.ReadOnly = true;
            this.textBoxLenA.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxLenA.SelectionStart = 0;
            this.textBoxLenA.Size = new System.Drawing.Size(259, 60);
            this.textBoxLenA.TabIndex = 3;
            this.textBoxLenA.TextWithLineBreaks = "";
            this.textBoxLenA.Title = "";
            this.textBoxLenA.UseSystemPasswordChar = false;
            this.textBoxLenA.Value = "";
            this.textBoxLenA.ValueBackColor = System.Drawing.Color.White;
            this.textBoxLenA.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxLenA.ValueText = "";
            this.textBoxLenA.ValueType = TableAIS.TextTitleType.Double;
            this.textBoxLenA.ValueWithLineBreaks = "";
            this.textBoxLenA.VisibleOK = false;
            // 
            // buttonLenA
            // 
            this.buttonLenA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLenA.Location = new System.Drawing.Point(3, 69);
            this.buttonLenA.Name = "buttonLenA";
            this.buttonLenA.Size = new System.Drawing.Size(259, 25);
            this.buttonLenA.TabIndex = 4;
            this.buttonLenA.Text = "Вычислить";
            this.buttonLenA.UseVisualStyleBackColor = true;
            this.buttonLenA.Click += new System.EventHandler(this.buttonLenA_Click);
            // 
            // groupBox5
            // 
            this.tableLayoutPanel7.SetColumnSpan(this.groupBox5, 2);
            this.groupBox5.Controls.Add(this.tableLayoutPanel6);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(3, 78);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox5.Size = new System.Drawing.Size(265, 118);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Отображение вектора {x,y,z}";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Controls.Add(this.textBoxViewA, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.buttonViewA, 0, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 21);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.68687F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.31313F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(265, 97);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // textBoxViewA
            // 
            this.textBoxViewA.AllowNegative = true;
            this.textBoxViewA.ClearingByReadonly = true;
            this.textBoxViewA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxViewA.EnterAllow = true;
            this.textBoxViewA.Location = new System.Drawing.Point(3, 3);
            this.textBoxViewA.MultiLine = false;
            this.textBoxViewA.Name = "textBoxViewA";
            this.textBoxViewA.NoReadOnly = false;
            this.textBoxViewA.ReadOnly = true;
            this.textBoxViewA.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxViewA.SelectionStart = 0;
            this.textBoxViewA.Size = new System.Drawing.Size(259, 60);
            this.textBoxViewA.TabIndex = 3;
            this.textBoxViewA.TextWithLineBreaks = "";
            this.textBoxViewA.Title = "";
            this.textBoxViewA.UseSystemPasswordChar = false;
            this.textBoxViewA.Value = "";
            this.textBoxViewA.ValueBackColor = System.Drawing.Color.White;
            this.textBoxViewA.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxViewA.ValueText = "";
            this.textBoxViewA.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxViewA.ValueWithLineBreaks = "";
            this.textBoxViewA.VisibleOK = false;
            // 
            // buttonViewA
            // 
            this.buttonViewA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonViewA.Location = new System.Drawing.Point(3, 69);
            this.buttonViewA.Name = "buttonViewA";
            this.buttonViewA.Size = new System.Drawing.Size(259, 25);
            this.buttonViewA.TabIndex = 4;
            this.buttonViewA.Text = "Вычислить";
            this.buttonViewA.UseVisualStyleBackColor = true;
            this.buttonViewA.Click += new System.EventHandler(this.buttonViewA_Click);
            // 
            // buttonCalsAZ
            // 
            this.buttonCalsAZ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalsAZ.Location = new System.Drawing.Point(3, 39);
            this.buttonCalsAZ.Name = "buttonCalsAZ";
            this.buttonCalsAZ.Size = new System.Drawing.Size(129, 33);
            this.buttonCalsAZ.TabIndex = 2;
            this.buttonCalsAZ.Text = "Вычислить Z";
            this.buttonCalsAZ.UseVisualStyleBackColor = true;
            this.buttonCalsAZ.Click += new System.EventHandler(this.buttonCalsAZ_Click);
            // 
            // buttonCalsAY
            // 
            this.buttonCalsAY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalsAY.Location = new System.Drawing.Point(138, 3);
            this.buttonCalsAY.Name = "buttonCalsAY";
            this.buttonCalsAY.Size = new System.Drawing.Size(130, 30);
            this.buttonCalsAY.TabIndex = 1;
            this.buttonCalsAY.Text = "Вычислить Y";
            this.buttonCalsAY.UseVisualStyleBackColor = true;
            this.buttonCalsAY.Click += new System.EventHandler(this.buttonCalsAY_Click);
            // 
            // buttonCalsAX
            // 
            this.buttonCalsAX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCalsAX.Location = new System.Drawing.Point(3, 3);
            this.buttonCalsAX.Name = "buttonCalsAX";
            this.buttonCalsAX.Size = new System.Drawing.Size(129, 30);
            this.buttonCalsAX.TabIndex = 0;
            this.buttonCalsAX.Text = "Вычислить X";
            this.buttonCalsAX.UseVisualStyleBackColor = true;
            this.buttonCalsAX.Click += new System.EventHandler(this.buttonCalsAX_Click);
            // 
            // menuStrip4
            // 
            this.menuStrip4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip4.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F);
            this.menuStrip4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вычислитьToolStripMenuItem});
            this.menuStrip4.Location = new System.Drawing.Point(554, 240);
            this.menuStrip4.Name = "menuStrip4";
            this.menuStrip4.Size = new System.Drawing.Size(279, 31);
            this.menuStrip4.TabIndex = 6;
            this.menuStrip4.Text = "menuStrip4";
            // 
            // вычислитьToolStripMenuItem
            // 
            this.вычислитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddAB,
            this.buttonSubAB,
            this.buttonVectorMullAB,
            this.buttonCoordsMullVector,
            this.buttonDivCoordsAB});
            this.вычислитьToolStripMenuItem.Name = "вычислитьToolStripMenuItem";
            this.вычислитьToolStripMenuItem.Size = new System.Drawing.Size(112, 26);
            this.вычислитьToolStripMenuItem.Text = "Вычисление";
            // 
            // buttonAddAB
            // 
            this.buttonAddAB.Name = "buttonAddAB";
            this.buttonAddAB.Size = new System.Drawing.Size(385, 26);
            this.buttonAddAB.Text = "Сумма (A+B)";
            this.buttonAddAB.Click += new System.EventHandler(this.buttonAddAB_Click);
            // 
            // buttonSubAB
            // 
            this.buttonSubAB.Name = "buttonSubAB";
            this.buttonSubAB.Size = new System.Drawing.Size(385, 26);
            this.buttonSubAB.Text = "Разность (A-B)";
            this.buttonSubAB.Click += new System.EventHandler(this.buttonSubAB_Click);
            // 
            // buttonVectorMullAB
            // 
            this.buttonVectorMullAB.Name = "buttonVectorMullAB";
            this.buttonVectorMullAB.Size = new System.Drawing.Size(385, 26);
            this.buttonVectorMullAB.Text = "Векторное произведение [A;B]";
            this.buttonVectorMullAB.Click += new System.EventHandler(this.buttonVectorMullAB_Click);
            // 
            // buttonCoordsMullVector
            // 
            this.buttonCoordsMullVector.Name = "buttonCoordsMullVector";
            this.buttonCoordsMullVector.Size = new System.Drawing.Size(385, 26);
            this.buttonCoordsMullVector.Text = "Покоординатное умножение векторов";
            this.buttonCoordsMullVector.Click += new System.EventHandler(this.buttonCoordsMullVector_Click);
            // 
            // buttonDivCoordsAB
            // 
            this.buttonDivCoordsAB.Name = "buttonDivCoordsAB";
            this.buttonDivCoordsAB.Size = new System.Drawing.Size(385, 26);
            this.buttonDivCoordsAB.Text = "Покоординатное деление векторов";
            this.buttonDivCoordsAB.Click += new System.EventHandler(this.buttonDivCoordsAB_Click);
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.tableLayoutPanel21);
            this.groupBox22.Location = new System.Drawing.Point(3, 599);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox22.Size = new System.Drawing.Size(833, 80);
            this.groupBox22.TabIndex = 1;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Число/Выражение";
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel21.ColumnCount = 3;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel21.Controls.Add(this.textBoxScalarAB, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.buttonScalarAB, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.menuStrip5, 2, 0);
            this.tableLayoutPanel21.Controls.Add(this.buttonRet, 1, 1);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(0, 21);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 2;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(833, 59);
            this.tableLayoutPanel21.TabIndex = 0;
            // 
            // textBoxScalarAB
            // 
            this.textBoxScalarAB.AllowNegative = true;
            this.textBoxScalarAB.ClearingByReadonly = false;
            this.textBoxScalarAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxScalarAB.EnterAllow = true;
            this.textBoxScalarAB.Location = new System.Drawing.Point(3, 3);
            this.textBoxScalarAB.MultiLine = false;
            this.textBoxScalarAB.Name = "textBoxScalarAB";
            this.textBoxScalarAB.NoReadOnly = true;
            this.textBoxScalarAB.ReadOnly = false;
            this.tableLayoutPanel21.SetRowSpan(this.textBoxScalarAB, 2);
            this.textBoxScalarAB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxScalarAB.SelectionStart = 0;
            this.textBoxScalarAB.Size = new System.Drawing.Size(271, 53);
            this.textBoxScalarAB.TabIndex = 0;
            this.textBoxScalarAB.TextWithLineBreaks = "";
            this.textBoxScalarAB.Title = "Значение";
            this.textBoxScalarAB.UseSystemPasswordChar = false;
            this.textBoxScalarAB.Value = "";
            this.textBoxScalarAB.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxScalarAB.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxScalarAB.ValueText = "";
            this.textBoxScalarAB.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxScalarAB.ValueWithLineBreaks = "";
            this.textBoxScalarAB.VisibleOK = false;
            // 
            // buttonScalarAB
            // 
            this.buttonScalarAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonScalarAB.Location = new System.Drawing.Point(280, 3);
            this.buttonScalarAB.Name = "buttonScalarAB";
            this.buttonScalarAB.Size = new System.Drawing.Size(271, 23);
            this.buttonScalarAB.TabIndex = 1;
            this.buttonScalarAB.Text = "Скалярное произведение";
            this.buttonScalarAB.UseVisualStyleBackColor = true;
            this.buttonScalarAB.Click += new System.EventHandler(this.buttonScalarAB_Click);
            // 
            // menuStrip5
            // 
            this.menuStrip5.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F);
            this.menuStrip5.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.длинаToolStripMenuItem,
            this.умножитьНаЧислоToolStripMenuItem});
            this.menuStrip5.Location = new System.Drawing.Point(557, 3);
            this.menuStrip5.Margin = new System.Windows.Forms.Padding(3);
            this.menuStrip5.Name = "menuStrip5";
            this.menuStrip5.Size = new System.Drawing.Size(273, 23);
            this.menuStrip5.TabIndex = 2;
            this.menuStrip5.Text = "menuStrip5";
            // 
            // длинаToolStripMenuItem
            // 
            this.длинаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCopyLenA,
            this.buttonCopyLenB,
            this.buttonCopyLenAB});
            this.длинаToolStripMenuItem.Name = "длинаToolStripMenuItem";
            this.длинаToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            this.длинаToolStripMenuItem.Text = "Длина";
            // 
            // buttonCopyLenA
            // 
            this.buttonCopyLenA.Name = "buttonCopyLenA";
            this.buttonCopyLenA.Size = new System.Drawing.Size(130, 26);
            this.buttonCopyLenA.Text = "A";
            this.buttonCopyLenA.Click += new System.EventHandler(this.buttonCopyLenA_Click);
            // 
            // buttonCopyLenB
            // 
            this.buttonCopyLenB.Name = "buttonCopyLenB";
            this.buttonCopyLenB.Size = new System.Drawing.Size(130, 26);
            this.buttonCopyLenB.Text = "B";
            this.buttonCopyLenB.Click += new System.EventHandler(this.buttonCopyLenB_Click);
            // 
            // buttonCopyLenAB
            // 
            this.buttonCopyLenAB.Name = "buttonCopyLenAB";
            this.buttonCopyLenAB.Size = new System.Drawing.Size(130, 26);
            this.buttonCopyLenAB.Text = "f(A;B)";
            this.buttonCopyLenAB.Click += new System.EventHandler(this.buttonCopyLenAB_Click);
            // 
            // умножитьНаЧислоToolStripMenuItem
            // 
            this.умножитьНаЧислоToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonMullNA,
            this.buttonMullNB,
            this.buttonMullNAB});
            this.умножитьНаЧислоToolStripMenuItem.Name = "умножитьНаЧислоToolStripMenuItem";
            this.умножитьНаЧислоToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.умножитьНаЧислоToolStripMenuItem.Text = "Умножить на число";
            // 
            // buttonMullNA
            // 
            this.buttonMullNA.Name = "buttonMullNA";
            this.buttonMullNA.Size = new System.Drawing.Size(130, 26);
            this.buttonMullNA.Text = "A";
            this.buttonMullNA.Click += new System.EventHandler(this.buttonMullNA_Click);
            // 
            // buttonMullNB
            // 
            this.buttonMullNB.Name = "buttonMullNB";
            this.buttonMullNB.Size = new System.Drawing.Size(130, 26);
            this.buttonMullNB.Text = "B";
            this.buttonMullNB.Click += new System.EventHandler(this.buttonMullNB_Click);
            // 
            // buttonMullNAB
            // 
            this.buttonMullNAB.Name = "buttonMullNAB";
            this.buttonMullNAB.Size = new System.Drawing.Size(130, 26);
            this.buttonMullNAB.Text = "f(A;B)";
            this.buttonMullNAB.Click += new System.EventHandler(this.buttonMullNAB_Click);
            // 
            // buttonRet
            // 
            this.buttonRet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonRet.Location = new System.Drawing.Point(280, 32);
            this.buttonRet.Name = "buttonRet";
            this.buttonRet.Size = new System.Drawing.Size(271, 24);
            this.buttonRet.TabIndex = 3;
            this.buttonRet.Text = "Обратное введённому";
            this.buttonRet.UseVisualStyleBackColor = true;
            this.buttonRet.Click += new System.EventHandler(this.buttonRet_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.flowResize2);
            this.tabPage2.Location = new System.Drawing.Point(4, 30);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(874, 381);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Векторная сумма и внешние данные";
            // 
            // flowResize2
            // 
            this.flowResize2.AutoScroll = true;
            this.flowResize2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowResize2.Controls.Add(this.groupBox13);
            this.flowResize2.Controls.Add(this.groupBox16);
            this.flowResize2.Controls.Add(this.groupBox15);
            this.flowResize2.Controls.Add(this.textBoxSumView);
            this.flowResize2.Controls.Add(this.groupBox19);
            this.flowResize2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowResize2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowResize2.Location = new System.Drawing.Point(3, 3);
            this.flowResize2.Name = "flowResize2";
            this.flowResize2.Size = new System.Drawing.Size(868, 375);
            this.flowResize2.TabIndex = 0;
            this.flowResize2.WithDelta = 35;
            this.flowResize2.WrapContents = false;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.tableLayoutPanel14);
            this.groupBox13.Location = new System.Drawing.Point(3, 3);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(833, 175);
            this.groupBox13.TabIndex = 0;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Вектор";
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 168F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.83308F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.16692F));
            this.tableLayoutPanel14.Controls.Add(this.menuStrip2, 2, 1);
            this.tableLayoutPanel14.Controls.Add(this.textBoxVectorLen, 1, 1);
            this.tableLayoutPanel14.Controls.Add(this.groupBox14, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.textBoxVectorCoords, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.menuStrip1, 2, 0);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 2;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(827, 145);
            this.tableLayoutPanel14.TabIndex = 0;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip2.Location = new System.Drawing.Point(516, 72);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(311, 29);
            this.menuStrip2.TabIndex = 4;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCalcLen,
            this.toolStripMenuItem3,
            this.вЫвестиВКалькуляторToolStripMenuItem,
            this.buttonLenClear});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(193, 25);
            this.toolStripMenuItem1.Text = "Изменение и вывод";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // buttonCalcLen
            // 
            this.buttonCalcLen.Name = "buttonCalcLen";
            this.buttonCalcLen.Size = new System.Drawing.Size(286, 26);
            this.buttonCalcLen.Text = "Вычислить";
            this.buttonCalcLen.Click += new System.EventHandler(this.buttonCalcLen_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonLenToMain,
            this.buttonLenToLast,
            this.buttonLenToClipboard});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(286, 26);
            this.toolStripMenuItem3.Text = "Вывести";
            // 
            // buttonLenToMain
            // 
            this.buttonLenToMain.Name = "buttonLenToMain";
            this.buttonLenToMain.Size = new System.Drawing.Size(287, 26);
            this.buttonLenToMain.Text = "На главный экран";
            this.buttonLenToMain.Click += new System.EventHandler(this.buttonLenToMain_Click);
            // 
            // buttonLenToLast
            // 
            this.buttonLenToLast.Name = "buttonLenToLast";
            this.buttonLenToLast.Size = new System.Drawing.Size(287, 26);
            this.buttonLenToLast.Text = "На предыдущий экран";
            this.buttonLenToLast.Click += new System.EventHandler(this.buttonLenToLast_Click);
            // 
            // buttonLenToClipboard
            // 
            this.buttonLenToClipboard.Name = "buttonLenToClipboard";
            this.buttonLenToClipboard.Size = new System.Drawing.Size(287, 26);
            this.buttonLenToClipboard.Text = "В буфер обмена";
            this.buttonLenToClipboard.Click += new System.EventHandler(this.buttonLenToClipboard_Click);
            // 
            // вЫвестиВКалькуляторToolStripMenuItem
            // 
            this.вЫвестиВКалькуляторToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToCalcA,
            this.buttonToCalcB,
            this.buttonToCalcBuffer,
            this.buttonToCalcHelp});
            this.вЫвестиВКалькуляторToolStripMenuItem.Name = "вЫвестиВКалькуляторToolStripMenuItem";
            this.вЫвестиВКалькуляторToolStripMenuItem.Size = new System.Drawing.Size(286, 26);
            this.вЫвестиВКалькуляторToolStripMenuItem.Text = "Вывести в калькулятор";
            // 
            // buttonToCalcA
            // 
            this.buttonToCalcA.Name = "buttonToCalcA";
            this.buttonToCalcA.Size = new System.Drawing.Size(143, 26);
            this.buttonToCalcA.Text = "A";
            this.buttonToCalcA.Click += new System.EventHandler(this.buttonToCalcA_Click);
            // 
            // buttonToCalcB
            // 
            this.buttonToCalcB.Name = "buttonToCalcB";
            this.buttonToCalcB.Size = new System.Drawing.Size(143, 26);
            this.buttonToCalcB.Text = "B";
            this.buttonToCalcB.Click += new System.EventHandler(this.buttonToCalcB_Click);
            // 
            // buttonToCalcBuffer
            // 
            this.buttonToCalcBuffer.Name = "buttonToCalcBuffer";
            this.buttonToCalcBuffer.Size = new System.Drawing.Size(143, 26);
            this.buttonToCalcBuffer.Text = "Buffer";
            this.buttonToCalcBuffer.Click += new System.EventHandler(this.buttonToCalcBuffer_Click);
            // 
            // buttonToCalcHelp
            // 
            this.buttonToCalcHelp.Name = "buttonToCalcHelp";
            this.buttonToCalcHelp.Size = new System.Drawing.Size(143, 26);
            this.buttonToCalcHelp.Text = "Help";
            this.buttonToCalcHelp.Click += new System.EventHandler(this.buttonToCalcHelp_Click);
            // 
            // buttonLenClear
            // 
            this.buttonLenClear.Name = "buttonLenClear";
            this.buttonLenClear.Size = new System.Drawing.Size(286, 26);
            this.buttonLenClear.Text = "Сбросить";
            this.buttonLenClear.Click += new System.EventHandler(this.buttonLenClear_Click);
            // 
            // textBoxVectorLen
            // 
            this.textBoxVectorLen.AllowNegative = true;
            this.textBoxVectorLen.ClearingByReadonly = false;
            this.textBoxVectorLen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxVectorLen.EnterAllow = true;
            this.textBoxVectorLen.Location = new System.Drawing.Point(171, 75);
            this.textBoxVectorLen.MultiLine = false;
            this.textBoxVectorLen.Name = "textBoxVectorLen";
            this.textBoxVectorLen.NoReadOnly = false;
            this.textBoxVectorLen.ReadOnly = true;
            this.textBoxVectorLen.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxVectorLen.SelectionStart = 0;
            this.textBoxVectorLen.Size = new System.Drawing.Size(342, 67);
            this.textBoxVectorLen.TabIndex = 2;
            this.textBoxVectorLen.TextWithLineBreaks = "";
            this.textBoxVectorLen.Title = "Длина";
            this.textBoxVectorLen.UseSystemPasswordChar = false;
            this.textBoxVectorLen.Value = "";
            this.textBoxVectorLen.ValueBackColor = System.Drawing.Color.White;
            this.textBoxVectorLen.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxVectorLen.ValueText = "";
            this.textBoxVectorLen.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxVectorLen.ValueWithLineBreaks = "";
            this.textBoxVectorLen.VisibleOK = false;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.tableLayoutPanel15);
            this.groupBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox14.Location = new System.Drawing.Point(3, 3);
            this.groupBox14.Name = "groupBox14";
            this.tableLayoutPanel14.SetRowSpan(this.groupBox14, 2);
            this.groupBox14.Size = new System.Drawing.Size(162, 139);
            this.groupBox14.TabIndex = 0;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Рабочий вектор";
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Controls.Add(this.radioButtonVectorAB, 0, 1);
            this.tableLayoutPanel15.Controls.Add(this.radioButtonVectorB, 1, 0);
            this.tableLayoutPanel15.Controls.Add(this.radioButtonVectorA, 0, 0);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(156, 109);
            this.tableLayoutPanel15.TabIndex = 0;
            // 
            // radioButtonVectorAB
            // 
            this.radioButtonVectorAB.AutoSize = true;
            this.tableLayoutPanel15.SetColumnSpan(this.radioButtonVectorAB, 2);
            this.radioButtonVectorAB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonVectorAB.Location = new System.Drawing.Point(3, 57);
            this.radioButtonVectorAB.Name = "radioButtonVectorAB";
            this.radioButtonVectorAB.Size = new System.Drawing.Size(150, 49);
            this.radioButtonVectorAB.TabIndex = 2;
            this.radioButtonVectorAB.Text = "A+B";
            this.radioButtonVectorAB.UseVisualStyleBackColor = true;
            // 
            // radioButtonVectorB
            // 
            this.radioButtonVectorB.AutoSize = true;
            this.radioButtonVectorB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonVectorB.Location = new System.Drawing.Point(81, 3);
            this.radioButtonVectorB.Name = "radioButtonVectorB";
            this.radioButtonVectorB.Size = new System.Drawing.Size(72, 48);
            this.radioButtonVectorB.TabIndex = 1;
            this.radioButtonVectorB.Text = "B";
            this.radioButtonVectorB.UseVisualStyleBackColor = true;
            // 
            // radioButtonVectorA
            // 
            this.radioButtonVectorA.AutoSize = true;
            this.radioButtonVectorA.Checked = true;
            this.radioButtonVectorA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonVectorA.Location = new System.Drawing.Point(3, 3);
            this.radioButtonVectorA.Name = "radioButtonVectorA";
            this.radioButtonVectorA.Size = new System.Drawing.Size(72, 48);
            this.radioButtonVectorA.TabIndex = 0;
            this.radioButtonVectorA.TabStop = true;
            this.radioButtonVectorA.Text = "A";
            this.radioButtonVectorA.UseVisualStyleBackColor = true;
            // 
            // textBoxVectorCoords
            // 
            this.textBoxVectorCoords.AllowNegative = true;
            this.textBoxVectorCoords.ClearingByReadonly = false;
            this.textBoxVectorCoords.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxVectorCoords.EnterAllow = true;
            this.textBoxVectorCoords.Location = new System.Drawing.Point(171, 3);
            this.textBoxVectorCoords.MultiLine = false;
            this.textBoxVectorCoords.Name = "textBoxVectorCoords";
            this.textBoxVectorCoords.NoReadOnly = false;
            this.textBoxVectorCoords.ReadOnly = true;
            this.textBoxVectorCoords.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxVectorCoords.SelectionStart = 0;
            this.textBoxVectorCoords.Size = new System.Drawing.Size(342, 66);
            this.textBoxVectorCoords.TabIndex = 1;
            this.textBoxVectorCoords.TextWithLineBreaks = "";
            this.textBoxVectorCoords.Title = "Координаты";
            this.textBoxVectorCoords.UseSystemPasswordChar = false;
            this.textBoxVectorCoords.Value = "";
            this.textBoxVectorCoords.ValueBackColor = System.Drawing.Color.White;
            this.textBoxVectorCoords.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxVectorCoords.ValueText = "";
            this.textBoxVectorCoords.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxVectorCoords.ValueWithLineBreaks = "";
            this.textBoxVectorCoords.VisibleOK = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.изменениеИВыводToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(516, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(311, 29);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // изменениеИВыводToolStripMenuItem
            // 
            this.изменениеИВыводToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonViewCalc,
            this.вывестиToolStripMenuItem,
            this.buttonCoordsClear});
            this.изменениеИВыводToolStripMenuItem.Name = "изменениеИВыводToolStripMenuItem";
            this.изменениеИВыводToolStripMenuItem.Size = new System.Drawing.Size(193, 25);
            this.изменениеИВыводToolStripMenuItem.Text = "Изменение и вывод";
            // 
            // buttonViewCalc
            // 
            this.buttonViewCalc.Name = "buttonViewCalc";
            this.buttonViewCalc.Size = new System.Drawing.Size(183, 26);
            this.buttonViewCalc.Text = "Вычислить";
            this.buttonViewCalc.Click += new System.EventHandler(this.buttonViewCalc_Click);
            // 
            // вывестиToolStripMenuItem
            // 
            this.вывестиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCoordsToMain,
            this.buttonCoordsToLast,
            this.buttonCoordsToClipboard});
            this.вывестиToolStripMenuItem.Name = "вывестиToolStripMenuItem";
            this.вывестиToolStripMenuItem.Size = new System.Drawing.Size(183, 26);
            this.вывестиToolStripMenuItem.Text = "Вывести";
            // 
            // buttonCoordsToMain
            // 
            this.buttonCoordsToMain.Name = "buttonCoordsToMain";
            this.buttonCoordsToMain.Size = new System.Drawing.Size(287, 26);
            this.buttonCoordsToMain.Text = "На главный экран";
            this.buttonCoordsToMain.Click += new System.EventHandler(this.buttonCoordsToMain_Click);
            // 
            // buttonCoordsToLast
            // 
            this.buttonCoordsToLast.Name = "buttonCoordsToLast";
            this.buttonCoordsToLast.Size = new System.Drawing.Size(287, 26);
            this.buttonCoordsToLast.Text = "На предыдущий экран";
            this.buttonCoordsToLast.Click += new System.EventHandler(this.buttonCoordsToLast_Click);
            // 
            // buttonCoordsToClipboard
            // 
            this.buttonCoordsToClipboard.Name = "buttonCoordsToClipboard";
            this.buttonCoordsToClipboard.Size = new System.Drawing.Size(287, 26);
            this.buttonCoordsToClipboard.Text = "В буфер обмена";
            this.buttonCoordsToClipboard.Click += new System.EventHandler(this.buttonCoordsToClipboard_Click);
            // 
            // buttonCoordsClear
            // 
            this.buttonCoordsClear.Name = "buttonCoordsClear";
            this.buttonCoordsClear.Size = new System.Drawing.Size(183, 26);
            this.buttonCoordsClear.Text = "Сбросить";
            this.buttonCoordsClear.Click += new System.EventHandler(this.buttonCoordsClear_Click);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.tableLayoutPanel17);
            this.groupBox16.Location = new System.Drawing.Point(3, 184);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(833, 172);
            this.groupBox16.TabIndex = 2;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Координаты вектора";
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 3;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.12817F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.39057F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.60218F));
            this.tableLayoutPanel17.Controls.Add(this.menuStrip3, 1, 1);
            this.tableLayoutPanel17.Controls.Add(this.textBoxCoordinate, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.groupBox18, 2, 0);
            this.tableLayoutPanel17.Controls.Add(this.groupBox17, 0, 0);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 2;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(827, 142);
            this.tableLayoutPanel17.TabIndex = 0;
            // 
            // menuStrip3
            // 
            this.menuStrip3.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.ввестиToolStripMenuItem});
            this.menuStrip3.Location = new System.Drawing.Point(182, 71);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(424, 29);
            this.menuStrip3.TabIndex = 4;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.buttonCoordinateClear});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(193, 25);
            this.toolStripMenuItem2.Text = "Изменение и вывод";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(183, 26);
            this.toolStripMenuItem4.Text = "Вычислить";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToMain,
            this.buttonToLast,
            this.buttonToClipBoard,
            this.buttonToCalculator});
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(183, 26);
            this.toolStripMenuItem5.Text = "Вывести";
            // 
            // buttonToMain
            // 
            this.buttonToMain.Name = "buttonToMain";
            this.buttonToMain.Size = new System.Drawing.Size(443, 26);
            this.buttonToMain.Text = "На главный экран";
            this.buttonToMain.Click += new System.EventHandler(this.buttonToMain_Click);
            // 
            // buttonToLast
            // 
            this.buttonToLast.Name = "buttonToLast";
            this.buttonToLast.Size = new System.Drawing.Size(443, 26);
            this.buttonToLast.Text = "На предыдущий экран";
            this.buttonToLast.Click += new System.EventHandler(this.buttonToLast_Click);
            // 
            // buttonToClipBoard
            // 
            this.buttonToClipBoard.Name = "buttonToClipBoard";
            this.buttonToClipBoard.Size = new System.Drawing.Size(443, 26);
            this.buttonToClipBoard.Text = "В буфер обмена";
            this.buttonToClipBoard.Click += new System.EventHandler(this.buttonToClipBoard_Click);
            // 
            // buttonToCalculator
            // 
            this.buttonToCalculator.Name = "buttonToCalculator";
            this.buttonToCalculator.Size = new System.Drawing.Size(443, 26);
            this.buttonToCalculator.Text = "В калькулятор (Значение в калькуляторе)";
            this.buttonToCalculator.Click += new System.EventHandler(this.buttonToCalculator_Click);
            // 
            // buttonCoordinateClear
            // 
            this.buttonCoordinateClear.Name = "buttonCoordinateClear";
            this.buttonCoordinateClear.Size = new System.Drawing.Size(183, 26);
            this.buttonCoordinateClear.Text = "Сбросить";
            this.buttonCoordinateClear.Click += new System.EventHandler(this.buttonCoordinateClear_Click);
            // 
            // ввестиToolStripMenuItem
            // 
            this.ввестиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonFromLast,
            this.buttonFromMain,
            this.buttonFromClipboard,
            this.buttonFromCalculator});
            this.ввестиToolStripMenuItem.Name = "ввестиToolStripMenuItem";
            this.ввестиToolStripMenuItem.Size = new System.Drawing.Size(81, 25);
            this.ввестиToolStripMenuItem.Text = "Ввести";
            // 
            // buttonFromLast
            // 
            this.buttonFromLast.Name = "buttonFromLast";
            this.buttonFromLast.Size = new System.Drawing.Size(463, 26);
            this.buttonFromLast.Text = "С предыдущего экрана";
            this.buttonFromLast.Click += new System.EventHandler(this.buttonFromLast_Click);
            // 
            // buttonFromMain
            // 
            this.buttonFromMain.Name = "buttonFromMain";
            this.buttonFromMain.Size = new System.Drawing.Size(463, 26);
            this.buttonFromMain.Text = "С главного экрана";
            this.buttonFromMain.Click += new System.EventHandler(this.buttonFromMain_Click);
            // 
            // buttonFromClipboard
            // 
            this.buttonFromClipboard.Name = "buttonFromClipboard";
            this.buttonFromClipboard.Size = new System.Drawing.Size(463, 26);
            this.buttonFromClipboard.Text = "Из буфера обмена";
            this.buttonFromClipboard.Click += new System.EventHandler(this.buttonFromClipboard_Click);
            // 
            // buttonFromCalculator
            // 
            this.buttonFromCalculator.Name = "buttonFromCalculator";
            this.buttonFromCalculator.Size = new System.Drawing.Size(463, 26);
            this.buttonFromCalculator.Text = "Из калькулятора (Значение в калькуляторе)";
            this.buttonFromCalculator.Click += new System.EventHandler(this.buttonFromCalculator_Click);
            // 
            // textBoxCoordinate
            // 
            this.textBoxCoordinate.AllowNegative = true;
            this.textBoxCoordinate.ClearingByReadonly = false;
            this.textBoxCoordinate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxCoordinate.EnterAllow = true;
            this.textBoxCoordinate.Location = new System.Drawing.Point(185, 3);
            this.textBoxCoordinate.MultiLine = false;
            this.textBoxCoordinate.Name = "textBoxCoordinate";
            this.textBoxCoordinate.NoReadOnly = false;
            this.textBoxCoordinate.ReadOnly = true;
            this.textBoxCoordinate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxCoordinate.SelectionStart = 0;
            this.textBoxCoordinate.Size = new System.Drawing.Size(418, 65);
            this.textBoxCoordinate.TabIndex = 2;
            this.textBoxCoordinate.TextWithLineBreaks = "";
            this.textBoxCoordinate.Title = "Координаты";
            this.textBoxCoordinate.UseSystemPasswordChar = false;
            this.textBoxCoordinate.Value = "";
            this.textBoxCoordinate.ValueBackColor = System.Drawing.Color.White;
            this.textBoxCoordinate.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxCoordinate.ValueText = "";
            this.textBoxCoordinate.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxCoordinate.ValueWithLineBreaks = "";
            this.textBoxCoordinate.VisibleOK = false;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.tableLayoutPanel19);
            this.groupBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox18.Location = new System.Drawing.Point(609, 3);
            this.groupBox18.Name = "groupBox18";
            this.tableLayoutPanel17.SetRowSpan(this.groupBox18, 2);
            this.groupBox18.Size = new System.Drawing.Size(215, 136);
            this.groupBox18.TabIndex = 1;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Значение в калькуляторе";
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 2;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel19.Controls.Add(this.radioButtonCalcHelp, 1, 1);
            this.tableLayoutPanel19.Controls.Add(this.radioButtonCalcBuffer, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.radioButtonCalcA, 1, 0);
            this.tableLayoutPanel19.Controls.Add(this.radioButtonCalcB, 0, 0);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(209, 106);
            this.tableLayoutPanel19.TabIndex = 0;
            // 
            // radioButtonCalcHelp
            // 
            this.radioButtonCalcHelp.AutoSize = true;
            this.radioButtonCalcHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonCalcHelp.Location = new System.Drawing.Point(107, 56);
            this.radioButtonCalcHelp.Name = "radioButtonCalcHelp";
            this.radioButtonCalcHelp.Size = new System.Drawing.Size(99, 47);
            this.radioButtonCalcHelp.TabIndex = 3;
            this.radioButtonCalcHelp.Text = "Help";
            this.radioButtonCalcHelp.UseVisualStyleBackColor = true;
            // 
            // radioButtonCalcBuffer
            // 
            this.radioButtonCalcBuffer.AutoSize = true;
            this.radioButtonCalcBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonCalcBuffer.Location = new System.Drawing.Point(3, 56);
            this.radioButtonCalcBuffer.Name = "radioButtonCalcBuffer";
            this.radioButtonCalcBuffer.Size = new System.Drawing.Size(98, 47);
            this.radioButtonCalcBuffer.TabIndex = 2;
            this.radioButtonCalcBuffer.Text = "Buffer";
            this.radioButtonCalcBuffer.UseVisualStyleBackColor = true;
            // 
            // radioButtonCalcA
            // 
            this.radioButtonCalcA.AutoSize = true;
            this.radioButtonCalcA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonCalcA.Location = new System.Drawing.Point(107, 3);
            this.radioButtonCalcA.Name = "radioButtonCalcA";
            this.radioButtonCalcA.Size = new System.Drawing.Size(99, 47);
            this.radioButtonCalcA.TabIndex = 1;
            this.radioButtonCalcA.Text = "A";
            this.radioButtonCalcA.UseVisualStyleBackColor = true;
            // 
            // radioButtonCalcB
            // 
            this.radioButtonCalcB.AutoSize = true;
            this.radioButtonCalcB.Checked = true;
            this.radioButtonCalcB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonCalcB.Location = new System.Drawing.Point(3, 3);
            this.radioButtonCalcB.Name = "radioButtonCalcB";
            this.radioButtonCalcB.Size = new System.Drawing.Size(98, 47);
            this.radioButtonCalcB.TabIndex = 0;
            this.radioButtonCalcB.TabStop = true;
            this.radioButtonCalcB.Text = "B";
            this.radioButtonCalcB.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.tableLayoutPanel18);
            this.groupBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox17.Location = new System.Drawing.Point(3, 3);
            this.groupBox17.Name = "groupBox17";
            this.tableLayoutPanel17.SetRowSpan(this.groupBox17, 2);
            this.groupBox17.Size = new System.Drawing.Size(176, 136);
            this.groupBox17.TabIndex = 0;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Рабочая координата";
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Controls.Add(this.radioButtonZ, 0, 1);
            this.tableLayoutPanel18.Controls.Add(this.radioButtonY, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.radioButtonX, 0, 0);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 2;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(170, 106);
            this.tableLayoutPanel18.TabIndex = 0;
            // 
            // radioButtonZ
            // 
            this.radioButtonZ.AutoSize = true;
            this.radioButtonZ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonZ.Location = new System.Drawing.Point(3, 56);
            this.radioButtonZ.Name = "radioButtonZ";
            this.radioButtonZ.Size = new System.Drawing.Size(79, 47);
            this.radioButtonZ.TabIndex = 2;
            this.radioButtonZ.Text = "Z";
            this.radioButtonZ.UseVisualStyleBackColor = true;
            // 
            // radioButtonY
            // 
            this.radioButtonY.AutoSize = true;
            this.radioButtonY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonY.Location = new System.Drawing.Point(88, 3);
            this.radioButtonY.Name = "radioButtonY";
            this.radioButtonY.Size = new System.Drawing.Size(79, 47);
            this.radioButtonY.TabIndex = 1;
            this.radioButtonY.Text = "Y";
            this.radioButtonY.UseVisualStyleBackColor = true;
            // 
            // radioButtonX
            // 
            this.radioButtonX.AutoSize = true;
            this.radioButtonX.Checked = true;
            this.radioButtonX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonX.Location = new System.Drawing.Point(3, 3);
            this.radioButtonX.Name = "radioButtonX";
            this.radioButtonX.Size = new System.Drawing.Size(79, 47);
            this.radioButtonX.TabIndex = 0;
            this.radioButtonX.TabStop = true;
            this.radioButtonX.Text = "X";
            this.radioButtonX.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.tableLayoutPanel16);
            this.groupBox15.Location = new System.Drawing.Point(3, 362);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(833, 170);
            this.groupBox15.TabIndex = 1;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Данные в калькуляторе";
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Controls.Add(this.textBoxHelp, 1, 1);
            this.tableLayoutPanel16.Controls.Add(this.textBoxBuffer, 0, 1);
            this.tableLayoutPanel16.Controls.Add(this.textBoxA, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.textBoxB, 0, 0);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(827, 140);
            this.tableLayoutPanel16.TabIndex = 0;
            // 
            // textBoxHelp
            // 
            this.textBoxHelp.AllowNegative = true;
            this.textBoxHelp.ClearingByReadonly = false;
            this.textBoxHelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxHelp.EnterAllow = true;
            this.textBoxHelp.Location = new System.Drawing.Point(416, 73);
            this.textBoxHelp.MultiLine = false;
            this.textBoxHelp.Name = "textBoxHelp";
            this.textBoxHelp.NoReadOnly = false;
            this.textBoxHelp.ReadOnly = true;
            this.textBoxHelp.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxHelp.SelectionStart = 0;
            this.textBoxHelp.Size = new System.Drawing.Size(408, 64);
            this.textBoxHelp.TabIndex = 3;
            this.textBoxHelp.TextWithLineBreaks = "";
            this.textBoxHelp.Title = "Help";
            this.textBoxHelp.UseSystemPasswordChar = false;
            this.textBoxHelp.Value = "";
            this.textBoxHelp.ValueBackColor = System.Drawing.Color.White;
            this.textBoxHelp.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxHelp.ValueText = "";
            this.textBoxHelp.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxHelp.ValueWithLineBreaks = "";
            this.textBoxHelp.VisibleOK = false;
            // 
            // textBoxBuffer
            // 
            this.textBoxBuffer.AllowNegative = true;
            this.textBoxBuffer.ClearingByReadonly = false;
            this.textBoxBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxBuffer.EnterAllow = true;
            this.textBoxBuffer.Location = new System.Drawing.Point(3, 73);
            this.textBoxBuffer.MultiLine = false;
            this.textBoxBuffer.Name = "textBoxBuffer";
            this.textBoxBuffer.NoReadOnly = false;
            this.textBoxBuffer.ReadOnly = true;
            this.textBoxBuffer.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxBuffer.SelectionStart = 0;
            this.textBoxBuffer.Size = new System.Drawing.Size(407, 64);
            this.textBoxBuffer.TabIndex = 2;
            this.textBoxBuffer.TextWithLineBreaks = "";
            this.textBoxBuffer.Title = "Buffer";
            this.textBoxBuffer.UseSystemPasswordChar = false;
            this.textBoxBuffer.Value = "";
            this.textBoxBuffer.ValueBackColor = System.Drawing.Color.White;
            this.textBoxBuffer.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxBuffer.ValueText = "";
            this.textBoxBuffer.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxBuffer.ValueWithLineBreaks = "";
            this.textBoxBuffer.VisibleOK = false;
            // 
            // textBoxA
            // 
            this.textBoxA.AllowNegative = true;
            this.textBoxA.ClearingByReadonly = false;
            this.textBoxA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxA.EnterAllow = true;
            this.textBoxA.Location = new System.Drawing.Point(416, 3);
            this.textBoxA.MultiLine = false;
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.NoReadOnly = false;
            this.textBoxA.ReadOnly = true;
            this.textBoxA.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxA.SelectionStart = 0;
            this.textBoxA.Size = new System.Drawing.Size(408, 64);
            this.textBoxA.TabIndex = 1;
            this.textBoxA.TextWithLineBreaks = "";
            this.textBoxA.Title = "A";
            this.textBoxA.UseSystemPasswordChar = false;
            this.textBoxA.Value = "";
            this.textBoxA.ValueBackColor = System.Drawing.Color.White;
            this.textBoxA.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxA.ValueText = "";
            this.textBoxA.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxA.ValueWithLineBreaks = "";
            this.textBoxA.VisibleOK = false;
            // 
            // textBoxB
            // 
            this.textBoxB.AllowNegative = true;
            this.textBoxB.ClearingByReadonly = false;
            this.textBoxB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxB.EnterAllow = true;
            this.textBoxB.Location = new System.Drawing.Point(3, 3);
            this.textBoxB.MultiLine = false;
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.NoReadOnly = false;
            this.textBoxB.ReadOnly = true;
            this.textBoxB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxB.SelectionStart = 0;
            this.textBoxB.Size = new System.Drawing.Size(407, 64);
            this.textBoxB.TabIndex = 0;
            this.textBoxB.TextWithLineBreaks = "";
            this.textBoxB.Title = "B";
            this.textBoxB.UseSystemPasswordChar = false;
            this.textBoxB.Value = "";
            this.textBoxB.ValueBackColor = System.Drawing.Color.White;
            this.textBoxB.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxB.ValueText = "";
            this.textBoxB.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxB.ValueWithLineBreaks = "";
            this.textBoxB.VisibleOK = false;
            // 
            // textBoxSumView
            // 
            this.textBoxSumView.AllowNegative = true;
            this.textBoxSumView.ClearingByReadonly = false;
            this.textBoxSumView.EnterAllow = true;
            this.textBoxSumView.Location = new System.Drawing.Point(3, 538);
            this.textBoxSumView.MultiLine = false;
            this.textBoxSumView.Name = "textBoxSumView";
            this.textBoxSumView.NoReadOnly = false;
            this.textBoxSumView.ReadOnly = true;
            this.textBoxSumView.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxSumView.SelectionStart = 0;
            this.textBoxSumView.Size = new System.Drawing.Size(833, 81);
            this.textBoxSumView.TabIndex = 4;
            this.textBoxSumView.TextWithLineBreaks = "";
            this.textBoxSumView.Title = "Отображение суммы";
            this.textBoxSumView.UseSystemPasswordChar = false;
            this.textBoxSumView.Value = "";
            this.textBoxSumView.ValueBackColor = System.Drawing.Color.White;
            this.textBoxSumView.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxSumView.ValueText = "";
            this.textBoxSumView.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxSumView.ValueWithLineBreaks = "";
            this.textBoxSumView.VisibleOK = false;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.tableLayoutPanel20);
            this.groupBox19.Location = new System.Drawing.Point(3, 625);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(833, 100);
            this.groupBox19.TabIndex = 3;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Вывод выражения (Векторной суммы)";
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 3;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.71985F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.96346F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.19489F));
            this.tableLayoutPanel20.Controls.Add(this.groupBox21, 2, 0);
            this.tableLayoutPanel20.Controls.Add(this.groupBox20, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.buttonSumOutput, 0, 0);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 1;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(827, 70);
            this.tableLayoutPanel20.TabIndex = 0;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.comboBoxOutputPlace);
            this.groupBox21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox21.Location = new System.Drawing.Point(497, 3);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(327, 64);
            this.groupBox21.TabIndex = 1;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Куда";
            // 
            // comboBoxOutputPlace
            // 
            this.comboBoxOutputPlace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxOutputPlace.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxOutputPlace.FormattingEnabled = true;
            this.comboBoxOutputPlace.Items.AddRange(new object[] {
            "На предыдущий экран",
            "На главный экран",
            "В буфер обмена"});
            this.comboBoxOutputPlace.Location = new System.Drawing.Point(3, 27);
            this.comboBoxOutputPlace.Name = "comboBoxOutputPlace";
            this.comboBoxOutputPlace.Size = new System.Drawing.Size(321, 26);
            this.comboBoxOutputPlace.TabIndex = 0;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.comboBoxOutputView);
            this.groupBox20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox20.Location = new System.Drawing.Point(249, 3);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(242, 64);
            this.groupBox20.TabIndex = 0;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Расположение результата";
            // 
            // comboBoxOutputView
            // 
            this.comboBoxOutputView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxOutputView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxOutputView.FormattingEnabled = true;
            this.comboBoxOutputView.Items.AddRange(new object[] {
            "Справа",
            "Слева"});
            this.comboBoxOutputView.Location = new System.Drawing.Point(3, 27);
            this.comboBoxOutputView.Name = "comboBoxOutputView";
            this.comboBoxOutputView.Size = new System.Drawing.Size(236, 26);
            this.comboBoxOutputView.TabIndex = 0;
            // 
            // buttonSumOutput
            // 
            this.buttonSumOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSumOutput.Location = new System.Drawing.Point(3, 3);
            this.buttonSumOutput.Name = "buttonSumOutput";
            this.buttonSumOutput.Size = new System.Drawing.Size(240, 64);
            this.buttonSumOutput.TabIndex = 2;
            this.buttonSumOutput.Text = "Вывести";
            this.buttonSumOutput.UseVisualStyleBackColor = true;
            this.buttonSumOutput.Click += new System.EventHandler(this.buttonSumOutput_Click);
            // 
            // timerVectorSumView
            // 
            this.timerVectorSumView.Enabled = true;
            this.timerVectorSumView.Tick += new System.EventHandler(this.timerVectorSumView_Tick);
            // 
            // VectorCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(882, 553);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(770, 570);
            this.Name = "VectorCalculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Векторный калькулятор";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pattern_FormClosed);
            this.Load += new System.EventHandler(this.Pattern_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.flowResize1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.textBoxViewAB1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.menuStrip4.ResumeLayout(false);
            this.menuStrip4.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel21.PerformLayout();
            this.menuStrip5.ResumeLayout(false);
            this.menuStrip5.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.flowResize2.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel18.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private FlowResize flowResize1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private TextBoxWithTitle textBoxAX;
        private TextBoxWithTitle textBoxAZ;
        private TextBoxWithTitle textBoxAY;
        private System.Windows.Forms.Button buttonClearA;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private TextBoxWithTitle textBoxABZ;
        private TextBoxWithTitle textBoxABY;
        private TextBoxWithTitle textBoxABX;
        private System.Windows.Forms.Button buttonClearAB;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private TextBoxWithTitle textBoxBZ;
        private TextBoxWithTitle textBoxBY;
        private TextBoxWithTitle textBoxBX;
        private System.Windows.Forms.Button buttonClearB;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private TextBoxWithTitle textBoxViewA;
        private System.Windows.Forms.Button buttonViewA;
        private System.Windows.Forms.Button buttonCalsAZ;
        private System.Windows.Forms.Button buttonCalsAY;
        private System.Windows.Forms.Button buttonCalsAX;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private TextBoxWithTitle textBoxLenA;
        private System.Windows.Forms.Button buttonLenA;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private TextBoxWithTitle textBoxLenAB;
        private System.Windows.Forms.Button buttonLenAB;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TableLayoutPanel textBoxViewAB1;
        private TextBoxWithTitle textBoxViewAB;
        private System.Windows.Forms.Button buttonViewAB;
        private System.Windows.Forms.Button buttonCalsABZ;
        private System.Windows.Forms.Button buttonCalsABY;
        private System.Windows.Forms.Button buttonCalsABX;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private TextBoxWithTitle textBoxLenB;
        private System.Windows.Forms.Button buttonLenB;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private TextBoxWithTitle textBoxViewB;
        private System.Windows.Forms.Button buttonViewB;
        private System.Windows.Forms.Button buttonCalsBZ;
        private System.Windows.Forms.Button buttonCalsBY;
        private System.Windows.Forms.Button buttonCalsBX;
        private FlowResize flowResize2;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Timer timerVectorSumView;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.RadioButton radioButtonVectorA;
        private System.Windows.Forms.RadioButton radioButtonVectorB;
        private System.Windows.Forms.RadioButton radioButtonVectorAB;
        private TextBoxWithTitle textBoxVectorCoords;
        private TextBoxWithTitle textBoxVectorLen;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem изменениеИВыводToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonViewCalc;
        private System.Windows.Forms.ToolStripMenuItem вывестиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonCoordsToMain;
        private System.Windows.Forms.ToolStripMenuItem buttonCoordsToLast;
        private System.Windows.Forms.ToolStripMenuItem buttonCoordsToClipboard;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonCalcLen;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem buttonLenToMain;
        private System.Windows.Forms.ToolStripMenuItem buttonLenToLast;
        private System.Windows.Forms.ToolStripMenuItem buttonLenToClipboard;
        private System.Windows.Forms.ToolStripMenuItem вЫвестиВКалькуляторToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToCalcA;
        private System.Windows.Forms.ToolStripMenuItem buttonToCalcB;
        private System.Windows.Forms.ToolStripMenuItem buttonToCalcBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonToCalcHelp;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private TextBoxWithTitle textBoxB;
        private TextBoxWithTitle textBoxHelp;
        private TextBoxWithTitle textBoxBuffer;
        private TextBoxWithTitle textBoxA;
        private System.Windows.Forms.ToolStripMenuItem buttonCoordsClear;
        private System.Windows.Forms.ToolStripMenuItem buttonLenClear;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.RadioButton radioButtonX;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.RadioButton radioButtonCalcHelp;
        private System.Windows.Forms.RadioButton radioButtonCalcBuffer;
        private System.Windows.Forms.RadioButton radioButtonCalcA;
        private System.Windows.Forms.RadioButton radioButtonCalcB;
        private System.Windows.Forms.RadioButton radioButtonZ;
        private System.Windows.Forms.RadioButton radioButtonY;
        private TextBoxWithTitle textBoxCoordinate;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem buttonToMain;
        private System.Windows.Forms.ToolStripMenuItem buttonToLast;
        private System.Windows.Forms.ToolStripMenuItem buttonToClipBoard;
        private System.Windows.Forms.ToolStripMenuItem buttonCoordinateClear;
        private System.Windows.Forms.ToolStripMenuItem buttonToCalculator;
        private System.Windows.Forms.ToolStripMenuItem ввестиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonFromLast;
        private System.Windows.Forms.ToolStripMenuItem buttonFromMain;
        private System.Windows.Forms.ToolStripMenuItem buttonFromClipboard;
        private System.Windows.Forms.ToolStripMenuItem buttonFromCalculator;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.ComboBox comboBoxOutputView;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.ComboBox comboBoxOutputPlace;
        private System.Windows.Forms.Button buttonSumOutput;
        private TextBoxWithTitle textBoxSumView;
        private System.Windows.Forms.MenuStrip menuStrip4;
        private System.Windows.Forms.ToolStripMenuItem вычислитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddAB;
        private System.Windows.Forms.ToolStripMenuItem buttonSubAB;
        private System.Windows.Forms.ToolStripMenuItem buttonVectorMullAB;
        private System.Windows.Forms.ToolStripMenuItem buttonCoordsMullVector;
        private System.Windows.Forms.ToolStripMenuItem buttonDivCoordsAB;
        private System.Windows.Forms.GroupBox groupBox22;
        private TextBoxWithTitle textBoxScalarAB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Button buttonScalarAB;
        private System.Windows.Forms.MenuStrip menuStrip5;
        private System.Windows.Forms.ToolStripMenuItem длинаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyLenA;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyLenB;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyLenAB;
        private System.Windows.Forms.ToolStripMenuItem умножитьНаЧислоToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonMullNA;
        private System.Windows.Forms.ToolStripMenuItem buttonMullNB;
        private System.Windows.Forms.ToolStripMenuItem buttonMullNAB;
        private System.Windows.Forms.Button buttonRet;
    }
}