﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    

   

    public partial class VectorCalculator : Form
    {
        public event Func<double> GetA, GetB, GetBuffer, GetHelp;
        public event Action<double> SetA, SetB, SetBuffer, SetHelp;
        public event Func<string> GetFormuleB, GetFormuleHelp;
        public event Action<string> SetFormuleB, SetFormuleHelp;


        public event Func<string> SetFromMain;

        SecondDelta SecondDelta;

        public event TimerOutput MetrOutput; 
        public event TimerOutput1 MetrOutput1;

        public event Func<string> SetNumberFromMain;

        public string SetNumberFromMainInvoke()
        {
            return SetNumberFromMain?.Invoke()??"";
        }


        public VectorCalculator()
        {
            InitializeComponent();
            SecondDelta = new SecondDelta();

            save = Save.None;

            Icon = Properties.Resources.AisTable1;

        }

        Save save;

        public Save Save
        {
            get => save; set => save = value;
        }

        public VectorCalculator(Save save):this()
        {
            Save = save;
        }

        public VectorCalculator(Form form) : this()
        {
            Load += (s, e) => form.Hide();
            FormClosing += (s, e) => form.Show();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            
            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();


            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Pattern_Load(object sender, EventArgs e)
        {
            labelName.Text = Text;
            Text += " - " + MainForm.AppName();

            comboBoxOutputView.SelectedIndex = 0;
            comboBoxOutputPlace.SelectedIndex = 0;
        }

        private void Pattern_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void buttonClearA_Click(object sender, EventArgs e)
        {
            textBoxAX.Clear();
            textBoxAY.Clear();
            textBoxAZ.Clear();
        }

        private void buttonClearB_Click(object sender, EventArgs e)
        {
            textBoxBX.Clear();
            textBoxBY.Clear();
            textBoxBZ.Clear();
        }

        private void buttonClearAB_Click(object sender, EventArgs e)
        {
            textBoxABX.Clear();
            textBoxABY.Clear();
            textBoxABZ.Clear();
        }

        private void buttonAddAB_Click(object sender, EventArgs e)
        {
            try
            {
                double aX = Calculate(textBoxAX.Value);
                double aY = Calculate(textBoxAY.Value);
                double aZ = Calculate(textBoxAZ.Value);

                double bX = Calculate(textBoxBX.Value);
                double bY = Calculate(textBoxBY.Value);
                double bZ = Calculate(textBoxBZ.Value);

                Vector vectorA = new Vector(aX, aY, aZ);
                Vector vectorB = new Vector(bX, bY, bZ);

                Vector vectorAB = vectorA+vectorB;

                textBoxABX.Value = vectorAB.X.ToString();
                textBoxABY.Value = vectorAB.Y.ToString();
                textBoxABZ.Value = vectorAB.Z.ToString();
            }
            catch { }
        }

        string FormuleB
        {
            get
            {
                try
                {
                    return GetFormuleB?.Invoke();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {
                try
                {
                    SetFormuleB?.Invoke(value);
                }
                catch { }
            }
        }

        string FormuleHelp
        {
            get
            {
                try
                {
                    return GetFormuleHelp?.Invoke();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {
                try
                {
                    SetFormuleHelp?.Invoke(value);
                }
                catch { }
            }
        }

        string B
        {
            get
            {
                try
                {
                    return (GetB?.Invoke()??0).ToString();
                }
                catch { 
                    return 0.ToString();
                }

            }
            set
            {
                try
                {
                    SetB?.Invoke(double.Parse(value));
                }
                catch { }
            }
        }

        string A
        {
            get
            {
                try
                {
                    return (GetA?.Invoke() ?? 0).ToString();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {
                try
                {
                    SetA?.Invoke(double.Parse(value));
                }
                catch { }
            }
        }

        string Buffer
        {
            get
            {
                try
                {
                    return (GetBuffer?.Invoke() ?? 0).ToString();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {
                try
                {
                    SetBuffer?.Invoke(double.Parse(value));
                }
                catch { }
            }
        }

        string Help
        {
            get
            {
                try
                {
                    return (GetHelp?.Invoke() ?? 0).ToString();
                }
                catch
                {
                    return 0.ToString();
                }

            }
            set
            {
                try
                {
                    SetHelp?.Invoke(double.Parse(value));
                }
                catch { }
            }
        }


        double Calculate(string formule)
        {
            try
            {
                try
                {
                    return double.Parse(formule.Replace('.', ','));
                }
                catch
                {
                    try
                    {
                        return double.Parse(formule.Replace(',', '.'));
                    }
                    catch
                    {
                        return MyCalculate.CalculateWithB(formule, A, Buffer, Help, B);
                    }
                }
            }
            catch
            {
                return 0.0;
            }
        }

        string VectorView(string x, string y, string z)
        {
            try
            {
                double aX = Calculate(x);
                double aY = Calculate(y);
                double aZ = Calculate(z);
                Vector a = new Vector(aX, aY, aZ);
                return a.ToString();
            }
            catch
            {
                return "";
            }
        }

        double VectorLen(string x, string y, string z)
        {
            try
            {
                double aX = Calculate(x);
                double aY = Calculate(y);
                double aZ = Calculate(z);
                Vector a = new Vector(aX, aY, aZ);
                return a.Length();
            }
            catch
            {
                return 0;
            }
        }

        private void buttonViewA_Click(object sender, EventArgs e)
        {
            textBoxViewA.Value = VectorView(textBoxAX.Value, textBoxAY.Value, textBoxAZ.Value);
        }

        private void buttonViewB_Click(object sender, EventArgs e)
        {
            textBoxViewB.Value = VectorView(textBoxBX.Value, textBoxBY.Value, textBoxBZ.Value);
        }

        private void buttonViewAB_Click(object sender, EventArgs e)
        {
            textBoxViewAB.Value = VectorView(textBoxABX.Value, textBoxABY.Value, textBoxABZ.Value);
        }

        private void buttonLenA_Click(object sender, EventArgs e)
        {
            textBoxLenA.Value = VectorLen(textBoxAX.Value, textBoxAY.Value, textBoxAZ.Value).ToString();
        }

        private void buttonLenB_Click(object sender, EventArgs e)
        {
            textBoxLenB.Value = VectorLen(textBoxBX.Value, textBoxBY.Value, textBoxBZ.Value).ToString();
        }

        private void buttonLenAB_Click(object sender, EventArgs e)
        {
            textBoxLenAB.Value = VectorLen(textBoxABX.Value, textBoxABY.Value, textBoxABZ.Value).ToString();
        }

        private void buttonCalsAX_Click(object sender, EventArgs e)
        {
            textBoxAX.Value = Calculate(textBoxAX.Value).ToString();
        }

        private void buttonCalsAY_Click(object sender, EventArgs e)
        {
            textBoxAY.Value = Calculate(textBoxAY.Value).ToString();
        }

        private void buttonCalsAZ_Click(object sender, EventArgs e)
        {
            textBoxAZ.Value = Calculate(textBoxAZ.Value).ToString();
        }

        private void timerVectorSumView_Tick(object sender, EventArgs e)
        {
            try
            {
                textBoxVectorCoords.Value = VectorCoords.Value;
                textBoxVectorLen.Value = VectorLength.Value;
                textBoxCoordinate.Value = Coordinate.Value;
            }
            catch { }

            try
            {
                textBoxB.Value = FormuleB;
                textBoxA.Value = A.ToString();
                textBoxBuffer.Value = Buffer.ToString();
                textBoxHelp.Value = FormuleHelp;
            }
            catch { }

            try
            {
                if (comboBoxOutputView.SelectedIndex == 0)
                    textBoxSumView.Value = textBoxViewA.Value + " + " + textBoxViewB.Value + " = " + textBoxViewAB.Value;
                else
                    textBoxSumView.Value = textBoxViewAB.Value + " = " + textBoxViewA.Value + " + " + textBoxViewB.Value;
            }
            catch { }
        }

        TextBoxWithTitle Coordinate
        {
            get
            {
                if(radioButtonVectorA.Checked)
                {
                    if(radioButtonX.Checked)
                    {
                        return textBoxAX;
                    }
                    if (radioButtonY.Checked)
                    {
                        return textBoxAY;
                    }
                    else
                    {
                        return textBoxAZ;
                    }
                }
                else if (radioButtonVectorB.Checked)
                {
                    if (radioButtonX.Checked)
                    {
                        return textBoxBX;
                    }
                    if (radioButtonY.Checked)
                    {
                        return textBoxBY;
                    }
                    else
                    {
                        return textBoxBZ;
                    }
                }
                else
                {
                    if (radioButtonX.Checked)
                    {
                        return textBoxABX;
                    }
                    if (radioButtonY.Checked)
                    {
                        return textBoxABY;
                    }
                    else
                    {
                        return textBoxABZ;
                    }
                }
            }
        }

        private void buttonViewCalc_Click(object sender, EventArgs e)
        {
            try
            {
                if(radioButtonVectorA.Checked)
                {
                    buttonViewA_Click(sender, e);
                }
                else
                if (radioButtonVectorB.Checked)
                {
                    buttonViewB_Click(sender, e);
                }
                else
                if (radioButtonVectorAB.Checked)
                {
                    buttonViewAB_Click(sender, e);
                }
            }
            catch { }
        }

        private void buttonCalcLen_Click(object sender, EventArgs e)
        {
            if (radioButtonVectorA.Checked)
            {
                buttonLenA_Click(sender, e);
            }
            else
                if (radioButtonVectorB.Checked)
            {
                buttonLenB_Click(sender, e);
            }
            else
                if (radioButtonVectorAB.Checked)
            {
                buttonLenAB_Click(sender, e);
            }
        }

        private void buttonCalsBX_Click(object sender, EventArgs e)
        {
            textBoxBX.Value = Calculate(textBoxBX.Value).ToString();
        }

        private void buttonCalsABX_Click(object sender, EventArgs e)
        {
            textBoxABX.Value = Calculate(textBoxABX.Value).ToString();
        }

        private void buttonCalsBY_Click(object sender, EventArgs e)
        {
            textBoxBY.Value = Calculate(textBoxBY.Value).ToString();
        }

        private void buttonCalsABY_Click(object sender, EventArgs e)
        {
            textBoxABY.Value = Calculate(textBoxABY.Value).ToString();
        }

        private void buttonCalsBZ_Click(object sender, EventArgs e)
        {
            textBoxBZ.Value = Calculate(textBoxBZ.Value).ToString();
        }

        private void buttonCalsABZ_Click(object sender, EventArgs e)
        {
            textBoxABZ.Value = Calculate(textBoxABZ.Value).ToString();
        }

        private void buttonCoordsToMain_Click(object sender, EventArgs e)
        {
            try
            {
                WriteMain(textBoxVectorCoords.Value);
            }
            catch { }
        }

        private void buttonCoordsToLast_Click(object sender, EventArgs e)
        {

            try
            {
                SaveV(textBoxVectorCoords.Value);
            }
            catch { }
        }

        private void buttonCoordsToClipboard_Click(object sender, EventArgs e)
        {

            try
            {
                WriteToClipboard(textBoxVectorCoords.Value);
            }
            catch { }
        }

        private void buttonLenToMain_Click(object sender, EventArgs e)
        {
            try
            {
                WriteMain(textBoxVectorLen.Value);
            }
            catch { }
        }

        private void buttonToCalcA_Click(object sender, EventArgs e)
        {
            try
            {
                SetA?.Invoke(double.Parse(textBoxVectorLen.Value));
            }
            catch { }
        }

        private void buttonToCalcB_Click(object sender, EventArgs e)
        {
            try
            {
                SetB?.Invoke(double.Parse(textBoxVectorLen.Value));
            }
            catch { }
        }

        private void buttonToCalcBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                SetBuffer?.Invoke(double.Parse(textBoxVectorLen.Value));
            }
            catch { }
        }

        private void buttonToCalcHelp_Click(object sender, EventArgs e)
        {
            try
            {
                SetHelp?.Invoke(double.Parse(textBoxVectorLen.Value));
            }
            catch { }
        }

        private void buttonCoordsClear_Click(object sender, EventArgs e)
        {
            
        }

        TextBoxWithTitle VectorCoords
        {
            get
            {
                if(radioButtonVectorA.Checked)
                {
                    return textBoxViewA;
                }
                else if(radioButtonVectorB.Checked)
                {
                    return textBoxViewB;
                }
                else
                {
                    return textBoxViewAB;
                }
            }
        }

        TextBoxWithTitle VectorLength
        {
            get
            {
                if (radioButtonVectorA.Checked)
                {
                    return textBoxLenA;
                }
                else if (radioButtonVectorB.Checked)
                {
                    return textBoxLenB;
                }
                else
                {
                    return textBoxLenAB;
                }
            }
        }

        private void buttonLenClear_Click(object sender, EventArgs e)
        {
            try
            {
                VectorLength.Clear();
            }
            catch { }
        }

        private void buttonCoordinateClear_Click(object sender, EventArgs e)
        {
            try
            {
                Coordinate.Clear();
            }
            catch { }
        }

        private void buttonToMain_Click(object sender, EventArgs e)
        {
            try
            {
                WriteMain(textBoxCoordinate.Value);
            }
            catch { }
        }

        private void buttonToLast_Click(object sender, EventArgs e)
        {
            try
            {
                SaveV(textBoxCoordinate.Value);
            }
            catch { }
        }

        private void buttonToClipBoard_Click(object sender, EventArgs e)
        {
            try
            {
                WriteToClipboard(textBoxCoordinate.Value);
            }
            catch { }
        }

        private void buttonToCalculator_Click(object sender, EventArgs e)
        {
            try
            {
                if(radioButtonCalcB.Checked)
                {
                    FormuleB = Coordinate.Value;

                }
                else if(radioButtonCalcA.Checked)
                {
                    A = Coordinate.Value;
                }
                else if(radioButtonCalcBuffer.Checked)
                {
                    Buffer = Coordinate.Value;
                }
                else
                {
                    FormuleHelp = Coordinate.Value;
                }
            }
            catch { }
        }

        private void buttonFromLast_Click(object sender, EventArgs e)
        {
            try
            {
                Coordinate.Value = FromLast();
            }
            catch { }
        }

        private void buttonFromMain_Click(object sender, EventArgs e)
        {
            try
            {
                Coordinate.Value = FromMain();
            }
            catch { }
        }

        private void buttonFromClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                Coordinate.Value = FromClipboard();
            }
            catch { }
        }

        private void buttonFromCalculator_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonCalcB.Checked)
                {
                    Coordinate.Value = FormuleB;

                }
                else if (radioButtonCalcA.Checked)
                {
                    Coordinate.Value = A;
                }
                else if (radioButtonCalcBuffer.Checked)
                {
                    Coordinate.Value = Buffer;
                }
                else
                {
                    Coordinate.Value = FormuleHelp;
                }
            }
            catch { }
        }

        private void buttonSumOutput_Click(object sender, EventArgs e)
        {
            string formule = "";
            int index = comboBoxOutputView.SelectedIndex;
            switch(index)
                {
                case 0: formule = textBoxViewA.Value + " + " + textBoxViewB.Value + " = " + textBoxViewAB.Value; break;
                case 1: formule = textBoxViewAB.Value + " = " + textBoxViewA.Value + " + " + textBoxViewB.Value; break;
            }
            index = comboBoxOutputPlace.SelectedIndex;
            switch (index)
            {
                case 0: SaveV(formule); break;
                case 1: WriteMain(formule); break;
                case 2: WriteToClipboard(formule); break;
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void buttonSubAB_Click(object sender, EventArgs e)
        {
            try
            {
                double aX = Calculate(textBoxAX.Value);
                double aY = Calculate(textBoxAY.Value);
                double aZ = Calculate(textBoxAZ.Value);

                double bX = Calculate(textBoxBX.Value);
                double bY = Calculate(textBoxBY.Value);
                double bZ = Calculate(textBoxBZ.Value);

                Vector vectorA = new Vector(aX, aY, aZ);
                Vector vectorB = new Vector(bX, bY, bZ);

                Vector vectorAB = vectorA - vectorB;

                textBoxABX.Value = vectorAB.X.ToString();
                textBoxABY.Value = vectorAB.Y.ToString();
                textBoxABZ.Value = vectorAB.Z.ToString();
            }
            catch { }
        }

        private void buttonVectorMullAB_Click(object sender, EventArgs e)
        {
            try
            {
                double aX = Calculate(textBoxAX.Value);
                double aY = Calculate(textBoxAY.Value);
                double aZ = Calculate(textBoxAZ.Value);

                double bX = Calculate(textBoxBX.Value);
                double bY = Calculate(textBoxBY.Value);
                double bZ = Calculate(textBoxBZ.Value);

                Vector vectorA = new Vector(aX, aY, aZ);
                Vector vectorB = new Vector(bX, bY, bZ);

                Vector vectorAB = Vector.MullVectors(vectorA, vectorB);

                textBoxABX.Value = vectorAB.X.ToString();
                textBoxABY.Value = vectorAB.Y.ToString();
                textBoxABZ.Value = vectorAB.Z.ToString();
            }
            catch { }
        }

        private void buttonCoordsMullVector_Click(object sender, EventArgs e)
        {
            try
            {
                double aX = Calculate(textBoxAX.Value);
                double aY = Calculate(textBoxAY.Value);
                double aZ = Calculate(textBoxAZ.Value);

                double bX = Calculate(textBoxBX.Value);
                double bY = Calculate(textBoxBY.Value);
                double bZ = Calculate(textBoxBZ.Value);

                Vector vectorA = new Vector(aX, aY, aZ);
                Vector vectorB = new Vector(bX, bY, bZ);

                Vector vectorAB = Vector.MullCoords(vectorA, vectorB);

                textBoxABX.Value = vectorAB.X.ToString();
                textBoxABY.Value = vectorAB.Y.ToString();
                textBoxABZ.Value = vectorAB.Z.ToString();
            }
            catch { }
        }

        private void buttonDivCoordsAB_Click(object sender, EventArgs e)
        {
            try
            {
                double aX = Calculate(textBoxAX.Value);
                double aY = Calculate(textBoxAY.Value);
                double aZ = Calculate(textBoxAZ.Value);

                double bX = Calculate(textBoxBX.Value);
                double bY = Calculate(textBoxBY.Value);
                double bZ = Calculate(textBoxBZ.Value);

                Vector vectorA = new Vector(aX, aY, aZ);
                Vector vectorB = new Vector(bX, bY, bZ);

                Vector vectorAB = Vector.DivCoords(vectorA, vectorB);

                textBoxABX.Value = vectorAB.X.ToString();
                textBoxABY.Value = vectorAB.Y.ToString();
                textBoxABZ.Value = vectorAB.Z.ToString();
            }
            catch { }
        }

        private void buttonScalarAB_Click(object sender, EventArgs e)
        {
            try
            {
                double aX = Calculate(textBoxAX.Value);
                double aY = Calculate(textBoxAY.Value);
                double aZ = Calculate(textBoxAZ.Value);

                double bX = Calculate(textBoxBX.Value);
                double bY = Calculate(textBoxBY.Value);
                double bZ = Calculate(textBoxBZ.Value);

                Vector vectorA = new Vector(aX, aY, aZ);
                Vector vectorB = new Vector(bX, bY, bZ);

                textBoxScalarAB.Value = (vectorA*vectorB).ToString();
            }
            catch { }
        }

        private void buttonCopyLenA_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxScalarAB.Value = textBoxLenA.Value;
            }
            catch { }
        }

        private void buttonCopyLenB_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxScalarAB.Value = textBoxLenB.Value;
            }
            catch { }
        }

        private void buttonCopyLenAB_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxScalarAB.Value = textBoxLenAB.Value;
            }
            catch { }
        }

        private void buttonMullNA_Click(object sender, EventArgs e)
        {
            try
            {
                double aX = Calculate(textBoxAX.Value);
                double aY = Calculate(textBoxAY.Value);
                double aZ = Calculate(textBoxAZ.Value);

                double n = Calculate(textBoxScalarAB.Value);

                Vector vectorA = new Vector(aX, aY, aZ);
                Vector vectorB = vectorA * n;
                vectorA = vectorB;

                textBoxAX.Value = vectorA.X.ToString();
                textBoxAY.Value = vectorA.Y.ToString();
                textBoxAZ.Value = vectorA.Z.ToString();
            }
            catch { }
        }

        private void buttonMullNB_Click(object sender, EventArgs e)
        {
            try
            {
                double aX = Calculate(textBoxBX.Value);
                double aY = Calculate(textBoxBY.Value);
                double aZ = Calculate(textBoxBZ.Value);

                double n = Calculate(textBoxScalarAB.Value);

                Vector vectorA = new Vector(aX, aY, aZ);
                Vector vectorB = vectorA * n;
                vectorA = vectorB;

                textBoxBX.Value = vectorA.X.ToString();
                textBoxBY.Value = vectorA.Y.ToString();
                textBoxBZ.Value = vectorA.Z.ToString();
            }
            catch { }
        }

        private void buttonMullNAB_Click(object sender, EventArgs e)
        {
            try
            {
                double aX = Calculate(textBoxABX.Value);
                double aY = Calculate(textBoxABY.Value);
                double aZ = Calculate(textBoxABZ.Value);

                double n = Calculate(textBoxScalarAB.Value);

                Vector vectorA = new Vector(aX, aY, aZ);
                Vector vectorB = vectorA * n;
                vectorA = vectorB;

                textBoxABX.Value = vectorA.X.ToString();
                textBoxABY.Value = vectorA.Y.ToString();
                textBoxABZ.Value = vectorA.Z.ToString();
            }
            catch { }
        }

        private void buttonRet_Click(object sender, EventArgs e)
        {
            try
            {
                double n = Calculate("1/" + MyCalculate.AddBaskets(textBoxScalarAB.Value));
                textBoxScalarAB.Value = n.ToString();
            }
            catch { }
        }

        private void buttonLenToLast_Click(object sender, EventArgs e)
        {
            try
            {
                SaveV(textBoxVectorLen.Value);
            }
            catch { }
        }

        private void buttonLenToClipboard_Click(object sender, EventArgs e)
        {
            try
            {
                WriteToClipboard(textBoxVectorLen.Value);
            }
            catch { }
        }

        public void SaveV(string text)
        {
            try
            {
                MetrOutput1?.Invoke(text, Save);
            }
            catch
            {

            }
        }

        public void WriteMain(string text)
        {
            try
            {
                ValueHelper.SetText(text);
            }
            catch { }
        }

        void WriteToClipboard(string text)
        {
            try
            {
                Clipboard.SetText(text);
            }
            catch { }
        }


        string FromLast()
        {
            try
            {
                return SetNumberFromMain?.Invoke();
            }
            catch
            {
                return "";
            }
        }

        string FromMain()
        {
            return ValueHelper.GetText();
        }

        string FromClipboard()
        {
            try
            {
                return Clipboard.GetText();
            }
            catch
            {
                return "";
            }
        }


    }
}
