﻿namespace TableAIS
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.buttonSecondmetr = new System.Windows.Forms.Button();
            this.buttonFormule = new System.Windows.Forms.Button();
            this.checkBoxCopyNumber = new System.Windows.Forms.CheckBox();
            this.listBoxFiles = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxLogotip = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.labelProcess = new System.Windows.Forms.Label();
            this.buttonProcess = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelAppName = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.listBoxLists = new System.Windows.Forms.ListBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxValue = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxResult = new System.Windows.Forms.TextBox();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.ввестиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueClear = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueCreate = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueSave = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.записатьФормулуВExcelтаблицуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFormuleWrite = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueFormuleWrite = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueWriteSave = new System.Windows.Forms.ToolStripMenuItem();
            this.copyValueName = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxCopyName = new System.Windows.Forms.ToolStripTextBox();
            this.buttonCopyValueToValue = new System.Windows.Forms.ToolStripMenuItem();
            this.самоЗначениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyInputText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyJsonView = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueJsonText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueFromJsonJalue = new System.Windows.Forms.ToolStripMenuItem();
            this.имяФайлаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyTextToValueName = new System.Windows.Forms.ToolStripMenuItem();
            this.вычислитьизмеритьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.секундомеромToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.калькуляторToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromTemesSaved = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonGetValueFromCalculatorMemory = new System.Windows.Forms.ToolStripMenuItem();
            this.списокСтроксообщенийToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTextEditor = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTextEditorWithMain = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTextEditorWithValue = new System.Windows.Forms.ToolStripMenuItem();
            this.восстановитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetValueText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetExcelTable = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSetFormuleFromExcel = new System.Windows.Forms.ToolStripMenuItem();
            this.имяФайлаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.имяЗначенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.постоянныйБуферToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToLongBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromLongBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClearLongBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.временныйБуферToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueToBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueFromBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSaveTextBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadBufferText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonClearTimeBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.текстовыйФайлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSaveTextFile = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadTextFile = new System.Windows.Forms.ToolStripMenuItem();
            this.двоичныйКодToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTextToBynaryCode = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTextByBynaruCode = new System.Windows.Forms.ToolStripMenuItem();
            this.оПриложенииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonProgramInfoDialog = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonProgramInfoToTextValue = new System.Windows.Forms.ToolStripMenuItem();
            this.ячейкаExcelтаблицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonChangeColumn = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonChangeRow = new System.Windows.Forms.ToolStripMenuItem();
            this.jsonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonJsonOutput = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromJsonValue = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonJsonNetOutput = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromJsonValueNet = new System.Windows.Forms.ToolStripMenuItem();
            this.буферОбменаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToClipBord = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFromClipBord = new System.Windows.Forms.ToolStripMenuItem();
            this.загрузитьТекстToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonLoadText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonInputValue = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip4 = new System.Windows.Forms.MenuStrip();
            this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonHostSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonSecurity = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxAutoSave = new System.Windows.Forms.CheckBox();
            this.checkBoxAutoWrite = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.tabControlExcel = new System.Windows.Forms.TabControl();
            this.Строка = new System.Windows.Forms.TabPage();
            this.checkBoxRowAdd = new System.Windows.Forms.CheckBox();
            this.Столбец = new System.Windows.Forms.TabPage();
            this.checkBoxChangeColumn = new System.Windows.Forms.CheckBox();
            this.groupBoxPasswordServer = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxServerPasswordShow = new System.Windows.Forms.CheckBox();
            this.checkBoxCurrentCell = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.comboBoxChangePoint = new System.Windows.Forms.ComboBox();
            this.groupBoxValuesThis = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonThisDelete = new System.Windows.Forms.Button();
            this.textBoxValueThisAdd = new System.Windows.Forms.TextBox();
            this.buttonThisAddClear = new System.Windows.Forms.Button();
            this.buttonThisAdd = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxValueThis = new System.Windows.Forms.TextBox();
            this.buttonValueThisClear = new System.Windows.Forms.Button();
            this.buttonTranferThisRun = new System.Windows.Forms.Button();
            this.buttonTranferThisRunFromText = new System.Windows.Forms.Button();
            this.checkBoxRunNotificationWrite = new System.Windows.Forms.CheckBox();
            this.checkBoxRunNotificationSave = new System.Windows.Forms.CheckBox();
            this.checkBoxNoAllowPutByNet = new System.Windows.Forms.CheckBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonShowNetBuffer = new System.Windows.Forms.Button();
            this.buttonClearNetBuffer = new System.Windows.Forms.Button();
            this.buttonLoadNet = new System.Windows.Forms.Button();
            this.buttonNetBoth = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxNessasirlyAuth = new System.Windows.Forms.CheckBox();
            this.checkBoxShowPassword = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.действиеСФайломToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CreateNoneFile = new System.Windows.Forms.ToolStripMenuItem();
            this.excelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonExcelOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonExcelCreate = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTcpClientAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.CreateFileThis = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonUdpClientAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.путьКФайлуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddTextFile = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFileDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonRename = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFileFind = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonExcelVisual = new System.Windows.Forms.ToolStripMenuItem();
            this.обновитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ReopenExcel = new System.Windows.Forms.ToolStripMenuItem();
            this.копироватьНазваниеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyNameFileValue = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyNameToText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyNameToValue = new System.Windows.Forms.ToolStripMenuItem();
            this.задатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonNameByText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonNameByValue = new System.Windows.Forms.ToolStripMenuItem();
            this.листВФайлеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddList = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDeleteList = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonRenameList = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonListFind = new System.Windows.Forms.ToolStripMenuItem();
            this.обновитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.buttonNameClear = new System.Windows.Forms.Button();
            this.labelName = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.listBoxValues = new System.Windows.Forms.ListBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.buttonValueView = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonAddValueWithName = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonDeleteValue = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueRename = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueFind = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonFindByAll = new System.Windows.Forms.ToolStripMenuItem();
            this.копироватьИмяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyValueNameText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonCopyValueNameValue = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueNameCopyName = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonJsonDateView = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonJsonDataViewDialog = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonJsonDataViewText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonRezervNamesView = new System.Windows.Forms.ToolStripMenuItem();
            this.butonReservNamesViewDialog = new System.Windows.Forms.ToolStripMenuItem();
            this.butonReservNamesViewText = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonValueUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonTranferValue = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonValueNameClear = new System.Windows.Forms.Button();
            this.textBoxValueName = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxPath = new System.Windows.Forms.TextBox();
            this.openExcelFile = new System.Windows.Forms.OpenFileDialog();
            this.saveExcelFile = new System.Windows.Forms.SaveFileDialog();
            this.timerTCP = new System.Windows.Forms.Timer(this.components);
            this.toolTipInfoDoing = new System.Windows.Forms.ToolTip(this.components);
            this.notifyIconThis = new System.Windows.Forms.NotifyIcon(this.components);
            this.notifyIconValue = new System.Windows.Forms.NotifyIcon(this.components);
            this.numbericRowAdd = new TableAIS.NumbericUser();
            this.numbericRows = new TableAIS.NumbericUser();
            this.numericAddColumn = new TableAIS.NumbericUser();
            this.numbericColumns = new TableAIS.NumbericUser();
            this.textBoxNameServer = new TableAIS.TextBoxWithTitle();
            this.textBoxPasswordServer = new TableAIS.TextBoxWithTitle();
            this.comboBoxValuesThis = new TableAIS.Controls.ComboBoxToolTip();
            this.textBoxPassword = new TableAIS.TextBoxWithTitle();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).BeginInit();
            this.tableLayoutPanel18.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.menuStrip3.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.menuStrip4.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tabControlExcel.SuspendLayout();
            this.Строка.SuspendLayout();
            this.Столбец.SuspendLayout();
            this.groupBoxPasswordServer.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBoxValuesThis.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonSecondmetr
            // 
            this.buttonSecondmetr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSecondmetr.Location = new System.Drawing.Point(3, 3);
            this.buttonSecondmetr.Name = "buttonSecondmetr";
            this.buttonSecondmetr.Size = new System.Drawing.Size(182, 25);
            this.buttonSecondmetr.TabIndex = 0;
            this.buttonSecondmetr.Text = "Секундомер/Таймер";
            this.toolTipInfoDoing.SetToolTip(this.buttonSecondmetr, "Открыть секундомер");
            this.buttonSecondmetr.UseVisualStyleBackColor = true;
            this.buttonSecondmetr.Click += new System.EventHandler(this.buttonSecondmetr_Click);
            // 
            // buttonFormule
            // 
            this.buttonFormule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonFormule.Location = new System.Drawing.Point(3, 34);
            this.buttonFormule.Name = "buttonFormule";
            this.buttonFormule.Size = new System.Drawing.Size(182, 25);
            this.buttonFormule.TabIndex = 1;
            this.buttonFormule.Text = "Калькулятор";
            this.toolTipInfoDoing.SetToolTip(this.buttonFormule, "Открыть калькулятор");
            this.buttonFormule.UseVisualStyleBackColor = true;
            this.buttonFormule.Click += new System.EventHandler(this.buttonFormule_Click);
            // 
            // checkBoxCopyNumber
            // 
            this.checkBoxCopyNumber.AutoSize = true;
            this.checkBoxCopyNumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxCopyNumber.Location = new System.Drawing.Point(3, 65);
            this.checkBoxCopyNumber.Name = "checkBoxCopyNumber";
            this.checkBoxCopyNumber.Size = new System.Drawing.Size(182, 25);
            this.checkBoxCopyNumber.TabIndex = 4;
            this.checkBoxCopyNumber.Text = "Копировать число";
            this.checkBoxCopyNumber.UseVisualStyleBackColor = true;
            // 
            // listBoxFiles
            // 
            this.listBoxFiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxFiles.FormattingEnabled = true;
            this.listBoxFiles.ItemHeight = 21;
            this.listBoxFiles.Location = new System.Drawing.Point(3, 30);
            this.listBoxFiles.Name = "listBoxFiles";
            this.listBoxFiles.Size = new System.Drawing.Size(244, 145);
            this.listBoxFiles.TabIndex = 5;
            this.listBoxFiles.Click += new System.EventHandler(this.listBoxFiles_SelectedIndexChanged);
            this.listBoxFiles.SelectedIndexChanged += new System.EventHandler(this.listBoxFiles_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(928, 89);
            this.panel1.TabIndex = 9;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.60191F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.39809F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBoxLogotip, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel18, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(924, 85);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBoxLogotip
            // 
            this.pictureBoxLogotip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLogotip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxLogotip.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogotip.Image")));
            this.pictureBoxLogotip.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxLogotip.Name = "pictureBoxLogotip";
            this.pictureBoxLogotip.Size = new System.Drawing.Size(80, 80);
            this.pictureBoxLogotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogotip.TabIndex = 0;
            this.pictureBoxLogotip.TabStop = false;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(618, 25);
            this.button1.Margin = new System.Windows.Forms.Padding(25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(281, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "Выйти";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.66666F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel18.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel18.Controls.Add(this.labelProcess, 0, 1);
            this.tableLayoutPanel18.Controls.Add(this.buttonProcess, 1, 1);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(89, 3);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 2;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(501, 80);
            this.tableLayoutPanel18.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.tableLayoutPanel18.SetColumnSpan(this.label1, 2);
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(495, 56);
            this.label1.TabIndex = 1;
            this.label1.Text = "Главный экран";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelProcess
            // 
            this.labelProcess.AutoSize = true;
            this.labelProcess.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelProcess.Location = new System.Drawing.Point(3, 56);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new System.Drawing.Size(328, 24);
            this.labelProcess.TabIndex = 2;
            this.labelProcess.Text = "TableAIS";
            this.labelProcess.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonProcess
            // 
            this.buttonProcess.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonProcess.Location = new System.Drawing.Point(334, 56);
            this.buttonProcess.Margin = new System.Windows.Forms.Padding(0);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new System.Drawing.Size(167, 24);
            this.buttonProcess.TabIndex = 3;
            this.buttonProcess.Text = "Процессы";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new System.EventHandler(this.buttonProcess_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F);
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate,
            this.labelTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 509);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(928, 24);
            this.statusStrip1.TabIndex = 10;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(164, 18);
            this.labelDate.Text = "toolStripStatusLabel1";
            // 
            // labelTime
            // 
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(164, 18);
            this.labelTime.Text = "toolStripStatusLabel1";
            // 
            // timerTime
            // 
            this.timerTime.Enabled = true;
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.labelAppName);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.panel2.Location = new System.Drawing.Point(0, 486);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(928, 23);
            this.panel2.TabIndex = 11;
            // 
            // labelAppName
            // 
            this.labelAppName.AutoSize = true;
            this.labelAppName.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAppName.Location = new System.Drawing.Point(371, 0);
            this.labelAppName.Name = "labelAppName";
            this.labelAppName.Size = new System.Drawing.Size(282, 18);
            this.labelAppName.TabIndex = 0;
            this.labelAppName.Text = "@Properties.Resources.AppName";
            this.toolTipInfoDoing.SetToolTip(this.labelAppName, "TableAIS");
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 256F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox2, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 1, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.58228F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.41772F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(928, 397);
            this.tableLayoutPanel2.TabIndex = 12;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBoxFiles);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(250, 178);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Файлы";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listBoxLists);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 187);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(250, 207);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Листы в файле";
            // 
            // listBoxLists
            // 
            this.listBoxLists.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxLists.FormattingEnabled = true;
            this.listBoxLists.ItemHeight = 21;
            this.listBoxLists.Location = new System.Drawing.Point(3, 30);
            this.listBoxLists.Name = "listBoxLists";
            this.listBoxLists.Size = new System.Drawing.Size(244, 174);
            this.listBoxLists.TabIndex = 0;
            this.listBoxLists.Click += new System.EventHandler(this.listBoxLists_SelectedIndexChanged);
            this.listBoxLists.SelectedIndexChanged += new System.EventHandler(this.listBoxLists_SelectedIndexChanged);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.tableLayoutPanel3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(259, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(666, 178);
            this.panel3.TabIndex = 2;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.24999F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.5F));
            this.tableLayoutPanel3.Controls.Add(this.textBoxValue, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel9, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel6, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel11, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.groupBox7, 2, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.86207F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.65517F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.48276F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(662, 174);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // textBoxValue
            // 
            this.textBoxValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxValue.Location = new System.Drawing.Point(209, 3);
            this.textBoxValue.Multiline = true;
            this.textBoxValue.Name = "textBoxValue";
            this.tableLayoutPanel3.SetRowSpan(this.textBoxValue, 2);
            this.textBoxValue.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxValue.Size = new System.Drawing.Size(200, 107);
            this.textBoxValue.TabIndex = 5;
            this.textBoxValue.TextChanged += new System.EventHandler(this.textBoxValue_TextChanged);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.textBoxResult, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.menuStrip3, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(415, 3);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(244, 39);
            this.tableLayoutPanel9.TabIndex = 8;
            // 
            // textBoxResult
            // 
            this.textBoxResult.BackColor = System.Drawing.Color.White;
            this.textBoxResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxResult.Location = new System.Drawing.Point(125, 3);
            this.textBoxResult.Name = "textBoxResult";
            this.textBoxResult.ReadOnly = true;
            this.textBoxResult.Size = new System.Drawing.Size(116, 34);
            this.textBoxResult.TabIndex = 8;
            // 
            // menuStrip3
            // 
            this.menuStrip3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip3.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ввестиToolStripMenuItem});
            this.menuStrip3.Location = new System.Drawing.Point(0, 0);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(122, 39);
            this.menuStrip3.TabIndex = 5;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // ввестиToolStripMenuItem
            // 
            this.ввестиToolStripMenuItem.BackColor = System.Drawing.Color.LightGray;
            this.ввестиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonValueClear,
            this.buttonValueCreate,
            this.buttonValueSave,
            this.buttonValueWriteSave,
            this.copyValueName,
            this.вычислитьизмеритьToolStripMenuItem,
            this.восстановитьToolStripMenuItem,
            this.постоянныйБуферToolStripMenuItem,
            this.временныйБуферToolStripMenuItem,
            this.текстовыйФайлToolStripMenuItem,
            this.двоичныйКодToolStripMenuItem,
            this.оПриложенииToolStripMenuItem,
            this.ячейкаExcelтаблицыToolStripMenuItem,
            this.jsonToolStripMenuItem,
            this.буферОбменаToolStripMenuItem,
            this.загрузитьТекстToolStripMenuItem});
            this.ввестиToolStripMenuItem.Name = "ввестиToolStripMenuItem";
            this.ввестиToolStripMenuItem.Size = new System.Drawing.Size(104, 35);
            this.ввестиToolStripMenuItem.Text = "Значение";
            this.ввестиToolStripMenuItem.ToolTipText = "Ввести/Сохранить значение";
            // 
            // buttonValueClear
            // 
            this.buttonValueClear.Name = "buttonValueClear";
            this.buttonValueClear.Size = new System.Drawing.Size(338, 26);
            this.buttonValueClear.Text = "Сбросить";
            this.buttonValueClear.Click += new System.EventHandler(this.buttonValueClear_Click);
            // 
            // buttonValueCreate
            // 
            this.buttonValueCreate.Name = "buttonValueCreate";
            this.buttonValueCreate.Size = new System.Drawing.Size(338, 26);
            this.buttonValueCreate.Text = "Ввести";
            this.buttonValueCreate.Click += new System.EventHandler(this.buttonValueCreate_Click);
            // 
            // buttonValueSave
            // 
            this.buttonValueSave.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сохранитьToolStripMenuItem,
            this.записатьФормулуВExcelтаблицуToolStripMenuItem});
            this.buttonValueSave.Name = "buttonValueSave";
            this.buttonValueSave.Size = new System.Drawing.Size(338, 26);
            this.buttonValueSave.Text = "Сохранить";
            // 
            // сохранитьToolStripMenuItem
            // 
            this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
            this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(390, 26);
            this.сохранитьToolStripMenuItem.Text = "Сохранить";
            this.сохранитьToolStripMenuItem.Click += new System.EventHandler(this.buttonValueSave_Click);
            // 
            // записатьФормулуВExcelтаблицуToolStripMenuItem
            // 
            this.записатьФормулуВExcelтаблицуToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonFormuleWrite,
            this.buttonValueFormuleWrite});
            this.записатьФормулуВExcelтаблицуToolStripMenuItem.Name = "записатьФормулуВExcelтаблицуToolStripMenuItem";
            this.записатьФормулуВExcelтаблицуToolStripMenuItem.Size = new System.Drawing.Size(390, 26);
            this.записатьФормулуВExcelтаблицуToolStripMenuItem.Text = "Записать формулу в Excel-таблицу";
            // 
            // buttonFormuleWrite
            // 
            this.buttonFormuleWrite.Name = "buttonFormuleWrite";
            this.buttonFormuleWrite.Size = new System.Drawing.Size(174, 26);
            this.buttonFormuleWrite.Text = "Текст";
            this.buttonFormuleWrite.Click += new System.EventHandler(this.buttonFormuleWrite_Click);
            // 
            // buttonValueFormuleWrite
            // 
            this.buttonValueFormuleWrite.Name = "buttonValueFormuleWrite";
            this.buttonValueFormuleWrite.Size = new System.Drawing.Size(174, 26);
            this.buttonValueFormuleWrite.Text = "Значение";
            this.buttonValueFormuleWrite.Click += new System.EventHandler(this.buttonValueFormuleWrite_Click);
            // 
            // buttonValueWriteSave
            // 
            this.buttonValueWriteSave.Name = "buttonValueWriteSave";
            this.buttonValueWriteSave.Size = new System.Drawing.Size(338, 26);
            this.buttonValueWriteSave.Text = "Ввести и сохранить";
            this.buttonValueWriteSave.Click += new System.EventHandler(this.buttonValueWriteSave_Click);
            // 
            // copyValueName
            // 
            this.copyValueName.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.textBoxCopyName,
            this.buttonCopyValueToValue,
            this.имяФайлаToolStripMenuItem,
            this.buttonCopyTextToValueName});
            this.copyValueName.Name = "copyValueName";
            this.copyValueName.Size = new System.Drawing.Size(338, 26);
            this.copyValueName.Text = "Копировать";
            // 
            // textBoxCopyName
            // 
            this.textBoxCopyName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCopyName.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxCopyName.Name = "textBoxCopyName";
            this.textBoxCopyName.Size = new System.Drawing.Size(100, 34);
            // 
            // buttonCopyValueToValue
            // 
            this.buttonCopyValueToValue.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.самоЗначениеToolStripMenuItem,
            this.buttonCopyInputText,
            this.buttonCopyJsonView,
            this.buttonValueJsonText,
            this.buttonValueFromJsonJalue});
            this.buttonCopyValueToValue.Name = "buttonCopyValueToValue";
            this.buttonCopyValueToValue.Size = new System.Drawing.Size(278, 26);
            this.buttonCopyValueToValue.Text = "Копировать значение";
            // 
            // самоЗначениеToolStripMenuItem
            // 
            this.самоЗначениеToolStripMenuItem.Name = "самоЗначениеToolStripMenuItem";
            this.самоЗначениеToolStripMenuItem.Size = new System.Drawing.Size(406, 26);
            this.самоЗначениеToolStripMenuItem.Text = "Само значение";
            this.самоЗначениеToolStripMenuItem.Click += new System.EventHandler(this.buttonCopyValueToValue_Click);
            // 
            // buttonCopyInputText
            // 
            this.buttonCopyInputText.Name = "buttonCopyInputText";
            this.buttonCopyInputText.Size = new System.Drawing.Size(406, 26);
            this.buttonCopyInputText.Text = "Введённый текст";
            this.buttonCopyInputText.Click += new System.EventHandler(this.buttonCopyInputText_Click);
            // 
            // buttonCopyJsonView
            // 
            this.buttonCopyJsonView.Name = "buttonCopyJsonView";
            this.buttonCopyJsonView.Size = new System.Drawing.Size(406, 26);
            this.buttonCopyJsonView.Text = "Json-представление";
            this.buttonCopyJsonView.Click += new System.EventHandler(this.buttonCopyJsonView_Click);
            // 
            // buttonValueJsonText
            // 
            this.buttonValueJsonText.Name = "buttonValueJsonText";
            this.buttonValueJsonText.Size = new System.Drawing.Size(406, 26);
            this.buttonValueJsonText.Text = "Значение из введённого Json-текста";
            this.buttonValueJsonText.Click += new System.EventHandler(this.buttonValueJsonText_Click);
            // 
            // buttonValueFromJsonJalue
            // 
            this.buttonValueFromJsonJalue.Name = "buttonValueFromJsonJalue";
            this.buttonValueFromJsonJalue.Size = new System.Drawing.Size(406, 26);
            this.buttonValueFromJsonJalue.Text = "Значение из Json-текста";
            this.buttonValueFromJsonJalue.Click += new System.EventHandler(this.buttonValueFromJsonJalue_Click);
            // 
            // имяФайлаToolStripMenuItem
            // 
            this.имяФайлаToolStripMenuItem.Name = "имяФайлаToolStripMenuItem";
            this.имяФайлаToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.имяФайлаToolStripMenuItem.Text = "Имя файла/Листа";
            this.имяФайлаToolStripMenuItem.Click += new System.EventHandler(this.buttonNameByText_Click);
            // 
            // buttonCopyTextToValueName
            // 
            this.buttonCopyTextToValueName.Name = "buttonCopyTextToValueName";
            this.buttonCopyTextToValueName.Size = new System.Drawing.Size(278, 26);
            this.buttonCopyTextToValueName.Text = "Имя значения";
            this.buttonCopyTextToValueName.Click += new System.EventHandler(this.buttonCopyTextToValueName_Click);
            // 
            // вычислитьизмеритьToolStripMenuItem
            // 
            this.вычислитьизмеритьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.секундомеромToolStripMenuItem,
            this.калькуляторToolStripMenuItem,
            this.buttonFromTemesSaved,
            this.buttonGetValueFromCalculatorMemory,
            this.списокСтроксообщенийToolStripMenuItem,
            this.buttonTextEditor,
            this.buttonTextEditorWithMain,
            this.buttonTextEditorWithValue});
            this.вычислитьизмеритьToolStripMenuItem.Name = "вычислитьизмеритьToolStripMenuItem";
            this.вычислитьизмеритьToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.вычислитьизмеритьToolStripMenuItem.Text = "Вычислить/измерить/Ввести";
            // 
            // секундомеромToolStripMenuItem
            // 
            this.секундомеромToolStripMenuItem.Name = "секундомеромToolStripMenuItem";
            this.секундомеромToolStripMenuItem.Size = new System.Drawing.Size(535, 26);
            this.секундомеромToolStripMenuItem.Text = "Секундомером/таймером";
            this.секундомеромToolStripMenuItem.Click += new System.EventHandler(this.buttonSecondmetr_Click);
            // 
            // калькуляторToolStripMenuItem
            // 
            this.калькуляторToolStripMenuItem.Name = "калькуляторToolStripMenuItem";
            this.калькуляторToolStripMenuItem.Size = new System.Drawing.Size(535, 26);
            this.калькуляторToolStripMenuItem.Text = "Калькулятор";
            this.калькуляторToolStripMenuItem.Click += new System.EventHandler(this.buttonFormule_Click);
            // 
            // buttonFromTemesSaved
            // 
            this.buttonFromTemesSaved.Name = "buttonFromTemesSaved";
            this.buttonFromTemesSaved.Size = new System.Drawing.Size(535, 26);
            this.buttonFromTemesSaved.Text = "Из списка измерений секундомером";
            this.buttonFromTemesSaved.Click += new System.EventHandler(this.buttonFromTemesSaved_Click);
            // 
            // buttonGetValueFromCalculatorMemory
            // 
            this.buttonGetValueFromCalculatorMemory.Name = "buttonGetValueFromCalculatorMemory";
            this.buttonGetValueFromCalculatorMemory.Size = new System.Drawing.Size(535, 26);
            this.buttonGetValueFromCalculatorMemory.Text = "Из памяти калькулятора";
            this.buttonGetValueFromCalculatorMemory.Click += new System.EventHandler(this.buttonGetValueFromCalculatorMemory_Click);
            // 
            // списокСтроксообщенийToolStripMenuItem
            // 
            this.списокСтроксообщенийToolStripMenuItem.Name = "списокСтроксообщенийToolStripMenuItem";
            this.списокСтроксообщенийToolStripMenuItem.Size = new System.Drawing.Size(535, 26);
            this.списокСтроксообщенийToolStripMenuItem.Text = "Список строк/сообщений";
            // 
            // buttonTextEditor
            // 
            this.buttonTextEditor.Name = "buttonTextEditor";
            this.buttonTextEditor.Size = new System.Drawing.Size(535, 26);
            this.buttonTextEditor.Text = "Текстовый редактор";
            this.buttonTextEditor.Click += new System.EventHandler(this.buttonTextEditor_Click);
            // 
            // buttonTextEditorWithMain
            // 
            this.buttonTextEditorWithMain.Name = "buttonTextEditorWithMain";
            this.buttonTextEditorWithMain.Size = new System.Drawing.Size(535, 26);
            this.buttonTextEditorWithMain.Text = "Текстовый редактор со значением текстового поля";
            this.buttonTextEditorWithMain.Click += new System.EventHandler(this.buttonTextEditorWithMain_Click);
            // 
            // buttonTextEditorWithValue
            // 
            this.buttonTextEditorWithValue.Name = "buttonTextEditorWithValue";
            this.buttonTextEditorWithValue.Size = new System.Drawing.Size(535, 26);
            this.buttonTextEditorWithValue.Text = "Текстовый редактор с текстом значения";
            this.buttonTextEditorWithValue.Click += new System.EventHandler(this.buttonTextEditorWithValue_Click);
            // 
            // восстановитьToolStripMenuItem
            // 
            this.восстановитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSetValueText,
            this.buttonSetExcelTable,
            this.buttonSetFormuleFromExcel,
            this.имяФайлаToolStripMenuItem1,
            this.имяЗначенияToolStripMenuItem});
            this.восстановитьToolStripMenuItem.Name = "восстановитьToolStripMenuItem";
            this.восстановитьToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.восстановитьToolStripMenuItem.Text = "Восстановить текст";
            // 
            // buttonSetValueText
            // 
            this.buttonSetValueText.Name = "buttonSetValueText";
            this.buttonSetValueText.Size = new System.Drawing.Size(321, 26);
            this.buttonSetValueText.Text = "Текст значения";
            this.buttonSetValueText.Click += new System.EventHandler(this.buttonSetValueText_Click);
            // 
            // buttonSetExcelTable
            // 
            this.buttonSetExcelTable.Name = "buttonSetExcelTable";
            this.buttonSetExcelTable.Size = new System.Drawing.Size(321, 26);
            this.buttonSetExcelTable.Text = "Текст из Excel-таблицы";
            this.buttonSetExcelTable.Click += new System.EventHandler(this.buttonSetExcelTable_Click);
            // 
            // buttonSetFormuleFromExcel
            // 
            this.buttonSetFormuleFromExcel.Name = "buttonSetFormuleFromExcel";
            this.buttonSetFormuleFromExcel.Size = new System.Drawing.Size(321, 26);
            this.buttonSetFormuleFromExcel.Text = "Формулу из Excel-таблицы";
            this.buttonSetFormuleFromExcel.Click += new System.EventHandler(this.buttonSetFormuleFromExcel_Click);
            // 
            // имяФайлаToolStripMenuItem1
            // 
            this.имяФайлаToolStripMenuItem1.Name = "имяФайлаToolStripMenuItem1";
            this.имяФайлаToolStripMenuItem1.Size = new System.Drawing.Size(321, 26);
            this.имяФайлаToolStripMenuItem1.Text = "Имя файла/Листа";
            this.имяФайлаToolStripMenuItem1.Click += new System.EventHandler(this.buttonCopyNameToText_Click);
            // 
            // имяЗначенияToolStripMenuItem
            // 
            this.имяЗначенияToolStripMenuItem.Name = "имяЗначенияToolStripMenuItem";
            this.имяЗначенияToolStripMenuItem.Size = new System.Drawing.Size(321, 26);
            this.имяЗначенияToolStripMenuItem.Text = "Имя значения";
            this.имяЗначенияToolStripMenuItem.Click += new System.EventHandler(this.buttonCopyValueNameText_Click);
            // 
            // постоянныйБуферToolStripMenuItem
            // 
            this.постоянныйБуферToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToLongBuffer,
            this.buttonFromLongBuffer,
            this.buttonClearLongBuffer});
            this.постоянныйБуферToolStripMenuItem.Name = "постоянныйБуферToolStripMenuItem";
            this.постоянныйБуферToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.постоянныйБуферToolStripMenuItem.Text = "Постоянный буфер";
            // 
            // buttonToLongBuffer
            // 
            this.buttonToLongBuffer.Name = "buttonToLongBuffer";
            this.buttonToLongBuffer.Size = new System.Drawing.Size(268, 26);
            this.buttonToLongBuffer.Text = "Загрузить в буфер";
            this.buttonToLongBuffer.Click += new System.EventHandler(this.buttonToLongBuffer_Click);
            // 
            // buttonFromLongBuffer
            // 
            this.buttonFromLongBuffer.Name = "buttonFromLongBuffer";
            this.buttonFromLongBuffer.Size = new System.Drawing.Size(268, 26);
            this.buttonFromLongBuffer.Text = "Загрузить из буфера";
            this.buttonFromLongBuffer.Click += new System.EventHandler(this.buttonFromLongBuffer_Click);
            // 
            // buttonClearLongBuffer
            // 
            this.buttonClearLongBuffer.Name = "buttonClearLongBuffer";
            this.buttonClearLongBuffer.Size = new System.Drawing.Size(268, 26);
            this.buttonClearLongBuffer.Text = "Очистить буфер";
            this.buttonClearLongBuffer.Click += new System.EventHandler(this.buttonClearLongBuffer_Click);
            // 
            // временныйБуферToolStripMenuItem
            // 
            this.временныйБуферToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonValueToBuffer,
            this.buttonValueFromBuffer,
            this.buttonSaveTextBuffer,
            this.buttonLoadBufferText,
            this.buttonClearTimeBuffer});
            this.временныйБуферToolStripMenuItem.Name = "временныйБуферToolStripMenuItem";
            this.временныйБуферToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.временныйБуферToolStripMenuItem.Text = "Временный буфер";
            // 
            // buttonValueToBuffer
            // 
            this.buttonValueToBuffer.Name = "buttonValueToBuffer";
            this.buttonValueToBuffer.Size = new System.Drawing.Size(421, 26);
            this.buttonValueToBuffer.Text = "Сохранить в буфер";
            this.buttonValueToBuffer.Click += new System.EventHandler(this.buttonValueToBuffer_Click);
            // 
            // buttonValueFromBuffer
            // 
            this.buttonValueFromBuffer.Name = "buttonValueFromBuffer";
            this.buttonValueFromBuffer.Size = new System.Drawing.Size(421, 26);
            this.buttonValueFromBuffer.Text = "Загрузить из буфера";
            this.buttonValueFromBuffer.Click += new System.EventHandler(this.buttonValueFromBuffer_Click);
            // 
            // buttonSaveTextBuffer
            // 
            this.buttonSaveTextBuffer.Name = "buttonSaveTextBuffer";
            this.buttonSaveTextBuffer.Size = new System.Drawing.Size(421, 26);
            this.buttonSaveTextBuffer.Text = "Сохранить введённый текст в буффер";
            this.buttonSaveTextBuffer.Click += new System.EventHandler(this.buttonSaveTextBuffer_Click);
            // 
            // buttonLoadBufferText
            // 
            this.buttonLoadBufferText.Name = "buttonLoadBufferText";
            this.buttonLoadBufferText.Size = new System.Drawing.Size(421, 26);
            this.buttonLoadBufferText.Text = "Вывести текст из буффера";
            this.buttonLoadBufferText.Click += new System.EventHandler(this.buttonLoadBufferText_Click);
            // 
            // buttonClearTimeBuffer
            // 
            this.buttonClearTimeBuffer.Name = "buttonClearTimeBuffer";
            this.buttonClearTimeBuffer.Size = new System.Drawing.Size(421, 26);
            this.buttonClearTimeBuffer.Text = "Очистить буфер";
            this.buttonClearTimeBuffer.Click += new System.EventHandler(this.buttonClearTimeBuffer_Click);
            // 
            // текстовыйФайлToolStripMenuItem
            // 
            this.текстовыйФайлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonSaveTextFile,
            this.buttonLoadTextFile});
            this.текстовыйФайлToolStripMenuItem.Name = "текстовыйФайлToolStripMenuItem";
            this.текстовыйФайлToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.текстовыйФайлToolStripMenuItem.Text = "Текстовый файл";
            // 
            // buttonSaveTextFile
            // 
            this.buttonSaveTextFile.Name = "buttonSaveTextFile";
            this.buttonSaveTextFile.Size = new System.Drawing.Size(307, 26);
            this.buttonSaveTextFile.Text = "Вывести текст в файл";
            this.buttonSaveTextFile.Click += new System.EventHandler(this.buttonSaveTextFile_Click);
            // 
            // buttonLoadTextFile
            // 
            this.buttonLoadTextFile.Name = "buttonLoadTextFile";
            this.buttonLoadTextFile.Size = new System.Drawing.Size(307, 26);
            this.buttonLoadTextFile.Text = "Загрузить текст из файла";
            this.buttonLoadTextFile.Click += new System.EventHandler(this.buttonLoadTextFile_Click);
            // 
            // двоичныйКодToolStripMenuItem
            // 
            this.двоичныйКодToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonTextToBynaryCode,
            this.buttonTextByBynaruCode});
            this.двоичныйКодToolStripMenuItem.Name = "двоичныйКодToolStripMenuItem";
            this.двоичныйКодToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.двоичныйКодToolStripMenuItem.Text = "Двоичный код";
            // 
            // buttonTextToBynaryCode
            // 
            this.buttonTextToBynaryCode.Name = "buttonTextToBynaryCode";
            this.buttonTextToBynaryCode.Size = new System.Drawing.Size(374, 26);
            this.buttonTextToBynaryCode.Text = "Перевести текст в двоичный код";
            this.buttonTextToBynaryCode.Click += new System.EventHandler(this.buttonTextToBynaryCode_Click);
            // 
            // buttonTextByBynaruCode
            // 
            this.buttonTextByBynaruCode.Name = "buttonTextByBynaruCode";
            this.buttonTextByBynaruCode.Size = new System.Drawing.Size(374, 26);
            this.buttonTextByBynaruCode.Text = "Перевести двоичный код в текст";
            this.buttonTextByBynaruCode.Click += new System.EventHandler(this.buttonTextByBynaruCode_Click);
            // 
            // оПриложенииToolStripMenuItem
            // 
            this.оПриложенииToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonProgramInfoDialog,
            this.buttonProgramInfoToTextValue});
            this.оПриложенииToolStripMenuItem.Name = "оПриложенииToolStripMenuItem";
            this.оПриложенииToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.оПриложенииToolStripMenuItem.Text = "О приложении";
            this.оПриложенииToolStripMenuItem.Click += new System.EventHandler(this.оПриложенииToolStripMenuItem_Click);
            // 
            // buttonProgramInfoDialog
            // 
            this.buttonProgramInfoDialog.Name = "buttonProgramInfoDialog";
            this.buttonProgramInfoDialog.Size = new System.Drawing.Size(259, 26);
            this.buttonProgramInfoDialog.Text = "Диалоговым окном";
            this.buttonProgramInfoDialog.Click += new System.EventHandler(this.buttonProgramInfoDialog_Click);
            // 
            // buttonProgramInfoToTextValue
            // 
            this.buttonProgramInfoToTextValue.Name = "buttonProgramInfoToTextValue";
            this.buttonProgramInfoToTextValue.Size = new System.Drawing.Size(259, 26);
            this.buttonProgramInfoToTextValue.Text = "В текстовое поле";
            this.buttonProgramInfoToTextValue.Click += new System.EventHandler(this.buttonProgramInfoToTextValue_Click);
            // 
            // ячейкаExcelтаблицыToolStripMenuItem
            // 
            this.ячейкаExcelтаблицыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonChangeColumn,
            this.buttonChangeRow});
            this.ячейкаExcelтаблицыToolStripMenuItem.Name = "ячейкаExcelтаблицыToolStripMenuItem";
            this.ячейкаExcelтаблицыToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.ячейкаExcelтаблицыToolStripMenuItem.Text = "Ячейка Excel-таблицы";
            // 
            // buttonChangeColumn
            // 
            this.buttonChangeColumn.Name = "buttonChangeColumn";
            this.buttonChangeColumn.Size = new System.Drawing.Size(250, 26);
            this.buttonChangeColumn.Text = "Изменить столбец";
            this.buttonChangeColumn.Click += new System.EventHandler(this.buttonChangeColumn_Click);
            // 
            // buttonChangeRow
            // 
            this.buttonChangeRow.Name = "buttonChangeRow";
            this.buttonChangeRow.Size = new System.Drawing.Size(250, 26);
            this.buttonChangeRow.Text = "Изменить строку";
            this.buttonChangeRow.Click += new System.EventHandler(this.buttonChangeRow_Click);
            // 
            // jsonToolStripMenuItem
            // 
            this.jsonToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonJsonOutput,
            this.buttonFromJsonValue,
            this.buttonJsonNetOutput,
            this.buttonFromJsonValueNet});
            this.jsonToolStripMenuItem.Name = "jsonToolStripMenuItem";
            this.jsonToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.jsonToolStripMenuItem.Text = "Json";
            // 
            // buttonJsonOutput
            // 
            this.buttonJsonOutput.Name = "buttonJsonOutput";
            this.buttonJsonOutput.Size = new System.Drawing.Size(467, 26);
            this.buttonJsonOutput.Text = "Вывести Json";
            this.buttonJsonOutput.Click += new System.EventHandler(this.buttonJsonOutput_Click);
            // 
            // buttonFromJsonValue
            // 
            this.buttonFromJsonValue.Name = "buttonFromJsonValue";
            this.buttonFromJsonValue.Size = new System.Drawing.Size(467, 26);
            this.buttonFromJsonValue.Text = "Вывести значение из Json-текста";
            this.buttonFromJsonValue.Click += new System.EventHandler(this.buttonFromJsonValue_Click);
            // 
            // buttonJsonNetOutput
            // 
            this.buttonJsonNetOutput.Name = "buttonJsonNetOutput";
            this.buttonJsonNetOutput.Size = new System.Drawing.Size(467, 26);
            this.buttonJsonNetOutput.Text = "Вывести в Json для передачи по сети";
            this.buttonJsonNetOutput.Click += new System.EventHandler(this.buttonJsonNetOutput_Click);
            // 
            // buttonFromJsonValueNet
            // 
            this.buttonFromJsonValueNet.Name = "buttonFromJsonValueNet";
            this.buttonFromJsonValueNet.Size = new System.Drawing.Size(467, 26);
            this.buttonFromJsonValueNet.Text = "Вывести текст из Json для передачи по сети";
            this.buttonFromJsonValueNet.Click += new System.EventHandler(this.buttonFromJsonValueNet_Click);
            // 
            // буферОбменаToolStripMenuItem
            // 
            this.буферОбменаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToClipBord,
            this.buttonFromClipBord});
            this.буферОбменаToolStripMenuItem.Name = "буферОбменаToolStripMenuItem";
            this.буферОбменаToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.буферОбменаToolStripMenuItem.Text = "Буфер обмена";
            // 
            // buttonToClipBord
            // 
            this.buttonToClipBord.Name = "buttonToClipBord";
            this.buttonToClipBord.Size = new System.Drawing.Size(372, 26);
            this.buttonToClipBord.Text = "Вывести текст в буфер обмена";
            this.buttonToClipBord.Click += new System.EventHandler(this.buttonToClipBord_Click);
            // 
            // buttonFromClipBord
            // 
            this.buttonFromClipBord.Name = "buttonFromClipBord";
            this.buttonFromClipBord.Size = new System.Drawing.Size(372, 26);
            this.buttonFromClipBord.Text = "Вывести текст из буфера обмена";
            this.buttonFromClipBord.Click += new System.EventHandler(this.buttonFromClipBord_Click);
            // 
            // загрузитьТекстToolStripMenuItem
            // 
            this.загрузитьТекстToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonLoadText,
            this.buttonInputValue});
            this.загрузитьТекстToolStripMenuItem.Name = "загрузитьТекстToolStripMenuItem";
            this.загрузитьТекстToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.загрузитьТекстToolStripMenuItem.Text = "Загрузить текст";
            // 
            // buttonLoadText
            // 
            this.buttonLoadText.Name = "buttonLoadText";
            this.buttonLoadText.Size = new System.Drawing.Size(174, 26);
            this.buttonLoadText.Text = "Текст";
            this.buttonLoadText.Click += new System.EventHandler(this.buttonLoadText_Click);
            // 
            // buttonInputValue
            // 
            this.buttonInputValue.Name = "buttonInputValue";
            this.buttonInputValue.Size = new System.Drawing.Size(174, 26);
            this.buttonInputValue.Text = "Значение";
            this.buttonInputValue.Click += new System.EventHandler(this.buttonInputValue_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Controls.Add(this.groupBox5, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.menuStrip4, 0, 3);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 4;
            this.tableLayoutPanel3.SetRowSpan(this.tableLayoutPanel6, 3);
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.12048F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.48193F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(200, 168);
            this.tableLayoutPanel6.TabIndex = 6;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tableLayoutPanel10);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(3, 3);
            this.groupBox5.Name = "groupBox5";
            this.tableLayoutPanel6.SetRowSpan(this.groupBox5, 3);
            this.groupBox5.Size = new System.Drawing.Size(194, 126);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Получить значение";
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.Controls.Add(this.checkBoxCopyNumber, 0, 2);
            this.tableLayoutPanel10.Controls.Add(this.buttonSecondmetr, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.buttonFormule, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 3;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(188, 93);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // menuStrip4
            // 
            this.menuStrip4.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.настройкиToolStripMenuItem});
            this.menuStrip4.Location = new System.Drawing.Point(0, 132);
            this.menuStrip4.Name = "menuStrip4";
            this.menuStrip4.Size = new System.Drawing.Size(200, 30);
            this.menuStrip4.TabIndex = 7;
            this.menuStrip4.Text = "menuStrip4";
            // 
            // настройкиToolStripMenuItem
            // 
            this.настройкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonHostSettings,
            this.buttonSecurity});
            this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
            this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(116, 25);
            this.настройкиToolStripMenuItem.Text = "Настройки";
            // 
            // buttonHostSettings
            // 
            this.buttonHostSettings.Name = "buttonHostSettings";
            this.buttonHostSettings.Size = new System.Drawing.Size(298, 26);
            this.buttonHostSettings.Text = "Настроить сетевой узел";
            this.buttonHostSettings.Click += new System.EventHandler(this.buttonHostSettings_Click);
            // 
            // buttonSecurity
            // 
            this.buttonSecurity.Name = "buttonSecurity";
            this.buttonSecurity.Size = new System.Drawing.Size(298, 26);
            this.buttonSecurity.Text = "Безопасность";
            this.buttonSecurity.Click += new System.EventHandler(this.buttonSecurity_Click);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel11.Controls.Add(this.checkBoxAutoSave, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.checkBoxAutoWrite, 0, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(209, 116);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(200, 55);
            this.tableLayoutPanel11.TabIndex = 9;
            // 
            // checkBoxAutoSave
            // 
            this.checkBoxAutoSave.AutoSize = true;
            this.checkBoxAutoSave.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoSave.Location = new System.Drawing.Point(3, 30);
            this.checkBoxAutoSave.Name = "checkBoxAutoSave";
            this.checkBoxAutoSave.Size = new System.Drawing.Size(194, 22);
            this.checkBoxAutoSave.TabIndex = 4;
            this.checkBoxAutoSave.Text = "Автосохранение";
            this.checkBoxAutoSave.UseVisualStyleBackColor = true;
            this.checkBoxAutoSave.CheckedChanged += new System.EventHandler(this.checkBoxAutoSave_CheckedChanged);
            // 
            // checkBoxAutoWrite
            // 
            this.checkBoxAutoWrite.AutoSize = true;
            this.checkBoxAutoWrite.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxAutoWrite.Location = new System.Drawing.Point(3, 3);
            this.checkBoxAutoWrite.Name = "checkBoxAutoWrite";
            this.checkBoxAutoWrite.Size = new System.Drawing.Size(194, 21);
            this.checkBoxAutoWrite.TabIndex = 9;
            this.checkBoxAutoWrite.Text = "Автоввод";
            this.checkBoxAutoWrite.UseVisualStyleBackColor = true;
            this.checkBoxAutoWrite.CheckedChanged += new System.EventHandler(this.checkBoxAutoWrite_CheckedChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.flowLayoutPanel1);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(415, 48);
            this.groupBox7.Name = "groupBox7";
            this.tableLayoutPanel3.SetRowSpan(this.groupBox7, 2);
            this.groupBox7.Size = new System.Drawing.Size(244, 123);
            this.groupBox7.TabIndex = 10;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Сохранение значения";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowLayoutPanel1.Controls.Add(this.tabControlExcel);
            this.flowLayoutPanel1.Controls.Add(this.textBoxNameServer);
            this.flowLayoutPanel1.Controls.Add(this.groupBoxPasswordServer);
            this.flowLayoutPanel1.Controls.Add(this.checkBoxCurrentCell);
            this.flowLayoutPanel1.Controls.Add(this.groupBox8);
            this.flowLayoutPanel1.Controls.Add(this.groupBoxValuesThis);
            this.flowLayoutPanel1.Controls.Add(this.groupBox9);
            this.flowLayoutPanel1.Controls.Add(this.checkBoxRunNotificationWrite);
            this.flowLayoutPanel1.Controls.Add(this.checkBoxRunNotificationSave);
            this.flowLayoutPanel1.Controls.Add(this.checkBoxNoAllowPutByNet);
            this.flowLayoutPanel1.Controls.Add(this.groupBox10);
            this.flowLayoutPanel1.Controls.Add(this.groupBox11);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 30);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(238, 90);
            this.flowLayoutPanel1.TabIndex = 0;
            this.flowLayoutPanel1.WrapContents = false;
            this.flowLayoutPanel1.SizeChanged += new System.EventHandler(this.flowLayoutPanel1_SizeChanged);
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // tabControlExcel
            // 
            this.tabControlExcel.Controls.Add(this.Строка);
            this.tabControlExcel.Controls.Add(this.Столбец);
            this.tabControlExcel.Location = new System.Drawing.Point(3, 3);
            this.tabControlExcel.Name = "tabControlExcel";
            this.tabControlExcel.SelectedIndex = 0;
            this.tabControlExcel.Size = new System.Drawing.Size(204, 300);
            this.tabControlExcel.TabIndex = 0;
            this.tabControlExcel.Visible = false;
            // 
            // Строка
            // 
            this.Строка.Controls.Add(this.numbericRowAdd);
            this.Строка.Controls.Add(this.checkBoxRowAdd);
            this.Строка.Controls.Add(this.numbericRows);
            this.Строка.Location = new System.Drawing.Point(4, 30);
            this.Строка.Name = "Строка";
            this.Строка.Padding = new System.Windows.Forms.Padding(3);
            this.Строка.Size = new System.Drawing.Size(196, 266);
            this.Строка.TabIndex = 0;
            this.Строка.Text = "Строка";
            this.Строка.UseVisualStyleBackColor = true;
            // 
            // checkBoxRowAdd
            // 
            this.checkBoxRowAdd.AutoSize = true;
            this.checkBoxRowAdd.Location = new System.Drawing.Point(3, 117);
            this.checkBoxRowAdd.Name = "checkBoxRowAdd";
            this.checkBoxRowAdd.Size = new System.Drawing.Size(138, 25);
            this.checkBoxRowAdd.TabIndex = 1;
            this.checkBoxRowAdd.Text = "Увеличивать";
            this.checkBoxRowAdd.UseVisualStyleBackColor = true;
            this.checkBoxRowAdd.CheckedChanged += new System.EventHandler(this.checkBoxRowAdd_CheckedChanged);
            // 
            // Столбец
            // 
            this.Столбец.Controls.Add(this.numericAddColumn);
            this.Столбец.Controls.Add(this.checkBoxChangeColumn);
            this.Столбец.Controls.Add(this.numbericColumns);
            this.Столбец.Location = new System.Drawing.Point(4, 30);
            this.Столбец.Name = "Столбец";
            this.Столбец.Padding = new System.Windows.Forms.Padding(3);
            this.Столбец.Size = new System.Drawing.Size(196, 266);
            this.Столбец.TabIndex = 1;
            this.Столбец.Text = "Столбец";
            this.Столбец.UseVisualStyleBackColor = true;
            // 
            // checkBoxChangeColumn
            // 
            this.checkBoxChangeColumn.AutoSize = true;
            this.checkBoxChangeColumn.Location = new System.Drawing.Point(6, 121);
            this.checkBoxChangeColumn.Name = "checkBoxChangeColumn";
            this.checkBoxChangeColumn.Size = new System.Drawing.Size(138, 25);
            this.checkBoxChangeColumn.TabIndex = 2;
            this.checkBoxChangeColumn.Text = "Увеличивать";
            this.checkBoxChangeColumn.UseVisualStyleBackColor = true;
            this.checkBoxChangeColumn.CheckedChanged += new System.EventHandler(this.checkBoxChangeColumn_CheckedChanged);
            // 
            // groupBoxPasswordServer
            // 
            this.groupBoxPasswordServer.Controls.Add(this.tableLayoutPanel16);
            this.groupBoxPasswordServer.Location = new System.Drawing.Point(3, 427);
            this.groupBoxPasswordServer.Name = "groupBoxPasswordServer";
            this.groupBoxPasswordServer.Size = new System.Drawing.Size(200, 160);
            this.groupBoxPasswordServer.TabIndex = 0;
            this.groupBoxPasswordServer.TabStop = false;
            this.groupBoxPasswordServer.Text = "Пароль на сервере";
            this.groupBoxPasswordServer.Visible = false;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 1;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Controls.Add(this.textBoxPasswordServer, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.checkBoxServerPasswordShow, 0, 1);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(194, 127);
            this.tableLayoutPanel16.TabIndex = 0;
            // 
            // checkBoxServerPasswordShow
            // 
            this.checkBoxServerPasswordShow.AutoSize = true;
            this.checkBoxServerPasswordShow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxServerPasswordShow.Location = new System.Drawing.Point(3, 90);
            this.checkBoxServerPasswordShow.Name = "checkBoxServerPasswordShow";
            this.checkBoxServerPasswordShow.Size = new System.Drawing.Size(188, 34);
            this.checkBoxServerPasswordShow.TabIndex = 1;
            this.checkBoxServerPasswordShow.Text = "Показывать";
            this.checkBoxServerPasswordShow.UseVisualStyleBackColor = true;
            this.checkBoxServerPasswordShow.CheckedChanged += new System.EventHandler(this.checkBoxServerPasswordShow_CheckedChanged);
            // 
            // checkBoxCurrentCell
            // 
            this.checkBoxCurrentCell.AutoSize = true;
            this.checkBoxCurrentCell.Location = new System.Drawing.Point(3, 593);
            this.checkBoxCurrentCell.Name = "checkBoxCurrentCell";
            this.checkBoxCurrentCell.Size = new System.Drawing.Size(166, 25);
            this.checkBoxCurrentCell.TabIndex = 3;
            this.checkBoxCurrentCell.Text = "Текущая ячейка";
            this.checkBoxCurrentCell.UseVisualStyleBackColor = true;
            this.checkBoxCurrentCell.Visible = false;
            this.checkBoxCurrentCell.CheckedChanged += new System.EventHandler(this.checkBoxCurrentCell_CheckedChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.comboBoxChangePoint);
            this.groupBox8.Location = new System.Drawing.Point(3, 624);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(200, 100);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Замена точки/запятой";
            // 
            // comboBoxChangePoint
            // 
            this.comboBoxChangePoint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxChangePoint.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxChangePoint.FormattingEnabled = true;
            this.comboBoxChangePoint.Location = new System.Drawing.Point(3, 30);
            this.comboBoxChangePoint.Name = "comboBoxChangePoint";
            this.comboBoxChangePoint.Size = new System.Drawing.Size(194, 29);
            this.comboBoxChangePoint.TabIndex = 0;
            this.comboBoxChangePoint.SelectedIndexChanged += new System.EventHandler(this.comboBoxChangePoint_SelectedIndexChanged);
            // 
            // groupBoxValuesThis
            // 
            this.groupBoxValuesThis.Controls.Add(this.tableLayoutPanel14);
            this.groupBoxValuesThis.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.groupBoxValuesThis.Location = new System.Drawing.Point(3, 730);
            this.groupBoxValuesThis.Name = "groupBoxValuesThis";
            this.groupBoxValuesThis.Size = new System.Drawing.Size(200, 140);
            this.groupBoxValuesThis.TabIndex = 5;
            this.groupBoxValuesThis.TabStop = false;
            this.groupBoxValuesThis.Text = "Принимающие значения";
            this.groupBoxValuesThis.Visible = false;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel14.Controls.Add(this.comboBoxValuesThis, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.buttonThisDelete, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.textBoxValueThisAdd, 0, 1);
            this.tableLayoutPanel14.Controls.Add(this.buttonThisAddClear, 1, 1);
            this.tableLayoutPanel14.Controls.Add(this.buttonThisAdd, 0, 2);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 24);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 3;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(194, 113);
            this.tableLayoutPanel14.TabIndex = 0;
            // 
            // buttonThisDelete
            // 
            this.buttonThisDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonThisDelete.Location = new System.Drawing.Point(152, 3);
            this.buttonThisDelete.Name = "buttonThisDelete";
            this.buttonThisDelete.Size = new System.Drawing.Size(39, 31);
            this.buttonThisDelete.TabIndex = 1;
            this.buttonThisDelete.Text = "<-";
            this.buttonThisDelete.UseVisualStyleBackColor = true;
            this.buttonThisDelete.Click += new System.EventHandler(this.buttonThisDelete_Click);
            // 
            // textBoxValueThisAdd
            // 
            this.textBoxValueThisAdd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxValueThisAdd.Location = new System.Drawing.Point(3, 40);
            this.textBoxValueThisAdd.Name = "textBoxValueThisAdd";
            this.textBoxValueThisAdd.Size = new System.Drawing.Size(143, 28);
            this.textBoxValueThisAdd.TabIndex = 2;
            // 
            // buttonThisAddClear
            // 
            this.buttonThisAddClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonThisAddClear.Location = new System.Drawing.Point(152, 40);
            this.buttonThisAddClear.Name = "buttonThisAddClear";
            this.buttonThisAddClear.Size = new System.Drawing.Size(39, 31);
            this.buttonThisAddClear.TabIndex = 3;
            this.buttonThisAddClear.Text = "C";
            this.buttonThisAddClear.UseVisualStyleBackColor = true;
            this.buttonThisAddClear.Click += new System.EventHandler(this.buttonThisAddClear_Click);
            // 
            // buttonThisAdd
            // 
            this.tableLayoutPanel14.SetColumnSpan(this.buttonThisAdd, 2);
            this.buttonThisAdd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonThisAdd.Location = new System.Drawing.Point(3, 77);
            this.buttonThisAdd.Name = "buttonThisAdd";
            this.buttonThisAdd.Size = new System.Drawing.Size(188, 33);
            this.buttonThisAdd.TabIndex = 4;
            this.buttonThisAdd.Text = "Добавить";
            this.buttonThisAdd.UseVisualStyleBackColor = true;
            this.buttonThisAdd.Click += new System.EventHandler(this.buttonThisAdd_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.tableLayoutPanel13);
            this.groupBox9.Location = new System.Drawing.Point(3, 876);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(200, 180);
            this.groupBox9.TabIndex = 4;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Передать значению";
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel13.Controls.Add(this.textBoxValueThis, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.buttonValueThisClear, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.buttonTranferThisRun, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.buttonTranferThisRunFromText, 0, 2);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel13.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 3;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(194, 147);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // textBoxValueThis
            // 
            this.textBoxValueThis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxValueThis.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F);
            this.textBoxValueThis.Location = new System.Drawing.Point(3, 3);
            this.textBoxValueThis.Name = "textBoxValueThis";
            this.textBoxValueThis.Size = new System.Drawing.Size(148, 28);
            this.textBoxValueThis.TabIndex = 0;
            // 
            // buttonValueThisClear
            // 
            this.buttonValueThisClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonValueThisClear.Location = new System.Drawing.Point(157, 3);
            this.buttonValueThisClear.Name = "buttonValueThisClear";
            this.buttonValueThisClear.Size = new System.Drawing.Size(34, 35);
            this.buttonValueThisClear.TabIndex = 1;
            this.buttonValueThisClear.Text = "C";
            this.buttonValueThisClear.UseVisualStyleBackColor = true;
            this.buttonValueThisClear.Click += new System.EventHandler(this.buttonValueThisClear_Click);
            // 
            // buttonTranferThisRun
            // 
            this.tableLayoutPanel13.SetColumnSpan(this.buttonTranferThisRun, 2);
            this.buttonTranferThisRun.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTranferThisRun.Location = new System.Drawing.Point(3, 44);
            this.buttonTranferThisRun.Name = "buttonTranferThisRun";
            this.buttonTranferThisRun.Size = new System.Drawing.Size(188, 47);
            this.buttonTranferThisRun.TabIndex = 2;
            this.buttonTranferThisRun.Text = "Передать из значения";
            this.buttonTranferThisRun.UseVisualStyleBackColor = true;
            this.buttonTranferThisRun.Click += new System.EventHandler(this.buttonTranferThisRun_Click);
            // 
            // buttonTranferThisRunFromText
            // 
            this.tableLayoutPanel13.SetColumnSpan(this.buttonTranferThisRunFromText, 2);
            this.buttonTranferThisRunFromText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTranferThisRunFromText.Location = new System.Drawing.Point(3, 97);
            this.buttonTranferThisRunFromText.Name = "buttonTranferThisRunFromText";
            this.buttonTranferThisRunFromText.Size = new System.Drawing.Size(188, 47);
            this.buttonTranferThisRunFromText.TabIndex = 3;
            this.buttonTranferThisRunFromText.Text = "Передать из текстового поля";
            this.buttonTranferThisRunFromText.UseVisualStyleBackColor = true;
            this.buttonTranferThisRunFromText.Click += new System.EventHandler(this.buttonTranferThisRunFromText_Click);
            // 
            // checkBoxRunNotificationWrite
            // 
            this.checkBoxRunNotificationWrite.Location = new System.Drawing.Point(3, 1062);
            this.checkBoxRunNotificationWrite.Name = "checkBoxRunNotificationWrite";
            this.checkBoxRunNotificationWrite.Size = new System.Drawing.Size(200, 79);
            this.checkBoxRunNotificationWrite.TabIndex = 6;
            this.checkBoxRunNotificationWrite.Text = "Уведомлять о записи текста в значение";
            this.checkBoxRunNotificationWrite.UseVisualStyleBackColor = true;
            this.checkBoxRunNotificationWrite.CheckedChanged += new System.EventHandler(this.checkBoxRunNotificationWrite_CheckedChanged);
            // 
            // checkBoxRunNotificationSave
            // 
            this.checkBoxRunNotificationSave.Location = new System.Drawing.Point(3, 1147);
            this.checkBoxRunNotificationSave.Name = "checkBoxRunNotificationSave";
            this.checkBoxRunNotificationSave.Size = new System.Drawing.Size(200, 79);
            this.checkBoxRunNotificationSave.TabIndex = 7;
            this.checkBoxRunNotificationSave.Text = "Уведомлять о сохранении текста значения";
            this.checkBoxRunNotificationSave.UseVisualStyleBackColor = true;
            this.checkBoxRunNotificationSave.CheckedChanged += new System.EventHandler(this.checkBoxRunNotificationSave_CheckedChanged);
            // 
            // checkBoxNoAllowPutByNet
            // 
            this.checkBoxNoAllowPutByNet.Location = new System.Drawing.Point(3, 1232);
            this.checkBoxNoAllowPutByNet.Name = "checkBoxNoAllowPutByNet";
            this.checkBoxNoAllowPutByNet.Size = new System.Drawing.Size(200, 98);
            this.checkBoxNoAllowPutByNet.TabIndex = 8;
            this.checkBoxNoAllowPutByNet.Text = "Запретить получение текста для значения по сети";
            this.checkBoxNoAllowPutByNet.UseVisualStyleBackColor = true;
            this.checkBoxNoAllowPutByNet.CheckedChanged += new System.EventHandler(this.checkBoxNoAllowPutByNet_CheckedChanged);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.tableLayoutPanel15);
            this.groupBox10.Location = new System.Drawing.Point(3, 1336);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(200, 178);
            this.groupBox10.TabIndex = 9;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Сетевой буфер";
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 1;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Controls.Add(this.buttonShowNetBuffer, 0, 3);
            this.tableLayoutPanel15.Controls.Add(this.buttonClearNetBuffer, 0, 1);
            this.tableLayoutPanel15.Controls.Add(this.buttonLoadNet, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.buttonNetBoth, 0, 2);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 4;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.99813F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(194, 145);
            this.tableLayoutPanel15.TabIndex = 0;
            // 
            // buttonShowNetBuffer
            // 
            this.buttonShowNetBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonShowNetBuffer.Location = new System.Drawing.Point(3, 111);
            this.buttonShowNetBuffer.Name = "buttonShowNetBuffer";
            this.buttonShowNetBuffer.Size = new System.Drawing.Size(188, 31);
            this.buttonShowNetBuffer.TabIndex = 3;
            this.buttonShowNetBuffer.Text = "Просмотреть текст";
            this.buttonShowNetBuffer.UseVisualStyleBackColor = true;
            this.buttonShowNetBuffer.Click += new System.EventHandler(this.buttonShowNetBuffer_Click);
            // 
            // buttonClearNetBuffer
            // 
            this.buttonClearNetBuffer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClearNetBuffer.Location = new System.Drawing.Point(3, 39);
            this.buttonClearNetBuffer.Name = "buttonClearNetBuffer";
            this.buttonClearNetBuffer.Size = new System.Drawing.Size(188, 30);
            this.buttonClearNetBuffer.TabIndex = 1;
            this.buttonClearNetBuffer.Text = "Очистить";
            this.buttonClearNetBuffer.UseVisualStyleBackColor = true;
            this.buttonClearNetBuffer.Click += new System.EventHandler(this.buttonClearNetBuffer_Click);
            // 
            // buttonLoadNet
            // 
            this.buttonLoadNet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonLoadNet.Location = new System.Drawing.Point(3, 3);
            this.buttonLoadNet.Name = "buttonLoadNet";
            this.buttonLoadNet.Size = new System.Drawing.Size(188, 30);
            this.buttonLoadNet.TabIndex = 0;
            this.buttonLoadNet.Text = "Загрузить текст";
            this.buttonLoadNet.UseVisualStyleBackColor = true;
            this.buttonLoadNet.Click += new System.EventHandler(this.buttonLoadNet_Click);
            // 
            // buttonNetBoth
            // 
            this.buttonNetBoth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonNetBoth.Location = new System.Drawing.Point(3, 75);
            this.buttonNetBoth.Name = "buttonNetBoth";
            this.buttonNetBoth.Size = new System.Drawing.Size(188, 30);
            this.buttonNetBoth.TabIndex = 2;
            this.buttonNetBoth.Text = "Оба действия";
            this.buttonNetBoth.UseVisualStyleBackColor = true;
            this.buttonNetBoth.Click += new System.EventHandler(this.buttonNetBoth_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.tableLayoutPanel17);
            this.groupBox11.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox11.Location = new System.Drawing.Point(3, 1520);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(200, 194);
            this.groupBox11.TabIndex = 10;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Пароль для получения по сети";
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel17.ColumnCount = 1;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.Controls.Add(this.checkBoxNessasirlyAuth, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.textBoxPassword, 0, 2);
            this.tableLayoutPanel17.Controls.Add(this.checkBoxShowPassword, 0, 3);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 4;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(194, 164);
            this.tableLayoutPanel17.TabIndex = 0;
            // 
            // checkBoxNessasirlyAuth
            // 
            this.checkBoxNessasirlyAuth.AutoSize = true;
            this.checkBoxNessasirlyAuth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxNessasirlyAuth.Location = new System.Drawing.Point(3, 13);
            this.checkBoxNessasirlyAuth.Name = "checkBoxNessasirlyAuth";
            this.checkBoxNessasirlyAuth.Size = new System.Drawing.Size(188, 34);
            this.checkBoxNessasirlyAuth.TabIndex = 0;
            this.checkBoxNessasirlyAuth.Text = "Обязательная авторизация";
            this.checkBoxNessasirlyAuth.UseVisualStyleBackColor = true;
            this.checkBoxNessasirlyAuth.CheckedChanged += new System.EventHandler(this.checkBoxNessasirlyAuth_CheckedChanged);
            // 
            // checkBoxShowPassword
            // 
            this.checkBoxShowPassword.AutoSize = true;
            this.checkBoxShowPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxShowPassword.Location = new System.Drawing.Point(3, 127);
            this.checkBoxShowPassword.Name = "checkBoxShowPassword";
            this.checkBoxShowPassword.Size = new System.Drawing.Size(188, 34);
            this.checkBoxShowPassword.TabIndex = 2;
            this.checkBoxShowPassword.Text = "Показывать пароль";
            this.checkBoxShowPassword.UseVisualStyleBackColor = true;
            this.checkBoxShowPassword.CheckedChanged += new System.EventHandler(this.checkBoxShowPassword_CheckedChanged);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.groupBox3, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.labelName, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.groupBox4, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.groupBox6, 1, 2);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(259, 187);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 3;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.54335F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.19774F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.76836F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(666, 207);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.действиеСФайломToolStripMenuItem,
            this.листВФайлеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(222, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // действиеСФайломToolStripMenuItem
            // 
            this.действиеСФайломToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem,
            this.buttonFileDelete,
            this.buttonRename,
            this.buttonFileFind,
            this.buttonExcelVisual,
            this.обновитьToolStripMenuItem,
            this.ReopenExcel,
            this.копироватьНазваниеToolStripMenuItem,
            this.задатьToolStripMenuItem});
            this.действиеСФайломToolStripMenuItem.Name = "действиеСФайломToolStripMenuItem";
            this.действиеСФайломToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.действиеСФайломToolStripMenuItem.Text = "Файл";
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CreateNoneFile,
            this.excelToolStripMenuItem,
            this.buttonTcpClientAdd,
            this.CreateFileThis,
            this.buttonUdpClientAdd,
            this.путьКФайлуToolStripMenuItem});
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(275, 26);
            this.добавитьToolStripMenuItem.Text = "Добавить";
            this.добавитьToolStripMenuItem.Click += new System.EventHandler(this.добавитьToolStripMenuItem_Click);
            // 
            // CreateNoneFile
            // 
            this.CreateNoneFile.Name = "CreateNoneFile";
            this.CreateNoneFile.Size = new System.Drawing.Size(270, 26);
            this.CreateNoneFile.Text = "Простой файл";
            this.CreateNoneFile.Click += new System.EventHandler(this.CreateNoneFile_Click);
            // 
            // excelToolStripMenuItem
            // 
            this.excelToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonExcelOpen,
            this.buttonExcelCreate});
            this.excelToolStripMenuItem.Name = "excelToolStripMenuItem";
            this.excelToolStripMenuItem.Size = new System.Drawing.Size(270, 26);
            this.excelToolStripMenuItem.Text = "Excel-таблица";
            this.excelToolStripMenuItem.Click += new System.EventHandler(this.excelToolStripMenuItem_Click);
            // 
            // buttonExcelOpen
            // 
            this.buttonExcelOpen.Name = "buttonExcelOpen";
            this.buttonExcelOpen.Size = new System.Drawing.Size(186, 26);
            this.buttonExcelOpen.Text = "Открыть";
            this.buttonExcelOpen.Click += new System.EventHandler(this.buttonExcelOpen_Click);
            // 
            // buttonExcelCreate
            // 
            this.buttonExcelCreate.Name = "buttonExcelCreate";
            this.buttonExcelCreate.Size = new System.Drawing.Size(186, 26);
            this.buttonExcelCreate.Text = "Создать файл";
            this.buttonExcelCreate.Click += new System.EventHandler(this.buttonExcelCreate_Click);
            // 
            // buttonTcpClientAdd
            // 
            this.buttonTcpClientAdd.Name = "buttonTcpClientAdd";
            this.buttonTcpClientAdd.Size = new System.Drawing.Size(270, 26);
            this.buttonTcpClientAdd.Text = "TCP-клиент";
            this.buttonTcpClientAdd.Click += new System.EventHandler(this.buttonTcpClientAdd_Click);
            // 
            // CreateFileThis
            // 
            this.CreateFileThis.Name = "CreateFileThis";
            this.CreateFileThis.Size = new System.Drawing.Size(270, 26);
            this.CreateFileThis.Text = "Файл на другие значения";
            this.CreateFileThis.Click += new System.EventHandler(this.CreateFileThis_Click);
            // 
            // buttonUdpClientAdd
            // 
            this.buttonUdpClientAdd.Name = "buttonUdpClientAdd";
            this.buttonUdpClientAdd.Size = new System.Drawing.Size(270, 26);
            this.buttonUdpClientAdd.Text = "UDP-клиент";
            this.buttonUdpClientAdd.Click += new System.EventHandler(this.buttonUdpClientAdd_Click);
            // 
            // путьКФайлуToolStripMenuItem
            // 
            this.путьКФайлуToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddTextFile});
            this.путьКФайлуToolStripMenuItem.Name = "путьКФайлуToolStripMenuItem";
            this.путьКФайлуToolStripMenuItem.Size = new System.Drawing.Size(270, 26);
            this.путьКФайлуToolStripMenuItem.Text = "Путь к файлу";
            // 
            // buttonAddTextFile
            // 
            this.buttonAddTextFile.Name = "buttonAddTextFile";
            this.buttonAddTextFile.Size = new System.Drawing.Size(263, 26);
            this.buttonAddTextFile.Text = "Файл на текстовый файл";
            this.buttonAddTextFile.Click += new System.EventHandler(this.buttonAddTextFile_Click);
            // 
            // buttonFileDelete
            // 
            this.buttonFileDelete.Name = "buttonFileDelete";
            this.buttonFileDelete.Size = new System.Drawing.Size(275, 26);
            this.buttonFileDelete.Text = "Удалить";
            this.buttonFileDelete.Click += new System.EventHandler(this.buttonFileDelete_Click);
            // 
            // buttonRename
            // 
            this.buttonRename.Name = "buttonRename";
            this.buttonRename.Size = new System.Drawing.Size(275, 26);
            this.buttonRename.Text = "Переименовать";
            this.buttonRename.Click += new System.EventHandler(this.buttonRename_Click);
            // 
            // buttonFileFind
            // 
            this.buttonFileFind.Name = "buttonFileFind";
            this.buttonFileFind.Size = new System.Drawing.Size(275, 26);
            this.buttonFileFind.Text = "Найти";
            this.buttonFileFind.Click += new System.EventHandler(this.buttonFileFind_Click);
            // 
            // buttonExcelVisual
            // 
            this.buttonExcelVisual.Name = "buttonExcelVisual";
            this.buttonExcelVisual.Size = new System.Drawing.Size(275, 26);
            this.buttonExcelVisual.Text = "Отобразить/Закрыть Excel";
            this.buttonExcelVisual.Click += new System.EventHandler(this.buttonExcelVisual_Click);
            // 
            // обновитьToolStripMenuItem
            // 
            this.обновитьToolStripMenuItem.Name = "обновитьToolStripMenuItem";
            this.обновитьToolStripMenuItem.Size = new System.Drawing.Size(275, 26);
            this.обновитьToolStripMenuItem.Text = "Обновить";
            this.обновитьToolStripMenuItem.Click += new System.EventHandler(this.listBoxFiles_SelectedIndexChanged);
            // 
            // ReopenExcel
            // 
            this.ReopenExcel.Name = "ReopenExcel";
            this.ReopenExcel.Size = new System.Drawing.Size(275, 26);
            this.ReopenExcel.Text = "Переоткрыть Excel-файл";
            this.ReopenExcel.Click += new System.EventHandler(this.ReopenExcel_Click);
            // 
            // копироватьНазваниеToolStripMenuItem
            // 
            this.копироватьНазваниеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCopyNameFileValue,
            this.buttonCopyNameToText,
            this.buttonCopyNameToValue});
            this.копироватьНазваниеToolStripMenuItem.Name = "копироватьНазваниеToolStripMenuItem";
            this.копироватьНазваниеToolStripMenuItem.Size = new System.Drawing.Size(275, 26);
            this.копироватьНазваниеToolStripMenuItem.Text = "Копировать название";
            // 
            // buttonCopyNameFileValue
            // 
            this.buttonCopyNameFileValue.Name = "buttonCopyNameFileValue";
            this.buttonCopyNameFileValue.Size = new System.Drawing.Size(192, 26);
            this.buttonCopyNameFileValue.Text = "Имя значения";
            this.buttonCopyNameFileValue.Click += new System.EventHandler(this.buttonCopyNameFileValue_Click);
            // 
            // buttonCopyNameToText
            // 
            this.buttonCopyNameToText.Name = "buttonCopyNameToText";
            this.buttonCopyNameToText.Size = new System.Drawing.Size(192, 26);
            this.buttonCopyNameToText.Text = "Текст";
            this.buttonCopyNameToText.Click += new System.EventHandler(this.buttonCopyNameToText_Click);
            // 
            // buttonCopyNameToValue
            // 
            this.buttonCopyNameToValue.Name = "buttonCopyNameToValue";
            this.buttonCopyNameToValue.Size = new System.Drawing.Size(192, 26);
            this.buttonCopyNameToValue.Text = "Значение";
            this.buttonCopyNameToValue.Click += new System.EventHandler(this.buttonCopyNameToValue_Click);
            // 
            // задатьToolStripMenuItem
            // 
            this.задатьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonNameByText,
            this.buttonNameByValue});
            this.задатьToolStripMenuItem.Name = "задатьToolStripMenuItem";
            this.задатьToolStripMenuItem.Size = new System.Drawing.Size(275, 26);
            this.задатьToolStripMenuItem.Text = "Задать";
            // 
            // buttonNameByText
            // 
            this.buttonNameByText.Name = "buttonNameByText";
            this.buttonNameByText.Size = new System.Drawing.Size(159, 26);
            this.buttonNameByText.Text = "Текст";
            this.buttonNameByText.Click += new System.EventHandler(this.buttonNameByText_Click);
            // 
            // buttonNameByValue
            // 
            this.buttonNameByValue.Name = "buttonNameByValue";
            this.buttonNameByValue.Size = new System.Drawing.Size(159, 26);
            this.buttonNameByValue.Text = "Значение";
            this.buttonNameByValue.Click += new System.EventHandler(this.buttonNameByValue_Click);
            // 
            // листВФайлеToolStripMenuItem
            // 
            this.листВФайлеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonAddList,
            this.buttonDeleteList,
            this.buttonRenameList,
            this.buttonListFind,
            this.обновитьToolStripMenuItem1});
            this.листВФайлеToolStripMenuItem.Name = "листВФайлеToolStripMenuItem";
            this.листВФайлеToolStripMenuItem.Size = new System.Drawing.Size(114, 24);
            this.листВФайлеToolStripMenuItem.Text = "Лист в файле";
            // 
            // buttonAddList
            // 
            this.buttonAddList.Name = "buttonAddList";
            this.buttonAddList.Size = new System.Drawing.Size(204, 26);
            this.buttonAddList.Text = "Добавить";
            this.buttonAddList.Click += new System.EventHandler(this.buttonAddList_Click);
            // 
            // buttonDeleteList
            // 
            this.buttonDeleteList.Name = "buttonDeleteList";
            this.buttonDeleteList.Size = new System.Drawing.Size(204, 26);
            this.buttonDeleteList.Text = "Удалить";
            this.buttonDeleteList.Click += new System.EventHandler(this.buttonDeleteList_Click);
            // 
            // buttonRenameList
            // 
            this.buttonRenameList.Name = "buttonRenameList";
            this.buttonRenameList.Size = new System.Drawing.Size(204, 26);
            this.buttonRenameList.Text = "Переименовать";
            this.buttonRenameList.Click += new System.EventHandler(this.buttonRenameList_Click);
            // 
            // buttonListFind
            // 
            this.buttonListFind.Name = "buttonListFind";
            this.buttonListFind.Size = new System.Drawing.Size(204, 26);
            this.buttonListFind.Text = "Найти";
            this.buttonListFind.Click += new System.EventHandler(this.buttonListFind_Click);
            // 
            // обновитьToolStripMenuItem1
            // 
            this.обновитьToolStripMenuItem1.Name = "обновитьToolStripMenuItem1";
            this.обновитьToolStripMenuItem1.Size = new System.Drawing.Size(204, 26);
            this.обновитьToolStripMenuItem1.Text = "Обновить";
            this.обновитьToolStripMenuItem1.Click += new System.EventHandler(this.listBoxLists_SelectedIndexChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel7);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 49);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(216, 87);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Название";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel7.Controls.Add(this.textBoxName, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.buttonNameClear, 1, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(210, 54);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // textBoxName
            // 
            this.textBoxName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxName.Location = new System.Drawing.Point(3, 3);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(154, 34);
            this.textBoxName.TabIndex = 0;
            // 
            // buttonNameClear
            // 
            this.buttonNameClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonNameClear.Location = new System.Drawing.Point(163, 3);
            this.buttonNameClear.Name = "buttonNameClear";
            this.buttonNameClear.Size = new System.Drawing.Size(44, 48);
            this.buttonNameClear.TabIndex = 1;
            this.buttonNameClear.Text = "C";
            this.buttonNameClear.UseVisualStyleBackColor = true;
            this.buttonNameClear.Click += new System.EventHandler(this.buttonNameClear_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelName.Location = new System.Drawing.Point(3, 139);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(216, 68);
            this.labelName.TabIndex = 2;
            this.labelName.Text = "label2";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox4
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.groupBox4, 2);
            this.groupBox4.Controls.Add(this.tableLayoutPanel5);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(225, 3);
            this.groupBox4.Name = "groupBox4";
            this.tableLayoutPanel4.SetRowSpan(this.groupBox4, 2);
            this.groupBox4.Size = new System.Drawing.Size(438, 133);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Значения";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.listBoxValues, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.menuStrip2, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel8, 1, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(432, 100);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // listBoxValues
            // 
            this.listBoxValues.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxValues.FormattingEnabled = true;
            this.listBoxValues.ItemHeight = 21;
            this.listBoxValues.Location = new System.Drawing.Point(3, 3);
            this.listBoxValues.Name = "listBoxValues";
            this.tableLayoutPanel5.SetRowSpan(this.listBoxValues, 2);
            this.listBoxValues.Size = new System.Drawing.Size(210, 94);
            this.listBoxValues.TabIndex = 0;
            this.listBoxValues.Click += new System.EventHandler(this.listBoxValues_SelectedIndexChanged);
            this.listBoxValues.SelectedIndexChanged += new System.EventHandler(this.listBoxValues_SelectedIndexChanged);
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonValueView});
            this.menuStrip2.Location = new System.Drawing.Point(216, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(1);
            this.menuStrip2.Size = new System.Drawing.Size(216, 30);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // buttonValueView
            // 
            this.buttonValueView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem1,
            this.buttonDeleteValue,
            this.buttonValueRename,
            this.buttonValueFind,
            this.buttonFindByAll,
            this.копироватьИмяToolStripMenuItem,
            this.buttonJsonDateView,
            this.buttonRezervNamesView,
            this.buttonValueUpdate,
            this.buttonTranferValue});
            this.buttonValueView.Name = "buttonValueView";
            this.buttonValueView.Size = new System.Drawing.Size(104, 25);
            this.buttonValueView.Text = "Значение";
            // 
            // добавитьToolStripMenuItem1
            // 
            this.добавитьToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonValueAdd,
            this.buttonAddValueWithName});
            this.добавитьToolStripMenuItem1.Name = "добавитьToolStripMenuItem1";
            this.добавитьToolStripMenuItem1.Size = new System.Drawing.Size(469, 26);
            this.добавитьToolStripMenuItem1.Text = "Добавить";
            this.добавитьToolStripMenuItem1.Click += new System.EventHandler(this.добавитьToolStripMenuItem1_Click);
            // 
            // buttonValueAdd
            // 
            this.buttonValueAdd.Name = "buttonValueAdd";
            this.buttonValueAdd.Size = new System.Drawing.Size(177, 26);
            this.buttonValueAdd.Text = "Добавить";
            this.buttonValueAdd.Click += new System.EventHandler(this.buttonValueAdd_Click);
            // 
            // buttonAddValueWithName
            // 
            this.buttonAddValueWithName.Name = "buttonAddValueWithName";
            this.buttonAddValueWithName.Size = new System.Drawing.Size(177, 26);
            this.buttonAddValueWithName.Text = "С именем";
            this.buttonAddValueWithName.Click += new System.EventHandler(this.buttonAddValueWithName_Click);
            // 
            // buttonDeleteValue
            // 
            this.buttonDeleteValue.Name = "buttonDeleteValue";
            this.buttonDeleteValue.Size = new System.Drawing.Size(469, 26);
            this.buttonDeleteValue.Text = "Удалить";
            this.buttonDeleteValue.Click += new System.EventHandler(this.buttonDeleteValue_Click);
            // 
            // buttonValueRename
            // 
            this.buttonValueRename.Name = "buttonValueRename";
            this.buttonValueRename.Size = new System.Drawing.Size(469, 26);
            this.buttonValueRename.Text = "Переименовать";
            this.buttonValueRename.Click += new System.EventHandler(this.buttonValueRename_Click);
            // 
            // buttonValueFind
            // 
            this.buttonValueFind.Name = "buttonValueFind";
            this.buttonValueFind.Size = new System.Drawing.Size(469, 26);
            this.buttonValueFind.Text = "Найти";
            this.buttonValueFind.Click += new System.EventHandler(this.buttonValueFind_Click);
            // 
            // buttonFindByAll
            // 
            this.buttonFindByAll.Name = "buttonFindByAll";
            this.buttonFindByAll.Size = new System.Drawing.Size(469, 26);
            this.buttonFindByAll.Text = "Найти среди всех";
            this.buttonFindByAll.Click += new System.EventHandler(this.buttonFindByAll_Click);
            // 
            // копироватьИмяToolStripMenuItem
            // 
            this.копироватьИмяToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonCopyValueNameText,
            this.buttonCopyValueNameValue,
            this.buttonValueNameCopyName});
            this.копироватьИмяToolStripMenuItem.Name = "копироватьИмяToolStripMenuItem";
            this.копироватьИмяToolStripMenuItem.Size = new System.Drawing.Size(469, 26);
            this.копироватьИмяToolStripMenuItem.Text = "Копировать имя";
            // 
            // buttonCopyValueNameText
            // 
            this.buttonCopyValueNameText.Name = "buttonCopyValueNameText";
            this.buttonCopyValueNameText.Size = new System.Drawing.Size(232, 26);
            this.buttonCopyValueNameText.Text = "Текст";
            this.buttonCopyValueNameText.Click += new System.EventHandler(this.buttonCopyValueNameText_Click);
            // 
            // buttonCopyValueNameValue
            // 
            this.buttonCopyValueNameValue.Name = "buttonCopyValueNameValue";
            this.buttonCopyValueNameValue.Size = new System.Drawing.Size(232, 26);
            this.buttonCopyValueNameValue.Text = "Значение";
            this.buttonCopyValueNameValue.Click += new System.EventHandler(this.buttonCopyValueNameValue_Click);
            // 
            // buttonValueNameCopyName
            // 
            this.buttonValueNameCopyName.Name = "buttonValueNameCopyName";
            this.buttonValueNameCopyName.Size = new System.Drawing.Size(232, 26);
            this.buttonValueNameCopyName.Text = "Название файла";
            this.buttonValueNameCopyName.Click += new System.EventHandler(this.buttonValueNameCopyName_Click);
            // 
            // buttonJsonDateView
            // 
            this.buttonJsonDateView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonJsonDataViewDialog,
            this.buttonJsonDataViewText});
            this.buttonJsonDateView.Name = "buttonJsonDateView";
            this.buttonJsonDateView.Size = new System.Drawing.Size(469, 26);
            this.buttonJsonDateView.Text = "Json-cтруктура передаваемого текста";
            // 
            // buttonJsonDataViewDialog
            // 
            this.buttonJsonDataViewDialog.Name = "buttonJsonDataViewDialog";
            this.buttonJsonDataViewDialog.Size = new System.Drawing.Size(259, 26);
            this.buttonJsonDataViewDialog.Text = "Диалоговым окном";
            this.buttonJsonDataViewDialog.Click += new System.EventHandler(this.buttonJsonDataViewDialog_Click);
            // 
            // buttonJsonDataViewText
            // 
            this.buttonJsonDataViewText.Name = "buttonJsonDataViewText";
            this.buttonJsonDataViewText.Size = new System.Drawing.Size(259, 26);
            this.buttonJsonDataViewText.Text = "В текстовое поле";
            this.buttonJsonDataViewText.Click += new System.EventHandler(this.buttonJsonDataViewText_Click);
            // 
            // buttonRezervNamesView
            // 
            this.buttonRezervNamesView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.butonReservNamesViewDialog,
            this.butonReservNamesViewText});
            this.buttonRezervNamesView.Name = "buttonRezervNamesView";
            this.buttonRezervNamesView.Size = new System.Drawing.Size(469, 26);
            this.buttonRezervNamesView.Text = "Зарезервированные имена";
            // 
            // butonReservNamesViewDialog
            // 
            this.butonReservNamesViewDialog.Name = "butonReservNamesViewDialog";
            this.butonReservNamesViewDialog.Size = new System.Drawing.Size(259, 26);
            this.butonReservNamesViewDialog.Text = "Диалоговым окном";
            this.butonReservNamesViewDialog.Click += new System.EventHandler(this.buttonRezervNamesView_Click);
            // 
            // butonReservNamesViewText
            // 
            this.butonReservNamesViewText.Name = "butonReservNamesViewText";
            this.butonReservNamesViewText.Size = new System.Drawing.Size(259, 26);
            this.butonReservNamesViewText.Text = "В текстовое поле";
            this.butonReservNamesViewText.Click += new System.EventHandler(this.butonReservNamesViewText_Click);
            // 
            // buttonValueUpdate
            // 
            this.buttonValueUpdate.Name = "buttonValueUpdate";
            this.buttonValueUpdate.Size = new System.Drawing.Size(469, 26);
            this.buttonValueUpdate.Text = "Обновить";
            this.buttonValueUpdate.Click += new System.EventHandler(this.listBoxValues_SelectedIndexChanged);
            // 
            // buttonTranferValue
            // 
            this.buttonTranferValue.Name = "buttonTranferValue";
            this.buttonTranferValue.Size = new System.Drawing.Size(469, 26);
            this.buttonTranferValue.Text = "Передать на значение с введённым именем";
            this.buttonTranferValue.Click += new System.EventHandler(this.buttonTranferValue_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel8.Controls.Add(this.buttonValueNameClear, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.textBoxValueName, 0, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(219, 53);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(210, 44);
            this.tableLayoutPanel8.TabIndex = 2;
            // 
            // buttonValueNameClear
            // 
            this.buttonValueNameClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonValueNameClear.Location = new System.Drawing.Point(163, 3);
            this.buttonValueNameClear.Name = "buttonValueNameClear";
            this.buttonValueNameClear.Size = new System.Drawing.Size(44, 38);
            this.buttonValueNameClear.TabIndex = 3;
            this.buttonValueNameClear.Text = "C";
            this.buttonValueNameClear.UseVisualStyleBackColor = true;
            this.buttonValueNameClear.Click += new System.EventHandler(this.buttonValueNameClear_Click);
            // 
            // textBoxValueName
            // 
            this.textBoxValueName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxValueName.Location = new System.Drawing.Point(3, 3);
            this.textBoxValueName.Name = "textBoxValueName";
            this.textBoxValueName.Size = new System.Drawing.Size(154, 34);
            this.textBoxValueName.TabIndex = 2;
            // 
            // groupBox6
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.groupBox6, 2);
            this.groupBox6.Controls.Add(this.tableLayoutPanel12);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(225, 142);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(438, 62);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Путь к файлу/Адрес-порт сервера";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel12.Controls.Add(this.textBoxPath, 0, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(432, 29);
            this.tableLayoutPanel12.TabIndex = 0;
            // 
            // textBoxPath
            // 
            this.textBoxPath.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel12.SetColumnSpan(this.textBoxPath, 2);
            this.textBoxPath.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxPath.Location = new System.Drawing.Point(3, 3);
            this.textBoxPath.Name = "textBoxPath";
            this.textBoxPath.ReadOnly = true;
            this.textBoxPath.Size = new System.Drawing.Size(426, 34);
            this.textBoxPath.TabIndex = 0;
            // 
            // openExcelFile
            // 
            this.openExcelFile.FileName = "openFileDialog1";
            this.openExcelFile.Filter = "Excel-файлы (*.xls; *xlsx)|*.xls;*.xlsx|Все файлы (*.*)|*.*";
            // 
            // saveExcelFile
            // 
            this.saveExcelFile.Filter = "Excel-файлы (*.xls; *xlsx)|*.xls;*.xlsx|Все файлы (*.*)|*.*";
            // 
            // timerTCP
            // 
            this.timerTCP.Tick += new System.EventHandler(this.timerTCP_Tick);
            // 
            // notifyIconThis
            // 
            this.notifyIconThis.Text = "notifyIcon1";
            this.notifyIconThis.Visible = true;
            // 
            // notifyIconValue
            // 
            this.notifyIconValue.Text = "notifyIcon1";
            this.notifyIconValue.Visible = true;
            // 
            // numbericRowAdd
            // 
            this.numbericRowAdd.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericRowAdd.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericRowAdd.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericRowAdd.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericRowAdd.Location = new System.Drawing.Point(0, 140);
            this.numbericRowAdd.Macimum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numbericRowAdd.Margin = new System.Windows.Forms.Padding(4);
            this.numbericRowAdd.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numbericRowAdd.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numbericRowAdd.Name = "numbericRowAdd";
            this.numbericRowAdd.NoReadOnly = true;
            this.numbericRowAdd.ReadOnly = false;
            this.numbericRowAdd.Size = new System.Drawing.Size(191, 110);
            this.numbericRowAdd.TabIndex = 2;
            this.numbericRowAdd.Title = "Увеличивать на";
            this.numbericRowAdd.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericRowAdd.VisibleOK = true;
            this.numbericRowAdd.ValueChanged += new TableAIS.ValueChangedControl(this.numbericRowAdd_ValueChanged);
            // 
            // numbericRows
            // 
            this.numbericRows.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericRows.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericRows.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericRows.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericRows.Location = new System.Drawing.Point(-3, 7);
            this.numbericRows.Macimum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numbericRows.Margin = new System.Windows.Forms.Padding(4);
            this.numbericRows.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numbericRows.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericRows.Name = "numbericRows";
            this.numbericRows.NoReadOnly = true;
            this.numbericRows.ReadOnly = false;
            this.numbericRows.Size = new System.Drawing.Size(180, 110);
            this.numbericRows.TabIndex = 0;
            this.numbericRows.Title = "Номер";
            this.numbericRows.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericRows.VisibleOK = true;
            this.numbericRows.ValueChanged += new TableAIS.ValueChangedControl(this.numbericRows_ValueChanged);
            // 
            // numericAddColumn
            // 
            this.numericAddColumn.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numericAddColumn.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numericAddColumn.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericAddColumn.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericAddColumn.Location = new System.Drawing.Point(0, 140);
            this.numericAddColumn.Macimum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericAddColumn.Margin = new System.Windows.Forms.Padding(5);
            this.numericAddColumn.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericAddColumn.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericAddColumn.Name = "numericAddColumn";
            this.numericAddColumn.NoReadOnly = true;
            this.numericAddColumn.ReadOnly = false;
            this.numericAddColumn.Size = new System.Drawing.Size(191, 110);
            this.numericAddColumn.TabIndex = 3;
            this.numericAddColumn.Title = "Увеличивать на";
            this.numericAddColumn.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numericAddColumn.VisibleOK = false;
            this.numericAddColumn.ValueChanged += new TableAIS.ValueChangedControl(this.numbericUser1_ValueChanged);
            // 
            // numbericColumns
            // 
            this.numbericColumns.Default = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericColumns.DefaultValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numbericColumns.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericColumns.Incriment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericColumns.Location = new System.Drawing.Point(8, 5);
            this.numbericColumns.Macimum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numbericColumns.Margin = new System.Windows.Forms.Padding(5);
            this.numbericColumns.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numbericColumns.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericColumns.Name = "numbericColumns";
            this.numbericColumns.NoReadOnly = true;
            this.numbericColumns.ReadOnly = false;
            this.numbericColumns.Size = new System.Drawing.Size(180, 110);
            this.numbericColumns.TabIndex = 1;
            this.numbericColumns.Title = "Номер";
            this.numbericColumns.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numbericColumns.VisibleOK = false;
            this.numbericColumns.ValueChanged += new TableAIS.ValueChangedControl(this.numbericColumns_ValueChanged);
            // 
            // textBoxNameServer
            // 
            this.textBoxNameServer.AllowNegative = true;
            this.textBoxNameServer.ClearingByReadonly = false;
            this.textBoxNameServer.EnterAllow = true;
            this.textBoxNameServer.Location = new System.Drawing.Point(4, 310);
            this.textBoxNameServer.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNameServer.MultiLine = false;
            this.textBoxNameServer.Name = "textBoxNameServer";
            this.textBoxNameServer.NoReadOnly = true;
            this.textBoxNameServer.ReadOnly = false;
            this.textBoxNameServer.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxNameServer.SelectionStart = 0;
            this.textBoxNameServer.Size = new System.Drawing.Size(200, 110);
            this.textBoxNameServer.TabIndex = 2;
            this.textBoxNameServer.TextWithLineBreaks = "";
            this.textBoxNameServer.Title = "Значение на сервере";
            this.textBoxNameServer.UseSystemPasswordChar = false;
            this.textBoxNameServer.Value = "";
            this.textBoxNameServer.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxNameServer.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxNameServer.ValueText = "";
            this.textBoxNameServer.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxNameServer.ValueWithLineBreaks = "";
            this.textBoxNameServer.Visible = false;
            this.textBoxNameServer.VisibleOK = true;
            this.textBoxNameServer.ValueChanged += new TableAIS.TextValueChanged(this.textBoxNameServer_ValueChanged);
            // 
            // textBoxPasswordServer
            // 
            this.textBoxPasswordServer.AllowNegative = true;
            this.textBoxPasswordServer.ClearingByReadonly = false;
            this.textBoxPasswordServer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxPasswordServer.EnterAllow = true;
            this.textBoxPasswordServer.Location = new System.Drawing.Point(4, 4);
            this.textBoxPasswordServer.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPasswordServer.MultiLine = false;
            this.textBoxPasswordServer.Name = "textBoxPasswordServer";
            this.textBoxPasswordServer.NoReadOnly = true;
            this.textBoxPasswordServer.ReadOnly = false;
            this.textBoxPasswordServer.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxPasswordServer.SelectionStart = 0;
            this.textBoxPasswordServer.Size = new System.Drawing.Size(186, 79);
            this.textBoxPasswordServer.TabIndex = 0;
            this.textBoxPasswordServer.TextWithLineBreaks = "";
            this.textBoxPasswordServer.Title = "Пароль";
            this.textBoxPasswordServer.UseSystemPasswordChar = true;
            this.textBoxPasswordServer.Value = "";
            this.textBoxPasswordServer.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxPasswordServer.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxPasswordServer.ValueText = "";
            this.textBoxPasswordServer.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxPasswordServer.ValueWithLineBreaks = "";
            this.textBoxPasswordServer.VisibleOK = false;
            this.textBoxPasswordServer.ValueChanged += new TableAIS.TextValueChanged(this.textBoxPasswordServer_ValueChanged);
            // 
            // comboBoxValuesThis
            // 
            this.comboBoxValuesThis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxValuesThis.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxValuesThis.DropDownWidth = 200;
            this.comboBoxValuesThis.FormattingEnabled = true;
            this.comboBoxValuesThis.Location = new System.Drawing.Point(3, 3);
            this.comboBoxValuesThis.Name = "comboBoxValuesThis";
            this.comboBoxValuesThis.Size = new System.Drawing.Size(143, 24);
            this.comboBoxValuesThis.TabIndex = 0;
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.AllowNegative = true;
            this.textBoxPassword.ClearingByReadonly = false;
            this.textBoxPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxPassword.EnterAllow = true;
            this.textBoxPassword.Location = new System.Drawing.Point(3, 53);
            this.textBoxPassword.MultiLine = false;
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.NoReadOnly = true;
            this.textBoxPassword.ReadOnly = false;
            this.textBoxPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxPassword.SelectionStart = 0;
            this.textBoxPassword.Size = new System.Drawing.Size(188, 68);
            this.textBoxPassword.TabIndex = 1;
            this.textBoxPassword.TextWithLineBreaks = "";
            this.textBoxPassword.Title = "Пароль";
            this.textBoxPassword.UseSystemPasswordChar = true;
            this.textBoxPassword.Value = "";
            this.textBoxPassword.ValueBackColor = System.Drawing.SystemColors.Window;
            this.textBoxPassword.ValueForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxPassword.ValueText = "";
            this.textBoxPassword.ValueType = TableAIS.TextTitleType.Text;
            this.textBoxPassword.ValueWithLineBreaks = "";
            this.textBoxPassword.VisibleOK = false;
            this.textBoxPassword.ValueChanged += new TableAIS.TextValueChanged(this.textBoxPassword_ValueChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(928, 533);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(820, 500);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Основное окно";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogotip)).EndInit();
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel18.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.menuStrip4.ResumeLayout(false);
            this.menuStrip4.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.tabControlExcel.ResumeLayout(false);
            this.Строка.ResumeLayout(false);
            this.Строка.PerformLayout();
            this.Столбец.ResumeLayout(false);
            this.Столбец.PerformLayout();
            this.groupBoxPasswordServer.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel16.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBoxValuesThis.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonSecondmetr;
        private System.Windows.Forms.Button buttonFormule;
        private System.Windows.Forms.CheckBox checkBoxCopyNumber;
        private System.Windows.Forms.ListBox listBoxFiles;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBoxLogotip;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.ToolStripStatusLabel labelTime;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox listBoxLists;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TextBox textBoxValue;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem действиеСФайломToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CreateNoneFile;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.ToolStripMenuItem buttonFileDelete;
        private System.Windows.Forms.ToolStripMenuItem buttonRename;
        private System.Windows.Forms.ToolStripMenuItem листВФайлеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddList;
        private System.Windows.Forms.ToolStripMenuItem buttonDeleteList;
        private System.Windows.Forms.ToolStripMenuItem buttonRenameList;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.ListBox listBoxValues;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.ToolStripMenuItem buttonFileFind;
        private System.Windows.Forms.ToolStripMenuItem buttonListFind;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem buttonValueView;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonValueAdd;
        private System.Windows.Forms.ToolStripMenuItem buttonAddValueWithName;
        private System.Windows.Forms.TextBox textBoxValueName;
        private System.Windows.Forms.ToolStripMenuItem buttonDeleteValue;
        private System.Windows.Forms.ToolStripMenuItem buttonValueRename;
        private System.Windows.Forms.ToolStripMenuItem buttonValueFind;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Button buttonNameClear;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Button buttonValueNameClear;
        private System.Windows.Forms.ToolStripMenuItem buttonFindByAll;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.TextBox textBoxResult;
        private System.Windows.Forms.CheckBox checkBoxAutoWrite;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.ToolStripMenuItem excelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonExcelOpen;
        private System.Windows.Forms.OpenFileDialog openExcelFile;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TextBox textBoxPath;
        private System.Windows.Forms.CheckBox checkBoxAutoSave;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem ввестиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonValueClear;
        private System.Windows.Forms.ToolStripMenuItem buttonValueCreate;
        private System.Windows.Forms.ToolStripMenuItem buttonValueSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.ToolStripMenuItem buttonExcelVisual;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TabControl tabControlExcel;
        private System.Windows.Forms.TabPage Строка;
        private System.Windows.Forms.TabPage Столбец;
        private NumbericUser numbericRows;
        private NumbericUser numbericColumns;
        private System.Windows.Forms.CheckBox checkBoxRowAdd;
        private NumbericUser numbericRowAdd;
        private NumbericUser numericAddColumn;
        private System.Windows.Forms.CheckBox checkBoxChangeColumn;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox comboBoxChangePoint;
        private System.Windows.Forms.ToolStripMenuItem buttonExcelCreate;
        private System.Windows.Forms.SaveFileDialog saveExcelFile;
        private System.Windows.Forms.ToolStripMenuItem copyValueName;
        private System.Windows.Forms.ToolStripTextBox textBoxCopyName;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyValueToValue;
        private System.Windows.Forms.ToolStripMenuItem самоЗначениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyInputText;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyJsonView;
        private System.Windows.Forms.ToolStripMenuItem buttonValueJsonText;
        private System.Windows.Forms.ToolStripMenuItem buttonValueFromJsonJalue;
        private System.Windows.Forms.ToolStripMenuItem buttonTcpClientAdd;
        private System.Windows.Forms.Timer timerTCP;
        private TextBoxWithTitle textBoxNameServer;
        private System.Windows.Forms.ToolStripMenuItem buttonRezervNamesView;
        private System.Windows.Forms.ToolStripMenuItem buttonValueWriteSave;
        private System.Windows.Forms.CheckBox checkBoxCurrentCell;
        private System.Windows.Forms.ToolStripMenuItem обновитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem обновитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem buttonValueUpdate;
        private System.Windows.Forms.ToolStripMenuItem ReopenExcel;
        private System.Windows.Forms.ToolStripMenuItem buttonTranferValue;
        private System.Windows.Forms.ToolStripMenuItem вычислитьизмеритьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem секундомеромToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem калькуляторToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonFromTemesSaved;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.TextBox textBoxValueThis;
        private System.Windows.Forms.Button buttonValueThisClear;
        private System.Windows.Forms.Button buttonTranferThisRun;
        private System.Windows.Forms.ToolStripMenuItem CreateFileThis;
        private System.Windows.Forms.GroupBox groupBoxValuesThis;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private Controls.ComboBoxToolTip comboBoxValuesThis;
        private System.Windows.Forms.Button buttonThisDelete;
        private System.Windows.Forms.TextBox textBoxValueThisAdd;
        private System.Windows.Forms.Button buttonThisAddClear;
        private System.Windows.Forms.Button buttonThisAdd;
        private System.Windows.Forms.ToolStripMenuItem восстановитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSetValueText;
        private System.Windows.Forms.ToolStripMenuItem buttonUdpClientAdd;
        private System.Windows.Forms.Button buttonTranferThisRunFromText;
        private System.Windows.Forms.ToolStripMenuItem buttonSetExcelTable;
        private System.Windows.Forms.ToolStripMenuItem buttonSetFormuleFromExcel;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem записатьФормулуВExcelтаблицуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonFormuleWrite;
        private System.Windows.Forms.ToolStripMenuItem buttonValueFormuleWrite;
        private System.Windows.Forms.ToolStripMenuItem buttonGetValueFromCalculatorMemory;
        private System.Windows.Forms.ToolStripMenuItem постоянныйБуферToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToLongBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonFromLongBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonClearLongBuffer;
        private System.Windows.Forms.ToolStripMenuItem временныйБуферToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonValueToBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonValueFromBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonSaveTextBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadBufferText;
        private System.Windows.Forms.ToolStripMenuItem текстовыйФайлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonSaveTextFile;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadTextFile;
        private System.Windows.Forms.ToolStripMenuItem двоичныйКодToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonTextToBynaryCode;
        private System.Windows.Forms.ToolStripMenuItem buttonTextByBynaruCode;
        private System.Windows.Forms.ToolStripMenuItem оПриложенииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonProgramInfoDialog;
        private System.Windows.Forms.ToolStripMenuItem buttonProgramInfoToTextValue;
        private System.Windows.Forms.ToolStripMenuItem ячейкаExcelтаблицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonChangeColumn;
        private System.Windows.Forms.ToolStripMenuItem buttonChangeRow;
        private System.Windows.Forms.ToolStripMenuItem jsonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonOutput;
        private System.Windows.Forms.ToolStripMenuItem buttonFromJsonValue;
        private System.Windows.Forms.ToolStripMenuItem буферОбменаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToClipBord;
        private System.Windows.Forms.ToolStripMenuItem buttonFromClipBord;
        private System.Windows.Forms.ToolStripMenuItem списокСтроксообщенийToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonTextEditor;
        private System.Windows.Forms.ToolStripMenuItem путьКФайлуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonAddTextFile;
        private System.Windows.Forms.ToolStripMenuItem buttonClearTimeBuffer;
        private System.Windows.Forms.ToolTip toolTipInfoDoing;
        private System.Windows.Forms.NotifyIcon notifyIconThis;
        private System.Windows.Forms.ToolStripMenuItem загрузитьТекстToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonLoadText;
        private System.Windows.Forms.ToolStripMenuItem buttonInputValue;
        private System.Windows.Forms.MenuStrip menuStrip4;
        private System.Windows.Forms.ToolStripMenuItem настройкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonHostSettings;
        private System.Windows.Forms.ToolStripMenuItem buttonSecurity;
        private System.Windows.Forms.ToolStripMenuItem копироватьНазваниеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyNameFileValue;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyNameToText;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyNameToValue;
        private System.Windows.Forms.ToolStripMenuItem задатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonNameByText;
        private System.Windows.Forms.ToolStripMenuItem buttonNameByValue;
        private System.Windows.Forms.ToolStripMenuItem копироватьИмяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyValueNameText;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyValueNameValue;
        private System.Windows.Forms.ToolStripMenuItem buttonValueNameCopyName;
        private System.Windows.Forms.ToolStripMenuItem имяФайлаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonCopyTextToValueName;
        private System.Windows.Forms.ToolStripMenuItem имяФайлаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem имяЗначенияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonNetOutput;
        private System.Windows.Forms.ToolStripMenuItem buttonFromJsonValueNet;
        private System.Windows.Forms.ToolStripMenuItem butonReservNamesViewDialog;
        private System.Windows.Forms.ToolStripMenuItem butonReservNamesViewText;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonDateView;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonDataViewDialog;
        private System.Windows.Forms.ToolStripMenuItem buttonJsonDataViewText;
        private System.Windows.Forms.CheckBox checkBoxRunNotificationWrite;
        private System.Windows.Forms.CheckBox checkBoxRunNotificationSave;
        private System.Windows.Forms.NotifyIcon notifyIconValue;
        private System.Windows.Forms.CheckBox checkBoxNoAllowPutByNet;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Button buttonLoadNet;
        private System.Windows.Forms.Button buttonClearNetBuffer;
        private System.Windows.Forms.Button buttonNetBoth;
        private System.Windows.Forms.Button buttonShowNetBuffer;
        private System.Windows.Forms.ToolStripMenuItem buttonTextEditorWithMain;
        private System.Windows.Forms.ToolStripMenuItem buttonTextEditorWithValue;
        private System.Windows.Forms.GroupBox groupBoxPasswordServer;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private TextBoxWithTitle textBoxPasswordServer;
        private System.Windows.Forms.CheckBox checkBoxServerPasswordShow;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.CheckBox checkBoxNessasirlyAuth;
        private TextBoxWithTitle textBoxPassword;
        private System.Windows.Forms.CheckBox checkBoxShowPassword;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Label labelProcess;
        private System.Windows.Forms.Button buttonProcess;
        private System.Windows.Forms.Label labelAppName;
    }
}

