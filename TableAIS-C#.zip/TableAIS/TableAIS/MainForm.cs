﻿
//using Microsoft.Office.Interop.Word;
//using Microsoft.Office.Interop.Excel;
using Microsoft.VisualBasic.ApplicationServices;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
//using static System.Net.Mime.MediaTypeNames;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace TableAIS
{
    public partial class MainForm : Form
    {
        public string ValueTextByControl
        {
            get => textBoxValue.Text.Replace(Environment.NewLine, "\n");
            set => textBoxValue.Text = value.Replace(Environment.NewLine, "\n").Replace("\n", Environment.NewLine);
        }

        public string TextResult
        {
            get => textBoxResult.Text;
            set => textBoxResult.Text = value;
        }

        static FilesList files;

        public static FilesList Files
        {
            get => files;
            set => files = value;
        }
        public FilesList FilesList
        {
            get => Files;
            set => Files = value;
        }

        public void CreateExcel()
        {
            try
            {
                ExcelPatern.ExcelApplication = new Excel.Application();
            }
            catch
            {

            }
        }

        public void NoVisibleExcel()
        {
            try
            {
                ExcelPatern.ExcelApplication.Visible = false;
            }
            catch
            {
            }
        }

        public MainForm()
        {
            CreateExcel();

            InitializeComponent();

            TcpHelper.mainForm = this;


            Icon = Properties.Resources.AisTable1;
            files = new FilesList();
            files.Changed += Files_Changed;
            files.GetText += Files_GetText;
            files.ToBuffer += Files_ToBuffer;
            comboBoxChangePoint.Items.AddRange(new ChangePointList().ToArray());

        }

        private void Files_ToBuffer(string value)
        {
            Buffer.Text = value;
        }

        private void Files_GetText(string value)
        {
            textBoxValue.Text = value.Replace("\n", Environment.NewLine);
        }

        private void Files_Changed(object[] list)
        {
            int index = FileIndex;
            listBoxFiles.Items.Clear();
            listBoxFiles.Items.AddRange(list);
            FileIndex = index;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

            labelName.Text = Text;
            Text += " - " +AppName();
            notifyIconValue.Text = "Просмотреть значение - "+AppName();
            notifyIconThis.Text = Text;
            notifyIconThis.Icon = Icon;
            notifyIconValue.Icon = Icon;
            notifyIconThis.Visible = true;
            notifyIconThis.BalloonTipIcon = ToolTipIcon.Info;
            notifyIconThis.BalloonTipText = "Автоматизированная информационная система";
            notifyIconThis.BalloonTipTitle = Text;
            notifyIconThis.Click += NotifyIconThis_Click;
            notifyIconThis.BalloonTipClicked += NotifyIconThis_BalloonTipClicked;

            ValueHelper.SetTextAction = (text) => ValueTextByControl = text;
            ValueHelper.GetTextAction = () => ValueTextByControl;
        }

        private void NotifyIconThis_BalloonTipClicked(object sender, EventArgs e)
        {
           try
            {
                Visible = true;
                //Show();
                WindowState = FormWindowState.Normal;
            }
            catch { }
        }

        private void NotifyIconThis_Click(object sender, EventArgs e)
        {
            try
            {
                notifyIconThis.ShowBalloonTip(2000);
            }
            catch { }
        }

        private void buttonSecondmetr_Click(object sender, EventArgs e)
        {
            SecondMetrForm form = new SecondMetrForm(Save.None);
            
            form.MetrOutput1 += Form_MetrOutput1;
            form.GetMilliseconds += Form_GetMilliseconds;
            form.GetTime += Form_GetTime;
            form.SetInput(textBoxValue.Text, checkBoxCopyNumber.Checked);
            form.Show();
        }

        private string Form_GetTime()
        {
            try
            {
                return textBoxValue.Text;
            }
            catch
            {
                return "";
            }
        }

        private double Form_GetMilliseconds()
        {
            try
            {
                return double.Parse(textBoxValue.Text.Replace('.', ','));
            }
            catch
            {
                return 0;
            }
        }

        private void Form_MetrOutput1(string time, Save save)
        {
            change = false;
            textBoxValue.Text = time.Replace("\n", Environment.NewLine);
            SetValueChange(textBoxValue, new EventArgs());
        }

        private void buttonFormule_Click(object sender, EventArgs e)
        {
            CalculatorString form = new CalculatorString(Save.None);
            form.MetrOutput1 += Form_MetrOutput1;
            form.SetNumberFromMain += Form_SetNumberFromMain;
            form.SetInput(ValueText, checkBoxCopyNumber.Checked);
            form.Show();
        }

        private string Form_SetNumberFromMain()
        {
            return textBoxValue.Text;
        }

        private void buttonValueClear_Click(object sender, EventArgs e)
        {
            textBoxValue.Clear();
        }

        public string ValueText
        {
            get => textBoxValue.Text;
            set => textBoxValue.Text = value;
        }

        public double ValueNumber
        {
            get
            {
                try
                {
                    return Convert.ToDouble(
                    new DataTable().Compute(
                        textBoxValue.Text.ToUpper().
                        Replace("PI", Math.PI.ToString()).
                        Replace("E", Math.E.ToString()).
                        Replace(',', '.')
                        , null).ToString());
                }
                catch
                {
                    return 0;
                }
            }
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {

            labelAppName.Text = Properties.Resources.AppName;
            toolTipInfoDoing.SetToolTip(labelAppName, labelAppName.Text);

            DateTime dateTime = DateTime.Now;
            labelDate.Text = dateTime.ToShortDateString();
            labelTime.Text = dateTime.ToLongTimeString();

            labelName.Text = $"\"{NameFile}\" - \"{NameList}\" - \"{NameValue}\"";

            try
            {
                TcpHelper.SetValue();
            }
            catch
            {

            }

            buttonHostSettings.Enabled = SecurityHelper.EnternetPermissions.Allowed;


            if (!SecurityHelper.TcpAllowed)
            {
                TcpHelper.ClientStarting = false;
                TcpHelper.ServerStop();
            }
            if (!SecurityHelper.UdpAllowed)
            {
                UDPHelper.ClientStarting = false;
                UDPHelper.ServerStop();
            }

            try
            {
                labelProcess.Text = ProcessInfo.NowProcessInfo.ToString();
            }
            catch { }

        }

        private void CreateNoneFile_Click(object sender, EventArgs e)
        {
            try
            {
                AddChanged(files.AddNone(textBoxName.Text));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Добавление файла",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        void AddChanged(ValuesFile file)
        {
            file.Changed += MainForm_Changed;
        }

        private void MainForm_Changed(object[] list, FileOutput file)
        {
            if (files.IndexByName(file) != listBoxFiles.SelectedIndex)
                return;
            int index = ListIndex;
            listBoxLists.Items.Clear();
            listBoxLists.Items.AddRange(list);
            ListIndex = index;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void listBoxFiles_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                textBoxName.Text = FileName;
                textBoxPath.Text = GetFile().GetPath();

                listBoxLists.Items.Clear();
                listBoxLists.Items.AddRange(GetFile().ArrayList());
            }
            catch
            {
                textBoxName.Text = "";
                listBoxLists.Items.Clear();
            }
        }

        public int FileIndex
        {
            get
            {
                int selectedIndex = listBoxFiles.SelectedIndex;
                if (selectedIndex < 0)
                {
                    if (listBoxFiles.Items.Count < 1)
                    {
                        return 0;
                    }
                    listBoxFiles.SelectedIndex = 0;
                    return selectedIndex;
                }
                return selectedIndex;
            }
            set
            {
                try
                {
                    int index = value;
                    if (listBoxFiles.Items.Count > 0 && index < 0)
                    {
                        index = 0;
                    }
                    listBoxFiles.SelectedIndex = index;
                }
                catch
                {
                    if (listBoxFiles.Items.Count > 0)
                        FileIndex = 0;
                }
                try
                {
                    listBoxFiles_SelectedIndexChanged(listBoxFiles, new EventArgs());
                }
                catch
                {

                }
            }
        }

        public int ListIndex
        {
            get
            {
                int selectedIndex = listBoxLists.SelectedIndex;
                if (selectedIndex < 0)
                {
                    if (listBoxLists.Items.Count < 1)
                    {
                        return 0;
                    }
                    listBoxLists.SelectedIndex = 0;
                    return selectedIndex;
                }
                return selectedIndex;
            }
            set
            {
                try
                {
                    int index = value;
                    if (listBoxLists.Items.Count > 0 && index < 0)
                    {
                        index = 0;
                    }
                    listBoxLists.SelectedIndex = index;
                }
                catch
                {
                    if (listBoxLists.Items.Count > 0)
                        ListIndex = 0;
                }
                try
                {
                    listBoxLists_SelectedIndexChanged(listBoxLists, new EventArgs());
                }
                catch
                {

                }
            }
        }

        public int ValueIndex
        {
            get
            {
                int selectedIndex = listBoxValues.SelectedIndex;
                if (selectedIndex < 0)
                {
                    if (listBoxValues.Items.Count < 1)
                    {
                        return 0;
                    }
                    listBoxValues.SelectedIndex = 0;
                    return selectedIndex;
                }
                return selectedIndex;
            }
            set
            {
                try
                {
                    int index = value;
                    if (listBoxValues.Items.Count > 0 && index < 0)
                    {
                        index = 0;
                    }
                    listBoxValues.SelectedIndex = index;
                }
                catch
                {
                    if (listBoxValues.Items.Count > 0)
                        ValueIndex = 0;
                }
                try
                {
                    listBoxValues_SelectedIndexChanged(listBoxValues, new EventArgs());
                }
                catch
                {

                }
            }
        }

        public string FileName
        {
            get => listBoxFiles.Items[FileIndex].ToString();

        }

        public string NameFile
        {
            get
            {
                try
                {
                    return FileName;
                }
                catch
                {
                    return "";
                }
            }
        }

        public string ListName
        {
            get => listBoxLists.Items[ListIndex].ToString();

        }

        public string NameList
        {
            get
            {
                try
                {
                    return ListName;
                }
                catch
                {
                    return "";
                }
            }
        }

        public string ValueName
        {
            get => listBoxValues.Items[ValueIndex].ToString();

        }

        public string NameValue
        {
            get
            {
                try
                {
                    return ValueName;
                }
                catch
                {
                    return "";
                }
            }
        }

        private void buttonFileDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите удалить файл из списка", "Удаление файла", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                return;
            try
            {
                ValuesFile file = GetFile();
                bool excel = file.IsExcel();
                try
                {
                    if (excel)
                    {
                        ExcelFile excel1 = GetFile().AsExcel();
                        string path = excel1.Path;
                        int index = ExcelPatern.Workbooks.FindIndex(w => w.FullName == path);
                        try
                        {
                            try
                            {
                                ExcelPatern.Workbooks[index].Save();
                            }
                            catch
                            {

                            }

                            ExcelPatern.Workbooks[index].Close();
                        }
                        catch
                        {

                        }
                        ExcelPatern.Workbooks.RemoveAt(index);
                    }
                }
                catch
                {

                }

                files.Delete(FileIndex);
            }
            catch
            {

            }
            GC.Collect();
        }

        private void buttonRename_Click(object sender, EventArgs e)
        {
            try
            {
                files.Rename(FileIndex, textBoxName.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Переименование файла",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        public ValuesFile GetFile() => files.Get(FileIndex);
        public ListFile GetList() => GetFile().Get(ListIndex);
        public ValueOfList GetValue() => GetList().Get(ValueIndex);

        public ValueOfList GetValueFew()
        {
            try
            {
                return GetValue();
            }
            catch 
            {
                return new ValueOfList();
            }
        }

        private void buttonAddList_Click(object sender, EventArgs e)
        {
            try
            {
                GetFile().AddList(textBoxName.Text).Changed += MainForm_Changed1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Добавление листа",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void MainForm_Changed1(object[] list, FileOutput file)
        {
            try
            {
                ListFile valueOfList = file.AsList();
                if (files.IndexByName(valueOfList.File) != listBoxFiles.SelectedIndex)
                    return;
                if(valueOfList.Index != listBoxLists.SelectedIndex)
                    return;
                int index = ValueIndex;
                listBoxValues.Items.Clear();
                listBoxValues.Items.AddRange(list);
                ValueIndex = index;
            }
            catch
            {

            }
        }

        private void listBoxLists_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                textBoxName.Text = ListName;

                listBoxValues.Items.Clear();
                listBoxValues.Items.AddRange(GetList().ArrayList());
            }
            catch (Exception ex)
            {
                textBoxName.Text = "";
                listBoxValues.Items.Clear();
            }
        }

        private void buttonDeleteList_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите удалить лист из списка", "Удаление листа", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                return;
            try
            {


                GetFile().Delete(ListIndex);

            }
            catch
            {

            }
            GC.Collect();
        }

        private void buttonRenameList_Click(object sender, EventArgs e)
        {
            try
            {
                GetFile().Rename(ListIndex, textBoxName.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Переименование файла",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void listBoxValues_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                textBoxValueName.Text = ValueName;
                ValueOfList value = GetValue();
                ValueOfList valueOfList = value;
                if (value.IsExcel())
                {
                    value.Get();
                }
                GetValue(valueOfList);

            }
            catch
            {

            }
        }

        private void buttonFileFind_Click(object sender, EventArgs e)
        {
            try
            {
                FileIndex = files.IndexOfFormat(textBoxName.Text);
            }
            catch
            {

            }
        }

        private void buttonListFind_Click(object sender, EventArgs e)
        {
            try
            {
                ListIndex = GetFile().IndexOfFormat(textBoxName.Text);
            }
            catch
            {

            }
        }

        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void buttonValueAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string text = textBoxValue.Text;
                bool autoWrite = checkBoxAutoWrite.Checked;
                ValueOfList value = GetList().AddValue(files);
                AddValueExcelChange(value, autoWrite, text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Добавление значения",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        public void GetValue(ValueOfList valueOfList)
        {
            change = false;
            GetValueText(valueOfList.ValueFormat, false);
            checkBoxAutoWrite.Checked = valueOfList.AutoWhrite;
            checkBoxAutoSave.Checked = valueOfList.AutoSave;
            numbericRows.Value = valueOfList.RowIndex;
            numbericColumns.Value = valueOfList.ColumnIndex;

            tabControlExcel.Visible = valueOfList.IsExcel() && valueOfList.NoCurrentCell;
            checkBoxCurrentCell.Visible = valueOfList.IsExcel();
            checkBoxCurrentCell.Checked = valueOfList.CurrentCell;
            textBoxNameServer.Visible = valueOfList.IsFileOrServer();
            groupBoxPasswordServer.Visible = valueOfList.IsNetwork();
            textBoxNameServer.Title = valueOfList.IsNetwork() ? "Значение на сервере" : "Имя файла";
            textBoxNameServer.Value = valueOfList.NameAtServer;
            checkBoxRowAdd.Checked = valueOfList.ChangeRow;
            numbericRowAdd.Value = valueOfList.AddRowIndex;
            checkBoxChangeColumn.Checked = valueOfList.ChangeColumn;
            numericAddColumn.Value = valueOfList.AddColumnIndex;
            comboBoxChangePoint.SelectedIndex = valueOfList.ChangePointIndex;
            groupBoxValuesThis.Visible = valueOfList.IsAtThis();
            comboBoxValuesThis.Items.Clear();
            comboBoxValuesThis.Items.Clear();
            comboBoxValuesThis.Items.AddRange(valueOfList.ValuesThis);

            checkBoxRunNotificationSave.Checked = valueOfList.RunNotificationSave;
            checkBoxRunNotificationWrite.Checked = valueOfList.RunNotificationWrite;
            checkBoxNoAllowPutByNet.Checked = valueOfList.NoAllowPutByNet;

            textBoxPasswordServer.Value = valueOfList.ServerPassword;

            textBoxPassword.Value = valueOfList.Password;
            checkBoxNessasirlyAuth.Checked = valueOfList.NecessarilyAuthorization;

            try
            {
                int index = ThisValueIndexSelect;
                int count = comboBoxValuesThis.Items.Count;
                if(count > 0 && index < 0)
                {
                    ThisValueIndexSelect = 0;
                }
            }
            catch
            {

            }
            change = true;

        }

        public int ThisValueIndexSelect
        {
            get => comboBoxValuesThis.SelectedIndex;
            set => comboBoxValuesThis.SelectedIndex = value;
        }

        private void Value_FromExcelChanged(ValueOfList value, ExcelFile excel)
        {
            int row = value.RowIndex;
            int column = value.ColumnIndex;
            try
            {
                string path = excel.Path;
                Excel._Workbook wb = ExcelPatern.Workbooks.Find(w => w.FullName == path);
                Excel.Worksheet ws = wb.Sheets[value.List.Name];
                Excel.Range cell;
                if (value.NoCurrentCell)
                    cell = ws.Cells[row, column];
                else
                {
                    ws = wb.ActiveSheet;
                    cell = ws.Cells[1, 1];
                }
                value.SetValue(Convert.ToString(cell.Value2), false);
            }
            catch
            {

            }
        }

        private void Value_Changed(ValueOfList valueOfList)
        {
            try
            {
                int file = listBoxFiles.SelectedIndex;
                if (file == -1)
                    return;
                int list = listBoxLists.SelectedIndex;
                if (list == -1)
                    return;
                int value = listBoxValues.SelectedIndex;
                if (value == -1)
                    return;
                int file1 = valueOfList.GetIndexAtList(files);
                if (file1 == -1 || file1 != file)
                    return;
                int list1 = valueOfList.ListIndex;
                if (list1 == -1 || list1 != list)
                    return;
                int value1 = valueOfList.Index;
                if (value1 == -1 || value1 != value)
                    return;
                GetValue(valueOfList);
            }
            catch
            {

            }

        }

        private void buttonAddValueWithName_Click(object sender, EventArgs e)
        {
            string name = textBoxValueName.Text;
            try
            {
                string text = textBoxValue.Text;
                bool autoWrite = checkBoxAutoWrite.Checked;
                ValueOfList value = GetList().AddValue(name, files);
                AddValueExcelChange(value, autoWrite, text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Добавление значения",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        void AddValueExcelChange(ValueOfList value, bool autoWrite, string text)
        {
            value.ToBufferChanging += Value_ToBufferChanging;
            value.FromBufferChanging += Value_FromBufferChanging;
            value.Changed += Value_Changed;
            value.FromExcelChanged += Value_FromExcelChanged;
            value.ShowNotificationView += Value_ShowNotificationView;
            if (autoWrite)
            {
                value.AutoWhrite = autoWrite;
                value.SetValue(text, false);
            }

        }

        private void Value_ShowNotificationView(ValueOfList value, string message)
        {
            try
            {
                //notifyIconValue.Text = message;

                try
                {
                    handler = null;
                }
                catch { }


                handler= (sender, e) =>
                    {
                        FindValue(value.Name);
                };
                notifyIconValue.BalloonTipClicked += handler;
                
                notifyIconValue.BalloonTipIcon = ToolTipIcon.Warning;
                notifyIconValue.BalloonTipTitle = "TableAIS (зарегистрировано действие со значением)";
                notifyIconValue.BalloonTipText = message;
                notifyIconValue.ShowBalloonTip(5000);
            }
            catch
            {

            }
        }

        EventHandler handler;

        private void Value_FromBufferChanging(ValueOfList value)
        {
            value.SetValue(Buffer.Text, true);
        }

        private void Value_ToBufferChanging(ValueOfList value)
        {
            Buffer.Text = value.ValuePoint;
        }

        private void buttonDeleteValue_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите удалить значение", "Удаление значения", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                return;
            try
            {
                GetList().Delete(ValueIndex);
            }
            catch
            {

            }
        }

        private void buttonValueRename_Click(object sender, EventArgs e)
        {
            try
            {
                GetList().Rename(ValueIndex, textBoxValueName.Text, files);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Переименование файла",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void buttonValueFind_Click(object sender, EventArgs e)
        {
            try
            {
                ValueIndex = GetList().IndexOfFormat(textBoxValueName.Text);
            }
            catch
            {

            }
        }

        private void buttonNameClear_Click(object sender, EventArgs e)
        {
            textBoxName.Clear();
        }

        private void buttonValueNameClear_Click(object sender, EventArgs e)
        {
            textBoxValueName.Clear();
        }

        private void buttonFindByAll_Click(object sender, EventArgs e)
        {
            FindValue(textBoxValueName.Text);
        }

        public void FindValue(string name)
        { 

            try
            {
                ValueOfList value = files.GetValue(name);
                ValuesFile file = value.File;
                ListFile list = value.List;

                FileIndex = files.IndexOf(file.Name);
                ListIndex = list.Index;
                ValueIndex = value.Index;
            }
            catch
            {

            }
        }

        private void buttonValueCreate_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue().SetValue(textBoxValue.Text, checkBoxAutoSave.Checked);
                textBoxResult.Text = "Успешно";
            }
            catch
            {
                textBoxResult.Text = "Ошибка";
            }
        }

        private void checkBoxAutoWrite_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                GetValue().AutoWhrite = (sender as CheckBox).Checked;
            }
            catch
            {

            }
        }

        private void textBoxValue_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int index = textBoxValue.SelectionStart;
                int length = textBoxValue.SelectionLength;
                if (GetValue().AutoWhrite && change)
                {
                    buttonValueCreate_Click(sender, e);
                }
                //textBoxValue.SelectionStart = index;
                //textBoxValue.SelectionLength = length;
            }
            catch
            {

            }
        }

        bool change = false;

        void SetValueChange(object sender, EventArgs e)
        {
            change = true;
            textBoxValue_TextChanged(sender, e);
        }
        

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                for (int i = 0; i < ExcelPatern.Workbooks.Count; i++)
                {
                    try
                    {
                        try
                        {
                            ExcelPatern.Workbooks[i].Save();
                        }
                        catch
                        {

                        }
                        ExcelPatern.Workbooks[i].Close(true);
                    }
                    catch
                    {

                    }
                }
            }
            catch
            {

            }

            try
            {
                ExcelPatern.excelApp.Quit();
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(ExcelPatern.excelApp);
                GC.Collect();
            }
            catch
            {

            }

            try
            {
                TcpHelper.ThisClient.Close();
            }
            catch
            {

            }

            try
            {
                TcpHelper.RemoteClient.Close();
            }
            catch
            {

            }

            try
            {
                TcpHelper.ThisServer.Close();
            }
            catch
            {

            }

            try
            {
                TcpHelper.NetworkStop();
            }
            catch
            {

            }

        }

        void OpenExcel()
        {
            if (ExcelPatern.ExcelApplication == null)
            {
                CreateExcel();
            }
        }

        private void buttonExcelOpen_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (openExcelFile.ShowDialog() == DialogResult.Cancel)
                {
                    return;
                }
                OpenExcel(openExcelFile.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                       "Добавление значения",
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
            GC.Collect();
        }

        void OpenExcel(string fileName)
        {
            try
            {
                Excel.Workbook book = null;

                try
                {

                    OpenExcel();
                    
                        book = ExcelPatern.ExcelApplication.Workbooks.Open(fileName);
                    
                    
                    ExcelFile file = files.AddExcel(TextName, fileName);
                    ExcelPatern.Workbooks.Add(book);



                    for (int i = 0; i < book.Worksheets.Count; i++)
                    {
                        int j = i + 1;
                        Excel.Worksheet worksheet = book.Worksheets[j];
                        file.AddList(worksheet.Name).Changed += MainForm_Changed1;

                    }
                    file.ToExcelChanged += File_ToExcelChanged;
                    file.InputFromExcel += File_InputFromExcel; 
                    AddChanged(file);
                    file.ExcelChangingName += File_ExcelChangingName;
                    if (files.IndexByName(file) == listBoxFiles.SelectedIndex)
                        file.ChangedInvoke();
                }
                catch (Exception ex)
                {
                    try
                    {
                        string name = book.FullName;
                        try
                        {
                            book.Close();
                        }
                        catch
                        {

                        }
                        int index = ExcelPatern.Workbooks.FindIndex(w => w.FullName == name);
                        ExcelPatern.Workbooks.RemoveAt(index);
                    }
                    catch
                    {

                    }
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                GC.Collect();
            }
        }

        private string File_InputFromExcel(ValueOfList valueOfList, ExcelFile excelFile)
        {
            try
            {
                int list = valueOfList.ListIndex;
                list++;
                int row = valueOfList.RowIndex;
                int column = valueOfList.ColumnIndex;
                ValueOfList value = valueOfList;
                Excel._Workbook wb = ExcelPatern.Workbooks.FirstOrDefault(w => w.FullName == excelFile.Path);
                Excel._Worksheet ws = wb.Worksheets[list];
                Excel.Range cell;
                if (value.NoCurrentCell)
                    cell = ws.Cells[row, column];
                else
                {
                    ws = wb.ActiveSheet;
                    cell = ws.Cells[1, 1];
                    
                }
                return Convert.ToString(cell.Value2);
            }
            catch
            {
                return valueOfList.Value;
            }
        }

        private void File_ExcelChangingName(string path, string oldName, string newName, ExcelFile f)
        {
            try
            {
                Excel._Workbook book = ExcelPatern.Workbooks.Find(w => w.FullName == path);

                if (oldName == "")
                {
                    int index = book.Sheets.Add();
                    book.Sheets[index].Name = newName;
                    
                }
                else if (newName == "")
                {
                    book.Sheets[oldName].Delete();
                }
                else
                {
                    book.Sheets[oldName].Name = newName;
                }

                book.Save();
                f.ChangedInvoke();
            }
            catch
            {

            }
        }

        private void File_ToExcelChanged(ValueOfList valueOfList, ExcelFile excelFile)
        {
            try
            {
                int list = valueOfList.ListIndex;
                list++;
                int row = valueOfList.RowIndex;
                int column = valueOfList.ColumnIndex;
                ValueOfList value = valueOfList;
                Excel._Workbook wb = ExcelPatern.Workbooks.FirstOrDefault(w => w.FullName == excelFile.Path);
                Excel._Worksheet ws = wb.Worksheets[list];
                Excel.Range cell;
                if (value.NoCurrentCell)
                    cell = ws.Cells[row, column];
                else
                {
                    ws = wb.ActiveSheet;
                    cell = ws.Cells[1, 1];
                }
                cell.Value2 = valueOfList.ValuePoint;
                wb.Save();
            }
            catch
            {

            }
        }

        public string TextName
        {
            get => textBoxName.Text;
            set => textBoxName.Text = value;
        }

        private void checkBoxAutoSave_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                GetValue().AutoSave = (sender as CheckBox).Checked;
            }
            catch
            {

            }
        }

        private void buttonValueSave_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue().Save();
                textBoxResult.Text = "Успешно";
            }
            catch
            {
                textBoxResult.Text = "Ошибка!!!";
            }
        }

        private void buttonExcelVisual_Click(object sender, EventArgs e)
        {
            try
            {
                OpenExcel();
                bool visible = ExcelPatern.ExcelApplication.Visible;
                ExcelPatern.ExcelApplication.Visible = !visible;
            }
            catch
            {

            }
        }

        private void excelToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void numbericRows_ValueChanged(object sender, EventArgs e, decimal value)
        {
            GetValue().SetRow(value);
        }

        private void numbericColumns_ValueChanged(object sender, EventArgs e, decimal value)
        {
            GetValue().SetColumn(value);
        }

        private void buttonChangeColumn_Click(object sender, EventArgs e)
        {
            tabControlExcel.SelectedIndex = 1;
        }

        private void buttonChangeRow_Click(object sender, EventArgs e)
        {
            tabControlExcel.SelectedIndex = 0;
        }

        private void checkBoxRowAdd_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                GetValue().ChangeRow = (sender as CheckBox).Checked;
            }
            catch
            {

            }
        }

        private void numbericRowAdd_ValueChanged(object sender, EventArgs e, decimal value)
        {
            try
            {
                GetValue().AddRowIndex = value;
            }
            catch
            {

            }
        }

        private void checkBoxChangeColumn_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                GetValue().ChangeColumn = (sender as CheckBox).Checked;
            }
            catch
            {

            }
        }

        private void numbericUser1_ValueChanged(object sender, EventArgs e, decimal value)
        {
            try
            {
                GetValue().AddColumnIndex = value;
            }
            catch
            {

            }
        }

        private void comboBoxChangePoint_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!change)
                return;

            try
            {
                GetValue().ChangePointIndex = (sender as ComboBox).SelectedIndex;
            }
            catch
            {

            }
        }

        private void buttonExcelCreate_Click(object sender, EventArgs e)
        {
            try
            {

                if (saveExcelFile.ShowDialog() == DialogResult.Cancel)
                {
                    return;
                }
                string fileName = saveExcelFile.FileName;
                OpenExcel();
                ExcelApp.SheetsInNewWorkbook = 1;
                Excel.Workbook book = ExcelApp.Workbooks.Add(Type.Missing);
                Excel.Worksheet sheet = book.Worksheets.get_Item(1);
                sheet.Name = "Лист 1";

                sheet.Columns.EntireColumn.AutoFit();
                sheet.Rows.EntireRow.AutoFit();

                book.SaveAs(Filename: fileName, AccessMode: Excel.XlSaveAsAccessMode.xlExclusive);
                try
                {
                    book.Close(true);
                }
                catch
                {

                }


                OpenExcel(fileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                       "Добавление значения",
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
            GC.Collect();
        }

        public Excel._Application ExcelApp
        {
            get => ExcelPatern.ExcelApplication;
            set => ExcelPatern.ExcelApplication = value;
        }

        private void buttonCopyValueToValue_Click(object sender, EventArgs e)
        {
            try
            {
                if(textBoxCopyName.Text.Length < 1)
                {
                    throw new Exception("Введите название значения в текстовом поле, которое выше");
                }
                files.CopyValue(NameValue, textBoxCopyName.Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,
                       "Копирование значения",
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
        }

        private void buttonCopyInputText_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxCopyName.Text.Length < 1)
                {
                    throw new Exception("Введите название значения в текстовом поле, которое выше");
                }
                files.SetValue(textBoxCopyName.Text, textBoxValue.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                       "Копирование значения",
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
        }

        private void buttonJsonOutput_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxValue.Text = GetValueFew().ToJson();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,
                       "Вывод в Json",
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
        }

        private void buttonCopyJsonView_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxCopyName.Text.Length < 1)
                {
                    throw new Exception("Введите название значения в текстовом поле, которое выше");
                }
                files.CopyValueWithJsonView(NameValue, textBoxCopyName.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                       "Копирование значения",
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
        }

        private void buttonValueJsonText_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxCopyName.Text.Length < 1)
                {
                    throw new Exception("Введите название значения в текстовом поле, которое выше");
                }
                files.SetJsonOfValue(textBoxCopyName.Text, textBoxValue.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                       "Копирование значения",
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
        }

        private void buttonValueFromJsonJalue_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxCopyName.Text.Length < 1)
                {
                    throw new Exception("Введите название значения в текстовом поле, которое выше");
                }
                files.CopyValueFromJsonView(NameValue, textBoxCopyName.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                       "Копирование значения",
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
        }

        private void buttonFromJsonValue_Click(object sender, EventArgs e)
        {
            try
            {
                string json = textBoxValue.Text;
                JsonObject obj = (JsonObject)JsonNode.Parse(json);
                textBoxValue.Text = obj["value"].ToString();
            }
            catch
            {

            }
        }

        private void buttonHostSettings_Click(object sender, EventArgs e)
        {
            HostSettings hostSettings = new HostSettings();
            hostSettings.Show();
        }

        private void buttonValueToBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue().ToBuffer();
            }
            catch
            {
                Buffer.Text = textBoxValue.Text;
            }
        }

        private void buttonValueFromBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue().FromBuffer();
            }
            catch
            {
                textBoxValue.Text = Buffer.Text.Replace("\n", Environment.NewLine);
            }
        }

        private void buttonSaveTextBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                Buffer.Text = ValueTextByControl;
            }
            catch
            {

            }
        }

        private void buttonLoadBufferText_Click(object sender, EventArgs e)
        {
            try
            {
                ValueTextByControl = Buffer.Text.Replace("\n", Environment.NewLine);
            }
            catch
            {

            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void buttonTcpClientAdd_Click(object sender, EventArgs e)
        {
            ClientSocketForm tcpClient = new ClientSocketForm();
            tcpClient.Port = 9000;
            tcpClient.SavedText += TcpClient_SavedText;
            tcpClient.ShowDialog();
        }

        private void TcpClient_SavedText(string text)
        {
            try
            {
                TcpFile file = files.AddTCP(textBoxName.Text, text);
                file.SavingTcpFile += File_SavingTcpFile;
                AddChanged(file);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Добавление файла",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void File_SavingTcpFile(TcpFile file, ValueOfList value, string jsonServerView, string serverAddress)
        {
            ValueOfList valueOfList = value;
            try
            {
                IPAddress iP = IPAddress.Parse(file.IpAddress);
                TcpHelper.SendToServer(new IPEndPoint(iP, file.Port), jsonServerView);
                timerTCP.Start();
            }
            catch(Exception e)
            {
                if(SecurityHelper.TcpPermissions.Allowed)
                {
                    textBoxResult.Text = "Ошибка!!!";
                }
                else
                {
                    textBoxResult.Text = "Запрещено!!!";
                }
                int file2 = listBoxFiles.SelectedIndex;
                if (file2 == -1)
                    return;
                int list = listBoxLists.SelectedIndex;
                if (list == -1)
                    return;
                int value2 = listBoxValues.SelectedIndex;
                if (value2 == -1)
                    return;
                int file1 = valueOfList.GetIndexAtList(files);
                if (file1 == -1 || file1 != file2)
                    return;
                int list1 = valueOfList.ListIndex;
                if (list1 == -1 || list1 != list)
                    return;
                int value1 = valueOfList.Index;
                if (value1 == -1 || value1 != value2)
                    return;
                throw e;
            }
        }

        private void timerTCP_Tick(object sender, EventArgs e)
        {
            (sender as Timer).Stop();

            try
            {
                if(TcpHelper.messageOutput)
                {

                    textBoxResult.Text = TcpHelper.message;
                    TcpHelper.messageOutput = false;
                    return;
                }
            }
            catch
            {

            }
            (sender as Timer).Start();
        }

        private void textBoxNameServer_ValueChanged(Control control, EventArgs e, string value)
        {
            try
            {
                GetValue().NameAtServer = value;
            }
            catch
            {

            }
        }

        public static string GetReservNames()
        {
            try
            {
                return File.ReadAllText("ReservNames.txt");
            }
            catch
            {
                return "";
            }
        }

        private void buttonRezervNamesView_Click(object sender, EventArgs e)
        {
            MessageBox.Show(GetReservNames(), "Зарезервированные имена", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonValueWriteSave_Click(object sender, EventArgs e)
        {
            buttonValueCreate_Click(sender, e);
            buttonValueSave_Click(sender, e);
        }

        private void checkBoxCurrentCell_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                GetValue().CurrentCell = (sender as CheckBox).Checked;
            }
            catch
            {

            }
            try
            {
                ValueOfList valueOfList = GetValue();
                tabControlExcel.Visible = valueOfList.IsExcel() && valueOfList.NoCurrentCell;
            }
            catch
            {

            }
        }

        private void добавитьToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void ReopenExcel_Click(object sender, EventArgs e)
        {
            try
            {
                ExcelFile file = GetFile().AsExcel();
                string fileName = file.FullName;
                TextName = file.Name;
                string name = TextName;
                buttonFileDelete_Click(sender, e);
                if (files.Contains(name))
                {
                    listBoxFiles_SelectedIndexChanged(sender, e);
                    return;
                }
                else
                {
                    TextName = name;
                    OpenExcel(fileName);
                }
            }
            catch
            {

            }
        }

        private void buttonTranferValue_Click(object sender, EventArgs e)
        {
            try
            {
                files.GetValue(textBoxValueName.Text).ValueWithSave = textBoxValue.Text;
            }
            catch(Exception ex)
            {

            }
        }

        private void buttonFromTemesSaved_Click(object sender, EventArgs e)
        {
            FormSecondsSaved saved = new FormSecondsSaved();
            saved.MetrOutput1 += Saved_MetrOutput1;
            saved.Show();
        }

        private void Saved_MetrOutput1(string time, Save save)
        {
            textBoxValue.Text = time;
        }

        private void buttonValueThisClear_Click(object sender, EventArgs e)
        {
            textBoxValueThis.Clear();
        }

        private void buttonTranferThisRun_Click(object sender, EventArgs e)
        {
            try
            {

                GetValue().Transfer(textBoxValueThis.Text);

                MessageBox.Show("Данные выбранному значению успешно переданы", "Передача данных", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось передать данные", "Передача данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CreateFileThis_Click(object sender, EventArgs e)
        {
            try
            {
                FileAtValueThis file = files.AddAtThis(textBoxName.Text);
                AddChanged(file);
                file.Saved += File_Saved;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Добавление файла",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void File_Saved(FileAtValueThis file, ValueOfList value, string message)
        {
            textBoxResult.Text = message;
        }

        private void buttonThisDelete_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue().DeleteValueThis(ThisValueIndexSelect);
                ThisValueIndexSelect = 0;
            }
            catch
            {

            }
        }

        private void buttonThisAddClear_Click(object sender, EventArgs e)
        {
            textBoxValueThisAdd.Clear();
        }

        private void buttonThisAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string name = textBoxValueThisAdd.Text;
                GetValue().AddValueThis(name);
                comboBoxValuesThis.SelectedIndex = GetValue().IndexValue(name);
            }
            catch
            {

            }
        }

        private void buttonSetValueText_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue(GetValue());
            }
            catch
            {

            }
        }

        private void buttonTranferThisRunFromText_Click(object sender, EventArgs e)
        {
            try
            {

                Files.SetValueByName(textBoxValueThis.Text, textBoxValue.Text);

                MessageBox.Show("Данные выбранному значению успешно переданы", "Передача данных", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Не удалось передать данные", "Передача данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void flowLayoutPanel1_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                FlowLayoutPanel thisPanel = sender as FlowLayoutPanel;
                int with = thisPanel.Width;
                Control.ControlCollection controls = thisPanel.Controls;
                int count = controls.Count;

                foreach (Control control in controls)
                {
                    control.Width = with - 35;
                }
            }
            catch
            {

            }
        }

        public void GetValueText(string text, bool changeThis = true)
        {
            change = false;
            textBoxValue.Text = text.Replace("\n", Environment.NewLine);
            change = changeThis;
        }

        private void buttonSetExcelTable_Click(object sender, EventArgs e)
        {
            try
            {
                ValueOfList valueOfList = GetValue();
                ValueOfList value = valueOfList;
                if (!value.IsExcel())
                    return;
                int list = valueOfList.ListIndex;
                list++;
                int row = valueOfList.RowIndex;
                int column = valueOfList.ColumnIndex;
                ExcelFile excelFile = value.File.AsExcel();
                Excel._Workbook wb = ExcelPatern.Workbooks.FirstOrDefault(w => w.FullName == excelFile.Path);
                Excel._Worksheet ws = wb.Worksheets[list];
                Excel.Range cell;
                if (value.NoCurrentCell)
                    cell = ws.Cells[row, column];
                else
                {
                    ws = wb.ActiveSheet;
                    cell = ws.Cells[1, 1];
                }
                GetValueText(Convert.ToString(cell.Value2));
            }
            catch
            {

            }
        }

        private void buttonUdpClientAdd_Click(object sender, EventArgs e)
        {
            ClientSocketForm udpClient = new ClientSocketForm();
            udpClient.Port = 9020;
            udpClient.SavedText += UdpClient_SavedText;
            udpClient.ShowDialog();
        }

        private void UdpClient_SavedText(string text)
        {
            try
            {
                UdpFile file = files.AddUDP(textBoxName.Text, text);
                file.SavingUdpFile += File_SavingUdpFile;
                AddChanged(file);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Добавление файла",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void File_SavingUdpFile(UdpFile file, ValueOfList value, string jsonServerView, string serverAddress)
        {
            ValueOfList valueOfList = value;
            try
            {
                UDPHelper.GetMessage = (text) => textBoxResult.Text = text;
                UDPHelper.Send(jsonServerView, file.IpAddress, file.Port);
            }
            catch (Exception e)
            {
                if (SecurityHelper.UdpPermissins.Allowed)
                {
                    textBoxResult.Text = "Ошибка!!!";
                }
                else
                {
                    textBoxResult.Text = "Запрещено!!!";
                }
                int file2 = listBoxFiles.SelectedIndex;
                if (file2 == -1)
                    return;
                int list = listBoxLists.SelectedIndex;
                if (list == -1)
                    return;
                int value2 = listBoxValues.SelectedIndex;
                if (value2 == -1)
                    return;
                int file1 = valueOfList.GetIndexAtList(files);
                if (file1 == -1 || file1 != file2)
                    return;
                int list1 = valueOfList.ListIndex;
                if (list1 == -1 || list1 != list)
                    return;
                int value1 = valueOfList.Index;
                if (value1 == -1 || value1 != value2)
                    return;
                throw e;
            }
        }

        private void buttonSetFormuleFromExcel_Click(object sender, EventArgs e)
        {
            try
            {
                ValueOfList valueOfList = GetValue();
                ValueOfList value = valueOfList;
                if (!value.IsExcel())
                    return;
                int list = valueOfList.ListIndex;
                list++;
                int row = valueOfList.RowIndex;
                int column = valueOfList.ColumnIndex;
                ExcelFile excelFile = value.File.AsExcel();
                Excel._Workbook wb = ExcelPatern.Workbooks.FirstOrDefault(w => w.FullName == excelFile.Path);
                Excel._Worksheet ws = wb.Worksheets[list];
                Excel.Range cell;
                if (value.NoCurrentCell)
                    cell = ws.Cells[row, column];
                else
                {
                    ws = wb.ActiveSheet;
                    cell = ws.Cells[1, 1];
                }
                GetValueText(Convert.ToString(cell.Formula));
            }
            catch
            {

            }
        }

        private void buttonFormuleWrite_Click(object sender, EventArgs e)
        {
            try
            {
                ValueOfList valueOfList = GetValue();
                ValueOfList value = valueOfList;
                if (!value.IsExcel())
                    return;
                int list = valueOfList.ListIndex;
                list++;
                int row = valueOfList.RowIndex;
                int column = valueOfList.ColumnIndex;
                ExcelFile excelFile = value.File.AsExcel();
                Excel._Workbook wb = ExcelPatern.Workbooks.FirstOrDefault(w => w.FullName == excelFile.Path);
                Excel._Worksheet ws = wb.Worksheets[list];
                Excel.Range cell;
                if (value.NoCurrentCell)
                    cell = ws.Cells[row, column];
                else
                {
                    ws = wb.ActiveSheet;
                    cell = ws.Cells[1, 1];
                }
               cell.Formula = textBoxValue.Text;
            }
            catch
            {

            }
        }

        private void buttonValueFormuleWrite_Click(object sender, EventArgs e)
        {
            try
            {
                ValueOfList valueOfList = GetValue();
                ValueOfList value = valueOfList;
                if (!value.IsExcel())
                    return;
                int list = valueOfList.ListIndex;
                list++;
                int row = valueOfList.RowIndex;
                int column = valueOfList.ColumnIndex;
                ExcelFile excelFile = value.File.AsExcel();
                Excel._Workbook wb = ExcelPatern.Workbooks.FirstOrDefault(w => w.FullName == excelFile.Path);
                Excel._Worksheet ws = wb.Worksheets[list];
                Excel.Range cell;
                if (value.NoCurrentCell)
                    cell = ws.Cells[row, column];
                else
                {
                    ws = wb.ActiveSheet;
                    cell = ws.Cells[1, 1];
                }
                cell.Formula = value.Value;
            }
            catch
            {

            }
        }

        private void buttonGetValueFromCalculatorMemory_Click(object sender, EventArgs e)
        {
            try
            {
                CalculatorMemory memory = new CalculatorMemory();
                memory.MetrOutput1 += Memory_MetrOutput1;
                memory.Show();
            }
            catch
            {

            }
        }

        private void Memory_MetrOutput1(string time, Save save)
        {
            textBoxValue.Text = time;
        }

        private void buttonToLongBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                PropertiesHelper.Buffer = ValueTextByControl;
                TextResult = "Успешно";
            }
            catch
            {
                TextResult = "Ошибка!!!";
            }
        }

        private void buttonFromLongBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                ValueTextByControl = PropertiesHelper.Buffer;
            }
            catch
            {

            }
        }

        private void buttonClearLongBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                PropertiesHelper.ClearBuffer();
                TextResult = "Успешно";
            }
            catch
            {
                TextResult = "Ошибка!!!";
            }
        }

        private void buttonSaveTextFile_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "Text Files (*.txt)|*.txt|Text Files (*.stxt)|*.stxt|Text Files (*.txt; *.stxt)|*.txt;*.stxt|All Files|*.*";
                save.Title = "Сохрание текста в файл";
                
                if (save.ShowDialog() == DialogResult.Cancel)
                    return;
                File.WriteAllText(save.FileName, ValueTextByControl);
                MessageBox.Show("Текст успешно сохранён в файл", "Сохрание текста в файл", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {


                MessageBox.Show($"Не удалось сохранить текст в файл: \n {ex.Message}", $"Сохрание текста в файл", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonLoadTextFile_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog save = new OpenFileDialog();
                save.Filter = "Text Files (*.txt)|*.txt|Text Files (*.stxt)|*.stxt|Text Files (*.txt; *.stxt)|*.txt;*.stxt|All Files|*.*";
                save.Title = "Загрузка текста из файла";
                if (save.ShowDialog() == DialogResult.Cancel)
                    return;
                ValueTextByControl = File.ReadAllText(save.FileName);
                MessageBox.Show("Текст успешно загружен из файла", "Загрузка текста из файла", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {


                MessageBox.Show($"Не удалось загрузить текст из файла: \n {ex.Message}", $"Загрузка текста из файла", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonTextToBynaryCode_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ValueTextByControl;
                ValueTextByControl = BynaryCode.BynaryText(value);
            }
            catch
            (Exception ex)
            {

            }
        }

        private void buttonTextByBynaruCode_Click(object sender, EventArgs e)
        {
            try
            {
                string value = ValueTextByControl;
                ValueTextByControl = BynaryCode.TextByBynaryCode(value).Replace("\n", Environment.NewLine);
            }
            catch
            (Exception ex)
            {

            }
        }

        public static string AppName()
        {
            return Application.ProductName + " " + FullVersion() + " - " + Application.ProductVersion + "\n";
        }

        public static string CodeVersion()
        {
            return Application.ProductVersion.Split('.')[0];
        }

        public static string VersionSubNumber()
        {
            return Properties.Settings.Default.SubVersion;
        }

        public static string FullVersion()
        {
            return CodeVersion()+"."+VersionSubNumber();
        }

        public static string ProgramInfo()
        {
            try
            {
                string name = Application.ProductName;
                string version = Application.ProductVersion;
                string codeVersion = "Код (Основной номер) версии: " + CodeVersion();
                string subVersion = "Номер подверсии: " + VersionSubNumber();
                string fullVersion = "Полный номер версии: " + FullVersion();

                string lines = "\n";
                string os = Environment.OSVersion.Platform.ToString();
                string number = Environment.OSVersion.VersionString;
                os = "ОС на устройстве: " + os + ": "+number;
                string osVersion = Environment.OSVersion.Version.ToString();
                osVersion = "Версия ОС на устройстве: " + osVersion;

                string path = "";

                try
                {
                    path = "Относительный путь к приложению - " + Application.StartupPath+"\n";
                    path += "Абсолютный путь к приложению - " + Application.ExecutablePath;
                }
                catch {
                    path = "";
                }


                name = "Название приложения: "+ name;
                version = "Версия сборки приложения: " + version;
                return string.Join("\n", AppName(), name, version, codeVersion, subVersion, fullVersion, lines, path, lines, os, osVersion);
            }
            catch
            {
                return "";
            }
        }

        private void buttonProgramInfoDialog_Click(object sender, EventArgs e)
        {
            MessageBox.Show(ProgramInfo(), "О приложении", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonProgramInfoToTextValue_Click(object sender, EventArgs e)
        {
            ValueTextByControl = ProgramInfo().Replace("\n", Environment.NewLine);
        }

        private void buttonToClipBord_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(ValueTextByControl);
                TextResult = "Успешно";
            }
            catch
            {
                TextResult = "Ошибка!!!";
            }
        }

        private void buttonFromClipBord_Click(object sender, EventArgs e)
        {
            try
            {
                ValueTextByControl = Clipboard.GetText();
                TextResult = "Успешно";
            }
            catch
            {
                TextResult = "Ошибка!!!";
            }
        }

        private void buttonTextEditor_Click(object sender, EventArgs e)
        {
            try
            {
                TextEditorForm textEditor = new TextEditorForm();
                textEditor.MetrOutput1 += (name, save) =>
                {
                    try
                    {
                        ValueTextByControl = name;
                    }
                    catch { }
                };
                textEditor.SetFromMain += TextEditor_SetFromMain;
                textEditor.Show();
            }
            catch { }
        }

        private string TextEditor_SetFromMain()
        {
            return ValueTextByControl;
        }

        private void buttonAddTextFile_Click(object sender, EventArgs e)
        {

            try
            {
                FolderBrowserDialog dialog = new FolderBrowserDialog();
                if (dialog.ShowDialog() == DialogResult.Cancel)
                    return;
                AddChanged(files.AddText(textBoxName.Text, dialog.SelectedPath));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Добавление файла",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void оПриложенииToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void buttonClearTimeBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                Buffer.Text = "";
            }
            catch
            {

            }
        }

        private void buttonLoadText_Click(object sender, EventArgs e)
        {
            try
            {
                change = false;
                ValueTextByControl = GetValue().InputText();
            }
            catch { }
            change = true;
        }

        private void buttonInputValue_Click(object sender, EventArgs e)
        {
            try
            {
                change = false;
                ValueTextByControl = GetValue().Input();
            }
            catch { }
            change = true;
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {

        }

        private void buttonSecurity_Click(object sender, EventArgs e)
        {
            SecurityForm form = new SecurityForm();
            form.Show();

        }

        private void buttonCopyNameFileValue_Click(object sender, EventArgs e)
        {
            textBoxValueName.Text = textBoxName.Text;
        }

        private void buttonCopyNameToText_Click(object sender, EventArgs e)
        {
            textBoxValue.Text = textBoxName.Text;
        }

        private void buttonCopyNameToValue_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue().SetValue(textBoxName.Text);
            }
            catch { }

        }

        private void buttonNameByText_Click(object sender, EventArgs e)
        {
            textBoxName.Text = textBoxValue.Text;
        }

        private void buttonNameByValue_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxValueName.Text = GetValue().Value;
            }
            catch { }
        }

        private void buttonCopyValueNameText_Click(object sender, EventArgs e)
        {
            textBoxValue.Text = textBoxValueName.Text;
        }

        private void buttonCopyValueNameValue_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue().SetValue(textBoxValueName.Text);
            }
            catch { }
        }

        private void buttonValueNameCopyName_Click(object sender, EventArgs e)
        {
            textBoxName.Text = textBoxValueName.Text;
        }

        private void buttonCopyTextToValueName_Click(object sender, EventArgs e)
        {
            textBoxValueName.Text = textBoxValue.Text;
        }

        private void buttonJsonNetOutput_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxValue.Text = GetValueFew().ToClientJson();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                       "Вывод в Json",
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
        }

        private void buttonFromJsonValueNet_Click(object sender, EventArgs e)
        {
            try
            {
                string json = textBoxValue.Text;
                JsonObject obj = (JsonObject)JsonNode.Parse(json);
                obj = (JsonObject)obj["value"];
                textBoxValue.Text = obj["value"].ToString();
            }
            catch
            {

            }
        }

        private void butonReservNamesViewText_Click(object sender, EventArgs e)
        {
            try
            {
                ValueTextByControl = GetReservNames();
            }
            catch { }
        }

        public static string GetReservNames1() => GetReservNames();

        public static string GetJsonInfo()
        {
            try
            {
                return File.ReadAllText("JsonTransferInfo.txt");
            }
            catch 
            {
                return "";
            }
        }

        private void buttonJsonDataViewDialog_Click(object sender, EventArgs e)
        {
            MessageBox.Show(GetJsonInfo(), "Json-структура передаваемого текста", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonJsonDataViewText_Click(object sender, EventArgs e)
        {
            try
            {
                ValueTextByControl = GetJsonInfo();
            }
            catch { }
        }

        private void checkBoxRunNotificationWrite_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                GetValue().RunNotificationWrite = (sender as CheckBox).Checked;
            }
            catch { }
        }

        private void checkBoxRunNotificationSave_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                GetValue().RunNotificationSave = (sender as CheckBox).Checked;
            }
            catch { }
        }

        private void checkBoxAllowPutByNet_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBoxNoAllowPutByNet_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                GetValue().NoAllowPutByNet = (sender as CheckBox).Checked;
            }
            catch { }
        }

        private void buttonLoadNet_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue().LoadNetBuffer();
            }
            catch { }
        }

        private void buttonClearNetBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue().ClearNetBuffer();
            }
            catch { }
        }

        private void buttonNetBoth_Click(object sender, EventArgs e)
        {
            try
            {
                GetValue().LoadNetBufferWithClear();
            }
            catch { }
        }

        private void buttonShowNetBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                string text = GetValue().NetBuffer;

                TextEditorForm form = new TextEditorForm(text);
                form.Show();
            }
            catch { }
        }

        private void buttonTextEditorWithMain_Click(object sender, EventArgs e)
        {
            try
            {
                string text = ValueTextByControl;

                TextEditorForm form = new TextEditorForm(text);
                form.Show();
            }
            catch { }
        }

        private void buttonTextEditorWithValue_Click(object sender, EventArgs e)
        {
            try
            {
                string text = GetValue().Value;

                TextEditorForm form = new TextEditorForm(text);
                form.Show();
            }
            catch { }
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBoxPasswordServer_ValueChanged(Control control, EventArgs e, string value)
        {
            try
            {
                try
                {
                    GetValue().ServerPassword = value;
                }
                catch
                {

                }
            }
            catch { }
        }

        private void checkBoxServerPasswordShow_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                textBoxNameServer.UseSystemPasswordChar = !checkBoxServerPasswordShow.Checked;
            }
            catch { }
        }

        private void textBoxPassword_ValueChanged(Control control, EventArgs e, string value)
        {
            try
            {
                try
                {
                    GetValue().Password = value;
                }
                catch
                {

                }
            }
            catch { }
        }

        private void checkBoxShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            textBoxPassword.UseSystemPasswordChar = !checkBoxShowPassword.Checked;
        }

        private void checkBoxNessasirlyAuth_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                GetValue().NecessarilyAuthorization = checkBoxNessasirlyAuth.Checked;
            }
            catch { }
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            ProcessListForm form = new ProcessListForm();
            form.Show();
        }
    }
}
