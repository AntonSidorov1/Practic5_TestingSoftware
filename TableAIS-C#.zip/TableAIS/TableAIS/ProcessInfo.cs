﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableAIS
{
    public static class ProcessInfo
    {

        public static Process NowProcess => Process.GetCurrentProcess();


        public static ProcessClass NowProcessInfo = new ProcessClass(NowProcess);

        public static List<Process> Processes => new List<Process>(Process.GetProcesses());

        public static ListProcesses ProcessList => new ListProcesses(Processes.FindAll(p =>p.ProcessName == Application.ProductName));
    }
}
