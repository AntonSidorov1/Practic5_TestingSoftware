﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using System.Windows.Forms;
using TableAIS.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;

using System.IO.MemoryMappedFiles;
using System.Diagnostics;

namespace TableAIS
{




    internal static class Program
    {
        



        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ValueHelper.ListCalculator = new ListCalculator();
            UDPHelper.UdpPortClient = 9010;
            UDPHelper.UdpPortServer = 9020;
            UDPHelper.ServerStarting = false;
            SecondMetrForm.SecondDeltas = new List<SecondDelta>();
            TcpHelper.Values = new List<string>();
            TcpHelper.tick = 10;
            TcpHelper.jsonText = "";
            TcpHelper.jsonOutput = false;
            TcpHelper.message = "";
            TcpHelper.messageOutput = false;
            TcpHelper.ServerStarting = false;
            TcpHelper.ClientStarting = false;
            Buffer.Text = "";
            TcpHelper.ServerPort = 9000;
            TcpHelper.ClientPort = 9050;
            SecondMetrForm.SecondSaved = false;

            FuncGraphicsForm.ListX = new List<double>();
            FuncGraphicsForm.ListY = new List<double>();

            ExcelPatern.Workbooks = new List<Excel._Workbook>();
            CalculatorMemory.HistoryFew = new CalculatorMemoryList();

            SecurityHelper.SetPermissions();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());

            Environment.Exit(0);
        }
    }
}
