﻿
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading;

namespace TableAIS
{
    public static class TcpHelper
    {
        public static bool ServerStarting;
        public static bool ClientStarting;

        public static Socket ThisClient;
        public static Socket ThisServer;
        public static Socket RemoteClient;
        public static int ServerPort;
        public static int ClientPort;

        public static IPAddress IpAddressAny => IPAddress.Any;

        public static string GetIpAddressAny() => IpAddressAny.ToString();
        public static string IpAddressThis
        {
            get
            {
                List<string> addresses = new List<string>();
                IPAddress[] interfaces = Dns.GetHostAddresses(Dns.GetHostName());
                for(int i = 0; i < interfaces.Length; i++)
                {
                    addresses.Add(interfaces[i].ToString());
                }
                return String.Join("; \t", addresses);
            }
        }

        public static string GetIpAddressThis() => IpAddressThis.ToString();

        public static Thread ServerThread;

        public static void ServerStart()
        {
            IPEndPoint endPoint = new IPEndPoint(IpAddressAny, ServerPort);
            ThisServer = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            ThisServer.Bind(endPoint);
            ThisServer.Listen(10000);
            ServerThread = new Thread(GetValueToServer);
            ServerThread.Start();
        }

        public static void ClientStart()
        {
            IPEndPoint endPoint = new IPEndPoint(IpAddressAny, ClientPort);
            ThisClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                ThisClient.Bind(endPoint);
            }
            catch
            {

            }
        }

        public static string message;
        public static bool messageOutput;

        public static bool sending = false;

        public static void SendToServer(IPEndPoint socket, string text)
        {
            if (!ClientStarting || !SecurityHelper.TcpSendAllowed)
                throw new Exception();
            Thread send = new Thread(() =>
            {
                while (sending)
                {
                    Thread.Sleep(1);
                }
                try
                {
                    sending = true;
                    try
                    {
                        ThisClient.Connect(socket);
                    }
                    catch
                    {
                        ThisClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                        ThisClient.Connect(socket);
                    }
                    ThisClient.ReceiveTimeout = 10;
                    ThisClient.Send(Encoding.UTF8.GetBytes(text));
                    
                    message = TcpRecive(ThisClient);
                }
                catch (Exception ex)
                {
                    message = "Не отправлено!!!";
                }
                finally
                {
                    try
                    {
                        EndPoint point = new IPEndPoint(IpAddressAny, ClientPort);
                        try
                        {
                            ThisClient.Disconnect(false);
                        }
                        catch(Exception ex)
                        {

                        }

                        try
                        {
                            ThisClient.Shutdown(SocketShutdown.Both);

                        }
                        catch
                        {

                        }
                        try
                        {
                            ThisClient.Close(0);

                        }
                        catch
                        {

                        }

                        try
                        {
                            ThisClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                            ThisClient.Bind(point);
                        }
                        catch
                        {

                        }
                    }
                    catch(Exception ex)
                    {
                        try
                        {
                            ThisClient.Disconnect(false);
                        }
                        catch (Exception e)
                        {

                        }
                        try
                        {
                            ThisClient.Shutdown(SocketShutdown.Both);

                        }
                        catch
                        {

                        }
                        try
                        {
                            ThisClient.Close();

                        }
                        catch
                        {

                        }
                    }

                    messageOutput = true;
                    sending = false;
                }

            });
            send.Start();
        }

        public static void ServerStop()
        {
            ServerStarting = false;
            try
            {
                ServerThread.Abort();
            }
            catch { }
            try
            {
                ServerThread.Interrupt();
            }
            catch { }
            try
            {
                RemoteClient.Close();
            }
            catch
            {

            }
            try
            {
                ThisServer.Close();
            }
            catch
            {

            }
        }

        public static void ClientStop()
        {
            ClientStarting = false;
            try
            {
                ThisClient.Close();
            }
            catch
            {

            }
        }

        public static void NetworkStop()
        {
            ServerStop();
            ClientStop();
        }

        public static string jsonText;
        public static bool jsonOutput;
        public static int tick;

        public static void SetValue()
        {

            try
            {
                if(jsonOutput)
                {
                    MainForm.Files.SetValueOfJson(jsonText);
                }
                jsonOutput = false;
            }
            catch
            {
                tick--;
                if(tick == 0)
                {
                    jsonOutput = false;
                    tick = 10;
                    Buffer.Text = jsonText;
                }

            }
        }

        public static List<string> Values;

        public static void GetValueToServer()
        {
            GetValueToServer(Values);
        }

        public static MainForm mainForm;

        public static string MessageRequest;


        static bool threadReciveRun;
        public static void SetValueFromServer(string json)
        {
            threadReciveRun = true;
            MessageRequest = "Успешно";
            jsonText = json;

            bool allowed = SecurityHelper.TcpReciveAllowed;
            if(!allowed)
            {
                MessageRequest = "Запрешено!!!";
            }

            bool requred = mainForm.InvokeRequired && allowed;
            if (requred)
            {
                IAsyncResult result = mainForm.BeginInvoke(new Action(() =>
                {
                    FilesList files = MainForm.Files;

                    try
                    {
                        JsonObject obj = (JsonObject)JsonNode.Parse(json);
                        string text = obj["name"].ToString();
                        string password = "";
                        try
                        {
                            password = obj["password"].ToString();
                        }
                        catch
                        {

                        }
                        string name = text;
                        obj = (JsonObject)obj["value"];
                        text = obj["name"].ToString();
                        text = obj["value"].ToString();

                        if(!files.ContainsValue(name))
                        {
                            MessageRequest = "Не найдено!!!";
                            Buffer.Text = json;
                        }
                        else if (!files.AllowPutByNet(name))
                        {
                            try
                            {
                                files.SetValueOfJsonNetBuffer(json);
                            }
                            catch { }
                            MessageRequest = "Запрещено!!!";
                            try
                            {
                                files.NotificationView(name, $"Была произведена попытка безуспешной передачи текста значению \"{name}\" с другого устройства по протоколу TCP \n" +
                                    $"Текст сохранён в сетевой буфер данного значения, откуда вы его можете присвоить значению \n" +
                                    $"Просмотреть изменения значения...");
                            }
                            catch
                            {
                                Buffer.Text = json;
                            }
                        }
                        else if (!files.CorrectPassword(name, password))
                        {
                            try
                            {
                                files.SetValueOfJsonNetBuffer(json);
                            }
                            catch { }
                            MessageRequest = "Неверный пароль!!!";
                            try
                            {
                                files.NotificationView(name, $"Была произведена попытка безуспешной передачи текста значению \"{name}\" с другого устройства по протоколу TCP с неправильно введённым паролем\n" +
                                    $"Текст сохранён в сетевой буфер данного значения, откуда вы его можете присвоить значению \n" +
                                    $"Просмотреть изменения значения...");
                            }
                            catch
                            {
                                Buffer.Text = json;
                            }
                        }
                        else
                        {
                            try
                            {
                                files.SetValueOfJson(json);
                                MessageRequest = "Успешно";
                            }
                            catch(Exception e)
                            {

                                MessageRequest = "Ошибка!!!";
                                Buffer.Text = json;
                            }
                        }
                        
                    }
                    catch
                    {
                        MessageRequest = "Не верно!!!";
                        Buffer.Text = json;
                    }
                    threadReciveRun = false;

                }
                    ));
                while(threadReciveRun)
                {
                    Thread.Sleep(5);
                }
            }

            
        }

        public static void GetValueToServer(List<string> values)
        {
            try
            {
                while(ServerStarting)
                {
                    RemoteClient = ThisServer.Accept();
                    try
                    {
                        string json = TcpRecive(RemoteClient);

                        jsonText = json;
                        //jsonOutput = true;

                        try
                        {
                            //SetValueFromServer(json);
                            string message = "Успешно";
                            try
                            {
                                JsonObject obj = (JsonObject)JsonNode.Parse(json);
                                string text = obj["name"].ToString();
                                obj = (JsonObject)obj["value"];
                                text = obj["name"].ToString();
                                text = obj["value"].ToString();
                                SetValueFromServer(json);
                                message = MessageRequest;
                            }
                            catch
                            {
                                message = "Не верно!!!";
                            }
                            RemoteClient.Send(Encoding.UTF8.GetBytes(message));
                        }
                        catch
                        {
                            
                        }
                    }
                    catch
                    {
                        try
                        {
                            RemoteClient.Send(Encoding.UTF8.GetBytes("Не получено!!!"));
                        }
                        catch
                        {

                        }
                    }
                    finally
                    {
                        try
                        {
                            RemoteClient.Disconnect(false);
                        }
                        catch (Exception ex)
                        {

                        }

                        try
                        {
                            RemoteClient.Shutdown(SocketShutdown.Both);
                        }
                        catch
                        {

                        }
                        try
                        {

                            RemoteClient.Close();
                        }
                        catch
                        {

                        }
                    }
                }
            }
            catch
            {
            }
            finally
            {
                try
                {
                    RemoteClient.Disconnect(false);
                }
                catch (Exception ex)
                {

                }

                try
                {
                    RemoteClient.Shutdown(SocketShutdown.Both);
                }
                catch
                {

                }
                try
                {

                    RemoteClient.Close();
                }
                catch
                {

                }
                ServerStarting = false;
            }
        }

        public static string TcpRecive(Socket client)
        {
            int recv =0;



            byte[] data = new byte[1024];
            List<byte> bytes = new List<byte>();

            do
            {
                try
                {
                    recv = client.Receive(data);
                    data = Encoding.UTF8.GetBytes(Encoding.UTF8.GetString(data, 0, recv));
                    bytes.AddRange(data);
                }
                catch
                {

                }
            }
            while (client.Available > 0 && recv > 0);
            return Encoding.UTF8.GetString(bytes.ToArray());
        }

    }
}
