"""ИДЗ 2. Сидоров Антон Дмитриевич. Группа 3586"""

# /// Сравнивает num с нулём, и если больше, то прибавляет plus
def NumberPlusIfLessZero(num:int, plus:int, zero:int = 0):
    if num < zero:
        num += plus
    return num    

Facultets = ["ФРТ", "ФЕЛ", "ФКТИ", "ФЭА", "ФИБС", "ИНПРОТЕХ", "ГФ", "ИФИО", "АСП"] #список факультетов

import datetime
LastName="Сидоров"
FirstName="Антон"
SecondName="Дмитриевич"
FIO: str = LastName+" "+FirstName+" "+SecondName
Zachetka: int = 358613
date:datetime = datetime.datetime.now()
Year:int = date.year
print("Год "+str(Year))
print(date.strftime("%d-%m-%Y"))
Year %= 10
Group:int = Zachetka // 100
coll:int = 49
print("_"*coll)
print(f'|\t{f"":<32}\t|')
print(f'|\t{f"{FIO:>30}":<32}\t|')
print(f"|{f'Группа {Group}':<32}\t\t|")
print(f"|{f'Номер студенческого билета {Zachetka}':<32}\t\t|")
print(f'|\t{f"":<32}\t|')
print("_"*coll)
Number:int = Zachetka % 100
YearGroup:int = Group // 1000
Kours:int = Year-YearGroup+1
Facultet:int = (Group // 100) % 10
N = NumberPlusIfLessZero(Facultet-1, 9)
FacultetName : str = Facultets[N]
Kours = NumberPlusIfLessZero(Kours, 10, 1)
x: int = 20
y:int = 10
print(f'|\t|{"Курс":>20}|{Kours:<10}|\t|')
print(f'|\t|{"Факультет":>20}|{Facultet:<10}|\t|')
print(f'|\t|{"":>20}|{f"({FacultetName})":<10}|\t|')
print(f'|\t|{"Группа":>20}|{Group:<10}|\t|')
print(f'|\t|{"Подгруппа":>20}|{Group % 100:<10}|\t|')
print(f'|\t|{"Номер в ведомости":>20}|{Number:<10}|\t|')
print(f'|\t|{"Номер зачётки":>20}|{Zachetka:<10}|\t|')
print("_"*coll, "\n")
