"""Функции для ИДЗ1. сидоров антон дмитриевич, Группа 3586"""
import datetime


def input_int(message: str) -> int:
    """Ввод целого числа с проверкой"""
    res:int = 0
    while True:
        try:
            print(f"Введите целое число ({message})")
            res = int(input())
            break
        except Exception:
            print("Ошибка!!! Error 400 Bad Request")
            print("Значение должно быть целым числом")
    return res

def get_now_date() -> str :
    "Получить текущие дату и время"
    date:datetime = datetime.datetime.now()
    return date.strftime(date.strftime("%d-%m-%Y %H:%M:%S"))
