"""ИДЗ-4. Сидоров Антон Дмитриевич, Группа 3586"""


from functions import *
from students import *
from grades import *
from students_grades import *
print("ИДЗ-4. Словари, циклы ")
print("Автор программы – студент Группы 3586, Сидоров Антон Дмитриевич")

print("Время запуска: "+get_now_date())

grades_coll:int = input_int("Количество оценок");
columsCount: int =  grades_coll;

students: dict = create_students()
for student, grades in students.items():
    MIN_GRADE, MAX_GRADE = 1, 5
    if student == "сидоров антон дмитриевич":
        MIN_GRADE = 4
    grades += create_grades(MIN_GRADE, MAX_GRADE, columsCount)

print(f"\n{"Оценки до исправления":^50}")
print_students(students)

students = grades_correct(students);

print(f"\n{"Оценки после исправления":^50}")
print_students(students)

print();
