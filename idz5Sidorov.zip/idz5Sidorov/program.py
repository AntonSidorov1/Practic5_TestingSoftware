"""ИДЗ-5, Список экземпляров класса.\n""" \
     """Автор программы — Сидоров Антон Дмитриевич, Группа 3586 \n"""

from functions import get_now_date
#from students import *
#from grades import *
#from students_grades import *
from student import Student
print(__doc__)
print(f" Дата и время запуска программы: {get_now_date()} \n")
#Num:int = input_int("Целое число")


students: list = [
    Student("Огрыпвыа", "Лвимоалм", "Имаум"),
    Student("Ртгытмг", "Лиишми", ""),
    Student("сидоров", "антон", "дмитриевич"),
    Student("Фашмрравш", "Шшрагри"),
    Student("Хшармимшравы", "Арммшгшва", "Ырггвааива"),
]

print("Список студентов:")
Student.line()
for student in students:
    print(student)
Student.line()
