"""Функции для ИДЗ1. сидоров антон дмитриевич, Группа 3586"""
import datetime


def input_int(message: str) -> int:
    """Ввод целого числа с проверкой"""
    res:int = 0
    while True:
        try:
            res = int(input(f"Введите целое число ({message})>> "))
            break
        except Exception as e:
            print("Ошибка!!! Error 400 Bad Request")
            print("Значение должно быть целым числом")
            print(e)
    return res

def get_now_date() -> str :
    "Получить текущие дату и время"
    date:datetime = datetime.datetime.now()
    return date.strftime(date.strftime("%d-%m-%Y %H:%M:%S"))

def text_correct(text:str) -> str:
    """Исправить заданный текст"""
    text = text.strip()
    text = text.replace(",", " ")
    text = text.replace(".", " ")
    text = text.replace("-", " ")
    text = text.replace("_", " ")
    text = text.strip()
    return text
