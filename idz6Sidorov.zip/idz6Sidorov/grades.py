"""Файл с функциями для работы с оценками"""
import random as rmd

def up3(grade: int) -> int:
    """Увеличить оценку до 3-х, если она ниже 3-х"""
    return 3 if grade < 3 else grade

def up4(grade: int) -> int:
    """С вероятностью 30% увеличить оценку на 1 бал, если она ниже 4"""
    if rmd.random() <= 0.3 and grade <4:
        return grade+1
    else:
        return grade

def up5(grade: int) -> int:
    """С вероятностью 10% увеличить оценку на 1 бал, если она ниже 5"""
    if rmd.random() <= 0.1 and grade <5:
        return grade+3
    else:
        return grade
