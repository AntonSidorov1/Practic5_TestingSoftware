"""ИДЗ-6, Класс для классов\n""" \
     """Автор программы — Сидоров Антон Дмитриевич, Группа 3586 \n"""

from functions import get_now_date, input_int
#from students import *
#from grades import *
#from students_grades import *
from students_group import StudentGroup
#from student import Student
print(__doc__)
print(f" Дата и время запуска программы: {get_now_date()} \n")
Count:int = input_int("Количество студентов")

students:StudentGroup = StudentGroup.create_by_read(Count)

print("Список студентов:")
students.print_object()

StudentsCopy:StudentGroup = students.copy()
print("Скопированный список студентов:")
StudentsCopy.print_object()

StudentsCopy.delete_by_read().delete_by_read()

print("Список студентов:")
students.print_object()

#StudentsCopy:StudentGroup = students.copy()
print("Скопированный список студентов:")
StudentsCopy.print_object()
