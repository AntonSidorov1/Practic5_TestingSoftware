"""Класс, в котором определены методы для копирования и строкового представления объекта"""
import copy

class StringObj:
    """Класс, в котором определены методы для копирования и строкового представления объекта"""

    def to_string(self) -> str:
        "Строковое представление объекта"
        return "Object"

    def __str__(self) -> str:
        "Строковое представление объекта"
        return self.to_string()

    def __repl__(self) -> str:
        "Строковое представление объекта"
        return self.__str__()

    def print_object(self):
        "Вывести строковое представление объекта"
        print(self)

    def __init__(self):
        pass

    def copy(self):
        """Создаёт полную копию объекта"""
        return copy.deepcopy(self)
