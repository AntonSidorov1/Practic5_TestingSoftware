"""Класс студента"""
from string_obj import StringObj
from functions import text_correct
class Student (StringObj):
    """Класс с методами для работы со студентами. Унаследован от StringObj """    

    last_name_len:int=0
    first_name_len:int=0
    second_name_len:int=0

    @staticmethod
    def create_student(fio:str):
        """Создание объекта класса"""
        return Student(fio)

    def fio(self) -> str:
        """ФИО студента"""
        return f"{self.last_name} {self.first_name} {self.second_name}"

    @staticmethod
    def get_line() -> str:
        """Горизонтальная отсечка у списка студентов"""
        len_line:int=Student.last_name_len+Student.first_name_len+Student.second_name_len+11
        return "-"*len_line

    @staticmethod
    def line() -> None:
        """Горизонтальная отсечка у списка студентов"""
        print(Student.get_line())

    def __init__(self,
                last_name:str,
                first_name:str = "",
                second_name:str=""
    ) -> None:
        """Создание объекта класса"""
        super().__init__()
        last_name = text_correct(last_name)
        first_name = text_correct(first_name)
        second_name = text_correct(second_name)
        if first_name == "":

            parts = last_name.split()
            self.last_name = parts[0]
            self.first_name = parts[1]
            if len(parts)>2:
                self.second_name = parts[2]
            else:
                self.second_name = ""
        else:
            self.last_name=last_name
            self.first_name=first_name
            self.second_name=second_name
        Student.first_name_len = max(len(self.first_name), Student.first_name_len)
        Student.second_name_len = max(len(self.second_name), Student.second_name_len)
        Student.last_name_len = max(len(self.last_name), Student.last_name_len)

    def to_string(self) -> str:
        return "| "\
        +f"{self.last_name:<{Student.last_name_len}}"\
        +" | "\
        +f"{self.first_name:<{Student.first_name_len}}"\
        +" | "\
        +f" {self.second_name:<{Student.second_name_len}}"\
        +" |"
