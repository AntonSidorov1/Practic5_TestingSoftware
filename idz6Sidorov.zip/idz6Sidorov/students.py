"""Файл с функциями для работы со студентами"""
import random as rand

def create_students()->dict:
    """Создание списка студентов"""
    students:dict = {} # students:dict = dict()
    students["Огрыпвыа Лвимоалм Имаум"]=[]
    students["Ртгытмг Лиишми Выришфа"]=[]
    students["сидоров антон дмитриевич"] = []
    students["Фашмрравш Шшрагри Шгармшг"]=[]
    students["Хшармимшравы Арммшгшва Ырггвааива"]=[]
    return students

def create_grades(min_grades: int, max_grades:int, count:int) -> list:
    """Метод генерации оценок"""
    return [rand.randint(min_grades, max_grades) for _ in range(count)]

def print_students(students: dict):
    """Вывод оценок"""
    max_len:int = len(max(students, key=len))
    for student, grades in students.items():
        grades_row:str = str(grades)
        grades_row = grades_row.replace("[", "")
        grades_row = grades_row.replace("]", "")
        grades_row = grades_row.replace(";", "")
        grades_row = grades_row.replace(",", "")
        print(f"| {(str(student)):<{max_len}} | {grades_row} |")
