"""Файл с функциями для исправления оценок у студентов"""
from grades import *
from students import *

def grades_up3(grades: list)->list:
    """Увеличить оценку до 3-х, если она ниже 3-х в списке оценок"""
    return list(map(lambda grade: up3(grade), grades))

def grades_up4(grades: list) -> list:
    """С вероятностью 30% увеличить оценку на 1 бал, если она ниже 4 в списке оценок"""
    return list(map(lambda grade: up4(grade), grades))

def grades_up5(grades: list) -> list:
    """С вероятностью 10% увеличить оценку на 1 бал, если она ниже 5 в списке оценок"""
    return list(map(lambda grade: up5(grade), grades))

def grades_list_correct(grades: list) -> list:
    """Исправить оценки в списке"""
    grades = grades_up5(grades)
    grades = grades_up4(grades)
    grades = grades_up3(grades)
    return grades

def grades_correct(students:dict) -> dict:
    """Исправить оценки у весх студентов"""
    return {student: grades_list_correct(grades) for student, grades in students.items() }
