"Класс - Группа студентов"

from student import Student
from string_obj import StringObj
from functions import text_correct

class StudentGroup (StringObj):
    "Класс - Группа студентов. Унаследован от StringObj "

    students_dict:dict

    __group__:int

    @property
    def group(self) -> int:
        """Получить или задать номер группы"""
        return self.__group__
    
    @group.setter
    def group(self, value:int):
        self.__group__ = value

    def add_student(self, student:Student) -> None:
        "Добавить студента в список по объекту"
        self.students_dict[student.fio()]=student

    def add_student_by_fio(self, fio:str) -> None:
        "Добавить студента по его ФИО"
        fio = text_correct(fio)
        self.students_dict[fio]=Student(fio)

    def set_students_fio_range(self, students:list) -> None:
        "Добавить студентов по списку фамилий"
        self.students_dict = {text_correct(fio):Student(fio) for fio in students}

    def delete_student(self, fio:str) -> None:
        "Удалить студента с заданной ФИО"
        del self.students_dict[fio]

    def __init__(self, group:int = 3586) -> None:
        """Создать объект класса"""
        super().__init__()
        self.group = group
        self.students_dict = {}

    def get_list_students(self) -> list:
        """Получить список студентов"""
        keys = self.students_dict.keys()
        students:list = list()
        for key in keys:
            students.append(self.students_dict[key])
        return students

    def to_string(self) -> str:
        text:str = "Номер группы - "+str(self.group)+ "\n"+Student.get_line()
        students:list = self.get_list_students()
        for student in students:
            text += "\n"+student.to_string()
        text += "\n"+ Student.get_line()
        return text

    def print_list_students(self) -> None:
        "Выводит список студентов"
        self.print_object()

    def read_group(self, count:int)->None:
        """Ввод студентов, с клавиатуры"""
        for i in range(count):
            while True:
                try:
                    fio = input(f"Введите ФИО {i+1}-го студента >>")
                    self.add_student_by_fio(fio)
                    break
                except Exception as e:
                    print("Ошибка!!! Error 400 Bad Request")
                    print("Неверный формат ФИО")
                    print(e)

    @staticmethod
    def create_by_read(count:int):
        """Ввод студентов, с клавиатуры"""
        students:StudentGroup = StudentGroup()
        students.read_group(count)
        return students

    def contains_student(self, fio:str)->bool:
        """Есть ли студент с заданной ФИО в группе"""
        return fio in self.students_dict.keys()

    def delete_by_read(self):
        """Удаляет из группы студента, ФИО которого пользователь ввёл с клавиатуры"""
        fio:str = text_correct(input("Введите фамилию удаляемого студента >> "))
        try:
            if not self.contains_student(fio):
                raise ValueError("Студента с заданными ФИО не существует")
            self.delete_student(fio)
            print("Студент успешно удалён \n")
        except Exception as e:
            print("Ошибка!!! Error 400 Bad Request")
            print("Не удалось удалить студента из группы")
            print(e)
            print()
        return self
